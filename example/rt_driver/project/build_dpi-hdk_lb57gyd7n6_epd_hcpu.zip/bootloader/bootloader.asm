
build_dpi-hdk_lb57gyd7n6_epd_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020204 <deregister_tm_clones>:
20020204:	4803      	ldr	r0, [pc, #12]	@ (20020214 <deregister_tm_clones+0x10>)
20020206:	4b04      	ldr	r3, [pc, #16]	@ (20020218 <deregister_tm_clones+0x14>)
20020208:	4283      	cmp	r3, r0
2002020a:	d002      	beq.n	20020212 <deregister_tm_clones+0xe>
2002020c:	4b03      	ldr	r3, [pc, #12]	@ (2002021c <deregister_tm_clones+0x18>)
2002020e:	b103      	cbz	r3, 20020212 <deregister_tm_clones+0xe>
20020210:	4718      	bx	r3
20020212:	4770      	bx	lr
20020214:	20044a08 	.word	0x20044a08
20020218:	20044a08 	.word	0x20044a08
2002021c:	00000000 	.word	0x00000000

20020220 <register_tm_clones>:
20020220:	4b06      	ldr	r3, [pc, #24]	@ (2002023c <register_tm_clones+0x1c>)
20020222:	4907      	ldr	r1, [pc, #28]	@ (20020240 <register_tm_clones+0x20>)
20020224:	1ac9      	subs	r1, r1, r3
20020226:	1089      	asrs	r1, r1, #2
20020228:	bf48      	it	mi
2002022a:	3101      	addmi	r1, #1
2002022c:	1049      	asrs	r1, r1, #1
2002022e:	d003      	beq.n	20020238 <register_tm_clones+0x18>
20020230:	4b04      	ldr	r3, [pc, #16]	@ (20020244 <register_tm_clones+0x24>)
20020232:	b10b      	cbz	r3, 20020238 <register_tm_clones+0x18>
20020234:	4801      	ldr	r0, [pc, #4]	@ (2002023c <register_tm_clones+0x1c>)
20020236:	4718      	bx	r3
20020238:	4770      	bx	lr
2002023a:	bf00      	nop
2002023c:	20044a08 	.word	0x20044a08
20020240:	20044a08 	.word	0x20044a08
20020244:	00000000 	.word	0x00000000

20020248 <__do_global_dtors_aux>:
20020248:	b510      	push	{r4, lr}
2002024a:	4c06      	ldr	r4, [pc, #24]	@ (20020264 <__do_global_dtors_aux+0x1c>)
2002024c:	7823      	ldrb	r3, [r4, #0]
2002024e:	b943      	cbnz	r3, 20020262 <__do_global_dtors_aux+0x1a>
20020250:	f7ff ffd8 	bl	20020204 <deregister_tm_clones>
20020254:	4b04      	ldr	r3, [pc, #16]	@ (20020268 <__do_global_dtors_aux+0x20>)
20020256:	b113      	cbz	r3, 2002025e <__do_global_dtors_aux+0x16>
20020258:	4804      	ldr	r0, [pc, #16]	@ (2002026c <__do_global_dtors_aux+0x24>)
2002025a:	f3af 8000 	nop.w
2002025e:	2301      	movs	r3, #1
20020260:	7023      	strb	r3, [r4, #0]
20020262:	bd10      	pop	{r4, pc}
20020264:	20044a08 	.word	0x20044a08
20020268:	00000000 	.word	0x00000000
2002026c:	20027464 	.word	0x20027464

20020270 <frame_dummy>:
20020270:	b508      	push	{r3, lr}
20020272:	4b05      	ldr	r3, [pc, #20]	@ (20020288 <frame_dummy+0x18>)
20020274:	b11b      	cbz	r3, 2002027e <frame_dummy+0xe>
20020276:	4905      	ldr	r1, [pc, #20]	@ (2002028c <frame_dummy+0x1c>)
20020278:	4805      	ldr	r0, [pc, #20]	@ (20020290 <frame_dummy+0x20>)
2002027a:	f3af 8000 	nop.w
2002027e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020282:	f7ff bfcd 	b.w	20020220 <register_tm_clones>
20020286:	bf00      	nop
20020288:	00000000 	.word	0x00000000
2002028c:	20044a0c 	.word	0x20044a0c
20020290:	20027464 	.word	0x20027464

20020294 <boot_uart_tx>:
20020294:	2300      	movs	r3, #0
20020296:	b510      	push	{r4, lr}
20020298:	4293      	cmp	r3, r2
2002029a:	db00      	blt.n	2002029e <boot_uart_tx+0xa>
2002029c:	bd10      	pop	{r4, pc}
2002029e:	69c4      	ldr	r4, [r0, #28]
200202a0:	0624      	lsls	r4, r4, #24
200202a2:	d5fc      	bpl.n	2002029e <boot_uart_tx+0xa>
200202a4:	5ccc      	ldrb	r4, [r1, r3]
200202a6:	3301      	adds	r3, #1
200202a8:	6284      	str	r4, [r0, #40]	@ 0x28
200202aa:	e7f5      	b.n	20020298 <boot_uart_tx+0x4>

200202ac <mpu_config>:
200202ac:	4770      	bx	lr

200202ae <cache_enable>:
200202ae:	4770      	bx	lr

200202b0 <board_pinmux_mpi1_type1>:
200202b0:	b510      	push	{r4, lr}
200202b2:	2100      	movs	r1, #0
200202b4:	f640 3004 	movw	r0, #2820	@ 0xb04
200202b8:	f003 ffaa 	bl	20024210 <HAL_PIN_Set2>
200202bc:	2100      	movs	r1, #0
200202be:	f44f 7082 	mov.w	r0, #260	@ 0x104
200202c2:	f003 ffa5 	bl	20024210 <HAL_PIN_Set2>
200202c6:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202ca:	f640 5004 	movw	r0, #3332	@ 0xd04
200202ce:	f003 ff9f 	bl	20024210 <HAL_PIN_Set2>
200202d2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202d6:	f44f 7041 	mov.w	r0, #772	@ 0x304
200202da:	f003 ff99 	bl	20024210 <HAL_PIN_Set2>
200202de:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202e2:	f240 5004 	movw	r0, #1284	@ 0x504
200202e6:	f003 ff93 	bl	20024210 <HAL_PIN_Set2>
200202ea:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202ee:	f640 4004 	movw	r0, #3076	@ 0xc04
200202f2:	f003 ff8d 	bl	20024210 <HAL_PIN_Set2>
200202f6:	2400      	movs	r4, #0
200202f8:	2201      	movs	r2, #1
200202fa:	3401      	adds	r4, #1
200202fc:	4611      	mov	r1, r2
200202fe:	4620      	mov	r0, r4
20020300:	f003 ffd0 	bl	200242a4 <HAL_PIN_Set_DS0>
20020304:	2200      	movs	r2, #0
20020306:	2101      	movs	r1, #1
20020308:	4620      	mov	r0, r4
2002030a:	f003 ffe1 	bl	200242d0 <HAL_PIN_Set_DS1>
2002030e:	2c0d      	cmp	r4, #13
20020310:	d1f2      	bne.n	200202f8 <board_pinmux_mpi1_type1+0x48>
20020312:	bd10      	pop	{r4, pc}

20020314 <board_pinmux_mpi1_type2>:
20020314:	b510      	push	{r4, lr}
20020316:	2100      	movs	r1, #0
20020318:	f640 3004 	movw	r0, #2820	@ 0xb04
2002031c:	f003 ff78 	bl	20024210 <HAL_PIN_Set2>
20020320:	2100      	movs	r1, #0
20020322:	f240 4004 	movw	r0, #1028	@ 0x404
20020326:	f003 ff73 	bl	20024210 <HAL_PIN_Set2>
2002032a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002032e:	f640 5004 	movw	r0, #3332	@ 0xd04
20020332:	f003 ff6d 	bl	20024210 <HAL_PIN_Set2>
20020336:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002033a:	f44f 7041 	mov.w	r0, #772	@ 0x304
2002033e:	f003 ff67 	bl	20024210 <HAL_PIN_Set2>
20020342:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020346:	f44f 7001 	mov.w	r0, #516	@ 0x204
2002034a:	f003 ff61 	bl	20024210 <HAL_PIN_Set2>
2002034e:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020352:	f640 2004 	movw	r0, #2564	@ 0xa04
20020356:	f003 ff5b 	bl	20024210 <HAL_PIN_Set2>
2002035a:	2400      	movs	r4, #0
2002035c:	2201      	movs	r2, #1
2002035e:	3401      	adds	r4, #1
20020360:	4611      	mov	r1, r2
20020362:	4620      	mov	r0, r4
20020364:	f003 ff9e 	bl	200242a4 <HAL_PIN_Set_DS0>
20020368:	2200      	movs	r2, #0
2002036a:	2101      	movs	r1, #1
2002036c:	4620      	mov	r0, r4
2002036e:	f003 ffaf 	bl	200242d0 <HAL_PIN_Set_DS1>
20020372:	2c0d      	cmp	r4, #13
20020374:	d1f2      	bne.n	2002035c <board_pinmux_mpi1_type2+0x48>
20020376:	bd10      	pop	{r4, pc}

20020378 <board_pinmux_mpi2>:
20020378:	b510      	push	{r4, lr}
2002037a:	2100      	movs	r1, #0
2002037c:	f641 2004 	movw	r0, #6660	@ 0x1a04
20020380:	f003 ff46 	bl	20024210 <HAL_PIN_Set2>
20020384:	2100      	movs	r1, #0
20020386:	f241 4004 	movw	r0, #5124	@ 0x1404
2002038a:	f003 ff41 	bl	20024210 <HAL_PIN_Set2>
2002038e:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020392:	f641 0004 	movw	r0, #6148	@ 0x1804
20020396:	f003 ff3b 	bl	20024210 <HAL_PIN_Set2>
2002039a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002039e:	f241 3004 	movw	r0, #4868	@ 0x1304
200203a2:	f003 ff35 	bl	20024210 <HAL_PIN_Set2>
200203a6:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203aa:	f241 2004 	movw	r0, #4612	@ 0x1204
200203ae:	f003 ff2f 	bl	20024210 <HAL_PIN_Set2>
200203b2:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203b6:	f641 1004 	movw	r0, #6404	@ 0x1904
200203ba:	f003 ff29 	bl	20024210 <HAL_PIN_Set2>
200203be:	240e      	movs	r4, #14
200203c0:	2201      	movs	r2, #1
200203c2:	4620      	mov	r0, r4
200203c4:	4611      	mov	r1, r2
200203c6:	f003 ff6d 	bl	200242a4 <HAL_PIN_Set_DS0>
200203ca:	4620      	mov	r0, r4
200203cc:	2200      	movs	r2, #0
200203ce:	2101      	movs	r1, #1
200203d0:	3401      	adds	r4, #1
200203d2:	f003 ff7d 	bl	200242d0 <HAL_PIN_Set_DS1>
200203d6:	2c1b      	cmp	r4, #27
200203d8:	d1f2      	bne.n	200203c0 <board_pinmux_mpi2+0x48>
200203da:	bd10      	pop	{r4, pc}

200203dc <board_pinmux_mpi3>:
200203dc:	b510      	push	{r4, lr}
200203de:	2100      	movs	r1, #0
200203e0:	f642 3001 	movw	r0, #11009	@ 0x2b01
200203e4:	f003 ff14 	bl	20024210 <HAL_PIN_Set2>
200203e8:	2100      	movs	r1, #0
200203ea:	f242 7001 	movw	r0, #9985	@ 0x2701
200203ee:	f003 ff0f 	bl	20024210 <HAL_PIN_Set2>
200203f2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200203f6:	f642 2001 	movw	r0, #10753	@ 0x2a01
200203fa:	f003 ff09 	bl	20024210 <HAL_PIN_Set2>
200203fe:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020402:	f642 0001 	movw	r0, #10241	@ 0x2801
20020406:	f003 ff03 	bl	20024210 <HAL_PIN_Set2>
2002040a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002040e:	f642 1001 	movw	r0, #10497	@ 0x2901
20020412:	f003 fefd 	bl	20024210 <HAL_PIN_Set2>
20020416:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002041a:	f642 4001 	movw	r0, #11265	@ 0x2c01
2002041e:	f003 fef7 	bl	20024210 <HAL_PIN_Set2>
20020422:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20020426:	4b13      	ldr	r3, [pc, #76]	@ (20020474 <board_pinmux_mpi3+0x98>)
20020428:	2427      	movs	r4, #39	@ 0x27
2002042a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002042e:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20020432:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020436:	f44f 4200 	mov.w	r2, #32768	@ 0x8000
2002043a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002043e:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020442:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020446:	f44f 4280 	mov.w	r2, #16384	@ 0x4000
2002044a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002044e:	f44f 3200 	mov.w	r2, #131072	@ 0x20000
20020452:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020456:	2201      	movs	r2, #1
20020458:	4620      	mov	r0, r4
2002045a:	4611      	mov	r1, r2
2002045c:	f003 ff22 	bl	200242a4 <HAL_PIN_Set_DS0>
20020460:	4620      	mov	r0, r4
20020462:	2200      	movs	r2, #0
20020464:	2101      	movs	r1, #1
20020466:	3401      	adds	r4, #1
20020468:	f003 ff32 	bl	200242d0 <HAL_PIN_Set_DS1>
2002046c:	2c2d      	cmp	r4, #45	@ 0x2d
2002046e:	d1f2      	bne.n	20020456 <board_pinmux_mpi3+0x7a>
20020470:	bd10      	pop	{r4, pc}
20020472:	bf00      	nop
20020474:	500ca000 	.word	0x500ca000

20020478 <board_pinmux_sd>:
20020478:	b510      	push	{r4, lr}
2002047a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002047e:	f642 2002 	movw	r0, #10754	@ 0x2a02
20020482:	f003 fec5 	bl	20024210 <HAL_PIN_Set2>
20020486:	f44f 4300 	mov.w	r3, #32768	@ 0x8000
2002048a:	4c1c      	ldr	r4, [pc, #112]	@ (200204fc <board_pinmux_sd+0x84>)
2002048c:	2014      	movs	r0, #20
2002048e:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
20020492:	f001 fa68 	bl	20021966 <HAL_Delay_us>
20020496:	2100      	movs	r1, #0
20020498:	f642 1002 	movw	r0, #10498	@ 0x2902
2002049c:	f003 feb8 	bl	20024210 <HAL_PIN_Set2>
200204a0:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204a4:	f642 3002 	movw	r0, #11010	@ 0x2b02
200204a8:	f003 feb2 	bl	20024210 <HAL_PIN_Set2>
200204ac:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204b0:	f642 4002 	movw	r0, #11266	@ 0x2c02
200204b4:	f003 feac 	bl	20024210 <HAL_PIN_Set2>
200204b8:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204bc:	f242 7002 	movw	r0, #9986	@ 0x2702
200204c0:	f003 fea6 	bl	20024210 <HAL_PIN_Set2>
200204c4:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204c8:	f642 0002 	movw	r0, #10242	@ 0x2802
200204cc:	f003 fea0 	bl	20024210 <HAL_PIN_Set2>
200204d0:	f44f 4380 	mov.w	r3, #16384	@ 0x4000
200204d4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204d8:	f44f 3380 	mov.w	r3, #65536	@ 0x10000
200204dc:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e0:	f44f 3300 	mov.w	r3, #131072	@ 0x20000
200204e4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e8:	f44f 5380 	mov.w	r3, #4096	@ 0x1000
200204ec:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f0:	f44f 5300 	mov.w	r3, #8192	@ 0x2000
200204f4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f8:	bd10      	pop	{r4, pc}
200204fa:	bf00      	nop
200204fc:	500ca000 	.word	0x500ca000

20020500 <board_boot_from>:
20020500:	b508      	push	{r3, lr}
20020502:	2000      	movs	r0, #0
20020504:	f007 f9b2 	bl	2002786c <HAL_Get_backup>
20020508:	f000 000f 	and.w	r0, r0, #15
2002050c:	bd08      	pop	{r3, pc}

2002050e <board_init>:
2002050e:	4770      	bx	lr

20020510 <bootloader_switch_clock>:
20020510:	2102      	movs	r1, #2
20020512:	2004      	movs	r0, #4
20020514:	f003 bfea 	b.w	200244ec <HAL_RCC_HCPU_ClockSelect>

20020518 <board_init_psram>:
20020518:	2201      	movs	r2, #1
2002051a:	b508      	push	{r3, lr}
2002051c:	4611      	mov	r1, r2
2002051e:	2000      	movs	r0, #0
20020520:	f007 f9c2 	bl	200278a8 <HAL_PMU_ConfigPeriLdo>
20020524:	2001      	movs	r0, #1
20020526:	f7ff fff3 	bl	20020510 <bootloader_switch_clock>
2002052a:	2002      	movs	r0, #2
2002052c:	f001 f910 	bl	20021750 <BSP_SetFlash1DIV>
20020530:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020534:	f001 b8c4 	b.w	200216c0 <bsp_psramc_init>

20020538 <erase_nor>:
20020538:	b570      	push	{r4, r5, r6, lr}
2002053a:	4b13      	ldr	r3, [pc, #76]	@ (20020588 <erase_nor+0x50>)
2002053c:	460c      	mov	r4, r1
2002053e:	681e      	ldr	r6, [r3, #0]
20020540:	6933      	ldr	r3, [r6, #16]
20020542:	4283      	cmp	r3, r0
20020544:	d901      	bls.n	2002054a <erase_nor+0x12>
20020546:	2001      	movs	r0, #1
20020548:	bd70      	pop	{r4, r5, r6, pc}
2002054a:	6972      	ldr	r2, [r6, #20]
2002054c:	441a      	add	r2, r3
2002054e:	4282      	cmp	r2, r0
20020550:	d3f9      	bcc.n	20020546 <erase_nor+0xe>
20020552:	1ac0      	subs	r0, r0, r3
20020554:	f3c0 030b 	ubfx	r3, r0, #0, #12
20020558:	b97b      	cbnz	r3, 2002057a <erase_nor+0x42>
2002055a:	f3c1 030b 	ubfx	r3, r1, #0, #12
2002055e:	b97b      	cbnz	r3, 20020580 <erase_nor+0x48>
20020560:	1845      	adds	r5, r0, r1
20020562:	1b29      	subs	r1, r5, r4
20020564:	b90c      	cbnz	r4, 2002056a <erase_nor+0x32>
20020566:	4620      	mov	r0, r4
20020568:	e7ee      	b.n	20020548 <erase_nor+0x10>
2002056a:	4630      	mov	r0, r6
2002056c:	f002 ffbb 	bl	200234e6 <HAL_QSPIEX_SECT_ERASE>
20020570:	2800      	cmp	r0, #0
20020572:	d1e8      	bne.n	20020546 <erase_nor+0xe>
20020574:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
20020578:	e7f3      	b.n	20020562 <erase_nor+0x2a>
2002057a:	f04f 30ff 	mov.w	r0, #4294967295
2002057e:	e7e3      	b.n	20020548 <erase_nor+0x10>
20020580:	f06f 0001 	mvn.w	r0, #1
20020584:	e7e0      	b.n	20020548 <erase_nor+0x10>
20020586:	bf00      	nop
20020588:	20046d30 	.word	0x20046d30

2002058c <write_nor>:
2002058c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020590:	4b1e      	ldr	r3, [pc, #120]	@ (2002060c <write_nor+0x80>)
20020592:	460f      	mov	r7, r1
20020594:	f8d3 8000 	ldr.w	r8, [r3]
20020598:	4616      	mov	r6, r2
2002059a:	f8d8 5010 	ldr.w	r5, [r8, #16]
2002059e:	4285      	cmp	r5, r0
200205a0:	d902      	bls.n	200205a8 <write_nor+0x1c>
200205a2:	2000      	movs	r0, #0
200205a4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200205a8:	f8d8 2014 	ldr.w	r2, [r8, #20]
200205ac:	442a      	add	r2, r5
200205ae:	4282      	cmp	r2, r0
200205b0:	d3f7      	bcc.n	200205a2 <write_nor+0x16>
200205b2:	1b45      	subs	r5, r0, r5
200205b4:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
200205b8:	d012      	beq.n	200205e0 <write_nor+0x54>
200205ba:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
200205be:	42b4      	cmp	r4, r6
200205c0:	bf28      	it	cs
200205c2:	4634      	movcs	r4, r6
200205c4:	460a      	mov	r2, r1
200205c6:	4623      	mov	r3, r4
200205c8:	4629      	mov	r1, r5
200205ca:	4640      	mov	r0, r8
200205cc:	f002 fea6 	bl	2002331c <HAL_QSPIEX_WRITE_PAGE>
200205d0:	4284      	cmp	r4, r0
200205d2:	d1e6      	bne.n	200205a2 <write_nor+0x16>
200205d4:	4425      	add	r5, r4
200205d6:	4427      	add	r7, r4
200205d8:	1b34      	subs	r4, r6, r4
200205da:	b91c      	cbnz	r4, 200205e4 <write_nor+0x58>
200205dc:	4630      	mov	r0, r6
200205de:	e7e1      	b.n	200205a4 <write_nor+0x18>
200205e0:	4634      	mov	r4, r6
200205e2:	e7fa      	b.n	200205da <write_nor+0x4e>
200205e4:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
200205e8:	46a1      	mov	r9, r4
200205ea:	bf28      	it	cs
200205ec:	f44f 7980 	movcs.w	r9, #256	@ 0x100
200205f0:	463a      	mov	r2, r7
200205f2:	464b      	mov	r3, r9
200205f4:	4629      	mov	r1, r5
200205f6:	4640      	mov	r0, r8
200205f8:	f002 fe90 	bl	2002331c <HAL_QSPIEX_WRITE_PAGE>
200205fc:	4581      	cmp	r9, r0
200205fe:	d1d0      	bne.n	200205a2 <write_nor+0x16>
20020600:	444d      	add	r5, r9
20020602:	444f      	add	r7, r9
20020604:	eba4 0409 	sub.w	r4, r4, r9
20020608:	e7e7      	b.n	200205da <write_nor+0x4e>
2002060a:	bf00      	nop
2002060c:	20046d30 	.word	0x20046d30

20020610 <read_nor>:
20020610:	460b      	mov	r3, r1
20020612:	b510      	push	{r4, lr}
20020614:	4614      	mov	r4, r2
20020616:	4601      	mov	r1, r0
20020618:	4618      	mov	r0, r3
2002061a:	f005 fb92 	bl	20025d42 <memcpy>
2002061e:	4620      	mov	r0, r4
20020620:	bd10      	pop	{r4, pc}
	...

20020624 <read_nand>:
20020624:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020628:	2600      	movs	r6, #0
2002062a:	460f      	mov	r7, r1
2002062c:	4615      	mov	r5, r2
2002062e:	46b0      	mov	r8, r6
20020630:	4b19      	ldr	r3, [pc, #100]	@ (20020698 <read_nand+0x74>)
20020632:	f8df a068 	ldr.w	sl, [pc, #104]	@ 2002069c <read_nand+0x78>
20020636:	681b      	ldr	r3, [r3, #0]
20020638:	f8df b064 	ldr.w	fp, [pc, #100]	@ 200206a0 <read_nand+0x7c>
2002063c:	691b      	ldr	r3, [r3, #16]
2002063e:	4604      	mov	r4, r0
20020640:	4283      	cmp	r3, r0
20020642:	b085      	sub	sp, #20
20020644:	bf98      	it	ls
20020646:	1ac4      	subls	r4, r0, r3
20020648:	b91d      	cbnz	r5, 20020652 <read_nand+0x2e>
2002064a:	4630      	mov	r0, r6
2002064c:	b005      	add	sp, #20
2002064e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020652:	f8da 1000 	ldr.w	r1, [sl]
20020656:	f8db 0000 	ldr.w	r0, [fp]
2002065a:	42a9      	cmp	r1, r5
2002065c:	fbb0 fcf1 	udiv	ip, r0, r1
20020660:	4689      	mov	r9, r1
20020662:	f101 32ff 	add.w	r2, r1, #4294967295
20020666:	bf28      	it	cs
20020668:	46a9      	movcs	r9, r5
2002066a:	fbb4 f1f1 	udiv	r1, r4, r1
2002066e:	f10c 3cff 	add.w	ip, ip, #4294967295
20020672:	fbb4 f0f0 	udiv	r0, r4, r0
20020676:	e9cd 8801 	strd	r8, r8, [sp, #4]
2002067a:	f8cd 9000 	str.w	r9, [sp]
2002067e:	19bb      	adds	r3, r7, r6
20020680:	4022      	ands	r2, r4
20020682:	ea0c 0101 	and.w	r1, ip, r1
20020686:	f004 fb6b 	bl	20024d60 <bbm_read_page>
2002068a:	4548      	cmp	r0, r9
2002068c:	d1dd      	bne.n	2002064a <read_nand+0x26>
2002068e:	4406      	add	r6, r0
20020690:	1a2d      	subs	r5, r5, r0
20020692:	4404      	add	r4, r0
20020694:	e7d8      	b.n	20020648 <read_nand+0x24>
20020696:	bf00      	nop
20020698:	20046d30 	.word	0x20046d30
2002069c:	20042c04 	.word	0x20042c04
200206a0:	20042c00 	.word	0x20042c00

200206a4 <read_sdnand>:
200206a4:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200206a8:	f3c0 0408 	ubfx	r4, r0, #0, #9
200206ac:	460e      	mov	r6, r1
200206ae:	4615      	mov	r5, r2
200206b0:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
200206b4:	b38c      	cbz	r4, 2002071a <read_sdnand+0x76>
200206b6:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 20020730 <read_sdnand+0x8c>
200206ba:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
200206be:	eba8 0004 	sub.w	r0, r8, r4
200206c2:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206c6:	4649      	mov	r1, r9
200206c8:	f000 fed2 	bl	20021470 <sd_read_data>
200206cc:	42af      	cmp	r7, r5
200206ce:	bf28      	it	cs
200206d0:	462f      	movcs	r7, r5
200206d2:	4630      	mov	r0, r6
200206d4:	eb09 0104 	add.w	r1, r9, r4
200206d8:	463a      	mov	r2, r7
200206da:	f005 fb32 	bl	20025d42 <memcpy>
200206de:	1bec      	subs	r4, r5, r7
200206e0:	44b8      	add	r8, r7
200206e2:	443e      	add	r6, r7
200206e4:	2700      	movs	r7, #0
200206e6:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
200206ea:	f02a 0a01 	bic.w	sl, sl, #1
200206ee:	4557      	cmp	r7, sl
200206f0:	eb07 0906 	add.w	r9, r7, r6
200206f4:	eb08 0007 	add.w	r0, r8, r7
200206f8:	d111      	bne.n	2002071e <read_sdnand+0x7a>
200206fa:	f3c4 0408 	ubfx	r4, r4, #0, #9
200206fe:	b14c      	cbz	r4, 20020714 <read_sdnand+0x70>
20020700:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020704:	490a      	ldr	r1, [pc, #40]	@ (20020730 <read_sdnand+0x8c>)
20020706:	f000 feb3 	bl	20021470 <sd_read_data>
2002070a:	4622      	mov	r2, r4
2002070c:	4648      	mov	r0, r9
2002070e:	4908      	ldr	r1, [pc, #32]	@ (20020730 <read_sdnand+0x8c>)
20020710:	f005 fb17 	bl	20025d42 <memcpy>
20020714:	4628      	mov	r0, r5
20020716:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002071a:	4614      	mov	r4, r2
2002071c:	e7e2      	b.n	200206e4 <read_sdnand+0x40>
2002071e:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020722:	4649      	mov	r1, r9
20020724:	f000 fea4 	bl	20021470 <sd_read_data>
20020728:	f507 7700 	add.w	r7, r7, #512	@ 0x200
2002072c:	e7df      	b.n	200206ee <read_sdnand+0x4a>
2002072e:	bf00      	nop
20020730:	20046b2c 	.word	0x20046b2c

20020734 <read_sdemmc>:
20020734:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020738:	f3c0 0408 	ubfx	r4, r0, #0, #9
2002073c:	460e      	mov	r6, r1
2002073e:	4615      	mov	r5, r2
20020740:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020744:	b38c      	cbz	r4, 200207aa <read_sdemmc+0x76>
20020746:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 200207c0 <read_sdemmc+0x8c>
2002074a:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
2002074e:	eba8 0004 	sub.w	r0, r8, r4
20020752:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020756:	4649      	mov	r1, r9
20020758:	f000 fd2e 	bl	200211b8 <emmc_read_data>
2002075c:	42af      	cmp	r7, r5
2002075e:	bf28      	it	cs
20020760:	462f      	movcs	r7, r5
20020762:	4630      	mov	r0, r6
20020764:	eb09 0104 	add.w	r1, r9, r4
20020768:	463a      	mov	r2, r7
2002076a:	f005 faea 	bl	20025d42 <memcpy>
2002076e:	1bec      	subs	r4, r5, r7
20020770:	44b8      	add	r8, r7
20020772:	443e      	add	r6, r7
20020774:	2700      	movs	r7, #0
20020776:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
2002077a:	f02a 0a01 	bic.w	sl, sl, #1
2002077e:	4557      	cmp	r7, sl
20020780:	eb07 0906 	add.w	r9, r7, r6
20020784:	eb08 0007 	add.w	r0, r8, r7
20020788:	d111      	bne.n	200207ae <read_sdemmc+0x7a>
2002078a:	f3c4 0408 	ubfx	r4, r4, #0, #9
2002078e:	b14c      	cbz	r4, 200207a4 <read_sdemmc+0x70>
20020790:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020794:	490a      	ldr	r1, [pc, #40]	@ (200207c0 <read_sdemmc+0x8c>)
20020796:	f000 fd0f 	bl	200211b8 <emmc_read_data>
2002079a:	4622      	mov	r2, r4
2002079c:	4648      	mov	r0, r9
2002079e:	4908      	ldr	r1, [pc, #32]	@ (200207c0 <read_sdemmc+0x8c>)
200207a0:	f005 facf 	bl	20025d42 <memcpy>
200207a4:	4628      	mov	r0, r5
200207a6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200207aa:	4614      	mov	r4, r2
200207ac:	e7e2      	b.n	20020774 <read_sdemmc+0x40>
200207ae:	f44f 7200 	mov.w	r2, #512	@ 0x200
200207b2:	4649      	mov	r1, r9
200207b4:	f000 fd00 	bl	200211b8 <emmc_read_data>
200207b8:	f507 7700 	add.w	r7, r7, #512	@ 0x200
200207bc:	e7df      	b.n	2002077e <read_sdemmc+0x4a>
200207be:	bf00      	nop
200207c0:	20046b2c 	.word	0x20046b2c

200207c4 <port_read_page>:
200207c4:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200207c8:	4615      	mov	r5, r2
200207ca:	460e      	mov	r6, r1
200207cc:	492b      	ldr	r1, [pc, #172]	@ (2002087c <port_read_page+0xb8>)
200207ce:	461a      	mov	r2, r3
200207d0:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
200207d4:	680f      	ldr	r7, [r1, #0]
200207d6:	18e9      	adds	r1, r5, r3
200207d8:	428f      	cmp	r7, r1
200207da:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
200207de:	d200      	bcs.n	200207e2 <port_read_page+0x1e>
200207e0:	e7fe      	b.n	200207e0 <port_read_page+0x1c>
200207e2:	4927      	ldr	r1, [pc, #156]	@ (20020880 <port_read_page+0xbc>)
200207e4:	f107 0980 	add.w	r9, r7, #128	@ 0x80
200207e8:	f1b9 0f00 	cmp.w	r9, #0
200207ec:	6809      	ldr	r1, [r1, #0]
200207ee:	dd18      	ble.n	20020822 <port_read_page+0x5e>
200207f0:	4c24      	ldr	r4, [pc, #144]	@ (20020884 <port_read_page+0xc0>)
200207f2:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
200207f6:	f004 081f 	and.w	r8, r4, #31
200207fa:	44c8      	add	r8, r9
200207fc:	f024 041f 	bic.w	r4, r4, #31
20020800:	f3bf 8f4f 	dsb	sy
20020804:	f8df a084 	ldr.w	sl, [pc, #132]	@ 2002088c <port_read_page+0xc8>
20020808:	44a0      	add	r8, r4
2002080a:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
2002080e:	3420      	adds	r4, #32
20020810:	eba8 0904 	sub.w	r9, r8, r4
20020814:	f1b9 0f00 	cmp.w	r9, #0
20020818:	dcf7      	bgt.n	2002080a <port_read_page+0x46>
2002081a:	f3bf 8f4f 	dsb	sy
2002081e:	f3bf 8f6f 	isb	sy
20020822:	07c4      	lsls	r4, r0, #31
20020824:	d51e      	bpl.n	20020864 <port_read_page+0xa0>
20020826:	4c17      	ldr	r4, [pc, #92]	@ (20020884 <port_read_page+0xc0>)
20020828:	f894 80d7 	ldrb.w	r8, [r4, #215]	@ 0xd7
2002082c:	f1b8 0f00 	cmp.w	r8, #0
20020830:	d018      	beq.n	20020864 <port_read_page+0xa0>
20020832:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
20020836:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
2002083a:	f004 041f 	and.w	r4, r4, #31
2002083e:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020842:	f028 081f 	bic.w	r8, r8, #31
20020846:	f3bf 8f4f 	dsb	sy
2002084a:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 2002088c <port_read_page+0xc8>
2002084e:	3c20      	subs	r4, #32
20020850:	2c00      	cmp	r4, #0
20020852:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
20020856:	f108 0820 	add.w	r8, r8, #32
2002085a:	dcf8      	bgt.n	2002084e <port_read_page+0x8a>
2002085c:	f3bf 8f4f 	dsb	sy
20020860:	f3bf 8f6f 	isb	sy
20020864:	fb07 5506 	mla	r5, r7, r6, r5
20020868:	e9cd ce08 	strd	ip, lr, [sp, #32]
2002086c:	fb01 5100 	mla	r1, r1, r0, r5
20020870:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020874:	4804      	ldr	r0, [pc, #16]	@ (20020888 <port_read_page+0xc4>)
20020876:	f002 bc6f 	b.w	20023158 <HAL_NAND_READ_WITHOOB>
2002087a:	bf00      	nop
2002087c:	20042c04 	.word	0x20042c04
20020880:	20042c00 	.word	0x20042c00
20020884:	20046f70 	.word	0x20046f70
20020888:	20047018 	.word	0x20047018
2002088c:	e000ed00 	.word	0xe000ed00

20020890 <bbm_get_bb>:
20020890:	b410      	push	{r4}
20020892:	4b1e      	ldr	r3, [pc, #120]	@ (2002090c <bbm_get_bb+0x7c>)
20020894:	4601      	mov	r1, r0
20020896:	6818      	ldr	r0, [r3, #0]
20020898:	3080      	adds	r0, #128	@ 0x80
2002089a:	2800      	cmp	r0, #0
2002089c:	dd14      	ble.n	200208c8 <bbm_get_bb+0x38>
2002089e:	4b1c      	ldr	r3, [pc, #112]	@ (20020910 <bbm_get_bb+0x80>)
200208a0:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208a2:	f003 021f 	and.w	r2, r3, #31
200208a6:	4402      	add	r2, r0
200208a8:	f023 031f 	bic.w	r3, r3, #31
200208ac:	f3bf 8f4f 	dsb	sy
200208b0:	4c18      	ldr	r4, [pc, #96]	@ (20020914 <bbm_get_bb+0x84>)
200208b2:	441a      	add	r2, r3
200208b4:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
200208b8:	3320      	adds	r3, #32
200208ba:	1ad0      	subs	r0, r2, r3
200208bc:	2800      	cmp	r0, #0
200208be:	dcf9      	bgt.n	200208b4 <bbm_get_bb+0x24>
200208c0:	f3bf 8f4f 	dsb	sy
200208c4:	f3bf 8f6f 	isb	sy
200208c8:	07cb      	lsls	r3, r1, #31
200208ca:	d51a      	bpl.n	20020902 <bbm_get_bb+0x72>
200208cc:	4b10      	ldr	r3, [pc, #64]	@ (20020910 <bbm_get_bb+0x80>)
200208ce:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
200208d2:	b1b2      	cbz	r2, 20020902 <bbm_get_bb+0x72>
200208d4:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208d6:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
200208da:	f003 031f 	and.w	r3, r3, #31
200208de:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
200208e2:	f022 021f 	bic.w	r2, r2, #31
200208e6:	f3bf 8f4f 	dsb	sy
200208ea:	480a      	ldr	r0, [pc, #40]	@ (20020914 <bbm_get_bb+0x84>)
200208ec:	3b20      	subs	r3, #32
200208ee:	2b00      	cmp	r3, #0
200208f0:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
200208f4:	f102 0220 	add.w	r2, r2, #32
200208f8:	dcf8      	bgt.n	200208ec <bbm_get_bb+0x5c>
200208fa:	f3bf 8f4f 	dsb	sy
200208fe:	f3bf 8f6f 	isb	sy
20020902:	4805      	ldr	r0, [pc, #20]	@ (20020918 <bbm_get_bb+0x88>)
20020904:	f85d 4b04 	ldr.w	r4, [sp], #4
20020908:	f002 bce7 	b.w	200232da <HAL_NAND_GET_BADBLK>
2002090c:	20042c04 	.word	0x20042c04
20020910:	20046f70 	.word	0x20046f70
20020914:	e000ed00 	.word	0xe000ed00
20020918:	20046fc4 	.word	0x20046fc4

2002091c <boot_device_init>:
2002091c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020920:	b08c      	sub	sp, #48	@ 0x30
20020922:	f001 fd29 	bl	20022378 <HAL_HPAON_EnableXT48>
20020926:	2101      	movs	r1, #1
20020928:	2000      	movs	r0, #0
2002092a:	f003 fddf 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
2002092e:	2101      	movs	r1, #1
20020930:	200c      	movs	r0, #12
20020932:	f003 fddb 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
20020936:	2001      	movs	r0, #1
20020938:	f003 fce0 	bl	200242fc <HAL_PMU_EnableDLL>
2002093c:	4fa3      	ldr	r7, [pc, #652]	@ (20020bcc <boot_device_init+0x2b0>)
2002093e:	2090      	movs	r0, #144	@ 0x90
20020940:	f003 ff3a 	bl	200247b8 <HAL_RCC_HCPU_ConfigHCLK>
20020944:	48a2      	ldr	r0, [pc, #648]	@ (20020bd0 <boot_device_init+0x2b4>)
20020946:	f003 fda1 	bl	2002448c <HAL_RCC_HCPU_EnableDLL2>
2002094a:	783b      	ldrb	r3, [r7, #0]
2002094c:	4ca1      	ldr	r4, [pc, #644]	@ (20020bd4 <boot_device_init+0x2b8>)
2002094e:	2b06      	cmp	r3, #6
20020950:	f200 8137 	bhi.w	20020bc2 <boot_device_init+0x2a6>
20020954:	e8df f013 	tbh	[pc, r3, lsl #1]
20020958:	00440007 	.word	0x00440007
2002095c:	009f0044 	.word	0x009f0044
20020960:	011b009f 	.word	0x011b009f
20020964:	012a      	.short	0x012a
20020966:	2006      	movs	r0, #6
20020968:	4e9b      	ldr	r6, [pc, #620]	@ (20020bd8 <boot_device_init+0x2bc>)
2002096a:	f000 fef7 	bl	2002175c <BSP_SetFlash2DIV>
2002096e:	ad02      	add	r5, sp, #8
20020970:	2102      	movs	r1, #2
20020972:	2006      	movs	r0, #6
20020974:	f003 fdba 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
20020978:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002097a:	c50f      	stmia	r5!, {r0, r1, r2, r3}
2002097c:	6833      	ldr	r3, [r6, #0]
2002097e:	2210      	movs	r2, #16
20020980:	2100      	movs	r1, #0
20020982:	602b      	str	r3, [r5, #0]
20020984:	a808      	add	r0, sp, #32
20020986:	f005 f96d 	bl	20025c64 <memset>
2002098a:	4b94      	ldr	r3, [pc, #592]	@ (20020bdc <boot_device_init+0x2c0>)
2002098c:	2601      	movs	r6, #1
2002098e:	9307      	str	r3, [sp, #28]
20020990:	2333      	movs	r3, #51	@ 0x33
20020992:	960a      	str	r6, [sp, #40]	@ 0x28
20020994:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020998:	f7ff fcee 	bl	20020378 <board_pinmux_mpi2>
2002099c:	2302      	movs	r3, #2
2002099e:	4d90      	ldr	r5, [pc, #576]	@ (20020be0 <boot_device_init+0x2c4>)
200209a0:	9303      	str	r3, [sp, #12]
200209a2:	4b90      	ldr	r3, [pc, #576]	@ (20020be4 <boot_device_init+0x2c8>)
200209a4:	2000      	movs	r0, #0
200209a6:	6023      	str	r3, [r4, #0]
200209a8:	f000 ffdd 	bl	20021966 <HAL_Delay_us>
200209ac:	f885 6099 	strb.w	r6, [r5, #153]	@ 0x99
200209b0:	f000 fec2 	bl	20021738 <BSP_GetFlash2DIV>
200209b4:	f105 0654 	add.w	r6, r5, #84	@ 0x54
200209b8:	4a8b      	ldr	r2, [pc, #556]	@ (20020be8 <boot_device_init+0x2cc>)
200209ba:	9000      	str	r0, [sp, #0]
200209bc:	ab07      	add	r3, sp, #28
200209be:	4630      	mov	r0, r6
200209c0:	a902      	add	r1, sp, #8
200209c2:	f002 fe43 	bl	2002364c <HAL_FLASH_Init>
200209c6:	4b89      	ldr	r3, [pc, #548]	@ (20020bec <boot_device_init+0x2d0>)
200209c8:	4a89      	ldr	r2, [pc, #548]	@ (20020bf0 <boot_device_init+0x2d4>)
200209ca:	601a      	str	r2, [r3, #0]
200209cc:	4a89      	ldr	r2, [pc, #548]	@ (20020bf4 <boot_device_init+0x2d8>)
200209ce:	4b8a      	ldr	r3, [pc, #552]	@ (20020bf8 <boot_device_init+0x2dc>)
200209d0:	601a      	str	r2, [r3, #0]
200209d2:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
200209d6:	4b89      	ldr	r3, [pc, #548]	@ (20020bfc <boot_device_init+0x2e0>)
200209d8:	601a      	str	r2, [r3, #0]
200209da:	4b89      	ldr	r3, [pc, #548]	@ (20020c00 <boot_device_init+0x2e4>)
200209dc:	601e      	str	r6, [r3, #0]
200209de:	e037      	b.n	20020a50 <boot_device_init+0x134>
200209e0:	2006      	movs	r0, #6
200209e2:	4e88      	ldr	r6, [pc, #544]	@ (20020c04 <boot_device_init+0x2e8>)
200209e4:	f000 feb4 	bl	20021750 <BSP_SetFlash1DIV>
200209e8:	ad02      	add	r5, sp, #8
200209ea:	2102      	movs	r1, #2
200209ec:	2004      	movs	r0, #4
200209ee:	f003 fd7d 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
200209f2:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
200209f4:	c50f      	stmia	r5!, {r0, r1, r2, r3}
200209f6:	6833      	ldr	r3, [r6, #0]
200209f8:	2210      	movs	r2, #16
200209fa:	602b      	str	r3, [r5, #0]
200209fc:	2100      	movs	r1, #0
200209fe:	a808      	add	r0, sp, #32
20020a00:	f005 f930 	bl	20025c64 <memset>
20020a04:	4b80      	ldr	r3, [pc, #512]	@ (20020c08 <boot_device_init+0x2ec>)
20020a06:	4d76      	ldr	r5, [pc, #472]	@ (20020be0 <boot_device_init+0x2c4>)
20020a08:	9307      	str	r3, [sp, #28]
20020a0a:	2332      	movs	r3, #50	@ 0x32
20020a0c:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020a10:	2301      	movs	r3, #1
20020a12:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
20020a16:	783b      	ldrb	r3, [r7, #0]
20020a18:	2b01      	cmp	r3, #1
20020a1a:	d139      	bne.n	20020a90 <boot_device_init+0x174>
20020a1c:	f7ff fc48 	bl	200202b0 <board_pinmux_mpi1_type1>
20020a20:	2302      	movs	r3, #2
20020a22:	9303      	str	r3, [sp, #12]
20020a24:	f000 fe82 	bl	2002172c <BSP_GetFlash1DIV>
20020a28:	4a78      	ldr	r2, [pc, #480]	@ (20020c0c <boot_device_init+0x2f0>)
20020a2a:	9000      	str	r0, [sp, #0]
20020a2c:	ab07      	add	r3, sp, #28
20020a2e:	486c      	ldr	r0, [pc, #432]	@ (20020be0 <boot_device_init+0x2c4>)
20020a30:	a902      	add	r1, sp, #8
20020a32:	f002 fe0b 	bl	2002364c <HAL_FLASH_Init>
20020a36:	4b6b      	ldr	r3, [pc, #428]	@ (20020be4 <boot_device_init+0x2c8>)
20020a38:	4a6d      	ldr	r2, [pc, #436]	@ (20020bf0 <boot_device_init+0x2d4>)
20020a3a:	6023      	str	r3, [r4, #0]
20020a3c:	4b6b      	ldr	r3, [pc, #428]	@ (20020bec <boot_device_init+0x2d0>)
20020a3e:	601a      	str	r2, [r3, #0]
20020a40:	4b6d      	ldr	r3, [pc, #436]	@ (20020bf8 <boot_device_init+0x2dc>)
20020a42:	4a6c      	ldr	r2, [pc, #432]	@ (20020bf4 <boot_device_init+0x2d8>)
20020a44:	601a      	str	r2, [r3, #0]
20020a46:	4b6d      	ldr	r3, [pc, #436]	@ (20020bfc <boot_device_init+0x2e0>)
20020a48:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020a4a:	601a      	str	r2, [r3, #0]
20020a4c:	4b6c      	ldr	r3, [pc, #432]	@ (20020c00 <boot_device_init+0x2e4>)
20020a4e:	601d      	str	r5, [r3, #0]
20020a50:	6823      	ldr	r3, [r4, #0]
20020a52:	2b00      	cmp	r3, #0
20020a54:	f000 8110 	beq.w	20020c78 <boot_device_init+0x35c>
20020a58:	4e68      	ldr	r6, [pc, #416]	@ (20020bfc <boot_device_init+0x2e0>)
20020a5a:	6830      	ldr	r0, [r6, #0]
20020a5c:	2800      	cmp	r0, #0
20020a5e:	f000 810b 	beq.w	20020c78 <boot_device_init+0x35c>
20020a62:	4d6b      	ldr	r5, [pc, #428]	@ (20020c10 <boot_device_init+0x2f4>)
20020a64:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020a68:	4629      	mov	r1, r5
20020a6a:	4798      	blx	r3
20020a6c:	682a      	ldr	r2, [r5, #0]
20020a6e:	4b69      	ldr	r3, [pc, #420]	@ (20020c14 <boot_device_init+0x2f8>)
20020a70:	7839      	ldrb	r1, [r7, #0]
20020a72:	429a      	cmp	r2, r3
20020a74:	f040 80fb 	bne.w	20020c6e <boot_device_init+0x352>
20020a78:	2904      	cmp	r1, #4
20020a7a:	d105      	bne.n	20020a88 <boot_device_init+0x16c>
20020a7c:	f8d5 30a4 	ldr.w	r3, [r5, #164]	@ 0xa4
20020a80:	1e5a      	subs	r2, r3, #1
20020a82:	3203      	adds	r2, #3
20020a84:	f240 80e2 	bls.w	20020c4c <boot_device_init+0x330>
20020a88:	2001      	movs	r0, #1
20020a8a:	b00c      	add	sp, #48	@ 0x30
20020a8c:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020a90:	f7ff fc40 	bl	20020314 <board_pinmux_mpi1_type2>
20020a94:	e7c4      	b.n	20020a20 <boot_device_init+0x104>
20020a96:	2006      	movs	r0, #6
20020a98:	4e5f      	ldr	r6, [pc, #380]	@ (20020c18 <boot_device_init+0x2fc>)
20020a9a:	f000 fe65 	bl	20021768 <BSP_SetFlash3DIV>
20020a9e:	ad02      	add	r5, sp, #8
20020aa0:	2102      	movs	r1, #2
20020aa2:	2008      	movs	r0, #8
20020aa4:	f003 fd22 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
20020aa8:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020aaa:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020aac:	f897 8000 	ldrb.w	r8, [r7]
20020ab0:	6833      	ldr	r3, [r6, #0]
20020ab2:	f1b8 0a03 	subs.w	sl, r8, #3
20020ab6:	602b      	str	r3, [r5, #0]
20020ab8:	f04f 0210 	mov.w	r2, #16
20020abc:	f04f 0100 	mov.w	r1, #0
20020ac0:	a808      	add	r0, sp, #32
20020ac2:	bf18      	it	ne
20020ac4:	f04f 0a01 	movne.w	sl, #1
20020ac8:	f005 f8cc 	bl	20025c64 <memset>
20020acc:	4b4e      	ldr	r3, [pc, #312]	@ (20020c08 <boot_device_init+0x2ec>)
20020ace:	2502      	movs	r5, #2
20020ad0:	9307      	str	r3, [sp, #28]
20020ad2:	2332      	movs	r3, #50	@ 0x32
20020ad4:	950a      	str	r5, [sp, #40]	@ 0x28
20020ad6:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020ada:	f7ff fc7f 	bl	200203dc <board_pinmux_mpi3>
20020ade:	f1b8 0f03 	cmp.w	r8, #3
20020ae2:	9503      	str	r5, [sp, #12]
20020ae4:	4d3e      	ldr	r5, [pc, #248]	@ (20020be0 <boot_device_init+0x2c4>)
20020ae6:	d045      	beq.n	20020b74 <boot_device_init+0x258>
20020ae8:	4b4c      	ldr	r3, [pc, #304]	@ (20020c1c <boot_device_init+0x300>)
20020aea:	6023      	str	r3, [r4, #0]
20020aec:	9b04      	ldr	r3, [sp, #16]
20020aee:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020af2:	9304      	str	r3, [sp, #16]
20020af4:	2301      	movs	r3, #1
20020af6:	9306      	str	r3, [sp, #24]
20020af8:	4b49      	ldr	r3, [pc, #292]	@ (20020c20 <boot_device_init+0x304>)
20020afa:	f8c5 30c4 	str.w	r3, [r5, #196]	@ 0xc4
20020afe:	f04f 0901 	mov.w	r9, #1
20020b02:	2000      	movs	r0, #0
20020b04:	f000 ff2f 	bl	20021966 <HAL_Delay_us>
20020b08:	f885 90ed 	strb.w	r9, [r5, #237]	@ 0xed
20020b0c:	f885 a0ec 	strb.w	sl, [r5, #236]	@ 0xec
20020b10:	f000 fe18 	bl	20021744 <BSP_GetFlash3DIV>
20020b14:	4a43      	ldr	r2, [pc, #268]	@ (20020c24 <boot_device_init+0x308>)
20020b16:	9000      	str	r0, [sp, #0]
20020b18:	ab07      	add	r3, sp, #28
20020b1a:	4843      	ldr	r0, [pc, #268]	@ (20020c28 <boot_device_init+0x30c>)
20020b1c:	a902      	add	r1, sp, #8
20020b1e:	f002 fd95 	bl	2002364c <HAL_FLASH_Init>
20020b22:	4e41      	ldr	r6, [pc, #260]	@ (20020c28 <boot_device_init+0x30c>)
20020b24:	bb48      	cbnz	r0, 20020b7a <boot_device_init+0x25e>
20020b26:	f1b8 0f03 	cmp.w	r8, #3
20020b2a:	d029      	beq.n	20020b80 <boot_device_init+0x264>
20020b2c:	4630      	mov	r0, r6
20020b2e:	f002 fb08 	bl	20023142 <HAL_NAND_PAGE_SIZE>
20020b32:	f8df a110 	ldr.w	sl, [pc, #272]	@ 20020c44 <boot_device_init+0x328>
20020b36:	f8df 8110 	ldr.w	r8, [pc, #272]	@ 20020c48 <boot_device_init+0x32c>
20020b3a:	f8ca 0000 	str.w	r0, [sl]
20020b3e:	4630      	mov	r0, r6
20020b40:	f002 fbbf 	bl	200232c2 <HAL_NAND_BLOCK_SIZE>
20020b44:	4649      	mov	r1, r9
20020b46:	f8c8 0000 	str.w	r0, [r8]
20020b4a:	4630      	mov	r0, r6
20020b4c:	f885 90d6 	strb.w	r9, [r5, #214]	@ 0xd6
20020b50:	f002 f9b7 	bl	20022ec2 <HAL_NAND_CONF_ECC>
20020b54:	f8da 0000 	ldr.w	r0, [sl]
20020b58:	f004 fbe8 	bl	2002532c <bbm_set_page_size>
20020b5c:	f8d8 0000 	ldr.w	r0, [r8]
20020b60:	f004 fbea 	bl	20025338 <bbm_set_blk_size>
20020b64:	4931      	ldr	r1, [pc, #196]	@ (20020c2c <boot_device_init+0x310>)
20020b66:	f8d5 00f4 	ldr.w	r0, [r5, #244]	@ 0xf4
20020b6a:	f004 fa81 	bl	20025070 <sif_bbm_init>
20020b6e:	f8d5 20f0 	ldr.w	r2, [r5, #240]	@ 0xf0
20020b72:	e730      	b.n	200209d6 <boot_device_init+0xba>
20020b74:	4b1b      	ldr	r3, [pc, #108]	@ (20020be4 <boot_device_init+0x2c8>)
20020b76:	6023      	str	r3, [r4, #0]
20020b78:	e7c1      	b.n	20020afe <boot_device_init+0x1e2>
20020b7a:	f1b8 0f03 	cmp.w	r8, #3
20020b7e:	d1f6      	bne.n	20020b6e <boot_device_init+0x252>
20020b80:	4b1a      	ldr	r3, [pc, #104]	@ (20020bec <boot_device_init+0x2d0>)
20020b82:	4a1b      	ldr	r2, [pc, #108]	@ (20020bf0 <boot_device_init+0x2d4>)
20020b84:	601a      	str	r2, [r3, #0]
20020b86:	4b1c      	ldr	r3, [pc, #112]	@ (20020bf8 <boot_device_init+0x2dc>)
20020b88:	4a1a      	ldr	r2, [pc, #104]	@ (20020bf4 <boot_device_init+0x2d8>)
20020b8a:	601a      	str	r2, [r3, #0]
20020b8c:	e7ef      	b.n	20020b6e <boot_device_init+0x252>
20020b8e:	f7ff fc73 	bl	20020478 <board_pinmux_sd>
20020b92:	f000 fb59 	bl	20021248 <sdio_sd_init>
20020b96:	2801      	cmp	r0, #1
20020b98:	d111      	bne.n	20020bbe <boot_device_init+0x2a2>
20020b9a:	4b25      	ldr	r3, [pc, #148]	@ (20020c30 <boot_device_init+0x314>)
20020b9c:	6023      	str	r3, [r4, #0]
20020b9e:	4b25      	ldr	r3, [pc, #148]	@ (20020c34 <boot_device_init+0x318>)
20020ba0:	4a16      	ldr	r2, [pc, #88]	@ (20020bfc <boot_device_init+0x2e0>)
20020ba2:	6013      	str	r3, [r2, #0]
20020ba4:	2200      	movs	r2, #0
20020ba6:	4b16      	ldr	r3, [pc, #88]	@ (20020c00 <boot_device_init+0x2e4>)
20020ba8:	601a      	str	r2, [r3, #0]
20020baa:	e751      	b.n	20020a50 <boot_device_init+0x134>
20020bac:	f7ff fc64 	bl	20020478 <board_pinmux_sd>
20020bb0:	f000 fa1c 	bl	20020fec <sdio_emmc_init>
20020bb4:	4b20      	ldr	r3, [pc, #128]	@ (20020c38 <boot_device_init+0x31c>)
20020bb6:	6018      	str	r0, [r3, #0]
20020bb8:	b908      	cbnz	r0, 20020bbe <boot_device_init+0x2a2>
20020bba:	4b20      	ldr	r3, [pc, #128]	@ (20020c3c <boot_device_init+0x320>)
20020bbc:	e7ee      	b.n	20020b9c <boot_device_init+0x280>
20020bbe:	2300      	movs	r3, #0
20020bc0:	e7ee      	b.n	20020ba0 <boot_device_init+0x284>
20020bc2:	481f      	ldr	r0, [pc, #124]	@ (20020c40 <boot_device_init+0x324>)
20020bc4:	f004 fef8 	bl	200259b8 <iprintf>
20020bc8:	e742      	b.n	20020a50 <boot_device_init+0x134>
20020bca:	bf00      	nop
20020bcc:	20044a24 	.word	0x20044a24
20020bd0:	112a8800 	.word	0x112a8800
20020bd4:	20046d3c 	.word	0x20046d3c
20020bd8:	200269cc 	.word	0x200269cc
20020bdc:	5008101c 	.word	0x5008101c
20020be0:	20046f70 	.word	0x20046f70
20020be4:	20020611 	.word	0x20020611
20020be8:	20046db0 	.word	0x20046db0
20020bec:	20046d38 	.word	0x20046d38
20020bf0:	2002058d 	.word	0x2002058d
20020bf4:	20020539 	.word	0x20020539
20020bf8:	20046d34 	.word	0x20046d34
20020bfc:	20046d2c 	.word	0x20046d2c
20020c00:	20046d30 	.word	0x20046d30
20020c04:	200269e0 	.word	0x200269e0
20020c08:	50081008 	.word	0x50081008
20020c0c:	20046d40 	.word	0x20046d40
20020c10:	20047138 	.word	0x20047138
20020c14:	53454346 	.word	0x53454346
20020c18:	200269f4 	.word	0x200269f4
20020c1c:	20020625 	.word	0x20020625
20020c20:	20045aac 	.word	0x20045aac
20020c24:	20046e20 	.word	0x20046e20
20020c28:	20047018 	.word	0x20047018
20020c2c:	20044a2c 	.word	0x20044a2c
20020c30:	200206a5 	.word	0x200206a5
20020c34:	64001000 	.word	0x64001000
20020c38:	20044a28 	.word	0x20044a28
20020c3c:	20020735 	.word	0x20020735
20020c40:	200264b8 	.word	0x200264b8
20020c44:	20042c04 	.word	0x20042c04
20020c48:	20042c00 	.word	0x20042c00
20020c4c:	4a0c      	ldr	r2, [pc, #48]	@ (20020c80 <boot_device_init+0x364>)
20020c4e:	4629      	mov	r1, r5
20020c50:	6013      	str	r3, [r2, #0]
20020c52:	4b0c      	ldr	r3, [pc, #48]	@ (20020c84 <boot_device_init+0x368>)
20020c54:	6830      	ldr	r0, [r6, #0]
20020c56:	681a      	ldr	r2, [r3, #0]
20020c58:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20020c5c:	f043 0301 	orr.w	r3, r3, #1
20020c60:	f882 302c 	strb.w	r3, [r2, #44]	@ 0x2c
20020c64:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020c68:	6823      	ldr	r3, [r4, #0]
20020c6a:	4798      	blx	r3
20020c6c:	e70c      	b.n	20020a88 <boot_device_init+0x16c>
20020c6e:	4806      	ldr	r0, [pc, #24]	@ (20020c88 <boot_device_init+0x36c>)
20020c70:	f004 fea2 	bl	200259b8 <iprintf>
20020c74:	2000      	movs	r0, #0
20020c76:	e708      	b.n	20020a8a <boot_device_init+0x16e>
20020c78:	7839      	ldrb	r1, [r7, #0]
20020c7a:	4804      	ldr	r0, [pc, #16]	@ (20020c8c <boot_device_init+0x370>)
20020c7c:	e7f8      	b.n	20020c70 <boot_device_init+0x354>
20020c7e:	bf00      	nop
20020c80:	20042c04 	.word	0x20042c04
20020c84:	20046d30 	.word	0x20046d30
20020c88:	200264cc 	.word	0x200264cc
20020c8c:	200264f2 	.word	0x200264f2

20020c90 <sifli_hw_efuse_load_bank0>:
20020c90:	2220      	movs	r2, #32
20020c92:	b508      	push	{r3, lr}
20020c94:	4904      	ldr	r1, [pc, #16]	@ (20020ca8 <sifli_hw_efuse_load_bank0+0x18>)
20020c96:	2000      	movs	r0, #0
20020c98:	f001 fb16 	bl	200222c8 <HAL_EFUSE_Read>
20020c9c:	2800      	cmp	r0, #0
20020c9e:	4802      	ldr	r0, [pc, #8]	@ (20020ca8 <sifli_hw_efuse_load_bank0+0x18>)
20020ca0:	bf08      	it	eq
20020ca2:	2000      	moveq	r0, #0
20020ca4:	bd08      	pop	{r3, pc}
20020ca6:	bf00      	nop
20020ca8:	20047114 	.word	0x20047114

20020cac <update_sec_flash>:
20020cac:	b570      	push	{r4, r5, r6, lr}
20020cae:	4604      	mov	r4, r0
20020cb0:	4b08      	ldr	r3, [pc, #32]	@ (20020cd4 <update_sec_flash+0x28>)
20020cb2:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20020cb6:	681d      	ldr	r5, [r3, #0]
20020cb8:	4b07      	ldr	r3, [pc, #28]	@ (20020cd8 <update_sec_flash+0x2c>)
20020cba:	4628      	mov	r0, r5
20020cbc:	681b      	ldr	r3, [r3, #0]
20020cbe:	4798      	blx	r3
20020cc0:	4b06      	ldr	r3, [pc, #24]	@ (20020cdc <update_sec_flash+0x30>)
20020cc2:	4621      	mov	r1, r4
20020cc4:	4628      	mov	r0, r5
20020cc6:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20020cca:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020cce:	681b      	ldr	r3, [r3, #0]
20020cd0:	4718      	bx	r3
20020cd2:	bf00      	nop
20020cd4:	20046d2c 	.word	0x20046d2c
20020cd8:	20046d34 	.word	0x20046d34
20020cdc:	20046d3c 	.word	0x20046d3c

20020ce0 <boot_images_help>:
20020ce0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020ce4:	4e55      	ldr	r6, [pc, #340]	@ (20020e3c <boot_images_help+0x15c>)
20020ce6:	f8df a164 	ldr.w	sl, [pc, #356]	@ 20020e4c <boot_images_help+0x16c>
20020cea:	6833      	ldr	r3, [r6, #0]
20020cec:	b085      	sub	sp, #20
20020cee:	4553      	cmp	r3, sl
20020cf0:	d156      	bne.n	20020da0 <boot_images_help+0xc0>
20020cf2:	2208      	movs	r2, #8
20020cf4:	2300      	movs	r3, #0
20020cf6:	f8df b158 	ldr.w	fp, [pc, #344]	@ 20020e50 <boot_images_help+0x170>
20020cfa:	eb0d 0102 	add.w	r1, sp, r2
20020cfe:	e9cd 3302 	strd	r3, r3, [sp, #8]
20020d02:	484f      	ldr	r0, [pc, #316]	@ (20020e40 <boot_images_help+0x160>)
20020d04:	f8db 3000 	ldr.w	r3, [fp]
20020d08:	4798      	blx	r3
20020d0a:	2008      	movs	r0, #8
20020d0c:	f006 fdae 	bl	2002786c <HAL_Get_backup>
20020d10:	4605      	mov	r5, r0
20020d12:	2005      	movs	r0, #5
20020d14:	f006 fdaa 	bl	2002786c <HAL_Get_backup>
20020d18:	f8df 9138 	ldr.w	r9, [pc, #312]	@ 20020e54 <boot_images_help+0x174>
20020d1c:	4949      	ldr	r1, [pc, #292]	@ (20020e44 <boot_images_help+0x164>)
20020d1e:	f8d9 4000 	ldr.w	r4, [r9]
20020d22:	f8df 8134 	ldr.w	r8, [pc, #308]	@ 20020e58 <boot_images_help+0x178>
20020d26:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d2a:	f8db 3000 	ldr.w	r3, [fp]
20020d2e:	4607      	mov	r7, r0
20020d30:	f8c8 1000 	str.w	r1, [r8]
20020d34:	4620      	mov	r0, r4
20020d36:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
20020d3a:	4798      	blx	r3
20020d3c:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
20020d40:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
20020d44:	4593      	cmp	fp, r2
20020d46:	d154      	bne.n	20020df2 <boot_images_help+0x112>
20020d48:	b2eb      	uxtb	r3, r5
20020d4a:	2b04      	cmp	r3, #4
20020d4c:	d02b      	beq.n	20020da6 <boot_images_help+0xc6>
20020d4e:	2b06      	cmp	r3, #6
20020d50:	d03f      	beq.n	20020dd2 <boot_images_help+0xf2>
20020d52:	2b01      	cmp	r3, #1
20020d54:	d148      	bne.n	20020de8 <boot_images_help+0x108>
20020d56:	2005      	movs	r0, #5
20020d58:	f006 fd88 	bl	2002786c <HAL_Get_backup>
20020d5c:	2802      	cmp	r0, #2
20020d5e:	d006      	beq.n	20020d6e <boot_images_help+0x8e>
20020d60:	9b02      	ldr	r3, [sp, #8]
20020d62:	4553      	cmp	r3, sl
20020d64:	d106      	bne.n	20020d74 <boot_images_help+0x94>
20020d66:	f89d 300d 	ldrb.w	r3, [sp, #13]
20020d6a:	2b7f      	cmp	r3, #127	@ 0x7f
20020d6c:	d102      	bne.n	20020d74 <boot_images_help+0x94>
20020d6e:	4b36      	ldr	r3, [pc, #216]	@ (20020e48 <boot_images_help+0x168>)
20020d70:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
20020d74:	f7ff fbd0 	bl	20020518 <board_init_psram>
20020d78:	f8d6 3200 	ldr.w	r3, [r6, #512]	@ 0x200
20020d7c:	3301      	adds	r3, #1
20020d7e:	d002      	beq.n	20020d86 <boot_images_help+0xa6>
20020d80:	200b      	movs	r0, #11
20020d82:	f000 fc2d 	bl	200215e0 <dfu_boot_img_in_flash>
20020d86:	f8d6 0c08 	ldr.w	r0, [r6, #3080]	@ 0xc08
20020d8a:	1c43      	adds	r3, r0, #1
20020d8c:	d008      	beq.n	20020da0 <boot_images_help+0xc0>
20020d8e:	f8d9 3000 	ldr.w	r3, [r9]
20020d92:	1ac0      	subs	r0, r0, r3
20020d94:	f5a0 5080 	sub.w	r0, r0, #4096	@ 0x1000
20020d98:	0a40      	lsrs	r0, r0, #9
20020d9a:	3002      	adds	r0, #2
20020d9c:	f000 fc20 	bl	200215e0 <dfu_boot_img_in_flash>
20020da0:	b005      	add	sp, #20
20020da2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020da6:	2008      	movs	r0, #8
20020da8:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020dac:	2106      	movs	r1, #6
20020dae:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20020db2:	f006 fd55 	bl	20027860 <HAL_Set_backup>
20020db6:	f8d8 0000 	ldr.w	r0, [r8]
20020dba:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020dbe:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20020dc2:	b11f      	cbz	r7, 20020dcc <boot_images_help+0xec>
20020dc4:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020dc8:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20020dcc:	f7ff ff6e 	bl	20020cac <update_sec_flash>
20020dd0:	e7c1      	b.n	20020d56 <boot_images_help+0x76>
20020dd2:	2101      	movs	r1, #1
20020dd4:	2008      	movs	r0, #8
20020dd6:	f006 fd43 	bl	20027860 <HAL_Set_backup>
20020dda:	f8d8 0000 	ldr.w	r0, [r8]
20020dde:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020de2:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
20020de6:	e7f1      	b.n	20020dcc <boot_images_help+0xec>
20020de8:	2101      	movs	r1, #1
20020dea:	2008      	movs	r0, #8
20020dec:	f006 fd38 	bl	20027860 <HAL_Set_backup>
20020df0:	e7b1      	b.n	20020d56 <boot_images_help+0x76>
20020df2:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020df6:	45a3      	cmp	fp, r4
20020df8:	d1ad      	bne.n	20020d56 <boot_images_help+0x76>
20020dfa:	b2eb      	uxtb	r3, r5
20020dfc:	2b03      	cmp	r3, #3
20020dfe:	d005      	beq.n	20020e0c <boot_images_help+0x12c>
20020e00:	2b05      	cmp	r3, #5
20020e02:	d018      	beq.n	20020e36 <boot_images_help+0x156>
20020e04:	2b02      	cmp	r3, #2
20020e06:	d0a6      	beq.n	20020d56 <boot_images_help+0x76>
20020e08:	2102      	movs	r1, #2
20020e0a:	e7ee      	b.n	20020dea <boot_images_help+0x10a>
20020e0c:	2008      	movs	r0, #8
20020e0e:	2105      	movs	r1, #5
20020e10:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20020e14:	9201      	str	r2, [sp, #4]
20020e16:	f006 fd23 	bl	20027860 <HAL_Set_backup>
20020e1a:	f8d8 0000 	ldr.w	r0, [r8]
20020e1e:	9a01      	ldr	r2, [sp, #4]
20020e20:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020e24:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
20020e28:	2f00      	cmp	r7, #0
20020e2a:	d0cf      	beq.n	20020dcc <boot_images_help+0xec>
20020e2c:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020e30:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20020e34:	e7ca      	b.n	20020dcc <boot_images_help+0xec>
20020e36:	2102      	movs	r1, #2
20020e38:	e7cc      	b.n	20020dd4 <boot_images_help+0xf4>
20020e3a:	bf00      	nop
20020e3c:	20047138 	.word	0x20047138
20020e40:	127c0000 	.word	0x127c0000
20020e44:	20049d4c 	.word	0x20049d4c
20020e48:	12001000 	.word	0x12001000
20020e4c:	53454346 	.word	0x53454346
20020e50:	20046d3c 	.word	0x20046d3c
20020e54:	20046d2c 	.word	0x20046d2c
20020e58:	20049d48 	.word	0x20049d48

20020e5c <_write>:
20020e5c:	2802      	cmp	r0, #2
20020e5e:	b510      	push	{r4, lr}
20020e60:	4614      	mov	r4, r2
20020e62:	dc04      	bgt.n	20020e6e <_write+0x12>
20020e64:	4803      	ldr	r0, [pc, #12]	@ (20020e74 <_write+0x18>)
20020e66:	f7ff fa15 	bl	20020294 <boot_uart_tx>
20020e6a:	4620      	mov	r0, r4
20020e6c:	bd10      	pop	{r4, pc}
20020e6e:	f04f 34ff 	mov.w	r4, #4294967295
20020e72:	e7fa      	b.n	20020e6a <_write+0xe>
20020e74:	50084000 	.word	0x50084000

20020e78 <entry>:
20020e78:	b508      	push	{r3, lr}
20020e7a:	f000 fb89 	bl	20021590 <sboot_init>
20020e7e:	f7ff fb46 	bl	2002050e <board_init>
20020e82:	f7ff fb3d 	bl	20020500 <board_boot_from>
20020e86:	4b04      	ldr	r3, [pc, #16]	@ (20020e98 <entry+0x20>)
20020e88:	7018      	strb	r0, [r3, #0]
20020e8a:	f7ff fd47 	bl	2002091c <boot_device_init>
20020e8e:	b108      	cbz	r0, 20020e94 <entry+0x1c>
20020e90:	f7ff ff26 	bl	20020ce0 <boot_images_help>
20020e94:	e7fe      	b.n	20020e94 <entry+0x1c>
20020e96:	bf00      	nop
20020e98:	20044a24 	.word	0x20044a24

20020e9c <sd1_init>:
20020e9c:	b510      	push	{r4, lr}
20020e9e:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20020ea2:	68e3      	ldr	r3, [r4, #12]
20020ea4:	2064      	movs	r0, #100	@ 0x64
20020ea6:	f023 0310 	bic.w	r3, r3, #16
20020eaa:	60e3      	str	r3, [r4, #12]
20020eac:	f000 fd5b 	bl	20021966 <HAL_Delay_us>
20020eb0:	f44f 7280 	mov.w	r2, #256	@ 0x100
20020eb4:	68e3      	ldr	r3, [r4, #12]
20020eb6:	f043 0310 	orr.w	r3, r3, #16
20020eba:	60e3      	str	r3, [r4, #12]
20020ebc:	4b02      	ldr	r3, [pc, #8]	@ (20020ec8 <sd1_init+0x2c>)
20020ebe:	631a      	str	r2, [r3, #48]	@ 0x30
20020ec0:	2200      	movs	r2, #0
20020ec2:	63da      	str	r2, [r3, #60]	@ 0x3c
20020ec4:	bd10      	pop	{r4, pc}
20020ec6:	bf00      	nop
20020ec8:	50045000 	.word	0x50045000

20020ecc <sd1_wait_cmd>:
20020ecc:	4b08      	ldr	r3, [pc, #32]	@ (20020ef0 <sd1_wait_cmd+0x24>)
20020ece:	681a      	ldr	r2, [r3, #0]
20020ed0:	f012 0f0a 	tst.w	r2, #10
20020ed4:	d0fb      	beq.n	20020ece <sd1_wait_cmd+0x2>
20020ed6:	2202      	movs	r2, #2
20020ed8:	601a      	str	r2, [r3, #0]
20020eda:	681a      	ldr	r2, [r3, #0]
20020edc:	0712      	lsls	r2, r2, #28
20020ede:	bf5f      	itttt	pl
20020ee0:	6818      	ldrpl	r0, [r3, #0]
20020ee2:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20020ee6:	0040      	lslpl	r0, r0, #1
20020ee8:	b2c0      	uxtbpl	r0, r0
20020eea:	bf48      	it	mi
20020eec:	2001      	movmi	r0, #1
20020eee:	4770      	bx	lr
20020ef0:	50045000 	.word	0x50045000

20020ef4 <sd1_send_cmd>:
20020ef4:	b538      	push	{r3, r4, r5, lr}
20020ef6:	4604      	mov	r4, r0
20020ef8:	460d      	mov	r5, r1
20020efa:	4b11      	ldr	r3, [pc, #68]	@ (20020f40 <sd1_send_cmd+0x4c>)
20020efc:	6818      	ldr	r0, [r3, #0]
20020efe:	f000 fd32 	bl	20021966 <HAL_Delay_us>
20020f02:	4b10      	ldr	r3, [pc, #64]	@ (20020f44 <sd1_send_cmd+0x50>)
20020f04:	2c0f      	cmp	r4, #15
20020f06:	609d      	str	r5, [r3, #8]
20020f08:	ea4f 4384 	mov.w	r3, r4, lsl #18
20020f0c:	d815      	bhi.n	20020f3a <sd1_send_cmd+0x46>
20020f0e:	2201      	movs	r2, #1
20020f10:	f248 0111 	movw	r1, #32785	@ 0x8011
20020f14:	40a2      	lsls	r2, r4
20020f16:	420a      	tst	r2, r1
20020f18:	d105      	bne.n	20020f26 <sd1_send_cmd+0x32>
20020f1a:	f240 6104 	movw	r1, #1540	@ 0x604
20020f1e:	420a      	tst	r2, r1
20020f20:	d00b      	beq.n	20020f3a <sd1_send_cmd+0x46>
20020f22:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
20020f26:	4a07      	ldr	r2, [pc, #28]	@ (20020f44 <sd1_send_cmd+0x50>)
20020f28:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
20020f2c:	f043 0301 	orr.w	r3, r3, #1
20020f30:	6053      	str	r3, [r2, #4]
20020f32:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20020f36:	f7ff bfc9 	b.w	20020ecc <sd1_wait_cmd>
20020f3a:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20020f3e:	e7f2      	b.n	20020f26 <sd1_send_cmd+0x32>
20020f40:	20042c08 	.word	0x20042c08
20020f44:	50045000 	.word	0x50045000

20020f48 <sd1_send_acmd>:
20020f48:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20020f4a:	4605      	mov	r5, r0
20020f4c:	460f      	mov	r7, r1
20020f4e:	2037      	movs	r0, #55	@ 0x37
20020f50:	0411      	lsls	r1, r2, #16
20020f52:	f7ff ffcf 	bl	20020ef4 <sd1_send_cmd>
20020f56:	4604      	mov	r4, r0
20020f58:	b968      	cbnz	r0, 20020f76 <sd1_send_acmd+0x2e>
20020f5a:	4b08      	ldr	r3, [pc, #32]	@ (20020f7c <sd1_send_acmd+0x34>)
20020f5c:	4e08      	ldr	r6, [pc, #32]	@ (20020f80 <sd1_send_acmd+0x38>)
20020f5e:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
20020f62:	60b7      	str	r7, [r6, #8]
20020f64:	6073      	str	r3, [r6, #4]
20020f66:	f7ff ffb1 	bl	20020ecc <sd1_wait_cmd>
20020f6a:	2802      	cmp	r0, #2
20020f6c:	d104      	bne.n	20020f78 <sd1_send_acmd+0x30>
20020f6e:	2d29      	cmp	r5, #41	@ 0x29
20020f70:	d102      	bne.n	20020f78 <sd1_send_acmd+0x30>
20020f72:	2304      	movs	r3, #4
20020f74:	6033      	str	r3, [r6, #0]
20020f76:	4620      	mov	r0, r4
20020f78:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20020f7a:	bf00      	nop
20020f7c:	00010101 	.word	0x00010101
20020f80:	50045000 	.word	0x50045000

20020f84 <sd1_get_rsp>:
20020f84:	b530      	push	{r4, r5, lr}
20020f86:	4c06      	ldr	r4, [pc, #24]	@ (20020fa0 <sd1_get_rsp+0x1c>)
20020f88:	68e5      	ldr	r5, [r4, #12]
20020f8a:	7005      	strb	r5, [r0, #0]
20020f8c:	6920      	ldr	r0, [r4, #16]
20020f8e:	6008      	str	r0, [r1, #0]
20020f90:	6961      	ldr	r1, [r4, #20]
20020f92:	6011      	str	r1, [r2, #0]
20020f94:	69a2      	ldr	r2, [r4, #24]
20020f96:	601a      	str	r2, [r3, #0]
20020f98:	69e2      	ldr	r2, [r4, #28]
20020f9a:	9b03      	ldr	r3, [sp, #12]
20020f9c:	601a      	str	r2, [r3, #0]
20020f9e:	bd30      	pop	{r4, r5, pc}
20020fa0:	50045000 	.word	0x50045000

20020fa4 <sd1_read>:
20020fa4:	f04f 33ff 	mov.w	r3, #4294967295
20020fa8:	4a04      	ldr	r2, [pc, #16]	@ (20020fbc <sd1_read+0x18>)
20020faa:	eb03 2341 	add.w	r3, r3, r1, lsl #9
20020fae:	6293      	str	r3, [r2, #40]	@ 0x28
20020fb0:	4b03      	ldr	r3, [pc, #12]	@ (20020fc0 <sd1_read+0x1c>)
20020fb2:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20020fb6:	6253      	str	r3, [r2, #36]	@ 0x24
20020fb8:	4770      	bx	lr
20020fba:	bf00      	nop
20020fbc:	50045000 	.word	0x50045000
20020fc0:	01ff0301 	.word	0x01ff0301

20020fc4 <sd1_wait_read>:
20020fc4:	4b08      	ldr	r3, [pc, #32]	@ (20020fe8 <sd1_wait_read+0x24>)
20020fc6:	681a      	ldr	r2, [r3, #0]
20020fc8:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20020fcc:	d0fb      	beq.n	20020fc6 <sd1_wait_read+0x2>
20020fce:	2220      	movs	r2, #32
20020fd0:	601a      	str	r2, [r3, #0]
20020fd2:	681a      	ldr	r2, [r3, #0]
20020fd4:	0612      	lsls	r2, r2, #24
20020fd6:	bf5f      	itttt	pl
20020fd8:	6818      	ldrpl	r0, [r3, #0]
20020fda:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
20020fde:	0040      	lslpl	r0, r0, #1
20020fe0:	b2c0      	uxtbpl	r0, r0
20020fe2:	bf48      	it	mi
20020fe4:	2001      	movmi	r0, #1
20020fe6:	4770      	bx	lr
20020fe8:	50045000 	.word	0x50045000

20020fec <sdio_emmc_init>:
20020fec:	b530      	push	{r4, r5, lr}
20020fee:	b08d      	sub	sp, #52	@ 0x34
20020ff0:	f7ff ff54 	bl	20020e9c <sd1_init>
20020ff4:	4c6c      	ldr	r4, [pc, #432]	@ (200211a8 <sdio_emmc_init+0x1bc>)
20020ff6:	4b6d      	ldr	r3, [pc, #436]	@ (200211ac <sdio_emmc_init+0x1c0>)
20020ff8:	2500      	movs	r5, #0
20020ffa:	6323      	str	r3, [r4, #48]	@ 0x30
20020ffc:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20020ffe:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021002:	f043 0302 	orr.w	r3, r3, #2
20021006:	6323      	str	r3, [r4, #48]	@ 0x30
20021008:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
2002100c:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002100e:	6223      	str	r3, [r4, #32]
20021010:	f000 fca9 	bl	20021966 <HAL_Delay_us>
20021014:	4629      	mov	r1, r5
20021016:	4628      	mov	r0, r5
20021018:	f7ff ff6c 	bl	20020ef4 <sd1_send_cmd>
2002101c:	2301      	movs	r3, #1
2002101e:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021020:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021022:	0799      	lsls	r1, r3, #30
20021024:	d5fc      	bpl.n	20021020 <sdio_emmc_init+0x34>
20021026:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021028:	f043 0320 	orr.w	r3, r3, #32
2002102c:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002102e:	4960      	ldr	r1, [pc, #384]	@ (200211b0 <sdio_emmc_init+0x1c4>)
20021030:	2001      	movs	r0, #1
20021032:	ad07      	add	r5, sp, #28
20021034:	f7ff ff5e 	bl	20020ef4 <sd1_send_cmd>
20021038:	ab06      	add	r3, sp, #24
2002103a:	aa05      	add	r2, sp, #20
2002103c:	a904      	add	r1, sp, #16
2002103e:	f10d 000f 	add.w	r0, sp, #15
20021042:	9500      	str	r5, [sp, #0]
20021044:	f7ff ff9e 	bl	20020f84 <sd1_get_rsp>
20021048:	2014      	movs	r0, #20
2002104a:	f000 fc8c 	bl	20021966 <HAL_Delay_us>
2002104e:	9b04      	ldr	r3, [sp, #16]
20021050:	2b00      	cmp	r3, #0
20021052:	daec      	bge.n	2002102e <sdio_emmc_init+0x42>
20021054:	4a57      	ldr	r2, [pc, #348]	@ (200211b4 <sdio_emmc_init+0x1c8>)
20021056:	f3c3 7380 	ubfx	r3, r3, #30, #1
2002105a:	f083 0301 	eor.w	r3, r3, #1
2002105e:	2100      	movs	r1, #0
20021060:	2002      	movs	r0, #2
20021062:	7013      	strb	r3, [r2, #0]
20021064:	f7ff ff46 	bl	20020ef4 <sd1_send_cmd>
20021068:	2801      	cmp	r0, #1
2002106a:	f000 8081 	beq.w	20021170 <sdio_emmc_init+0x184>
2002106e:	2802      	cmp	r0, #2
20021070:	d07e      	beq.n	20021170 <sdio_emmc_init+0x184>
20021072:	ab08      	add	r3, sp, #32
20021074:	9300      	str	r3, [sp, #0]
20021076:	aa0a      	add	r2, sp, #40	@ 0x28
20021078:	ab09      	add	r3, sp, #36	@ 0x24
2002107a:	a90b      	add	r1, sp, #44	@ 0x2c
2002107c:	f10d 000f 	add.w	r0, sp, #15
20021080:	f7ff ff80 	bl	20020f84 <sd1_get_rsp>
20021084:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021088:	2003      	movs	r0, #3
2002108a:	f7ff ff33 	bl	20020ef4 <sd1_send_cmd>
2002108e:	2801      	cmp	r0, #1
20021090:	d070      	beq.n	20021174 <sdio_emmc_init+0x188>
20021092:	2802      	cmp	r0, #2
20021094:	d070      	beq.n	20021178 <sdio_emmc_init+0x18c>
20021096:	ab06      	add	r3, sp, #24
20021098:	9500      	str	r5, [sp, #0]
2002109a:	aa05      	add	r2, sp, #20
2002109c:	a904      	add	r1, sp, #16
2002109e:	f10d 000f 	add.w	r0, sp, #15
200210a2:	f7ff ff6f 	bl	20020f84 <sd1_get_rsp>
200210a6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200210aa:	2b03      	cmp	r3, #3
200210ac:	d166      	bne.n	2002117c <sdio_emmc_init+0x190>
200210ae:	4c3e      	ldr	r4, [pc, #248]	@ (200211a8 <sdio_emmc_init+0x1bc>)
200210b0:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210b4:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
200210b6:	2009      	movs	r0, #9
200210b8:	f023 0320 	bic.w	r3, r3, #32
200210bc:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210be:	f7ff ff19 	bl	20020ef4 <sd1_send_cmd>
200210c2:	2801      	cmp	r0, #1
200210c4:	d05c      	beq.n	20021180 <sdio_emmc_init+0x194>
200210c6:	2802      	cmp	r0, #2
200210c8:	d05c      	beq.n	20021184 <sdio_emmc_init+0x198>
200210ca:	ab06      	add	r3, sp, #24
200210cc:	aa05      	add	r2, sp, #20
200210ce:	a904      	add	r1, sp, #16
200210d0:	f10d 000f 	add.w	r0, sp, #15
200210d4:	9500      	str	r5, [sp, #0]
200210d6:	f7ff ff55 	bl	20020f84 <sd1_get_rsp>
200210da:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
200210de:	6323      	str	r3, [r4, #48]	@ 0x30
200210e0:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200210e2:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210e6:	f043 0302 	orr.w	r3, r3, #2
200210ea:	6323      	str	r3, [r4, #48]	@ 0x30
200210ec:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200210f0:	6223      	str	r3, [r4, #32]
200210f2:	2300      	movs	r3, #0
200210f4:	2007      	movs	r0, #7
200210f6:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210f8:	f7ff fefc 	bl	20020ef4 <sd1_send_cmd>
200210fc:	2801      	cmp	r0, #1
200210fe:	d043      	beq.n	20021188 <sdio_emmc_init+0x19c>
20021100:	2802      	cmp	r0, #2
20021102:	d043      	beq.n	2002118c <sdio_emmc_init+0x1a0>
20021104:	ab06      	add	r3, sp, #24
20021106:	9500      	str	r5, [sp, #0]
20021108:	aa05      	add	r2, sp, #20
2002110a:	a904      	add	r1, sp, #16
2002110c:	f10d 000f 	add.w	r0, sp, #15
20021110:	f7ff ff38 	bl	20020f84 <sd1_get_rsp>
20021114:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021118:	2b07      	cmp	r3, #7
2002111a:	d139      	bne.n	20021190 <sdio_emmc_init+0x1a4>
2002111c:	2101      	movs	r1, #1
2002111e:	2000      	movs	r0, #0
20021120:	f7ff ff40 	bl	20020fa4 <sd1_read>
20021124:	f04f 33ff 	mov.w	r3, #4294967295
20021128:	2100      	movs	r1, #0
2002112a:	2011      	movs	r0, #17
2002112c:	6023      	str	r3, [r4, #0]
2002112e:	f7ff fee1 	bl	20020ef4 <sd1_send_cmd>
20021132:	2801      	cmp	r0, #1
20021134:	d02e      	beq.n	20021194 <sdio_emmc_init+0x1a8>
20021136:	2802      	cmp	r0, #2
20021138:	d02e      	beq.n	20021198 <sdio_emmc_init+0x1ac>
2002113a:	ab06      	add	r3, sp, #24
2002113c:	9500      	str	r5, [sp, #0]
2002113e:	aa05      	add	r2, sp, #20
20021140:	a904      	add	r1, sp, #16
20021142:	f10d 000f 	add.w	r0, sp, #15
20021146:	f7ff ff1d 	bl	20020f84 <sd1_get_rsp>
2002114a:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002114e:	2b11      	cmp	r3, #17
20021150:	d124      	bne.n	2002119c <sdio_emmc_init+0x1b0>
20021152:	2320      	movs	r3, #32
20021154:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021156:	f7ff ff35 	bl	20020fc4 <sd1_wait_read>
2002115a:	6823      	ldr	r3, [r4, #0]
2002115c:	061a      	lsls	r2, r3, #24
2002115e:	d41f      	bmi.n	200211a0 <sdio_emmc_init+0x1b4>
20021160:	6823      	ldr	r3, [r4, #0]
20021162:	065b      	lsls	r3, r3, #25
20021164:	d41e      	bmi.n	200211a4 <sdio_emmc_init+0x1b8>
20021166:	2080      	movs	r0, #128	@ 0x80
20021168:	3801      	subs	r0, #1
2002116a:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
2002116e:	d1fb      	bne.n	20021168 <sdio_emmc_init+0x17c>
20021170:	b00d      	add	sp, #52	@ 0x34
20021172:	bd30      	pop	{r4, r5, pc}
20021174:	2003      	movs	r0, #3
20021176:	e7fb      	b.n	20021170 <sdio_emmc_init+0x184>
20021178:	2004      	movs	r0, #4
2002117a:	e7f9      	b.n	20021170 <sdio_emmc_init+0x184>
2002117c:	2005      	movs	r0, #5
2002117e:	e7f7      	b.n	20021170 <sdio_emmc_init+0x184>
20021180:	2006      	movs	r0, #6
20021182:	e7f5      	b.n	20021170 <sdio_emmc_init+0x184>
20021184:	2007      	movs	r0, #7
20021186:	e7f3      	b.n	20021170 <sdio_emmc_init+0x184>
20021188:	2008      	movs	r0, #8
2002118a:	e7f1      	b.n	20021170 <sdio_emmc_init+0x184>
2002118c:	2009      	movs	r0, #9
2002118e:	e7ef      	b.n	20021170 <sdio_emmc_init+0x184>
20021190:	200a      	movs	r0, #10
20021192:	e7ed      	b.n	20021170 <sdio_emmc_init+0x184>
20021194:	2012      	movs	r0, #18
20021196:	e7eb      	b.n	20021170 <sdio_emmc_init+0x184>
20021198:	2013      	movs	r0, #19
2002119a:	e7e9      	b.n	20021170 <sdio_emmc_init+0x184>
2002119c:	2014      	movs	r0, #20
2002119e:	e7e7      	b.n	20021170 <sdio_emmc_init+0x184>
200211a0:	2015      	movs	r0, #21
200211a2:	e7e5      	b.n	20021170 <sdio_emmc_init+0x184>
200211a4:	2016      	movs	r0, #22
200211a6:	e7e3      	b.n	20021170 <sdio_emmc_init+0x184>
200211a8:	50045000 	.word	0x50045000
200211ac:	00016700 	.word	0x00016700
200211b0:	40000080 	.word	0x40000080
200211b4:	20042c0c 	.word	0x20042c0c

200211b8 <emmc_read_data>:
200211b8:	b570      	push	{r4, r5, r6, lr}
200211ba:	4606      	mov	r6, r0
200211bc:	460d      	mov	r5, r1
200211be:	2000      	movs	r0, #0
200211c0:	2101      	movs	r1, #1
200211c2:	b088      	sub	sp, #32
200211c4:	4614      	mov	r4, r2
200211c6:	f7ff feed 	bl	20020fa4 <sd1_read>
200211ca:	f04f 32ff 	mov.w	r2, #4294967295
200211ce:	4b1c      	ldr	r3, [pc, #112]	@ (20021240 <emmc_read_data+0x88>)
200211d0:	601a      	str	r2, [r3, #0]
200211d2:	4b1c      	ldr	r3, [pc, #112]	@ (20021244 <emmc_read_data+0x8c>)
200211d4:	781b      	ldrb	r3, [r3, #0]
200211d6:	b903      	cbnz	r3, 200211da <emmc_read_data+0x22>
200211d8:	0a76      	lsrs	r6, r6, #9
200211da:	4631      	mov	r1, r6
200211dc:	2011      	movs	r0, #17
200211de:	f7ff fe89 	bl	20020ef4 <sd1_send_cmd>
200211e2:	3801      	subs	r0, #1
200211e4:	b2c0      	uxtb	r0, r0
200211e6:	2801      	cmp	r0, #1
200211e8:	d802      	bhi.n	200211f0 <emmc_read_data+0x38>
200211ea:	2000      	movs	r0, #0
200211ec:	b008      	add	sp, #32
200211ee:	bd70      	pop	{r4, r5, r6, pc}
200211f0:	ab07      	add	r3, sp, #28
200211f2:	9300      	str	r3, [sp, #0]
200211f4:	aa05      	add	r2, sp, #20
200211f6:	ab06      	add	r3, sp, #24
200211f8:	a904      	add	r1, sp, #16
200211fa:	f10d 000f 	add.w	r0, sp, #15
200211fe:	f7ff fec1 	bl	20020f84 <sd1_get_rsp>
20021202:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021206:	2b11      	cmp	r3, #17
20021208:	d1ef      	bne.n	200211ea <emmc_read_data+0x32>
2002120a:	f04f 33ff 	mov.w	r3, #4294967295
2002120e:	4e0c      	ldr	r6, [pc, #48]	@ (20021240 <emmc_read_data+0x88>)
20021210:	6033      	str	r3, [r6, #0]
20021212:	2320      	movs	r3, #32
20021214:	62f3      	str	r3, [r6, #44]	@ 0x2c
20021216:	f7ff fed5 	bl	20020fc4 <sd1_wait_read>
2002121a:	6833      	ldr	r3, [r6, #0]
2002121c:	061a      	lsls	r2, r3, #24
2002121e:	d4e4      	bmi.n	200211ea <emmc_read_data+0x32>
20021220:	6833      	ldr	r3, [r6, #0]
20021222:	065b      	lsls	r3, r3, #25
20021224:	d4e1      	bmi.n	200211ea <emmc_read_data+0x32>
20021226:	f024 0303 	bic.w	r3, r4, #3
2002122a:	442b      	add	r3, r5
2002122c:	429d      	cmp	r5, r3
2002122e:	d101      	bne.n	20021234 <emmc_read_data+0x7c>
20021230:	4620      	mov	r0, r4
20021232:	e7db      	b.n	200211ec <emmc_read_data+0x34>
20021234:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
20021238:	f845 2b04 	str.w	r2, [r5], #4
2002123c:	e7f6      	b.n	2002122c <emmc_read_data+0x74>
2002123e:	bf00      	nop
20021240:	50045000 	.word	0x50045000
20021244:	20042c0c 	.word	0x20042c0c

20021248 <sdio_sd_init>:
20021248:	b5f0      	push	{r4, r5, r6, r7, lr}
2002124a:	b08d      	sub	sp, #52	@ 0x34
2002124c:	f7ff fe26 	bl	20020e9c <sd1_init>
20021250:	4c83      	ldr	r4, [pc, #524]	@ (20021460 <sdio_sd_init+0x218>)
20021252:	4b84      	ldr	r3, [pc, #528]	@ (20021464 <sdio_sd_init+0x21c>)
20021254:	2500      	movs	r5, #0
20021256:	6323      	str	r3, [r4, #48]	@ 0x30
20021258:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002125a:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
2002125e:	f043 0302 	orr.w	r3, r3, #2
20021262:	6323      	str	r3, [r4, #48]	@ 0x30
20021264:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20021268:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002126a:	6223      	str	r3, [r4, #32]
2002126c:	f000 fb7b 	bl	20021966 <HAL_Delay_us>
20021270:	4629      	mov	r1, r5
20021272:	4628      	mov	r0, r5
20021274:	f7ff fe3e 	bl	20020ef4 <sd1_send_cmd>
20021278:	2301      	movs	r3, #1
2002127a:	65e3      	str	r3, [r4, #92]	@ 0x5c
2002127c:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
2002127e:	079a      	lsls	r2, r3, #30
20021280:	d5fc      	bpl.n	2002127c <sdio_sd_init+0x34>
20021282:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
20021286:	2008      	movs	r0, #8
20021288:	f7ff fe34 	bl	20020ef4 <sd1_send_cmd>
2002128c:	3801      	subs	r0, #1
2002128e:	b2c0      	uxtb	r0, r0
20021290:	2801      	cmp	r0, #1
20021292:	d802      	bhi.n	2002129a <sdio_sd_init+0x52>
20021294:	2038      	movs	r0, #56	@ 0x38
20021296:	b00d      	add	sp, #52	@ 0x34
20021298:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002129a:	ac07      	add	r4, sp, #28
2002129c:	ab06      	add	r3, sp, #24
2002129e:	9400      	str	r4, [sp, #0]
200212a0:	aa05      	add	r2, sp, #20
200212a2:	a904      	add	r1, sp, #16
200212a4:	f10d 000f 	add.w	r0, sp, #15
200212a8:	f7ff fe6c 	bl	20020f84 <sd1_get_rsp>
200212ac:	f89d 300f 	ldrb.w	r3, [sp, #15]
200212b0:	2b08      	cmp	r3, #8
200212b2:	d1ef      	bne.n	20021294 <sdio_sd_init+0x4c>
200212b4:	9b04      	ldr	r3, [sp, #16]
200212b6:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
200212ba:	d1eb      	bne.n	20021294 <sdio_sd_init+0x4c>
200212bc:	2200      	movs	r2, #0
200212be:	2029      	movs	r0, #41	@ 0x29
200212c0:	4969      	ldr	r1, [pc, #420]	@ (20021468 <sdio_sd_init+0x220>)
200212c2:	f7ff fe41 	bl	20020f48 <sd1_send_acmd>
200212c6:	2801      	cmp	r0, #1
200212c8:	f000 80bd 	beq.w	20021446 <sdio_sd_init+0x1fe>
200212cc:	ab06      	add	r3, sp, #24
200212ce:	9400      	str	r4, [sp, #0]
200212d0:	aa05      	add	r2, sp, #20
200212d2:	a904      	add	r1, sp, #16
200212d4:	f10d 000f 	add.w	r0, sp, #15
200212d8:	f7ff fe54 	bl	20020f84 <sd1_get_rsp>
200212dc:	9b04      	ldr	r3, [sp, #16]
200212de:	2b00      	cmp	r3, #0
200212e0:	db03      	blt.n	200212ea <sdio_sd_init+0xa2>
200212e2:	2002      	movs	r0, #2
200212e4:	f000 fb3f 	bl	20021966 <HAL_Delay_us>
200212e8:	e7e8      	b.n	200212bc <sdio_sd_init+0x74>
200212ea:	2100      	movs	r1, #0
200212ec:	2002      	movs	r0, #2
200212ee:	f7ff fe01 	bl	20020ef4 <sd1_send_cmd>
200212f2:	3801      	subs	r0, #1
200212f4:	b2c0      	uxtb	r0, r0
200212f6:	2801      	cmp	r0, #1
200212f8:	f240 80a7 	bls.w	2002144a <sdio_sd_init+0x202>
200212fc:	ab08      	add	r3, sp, #32
200212fe:	9300      	str	r3, [sp, #0]
20021300:	aa0a      	add	r2, sp, #40	@ 0x28
20021302:	ab09      	add	r3, sp, #36	@ 0x24
20021304:	a90b      	add	r1, sp, #44	@ 0x2c
20021306:	f10d 000f 	add.w	r0, sp, #15
2002130a:	f7ff fe3b 	bl	20020f84 <sd1_get_rsp>
2002130e:	2100      	movs	r1, #0
20021310:	2003      	movs	r0, #3
20021312:	f7ff fdef 	bl	20020ef4 <sd1_send_cmd>
20021316:	3801      	subs	r0, #1
20021318:	b2c0      	uxtb	r0, r0
2002131a:	2801      	cmp	r0, #1
2002131c:	d801      	bhi.n	20021322 <sdio_sd_init+0xda>
2002131e:	2033      	movs	r0, #51	@ 0x33
20021320:	e7b9      	b.n	20021296 <sdio_sd_init+0x4e>
20021322:	ab06      	add	r3, sp, #24
20021324:	9400      	str	r4, [sp, #0]
20021326:	aa05      	add	r2, sp, #20
20021328:	a904      	add	r1, sp, #16
2002132a:	f10d 000f 	add.w	r0, sp, #15
2002132e:	f7ff fe29 	bl	20020f84 <sd1_get_rsp>
20021332:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021336:	2b03      	cmp	r3, #3
20021338:	d1f1      	bne.n	2002131e <sdio_sd_init+0xd6>
2002133a:	9f04      	ldr	r7, [sp, #16]
2002133c:	2009      	movs	r0, #9
2002133e:	0c3d      	lsrs	r5, r7, #16
20021340:	042d      	lsls	r5, r5, #16
20021342:	4629      	mov	r1, r5
20021344:	f7ff fdd6 	bl	20020ef4 <sd1_send_cmd>
20021348:	3801      	subs	r0, #1
2002134a:	b2c0      	uxtb	r0, r0
2002134c:	2801      	cmp	r0, #1
2002134e:	d97e      	bls.n	2002144e <sdio_sd_init+0x206>
20021350:	9400      	str	r4, [sp, #0]
20021352:	ab06      	add	r3, sp, #24
20021354:	aa05      	add	r2, sp, #20
20021356:	a904      	add	r1, sp, #16
20021358:	f10d 000f 	add.w	r0, sp, #15
2002135c:	f7ff fe12 	bl	20020f84 <sd1_get_rsp>
20021360:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021364:	9c06      	ldr	r4, [sp, #24]
20021366:	9907      	ldr	r1, [sp, #28]
20021368:	0e23      	lsrs	r3, r4, #24
2002136a:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
2002136e:	0e01      	lsrs	r1, r0, #24
20021370:	ea41 2104 	orr.w	r1, r1, r4, lsl #8
20021374:	9105      	str	r1, [sp, #20]
20021376:	0e11      	lsrs	r1, r2, #24
20021378:	9304      	str	r3, [sp, #16]
2002137a:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
2002137e:	0212      	lsls	r2, r2, #8
20021380:	0f9b      	lsrs	r3, r3, #30
20021382:	9106      	str	r1, [sp, #24]
20021384:	9207      	str	r2, [sp, #28]
20021386:	d01b      	beq.n	200213c0 <sdio_sd_init+0x178>
20021388:	2b01      	cmp	r3, #1
2002138a:	d162      	bne.n	20021452 <sdio_sd_init+0x20a>
2002138c:	2300      	movs	r3, #0
2002138e:	4a37      	ldr	r2, [pc, #220]	@ (2002146c <sdio_sd_init+0x224>)
20021390:	4c33      	ldr	r4, [pc, #204]	@ (20021460 <sdio_sd_init+0x218>)
20021392:	7013      	strb	r3, [r2, #0]
20021394:	f44f 63a0 	mov.w	r3, #1280	@ 0x500
20021398:	6323      	str	r3, [r4, #48]	@ 0x30
2002139a:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002139c:	2600      	movs	r6, #0
2002139e:	f043 0302 	orr.w	r3, r3, #2
200213a2:	6323      	str	r3, [r4, #48]	@ 0x30
200213a4:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200213a8:	4629      	mov	r1, r5
200213aa:	6223      	str	r3, [r4, #32]
200213ac:	2007      	movs	r0, #7
200213ae:	63e6      	str	r6, [r4, #60]	@ 0x3c
200213b0:	f7ff fda0 	bl	20020ef4 <sd1_send_cmd>
200213b4:	3801      	subs	r0, #1
200213b6:	b2c0      	uxtb	r0, r0
200213b8:	2801      	cmp	r0, #1
200213ba:	d803      	bhi.n	200213c4 <sdio_sd_init+0x17c>
200213bc:	2037      	movs	r0, #55	@ 0x37
200213be:	e76a      	b.n	20021296 <sdio_sd_init+0x4e>
200213c0:	2301      	movs	r3, #1
200213c2:	e7e4      	b.n	2002138e <sdio_sd_init+0x146>
200213c4:	ad07      	add	r5, sp, #28
200213c6:	ab06      	add	r3, sp, #24
200213c8:	9500      	str	r5, [sp, #0]
200213ca:	aa05      	add	r2, sp, #20
200213cc:	a904      	add	r1, sp, #16
200213ce:	f10d 000f 	add.w	r0, sp, #15
200213d2:	f7ff fdd7 	bl	20020f84 <sd1_get_rsp>
200213d6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200213da:	2b07      	cmp	r3, #7
200213dc:	d1ee      	bne.n	200213bc <sdio_sd_init+0x174>
200213de:	4631      	mov	r1, r6
200213e0:	2006      	movs	r0, #6
200213e2:	0c3a      	lsrs	r2, r7, #16
200213e4:	f7ff fdb0 	bl	20020f48 <sd1_send_acmd>
200213e8:	3801      	subs	r0, #1
200213ea:	b2c0      	uxtb	r0, r0
200213ec:	2801      	cmp	r0, #1
200213ee:	d932      	bls.n	20021456 <sdio_sd_init+0x20e>
200213f0:	2101      	movs	r1, #1
200213f2:	4630      	mov	r0, r6
200213f4:	f7ff fdd6 	bl	20020fa4 <sd1_read>
200213f8:	4631      	mov	r1, r6
200213fa:	2011      	movs	r0, #17
200213fc:	f7ff fd7a 	bl	20020ef4 <sd1_send_cmd>
20021400:	3801      	subs	r0, #1
20021402:	b2c0      	uxtb	r0, r0
20021404:	2801      	cmp	r0, #1
20021406:	d801      	bhi.n	2002140c <sdio_sd_init+0x1c4>
20021408:	2052      	movs	r0, #82	@ 0x52
2002140a:	e744      	b.n	20021296 <sdio_sd_init+0x4e>
2002140c:	ab06      	add	r3, sp, #24
2002140e:	9500      	str	r5, [sp, #0]
20021410:	aa05      	add	r2, sp, #20
20021412:	a904      	add	r1, sp, #16
20021414:	f10d 000f 	add.w	r0, sp, #15
20021418:	f7ff fdb4 	bl	20020f84 <sd1_get_rsp>
2002141c:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021420:	2b11      	cmp	r3, #17
20021422:	d1f1      	bne.n	20021408 <sdio_sd_init+0x1c0>
20021424:	f04f 33ff 	mov.w	r3, #4294967295
20021428:	6023      	str	r3, [r4, #0]
2002142a:	2320      	movs	r3, #32
2002142c:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002142e:	f7ff fdc9 	bl	20020fc4 <sd1_wait_read>
20021432:	6823      	ldr	r3, [r4, #0]
20021434:	061b      	lsls	r3, r3, #24
20021436:	d410      	bmi.n	2002145a <sdio_sd_init+0x212>
20021438:	6823      	ldr	r3, [r4, #0]
2002143a:	f013 0f40 	tst.w	r3, #64	@ 0x40
2002143e:	bf14      	ite	ne
20021440:	2044      	movne	r0, #68	@ 0x44
20021442:	2001      	moveq	r0, #1
20021444:	e727      	b.n	20021296 <sdio_sd_init+0x4e>
20021446:	2034      	movs	r0, #52	@ 0x34
20021448:	e725      	b.n	20021296 <sdio_sd_init+0x4e>
2002144a:	2032      	movs	r0, #50	@ 0x32
2002144c:	e723      	b.n	20021296 <sdio_sd_init+0x4e>
2002144e:	2039      	movs	r0, #57	@ 0x39
20021450:	e721      	b.n	20021296 <sdio_sd_init+0x4e>
20021452:	2054      	movs	r0, #84	@ 0x54
20021454:	e71f      	b.n	20021296 <sdio_sd_init+0x4e>
20021456:	2036      	movs	r0, #54	@ 0x36
20021458:	e71d      	b.n	20021296 <sdio_sd_init+0x4e>
2002145a:	204f      	movs	r0, #79	@ 0x4f
2002145c:	e71b      	b.n	20021296 <sdio_sd_init+0x4e>
2002145e:	bf00      	nop
20021460:	50045000 	.word	0x50045000
20021464:	00016700 	.word	0x00016700
20021468:	40ff8000 	.word	0x40ff8000
2002146c:	20042c0d 	.word	0x20042c0d

20021470 <sd_read_data>:
20021470:	b570      	push	{r4, r5, r6, lr}
20021472:	4606      	mov	r6, r0
20021474:	460d      	mov	r5, r1
20021476:	2000      	movs	r0, #0
20021478:	2101      	movs	r1, #1
2002147a:	b088      	sub	sp, #32
2002147c:	4614      	mov	r4, r2
2002147e:	f7ff fd91 	bl	20020fa4 <sd1_read>
20021482:	4b1b      	ldr	r3, [pc, #108]	@ (200214f0 <sd_read_data+0x80>)
20021484:	781b      	ldrb	r3, [r3, #0]
20021486:	b903      	cbnz	r3, 2002148a <sd_read_data+0x1a>
20021488:	0a76      	lsrs	r6, r6, #9
2002148a:	4631      	mov	r1, r6
2002148c:	2011      	movs	r0, #17
2002148e:	f7ff fd31 	bl	20020ef4 <sd1_send_cmd>
20021492:	3801      	subs	r0, #1
20021494:	b2c0      	uxtb	r0, r0
20021496:	2801      	cmp	r0, #1
20021498:	d802      	bhi.n	200214a0 <sd_read_data+0x30>
2002149a:	2000      	movs	r0, #0
2002149c:	b008      	add	sp, #32
2002149e:	bd70      	pop	{r4, r5, r6, pc}
200214a0:	ab07      	add	r3, sp, #28
200214a2:	9300      	str	r3, [sp, #0]
200214a4:	aa05      	add	r2, sp, #20
200214a6:	ab06      	add	r3, sp, #24
200214a8:	a904      	add	r1, sp, #16
200214aa:	f10d 000f 	add.w	r0, sp, #15
200214ae:	f7ff fd69 	bl	20020f84 <sd1_get_rsp>
200214b2:	f89d 300f 	ldrb.w	r3, [sp, #15]
200214b6:	2b11      	cmp	r3, #17
200214b8:	d1ef      	bne.n	2002149a <sd_read_data+0x2a>
200214ba:	f04f 33ff 	mov.w	r3, #4294967295
200214be:	4e0d      	ldr	r6, [pc, #52]	@ (200214f4 <sd_read_data+0x84>)
200214c0:	6033      	str	r3, [r6, #0]
200214c2:	2320      	movs	r3, #32
200214c4:	62f3      	str	r3, [r6, #44]	@ 0x2c
200214c6:	f7ff fd7d 	bl	20020fc4 <sd1_wait_read>
200214ca:	6833      	ldr	r3, [r6, #0]
200214cc:	061a      	lsls	r2, r3, #24
200214ce:	d4e4      	bmi.n	2002149a <sd_read_data+0x2a>
200214d0:	6833      	ldr	r3, [r6, #0]
200214d2:	065b      	lsls	r3, r3, #25
200214d4:	d4e1      	bmi.n	2002149a <sd_read_data+0x2a>
200214d6:	f024 0303 	bic.w	r3, r4, #3
200214da:	442b      	add	r3, r5
200214dc:	429d      	cmp	r5, r3
200214de:	d101      	bne.n	200214e4 <sd_read_data+0x74>
200214e0:	4620      	mov	r0, r4
200214e2:	e7db      	b.n	2002149c <sd_read_data+0x2c>
200214e4:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
200214e8:	f845 2b04 	str.w	r2, [r5], #4
200214ec:	e7f6      	b.n	200214dc <sd_read_data+0x6c>
200214ee:	bf00      	nop
200214f0:	20042c0d 	.word	0x20042c0d
200214f4:	50045000 	.word	0x50045000

200214f8 <is_addr_in_nor>:
200214f8:	4b09      	ldr	r3, [pc, #36]	@ (20021520 <is_addr_in_nor+0x28>)
200214fa:	4602      	mov	r2, r0
200214fc:	681b      	ldr	r3, [r3, #0]
200214fe:	b163      	cbz	r3, 2002151a <is_addr_in_nor+0x22>
20021500:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
20021504:	b948      	cbnz	r0, 2002151a <is_addr_in_nor+0x22>
20021506:	6919      	ldr	r1, [r3, #16]
20021508:	4291      	cmp	r1, r2
2002150a:	d807      	bhi.n	2002151c <is_addr_in_nor+0x24>
2002150c:	695b      	ldr	r3, [r3, #20]
2002150e:	4419      	add	r1, r3
20021510:	4291      	cmp	r1, r2
20021512:	bf94      	ite	ls
20021514:	2000      	movls	r0, #0
20021516:	2001      	movhi	r0, #1
20021518:	4770      	bx	lr
2002151a:	2000      	movs	r0, #0
2002151c:	4770      	bx	lr
2002151e:	bf00      	nop
20021520:	20046d30 	.word	0x20046d30

20021524 <sifli_verify_img_cmac_hash>:
20021524:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20021528:	461d      	mov	r5, r3
2002152a:	4b16      	ldr	r3, [pc, #88]	@ (20021584 <sifli_verify_img_cmac_hash+0x60>)
2002152c:	460e      	mov	r6, r1
2002152e:	681b      	ldr	r3, [r3, #0]
20021530:	4617      	mov	r7, r2
20021532:	b092      	sub	sp, #72	@ 0x48
20021534:	b12b      	cbz	r3, 20021542 <sifli_verify_img_cmac_hash+0x1e>
20021536:	b920      	cbnz	r0, 20021542 <sifli_verify_img_cmac_hash+0x1e>
20021538:	2220      	movs	r2, #32
2002153a:	2002      	movs	r0, #2
2002153c:	4912      	ldr	r1, [pc, #72]	@ (20021588 <sifli_verify_img_cmac_hash+0x64>)
2002153e:	4798      	blx	r3
20021540:	4811      	ldr	r0, [pc, #68]	@ (20021588 <sifli_verify_img_cmac_hash+0x64>)
20021542:	4601      	mov	r1, r0
20021544:	2220      	movs	r2, #32
20021546:	a803      	add	r0, sp, #12
20021548:	f003 ff16 	bl	20025378 <sf_crypto_aes_cmac_init>
2002154c:	4604      	mov	r4, r0
2002154e:	b100      	cbz	r0, 20021552 <sifli_verify_img_cmac_hash+0x2e>
20021550:	e7fe      	b.n	20021550 <sifli_verify_img_cmac_hash+0x2c>
20021552:	f8df 8038 	ldr.w	r8, [pc, #56]	@ 2002158c <sifli_verify_img_cmac_hash+0x68>
20021556:	2301      	movs	r3, #1
20021558:	463a      	mov	r2, r7
2002155a:	4631      	mov	r1, r6
2002155c:	f8cd 8000 	str.w	r8, [sp]
20021560:	a803      	add	r0, sp, #12
20021562:	f003 ff46 	bl	200253f2 <sf_crypto_aes_cmac_calc>
20021566:	b950      	cbnz	r0, 2002157e <sifli_verify_img_cmac_hash+0x5a>
20021568:	2210      	movs	r2, #16
2002156a:	4629      	mov	r1, r5
2002156c:	4640      	mov	r0, r8
2002156e:	f004 fb69 	bl	20025c44 <memcmp>
20021572:	fab0 f080 	clz	r0, r0
20021576:	0940      	lsrs	r0, r0, #5
20021578:	b012      	add	sp, #72	@ 0x48
2002157a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002157e:	4620      	mov	r0, r4
20021580:	e7fa      	b.n	20021578 <sifli_verify_img_cmac_hash+0x54>
20021582:	bf00      	nop
20021584:	20047134 	.word	0x20047134
20021588:	2004c960 	.word	0x2004c960
2002158c:	2004c980 	.word	0x2004c980

20021590 <sboot_init>:
20021590:	b507      	push	{r0, r1, r2, lr}
20021592:	f7ff fb7d 	bl	20020c90 <sifli_hw_efuse_load_bank0>
20021596:	b150      	cbz	r0, 200215ae <sboot_init+0x1e>
20021598:	2302      	movs	r3, #2
2002159a:	21ee      	movs	r1, #238	@ 0xee
2002159c:	f10d 0207 	add.w	r2, sp, #7
200215a0:	f006 f8d2 	bl	20027748 <HAL_EFUSE_Extract>
200215a4:	2800      	cmp	r0, #0
200215a6:	dc08      	bgt.n	200215ba <sboot_init+0x2a>
200215a8:	b003      	add	sp, #12
200215aa:	f85d fb04 	ldr.w	pc, [sp], #4
200215ae:	4807      	ldr	r0, [pc, #28]	@ (200215cc <sboot_init+0x3c>)
200215b0:	b003      	add	sp, #12
200215b2:	f85d eb04 	ldr.w	lr, [sp], #4
200215b6:	f004 ba67 	b.w	20025a88 <puts>
200215ba:	f89d 3007 	ldrb.w	r3, [sp, #7]
200215be:	2b00      	cmp	r3, #0
200215c0:	d0f2      	beq.n	200215a8 <sboot_init+0x18>
200215c2:	2201      	movs	r2, #1
200215c4:	4b02      	ldr	r3, [pc, #8]	@ (200215d0 <sboot_init+0x40>)
200215c6:	701a      	strb	r2, [r3, #0]
200215c8:	e7ee      	b.n	200215a8 <sboot_init+0x18>
200215ca:	bf00      	nop
200215cc:	20026514 	.word	0x20026514
200215d0:	2004c95c 	.word	0x2004c95c

200215d4 <run_img>:
200215d4:	f8d0 d000 	ldr.w	sp, [r0]
200215d8:	f8d0 f004 	ldr.w	pc, [r0, #4]
200215dc:	4770      	bx	lr
	...

200215e0 <dfu_boot_img_in_flash>:
200215e0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200215e4:	4e27      	ldr	r6, [pc, #156]	@ (20021684 <dfu_boot_img_in_flash+0xa4>)
200215e6:	1e84      	subs	r4, r0, #2
200215e8:	eb06 1300 	add.w	r3, r6, r0, lsl #4
200215ec:	eb06 2040 	add.w	r0, r6, r0, lsl #9
200215f0:	f8d0 7c00 	ldr.w	r7, [r0, #3072]	@ 0xc00
200215f4:	f8d3 8004 	ldr.w	r8, [r3, #4]
200215f8:	68dd      	ldr	r5, [r3, #12]
200215fa:	b177      	cbz	r7, 2002161a <dfu_boot_img_in_flash+0x3a>
200215fc:	45a8      	cmp	r8, r5
200215fe:	d00c      	beq.n	2002161a <dfu_boot_img_in_flash+0x3a>
20021600:	4628      	mov	r0, r5
20021602:	f7ff ff79 	bl	200214f8 <is_addr_in_nor>
20021606:	b940      	cbnz	r0, 2002161a <dfu_boot_img_in_flash+0x3a>
20021608:	4b1f      	ldr	r3, [pc, #124]	@ (20021688 <dfu_boot_img_in_flash+0xa8>)
2002160a:	4629      	mov	r1, r5
2002160c:	781a      	ldrb	r2, [r3, #0]
2002160e:	4b1f      	ldr	r3, [pc, #124]	@ (2002168c <dfu_boot_img_in_flash+0xac>)
20021610:	4640      	mov	r0, r8
20021612:	681b      	ldr	r3, [r3, #0]
20021614:	eb07 1202 	add.w	r2, r7, r2, lsl #4
20021618:	4798      	blx	r3
2002161a:	2c07      	cmp	r4, #7
2002161c:	dc30      	bgt.n	20021680 <dfu_boot_img_in_flash+0xa0>
2002161e:	4263      	negs	r3, r4
20021620:	f003 0303 	and.w	r3, r3, #3
20021624:	f004 0703 	and.w	r7, r4, #3
20021628:	bf58      	it	pl
2002162a:	425f      	negpl	r7, r3
2002162c:	2f02      	cmp	r7, #2
2002162e:	d827      	bhi.n	20021680 <dfu_boot_img_in_flash+0xa0>
20021630:	4628      	mov	r0, r5
20021632:	f7ff ff61 	bl	200214f8 <is_addr_in_nor>
20021636:	b150      	cbz	r0, 2002164e <dfu_boot_img_in_flash+0x6e>
20021638:	4815      	ldr	r0, [pc, #84]	@ (20021690 <dfu_boot_img_in_flash+0xb0>)
2002163a:	f104 0208 	add.w	r2, r4, #8
2002163e:	0252      	lsls	r2, r2, #9
20021640:	4629      	mov	r1, r5
20021642:	58b2      	ldr	r2, [r6, r2]
20021644:	6800      	ldr	r0, [r0, #0]
20021646:	eba8 0305 	sub.w	r3, r8, r5
2002164a:	f001 fbfd 	bl	20022e48 <HAL_FLASH_ALIAS_CFG>
2002164e:	4b0e      	ldr	r3, [pc, #56]	@ (20021688 <dfu_boot_img_in_flash+0xa8>)
20021650:	781b      	ldrb	r3, [r3, #0]
20021652:	b923      	cbnz	r3, 2002165e <dfu_boot_img_in_flash+0x7e>
20021654:	4628      	mov	r0, r5
20021656:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002165a:	f7ff bfbb 	b.w	200215d4 <run_img>
2002165e:	2f01      	cmp	r7, #1
20021660:	d1f8      	bne.n	20021654 <dfu_boot_img_in_flash+0x74>
20021662:	3408      	adds	r4, #8
20021664:	0264      	lsls	r4, r4, #9
20021666:	5932      	ldr	r2, [r6, r4]
20021668:	4629      	mov	r1, r5
2002166a:	2000      	movs	r0, #0
2002166c:	1953      	adds	r3, r2, r5
2002166e:	f7ff ff59 	bl	20021524 <sifli_verify_img_cmac_hash>
20021672:	2800      	cmp	r0, #0
20021674:	d1ee      	bne.n	20021654 <dfu_boot_img_in_flash+0x74>
20021676:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002167a:	4806      	ldr	r0, [pc, #24]	@ (20021694 <dfu_boot_img_in_flash+0xb4>)
2002167c:	f004 ba04 	b.w	20025a88 <puts>
20021680:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021684:	20047138 	.word	0x20047138
20021688:	2004c95c 	.word	0x2004c95c
2002168c:	20046d3c 	.word	0x20046d3c
20021690:	20046d30 	.word	0x20046d30
20021694:	20026525 	.word	0x20026525

20021698 <_close>:
20021698:	f04f 30ff 	mov.w	r0, #4294967295
2002169c:	4770      	bx	lr

2002169e <_lseek>:
2002169e:	f04f 30ff 	mov.w	r0, #4294967295
200216a2:	4770      	bx	lr

200216a4 <_read>:
200216a4:	2000      	movs	r0, #0
200216a6:	4770      	bx	lr

200216a8 <_fstat>:
200216a8:	2000      	movs	r0, #0
200216aa:	4770      	bx	lr

200216ac <_isatty>:
200216ac:	2001      	movs	r0, #1
200216ae:	4770      	bx	lr

200216b0 <flash_memset>:
200216b0:	4603      	mov	r3, r0
200216b2:	4402      	add	r2, r0
200216b4:	4293      	cmp	r3, r2
200216b6:	d100      	bne.n	200216ba <flash_memset+0xa>
200216b8:	4770      	bx	lr
200216ba:	f803 1b01 	strb.w	r1, [r3], #1
200216be:	e7f9      	b.n	200216b4 <flash_memset+0x4>

200216c0 <bsp_psramc_init>:
200216c0:	b570      	push	{r4, r5, r6, lr}
200216c2:	b086      	sub	sp, #24
200216c4:	f000 f832 	bl	2002172c <BSP_GetFlash1DIV>
200216c8:	2100      	movs	r1, #0
200216ca:	2240      	movs	r2, #64	@ 0x40
200216cc:	4605      	mov	r5, r0
200216ce:	4815      	ldr	r0, [pc, #84]	@ (20021724 <bsp_psramc_init+0x64>)
200216d0:	f7ff ffee 	bl	200216b0 <flash_memset>
200216d4:	2214      	movs	r2, #20
200216d6:	a801      	add	r0, sp, #4
200216d8:	f7ff ffea 	bl	200216b0 <flash_memset>
200216dc:	4b12      	ldr	r3, [pc, #72]	@ (20021728 <bsp_psramc_init+0x68>)
200216de:	2001      	movs	r0, #1
200216e0:	9301      	str	r3, [sp, #4]
200216e2:	f005 fedb 	bl	2002749c <bsp_psram_get_mpi_mode>
200216e6:	2800      	cmp	r0, #0
200216e8:	bf08      	it	eq
200216ea:	2003      	moveq	r0, #3
200216ec:	f04f 5380 	mov.w	r3, #268435456	@ 0x10000000
200216f0:	2210      	movs	r2, #16
200216f2:	9005      	str	r0, [sp, #20]
200216f4:	e9cd 3203 	strd	r3, r2, [sp, #12]
200216f8:	f000 f87b 	bl	200217f2 <SystemPowerOnModeGet>
200216fc:	1e41      	subs	r1, r0, #1
200216fe:	4248      	negs	r0, r1
20021700:	4e08      	ldr	r6, [pc, #32]	@ (20021724 <bsp_psramc_init+0x64>)
20021702:	4148      	adcs	r0, r1
20021704:	f886 002f 	strb.w	r0, [r6, #47]	@ 0x2f
20021708:	f005 fee0 	bl	200274cc <bsp_psram1_pinmux_init>
2002170c:	4604      	mov	r4, r0
2002170e:	b100      	cbz	r0, 20021712 <bsp_psramc_init+0x52>
20021710:	e7fe      	b.n	20021710 <bsp_psramc_init+0x50>
20021712:	462a      	mov	r2, r5
20021714:	4630      	mov	r0, r6
20021716:	a901      	add	r1, sp, #4
20021718:	f002 fcbe 	bl	20024098 <HAL_MPI_PSRAM_Init>
2002171c:	4620      	mov	r0, r4
2002171e:	b006      	add	sp, #24
20021720:	bd70      	pop	{r4, r5, r6, pc}
20021722:	bf00      	nop
20021724:	2004c994 	.word	0x2004c994
20021728:	50041000 	.word	0x50041000

2002172c <BSP_GetFlash1DIV>:
2002172c:	4b01      	ldr	r3, [pc, #4]	@ (20021734 <BSP_GetFlash1DIV+0x8>)
2002172e:	8818      	ldrh	r0, [r3, #0]
20021730:	4770      	bx	lr
20021732:	bf00      	nop
20021734:	20042c12 	.word	0x20042c12

20021738 <BSP_GetFlash2DIV>:
20021738:	4b01      	ldr	r3, [pc, #4]	@ (20021740 <BSP_GetFlash2DIV+0x8>)
2002173a:	8818      	ldrh	r0, [r3, #0]
2002173c:	4770      	bx	lr
2002173e:	bf00      	nop
20021740:	20042c10 	.word	0x20042c10

20021744 <BSP_GetFlash3DIV>:
20021744:	4b01      	ldr	r3, [pc, #4]	@ (2002174c <BSP_GetFlash3DIV+0x8>)
20021746:	8818      	ldrh	r0, [r3, #0]
20021748:	4770      	bx	lr
2002174a:	bf00      	nop
2002174c:	20042c0e 	.word	0x20042c0e

20021750 <BSP_SetFlash1DIV>:
20021750:	4b01      	ldr	r3, [pc, #4]	@ (20021758 <BSP_SetFlash1DIV+0x8>)
20021752:	8018      	strh	r0, [r3, #0]
20021754:	4770      	bx	lr
20021756:	bf00      	nop
20021758:	20042c12 	.word	0x20042c12

2002175c <BSP_SetFlash2DIV>:
2002175c:	4b01      	ldr	r3, [pc, #4]	@ (20021764 <BSP_SetFlash2DIV+0x8>)
2002175e:	8018      	strh	r0, [r3, #0]
20021760:	4770      	bx	lr
20021762:	bf00      	nop
20021764:	20042c10 	.word	0x20042c10

20021768 <BSP_SetFlash3DIV>:
20021768:	4b01      	ldr	r3, [pc, #4]	@ (20021770 <BSP_SetFlash3DIV+0x8>)
2002176a:	8018      	strh	r0, [r3, #0]
2002176c:	4770      	bx	lr
2002176e:	bf00      	nop
20021770:	20042c0e 	.word	0x20042c0e

20021774 <pmu_ldo_inc>:
20021774:	2000      	movs	r0, #0
20021776:	4770      	bx	lr

20021778 <pmu_ldo_recover>:
20021778:	2000      	movs	r0, #0
2002177a:	4770      	bx	lr

2002177c <hw_preinit0>:
2002177c:	4770      	bx	lr
	...

20021780 <cache_disable>:
20021780:	b570      	push	{r4, r5, r6, lr}
20021782:	f3bf 8f4f 	dsb	sy
20021786:	f3bf 8f6f 	isb	sy
2002178a:	4a18      	ldr	r2, [pc, #96]	@ (200217ec <cache_disable+0x6c>)
2002178c:	6953      	ldr	r3, [r2, #20]
2002178e:	f423 3300 	bic.w	r3, r3, #131072	@ 0x20000
20021792:	6153      	str	r3, [r2, #20]
20021794:	2300      	movs	r3, #0
20021796:	f8c2 3250 	str.w	r3, [r2, #592]	@ 0x250
2002179a:	f3bf 8f4f 	dsb	sy
2002179e:	f3bf 8f6f 	isb	sy
200217a2:	f8c2 3084 	str.w	r3, [r2, #132]	@ 0x84
200217a6:	f3bf 8f4f 	dsb	sy
200217aa:	6953      	ldr	r3, [r2, #20]
200217ac:	f423 3380 	bic.w	r3, r3, #65536	@ 0x10000
200217b0:	6153      	str	r3, [r2, #20]
200217b2:	f3bf 8f4f 	dsb	sy
200217b6:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
200217ba:	f8d2 3080 	ldr.w	r3, [r2, #128]	@ 0x80
200217be:	f3c3 00c9 	ubfx	r0, r3, #3, #10
200217c2:	f3c3 334e 	ubfx	r3, r3, #13, #15
200217c6:	015b      	lsls	r3, r3, #5
200217c8:	4601      	mov	r1, r0
200217ca:	ea03 0604 	and.w	r6, r3, r4
200217ce:	ea46 7581 	orr.w	r5, r6, r1, lsl #30
200217d2:	3901      	subs	r1, #1
200217d4:	f8c2 5274 	str.w	r5, [r2, #628]	@ 0x274
200217d8:	d2f9      	bcs.n	200217ce <cache_disable+0x4e>
200217da:	3b20      	subs	r3, #32
200217dc:	f113 0f20 	cmn.w	r3, #32
200217e0:	d1f2      	bne.n	200217c8 <cache_disable+0x48>
200217e2:	f3bf 8f4f 	dsb	sy
200217e6:	f3bf 8f6f 	isb	sy
200217ea:	bd70      	pop	{r4, r5, r6, pc}
200217ec:	e000ed00 	.word	0xe000ed00

200217f0 <SystemPowerOnModeInit>:
200217f0:	4770      	bx	lr

200217f2 <SystemPowerOnModeGet>:
200217f2:	2000      	movs	r0, #0
200217f4:	4770      	bx	lr
	...

200217f8 <SystemInit>:
200217f8:	b508      	push	{r3, lr}
200217fa:	4a0e      	ldr	r2, [pc, #56]	@ (20021834 <SystemInit+0x3c>)
200217fc:	4b0e      	ldr	r3, [pc, #56]	@ (20021838 <SystemInit+0x40>)
200217fe:	609a      	str	r2, [r3, #8]
20021800:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021804:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021808:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
2002180c:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021810:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
20021814:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021818:	f7ff ffb0 	bl	2002177c <hw_preinit0>
2002181c:	f7ff ffb0 	bl	20021780 <cache_disable>
20021820:	f7fe fd44 	bl	200202ac <mpu_config>
20021824:	f7fe fd43 	bl	200202ae <cache_enable>
20021828:	f7ff ffe2 	bl	200217f0 <SystemPowerOnModeInit>
2002182c:	4b03      	ldr	r3, [pc, #12]	@ (2002183c <SystemInit+0x44>)
2002182e:	4a04      	ldr	r2, [pc, #16]	@ (20021840 <SystemInit+0x48>)
20021830:	601a      	str	r2, [r3, #0]
20021832:	bd08      	pop	{r3, pc}
20021834:	20020000 	.word	0x20020000
20021838:	e000ed00 	.word	0xe000ed00
2002183c:	20042c14 	.word	0x20042c14
20021840:	017d7840 	.word	0x017d7840

20021844 <Reset_Handler>:
20021844:	f8df d048 	ldr.w	sp, [pc, #72]	@ 20021890 <ACPU2HCPU_IRQHandler+0x2>
20021848:	4812      	ldr	r0, [pc, #72]	@ (20021894 <ACPU2HCPU_IRQHandler+0x6>)
2002184a:	f380 880a 	msr	MSPLIM, r0
2002184e:	f7ff ffd3 	bl	200217f8 <SystemInit>
20021852:	4c11      	ldr	r4, [pc, #68]	@ (20021898 <ACPU2HCPU_IRQHandler+0xa>)
20021854:	4d11      	ldr	r5, [pc, #68]	@ (2002189c <ACPU2HCPU_IRQHandler+0xe>)
20021856:	42ac      	cmp	r4, r5
20021858:	da09      	bge.n	2002186e <Reset_Handler+0x2a>
2002185a:	6821      	ldr	r1, [r4, #0]
2002185c:	6862      	ldr	r2, [r4, #4]
2002185e:	68a3      	ldr	r3, [r4, #8]
20021860:	3b04      	subs	r3, #4
20021862:	bfa2      	ittt	ge
20021864:	58c8      	ldrge	r0, [r1, r3]
20021866:	50d0      	strge	r0, [r2, r3]
20021868:	e7fa      	bge.n	20021860 <Reset_Handler+0x1c>
2002186a:	340c      	adds	r4, #12
2002186c:	e7f3      	b.n	20021856 <Reset_Handler+0x12>
2002186e:	4b0c      	ldr	r3, [pc, #48]	@ (200218a0 <ACPU2HCPU_IRQHandler+0x12>)
20021870:	4c0c      	ldr	r4, [pc, #48]	@ (200218a4 <ACPU2HCPU_IRQHandler+0x16>)
20021872:	42a3      	cmp	r3, r4
20021874:	da08      	bge.n	20021888 <Reset_Handler+0x44>
20021876:	6819      	ldr	r1, [r3, #0]
20021878:	685a      	ldr	r2, [r3, #4]
2002187a:	2000      	movs	r0, #0
2002187c:	3a04      	subs	r2, #4
2002187e:	bfa4      	itt	ge
20021880:	5088      	strge	r0, [r1, r2]
20021882:	e7fb      	bge.n	2002187c <Reset_Handler+0x38>
20021884:	3308      	adds	r3, #8
20021886:	e7f4      	b.n	20021872 <Reset_Handler+0x2e>
20021888:	f7ff faf6 	bl	20020e78 <entry>

2002188c <HardFault_Handler>:
2002188c:	e7fe      	b.n	2002188c <HardFault_Handler>

2002188e <ACPU2HCPU_IRQHandler>:
2002188e:	e7fe      	b.n	2002188e <ACPU2HCPU_IRQHandler>
20021890:	20042000 	.word	0x20042000
20021894:	20040000 	.word	0x20040000
20021898:	2002790c 	.word	0x2002790c
2002189c:	20027918 	.word	0x20027918
200218a0:	20027918 	.word	0x20027918
200218a4:	20027920 	.word	0x20027920

200218a8 <__aeabi_unwind_cpp_pr0>:
200218a8:	2000      	movs	r0, #0
200218aa:	4770      	bx	lr

200218ac <HAL_GetTick>:
200218ac:	4b01      	ldr	r3, [pc, #4]	@ (200218b4 <HAL_GetTick+0x8>)
200218ae:	6818      	ldr	r0, [r3, #0]
200218b0:	4770      	bx	lr
200218b2:	bf00      	nop
200218b4:	2004c9d8 	.word	0x2004c9d8

200218b8 <HAL_Delay_us_>:
200218b8:	b538      	push	{r3, r4, r5, lr}
200218ba:	4604      	mov	r4, r0
200218bc:	4d16      	ldr	r5, [pc, #88]	@ (20021918 <HAL_Delay_us_+0x60>)
200218be:	b128      	cbz	r0, 200218cc <HAL_Delay_us_+0x14>
200218c0:	682b      	ldr	r3, [r5, #0]
200218c2:	b11b      	cbz	r3, 200218cc <HAL_Delay_us_+0x14>
200218c4:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
200218c8:	d90a      	bls.n	200218e0 <HAL_Delay_us_+0x28>
200218ca:	e7fe      	b.n	200218ca <HAL_Delay_us_+0x12>
200218cc:	2000      	movs	r0, #0
200218ce:	f002 fdf1 	bl	200244b4 <HAL_RCC_GetHCLKFreq>
200218d2:	4b12      	ldr	r3, [pc, #72]	@ (2002191c <HAL_Delay_us_+0x64>)
200218d4:	fbb0 f0f3 	udiv	r0, r0, r3
200218d8:	6028      	str	r0, [r5, #0]
200218da:	2c00      	cmp	r4, #0
200218dc:	d1f2      	bne.n	200218c4 <HAL_Delay_us_+0xc>
200218de:	bd38      	pop	{r3, r4, r5, pc}
200218e0:	4a0f      	ldr	r2, [pc, #60]	@ (20021920 <HAL_Delay_us_+0x68>)
200218e2:	6813      	ldr	r3, [r2, #0]
200218e4:	f013 0301 	ands.w	r3, r3, #1
200218e8:	d10d      	bne.n	20021906 <HAL_Delay_us_+0x4e>
200218ea:	480e      	ldr	r0, [pc, #56]	@ (20021924 <HAL_Delay_us_+0x6c>)
200218ec:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
200218f0:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
200218f4:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
200218f8:	6053      	str	r3, [r2, #4]
200218fa:	6813      	ldr	r3, [r2, #0]
200218fc:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
20021900:	f043 0301 	orr.w	r3, r3, #1
20021904:	6013      	str	r3, [r2, #0]
20021906:	682b      	ldr	r3, [r5, #0]
20021908:	4a05      	ldr	r2, [pc, #20]	@ (20021920 <HAL_Delay_us_+0x68>)
2002190a:	435c      	muls	r4, r3
2002190c:	6851      	ldr	r1, [r2, #4]
2002190e:	6853      	ldr	r3, [r2, #4]
20021910:	1a5b      	subs	r3, r3, r1
20021912:	429c      	cmp	r4, r3
20021914:	d8fb      	bhi.n	2002190e <HAL_Delay_us_+0x56>
20021916:	e7e2      	b.n	200218de <HAL_Delay_us_+0x26>
20021918:	2004c9d4 	.word	0x2004c9d4
2002191c:	000f4240 	.word	0x000f4240
20021920:	e0001000 	.word	0xe0001000
20021924:	e000ed00 	.word	0xe000ed00

20021928 <HAL_Delay_us2_>:
20021928:	b537      	push	{r0, r1, r2, r4, r5, lr}
2002192a:	9001      	str	r0, [sp, #4]
2002192c:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
20021930:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20021934:	6944      	ldr	r4, [r0, #20]
20021936:	9b01      	ldr	r3, [sp, #4]
20021938:	4363      	muls	r3, r4
2002193a:	fbb3 f3f2 	udiv	r3, r3, r2
2002193e:	9301      	str	r3, [sp, #4]
20021940:	2300      	movs	r3, #0
20021942:	6981      	ldr	r1, [r0, #24]
20021944:	6982      	ldr	r2, [r0, #24]
20021946:	428a      	cmp	r2, r1
20021948:	d0fc      	beq.n	20021944 <HAL_Delay_us2_+0x1c>
2002194a:	bf25      	ittet	cs
2002194c:	1aa5      	subcs	r5, r4, r2
2002194e:	195b      	addcs	r3, r3, r5
20021950:	185b      	addcc	r3, r3, r1
20021952:	185b      	addcs	r3, r3, r1
20021954:	9901      	ldr	r1, [sp, #4]
20021956:	bf38      	it	cc
20021958:	1a9b      	subcc	r3, r3, r2
2002195a:	4299      	cmp	r1, r3
2002195c:	d801      	bhi.n	20021962 <HAL_Delay_us2_+0x3a>
2002195e:	b003      	add	sp, #12
20021960:	bd30      	pop	{r4, r5, pc}
20021962:	4611      	mov	r1, r2
20021964:	e7ee      	b.n	20021944 <HAL_Delay_us2_+0x1c>

20021966 <HAL_Delay_us>:
20021966:	4603      	mov	r3, r0
20021968:	b570      	push	{r4, r5, r6, lr}
2002196a:	b1b8      	cbz	r0, 2002199c <HAL_Delay_us+0x36>
2002196c:	f242 7510 	movw	r5, #10000	@ 0x2710
20021970:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
20021974:	42ab      	cmp	r3, r5
20021976:	bf84      	itt	hi
20021978:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
2002197c:	f242 7310 	movwhi	r3, #10000	@ 0x2710
20021980:	6932      	ldr	r2, [r6, #16]
20021982:	bf98      	it	ls
20021984:	2400      	movls	r4, #0
20021986:	4618      	mov	r0, r3
20021988:	bf88      	it	hi
2002198a:	3c10      	subhi	r4, #16
2002198c:	07d3      	lsls	r3, r2, #31
2002198e:	d508      	bpl.n	200219a2 <HAL_Delay_us+0x3c>
20021990:	f7ff ffca 	bl	20021928 <HAL_Delay_us2_>
20021994:	4623      	mov	r3, r4
20021996:	2c00      	cmp	r4, #0
20021998:	d1ec      	bne.n	20021974 <HAL_Delay_us+0xe>
2002199a:	e001      	b.n	200219a0 <HAL_Delay_us+0x3a>
2002199c:	f7ff ff8c 	bl	200218b8 <HAL_Delay_us_>
200219a0:	bd70      	pop	{r4, r5, r6, pc}
200219a2:	f7ff ff89 	bl	200218b8 <HAL_Delay_us_>
200219a6:	e7f5      	b.n	20021994 <HAL_Delay_us+0x2e>

200219a8 <WDT_IRQHandler>:
200219a8:	4770      	bx	lr

200219aa <DBG_Trigger_IRQHandler>:
200219aa:	4770      	bx	lr

200219ac <NMI_Handler>:
200219ac:	b508      	push	{r3, lr}
200219ae:	4b05      	ldr	r3, [pc, #20]	@ (200219c4 <NMI_Handler+0x18>)
200219b0:	6a1b      	ldr	r3, [r3, #32]
200219b2:	005b      	lsls	r3, r3, #1
200219b4:	d502      	bpl.n	200219bc <NMI_Handler+0x10>
200219b6:	f7ff fff8 	bl	200219aa <DBG_Trigger_IRQHandler>
200219ba:	bd08      	pop	{r3, pc}
200219bc:	f7ff fff4 	bl	200219a8 <WDT_IRQHandler>
200219c0:	e7fb      	b.n	200219ba <NMI_Handler+0xe>
200219c2:	bf00      	nop
200219c4:	5000b000 	.word	0x5000b000

200219c8 <HAL_AES_run_help>:
200219c8:	b510      	push	{r4, lr}
200219ca:	f101 4470 	add.w	r4, r1, #4026531840	@ 0xf0000000
200219ce:	f1b4 5f80 	cmp.w	r4, #268435456	@ 0x10000000
200219d2:	4c0e      	ldr	r4, [pc, #56]	@ (20021a0c <HAL_AES_run_help+0x44>)
200219d4:	bf38      	it	cc
200219d6:	f101 41a0 	addcc.w	r1, r1, #1342177280	@ 0x50000000
200219da:	6161      	str	r1, [r4, #20]
200219dc:	f102 4170 	add.w	r1, r2, #4026531840	@ 0xf0000000
200219e0:	f1b1 5f80 	cmp.w	r1, #268435456	@ 0x10000000
200219e4:	f103 030f 	add.w	r3, r3, #15
200219e8:	ea4f 1323 	mov.w	r3, r3, asr #4
200219ec:	bf38      	it	cc
200219ee:	f102 42a0 	addcc.w	r2, r2, #1342177280	@ 0x50000000
200219f2:	61a2      	str	r2, [r4, #24]
200219f4:	61e3      	str	r3, [r4, #28]
200219f6:	6923      	ldr	r3, [r4, #16]
200219f8:	b108      	cbz	r0, 200219fe <HAL_AES_run_help+0x36>
200219fa:	ea43 13c0 	orr.w	r3, r3, r0, lsl #7
200219fe:	4a03      	ldr	r2, [pc, #12]	@ (20021a0c <HAL_AES_run_help+0x44>)
20021a00:	6123      	str	r3, [r4, #16]
20021a02:	6813      	ldr	r3, [r2, #0]
20021a04:	f043 0301 	orr.w	r3, r3, #1
20021a08:	6013      	str	r3, [r2, #0]
20021a0a:	bd10      	pop	{r4, pc}
20021a0c:	5000d000 	.word	0x5000d000

20021a10 <HAL_AES_reset>:
20021a10:	2202      	movs	r2, #2
20021a12:	2000      	movs	r0, #0
20021a14:	4b01      	ldr	r3, [pc, #4]	@ (20021a1c <HAL_AES_reset+0xc>)
20021a16:	601a      	str	r2, [r3, #0]
20021a18:	6018      	str	r0, [r3, #0]
20021a1a:	4770      	bx	lr
20021a1c:	5000d000 	.word	0x5000d000

20021a20 <HAL_AES_init>:
20021a20:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021a22:	4604      	mov	r4, r0
20021a24:	200c      	movs	r0, #12
20021a26:	461e      	mov	r6, r3
20021a28:	460d      	mov	r5, r1
20021a2a:	4617      	mov	r7, r2
20021a2c:	f002 fe96 	bl	2002475c <HAL_RCC_EnableModule>
20021a30:	4b1c      	ldr	r3, [pc, #112]	@ (20021aa4 <HAL_AES_init+0x84>)
20021a32:	685b      	ldr	r3, [r3, #4]
20021a34:	07db      	lsls	r3, r3, #31
20021a36:	d501      	bpl.n	20021a3c <HAL_AES_init+0x1c>
20021a38:	f7ff ffea 	bl	20021a10 <HAL_AES_reset>
20021a3c:	fab4 f184 	clz	r1, r4
20021a40:	2d18      	cmp	r5, #24
20021a42:	ea4f 1151 	mov.w	r1, r1, lsr #5
20021a46:	ea4f 1141 	mov.w	r1, r1, lsl #5
20021a4a:	d01b      	beq.n	20021a84 <HAL_AES_init+0x64>
20021a4c:	2d20      	cmp	r5, #32
20021a4e:	d01b      	beq.n	20021a88 <HAL_AES_init+0x68>
20021a50:	2d10      	cmp	r5, #16
20021a52:	d124      	bne.n	20021a9e <HAL_AES_init+0x7e>
20021a54:	2300      	movs	r3, #0
20021a56:	b164      	cbz	r4, 20021a72 <HAL_AES_init+0x52>
20021a58:	4620      	mov	r0, r4
20021a5a:	4a13      	ldr	r2, [pc, #76]	@ (20021aa8 <HAL_AES_init+0x88>)
20021a5c:	f025 0503 	bic.w	r5, r5, #3
20021a60:	4425      	add	r5, r4
20021a62:	1b12      	subs	r2, r2, r4
20021a64:	1814      	adds	r4, r2, r0
20021a66:	f850 cb04 	ldr.w	ip, [r0], #4
20021a6a:	4285      	cmp	r5, r0
20021a6c:	f8c4 c000 	str.w	ip, [r4]
20021a70:	d1f8      	bne.n	20021a64 <HAL_AES_init+0x44>
20021a72:	4331      	orrs	r1, r6
20021a74:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
20021a78:	4b0a      	ldr	r3, [pc, #40]	@ (20021aa4 <HAL_AES_init+0x84>)
20021a7a:	6119      	str	r1, [r3, #16]
20021a7c:	b106      	cbz	r6, 20021a80 <HAL_AES_init+0x60>
20021a7e:	b92f      	cbnz	r7, 20021a8c <HAL_AES_init+0x6c>
20021a80:	2000      	movs	r0, #0
20021a82:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021a84:	2301      	movs	r3, #1
20021a86:	e7e6      	b.n	20021a56 <HAL_AES_init+0x36>
20021a88:	2302      	movs	r3, #2
20021a8a:	e7e4      	b.n	20021a56 <HAL_AES_init+0x36>
20021a8c:	683a      	ldr	r2, [r7, #0]
20021a8e:	621a      	str	r2, [r3, #32]
20021a90:	687a      	ldr	r2, [r7, #4]
20021a92:	625a      	str	r2, [r3, #36]	@ 0x24
20021a94:	68ba      	ldr	r2, [r7, #8]
20021a96:	629a      	str	r2, [r3, #40]	@ 0x28
20021a98:	68fa      	ldr	r2, [r7, #12]
20021a9a:	62da      	str	r2, [r3, #44]	@ 0x2c
20021a9c:	e7f0      	b.n	20021a80 <HAL_AES_init+0x60>
20021a9e:	f04f 30ff 	mov.w	r0, #4294967295
20021aa2:	e7ee      	b.n	20021a82 <HAL_AES_init+0x62>
20021aa4:	5000d000 	.word	0x5000d000
20021aa8:	5000d030 	.word	0x5000d030

20021aac <HAL_AES_run>:
20021aac:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021aae:	2708      	movs	r7, #8
20021ab0:	4e17      	ldr	r6, [pc, #92]	@ (20021b10 <HAL_AES_run+0x64>)
20021ab2:	4614      	mov	r4, r2
20021ab4:	461d      	mov	r5, r3
20021ab6:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
20021aba:	f3bf 8f4f 	dsb	sy
20021abe:	f3bf 8f6f 	isb	sy
20021ac2:	2700      	movs	r7, #0
20021ac4:	4e13      	ldr	r6, [pc, #76]	@ (20021b14 <HAL_AES_run+0x68>)
20021ac6:	60f7      	str	r7, [r6, #12]
20021ac8:	f7ff ff7e 	bl	200219c8 <HAL_AES_run_help>
20021acc:	6873      	ldr	r3, [r6, #4]
20021ace:	07db      	lsls	r3, r3, #31
20021ad0:	d4fc      	bmi.n	20021acc <HAL_AES_run+0x20>
20021ad2:	68b0      	ldr	r0, [r6, #8]
20021ad4:	f000 0006 	and.w	r0, r0, #6
20021ad8:	3800      	subs	r0, #0
20021ada:	bf18      	it	ne
20021adc:	2001      	movne	r0, #1
20021ade:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
20021ae2:	d314      	bcc.n	20021b0e <HAL_AES_run+0x62>
20021ae4:	2d00      	cmp	r5, #0
20021ae6:	dd12      	ble.n	20021b0e <HAL_AES_run+0x62>
20021ae8:	f004 031f 	and.w	r3, r4, #31
20021aec:	442b      	add	r3, r5
20021aee:	f024 021f 	bic.w	r2, r4, #31
20021af2:	f3bf 8f4f 	dsb	sy
20021af6:	4c08      	ldr	r4, [pc, #32]	@ (20021b18 <HAL_AES_run+0x6c>)
20021af8:	4413      	add	r3, r2
20021afa:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
20021afe:	3220      	adds	r2, #32
20021b00:	1a99      	subs	r1, r3, r2
20021b02:	2900      	cmp	r1, #0
20021b04:	dcf9      	bgt.n	20021afa <HAL_AES_run+0x4e>
20021b06:	f3bf 8f4f 	dsb	sy
20021b0a:	f3bf 8f6f 	isb	sy
20021b0e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021b10:	e000e100 	.word	0xe000e100
20021b14:	5000d000 	.word	0x5000d000
20021b18:	e000ed00 	.word	0xe000ed00

20021b1c <HAL_NVIC_EnableIRQ>:
20021b1c:	2800      	cmp	r0, #0
20021b1e:	da00      	bge.n	20021b22 <HAL_NVIC_EnableIRQ+0x6>
20021b20:	e7fe      	b.n	20021b20 <HAL_NVIC_EnableIRQ+0x4>
20021b22:	2301      	movs	r3, #1
20021b24:	0941      	lsrs	r1, r0, #5
20021b26:	4a03      	ldr	r2, [pc, #12]	@ (20021b34 <HAL_NVIC_EnableIRQ+0x18>)
20021b28:	f000 001f 	and.w	r0, r0, #31
20021b2c:	4083      	lsls	r3, r0
20021b2e:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20021b32:	4770      	bx	lr
20021b34:	e000e100 	.word	0xe000e100

20021b38 <HAL_NVIC_DisableIRQ>:
20021b38:	2800      	cmp	r0, #0
20021b3a:	da00      	bge.n	20021b3e <HAL_NVIC_DisableIRQ+0x6>
20021b3c:	e7fe      	b.n	20021b3c <HAL_NVIC_DisableIRQ+0x4>
20021b3e:	2201      	movs	r2, #1
20021b40:	4906      	ldr	r1, [pc, #24]	@ (20021b5c <HAL_NVIC_DisableIRQ+0x24>)
20021b42:	0943      	lsrs	r3, r0, #5
20021b44:	f000 001f 	and.w	r0, r0, #31
20021b48:	4082      	lsls	r2, r0
20021b4a:	3320      	adds	r3, #32
20021b4c:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20021b50:	f3bf 8f4f 	dsb	sy
20021b54:	f3bf 8f6f 	isb	sy
20021b58:	4770      	bx	lr
20021b5a:	bf00      	nop
20021b5c:	e000e100 	.word	0xe000e100

20021b60 <DMA_IsChannelOwner>:
20021b60:	b510      	push	{r4, lr}
20021b62:	4911      	ldr	r1, [pc, #68]	@ (20021ba8 <DMA_IsChannelOwner+0x48>)
20021b64:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021b66:	4602      	mov	r2, r0
20021b68:	428b      	cmp	r3, r1
20021b6a:	d003      	beq.n	20021b74 <DMA_IsChannelOwner+0x14>
20021b6c:	490f      	ldr	r1, [pc, #60]	@ (20021bac <DMA_IsChannelOwner+0x4c>)
20021b6e:	428b      	cmp	r3, r1
20021b70:	d007      	beq.n	20021b82 <DMA_IsChannelOwner+0x22>
20021b72:	e7fe      	b.n	20021b72 <DMA_IsChannelOwner+0x12>
20021b74:	4b0e      	ldr	r3, [pc, #56]	@ (20021bb0 <DMA_IsChannelOwner+0x50>)
20021b76:	6d10      	ldr	r0, [r2, #80]	@ 0x50
20021b78:	281f      	cmp	r0, #31
20021b7a:	ea4f 0190 	mov.w	r1, r0, lsr #2
20021b7e:	d902      	bls.n	20021b86 <DMA_IsChannelOwner+0x26>
20021b80:	e7fe      	b.n	20021b80 <DMA_IsChannelOwner+0x20>
20021b82:	4b0c      	ldr	r3, [pc, #48]	@ (20021bb4 <DMA_IsChannelOwner+0x54>)
20021b84:	e7f7      	b.n	20021b76 <DMA_IsChannelOwner+0x16>
20021b86:	f3ef 8410 	mrs	r4, PRIMASK
20021b8a:	2001      	movs	r0, #1
20021b8c:	f380 8810 	msr	PRIMASK, r0
20021b90:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
20021b94:	7900      	ldrb	r0, [r0, #4]
20021b96:	b120      	cbz	r0, 20021ba2 <DMA_IsChannelOwner+0x42>
20021b98:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
20021b9c:	1a83      	subs	r3, r0, r2
20021b9e:	4258      	negs	r0, r3
20021ba0:	4158      	adcs	r0, r3
20021ba2:	f384 8810 	msr	PRIMASK, r4
20021ba6:	bd10      	pop	{r4, pc}
20021ba8:	50081000 	.word	0x50081000
20021bac:	40001000 	.word	0x40001000
20021bb0:	2004ca1c 	.word	0x2004ca1c
20021bb4:	2004c9dc 	.word	0x2004c9dc

20021bb8 <DMA_FreeChannel.isra.0>:
20021bb8:	b538      	push	{r3, r4, r5, lr}
20021bba:	4a13      	ldr	r2, [pc, #76]	@ (20021c08 <DMA_FreeChannel.isra.0+0x50>)
20021bbc:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021bbe:	4293      	cmp	r3, r2
20021bc0:	d003      	beq.n	20021bca <DMA_FreeChannel.isra.0+0x12>
20021bc2:	4a12      	ldr	r2, [pc, #72]	@ (20021c0c <DMA_FreeChannel.isra.0+0x54>)
20021bc4:	4293      	cmp	r3, r2
20021bc6:	d008      	beq.n	20021bda <DMA_FreeChannel.isra.0+0x22>
20021bc8:	e7fe      	b.n	20021bc8 <DMA_FreeChannel.isra.0+0x10>
20021bca:	2132      	movs	r1, #50	@ 0x32
20021bcc:	4a10      	ldr	r2, [pc, #64]	@ (20021c10 <DMA_FreeChannel.isra.0+0x58>)
20021bce:	6d04      	ldr	r4, [r0, #80]	@ 0x50
20021bd0:	2c1f      	cmp	r4, #31
20021bd2:	ea4f 0394 	mov.w	r3, r4, lsr #2
20021bd6:	d903      	bls.n	20021be0 <DMA_FreeChannel.isra.0+0x28>
20021bd8:	e7fe      	b.n	20021bd8 <DMA_FreeChannel.isra.0+0x20>
20021bda:	2102      	movs	r1, #2
20021bdc:	4a0d      	ldr	r2, [pc, #52]	@ (20021c14 <DMA_FreeChannel.isra.0+0x5c>)
20021bde:	e7f6      	b.n	20021bce <DMA_FreeChannel.isra.0+0x16>
20021be0:	f3ef 8410 	mrs	r4, PRIMASK
20021be4:	2501      	movs	r5, #1
20021be6:	f385 8810 	msr	PRIMASK, r5
20021bea:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
20021bee:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
20021bf2:	4290      	cmp	r0, r2
20021bf4:	d105      	bne.n	20021c02 <DMA_FreeChannel.isra.0+0x4a>
20021bf6:	1858      	adds	r0, r3, r1
20021bf8:	b240      	sxtb	r0, r0
20021bfa:	f7ff ff9d 	bl	20021b38 <HAL_NVIC_DisableIRQ>
20021bfe:	2300      	movs	r3, #0
20021c00:	712b      	strb	r3, [r5, #4]
20021c02:	f384 8810 	msr	PRIMASK, r4
20021c06:	bd38      	pop	{r3, r4, r5, pc}
20021c08:	50081000 	.word	0x50081000
20021c0c:	40001000 	.word	0x40001000
20021c10:	2004ca1c 	.word	0x2004ca1c
20021c14:	2004c9dc 	.word	0x2004c9dc

20021c18 <DMA_SetBurstSizeAndFix.part.0>:
20021c18:	6843      	ldr	r3, [r0, #4]
20021c1a:	2b10      	cmp	r3, #16
20021c1c:	d113      	bne.n	20021c46 <DMA_SetBurstSizeAndFix.part.0+0x2e>
20021c1e:	8c02      	ldrh	r2, [r0, #32]
20021c20:	b11a      	cbz	r2, 20021c2a <DMA_SetBurstSizeAndFix.part.0+0x12>
20021c22:	680b      	ldr	r3, [r1, #0]
20021c24:	f043 5380 	orr.w	r3, r3, #268435456	@ 0x10000000
20021c28:	600b      	str	r3, [r1, #0]
20021c2a:	680b      	ldr	r3, [r1, #0]
20021c2c:	f362 6319 	bfi	r3, r2, #24, #2
20021c30:	600b      	str	r3, [r1, #0]
20021c32:	6842      	ldr	r2, [r0, #4]
20021c34:	b94a      	cbnz	r2, 20021c4a <DMA_SetBurstSizeAndFix.part.0+0x32>
20021c36:	8c02      	ldrh	r2, [r0, #32]
20021c38:	b10a      	cbz	r2, 20021c3e <DMA_SetBurstSizeAndFix.part.0+0x26>
20021c3a:	f043 5300 	orr.w	r3, r3, #536870912	@ 0x20000000
20021c3e:	f362 639b 	bfi	r3, r2, #26, #2
20021c42:	600b      	str	r3, [r1, #0]
20021c44:	4770      	bx	lr
20021c46:	2203      	movs	r2, #3
20021c48:	e7ef      	b.n	20021c2a <DMA_SetBurstSizeAndFix.part.0+0x12>
20021c4a:	2203      	movs	r2, #3
20021c4c:	e7f7      	b.n	20021c3e <DMA_SetBurstSizeAndFix.part.0+0x26>

20021c4e <DMA_Init>:
20021c4e:	2302      	movs	r3, #2
20021c50:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021c52:	f880 3031 	strb.w	r3, [r0, #49]	@ 0x31
20021c56:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021c5a:	4604      	mov	r4, r0
20021c5c:	2b00      	cmp	r3, #0
20021c5e:	bfa2      	ittt	ge
20021c60:	6803      	ldrge	r3, [r0, #0]
20021c62:	6a42      	ldrge	r2, [r0, #36]	@ 0x24
20021c64:	611a      	strge	r2, [r3, #16]
20021c66:	e9d0 3102 	ldrd	r3, r1, [r0, #8]
20021c6a:	430b      	orrs	r3, r1
20021c6c:	6901      	ldr	r1, [r0, #16]
20021c6e:	6805      	ldr	r5, [r0, #0]
20021c70:	430b      	orrs	r3, r1
20021c72:	6941      	ldr	r1, [r0, #20]
20021c74:	682a      	ldr	r2, [r5, #0]
20021c76:	430b      	orrs	r3, r1
20021c78:	6981      	ldr	r1, [r0, #24]
20021c7a:	f36f 120e 	bfc	r2, #4, #11
20021c7e:	430b      	orrs	r3, r1
20021c80:	69c1      	ldr	r1, [r0, #28]
20021c82:	430b      	orrs	r3, r1
20021c84:	6a01      	ldr	r1, [r0, #32]
20021c86:	430b      	orrs	r3, r1
20021c88:	4313      	orrs	r3, r2
20021c8a:	9301      	str	r3, [sp, #4]
20021c8c:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021c90:	2b00      	cmp	r3, #0
20021c92:	da08      	bge.n	20021ca6 <DMA_Init+0x58>
20021c94:	6d43      	ldr	r3, [r0, #84]	@ 0x54
20021c96:	f3c3 031e 	ubfx	r3, r3, #0, #31
20021c9a:	2b01      	cmp	r3, #1
20021c9c:	d803      	bhi.n	20021ca6 <DMA_Init+0x58>
20021c9e:	a901      	add	r1, sp, #4
20021ca0:	3004      	adds	r0, #4
20021ca2:	f7ff ffb9 	bl	20021c18 <DMA_SetBurstSizeAndFix.part.0>
20021ca6:	9b01      	ldr	r3, [sp, #4]
20021ca8:	602b      	str	r3, [r5, #0]
20021caa:	68a3      	ldr	r3, [r4, #8]
20021cac:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021cb0:	d01f      	beq.n	20021cf2 <DMA_Init+0xa4>
20021cb2:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021cb4:	f3c3 0387 	ubfx	r3, r3, #2, #8
20021cb8:	f3ef 8110 	mrs	r1, PRIMASK
20021cbc:	2201      	movs	r2, #1
20021cbe:	f382 8810 	msr	PRIMASK, r2
20021cc2:	0758      	lsls	r0, r3, #29
20021cc4:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
20021cc6:	d41d      	bmi.n	20021d04 <DMA_Init+0xb6>
20021cc8:	253f      	movs	r5, #63	@ 0x3f
20021cca:	f003 0307 	and.w	r3, r3, #7
20021cce:	f8d2 00a8 	ldr.w	r0, [r2, #168]	@ 0xa8
20021cd2:	00db      	lsls	r3, r3, #3
20021cd4:	409d      	lsls	r5, r3
20021cd6:	ea20 0005 	bic.w	r0, r0, r5
20021cda:	f8c2 00a8 	str.w	r0, [r2, #168]	@ 0xa8
20021cde:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021ce0:	6862      	ldr	r2, [r4, #4]
20021ce2:	f8d0 50a8 	ldr.w	r5, [r0, #168]	@ 0xa8
20021ce6:	409a      	lsls	r2, r3
20021ce8:	432a      	orrs	r2, r5
20021cea:	f8c0 20a8 	str.w	r2, [r0, #168]	@ 0xa8
20021cee:	f381 8810 	msr	PRIMASK, r1
20021cf2:	69a2      	ldr	r2, [r4, #24]
20021cf4:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
20021cf8:	d018      	beq.n	20021d2c <DMA_Init+0xde>
20021cfa:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
20021cfe:	d01f      	beq.n	20021d40 <DMA_Init+0xf2>
20021d00:	b1aa      	cbz	r2, 20021d2e <DMA_Init+0xe0>
20021d02:	e7fe      	b.n	20021d02 <DMA_Init+0xb4>
20021d04:	253f      	movs	r5, #63	@ 0x3f
20021d06:	f003 0303 	and.w	r3, r3, #3
20021d0a:	f8d2 00ac 	ldr.w	r0, [r2, #172]	@ 0xac
20021d0e:	00db      	lsls	r3, r3, #3
20021d10:	409d      	lsls	r5, r3
20021d12:	ea20 0005 	bic.w	r0, r0, r5
20021d16:	f8c2 00ac 	str.w	r0, [r2, #172]	@ 0xac
20021d1a:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021d1c:	6862      	ldr	r2, [r4, #4]
20021d1e:	f8d0 50ac 	ldr.w	r5, [r0, #172]	@ 0xac
20021d22:	409a      	lsls	r2, r3
20021d24:	432a      	orrs	r2, r5
20021d26:	f8c0 20ac 	str.w	r2, [r0, #172]	@ 0xac
20021d2a:	e7e0      	b.n	20021cee <DMA_Init+0xa0>
20021d2c:	2201      	movs	r2, #1
20021d2e:	6963      	ldr	r3, [r4, #20]
20021d30:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20021d34:	d006      	beq.n	20021d44 <DMA_Init+0xf6>
20021d36:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021d3a:	d02c      	beq.n	20021d96 <DMA_Init+0x148>
20021d3c:	b11b      	cbz	r3, 20021d46 <DMA_Init+0xf8>
20021d3e:	e7fe      	b.n	20021d3e <DMA_Init+0xf0>
20021d40:	2202      	movs	r2, #2
20021d42:	e7f4      	b.n	20021d2e <DMA_Init+0xe0>
20021d44:	2301      	movs	r3, #1
20021d46:	6921      	ldr	r1, [r4, #16]
20021d48:	f1a1 0080 	sub.w	r0, r1, #128	@ 0x80
20021d4c:	4241      	negs	r1, r0
20021d4e:	4141      	adcs	r1, r0
20021d50:	68e0      	ldr	r0, [r4, #12]
20021d52:	f1a0 0540 	sub.w	r5, r0, #64	@ 0x40
20021d56:	4268      	negs	r0, r5
20021d58:	4168      	adcs	r0, r5
20021d5a:	68a5      	ldr	r5, [r4, #8]
20021d5c:	2d10      	cmp	r5, #16
20021d5e:	bf1f      	itttt	ne
20021d60:	f884 106d 	strbne.w	r1, [r4, #109]	@ 0x6d
20021d64:	4619      	movne	r1, r3
20021d66:	4613      	movne	r3, r2
20021d68:	460a      	movne	r2, r1
20021d6a:	f884 306f 	strb.w	r3, [r4, #111]	@ 0x6f
20021d6e:	f884 206e 	strb.w	r2, [r4, #110]	@ 0x6e
20021d72:	f04f 0300 	mov.w	r3, #0
20021d76:	f04f 0201 	mov.w	r2, #1
20021d7a:	64a3      	str	r3, [r4, #72]	@ 0x48
20021d7c:	bf06      	itte	eq
20021d7e:	f884 006d 	strbeq.w	r0, [r4, #109]	@ 0x6d
20021d82:	f884 106c 	strbeq.w	r1, [r4, #108]	@ 0x6c
20021d86:	f884 006c 	strbne.w	r0, [r4, #108]	@ 0x6c
20021d8a:	f884 2031 	strb.w	r2, [r4, #49]	@ 0x31
20021d8e:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021d92:	b003      	add	sp, #12
20021d94:	bd30      	pop	{r4, r5, pc}
20021d96:	2302      	movs	r3, #2
20021d98:	e7d5      	b.n	20021d46 <DMA_Init+0xf8>
	...

20021d9c <DMA_AllocChannel>:
20021d9c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021d9e:	4b2f      	ldr	r3, [pc, #188]	@ (20021e5c <DMA_AllocChannel+0xc0>)
20021da0:	6802      	ldr	r2, [r0, #0]
20021da2:	4604      	mov	r4, r0
20021da4:	4413      	add	r3, r2
20021da6:	2ba0      	cmp	r3, #160	@ 0xa0
20021da8:	d904      	bls.n	20021db4 <DMA_AllocChannel+0x18>
20021daa:	4b2d      	ldr	r3, [pc, #180]	@ (20021e60 <DMA_AllocChannel+0xc4>)
20021dac:	4413      	add	r3, r2
20021dae:	2ba0      	cmp	r3, #160	@ 0xa0
20021db0:	d90f      	bls.n	20021dd2 <DMA_AllocChannel+0x36>
20021db2:	e7fe      	b.n	20021db2 <DMA_AllocChannel+0x16>
20021db4:	2032      	movs	r0, #50	@ 0x32
20021db6:	f8df c0b4 	ldr.w	ip, [pc, #180]	@ 20021e6c <DMA_AllocChannel+0xd0>
20021dba:	4b2a      	ldr	r3, [pc, #168]	@ (20021e64 <DMA_AllocChannel+0xc8>)
20021dbc:	f3ef 8710 	mrs	r7, PRIMASK
20021dc0:	2201      	movs	r2, #1
20021dc2:	f382 8810 	msr	PRIMASK, r2
20021dc6:	6d26      	ldr	r6, [r4, #80]	@ 0x50
20021dc8:	2e1f      	cmp	r6, #31
20021dca:	ea4f 0596 	mov.w	r5, r6, lsr #2
20021dce:	d905      	bls.n	20021ddc <DMA_AllocChannel+0x40>
20021dd0:	e7fe      	b.n	20021dd0 <DMA_AllocChannel+0x34>
20021dd2:	2002      	movs	r0, #2
20021dd4:	f8df c098 	ldr.w	ip, [pc, #152]	@ 20021e70 <DMA_AllocChannel+0xd4>
20021dd8:	4b23      	ldr	r3, [pc, #140]	@ (20021e68 <DMA_AllocChannel+0xcc>)
20021dda:	e7ef      	b.n	20021dbc <DMA_AllocChannel+0x20>
20021ddc:	eb03 06c5 	add.w	r6, r3, r5, lsl #3
20021de0:	f896 e004 	ldrb.w	lr, [r6, #4]
20021de4:	f1be 0f00 	cmp.w	lr, #0
20021de8:	d033      	beq.n	20021e52 <DMA_AllocChannel+0xb6>
20021dea:	f853 2035 	ldr.w	r2, [r3, r5, lsl #3]
20021dee:	42a2      	cmp	r2, r4
20021df0:	d103      	bne.n	20021dfa <DMA_AllocChannel+0x5e>
20021df2:	f387 8810 	msr	PRIMASK, r7
20021df6:	2002      	movs	r0, #2
20021df8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021dfa:	2200      	movs	r2, #0
20021dfc:	791d      	ldrb	r5, [r3, #4]
20021dfe:	461e      	mov	r6, r3
20021e00:	bb0d      	cbnz	r5, 20021e46 <DMA_AllocChannel+0xaa>
20021e02:	2301      	movs	r3, #1
20021e04:	7133      	strb	r3, [r6, #4]
20021e06:	2314      	movs	r3, #20
20021e08:	fb03 c302 	mla	r3, r3, r2, ip
20021e0c:	4410      	add	r0, r2
20021e0e:	0092      	lsls	r2, r2, #2
20021e10:	b245      	sxtb	r5, r0
20021e12:	6023      	str	r3, [r4, #0]
20021e14:	6522      	str	r2, [r4, #80]	@ 0x50
20021e16:	f387 8810 	msr	PRIMASK, r7
20021e1a:	b129      	cbz	r1, 20021e28 <DMA_AllocChannel+0x8c>
20021e1c:	6833      	ldr	r3, [r6, #0]
20021e1e:	42a3      	cmp	r3, r4
20021e20:	d002      	beq.n	20021e28 <DMA_AllocChannel+0x8c>
20021e22:	4620      	mov	r0, r4
20021e24:	f7ff ff13 	bl	20021c4e <DMA_Init>
20021e28:	6034      	str	r4, [r6, #0]
20021e2a:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
20021e2c:	f105 4260 	add.w	r2, r5, #3758096384	@ 0xe0000000
20021e30:	015b      	lsls	r3, r3, #5
20021e32:	b2db      	uxtb	r3, r3
20021e34:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20021e38:	4628      	mov	r0, r5
20021e3a:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
20021e3e:	f7ff fe6d 	bl	20021b1c <HAL_NVIC_EnableIRQ>
20021e42:	2000      	movs	r0, #0
20021e44:	e7d8      	b.n	20021df8 <DMA_AllocChannel+0x5c>
20021e46:	3201      	adds	r2, #1
20021e48:	2a08      	cmp	r2, #8
20021e4a:	f103 0308 	add.w	r3, r3, #8
20021e4e:	d1d5      	bne.n	20021dfc <DMA_AllocChannel+0x60>
20021e50:	e7cf      	b.n	20021df2 <DMA_AllocChannel+0x56>
20021e52:	4405      	add	r5, r0
20021e54:	7132      	strb	r2, [r6, #4]
20021e56:	b26d      	sxtb	r5, r5
20021e58:	e7dd      	b.n	20021e16 <DMA_AllocChannel+0x7a>
20021e5a:	bf00      	nop
20021e5c:	aff7eff8 	.word	0xaff7eff8
20021e60:	bfffeff8 	.word	0xbfffeff8
20021e64:	2004ca1c 	.word	0x2004ca1c
20021e68:	2004c9dc 	.word	0x2004c9dc
20021e6c:	50081008 	.word	0x50081008
20021e70:	40001008 	.word	0x40001008

20021e74 <HAL_DMA_Init>:
20021e74:	b538      	push	{r3, r4, r5, lr}
20021e76:	4604      	mov	r4, r0
20021e78:	2800      	cmp	r0, #0
20021e7a:	d05b      	beq.n	20021f34 <HAL_DMA_Init+0xc0>
20021e7c:	6883      	ldr	r3, [r0, #8]
20021e7e:	f033 0210 	bics.w	r2, r3, #16
20021e82:	d003      	beq.n	20021e8c <HAL_DMA_Init+0x18>
20021e84:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021e88:	d000      	beq.n	20021e8c <HAL_DMA_Init+0x18>
20021e8a:	e7fe      	b.n	20021e8a <HAL_DMA_Init+0x16>
20021e8c:	68e3      	ldr	r3, [r4, #12]
20021e8e:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20021e92:	d000      	beq.n	20021e96 <HAL_DMA_Init+0x22>
20021e94:	e7fe      	b.n	20021e94 <HAL_DMA_Init+0x20>
20021e96:	6923      	ldr	r3, [r4, #16]
20021e98:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
20021e9c:	d000      	beq.n	20021ea0 <HAL_DMA_Init+0x2c>
20021e9e:	e7fe      	b.n	20021e9e <HAL_DMA_Init+0x2a>
20021ea0:	6963      	ldr	r3, [r4, #20]
20021ea2:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20021ea6:	d003      	beq.n	20021eb0 <HAL_DMA_Init+0x3c>
20021ea8:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021eac:	d000      	beq.n	20021eb0 <HAL_DMA_Init+0x3c>
20021eae:	e7fe      	b.n	20021eae <HAL_DMA_Init+0x3a>
20021eb0:	69a3      	ldr	r3, [r4, #24]
20021eb2:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20021eb6:	d003      	beq.n	20021ec0 <HAL_DMA_Init+0x4c>
20021eb8:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
20021ebc:	d000      	beq.n	20021ec0 <HAL_DMA_Init+0x4c>
20021ebe:	e7fe      	b.n	20021ebe <HAL_DMA_Init+0x4a>
20021ec0:	69e3      	ldr	r3, [r4, #28]
20021ec2:	f033 0320 	bics.w	r3, r3, #32
20021ec6:	d000      	beq.n	20021eca <HAL_DMA_Init+0x56>
20021ec8:	e7fe      	b.n	20021ec8 <HAL_DMA_Init+0x54>
20021eca:	6a23      	ldr	r3, [r4, #32]
20021ecc:	f433 5240 	bics.w	r2, r3, #12288	@ 0x3000
20021ed0:	d000      	beq.n	20021ed4 <HAL_DMA_Init+0x60>
20021ed2:	e7fe      	b.n	20021ed2 <HAL_DMA_Init+0x5e>
20021ed4:	6863      	ldr	r3, [r4, #4]
20021ed6:	2b51      	cmp	r3, #81	@ 0x51
20021ed8:	d900      	bls.n	20021edc <HAL_DMA_Init+0x68>
20021eda:	e7fe      	b.n	20021eda <HAL_DMA_Init+0x66>
20021edc:	6821      	ldr	r1, [r4, #0]
20021ede:	4b17      	ldr	r3, [pc, #92]	@ (20021f3c <HAL_DMA_Init+0xc8>)
20021ee0:	440b      	add	r3, r1
20021ee2:	2b8c      	cmp	r3, #140	@ 0x8c
20021ee4:	d81a      	bhi.n	20021f1c <HAL_DMA_Init+0xa8>
20021ee6:	2214      	movs	r2, #20
20021ee8:	fbb3 f3f2 	udiv	r3, r3, r2
20021eec:	2201      	movs	r2, #1
20021eee:	4914      	ldr	r1, [pc, #80]	@ (20021f40 <HAL_DMA_Init+0xcc>)
20021ef0:	0098      	lsls	r0, r3, #2
20021ef2:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021ef6:	ea43 73c2 	orr.w	r3, r3, r2, lsl #31
20021efa:	e9c4 1013 	strd	r1, r0, [r4, #76]	@ 0x4c
20021efe:	6563      	str	r3, [r4, #84]	@ 0x54
20021f00:	2100      	movs	r1, #0
20021f02:	4620      	mov	r0, r4
20021f04:	f7ff ff4a 	bl	20021d9c <DMA_AllocChannel>
20021f08:	4605      	mov	r5, r0
20021f0a:	b9a8      	cbnz	r0, 20021f38 <HAL_DMA_Init+0xc4>
20021f0c:	4620      	mov	r0, r4
20021f0e:	f7ff fe9e 	bl	20021c4e <DMA_Init>
20021f12:	4620      	mov	r0, r4
20021f14:	f7ff fe50 	bl	20021bb8 <DMA_FreeChannel.isra.0>
20021f18:	4628      	mov	r0, r5
20021f1a:	bd38      	pop	{r3, r4, r5, pc}
20021f1c:	4b09      	ldr	r3, [pc, #36]	@ (20021f44 <HAL_DMA_Init+0xd0>)
20021f1e:	440b      	add	r3, r1
20021f20:	2b8c      	cmp	r3, #140	@ 0x8c
20021f22:	d807      	bhi.n	20021f34 <HAL_DMA_Init+0xc0>
20021f24:	2114      	movs	r1, #20
20021f26:	fbb3 f3f1 	udiv	r3, r3, r1
20021f2a:	4907      	ldr	r1, [pc, #28]	@ (20021f48 <HAL_DMA_Init+0xd4>)
20021f2c:	0098      	lsls	r0, r3, #2
20021f2e:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021f32:	e7e0      	b.n	20021ef6 <HAL_DMA_Init+0x82>
20021f34:	2501      	movs	r5, #1
20021f36:	e7ef      	b.n	20021f18 <HAL_DMA_Init+0xa4>
20021f38:	2502      	movs	r5, #2
20021f3a:	e7ed      	b.n	20021f18 <HAL_DMA_Init+0xa4>
20021f3c:	aff7eff8 	.word	0xaff7eff8
20021f40:	50081000 	.word	0x50081000
20021f44:	bfffeff8 	.word	0xbfffeff8
20021f48:	40001000 	.word	0x40001000

20021f4c <HAL_DMA_DeInit>:
20021f4c:	b538      	push	{r3, r4, r5, lr}
20021f4e:	4604      	mov	r4, r0
20021f50:	2800      	cmp	r0, #0
20021f52:	d05e      	beq.n	20022012 <HAL_DMA_DeInit+0xc6>
20021f54:	6802      	ldr	r2, [r0, #0]
20021f56:	4b30      	ldr	r3, [pc, #192]	@ (20022018 <HAL_DMA_DeInit+0xcc>)
20021f58:	4413      	add	r3, r2
20021f5a:	2b8c      	cmp	r3, #140	@ 0x8c
20021f5c:	d841      	bhi.n	20021fe2 <HAL_DMA_DeInit+0x96>
20021f5e:	2214      	movs	r2, #20
20021f60:	fbb3 f3f2 	udiv	r3, r3, r2
20021f64:	009b      	lsls	r3, r3, #2
20021f66:	6503      	str	r3, [r0, #80]	@ 0x50
20021f68:	4b2c      	ldr	r3, [pc, #176]	@ (2002201c <HAL_DMA_DeInit+0xd0>)
20021f6a:	64e3      	str	r3, [r4, #76]	@ 0x4c
20021f6c:	4620      	mov	r0, r4
20021f6e:	f7ff fdf7 	bl	20021b60 <DMA_IsChannelOwner>
20021f72:	b3a0      	cbz	r0, 20021fde <HAL_DMA_DeInit+0x92>
20021f74:	6822      	ldr	r2, [r4, #0]
20021f76:	6813      	ldr	r3, [r2, #0]
20021f78:	f023 0301 	bic.w	r3, r3, #1
20021f7c:	6013      	str	r3, [r2, #0]
20021f7e:	2200      	movs	r2, #0
20021f80:	6823      	ldr	r3, [r4, #0]
20021f82:	601a      	str	r2, [r3, #0]
20021f84:	2201      	movs	r2, #1
20021f86:	e9d4 1313 	ldrd	r1, r3, [r4, #76]	@ 0x4c
20021f8a:	f003 031c 	and.w	r3, r3, #28
20021f8e:	fa02 f303 	lsl.w	r3, r2, r3
20021f92:	604b      	str	r3, [r1, #4]
20021f94:	f3ef 8510 	mrs	r5, PRIMASK
20021f98:	f382 8810 	msr	PRIMASK, r2
20021f9c:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021f9e:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
20021fa0:	2b0f      	cmp	r3, #15
20021fa2:	ea4f 0293 	mov.w	r2, r3, lsr #2
20021fa6:	d827      	bhi.n	20021ff8 <HAL_DMA_DeInit+0xac>
20021fa8:	203f      	movs	r0, #63	@ 0x3f
20021faa:	005b      	lsls	r3, r3, #1
20021fac:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
20021fb0:	f003 0338 	and.w	r3, r3, #56	@ 0x38
20021fb4:	fa00 f303 	lsl.w	r3, r0, r3
20021fb8:	ea22 0303 	bic.w	r3, r2, r3
20021fbc:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
20021fc0:	f385 8810 	msr	PRIMASK, r5
20021fc4:	4620      	mov	r0, r4
20021fc6:	f7ff fdf7 	bl	20021bb8 <DMA_FreeChannel.isra.0>
20021fca:	2300      	movs	r3, #0
20021fcc:	e9c4 330e 	strd	r3, r3, [r4, #56]	@ 0x38
20021fd0:	e9c4 3310 	strd	r3, r3, [r4, #64]	@ 0x40
20021fd4:	64a3      	str	r3, [r4, #72]	@ 0x48
20021fd6:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021fda:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20021fde:	2000      	movs	r0, #0
20021fe0:	bd38      	pop	{r3, r4, r5, pc}
20021fe2:	4b0f      	ldr	r3, [pc, #60]	@ (20022020 <HAL_DMA_DeInit+0xd4>)
20021fe4:	4413      	add	r3, r2
20021fe6:	2b8c      	cmp	r3, #140	@ 0x8c
20021fe8:	d8c0      	bhi.n	20021f6c <HAL_DMA_DeInit+0x20>
20021fea:	2214      	movs	r2, #20
20021fec:	fbb3 f3f2 	udiv	r3, r3, r2
20021ff0:	009b      	lsls	r3, r3, #2
20021ff2:	6503      	str	r3, [r0, #80]	@ 0x50
20021ff4:	4b0b      	ldr	r3, [pc, #44]	@ (20022024 <HAL_DMA_DeInit+0xd8>)
20021ff6:	e7b8      	b.n	20021f6a <HAL_DMA_DeInit+0x1e>
20021ff8:	f002 0303 	and.w	r3, r2, #3
20021ffc:	223f      	movs	r2, #63	@ 0x3f
20021ffe:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20022002:	00db      	lsls	r3, r3, #3
20022004:	fa02 f303 	lsl.w	r3, r2, r3
20022008:	ea20 0303 	bic.w	r3, r0, r3
2002200c:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
20022010:	e7d6      	b.n	20021fc0 <HAL_DMA_DeInit+0x74>
20022012:	2001      	movs	r0, #1
20022014:	e7e4      	b.n	20021fe0 <HAL_DMA_DeInit+0x94>
20022016:	bf00      	nop
20022018:	aff7eff8 	.word	0xaff7eff8
2002201c:	50081000 	.word	0x50081000
20022020:	bfffeff8 	.word	0xbfffeff8
20022024:	40001000 	.word	0x40001000

20022028 <HAL_DMA_PollForTransfer>:
20022028:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002202c:	f890 3031 	ldrb.w	r3, [r0, #49]	@ 0x31
20022030:	4617      	mov	r7, r2
20022032:	2b02      	cmp	r3, #2
20022034:	4604      	mov	r4, r0
20022036:	4688      	mov	r8, r1
20022038:	b2da      	uxtb	r2, r3
2002203a:	d005      	beq.n	20022048 <HAL_DMA_PollForTransfer+0x20>
2002203c:	2304      	movs	r3, #4
2002203e:	6483      	str	r3, [r0, #72]	@ 0x48
20022040:	2300      	movs	r3, #0
20022042:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022046:	e006      	b.n	20022056 <HAL_DMA_PollForTransfer+0x2e>
20022048:	6803      	ldr	r3, [r0, #0]
2002204a:	681b      	ldr	r3, [r3, #0]
2002204c:	0699      	lsls	r1, r3, #26
2002204e:	d505      	bpl.n	2002205c <HAL_DMA_PollForTransfer+0x34>
20022050:	f44f 7380 	mov.w	r3, #256	@ 0x100
20022054:	6483      	str	r3, [r0, #72]	@ 0x48
20022056:	2001      	movs	r0, #1
20022058:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002205c:	6d05      	ldr	r5, [r0, #80]	@ 0x50
2002205e:	f005 051c 	and.w	r5, r5, #28
20022062:	f1b8 0f00 	cmp.w	r8, #0
20022066:	d123      	bne.n	200220b0 <HAL_DMA_PollForTransfer+0x88>
20022068:	fa02 f505 	lsl.w	r5, r2, r5
2002206c:	f7ff fc1e 	bl	200218ac <HAL_GetTick>
20022070:	f04f 0a08 	mov.w	sl, #8
20022074:	4681      	mov	r9, r0
20022076:	e9d4 6313 	ldrd	r6, r3, [r4, #76]	@ 0x4c
2002207a:	f003 031c 	and.w	r3, r3, #28
2002207e:	fa0a f103 	lsl.w	r1, sl, r3
20022082:	6832      	ldr	r2, [r6, #0]
20022084:	ea12 0b05 	ands.w	fp, r2, r5
20022088:	d016      	beq.n	200220b8 <HAL_DMA_PollForTransfer+0x90>
2002208a:	f1b8 0f00 	cmp.w	r8, #0
2002208e:	d136      	bne.n	200220fe <HAL_DMA_PollForTransfer+0xd6>
20022090:	2202      	movs	r2, #2
20022092:	fa02 f303 	lsl.w	r3, r2, r3
20022096:	6073      	str	r3, [r6, #4]
20022098:	6da3      	ldr	r3, [r4, #88]	@ 0x58
2002209a:	b92b      	cbnz	r3, 200220a8 <HAL_DMA_PollForTransfer+0x80>
2002209c:	4620      	mov	r0, r4
2002209e:	f7ff fd8b 	bl	20021bb8 <DMA_FreeChannel.isra.0>
200220a2:	2301      	movs	r3, #1
200220a4:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200220a8:	2000      	movs	r0, #0
200220aa:	f884 0030 	strb.w	r0, [r4, #48]	@ 0x30
200220ae:	e7d3      	b.n	20022058 <HAL_DMA_PollForTransfer+0x30>
200220b0:	2304      	movs	r3, #4
200220b2:	fa03 f505 	lsl.w	r5, r3, r5
200220b6:	e7d9      	b.n	2002206c <HAL_DMA_PollForTransfer+0x44>
200220b8:	6832      	ldr	r2, [r6, #0]
200220ba:	4211      	tst	r1, r2
200220bc:	d00c      	beq.n	200220d8 <HAL_DMA_PollForTransfer+0xb0>
200220be:	2501      	movs	r5, #1
200220c0:	fa05 f303 	lsl.w	r3, r5, r3
200220c4:	6073      	str	r3, [r6, #4]
200220c6:	4620      	mov	r0, r4
200220c8:	64a5      	str	r5, [r4, #72]	@ 0x48
200220ca:	f7ff fd75 	bl	20021bb8 <DMA_FreeChannel.isra.0>
200220ce:	f884 5031 	strb.w	r5, [r4, #49]	@ 0x31
200220d2:	f884 b030 	strb.w	fp, [r4, #48]	@ 0x30
200220d6:	e7be      	b.n	20022056 <HAL_DMA_PollForTransfer+0x2e>
200220d8:	1c7a      	adds	r2, r7, #1
200220da:	d0d2      	beq.n	20022082 <HAL_DMA_PollForTransfer+0x5a>
200220dc:	f7ff fbe6 	bl	200218ac <HAL_GetTick>
200220e0:	eba0 0009 	sub.w	r0, r0, r9
200220e4:	42b8      	cmp	r0, r7
200220e6:	d801      	bhi.n	200220ec <HAL_DMA_PollForTransfer+0xc4>
200220e8:	2f00      	cmp	r7, #0
200220ea:	d1c4      	bne.n	20022076 <HAL_DMA_PollForTransfer+0x4e>
200220ec:	2320      	movs	r3, #32
200220ee:	4620      	mov	r0, r4
200220f0:	64a3      	str	r3, [r4, #72]	@ 0x48
200220f2:	f7ff fd61 	bl	20021bb8 <DMA_FreeChannel.isra.0>
200220f6:	2301      	movs	r3, #1
200220f8:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200220fc:	e7a0      	b.n	20022040 <HAL_DMA_PollForTransfer+0x18>
200220fe:	2204      	movs	r2, #4
20022100:	fa02 f303 	lsl.w	r3, r2, r3
20022104:	6073      	str	r3, [r6, #4]
20022106:	e7cf      	b.n	200220a8 <HAL_DMA_PollForTransfer+0x80>

20022108 <DMA_Remap>:
20022108:	b530      	push	{r4, r5, lr}
2002210a:	4b15      	ldr	r3, [pc, #84]	@ (20022160 <DMA_Remap+0x58>)
2002210c:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
2002210e:	429c      	cmp	r4, r3
20022110:	d11b      	bne.n	2002214a <DMA_Remap+0x42>
20022112:	6883      	ldr	r3, [r0, #8]
20022114:	2b10      	cmp	r3, #16
20022116:	d002      	beq.n	2002211e <DMA_Remap+0x16>
20022118:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
2002211c:	d108      	bne.n	20022130 <DMA_Remap+0x28>
2002211e:	680b      	ldr	r3, [r1, #0]
20022120:	4c10      	ldr	r4, [pc, #64]	@ (20022164 <DMA_Remap+0x5c>)
20022122:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
20022126:	42a5      	cmp	r5, r4
20022128:	bf98      	it	ls
2002212a:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
2002212e:	600b      	str	r3, [r1, #0]
20022130:	6883      	ldr	r3, [r0, #8]
20022132:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
20022136:	d108      	bne.n	2002214a <DMA_Remap+0x42>
20022138:	6813      	ldr	r3, [r2, #0]
2002213a:	480a      	ldr	r0, [pc, #40]	@ (20022164 <DMA_Remap+0x5c>)
2002213c:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
20022140:	4284      	cmp	r4, r0
20022142:	bf98      	it	ls
20022144:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
20022148:	6013      	str	r3, [r2, #0]
2002214a:	680b      	ldr	r3, [r1, #0]
2002214c:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
20022150:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20022154:	bf3c      	itt	cc
20022156:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
2002215a:	600b      	strcc	r3, [r1, #0]
2002215c:	bd30      	pop	{r4, r5, pc}
2002215e:	bf00      	nop
20022160:	40001000 	.word	0x40001000
20022164:	0007fffe 	.word	0x0007fffe

20022168 <DMA_Start>:
20022168:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
2002216c:	f64f 75ff 	movw	r5, #65535	@ 0xffff
20022170:	4a2f      	ldr	r2, [pc, #188]	@ (20022230 <DMA_Start+0xc8>)
20022172:	4f30      	ldr	r7, [pc, #192]	@ (20022234 <DMA_Start+0xcc>)
20022174:	460e      	mov	r6, r1
20022176:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
20022178:	6d83      	ldr	r3, [r0, #88]	@ 0x58
2002217a:	4291      	cmp	r1, r2
2002217c:	bf18      	it	ne
2002217e:	463d      	movne	r5, r7
20022180:	429d      	cmp	r5, r3
20022182:	bf28      	it	cs
20022184:	461d      	movcs	r5, r3
20022186:	6802      	ldr	r2, [r0, #0]
20022188:	1b5b      	subs	r3, r3, r5
2002218a:	6583      	str	r3, [r0, #88]	@ 0x58
2002218c:	6605      	str	r5, [r0, #96]	@ 0x60
2002218e:	6813      	ldr	r3, [r2, #0]
20022190:	f890 706e 	ldrb.w	r7, [r0, #110]	@ 0x6e
20022194:	f023 0301 	bic.w	r3, r3, #1
20022198:	f890 806f 	ldrb.w	r8, [r0, #111]	@ 0x6f
2002219c:	6013      	str	r3, [r2, #0]
2002219e:	e9d0 2319 	ldrd	r2, r3, [r0, #100]	@ 0x64
200221a2:	e9cd 2300 	strd	r2, r3, [sp]
200221a6:	e9d0 2313 	ldrd	r2, r3, [r0, #76]	@ 0x4c
200221aa:	f003 011c 	and.w	r1, r3, #28
200221ae:	2301      	movs	r3, #1
200221b0:	4604      	mov	r4, r0
200221b2:	408b      	lsls	r3, r1
200221b4:	6053      	str	r3, [r2, #4]
200221b6:	6803      	ldr	r3, [r0, #0]
200221b8:	4669      	mov	r1, sp
200221ba:	605d      	str	r5, [r3, #4]
200221bc:	aa01      	add	r2, sp, #4
200221be:	f7ff ffa3 	bl	20022108 <DMA_Remap>
200221c2:	e9dd 0300 	ldrd	r0, r3, [sp]
200221c6:	68a1      	ldr	r1, [r4, #8]
200221c8:	6822      	ldr	r2, [r4, #0]
200221ca:	2910      	cmp	r1, #16
200221cc:	bf0b      	itete	eq
200221ce:	6093      	streq	r3, [r2, #8]
200221d0:	6090      	strne	r0, [r2, #8]
200221d2:	6823      	ldreq	r3, [r4, #0]
200221d4:	6822      	ldrne	r2, [r4, #0]
200221d6:	bf0c      	ite	eq
200221d8:	60d8      	streq	r0, [r3, #12]
200221da:	60d3      	strne	r3, [r2, #12]
200221dc:	f894 306c 	ldrb.w	r3, [r4, #108]	@ 0x6c
200221e0:	b123      	cbz	r3, 200221ec <DMA_Start+0x84>
200221e2:	6e63      	ldr	r3, [r4, #100]	@ 0x64
200221e4:	fa05 f707 	lsl.w	r7, r5, r7
200221e8:	443b      	add	r3, r7
200221ea:	6663      	str	r3, [r4, #100]	@ 0x64
200221ec:	f894 306d 	ldrb.w	r3, [r4, #109]	@ 0x6d
200221f0:	b123      	cbz	r3, 200221fc <DMA_Start+0x94>
200221f2:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
200221f4:	fa05 f508 	lsl.w	r5, r5, r8
200221f8:	442b      	add	r3, r5
200221fa:	66a3      	str	r3, [r4, #104]	@ 0x68
200221fc:	b136      	cbz	r6, 2002220c <DMA_Start+0xa4>
200221fe:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
20022200:	6823      	ldr	r3, [r4, #0]
20022202:	b15a      	cbz	r2, 2002221c <DMA_Start+0xb4>
20022204:	681a      	ldr	r2, [r3, #0]
20022206:	f042 020e 	orr.w	r2, r2, #14
2002220a:	601a      	str	r2, [r3, #0]
2002220c:	6822      	ldr	r2, [r4, #0]
2002220e:	6813      	ldr	r3, [r2, #0]
20022210:	f043 0301 	orr.w	r3, r3, #1
20022214:	6013      	str	r3, [r2, #0]
20022216:	b002      	add	sp, #8
20022218:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002221c:	681a      	ldr	r2, [r3, #0]
2002221e:	f022 0204 	bic.w	r2, r2, #4
20022222:	601a      	str	r2, [r3, #0]
20022224:	6822      	ldr	r2, [r4, #0]
20022226:	6813      	ldr	r3, [r2, #0]
20022228:	f043 030a 	orr.w	r3, r3, #10
2002222c:	6013      	str	r3, [r2, #0]
2002222e:	e7ed      	b.n	2002220c <DMA_Start+0xa4>
20022230:	40001000 	.word	0x40001000
20022234:	000fffff 	.word	0x000fffff

20022238 <HAL_DMA_Start>:
20022238:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002223a:	461d      	mov	r5, r3
2002223c:	69c3      	ldr	r3, [r0, #28]
2002223e:	4604      	mov	r4, r0
20022240:	2b20      	cmp	r3, #32
20022242:	460f      	mov	r7, r1
20022244:	4616      	mov	r6, r2
20022246:	d10b      	bne.n	20022260 <HAL_DMA_Start+0x28>
20022248:	b14d      	cbz	r5, 2002225e <HAL_DMA_Start+0x26>
2002224a:	f64f 73ff 	movw	r3, #65535	@ 0xffff
2002224e:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
20022250:	4a1b      	ldr	r2, [pc, #108]	@ (200222c0 <HAL_DMA_Start+0x88>)
20022252:	481c      	ldr	r0, [pc, #112]	@ (200222c4 <HAL_DMA_Start+0x8c>)
20022254:	4291      	cmp	r1, r2
20022256:	bf18      	it	ne
20022258:	4603      	movne	r3, r0
2002225a:	42ab      	cmp	r3, r5
2002225c:	d800      	bhi.n	20022260 <HAL_DMA_Start+0x28>
2002225e:	e7fe      	b.n	2002225e <HAL_DMA_Start+0x26>
20022260:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
20022264:	2b01      	cmp	r3, #1
20022266:	d00e      	beq.n	20022286 <HAL_DMA_Start+0x4e>
20022268:	2301      	movs	r3, #1
2002226a:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
2002226e:	f894 3031 	ldrb.w	r3, [r4, #49]	@ 0x31
20022272:	2b01      	cmp	r3, #1
20022274:	b2d9      	uxtb	r1, r3
20022276:	d103      	bne.n	20022280 <HAL_DMA_Start+0x48>
20022278:	4620      	mov	r0, r4
2002227a:	f7ff fd8f 	bl	20021d9c <DMA_AllocChannel>
2002227e:	b120      	cbz	r0, 2002228a <HAL_DMA_Start+0x52>
20022280:	2300      	movs	r3, #0
20022282:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022286:	2002      	movs	r0, #2
20022288:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002228a:	2302      	movs	r3, #2
2002228c:	e9c4 5516 	strd	r5, r5, [r4, #88]	@ 0x58
20022290:	e9c4 7619 	strd	r7, r6, [r4, #100]	@ 0x64
20022294:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022298:	64a0      	str	r0, [r4, #72]	@ 0x48
2002229a:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002229c:	2800      	cmp	r0, #0
2002229e:	d0f3      	beq.n	20022288 <HAL_DMA_Start+0x50>
200222a0:	2100      	movs	r1, #0
200222a2:	4620      	mov	r0, r4
200222a4:	f7ff ff60 	bl	20022168 <DMA_Start>
200222a8:	6da3      	ldr	r3, [r4, #88]	@ 0x58
200222aa:	2b00      	cmp	r3, #0
200222ac:	d0f5      	beq.n	2002229a <HAL_DMA_Start+0x62>
200222ae:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
200222b2:	2100      	movs	r1, #0
200222b4:	4620      	mov	r0, r4
200222b6:	f7ff feb7 	bl	20022028 <HAL_DMA_PollForTransfer>
200222ba:	2800      	cmp	r0, #0
200222bc:	d0ed      	beq.n	2002229a <HAL_DMA_Start+0x62>
200222be:	e7e3      	b.n	20022288 <HAL_DMA_Start+0x50>
200222c0:	40001000 	.word	0x40001000
200222c4:	000fffff 	.word	0x000fffff

200222c8 <HAL_EFUSE_Read>:
200222c8:	2a20      	cmp	r2, #32
200222ca:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200222ce:	4607      	mov	r7, r0
200222d0:	460c      	mov	r4, r1
200222d2:	4690      	mov	r8, r2
200222d4:	dc25      	bgt.n	20022322 <HAL_EFUSE_Read+0x5a>
200222d6:	f3c0 09c4 	ubfx	r9, r0, #3, #5
200222da:	eb09 0302 	add.w	r3, r9, r2
200222de:	2b20      	cmp	r3, #32
200222e0:	dc1f      	bgt.n	20022322 <HAL_EFUSE_Read+0x5a>
200222e2:	f012 0f03 	tst.w	r2, #3
200222e6:	d11c      	bne.n	20022322 <HAL_EFUSE_Read+0x5a>
200222e8:	f010 051f 	ands.w	r5, r0, #31
200222ec:	d119      	bne.n	20022322 <HAL_EFUSE_Read+0x5a>
200222ee:	2003      	movs	r0, #3
200222f0:	f7ff fa40 	bl	20021774 <pmu_ldo_inc>
200222f4:	4629      	mov	r1, r5
200222f6:	4e1d      	ldr	r6, [pc, #116]	@ (2002236c <HAL_EFUSE_Read+0xa4>)
200222f8:	0a3f      	lsrs	r7, r7, #8
200222fa:	00bb      	lsls	r3, r7, #2
200222fc:	6033      	str	r3, [r6, #0]
200222fe:	6833      	ldr	r3, [r6, #0]
20022300:	4a1b      	ldr	r2, [pc, #108]	@ (20022370 <HAL_EFUSE_Read+0xa8>)
20022302:	f043 0301 	orr.w	r3, r3, #1
20022306:	6033      	str	r3, [r6, #0]
20022308:	68b3      	ldr	r3, [r6, #8]
2002230a:	07db      	lsls	r3, r3, #31
2002230c:	d401      	bmi.n	20022312 <HAL_EFUSE_Read+0x4a>
2002230e:	4291      	cmp	r1, r2
20022310:	d10c      	bne.n	2002232c <HAL_EFUSE_Read+0x64>
20022312:	68b3      	ldr	r3, [r6, #8]
20022314:	4291      	cmp	r1, r2
20022316:	f043 0301 	orr.w	r3, r3, #1
2002231a:	60b3      	str	r3, [r6, #8]
2002231c:	d108      	bne.n	20022330 <HAL_EFUSE_Read+0x68>
2002231e:	f7ff fa2b 	bl	20021778 <pmu_ldo_recover>
20022322:	f04f 0800 	mov.w	r8, #0
20022326:	4640      	mov	r0, r8
20022328:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002232c:	3101      	adds	r1, #1
2002232e:	e7eb      	b.n	20022308 <HAL_EFUSE_Read+0x40>
20022330:	4a10      	ldr	r2, [pc, #64]	@ (20022374 <HAL_EFUSE_Read+0xac>)
20022332:	f009 031c 	and.w	r3, r9, #28
20022336:	eb03 1347 	add.w	r3, r3, r7, lsl #5
2002233a:	f028 0103 	bic.w	r1, r8, #3
2002233e:	441a      	add	r2, r3
20022340:	4421      	add	r1, r4
20022342:	428c      	cmp	r4, r1
20022344:	d102      	bne.n	2002234c <HAL_EFUSE_Read+0x84>
20022346:	f7ff fa17 	bl	20021778 <pmu_ldo_recover>
2002234a:	e7ec      	b.n	20022326 <HAL_EFUSE_Read+0x5e>
2002234c:	f852 3b04 	ldr.w	r3, [r2], #4
20022350:	3404      	adds	r4, #4
20022352:	0a1d      	lsrs	r5, r3, #8
20022354:	f804 3c04 	strb.w	r3, [r4, #-4]
20022358:	f804 5c03 	strb.w	r5, [r4, #-3]
2002235c:	0c1d      	lsrs	r5, r3, #16
2002235e:	0e1b      	lsrs	r3, r3, #24
20022360:	f804 5c02 	strb.w	r5, [r4, #-2]
20022364:	f804 3c01 	strb.w	r3, [r4, #-1]
20022368:	e7eb      	b.n	20022342 <HAL_EFUSE_Read+0x7a>
2002236a:	bf00      	nop
2002236c:	5000c000 	.word	0x5000c000
20022370:	00bb8000 	.word	0x00bb8000
20022374:	5000c030 	.word	0x5000c030

20022378 <HAL_HPAON_EnableXT48>:
20022378:	4b04      	ldr	r3, [pc, #16]	@ (2002238c <HAL_HPAON_EnableXT48+0x14>)
2002237a:	689a      	ldr	r2, [r3, #8]
2002237c:	f042 0202 	orr.w	r2, r2, #2
20022380:	609a      	str	r2, [r3, #8]
20022382:	689a      	ldr	r2, [r3, #8]
20022384:	2a00      	cmp	r2, #0
20022386:	dafc      	bge.n	20022382 <HAL_HPAON_EnableXT48+0xa>
20022388:	4770      	bx	lr
2002238a:	bf00      	nop
2002238c:	500c0000 	.word	0x500c0000

20022390 <HAL_HPAON_DisableXT48>:
20022390:	4a02      	ldr	r2, [pc, #8]	@ (2002239c <HAL_HPAON_DisableXT48+0xc>)
20022392:	6893      	ldr	r3, [r2, #8]
20022394:	f023 0302 	bic.w	r3, r3, #2
20022398:	6093      	str	r3, [r2, #8]
2002239a:	4770      	bx	lr
2002239c:	500c0000 	.word	0x500c0000

200223a0 <HAL_QSPI_Init>:
200223a0:	b510      	push	{r4, lr}
200223a2:	b1e8      	cbz	r0, 200223e0 <HAL_QSPI_Init+0x40>
200223a4:	b1e1      	cbz	r1, 200223e0 <HAL_QSPI_Init+0x40>
200223a6:	2300      	movs	r3, #0
200223a8:	2201      	movs	r2, #1
200223aa:	6043      	str	r3, [r0, #4]
200223ac:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
200223b0:	680c      	ldr	r4, [r1, #0]
200223b2:	6004      	str	r4, [r0, #0]
200223b4:	684a      	ldr	r2, [r1, #4]
200223b6:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
200223ba:	688a      	ldr	r2, [r1, #8]
200223bc:	6102      	str	r2, [r0, #16]
200223be:	68ca      	ldr	r2, [r1, #12]
200223c0:	0512      	lsls	r2, r2, #20
200223c2:	6142      	str	r2, [r0, #20]
200223c4:	22ff      	movs	r2, #255	@ 0xff
200223c6:	f8c4 208c 	str.w	r2, [r4, #140]	@ 0x8c
200223ca:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
200223ce:	6801      	ldr	r1, [r0, #0]
200223d0:	f8c1 4080 	str.w	r4, [r1, #128]	@ 0x80
200223d4:	6801      	ldr	r1, [r0, #0]
200223d6:	620a      	str	r2, [r1, #32]
200223d8:	6801      	ldr	r1, [r0, #0]
200223da:	4618      	mov	r0, r3
200223dc:	644a      	str	r2, [r1, #68]	@ 0x44
200223de:	bd10      	pop	{r4, pc}
200223e0:	2001      	movs	r0, #1
200223e2:	e7fc      	b.n	200223de <HAL_QSPI_Init+0x3e>

200223e4 <HAL_FLASH_SET_AHB_RCMD>:
200223e4:	b138      	cbz	r0, 200223f6 <HAL_FLASH_SET_AHB_RCMD+0x12>
200223e6:	6802      	ldr	r2, [r0, #0]
200223e8:	2000      	movs	r0, #0
200223ea:	6c13      	ldr	r3, [r2, #64]	@ 0x40
200223ec:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
200223f0:	4319      	orrs	r1, r3
200223f2:	6411      	str	r1, [r2, #64]	@ 0x40
200223f4:	4770      	bx	lr
200223f6:	2001      	movs	r0, #1
200223f8:	4770      	bx	lr

200223fa <HAL_FLASH_CFG_AHB_RCMD>:
200223fa:	b570      	push	{r4, r5, r6, lr}
200223fc:	b1c8      	cbz	r0, 20022432 <HAL_FLASH_CFG_AHB_RCMD+0x38>
200223fe:	6805      	ldr	r5, [r0, #0]
20022400:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022404:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022408:	6cac      	ldr	r4, [r5, #72]	@ 0x48
2002240a:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002240e:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022412:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022416:	f36f 0414 	bfc	r4, #0, #21
2002241a:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
2002241e:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022422:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022426:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
2002242a:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
2002242e:	4321      	orrs	r1, r4
20022430:	64a9      	str	r1, [r5, #72]	@ 0x48
20022432:	bd70      	pop	{r4, r5, r6, pc}

20022434 <HAL_FLASH_SET_AHB_WCMD>:
20022434:	b140      	cbz	r0, 20022448 <HAL_FLASH_SET_AHB_WCMD+0x14>
20022436:	6802      	ldr	r2, [r0, #0]
20022438:	2000      	movs	r0, #0
2002243a:	6c13      	ldr	r3, [r2, #64]	@ 0x40
2002243c:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
20022440:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
20022444:	6411      	str	r1, [r2, #64]	@ 0x40
20022446:	4770      	bx	lr
20022448:	2001      	movs	r0, #1
2002244a:	4770      	bx	lr

2002244c <HAL_FLASH_CFG_AHB_WCMD>:
2002244c:	b570      	push	{r4, r5, r6, lr}
2002244e:	b1c8      	cbz	r0, 20022484 <HAL_FLASH_CFG_AHB_WCMD+0x38>
20022450:	6805      	ldr	r5, [r0, #0]
20022452:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022456:	f99d 001c 	ldrsb.w	r0, [sp, #28]
2002245a:	6d2c      	ldr	r4, [r5, #80]	@ 0x50
2002245c:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022460:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022464:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022468:	f36f 0414 	bfc	r4, #0, #21
2002246c:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022470:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022474:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022478:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
2002247c:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
20022480:	4321      	orrs	r1, r4
20022482:	6529      	str	r1, [r5, #80]	@ 0x50
20022484:	bd70      	pop	{r4, r5, r6, pc}

20022486 <HAL_FLASH_WRITE_WORD>:
20022486:	b118      	cbz	r0, 20022490 <HAL_FLASH_WRITE_WORD+0xa>
20022488:	6803      	ldr	r3, [r0, #0]
2002248a:	2000      	movs	r0, #0
2002248c:	6059      	str	r1, [r3, #4]
2002248e:	4770      	bx	lr
20022490:	2001      	movs	r0, #1
20022492:	4770      	bx	lr

20022494 <HAL_FLASH_WRITE_DLEN>:
20022494:	b130      	cbz	r0, 200224a4 <HAL_FLASH_WRITE_DLEN+0x10>
20022496:	6803      	ldr	r3, [r0, #0]
20022498:	3901      	subs	r1, #1
2002249a:	f3c1 0113 	ubfx	r1, r1, #0, #20
2002249e:	2000      	movs	r0, #0
200224a0:	6259      	str	r1, [r3, #36]	@ 0x24
200224a2:	4770      	bx	lr
200224a4:	2001      	movs	r0, #1
200224a6:	4770      	bx	lr

200224a8 <HAL_FLASH_WRITE_DLEN2>:
200224a8:	b130      	cbz	r0, 200224b8 <HAL_FLASH_WRITE_DLEN2+0x10>
200224aa:	6803      	ldr	r3, [r0, #0]
200224ac:	3901      	subs	r1, #1
200224ae:	f3c1 0113 	ubfx	r1, r1, #0, #20
200224b2:	2000      	movs	r0, #0
200224b4:	6399      	str	r1, [r3, #56]	@ 0x38
200224b6:	4770      	bx	lr
200224b8:	2001      	movs	r0, #1
200224ba:	4770      	bx	lr

200224bc <HAL_FLASH_WRITE_ABYTE>:
200224bc:	b108      	cbz	r0, 200224c2 <HAL_FLASH_WRITE_ABYTE+0x6>
200224be:	6803      	ldr	r3, [r0, #0]
200224c0:	6219      	str	r1, [r3, #32]
200224c2:	4770      	bx	lr

200224c4 <HAL_FLASH_IS_CMD_DONE>:
200224c4:	b118      	cbz	r0, 200224ce <HAL_FLASH_IS_CMD_DONE+0xa>
200224c6:	6803      	ldr	r3, [r0, #0]
200224c8:	6918      	ldr	r0, [r3, #16]
200224ca:	f000 0001 	and.w	r0, r0, #1
200224ce:	4770      	bx	lr

200224d0 <HAL_FLASH_CLR_CMD_DONE>:
200224d0:	b120      	cbz	r0, 200224dc <HAL_FLASH_CLR_CMD_DONE+0xc>
200224d2:	6802      	ldr	r2, [r0, #0]
200224d4:	6953      	ldr	r3, [r2, #20]
200224d6:	f043 0301 	orr.w	r3, r3, #1
200224da:	6153      	str	r3, [r2, #20]
200224dc:	4770      	bx	lr

200224de <HAL_FLASH_SET_CMD>:
200224de:	b538      	push	{r3, r4, r5, lr}
200224e0:	460d      	mov	r5, r1
200224e2:	4604      	mov	r4, r0
200224e4:	b1a8      	cbz	r0, 20022512 <HAL_FLASH_SET_CMD+0x34>
200224e6:	6803      	ldr	r3, [r0, #0]
200224e8:	61da      	str	r2, [r3, #28]
200224ea:	6b43      	ldr	r3, [r0, #52]	@ 0x34
200224ec:	b10b      	cbz	r3, 200224f2 <HAL_FLASH_SET_CMD+0x14>
200224ee:	2001      	movs	r0, #1
200224f0:	4798      	blx	r3
200224f2:	6823      	ldr	r3, [r4, #0]
200224f4:	619d      	str	r5, [r3, #24]
200224f6:	4620      	mov	r0, r4
200224f8:	f7ff ffe4 	bl	200224c4 <HAL_FLASH_IS_CMD_DONE>
200224fc:	2800      	cmp	r0, #0
200224fe:	d0fa      	beq.n	200224f6 <HAL_FLASH_SET_CMD+0x18>
20022500:	4620      	mov	r0, r4
20022502:	f7ff ffe5 	bl	200224d0 <HAL_FLASH_CLR_CMD_DONE>
20022506:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20022508:	b10b      	cbz	r3, 2002250e <HAL_FLASH_SET_CMD+0x30>
2002250a:	2000      	movs	r0, #0
2002250c:	4798      	blx	r3
2002250e:	2000      	movs	r0, #0
20022510:	bd38      	pop	{r3, r4, r5, pc}
20022512:	2001      	movs	r0, #1
20022514:	e7fc      	b.n	20022510 <HAL_FLASH_SET_CMD+0x32>

20022516 <HAL_FLASH_CLR_STATUS>:
20022516:	b118      	cbz	r0, 20022520 <HAL_FLASH_CLR_STATUS+0xa>
20022518:	6802      	ldr	r2, [r0, #0]
2002251a:	6953      	ldr	r3, [r2, #20]
2002251c:	4319      	orrs	r1, r3
2002251e:	6151      	str	r1, [r2, #20]
20022520:	4770      	bx	lr

20022522 <HAL_FLASH_STATUS_MATCH>:
20022522:	b118      	cbz	r0, 2002252c <HAL_FLASH_STATUS_MATCH+0xa>
20022524:	6803      	ldr	r3, [r0, #0]
20022526:	6918      	ldr	r0, [r3, #16]
20022528:	f3c0 00c0 	ubfx	r0, r0, #3, #1
2002252c:	4770      	bx	lr

2002252e <HAL_FLASH_IS_PROG_DONE>:
2002252e:	b128      	cbz	r0, 2002253c <HAL_FLASH_IS_PROG_DONE+0xe>
20022530:	6803      	ldr	r3, [r0, #0]
20022532:	6858      	ldr	r0, [r3, #4]
20022534:	43c0      	mvns	r0, r0
20022536:	f000 0001 	and.w	r0, r0, #1
2002253a:	4770      	bx	lr
2002253c:	2001      	movs	r0, #1
2002253e:	4770      	bx	lr

20022540 <HAL_FLASH_READ32>:
20022540:	b108      	cbz	r0, 20022546 <HAL_FLASH_READ32+0x6>
20022542:	6803      	ldr	r3, [r0, #0]
20022544:	6858      	ldr	r0, [r3, #4]
20022546:	4770      	bx	lr

20022548 <HAL_FLASH_SET_TXSLOT>:
20022548:	b120      	cbz	r0, 20022554 <HAL_FLASH_SET_TXSLOT+0xc>
2002254a:	6802      	ldr	r2, [r0, #0]
2002254c:	6d53      	ldr	r3, [r2, #84]	@ 0x54
2002254e:	f361 238e 	bfi	r3, r1, #10, #5
20022552:	6553      	str	r3, [r2, #84]	@ 0x54
20022554:	4770      	bx	lr

20022556 <HAL_FLASH_SET_CLK_rom>:
20022556:	b108      	cbz	r0, 2002255c <HAL_FLASH_SET_CLK_rom+0x6>
20022558:	6803      	ldr	r3, [r0, #0]
2002255a:	60d9      	str	r1, [r3, #12]
2002255c:	4770      	bx	lr

2002255e <HAL_FLASH_GET_DIV>:
2002255e:	b110      	cbz	r0, 20022566 <HAL_FLASH_GET_DIV+0x8>
20022560:	6803      	ldr	r3, [r0, #0]
20022562:	68d8      	ldr	r0, [r3, #12]
20022564:	b2c0      	uxtb	r0, r0
20022566:	4770      	bx	lr

20022568 <HAL_FLASH_MANUAL_CMD>:
20022568:	b570      	push	{r4, r5, r6, lr}
2002256a:	b1e8      	cbz	r0, 200225a8 <HAL_FLASH_MANUAL_CMD+0x40>
2002256c:	6805      	ldr	r5, [r0, #0]
2002256e:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022572:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022576:	6aac      	ldr	r4, [r5, #40]	@ 0x28
20022578:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002257c:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022580:	f36f 0415 	bfc	r4, #0, #22
20022584:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022588:	f99d 6014 	ldrsb.w	r6, [sp, #20]
2002258c:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
20022590:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022594:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022598:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
2002259c:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200225a0:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200225a4:	4321      	orrs	r1, r4
200225a6:	62a9      	str	r1, [r5, #40]	@ 0x28
200225a8:	bd70      	pop	{r4, r5, r6, pc}

200225aa <HAL_FLASH_MANUAL_CMD2>:
200225aa:	b570      	push	{r4, r5, r6, lr}
200225ac:	b1e8      	cbz	r0, 200225ea <HAL_FLASH_MANUAL_CMD2+0x40>
200225ae:	6805      	ldr	r5, [r0, #0]
200225b0:	f99d 601c 	ldrsb.w	r6, [sp, #28]
200225b4:	f99d 0020 	ldrsb.w	r0, [sp, #32]
200225b8:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
200225ba:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200225be:	f99d 6010 	ldrsb.w	r6, [sp, #16]
200225c2:	f36f 0415 	bfc	r4, #0, #22
200225c6:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
200225ca:	f99d 6014 	ldrsb.w	r6, [sp, #20]
200225ce:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
200225d2:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200225d6:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
200225da:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
200225de:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200225e2:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200225e6:	4321      	orrs	r1, r4
200225e8:	63e9      	str	r1, [r5, #60]	@ 0x3c
200225ea:	bd70      	pop	{r4, r5, r6, pc}

200225ec <HAL_FLASH_SET_ALIAS_RANGE>:
200225ec:	b510      	push	{r4, lr}
200225ee:	b158      	cbz	r0, 20022608 <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
200225f0:	4b06      	ldr	r3, [pc, #24]	@ (2002260c <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
200225f2:	6804      	ldr	r4, [r0, #0]
200225f4:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
200225f8:	440a      	add	r2, r1
200225fa:	4019      	ands	r1, r3
200225fc:	6761      	str	r1, [r4, #116]	@ 0x74
200225fe:	401a      	ands	r2, r3
20022600:	6803      	ldr	r3, [r0, #0]
20022602:	2000      	movs	r0, #0
20022604:	679a      	str	r2, [r3, #120]	@ 0x78
20022606:	bd10      	pop	{r4, pc}
20022608:	2001      	movs	r0, #1
2002260a:	e7fc      	b.n	20022606 <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
2002260c:	fffffc00 	.word	0xfffffc00

20022610 <HAL_FLASH_SET_ALIAS_OFFSET>:
20022610:	b128      	cbz	r0, 2002261e <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
20022612:	6803      	ldr	r3, [r0, #0]
20022614:	f36f 0109 	bfc	r1, #0, #10
20022618:	2000      	movs	r0, #0
2002261a:	67d9      	str	r1, [r3, #124]	@ 0x7c
2002261c:	4770      	bx	lr
2002261e:	2001      	movs	r0, #1
20022620:	4770      	bx	lr

20022622 <HAL_FLASH_ENABLE_QSPI>:
20022622:	b150      	cbz	r0, 2002263a <HAL_FLASH_ENABLE_QSPI+0x18>
20022624:	6803      	ldr	r3, [r0, #0]
20022626:	681a      	ldr	r2, [r3, #0]
20022628:	b121      	cbz	r1, 20022634 <HAL_FLASH_ENABLE_QSPI+0x12>
2002262a:	f042 0201 	orr.w	r2, r2, #1
2002262e:	2000      	movs	r0, #0
20022630:	601a      	str	r2, [r3, #0]
20022632:	4770      	bx	lr
20022634:	f022 0201 	bic.w	r2, r2, #1
20022638:	e7f9      	b.n	2002262e <HAL_FLASH_ENABLE_QSPI+0xc>
2002263a:	2001      	movs	r0, #1
2002263c:	4770      	bx	lr

2002263e <HAL_FLASH_ENABLE_OPI>:
2002263e:	b150      	cbz	r0, 20022656 <HAL_FLASH_ENABLE_OPI+0x18>
20022640:	6803      	ldr	r3, [r0, #0]
20022642:	681a      	ldr	r2, [r3, #0]
20022644:	b121      	cbz	r1, 20022650 <HAL_FLASH_ENABLE_OPI+0x12>
20022646:	f442 1200 	orr.w	r2, r2, #2097152	@ 0x200000
2002264a:	2000      	movs	r0, #0
2002264c:	601a      	str	r2, [r3, #0]
2002264e:	4770      	bx	lr
20022650:	f422 1200 	bic.w	r2, r2, #2097152	@ 0x200000
20022654:	e7f9      	b.n	2002264a <HAL_FLASH_ENABLE_OPI+0xc>
20022656:	2001      	movs	r0, #1
20022658:	4770      	bx	lr

2002265a <HAL_FLASH_ENABLE_HYPER>:
2002265a:	b148      	cbz	r0, 20022670 <HAL_FLASH_ENABLE_HYPER+0x16>
2002265c:	6802      	ldr	r2, [r0, #0]
2002265e:	6893      	ldr	r3, [r2, #8]
20022660:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
20022664:	b109      	cbz	r1, 2002266a <HAL_FLASH_ENABLE_HYPER+0x10>
20022666:	f043 0320 	orr.w	r3, r3, #32
2002266a:	2000      	movs	r0, #0
2002266c:	6093      	str	r3, [r2, #8]
2002266e:	4770      	bx	lr
20022670:	2001      	movs	r0, #1
20022672:	4770      	bx	lr

20022674 <HAL_FLASH_ENABLE_CMD2>:
20022674:	b150      	cbz	r0, 2002268c <HAL_FLASH_ENABLE_CMD2+0x18>
20022676:	6803      	ldr	r3, [r0, #0]
20022678:	681a      	ldr	r2, [r3, #0]
2002267a:	b121      	cbz	r1, 20022686 <HAL_FLASH_ENABLE_CMD2+0x12>
2002267c:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
20022680:	2000      	movs	r0, #0
20022682:	601a      	str	r2, [r3, #0]
20022684:	4770      	bx	lr
20022686:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
2002268a:	e7f9      	b.n	20022680 <HAL_FLASH_ENABLE_CMD2+0xc>
2002268c:	2001      	movs	r0, #1
2002268e:	4770      	bx	lr

20022690 <HAL_FLASH_STAUS_MATCH_CMD2>:
20022690:	b150      	cbz	r0, 200226a8 <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
20022692:	6803      	ldr	r3, [r0, #0]
20022694:	681a      	ldr	r2, [r3, #0]
20022696:	b121      	cbz	r1, 200226a2 <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
20022698:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
2002269c:	2000      	movs	r0, #0
2002269e:	601a      	str	r2, [r3, #0]
200226a0:	4770      	bx	lr
200226a2:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
200226a6:	e7f9      	b.n	2002269c <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
200226a8:	2001      	movs	r0, #1
200226aa:	4770      	bx	lr

200226ac <HAL_FLASH_SET_CS_TIME>:
200226ac:	b530      	push	{r4, r5, lr}
200226ae:	b180      	cbz	r0, 200226d2 <HAL_FLASH_SET_CS_TIME+0x26>
200226b0:	6805      	ldr	r5, [r0, #0]
200226b2:	f8bd 000c 	ldrh.w	r0, [sp, #12]
200226b6:	68ac      	ldr	r4, [r5, #8]
200226b8:	0680      	lsls	r0, r0, #26
200226ba:	ea40 5383 	orr.w	r3, r0, r3, lsl #22
200226be:	2000      	movs	r0, #0
200226c0:	ea43 4181 	orr.w	r1, r3, r1, lsl #18
200226c4:	f36f 149e 	bfc	r4, #6, #25
200226c8:	ea41 1282 	orr.w	r2, r1, r2, lsl #6
200226cc:	4322      	orrs	r2, r4
200226ce:	60aa      	str	r2, [r5, #8]
200226d0:	bd30      	pop	{r4, r5, pc}
200226d2:	2001      	movs	r0, #1
200226d4:	e7fc      	b.n	200226d0 <HAL_FLASH_SET_CS_TIME+0x24>

200226d6 <HAL_FLASH_SET_ROW_BOUNDARY>:
200226d6:	b130      	cbz	r0, 200226e6 <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
200226d8:	6802      	ldr	r2, [r0, #0]
200226da:	2000      	movs	r0, #0
200226dc:	6893      	ldr	r3, [r2, #8]
200226de:	f361 0302 	bfi	r3, r1, #0, #3
200226e2:	6093      	str	r3, [r2, #8]
200226e4:	4770      	bx	lr
200226e6:	2001      	movs	r0, #1
200226e8:	4770      	bx	lr

200226ea <HAL_FLASH_SET_LEGACY>:
200226ea:	b148      	cbz	r0, 20022700 <HAL_FLASH_SET_LEGACY+0x16>
200226ec:	6802      	ldr	r2, [r0, #0]
200226ee:	6893      	ldr	r3, [r2, #8]
200226f0:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
200226f4:	b109      	cbz	r1, 200226fa <HAL_FLASH_SET_LEGACY+0x10>
200226f6:	f043 0310 	orr.w	r3, r3, #16
200226fa:	2000      	movs	r0, #0
200226fc:	6093      	str	r3, [r2, #8]
200226fe:	4770      	bx	lr
20022700:	2001      	movs	r0, #1
20022702:	4770      	bx	lr

20022704 <HAL_FLASH_SET_DUAL_MODE>:
20022704:	b150      	cbz	r0, 2002271c <HAL_FLASH_SET_DUAL_MODE+0x18>
20022706:	6803      	ldr	r3, [r0, #0]
20022708:	681a      	ldr	r2, [r3, #0]
2002270a:	b121      	cbz	r1, 20022716 <HAL_FLASH_SET_DUAL_MODE+0x12>
2002270c:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
20022710:	2000      	movs	r0, #0
20022712:	601a      	str	r2, [r3, #0]
20022714:	4770      	bx	lr
20022716:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
2002271a:	e7f9      	b.n	20022710 <HAL_FLASH_SET_DUAL_MODE+0xc>
2002271c:	2001      	movs	r0, #1
2002271e:	4770      	bx	lr

20022720 <HAL_FLASH_SET_X16_MODE>:
20022720:	b150      	cbz	r0, 20022738 <HAL_FLASH_SET_X16_MODE+0x18>
20022722:	6803      	ldr	r3, [r0, #0]
20022724:	681a      	ldr	r2, [r3, #0]
20022726:	b121      	cbz	r1, 20022732 <HAL_FLASH_SET_X16_MODE+0x12>
20022728:	f442 0200 	orr.w	r2, r2, #8388608	@ 0x800000
2002272c:	2000      	movs	r0, #0
2002272e:	601a      	str	r2, [r3, #0]
20022730:	4770      	bx	lr
20022732:	f422 0200 	bic.w	r2, r2, #8388608	@ 0x800000
20022736:	e7f9      	b.n	2002272c <HAL_FLASH_SET_X16_MODE+0xc>
20022738:	2001      	movs	r0, #1
2002273a:	4770      	bx	lr

2002273c <HAL_MPI_EN_FIXLAT>:
2002273c:	2000      	movs	r0, #0
2002273e:	4770      	bx	lr

20022740 <HAL_MPI_ENABLE_DQS>:
20022740:	fab0 f080 	clz	r0, r0
20022744:	0940      	lsrs	r0, r0, #5
20022746:	4770      	bx	lr

20022748 <HAL_MPI_SET_DQS_DELAY>:
20022748:	b138      	cbz	r0, 2002275a <HAL_MPI_SET_DQS_DELAY+0x12>
2002274a:	6802      	ldr	r2, [r0, #0]
2002274c:	2000      	movs	r0, #0
2002274e:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022750:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
20022754:	4319      	orrs	r1, r3
20022756:	6591      	str	r1, [r2, #88]	@ 0x58
20022758:	4770      	bx	lr
2002275a:	2001      	movs	r0, #1
2002275c:	4770      	bx	lr

2002275e <HAL_MPI_SET_SCK>:
2002275e:	b150      	cbz	r0, 20022776 <HAL_MPI_SET_SCK+0x18>
20022760:	6800      	ldr	r0, [r0, #0]
20022762:	0412      	lsls	r2, r2, #16
20022764:	6d83      	ldr	r3, [r0, #88]	@ 0x58
20022766:	ea42 2101 	orr.w	r1, r2, r1, lsl #8
2002276a:	f36f 2310 	bfc	r3, #8, #9
2002276e:	4319      	orrs	r1, r3
20022770:	6581      	str	r1, [r0, #88]	@ 0x58
20022772:	2000      	movs	r0, #0
20022774:	4770      	bx	lr
20022776:	2001      	movs	r0, #1
20022778:	4770      	bx	lr

2002277a <HAL_MPI_CFG_DTR>:
2002277a:	6803      	ldr	r3, [r0, #0]
2002277c:	6d9a      	ldr	r2, [r3, #88]	@ 0x58
2002277e:	b121      	cbz	r1, 2002278a <HAL_MPI_CFG_DTR+0x10>
20022780:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
20022784:	2000      	movs	r0, #0
20022786:	659a      	str	r2, [r3, #88]	@ 0x58
20022788:	4770      	bx	lr
2002278a:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
2002278e:	e7f9      	b.n	20022784 <HAL_MPI_CFG_DTR+0xa>

20022790 <HAL_MPI_MODIFY_RCMD_DELAY>:
20022790:	b130      	cbz	r0, 200227a0 <HAL_MPI_MODIFY_RCMD_DELAY+0x10>
20022792:	6802      	ldr	r2, [r0, #0]
20022794:	6c93      	ldr	r3, [r2, #72]	@ 0x48
20022796:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
2002279a:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
2002279e:	6491      	str	r1, [r2, #72]	@ 0x48
200227a0:	4770      	bx	lr

200227a2 <HAL_MPI_MODIFY_WCMD_DELAY>:
200227a2:	b130      	cbz	r0, 200227b2 <HAL_MPI_MODIFY_WCMD_DELAY+0x10>
200227a4:	6802      	ldr	r2, [r0, #0]
200227a6:	6d13      	ldr	r3, [r2, #80]	@ 0x50
200227a8:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
200227ac:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
200227b0:	6511      	str	r1, [r2, #80]	@ 0x50
200227b2:	4770      	bx	lr

200227b4 <HAL_FLASH_SET_WDT>:
200227b4:	b148      	cbz	r0, 200227ca <HAL_FLASH_SET_WDT+0x16>
200227b6:	6803      	ldr	r3, [r0, #0]
200227b8:	f8d3 2090 	ldr.w	r2, [r3, #144]	@ 0x90
200227bc:	b109      	cbz	r1, 200227c2 <HAL_FLASH_SET_WDT+0xe>
200227be:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
200227c2:	2000      	movs	r0, #0
200227c4:	f8c3 1090 	str.w	r1, [r3, #144]	@ 0x90
200227c8:	4770      	bx	lr
200227ca:	2001      	movs	r0, #1
200227cc:	4770      	bx	lr

200227ce <HAL_FLASH_CONFIG_AHB_READ>:
200227ce:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200227d0:	4605      	mov	r5, r0
200227d2:	2800      	cmp	r0, #0
200227d4:	d03d      	beq.n	20022852 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200227d6:	68c4      	ldr	r4, [r0, #12]
200227d8:	b301      	cbz	r1, 2002281c <HAL_FLASH_CONFIG_AHB_READ+0x4e>
200227da:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
200227de:	2b00      	cmp	r3, #0
200227e0:	d037      	beq.n	20022852 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200227e2:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
200227e6:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
200227ea:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
200227ee:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
200227f2:	9603      	str	r6, [sp, #12]
200227f4:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
200227f8:	9602      	str	r6, [sp, #8]
200227fa:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
200227fe:	9601      	str	r6, [sp, #4]
20022800:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
20022804:	9400      	str	r4, [sp, #0]
20022806:	f7ff fdf8 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
2002280a:	68eb      	ldr	r3, [r5, #12]
2002280c:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
20022810:	4628      	mov	r0, r5
20022812:	f7ff fde7 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
20022816:	2000      	movs	r0, #0
20022818:	b004      	add	sp, #16
2002281a:	bd70      	pop	{r4, r5, r6, pc}
2002281c:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
20022820:	b1bb      	cbz	r3, 20022852 <HAL_FLASH_CONFIG_AHB_READ+0x84>
20022822:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
20022826:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
2002282a:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
2002282e:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
20022832:	9603      	str	r6, [sp, #12]
20022834:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
20022838:	9602      	str	r6, [sp, #8]
2002283a:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
2002283e:	9601      	str	r6, [sp, #4]
20022840:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
20022844:	9400      	str	r4, [sp, #0]
20022846:	f7ff fdd8 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
2002284a:	68eb      	ldr	r3, [r5, #12]
2002284c:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20022850:	e7de      	b.n	20022810 <HAL_FLASH_CONFIG_AHB_READ+0x42>
20022852:	2001      	movs	r0, #1
20022854:	e7e0      	b.n	20022818 <HAL_FLASH_CONFIG_AHB_READ+0x4a>

20022856 <HAL_FLASH_CONFIG_FULL_AHB_READ>:
20022856:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20022858:	4605      	mov	r5, r0
2002285a:	2800      	cmp	r0, #0
2002285c:	d036      	beq.n	200228cc <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
2002285e:	68c4      	ldr	r4, [r0, #12]
20022860:	b1e1      	cbz	r1, 2002289c <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
20022862:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
20022866:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
2002286a:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
2002286e:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
20022872:	9603      	str	r6, [sp, #12]
20022874:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
20022878:	9602      	str	r6, [sp, #8]
2002287a:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
2002287e:	9601      	str	r6, [sp, #4]
20022880:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
20022884:	9400      	str	r4, [sp, #0]
20022886:	f7ff fdb8 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
2002288a:	68eb      	ldr	r3, [r5, #12]
2002288c:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
20022890:	4628      	mov	r0, r5
20022892:	f7ff fda7 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
20022896:	2000      	movs	r0, #0
20022898:	b004      	add	sp, #16
2002289a:	bd70      	pop	{r4, r5, r6, pc}
2002289c:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
200228a0:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
200228a4:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
200228a8:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
200228ac:	9603      	str	r6, [sp, #12]
200228ae:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
200228b2:	9602      	str	r6, [sp, #8]
200228b4:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
200228b8:	9601      	str	r6, [sp, #4]
200228ba:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
200228be:	9400      	str	r4, [sp, #0]
200228c0:	f7ff fd9b 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
200228c4:	68eb      	ldr	r3, [r5, #12]
200228c6:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
200228ca:	e7e1      	b.n	20022890 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
200228cc:	2001      	movs	r0, #1
200228ce:	e7e3      	b.n	20022898 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

200228d0 <HAL_FLASH_PRE_CMD>:
200228d0:	b530      	push	{r4, r5, lr}
200228d2:	68c4      	ldr	r4, [r0, #12]
200228d4:	b087      	sub	sp, #28
200228d6:	b304      	cbz	r4, 2002291a <HAL_FLASH_PRE_CMD+0x4a>
200228d8:	2938      	cmp	r1, #56	@ 0x38
200228da:	d81e      	bhi.n	2002291a <HAL_FLASH_PRE_CMD+0x4a>
200228dc:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
200228e0:	440c      	add	r4, r1
200228e2:	7c23      	ldrb	r3, [r4, #16]
200228e4:	b1cb      	cbz	r3, 2002291a <HAL_FLASH_PRE_CMD+0x4a>
200228e6:	f994 5018 	ldrsb.w	r5, [r4, #24]
200228ea:	f994 3013 	ldrsb.w	r3, [r4, #19]
200228ee:	f994 2012 	ldrsb.w	r2, [r4, #18]
200228f2:	f994 1011 	ldrsb.w	r1, [r4, #17]
200228f6:	9504      	str	r5, [sp, #16]
200228f8:	f994 5017 	ldrsb.w	r5, [r4, #23]
200228fc:	9503      	str	r5, [sp, #12]
200228fe:	f994 5016 	ldrsb.w	r5, [r4, #22]
20022902:	9502      	str	r5, [sp, #8]
20022904:	f994 5015 	ldrsb.w	r5, [r4, #21]
20022908:	9501      	str	r5, [sp, #4]
2002290a:	f994 4014 	ldrsb.w	r4, [r4, #20]
2002290e:	9400      	str	r4, [sp, #0]
20022910:	f7ff fe2a 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20022914:	2000      	movs	r0, #0
20022916:	b007      	add	sp, #28
20022918:	bd30      	pop	{r4, r5, pc}
2002291a:	2001      	movs	r0, #1
2002291c:	e7fb      	b.n	20022916 <HAL_FLASH_PRE_CMD+0x46>

2002291e <HAL_FLASH_ISSUE_CMD>:
2002291e:	b5f0      	push	{r4, r5, r6, r7, lr}
20022920:	68c4      	ldr	r4, [r0, #12]
20022922:	4606      	mov	r6, r0
20022924:	4617      	mov	r7, r2
20022926:	b087      	sub	sp, #28
20022928:	b354      	cbz	r4, 20022980 <HAL_FLASH_ISSUE_CMD+0x62>
2002292a:	2938      	cmp	r1, #56	@ 0x38
2002292c:	d828      	bhi.n	20022980 <HAL_FLASH_ISSUE_CMD+0x62>
2002292e:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
20022932:	442c      	add	r4, r5
20022934:	7c23      	ldrb	r3, [r4, #16]
20022936:	b31b      	cbz	r3, 20022980 <HAL_FLASH_ISSUE_CMD+0x62>
20022938:	f994 c018 	ldrsb.w	ip, [r4, #24]
2002293c:	f994 3013 	ldrsb.w	r3, [r4, #19]
20022940:	f994 2012 	ldrsb.w	r2, [r4, #18]
20022944:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022948:	f8cd c010 	str.w	ip, [sp, #16]
2002294c:	f994 c017 	ldrsb.w	ip, [r4, #23]
20022950:	f8cd c00c 	str.w	ip, [sp, #12]
20022954:	f994 c016 	ldrsb.w	ip, [r4, #22]
20022958:	f8cd c008 	str.w	ip, [sp, #8]
2002295c:	f994 c015 	ldrsb.w	ip, [r4, #21]
20022960:	f8cd c004 	str.w	ip, [sp, #4]
20022964:	f994 4014 	ldrsb.w	r4, [r4, #20]
20022968:	9400      	str	r4, [sp, #0]
2002296a:	f7ff fdfd 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
2002296e:	68f3      	ldr	r3, [r6, #12]
20022970:	463a      	mov	r2, r7
20022972:	442b      	add	r3, r5
20022974:	4630      	mov	r0, r6
20022976:	7c19      	ldrb	r1, [r3, #16]
20022978:	f7ff fdb1 	bl	200224de <HAL_FLASH_SET_CMD>
2002297c:	b007      	add	sp, #28
2002297e:	bdf0      	pop	{r4, r5, r6, r7, pc}
20022980:	2001      	movs	r0, #1
20022982:	e7fb      	b.n	2002297c <HAL_FLASH_ISSUE_CMD+0x5e>

20022984 <HAL_FLASH_ISSUE_CMD_SEQ>:
20022984:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20022988:	4690      	mov	r8, r2
2002298a:	68c2      	ldr	r2, [r0, #12]
2002298c:	4604      	mov	r4, r0
2002298e:	b086      	sub	sp, #24
20022990:	2a00      	cmp	r2, #0
20022992:	d073      	beq.n	20022a7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022994:	2938      	cmp	r1, #56	@ 0x38
20022996:	d871      	bhi.n	20022a7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022998:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
2002299c:	19d6      	adds	r6, r2, r7
2002299e:	7c31      	ldrb	r1, [r6, #16]
200229a0:	2900      	cmp	r1, #0
200229a2:	d06b      	beq.n	20022a7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229a4:	2b38      	cmp	r3, #56	@ 0x38
200229a6:	d869      	bhi.n	20022a7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229a8:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
200229ac:	442a      	add	r2, r5
200229ae:	7c13      	ldrb	r3, [r2, #16]
200229b0:	2b00      	cmp	r3, #0
200229b2:	d063      	beq.n	20022a7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229b4:	f996 c018 	ldrsb.w	ip, [r6, #24]
200229b8:	f996 3013 	ldrsb.w	r3, [r6, #19]
200229bc:	f996 2012 	ldrsb.w	r2, [r6, #18]
200229c0:	f996 1011 	ldrsb.w	r1, [r6, #17]
200229c4:	f8cd c010 	str.w	ip, [sp, #16]
200229c8:	f996 c017 	ldrsb.w	ip, [r6, #23]
200229cc:	f8cd c00c 	str.w	ip, [sp, #12]
200229d0:	f996 c016 	ldrsb.w	ip, [r6, #22]
200229d4:	f8cd c008 	str.w	ip, [sp, #8]
200229d8:	f996 c015 	ldrsb.w	ip, [r6, #21]
200229dc:	f8cd c004 	str.w	ip, [sp, #4]
200229e0:	f996 6014 	ldrsb.w	r6, [r6, #20]
200229e4:	9600      	str	r6, [sp, #0]
200229e6:	f7ff fdbf 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
200229ea:	68e0      	ldr	r0, [r4, #12]
200229ec:	4428      	add	r0, r5
200229ee:	f990 6018 	ldrsb.w	r6, [r0, #24]
200229f2:	f990 3013 	ldrsb.w	r3, [r0, #19]
200229f6:	f990 2012 	ldrsb.w	r2, [r0, #18]
200229fa:	f990 1011 	ldrsb.w	r1, [r0, #17]
200229fe:	9604      	str	r6, [sp, #16]
20022a00:	f990 6017 	ldrsb.w	r6, [r0, #23]
20022a04:	9603      	str	r6, [sp, #12]
20022a06:	f990 6016 	ldrsb.w	r6, [r0, #22]
20022a0a:	9602      	str	r6, [sp, #8]
20022a0c:	f990 6015 	ldrsb.w	r6, [r0, #21]
20022a10:	9601      	str	r6, [sp, #4]
20022a12:	f990 0014 	ldrsb.w	r0, [r0, #20]
20022a16:	9000      	str	r0, [sp, #0]
20022a18:	4620      	mov	r0, r4
20022a1a:	f7ff fdc6 	bl	200225aa <HAL_FLASH_MANUAL_CMD2>
20022a1e:	2200      	movs	r2, #0
20022a20:	6823      	ldr	r3, [r4, #0]
20022a22:	2101      	movs	r1, #1
20022a24:	f8c3 2084 	str.w	r2, [r3, #132]	@ 0x84
20022a28:	68e3      	ldr	r3, [r4, #12]
20022a2a:	6822      	ldr	r2, [r4, #0]
20022a2c:	442b      	add	r3, r5
20022a2e:	7c1b      	ldrb	r3, [r3, #16]
20022a30:	4620      	mov	r0, r4
20022a32:	62d3      	str	r3, [r2, #44]	@ 0x2c
20022a34:	6823      	ldr	r3, [r4, #0]
20022a36:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
20022a38:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20022a3c:	f7ff fe1a 	bl	20022674 <HAL_FLASH_ENABLE_CMD2>
20022a40:	4620      	mov	r0, r4
20022a42:	f7ff fe25 	bl	20022690 <HAL_FLASH_STAUS_MATCH_CMD2>
20022a46:	6823      	ldr	r3, [r4, #0]
20022a48:	f8c3 801c 	str.w	r8, [r3, #28]
20022a4c:	68e3      	ldr	r3, [r4, #12]
20022a4e:	6822      	ldr	r2, [r4, #0]
20022a50:	443b      	add	r3, r7
20022a52:	7c1b      	ldrb	r3, [r3, #16]
20022a54:	6193      	str	r3, [r2, #24]
20022a56:	4620      	mov	r0, r4
20022a58:	f7ff fd63 	bl	20022522 <HAL_FLASH_STATUS_MATCH>
20022a5c:	2800      	cmp	r0, #0
20022a5e:	d0fa      	beq.n	20022a56 <HAL_FLASH_ISSUE_CMD_SEQ+0xd2>
20022a60:	2109      	movs	r1, #9
20022a62:	4620      	mov	r0, r4
20022a64:	f7ff fd57 	bl	20022516 <HAL_FLASH_CLR_STATUS>
20022a68:	2100      	movs	r1, #0
20022a6a:	f7ff fe03 	bl	20022674 <HAL_FLASH_ENABLE_CMD2>
20022a6e:	4620      	mov	r0, r4
20022a70:	f7ff fe0e 	bl	20022690 <HAL_FLASH_STAUS_MATCH_CMD2>
20022a74:	4608      	mov	r0, r1
20022a76:	b006      	add	sp, #24
20022a78:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022a7c:	2001      	movs	r0, #1
20022a7e:	e7fa      	b.n	20022a76 <HAL_FLASH_ISSUE_CMD_SEQ+0xf2>

20022a80 <nor_qspi_switch>:
20022a80:	b570      	push	{r4, r5, r6, lr}
20022a82:	4604      	mov	r4, r0
20022a84:	b3e0      	cbz	r0, 20022b00 <nor_qspi_switch+0x80>
20022a86:	68c3      	ldr	r3, [r0, #12]
20022a88:	b3d3      	cbz	r3, 20022b00 <nor_qspi_switch+0x80>
20022a8a:	b3c9      	cbz	r1, 20022b00 <nor_qspi_switch+0x80>
20022a8c:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022a90:	2101      	movs	r1, #1
20022a92:	b3b5      	cbz	r5, 20022b02 <nor_qspi_switch+0x82>
20022a94:	f7ff fcfe 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022a98:	2200      	movs	r2, #0
20022a9a:	2114      	movs	r1, #20
20022a9c:	4620      	mov	r0, r4
20022a9e:	f7ff ff3e 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022aa2:	4620      	mov	r0, r4
20022aa4:	f7ff fd4c 	bl	20022540 <HAL_FLASH_READ32>
20022aa8:	f010 0501 	ands.w	r5, r0, #1
20022aac:	d000      	beq.n	20022ab0 <nor_qspi_switch+0x30>
20022aae:	e7fe      	b.n	20022aae <nor_qspi_switch+0x2e>
20022ab0:	462a      	mov	r2, r5
20022ab2:	2115      	movs	r1, #21
20022ab4:	4620      	mov	r0, r4
20022ab6:	f7ff ff32 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022aba:	4606      	mov	r6, r0
20022abc:	b120      	cbz	r0, 20022ac8 <nor_qspi_switch+0x48>
20022abe:	462a      	mov	r2, r5
20022ac0:	4629      	mov	r1, r5
20022ac2:	4620      	mov	r0, r4
20022ac4:	f7ff ff2b 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022ac8:	2102      	movs	r1, #2
20022aca:	4620      	mov	r0, r4
20022acc:	f7ff fcdb 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20022ad0:	2101      	movs	r1, #1
20022ad2:	4620      	mov	r0, r4
20022ad4:	f7ff fcde 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022ad8:	2200      	movs	r2, #0
20022ada:	212b      	movs	r1, #43	@ 0x2b
20022adc:	4620      	mov	r0, r4
20022ade:	f7ff ff1e 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022ae2:	b16e      	cbz	r6, 20022b00 <nor_qspi_switch+0x80>
20022ae4:	2101      	movs	r1, #1
20022ae6:	4620      	mov	r0, r4
20022ae8:	f7ff fcd4 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022aec:	2200      	movs	r2, #0
20022aee:	2102      	movs	r1, #2
20022af0:	4620      	mov	r0, r4
20022af2:	f7ff ff14 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022af6:	4620      	mov	r0, r4
20022af8:	f7ff fd19 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
20022afc:	2800      	cmp	r0, #0
20022afe:	d0f5      	beq.n	20022aec <nor_qspi_switch+0x6c>
20022b00:	bd70      	pop	{r4, r5, r6, pc}
20022b02:	f7ff fcc7 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022b06:	462a      	mov	r2, r5
20022b08:	2102      	movs	r1, #2
20022b0a:	4620      	mov	r0, r4
20022b0c:	f7ff ff07 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b10:	4620      	mov	r0, r4
20022b12:	f7ff fd15 	bl	20022540 <HAL_FLASH_READ32>
20022b16:	462a      	mov	r2, r5
20022b18:	2114      	movs	r1, #20
20022b1a:	4620      	mov	r0, r4
20022b1c:	f7ff feff 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b20:	b910      	cbnz	r0, 20022b28 <nor_qspi_switch+0xa8>
20022b22:	4620      	mov	r0, r4
20022b24:	f7ff fd0c 	bl	20022540 <HAL_FLASH_READ32>
20022b28:	68e3      	ldr	r3, [r4, #12]
20022b2a:	7a1b      	ldrb	r3, [r3, #8]
20022b2c:	b3ab      	cbz	r3, 20022b9a <nor_qspi_switch+0x11a>
20022b2e:	2101      	movs	r1, #1
20022b30:	f003 050f 	and.w	r5, r3, #15
20022b34:	091b      	lsrs	r3, r3, #4
20022b36:	fa01 f303 	lsl.w	r3, r1, r3
20022b3a:	b2db      	uxtb	r3, r3
20022b3c:	b10d      	cbz	r5, 20022b42 <nor_qspi_switch+0xc2>
20022b3e:	461d      	mov	r5, r3
20022b40:	2300      	movs	r3, #0
20022b42:	2200      	movs	r2, #0
20022b44:	2115      	movs	r1, #21
20022b46:	4620      	mov	r0, r4
20022b48:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
20022b4c:	f7ff fee7 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b50:	4606      	mov	r6, r0
20022b52:	b120      	cbz	r0, 20022b5e <nor_qspi_switch+0xde>
20022b54:	2200      	movs	r2, #0
20022b56:	4620      	mov	r0, r4
20022b58:	4611      	mov	r1, r2
20022b5a:	f7ff fee0 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b5e:	4629      	mov	r1, r5
20022b60:	4620      	mov	r0, r4
20022b62:	f7ff fc90 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20022b66:	2102      	movs	r1, #2
20022b68:	4620      	mov	r0, r4
20022b6a:	f7ff fc93 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022b6e:	2200      	movs	r2, #0
20022b70:	2103      	movs	r1, #3
20022b72:	4620      	mov	r0, r4
20022b74:	f7ff fed3 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b78:	2e00      	cmp	r6, #0
20022b7a:	d0c1      	beq.n	20022b00 <nor_qspi_switch+0x80>
20022b7c:	2101      	movs	r1, #1
20022b7e:	4620      	mov	r0, r4
20022b80:	f7ff fc88 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022b84:	2200      	movs	r2, #0
20022b86:	2102      	movs	r1, #2
20022b88:	4620      	mov	r0, r4
20022b8a:	f7ff fec8 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022b8e:	4620      	mov	r0, r4
20022b90:	f7ff fccd 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
20022b94:	2800      	cmp	r0, #0
20022b96:	d0f5      	beq.n	20022b84 <nor_qspi_switch+0x104>
20022b98:	e7b2      	b.n	20022b00 <nor_qspi_switch+0x80>
20022b9a:	2502      	movs	r5, #2
20022b9c:	e7d1      	b.n	20022b42 <nor_qspi_switch+0xc2>

20022b9e <HAL_FLASH_SET_QUAL_SPI>:
20022b9e:	b538      	push	{r3, r4, r5, lr}
20022ba0:	4604      	mov	r4, r0
20022ba2:	460d      	mov	r5, r1
20022ba4:	f7ff ff6c 	bl	20022a80 <nor_qspi_switch>
20022ba8:	4629      	mov	r1, r5
20022baa:	4620      	mov	r0, r4
20022bac:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022bb0:	f7ff be0d 	b.w	200227ce <HAL_FLASH_CONFIG_AHB_READ>

20022bb4 <HAL_FLASH_FADDR_SET_QSPI>:
20022bb4:	b538      	push	{r3, r4, r5, lr}
20022bb6:	4604      	mov	r4, r0
20022bb8:	460d      	mov	r5, r1
20022bba:	f7ff ff61 	bl	20022a80 <nor_qspi_switch>
20022bbe:	4629      	mov	r1, r5
20022bc0:	4620      	mov	r0, r4
20022bc2:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022bc6:	f7ff be46 	b.w	20022856 <HAL_FLASH_CONFIG_FULL_AHB_READ>

20022bca <HAL_FLASH_GET_NOR_ID>:
20022bca:	b510      	push	{r4, lr}
20022bcc:	4604      	mov	r4, r0
20022bce:	b140      	cbz	r0, 20022be2 <HAL_FLASH_GET_NOR_ID+0x18>
20022bd0:	6802      	ldr	r2, [r0, #0]
20022bd2:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022bd4:	f36f 0315 	bfc	r3, #0, #22
20022bd8:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
20022bdc:	f043 0301 	orr.w	r3, r3, #1
20022be0:	6293      	str	r3, [r2, #40]	@ 0x28
20022be2:	2103      	movs	r1, #3
20022be4:	4620      	mov	r0, r4
20022be6:	f7ff fc55 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022bea:	2200      	movs	r2, #0
20022bec:	219f      	movs	r1, #159	@ 0x9f
20022bee:	4620      	mov	r0, r4
20022bf0:	f7ff fc75 	bl	200224de <HAL_FLASH_SET_CMD>
20022bf4:	4620      	mov	r0, r4
20022bf6:	f7ff fca3 	bl	20022540 <HAL_FLASH_READ32>
20022bfa:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022bfe:	bd10      	pop	{r4, pc}

20022c00 <HAL_FLASH_CLR_PROTECT>:
20022c00:	b570      	push	{r4, r5, r6, lr}
20022c02:	4604      	mov	r4, r0
20022c04:	2800      	cmp	r0, #0
20022c06:	d03e      	beq.n	20022c86 <HAL_FLASH_CLR_PROTECT+0x86>
20022c08:	68c3      	ldr	r3, [r0, #12]
20022c0a:	2101      	movs	r1, #1
20022c0c:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022c10:	2d00      	cmp	r5, #0
20022c12:	d03b      	beq.n	20022c8c <HAL_FLASH_CLR_PROTECT+0x8c>
20022c14:	f7ff fc3e 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022c18:	2200      	movs	r2, #0
20022c1a:	2102      	movs	r1, #2
20022c1c:	4620      	mov	r0, r4
20022c1e:	f7ff fe7e 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c22:	bb88      	cbnz	r0, 20022c88 <HAL_FLASH_CLR_PROTECT+0x88>
20022c24:	4620      	mov	r0, r4
20022c26:	f7ff fc8b 	bl	20022540 <HAL_FLASH_READ32>
20022c2a:	b2c0      	uxtb	r0, r0
20022c2c:	68e3      	ldr	r3, [r4, #12]
20022c2e:	79dd      	ldrb	r5, [r3, #7]
20022c30:	b10d      	cbz	r5, 20022c36 <HAL_FLASH_CLR_PROTECT+0x36>
20022c32:	ea20 0505 	bic.w	r5, r0, r5
20022c36:	2200      	movs	r2, #0
20022c38:	2115      	movs	r1, #21
20022c3a:	4620      	mov	r0, r4
20022c3c:	f7ff fe6f 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c40:	4606      	mov	r6, r0
20022c42:	b120      	cbz	r0, 20022c4e <HAL_FLASH_CLR_PROTECT+0x4e>
20022c44:	2200      	movs	r2, #0
20022c46:	4620      	mov	r0, r4
20022c48:	4611      	mov	r1, r2
20022c4a:	f7ff fe68 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c4e:	4629      	mov	r1, r5
20022c50:	4620      	mov	r0, r4
20022c52:	f7ff fc18 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20022c56:	2101      	movs	r1, #1
20022c58:	4620      	mov	r0, r4
20022c5a:	f7ff fc1b 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022c5e:	2200      	movs	r2, #0
20022c60:	2103      	movs	r1, #3
20022c62:	4620      	mov	r0, r4
20022c64:	f7ff fe5b 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c68:	b16e      	cbz	r6, 20022c86 <HAL_FLASH_CLR_PROTECT+0x86>
20022c6a:	2101      	movs	r1, #1
20022c6c:	4620      	mov	r0, r4
20022c6e:	f7ff fc11 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022c72:	2200      	movs	r2, #0
20022c74:	2102      	movs	r1, #2
20022c76:	4620      	mov	r0, r4
20022c78:	f7ff fe51 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c7c:	4620      	mov	r0, r4
20022c7e:	f7ff fc56 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
20022c82:	2800      	cmp	r0, #0
20022c84:	d0f5      	beq.n	20022c72 <HAL_FLASH_CLR_PROTECT+0x72>
20022c86:	bd70      	pop	{r4, r5, r6, pc}
20022c88:	2000      	movs	r0, #0
20022c8a:	e7cf      	b.n	20022c2c <HAL_FLASH_CLR_PROTECT+0x2c>
20022c8c:	f7ff fc02 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022c90:	462a      	mov	r2, r5
20022c92:	2102      	movs	r1, #2
20022c94:	4620      	mov	r0, r4
20022c96:	f7ff fe42 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022c9a:	2800      	cmp	r0, #0
20022c9c:	d13e      	bne.n	20022d1c <HAL_FLASH_CLR_PROTECT+0x11c>
20022c9e:	4620      	mov	r0, r4
20022ca0:	f7ff fc4e 	bl	20022540 <HAL_FLASH_READ32>
20022ca4:	b2c6      	uxtb	r6, r0
20022ca6:	2200      	movs	r2, #0
20022ca8:	2114      	movs	r1, #20
20022caa:	4620      	mov	r0, r4
20022cac:	f7ff fe37 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022cb0:	b918      	cbnz	r0, 20022cba <HAL_FLASH_CLR_PROTECT+0xba>
20022cb2:	4620      	mov	r0, r4
20022cb4:	f7ff fc44 	bl	20022540 <HAL_FLASH_READ32>
20022cb8:	b2c5      	uxtb	r5, r0
20022cba:	68e3      	ldr	r3, [r4, #12]
20022cbc:	79d9      	ldrb	r1, [r3, #7]
20022cbe:	b109      	cbz	r1, 20022cc4 <HAL_FLASH_CLR_PROTECT+0xc4>
20022cc0:	ea26 0101 	bic.w	r1, r6, r1
20022cc4:	2200      	movs	r2, #0
20022cc6:	4620      	mov	r0, r4
20022cc8:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20022ccc:	2115      	movs	r1, #21
20022cce:	f7ff fe26 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022cd2:	4606      	mov	r6, r0
20022cd4:	b120      	cbz	r0, 20022ce0 <HAL_FLASH_CLR_PROTECT+0xe0>
20022cd6:	2200      	movs	r2, #0
20022cd8:	4620      	mov	r0, r4
20022cda:	4611      	mov	r1, r2
20022cdc:	f7ff fe1f 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022ce0:	4629      	mov	r1, r5
20022ce2:	4620      	mov	r0, r4
20022ce4:	f7ff fbcf 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20022ce8:	2102      	movs	r1, #2
20022cea:	4620      	mov	r0, r4
20022cec:	f7ff fbd2 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022cf0:	2200      	movs	r2, #0
20022cf2:	2103      	movs	r1, #3
20022cf4:	4620      	mov	r0, r4
20022cf6:	f7ff fe12 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022cfa:	2e00      	cmp	r6, #0
20022cfc:	d0c3      	beq.n	20022c86 <HAL_FLASH_CLR_PROTECT+0x86>
20022cfe:	2101      	movs	r1, #1
20022d00:	4620      	mov	r0, r4
20022d02:	f7ff fbc7 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022d06:	2200      	movs	r2, #0
20022d08:	2102      	movs	r1, #2
20022d0a:	4620      	mov	r0, r4
20022d0c:	f7ff fe07 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022d10:	4620      	mov	r0, r4
20022d12:	f7ff fc0c 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
20022d16:	2800      	cmp	r0, #0
20022d18:	d0f5      	beq.n	20022d06 <HAL_FLASH_CLR_PROTECT+0x106>
20022d1a:	e7b4      	b.n	20022c86 <HAL_FLASH_CLR_PROTECT+0x86>
20022d1c:	462e      	mov	r6, r5
20022d1e:	e7c2      	b.n	20022ca6 <HAL_FLASH_CLR_PROTECT+0xa6>

20022d20 <HAL_QSPI_SET_CLK_INV>:
20022d20:	b120      	cbz	r0, 20022d2c <HAL_QSPI_SET_CLK_INV+0xc>
20022d22:	6802      	ldr	r2, [r0, #0]
20022d24:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022d26:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20022d2a:	6593      	str	r3, [r2, #88]	@ 0x58
20022d2c:	4770      	bx	lr

20022d2e <HAL_FLASH_RELEASE_DPD>:
20022d2e:	b538      	push	{r3, r4, r5, lr}
20022d30:	4604      	mov	r4, r0
20022d32:	b1d0      	cbz	r0, 20022d6a <HAL_FLASH_RELEASE_DPD+0x3c>
20022d34:	6803      	ldr	r3, [r0, #0]
20022d36:	21ab      	movs	r1, #171	@ 0xab
20022d38:	681d      	ldr	r5, [r3, #0]
20022d3a:	f015 0501 	ands.w	r5, r5, #1
20022d3e:	bf02      	ittt	eq
20022d40:	681a      	ldreq	r2, [r3, #0]
20022d42:	f042 0201 	orreq.w	r2, r2, #1
20022d46:	601a      	streq	r2, [r3, #0]
20022d48:	6802      	ldr	r2, [r0, #0]
20022d4a:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022d4c:	f36f 0315 	bfc	r3, #0, #22
20022d50:	f043 0301 	orr.w	r3, r3, #1
20022d54:	6293      	str	r3, [r2, #40]	@ 0x28
20022d56:	2200      	movs	r2, #0
20022d58:	f7ff fbc1 	bl	200224de <HAL_FLASH_SET_CMD>
20022d5c:	b925      	cbnz	r5, 20022d68 <HAL_FLASH_RELEASE_DPD+0x3a>
20022d5e:	6822      	ldr	r2, [r4, #0]
20022d60:	6813      	ldr	r3, [r2, #0]
20022d62:	f023 0301 	bic.w	r3, r3, #1
20022d66:	6013      	str	r3, [r2, #0]
20022d68:	bd38      	pop	{r3, r4, r5, pc}
20022d6a:	2001      	movs	r0, #1
20022d6c:	e7fc      	b.n	20022d68 <HAL_FLASH_RELEASE_DPD+0x3a>

20022d6e <flash_handle_valid>:
20022d6e:	b118      	cbz	r0, 20022d78 <flash_handle_valid+0xa>
20022d70:	68c0      	ldr	r0, [r0, #12]
20022d72:	3800      	subs	r0, #0
20022d74:	bf18      	it	ne
20022d76:	2001      	movne	r0, #1
20022d78:	4770      	bx	lr

20022d7a <HAL_GET_FLASH_MID>:
20022d7a:	2000      	movs	r0, #0
20022d7c:	4770      	bx	lr

20022d7e <HAL_FLASH_DMA_START>:
20022d7e:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022d82:	4688      	mov	r8, r1
20022d84:	4699      	mov	r9, r3
20022d86:	4604      	mov	r4, r0
20022d88:	2800      	cmp	r0, #0
20022d8a:	d045      	beq.n	20022e18 <HAL_FLASH_DMA_START+0x9a>
20022d8c:	6883      	ldr	r3, [r0, #8]
20022d8e:	2b00      	cmp	r3, #0
20022d90:	d042      	beq.n	20022e18 <HAL_FLASH_DMA_START+0x9a>
20022d92:	f1b9 0f00 	cmp.w	r9, #0
20022d96:	d03f      	beq.n	20022e18 <HAL_FLASH_DMA_START+0x9a>
20022d98:	6801      	ldr	r1, [r0, #0]
20022d9a:	680f      	ldr	r7, [r1, #0]
20022d9c:	b332      	cbz	r2, 20022dec <HAL_FLASH_DMA_START+0x6e>
20022d9e:	2210      	movs	r2, #16
20022da0:	609a      	str	r2, [r3, #8]
20022da2:	2300      	movs	r3, #0
20022da4:	6882      	ldr	r2, [r0, #8]
20022da6:	464e      	mov	r6, r9
20022da8:	6153      	str	r3, [r2, #20]
20022daa:	6882      	ldr	r2, [r0, #8]
20022dac:	6193      	str	r3, [r2, #24]
20022dae:	6882      	ldr	r2, [r0, #8]
20022db0:	60d3      	str	r3, [r2, #12]
20022db2:	2280      	movs	r2, #128	@ 0x80
20022db4:	6883      	ldr	r3, [r0, #8]
20022db6:	611a      	str	r2, [r3, #16]
20022db8:	6805      	ldr	r5, [r0, #0]
20022dba:	3504      	adds	r5, #4
20022dbc:	68a0      	ldr	r0, [r4, #8]
20022dbe:	f7ff f8c5 	bl	20021f4c <HAL_DMA_DeInit>
20022dc2:	bb50      	cbnz	r0, 20022e1a <HAL_FLASH_DMA_START+0x9c>
20022dc4:	68a0      	ldr	r0, [r4, #8]
20022dc6:	f7ff f855 	bl	20021e74 <HAL_DMA_Init>
20022dca:	bb30      	cbnz	r0, 20022e1a <HAL_FLASH_DMA_START+0x9c>
20022dcc:	6823      	ldr	r3, [r4, #0]
20022dce:	f047 0720 	orr.w	r7, r7, #32
20022dd2:	601f      	str	r7, [r3, #0]
20022dd4:	6822      	ldr	r2, [r4, #0]
20022dd6:	f109 33ff 	add.w	r3, r9, #4294967295
20022dda:	6253      	str	r3, [r2, #36]	@ 0x24
20022ddc:	4641      	mov	r1, r8
20022dde:	4633      	mov	r3, r6
20022de0:	462a      	mov	r2, r5
20022de2:	68a0      	ldr	r0, [r4, #8]
20022de4:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022de8:	f7ff ba26 	b.w	20022238 <HAL_DMA_Start>
20022dec:	f44f 7100 	mov.w	r1, #512	@ 0x200
20022df0:	609a      	str	r2, [r3, #8]
20022df2:	6883      	ldr	r3, [r0, #8]
20022df4:	f109 0603 	add.w	r6, r9, #3
20022df8:	6159      	str	r1, [r3, #20]
20022dfa:	f44f 6100 	mov.w	r1, #2048	@ 0x800
20022dfe:	6883      	ldr	r3, [r0, #8]
20022e00:	4645      	mov	r5, r8
20022e02:	6199      	str	r1, [r3, #24]
20022e04:	6883      	ldr	r3, [r0, #8]
20022e06:	08b6      	lsrs	r6, r6, #2
20022e08:	60da      	str	r2, [r3, #12]
20022e0a:	2280      	movs	r2, #128	@ 0x80
20022e0c:	6883      	ldr	r3, [r0, #8]
20022e0e:	611a      	str	r2, [r3, #16]
20022e10:	6803      	ldr	r3, [r0, #0]
20022e12:	f103 0804 	add.w	r8, r3, #4
20022e16:	e7d1      	b.n	20022dbc <HAL_FLASH_DMA_START+0x3e>
20022e18:	2001      	movs	r0, #1
20022e1a:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

20022e1e <HAL_FLASH_DMA_WAIT_DONE>:
20022e1e:	b510      	push	{r4, lr}
20022e20:	460a      	mov	r2, r1
20022e22:	4604      	mov	r4, r0
20022e24:	b170      	cbz	r0, 20022e44 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022e26:	6880      	ldr	r0, [r0, #8]
20022e28:	b160      	cbz	r0, 20022e44 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022e2a:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20022e2c:	b111      	cbz	r1, 20022e34 <HAL_FLASH_DMA_WAIT_DONE+0x16>
20022e2e:	f04f 32ff 	mov.w	r2, #4294967295
20022e32:	2100      	movs	r1, #0
20022e34:	f7ff f8f8 	bl	20022028 <HAL_DMA_PollForTransfer>
20022e38:	6822      	ldr	r2, [r4, #0]
20022e3a:	6813      	ldr	r3, [r2, #0]
20022e3c:	f023 0320 	bic.w	r3, r3, #32
20022e40:	6013      	str	r3, [r2, #0]
20022e42:	bd10      	pop	{r4, pc}
20022e44:	2001      	movs	r0, #1
20022e46:	e7fc      	b.n	20022e42 <HAL_FLASH_DMA_WAIT_DONE+0x24>

20022e48 <HAL_FLASH_ALIAS_CFG>:
20022e48:	b538      	push	{r3, r4, r5, lr}
20022e4a:	461d      	mov	r5, r3
20022e4c:	4604      	mov	r4, r0
20022e4e:	b158      	cbz	r0, 20022e68 <HAL_FLASH_ALIAS_CFG+0x20>
20022e50:	6903      	ldr	r3, [r0, #16]
20022e52:	428b      	cmp	r3, r1
20022e54:	bf98      	it	ls
20022e56:	1ac9      	subls	r1, r1, r3
20022e58:	f7ff fbc8 	bl	200225ec <HAL_FLASH_SET_ALIAS_RANGE>
20022e5c:	4629      	mov	r1, r5
20022e5e:	4620      	mov	r0, r4
20022e60:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022e64:	f7ff bbd4 	b.w	20022610 <HAL_FLASH_SET_ALIAS_OFFSET>
20022e68:	bd38      	pop	{r3, r4, r5, pc}

20022e6a <nand_read_id>:
20022e6a:	b510      	push	{r4, lr}
20022e6c:	460b      	mov	r3, r1
20022e6e:	4604      	mov	r4, r0
20022e70:	b086      	sub	sp, #24
20022e72:	b320      	cbz	r0, 20022ebe <nand_read_id+0x54>
20022e74:	2908      	cmp	r1, #8
20022e76:	f04f 0100 	mov.w	r1, #0
20022e7a:	f04f 0201 	mov.w	r2, #1
20022e7e:	bf83      	ittte	hi
20022e80:	460b      	movhi	r3, r1
20022e82:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
20022e86:	e9cd 1100 	strdhi	r1, r1, [sp]
20022e8a:	e9cd 1102 	strdls	r1, r1, [sp, #8]
20022e8e:	bf8e      	itee	hi
20022e90:	4619      	movhi	r1, r3
20022e92:	e9cd 1100 	strdls	r1, r1, [sp]
20022e96:	b25b      	sxtbls	r3, r3
20022e98:	9204      	str	r2, [sp, #16]
20022e9a:	f7ff fb65 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20022e9e:	2103      	movs	r1, #3
20022ea0:	4620      	mov	r0, r4
20022ea2:	f7ff faf7 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022ea6:	2200      	movs	r2, #0
20022ea8:	219f      	movs	r1, #159	@ 0x9f
20022eaa:	4620      	mov	r0, r4
20022eac:	f7ff fb17 	bl	200224de <HAL_FLASH_SET_CMD>
20022eb0:	4620      	mov	r0, r4
20022eb2:	f7ff fb45 	bl	20022540 <HAL_FLASH_READ32>
20022eb6:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022eba:	b006      	add	sp, #24
20022ebc:	bd10      	pop	{r4, pc}
20022ebe:	20ff      	movs	r0, #255	@ 0xff
20022ec0:	e7fb      	b.n	20022eba <nand_read_id+0x50>

20022ec2 <HAL_NAND_CONF_ECC>:
20022ec2:	b538      	push	{r3, r4, r5, lr}
20022ec4:	460d      	mov	r5, r1
20022ec6:	4604      	mov	r4, r0
20022ec8:	b398      	cbz	r0, 20022f32 <HAL_NAND_CONF_ECC+0x70>
20022eca:	68c3      	ldr	r3, [r0, #12]
20022ecc:	b38b      	cbz	r3, 20022f32 <HAL_NAND_CONF_ECC+0x70>
20022ece:	799a      	ldrb	r2, [r3, #6]
20022ed0:	b392      	cbz	r2, 20022f38 <HAL_NAND_CONF_ECC+0x76>
20022ed2:	7a9b      	ldrb	r3, [r3, #10]
20022ed4:	b383      	cbz	r3, 20022f38 <HAL_NAND_CONF_ECC+0x76>
20022ed6:	2101      	movs	r1, #1
20022ed8:	f7ff fadc 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022edc:	68e3      	ldr	r3, [r4, #12]
20022ede:	2102      	movs	r1, #2
20022ee0:	799a      	ldrb	r2, [r3, #6]
20022ee2:	4620      	mov	r0, r4
20022ee4:	f7ff fd1b 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022ee8:	4620      	mov	r0, r4
20022eea:	f7ff fb29 	bl	20022540 <HAL_FLASH_READ32>
20022eee:	68e3      	ldr	r3, [r4, #12]
20022ef0:	7a9b      	ldrb	r3, [r3, #10]
20022ef2:	b1dd      	cbz	r5, 20022f2c <HAL_NAND_CONF_ECC+0x6a>
20022ef4:	ea43 0100 	orr.w	r1, r3, r0
20022ef8:	4620      	mov	r0, r4
20022efa:	f7ff fac4 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20022efe:	2101      	movs	r1, #1
20022f00:	4620      	mov	r0, r4
20022f02:	f7ff fac7 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022f06:	68e3      	ldr	r3, [r4, #12]
20022f08:	2103      	movs	r1, #3
20022f0a:	799a      	ldrb	r2, [r3, #6]
20022f0c:	4620      	mov	r0, r4
20022f0e:	f7ff fd06 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022f12:	68e3      	ldr	r3, [r4, #12]
20022f14:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20022f18:	2102      	movs	r1, #2
20022f1a:	799a      	ldrb	r2, [r3, #6]
20022f1c:	4620      	mov	r0, r4
20022f1e:	f7ff fcfe 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022f22:	4620      	mov	r0, r4
20022f24:	f7ff fb0c 	bl	20022540 <HAL_FLASH_READ32>
20022f28:	2000      	movs	r0, #0
20022f2a:	bd38      	pop	{r3, r4, r5, pc}
20022f2c:	ea20 0103 	bic.w	r1, r0, r3
20022f30:	e7e2      	b.n	20022ef8 <HAL_NAND_CONF_ECC+0x36>
20022f32:	f04f 30ff 	mov.w	r0, #4294967295
20022f36:	e7f8      	b.n	20022f2a <HAL_NAND_CONF_ECC+0x68>
20022f38:	f06f 0001 	mvn.w	r0, #1
20022f3c:	e7f5      	b.n	20022f2a <HAL_NAND_CONF_ECC+0x68>

20022f3e <HAL_NAND_GET_ECC_STATUS>:
20022f3e:	b510      	push	{r4, lr}
20022f40:	4604      	mov	r4, r0
20022f42:	b320      	cbz	r0, 20022f8e <HAL_NAND_GET_ECC_STATUS+0x50>
20022f44:	68c2      	ldr	r2, [r0, #12]
20022f46:	b31a      	cbz	r2, 20022f90 <HAL_NAND_GET_ECC_STATUS+0x52>
20022f48:	7913      	ldrb	r3, [r2, #4]
20022f4a:	b31b      	cbz	r3, 20022f94 <HAL_NAND_GET_ECC_STATUS+0x56>
20022f4c:	79d3      	ldrb	r3, [r2, #7]
20022f4e:	b30b      	cbz	r3, 20022f94 <HAL_NAND_GET_ECC_STATUS+0x56>
20022f50:	2101      	movs	r1, #1
20022f52:	f7ff fa9f 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20022f56:	68e3      	ldr	r3, [r4, #12]
20022f58:	2102      	movs	r1, #2
20022f5a:	791a      	ldrb	r2, [r3, #4]
20022f5c:	4620      	mov	r0, r4
20022f5e:	f7ff fcde 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20022f62:	4620      	mov	r0, r4
20022f64:	f7ff faec 	bl	20022540 <HAL_FLASH_READ32>
20022f68:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
20022f6c:	2a3f      	cmp	r2, #63	@ 0x3f
20022f6e:	ea4f 1312 	mov.w	r3, r2, lsr #4
20022f72:	d804      	bhi.n	20022f7e <HAL_NAND_GET_ECC_STATUS+0x40>
20022f74:	2b01      	cmp	r3, #1
20022f76:	d808      	bhi.n	20022f8a <HAL_NAND_GET_ECC_STATUS+0x4c>
20022f78:	f000 0030 	and.w	r0, r0, #48	@ 0x30
20022f7c:	e007      	b.n	20022f8e <HAL_NAND_GET_ECC_STATUS+0x50>
20022f7e:	3b04      	subs	r3, #4
20022f80:	2b01      	cmp	r3, #1
20022f82:	d8f9      	bhi.n	20022f78 <HAL_NAND_GET_ECC_STATUS+0x3a>
20022f84:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
20022f88:	e001      	b.n	20022f8e <HAL_NAND_GET_ECC_STATUS+0x50>
20022f8a:	f000 0070 	and.w	r0, r0, #112	@ 0x70
20022f8e:	bd10      	pop	{r4, pc}
20022f90:	4610      	mov	r0, r2
20022f92:	e7fc      	b.n	20022f8e <HAL_NAND_GET_ECC_STATUS+0x50>
20022f94:	4618      	mov	r0, r3
20022f96:	e7fa      	b.n	20022f8e <HAL_NAND_GET_ECC_STATUS+0x50>

20022f98 <HAL_NAND_CHECK_ECC>:
20022f98:	4603      	mov	r3, r0
20022f9a:	1108      	asrs	r0, r1, #4
20022f9c:	b172      	cbz	r2, 20022fbc <HAL_NAND_CHECK_ECC+0x24>
20022f9e:	2b07      	cmp	r3, #7
20022fa0:	d80c      	bhi.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
20022fa2:	e8df f003 	tbb	[pc, r3]
20022fa6:	0d04      	.short	0x0d04
20022fa8:	3f352e18 	.word	0x3f352e18
20022fac:	4c47      	.short	0x4c47
20022fae:	b128      	cbz	r0, 20022fbc <HAL_NAND_CHECK_ECC+0x24>
20022fb0:	2801      	cmp	r0, #1
20022fb2:	6813      	ldr	r3, [r2, #0]
20022fb4:	d10a      	bne.n	20022fcc <HAL_NAND_CHECK_ECC+0x34>
20022fb6:	f043 0301 	orr.w	r3, r3, #1
20022fba:	6013      	str	r3, [r2, #0]
20022fbc:	2000      	movs	r0, #0
20022fbe:	4770      	bx	lr
20022fc0:	f020 0302 	bic.w	r3, r0, #2
20022fc4:	2b01      	cmp	r3, #1
20022fc6:	d003      	beq.n	20022fd0 <HAL_NAND_CHECK_ECC+0x38>
20022fc8:	b1d0      	cbz	r0, 20023000 <HAL_NAND_CHECK_ECC+0x68>
20022fca:	6813      	ldr	r3, [r2, #0]
20022fcc:	4303      	orrs	r3, r0
20022fce:	e016      	b.n	20022ffe <HAL_NAND_CHECK_ECC+0x66>
20022fd0:	6813      	ldr	r3, [r2, #0]
20022fd2:	4303      	orrs	r3, r0
20022fd4:	e7f1      	b.n	20022fba <HAL_NAND_CHECK_ECC+0x22>
20022fd6:	2805      	cmp	r0, #5
20022fd8:	d8f7      	bhi.n	20022fca <HAL_NAND_CHECK_ECC+0x32>
20022fda:	a301      	add	r3, pc, #4	@ (adr r3, 20022fe0 <HAL_NAND_CHECK_ECC+0x48>)
20022fdc:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
20022fe0:	20022fbd 	.word	0x20022fbd
20022fe4:	20022fd1 	.word	0x20022fd1
20022fe8:	20022ff9 	.word	0x20022ff9
20022fec:	20022fd1 	.word	0x20022fd1
20022ff0:	20022fcb 	.word	0x20022fcb
20022ff4:	20022fd1 	.word	0x20022fd1
20022ff8:	6813      	ldr	r3, [r2, #0]
20022ffa:	f043 0302 	orr.w	r3, r3, #2
20022ffe:	6013      	str	r3, [r2, #0]
20023000:	4770      	bx	lr
20023002:	2800      	cmp	r0, #0
20023004:	d0da      	beq.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
20023006:	1e43      	subs	r3, r0, #1
20023008:	2b05      	cmp	r3, #5
2002300a:	6813      	ldr	r3, [r2, #0]
2002300c:	d9e1      	bls.n	20022fd2 <HAL_NAND_CHECK_ECC+0x3a>
2002300e:	e7dd      	b.n	20022fcc <HAL_NAND_CHECK_ECC+0x34>
20023010:	07c3      	lsls	r3, r0, #31
20023012:	f000 0103 	and.w	r1, r0, #3
20023016:	d402      	bmi.n	2002301e <HAL_NAND_CHECK_ECC+0x86>
20023018:	2900      	cmp	r1, #0
2002301a:	d0cf      	beq.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
2002301c:	e7d5      	b.n	20022fca <HAL_NAND_CHECK_ECC+0x32>
2002301e:	6813      	ldr	r3, [r2, #0]
20023020:	430b      	orrs	r3, r1
20023022:	e7ca      	b.n	20022fba <HAL_NAND_CHECK_ECC+0x22>
20023024:	2800      	cmp	r0, #0
20023026:	d0c9      	beq.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
20023028:	6813      	ldr	r3, [r2, #0]
2002302a:	2808      	cmp	r0, #8
2002302c:	ea43 0300 	orr.w	r3, r3, r0
20023030:	dce5      	bgt.n	20022ffe <HAL_NAND_CHECK_ECC+0x66>
20023032:	e7c2      	b.n	20022fba <HAL_NAND_CHECK_ECC+0x22>
20023034:	2800      	cmp	r0, #0
20023036:	d0c1      	beq.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
20023038:	1e43      	subs	r3, r0, #1
2002303a:	2b01      	cmp	r3, #1
2002303c:	e7e5      	b.n	2002300a <HAL_NAND_CHECK_ECC+0x72>
2002303e:	2800      	cmp	r0, #0
20023040:	d0bc      	beq.n	20022fbc <HAL_NAND_CHECK_ECC+0x24>
20023042:	1e43      	subs	r3, r0, #1
20023044:	2b02      	cmp	r3, #2
20023046:	e7e0      	b.n	2002300a <HAL_NAND_CHECK_ECC+0x72>

20023048 <HAL_NAND_GET_ECC_RESULT>:
20023048:	b510      	push	{r4, lr}
2002304a:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
2002304e:	4604      	mov	r4, r0
20023050:	b90b      	cbnz	r3, 20023056 <HAL_NAND_GET_ECC_RESULT+0xe>
20023052:	2000      	movs	r0, #0
20023054:	bd10      	pop	{r4, pc}
20023056:	f7ff ff72 	bl	20022f3e <HAL_NAND_GET_ECC_STATUS>
2002305a:	4601      	mov	r1, r0
2002305c:	2800      	cmp	r0, #0
2002305e:	d0f8      	beq.n	20023052 <HAL_NAND_GET_ECC_RESULT+0xa>
20023060:	6862      	ldr	r2, [r4, #4]
20023062:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
20023064:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
20023068:	6062      	str	r2, [r4, #4]
2002306a:	b938      	cbnz	r0, 2002307c <HAL_NAND_GET_ECC_RESULT+0x34>
2002306c:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
20023070:	1d22      	adds	r2, r4, #4
20023072:	0900      	lsrs	r0, r0, #4
20023074:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20023078:	f7ff bf8e 	b.w	20022f98 <HAL_NAND_CHECK_ECC>
2002307c:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
20023080:	ea4f 1321 	mov.w	r3, r1, asr #4
20023084:	db00      	blt.n	20023088 <HAL_NAND_GET_ECC_RESULT+0x40>
20023086:	e7fe      	b.n	20023086 <HAL_NAND_GET_ECC_RESULT+0x3e>
20023088:	6801      	ldr	r1, [r0, #0]
2002308a:	40d9      	lsrs	r1, r3
2002308c:	f011 0f01 	tst.w	r1, #1
20023090:	bf18      	it	ne
20023092:	4618      	movne	r0, r3
20023094:	ea43 0302 	orr.w	r3, r3, r2
20023098:	bf08      	it	eq
2002309a:	2000      	moveq	r0, #0
2002309c:	6063      	str	r3, [r4, #4]
2002309e:	e7d9      	b.n	20023054 <HAL_NAND_GET_ECC_RESULT+0xc>

200230a0 <HAL_NAND_EN_QUAL>:
200230a0:	b538      	push	{r3, r4, r5, lr}
200230a2:	460d      	mov	r5, r1
200230a4:	4604      	mov	r4, r0
200230a6:	b348      	cbz	r0, 200230fc <HAL_NAND_EN_QUAL+0x5c>
200230a8:	68c3      	ldr	r3, [r0, #12]
200230aa:	b33b      	cbz	r3, 200230fc <HAL_NAND_EN_QUAL+0x5c>
200230ac:	799a      	ldrb	r2, [r3, #6]
200230ae:	b10a      	cbz	r2, 200230b4 <HAL_NAND_EN_QUAL+0x14>
200230b0:	7a1b      	ldrb	r3, [r3, #8]
200230b2:	b90b      	cbnz	r3, 200230b8 <HAL_NAND_EN_QUAL+0x18>
200230b4:	2000      	movs	r0, #0
200230b6:	bd38      	pop	{r3, r4, r5, pc}
200230b8:	2101      	movs	r1, #1
200230ba:	f7ff f9eb 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200230be:	68e3      	ldr	r3, [r4, #12]
200230c0:	2102      	movs	r1, #2
200230c2:	799a      	ldrb	r2, [r3, #6]
200230c4:	4620      	mov	r0, r4
200230c6:	f7ff fc2a 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200230ca:	4620      	mov	r0, r4
200230cc:	f7ff fa38 	bl	20022540 <HAL_FLASH_READ32>
200230d0:	68e3      	ldr	r3, [r4, #12]
200230d2:	7a1b      	ldrb	r3, [r3, #8]
200230d4:	b17d      	cbz	r5, 200230f6 <HAL_NAND_EN_QUAL+0x56>
200230d6:	ea43 0100 	orr.w	r1, r3, r0
200230da:	4620      	mov	r0, r4
200230dc:	f7ff f9d3 	bl	20022486 <HAL_FLASH_WRITE_WORD>
200230e0:	2101      	movs	r1, #1
200230e2:	4620      	mov	r0, r4
200230e4:	f7ff f9d6 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200230e8:	68e3      	ldr	r3, [r4, #12]
200230ea:	2103      	movs	r1, #3
200230ec:	4620      	mov	r0, r4
200230ee:	799a      	ldrb	r2, [r3, #6]
200230f0:	f7ff fc15 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200230f4:	e7de      	b.n	200230b4 <HAL_NAND_EN_QUAL+0x14>
200230f6:	ea20 0103 	bic.w	r1, r0, r3
200230fa:	e7ee      	b.n	200230da <HAL_NAND_EN_QUAL+0x3a>
200230fc:	f04f 30ff 	mov.w	r0, #4294967295
20023100:	e7d9      	b.n	200230b6 <HAL_NAND_EN_QUAL+0x16>

20023102 <nand_clear_status>:
20023102:	b538      	push	{r3, r4, r5, lr}
20023104:	460d      	mov	r5, r1
20023106:	2101      	movs	r1, #1
20023108:	4604      	mov	r4, r0
2002310a:	f7ff f9c3 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
2002310e:	2dc9      	cmp	r5, #201	@ 0xc9
20023110:	d001      	beq.n	20023116 <nand_clear_status+0x14>
20023112:	2d01      	cmp	r5, #1
20023114:	d109      	bne.n	2002312a <nand_clear_status+0x28>
20023116:	2102      	movs	r1, #2
20023118:	4620      	mov	r0, r4
2002311a:	f7ff f9b4 	bl	20022486 <HAL_FLASH_WRITE_WORD>
2002311e:	68e3      	ldr	r3, [r4, #12]
20023120:	2103      	movs	r1, #3
20023122:	4620      	mov	r0, r4
20023124:	795a      	ldrb	r2, [r3, #5]
20023126:	f7ff fbfa 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
2002312a:	2100      	movs	r1, #0
2002312c:	4620      	mov	r0, r4
2002312e:	f7ff f9aa 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20023132:	68e3      	ldr	r3, [r4, #12]
20023134:	2103      	movs	r1, #3
20023136:	4620      	mov	r0, r4
20023138:	795a      	ldrb	r2, [r3, #5]
2002313a:	f7ff fbf0 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
2002313e:	2000      	movs	r0, #0
20023140:	bd38      	pop	{r3, r4, r5, pc}

20023142 <HAL_NAND_PAGE_SIZE>:
20023142:	b140      	cbz	r0, 20023156 <HAL_NAND_PAGE_SIZE+0x14>
20023144:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
20023148:	f013 0f01 	tst.w	r3, #1
2002314c:	bf14      	ite	ne
2002314e:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
20023152:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
20023156:	4770      	bx	lr

20023158 <HAL_NAND_READ_WITHOOB>:
20023158:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002315c:	b085      	sub	sp, #20
2002315e:	460e      	mov	r6, r1
20023160:	4691      	mov	r9, r2
20023162:	461d      	mov	r5, r3
20023164:	4604      	mov	r4, r0
20023166:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
20023168:	b1b0      	cbz	r0, 20023198 <HAL_NAND_READ_WITHOOB+0x40>
2002316a:	68c3      	ldr	r3, [r0, #12]
2002316c:	b1a3      	cbz	r3, 20023198 <HAL_NAND_READ_WITHOOB+0x40>
2002316e:	69c3      	ldr	r3, [r0, #28]
20023170:	b193      	cbz	r3, 20023198 <HAL_NAND_READ_WITHOOB+0x40>
20023172:	2f80      	cmp	r7, #128	@ 0x80
20023174:	d810      	bhi.n	20023198 <HAL_NAND_READ_WITHOOB+0x40>
20023176:	f7ff ffe4 	bl	20023142 <HAL_NAND_PAGE_SIZE>
2002317a:	f100 3aff 	add.w	sl, r0, #4294967295
2002317e:	ea0a 0a01 	and.w	sl, sl, r1
20023182:	eb0a 0305 	add.w	r3, sl, r5
20023186:	4283      	cmp	r3, r0
20023188:	4680      	mov	r8, r0
2002318a:	d907      	bls.n	2002319c <HAL_NAND_READ_WITHOOB+0x44>
2002318c:	2002      	movs	r0, #2
2002318e:	6060      	str	r0, [r4, #4]
20023190:	2000      	movs	r0, #0
20023192:	b005      	add	sp, #20
20023194:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20023198:	2001      	movs	r0, #1
2002319a:	e7f8      	b.n	2002318e <HAL_NAND_READ_WITHOOB+0x36>
2002319c:	2300      	movs	r3, #0
2002319e:	6063      	str	r3, [r4, #4]
200231a0:	6923      	ldr	r3, [r4, #16]
200231a2:	f04f 0b00 	mov.w	fp, #0
200231a6:	428b      	cmp	r3, r1
200231a8:	bf98      	it	ls
200231aa:	1ace      	subls	r6, r1, r3
200231ac:	fbb6 f2f0 	udiv	r2, r6, r0
200231b0:	2104      	movs	r1, #4
200231b2:	4620      	mov	r0, r4
200231b4:	f7ff fbb3 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200231b8:	2014      	movs	r0, #20
200231ba:	f7fe fb7d 	bl	200218b8 <HAL_Delay_us_>
200231be:	2101      	movs	r1, #1
200231c0:	4620      	mov	r0, r4
200231c2:	f7ff f967 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200231c6:	2005      	movs	r0, #5
200231c8:	f7fe fb76 	bl	200218b8 <HAL_Delay_us_>
200231cc:	68e2      	ldr	r2, [r4, #12]
200231ce:	2102      	movs	r1, #2
200231d0:	7912      	ldrb	r2, [r2, #4]
200231d2:	4620      	mov	r0, r4
200231d4:	f7ff fba3 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200231d8:	4620      	mov	r0, r4
200231da:	f7ff f9b1 	bl	20022540 <HAL_FLASH_READ32>
200231de:	07c1      	lsls	r1, r0, #31
200231e0:	d4f1      	bmi.n	200231c6 <HAL_NAND_READ_WITHOOB+0x6e>
200231e2:	f1bb 0f00 	cmp.w	fp, #0
200231e6:	d102      	bne.n	200231ee <HAL_NAND_READ_WITHOOB+0x96>
200231e8:	f04f 0b01 	mov.w	fp, #1
200231ec:	e7eb      	b.n	200231c6 <HAL_NAND_READ_WITHOOB+0x6e>
200231ee:	4620      	mov	r0, r4
200231f0:	f7ff ff2a 	bl	20023048 <HAL_NAND_GET_ECC_RESULT>
200231f4:	b110      	cbz	r0, 200231fc <HAL_NAND_READ_WITHOOB+0xa4>
200231f6:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
200231fa:	e7c8      	b.n	2002318e <HAL_NAND_READ_WITHOOB+0x36>
200231fc:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
20023200:	68e3      	ldr	r3, [r4, #12]
20023202:	bbb2      	cbnz	r2, 20023272 <HAL_NAND_READ_WITHOOB+0x11a>
20023204:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023208:	4620      	mov	r0, r4
2002320a:	f7ff f8eb 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
2002320e:	68e0      	ldr	r0, [r4, #12]
20023210:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
20023214:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023218:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
2002321c:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
20023220:	f8cd c00c 	str.w	ip, [sp, #12]
20023224:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023228:	f8cd c008 	str.w	ip, [sp, #8]
2002322c:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
20023230:	f8cd c004 	str.w	ip, [sp, #4]
20023234:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
20023238:	9000      	str	r0, [sp, #0]
2002323a:	4620      	mov	r0, r4
2002323c:	f7ff f8dd 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
20023240:	03b2      	lsls	r2, r6, #14
20023242:	f8d4 b010 	ldr.w	fp, [r4, #16]
20023246:	d504      	bpl.n	20023252 <HAL_NAND_READ_WITHOOB+0xfa>
20023248:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
2002324c:	b10a      	cbz	r2, 20023252 <HAL_NAND_READ_WITHOOB+0xfa>
2002324e:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
20023252:	ea49 0205 	orr.w	r2, r9, r5
20023256:	ea42 020a 	orr.w	r2, r2, sl
2002325a:	0793      	lsls	r3, r2, #30
2002325c:	d102      	bne.n	20023264 <HAL_NAND_READ_WITHOOB+0x10c>
2002325e:	1e6a      	subs	r2, r5, #1
20023260:	2afe      	cmp	r2, #254	@ 0xfe
20023262:	d821      	bhi.n	200232a8 <HAL_NAND_READ_WITHOOB+0x150>
20023264:	462a      	mov	r2, r5
20023266:	4648      	mov	r0, r9
20023268:	eb0b 010a 	add.w	r1, fp, sl
2002326c:	f002 fd69 	bl	20025d42 <memcpy>
20023270:	e01d      	b.n	200232ae <HAL_NAND_READ_WITHOOB+0x156>
20023272:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
20023276:	4620      	mov	r0, r4
20023278:	f7ff f8b4 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
2002327c:	68e0      	ldr	r0, [r4, #12]
2002327e:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
20023282:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
20023286:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
2002328a:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
2002328e:	f8cd c00c 	str.w	ip, [sp, #12]
20023292:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
20023296:	f8cd c008 	str.w	ip, [sp, #8]
2002329a:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
2002329e:	f8cd c004 	str.w	ip, [sp, #4]
200232a2:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
200232a6:	e7c7      	b.n	20023238 <HAL_NAND_READ_WITHOOB+0xe0>
200232a8:	f1b9 0f00 	cmp.w	r9, #0
200232ac:	d1da      	bne.n	20023264 <HAL_NAND_READ_WITHOOB+0x10c>
200232ae:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
200232b0:	b12b      	cbz	r3, 200232be <HAL_NAND_READ_WITHOOB+0x166>
200232b2:	463a      	mov	r2, r7
200232b4:	4618      	mov	r0, r3
200232b6:	eb0b 0108 	add.w	r1, fp, r8
200232ba:	f002 fd42 	bl	20025d42 <memcpy>
200232be:	1978      	adds	r0, r7, r5
200232c0:	e767      	b.n	20023192 <HAL_NAND_READ_WITHOOB+0x3a>

200232c2 <HAL_NAND_BLOCK_SIZE>:
200232c2:	b508      	push	{r3, lr}
200232c4:	4602      	mov	r2, r0
200232c6:	f7ff ff3c 	bl	20023142 <HAL_NAND_PAGE_SIZE>
200232ca:	b128      	cbz	r0, 200232d8 <HAL_NAND_BLOCK_SIZE+0x16>
200232cc:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
200232d0:	079b      	lsls	r3, r3, #30
200232d2:	bf4c      	ite	mi
200232d4:	01c0      	lslmi	r0, r0, #7
200232d6:	0180      	lslpl	r0, r0, #6
200232d8:	bd08      	pop	{r3, pc}

200232da <HAL_NAND_GET_BADBLK>:
200232da:	b51f      	push	{r0, r1, r2, r3, r4, lr}
200232dc:	4604      	mov	r4, r0
200232de:	b910      	cbnz	r0, 200232e6 <HAL_NAND_GET_BADBLK+0xc>
200232e0:	2000      	movs	r0, #0
200232e2:	b004      	add	sp, #16
200232e4:	bd10      	pop	{r4, pc}
200232e6:	6a03      	ldr	r3, [r0, #32]
200232e8:	2b00      	cmp	r3, #0
200232ea:	d0f9      	beq.n	200232e0 <HAL_NAND_GET_BADBLK+0x6>
200232ec:	f7ff ffe9 	bl	200232c2 <HAL_NAND_BLOCK_SIZE>
200232f0:	2304      	movs	r3, #4
200232f2:	9301      	str	r3, [sp, #4]
200232f4:	ab03      	add	r3, sp, #12
200232f6:	9300      	str	r3, [sp, #0]
200232f8:	2300      	movs	r3, #0
200232fa:	4341      	muls	r1, r0
200232fc:	461a      	mov	r2, r3
200232fe:	4620      	mov	r0, r4
20023300:	f7ff ff2a 	bl	20023158 <HAL_NAND_READ_WITHOOB>
20023304:	b140      	cbz	r0, 20023318 <HAL_NAND_GET_BADBLK+0x3e>
20023306:	f89d 300c 	ldrb.w	r3, [sp, #12]
2002330a:	2bff      	cmp	r3, #255	@ 0xff
2002330c:	d0e8      	beq.n	200232e0 <HAL_NAND_GET_BADBLK+0x6>
2002330e:	9803      	ldr	r0, [sp, #12]
20023310:	2800      	cmp	r0, #0
20023312:	bf08      	it	eq
20023314:	2001      	moveq	r0, #1
20023316:	e7e4      	b.n	200232e2 <HAL_NAND_GET_BADBLK+0x8>
20023318:	2001      	movs	r0, #1
2002331a:	e7e2      	b.n	200232e2 <HAL_NAND_GET_BADBLK+0x8>

2002331c <HAL_QSPIEX_WRITE_PAGE>:
2002331c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023320:	b099      	sub	sp, #100	@ 0x64
20023322:	4604      	mov	r4, r0
20023324:	460e      	mov	r6, r1
20023326:	4691      	mov	r9, r2
20023328:	f7ff fd21 	bl	20022d6e <flash_handle_valid>
2002332c:	b318      	cbz	r0, 20023376 <HAL_QSPIEX_WRITE_PAGE+0x5a>
2002332e:	2b00      	cmp	r3, #0
20023330:	f000 80d7 	beq.w	200234e2 <HAL_QSPIEX_WRITE_PAGE+0x1c6>
20023334:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20023338:	bf28      	it	cs
2002333a:	f44f 7380 	movcs.w	r3, #256	@ 0x100
2002333e:	68a1      	ldr	r1, [r4, #8]
20023340:	461d      	mov	r5, r3
20023342:	6962      	ldr	r2, [r4, #20]
20023344:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023348:	2900      	cmp	r1, #0
2002334a:	d03b      	beq.n	200233c4 <HAL_QSPIEX_WRITE_PAGE+0xa8>
2002334c:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023350:	d914      	bls.n	2002337c <HAL_QSPIEX_WRITE_PAGE+0x60>
20023352:	2b02      	cmp	r3, #2
20023354:	bf14      	ite	ne
20023356:	2727      	movne	r7, #39	@ 0x27
20023358:	2728      	moveq	r7, #40	@ 0x28
2002335a:	4639      	mov	r1, r7
2002335c:	4620      	mov	r0, r4
2002335e:	f7ff fab7 	bl	200228d0 <HAL_FLASH_PRE_CMD>
20023362:	4649      	mov	r1, r9
20023364:	462b      	mov	r3, r5
20023366:	2201      	movs	r2, #1
20023368:	4620      	mov	r0, r4
2002336a:	f7ff fd08 	bl	20022d7e <HAL_FLASH_DMA_START>
2002336e:	4601      	mov	r1, r0
20023370:	b148      	cbz	r0, 20023386 <HAL_QSPIEX_WRITE_PAGE+0x6a>
20023372:	2500      	movs	r5, #0
20023374:	4628      	mov	r0, r5
20023376:	b019      	add	sp, #100	@ 0x64
20023378:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002337c:	2b02      	cmp	r3, #2
2002337e:	bf14      	ite	ne
20023380:	2716      	movne	r7, #22
20023382:	2717      	moveq	r7, #23
20023384:	e7e9      	b.n	2002335a <HAL_QSPIEX_WRITE_PAGE+0x3e>
20023386:	4632      	mov	r2, r6
20023388:	4620      	mov	r0, r4
2002338a:	f7ff fac8 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
2002338e:	2101      	movs	r1, #1
20023390:	4620      	mov	r0, r4
20023392:	f7ff f889 	bl	200224a8 <HAL_FLASH_WRITE_DLEN2>
20023396:	2301      	movs	r3, #1
20023398:	4632      	mov	r2, r6
2002339a:	9300      	str	r3, [sp, #0]
2002339c:	4639      	mov	r1, r7
2002339e:	2302      	movs	r3, #2
200233a0:	4620      	mov	r0, r4
200233a2:	f7ff faef 	bl	20022984 <HAL_FLASH_ISSUE_CMD_SEQ>
200233a6:	2800      	cmp	r0, #0
200233a8:	d1e3      	bne.n	20023372 <HAL_QSPIEX_WRITE_PAGE+0x56>
200233aa:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
200233ae:	4620      	mov	r0, r4
200233b0:	f7ff fd35 	bl	20022e1e <HAL_FLASH_DMA_WAIT_DONE>
200233b4:	2800      	cmp	r0, #0
200233b6:	d1dc      	bne.n	20023372 <HAL_QSPIEX_WRITE_PAGE+0x56>
200233b8:	6822      	ldr	r2, [r4, #0]
200233ba:	6813      	ldr	r3, [r2, #0]
200233bc:	f023 0320 	bic.w	r3, r3, #32
200233c0:	6013      	str	r3, [r2, #0]
200233c2:	e7d7      	b.n	20023374 <HAL_QSPIEX_WRITE_PAGE+0x58>
200233c4:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
200233c8:	f240 8082 	bls.w	200234d0 <HAL_QSPIEX_WRITE_PAGE+0x1b4>
200233cc:	2b02      	cmp	r3, #2
200233ce:	bf14      	ite	ne
200233d0:	2327      	movne	r3, #39	@ 0x27
200233d2:	2328      	moveq	r3, #40	@ 0x28
200233d4:	462f      	mov	r7, r5
200233d6:	f04f 0800 	mov.w	r8, #0
200233da:	9303      	str	r3, [sp, #12]
200233dc:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
200233e0:	2f40      	cmp	r7, #64	@ 0x40
200233e2:	bfd4      	ite	le
200233e4:	ea0a 0a07 	andle.w	sl, sl, r7
200233e8:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
200233ec:	f1ba 0f00 	cmp.w	sl, #0
200233f0:	d03f      	beq.n	20023472 <HAL_QSPIEX_WRITE_PAGE+0x156>
200233f2:	2200      	movs	r2, #0
200233f4:	4620      	mov	r0, r4
200233f6:	4611      	mov	r1, r2
200233f8:	f7ff fa91 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200233fc:	eb09 0308 	add.w	r3, r9, r8
20023400:	f10d 0c20 	add.w	ip, sp, #32
20023404:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023408:	4662      	mov	r2, ip
2002340a:	6818      	ldr	r0, [r3, #0]
2002340c:	6859      	ldr	r1, [r3, #4]
2002340e:	3308      	adds	r3, #8
20023410:	c203      	stmia	r2!, {r0, r1}
20023412:	4573      	cmp	r3, lr
20023414:	4694      	mov	ip, r2
20023416:	d1f7      	bne.n	20023408 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023418:	f04f 0b00 	mov.w	fp, #0
2002341c:	ea4f 02aa 	mov.w	r2, sl, asr #2
20023420:	ab08      	add	r3, sp, #32
20023422:	f853 1b04 	ldr.w	r1, [r3], #4
20023426:	4620      	mov	r0, r4
20023428:	9205      	str	r2, [sp, #20]
2002342a:	9304      	str	r3, [sp, #16]
2002342c:	f7ff f82b 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20023430:	9a05      	ldr	r2, [sp, #20]
20023432:	f10b 0b01 	add.w	fp, fp, #1
20023436:	4593      	cmp	fp, r2
20023438:	9b04      	ldr	r3, [sp, #16]
2002343a:	d1f2      	bne.n	20023422 <HAL_QSPIEX_WRITE_PAGE+0x106>
2002343c:	4651      	mov	r1, sl
2002343e:	4620      	mov	r0, r4
20023440:	f7ff f828 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20023444:	4620      	mov	r0, r4
20023446:	9903      	ldr	r1, [sp, #12]
20023448:	eb06 0208 	add.w	r2, r6, r8
2002344c:	f7ff fa67 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20023450:	2101      	movs	r1, #1
20023452:	4620      	mov	r0, r4
20023454:	f7ff f81e 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20023458:	2200      	movs	r2, #0
2002345a:	2102      	movs	r1, #2
2002345c:	4620      	mov	r0, r4
2002345e:	f7ff fa5e 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20023462:	4620      	mov	r0, r4
20023464:	f7ff f863 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
20023468:	2800      	cmp	r0, #0
2002346a:	d0f1      	beq.n	20023450 <HAL_QSPIEX_WRITE_PAGE+0x134>
2002346c:	eba7 070a 	sub.w	r7, r7, sl
20023470:	44d0      	add	r8, sl
20023472:	1e7b      	subs	r3, r7, #1
20023474:	2b02      	cmp	r3, #2
20023476:	d830      	bhi.n	200234da <HAL_QSPIEX_WRITE_PAGE+0x1be>
20023478:	6923      	ldr	r3, [r4, #16]
2002347a:	4446      	add	r6, r8
2002347c:	4333      	orrs	r3, r6
2002347e:	681b      	ldr	r3, [r3, #0]
20023480:	463a      	mov	r2, r7
20023482:	eb09 0108 	add.w	r1, r9, r8
20023486:	a807      	add	r0, sp, #28
20023488:	9307      	str	r3, [sp, #28]
2002348a:	f002 fc5a 	bl	20025d42 <memcpy>
2002348e:	2200      	movs	r2, #0
20023490:	4620      	mov	r0, r4
20023492:	4611      	mov	r1, r2
20023494:	f7ff fa43 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
20023498:	9907      	ldr	r1, [sp, #28]
2002349a:	4620      	mov	r0, r4
2002349c:	f7fe fff3 	bl	20022486 <HAL_FLASH_WRITE_WORD>
200234a0:	2104      	movs	r1, #4
200234a2:	4620      	mov	r0, r4
200234a4:	f7fe fff6 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200234a8:	4632      	mov	r2, r6
200234aa:	4620      	mov	r0, r4
200234ac:	9903      	ldr	r1, [sp, #12]
200234ae:	f7ff fa36 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200234b2:	2101      	movs	r1, #1
200234b4:	4620      	mov	r0, r4
200234b6:	f7fe ffed 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200234ba:	2200      	movs	r2, #0
200234bc:	2102      	movs	r1, #2
200234be:	4620      	mov	r0, r4
200234c0:	f7ff fa2d 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200234c4:	4620      	mov	r0, r4
200234c6:	f7ff f832 	bl	2002252e <HAL_FLASH_IS_PROG_DONE>
200234ca:	2800      	cmp	r0, #0
200234cc:	d0f1      	beq.n	200234b2 <HAL_QSPIEX_WRITE_PAGE+0x196>
200234ce:	e751      	b.n	20023374 <HAL_QSPIEX_WRITE_PAGE+0x58>
200234d0:	2b02      	cmp	r3, #2
200234d2:	bf14      	ite	ne
200234d4:	2316      	movne	r3, #22
200234d6:	2317      	moveq	r3, #23
200234d8:	e77c      	b.n	200233d4 <HAL_QSPIEX_WRITE_PAGE+0xb8>
200234da:	2f00      	cmp	r7, #0
200234dc:	f73f af7e 	bgt.w	200233dc <HAL_QSPIEX_WRITE_PAGE+0xc0>
200234e0:	e748      	b.n	20023374 <HAL_QSPIEX_WRITE_PAGE+0x58>
200234e2:	4618      	mov	r0, r3
200234e4:	e747      	b.n	20023376 <HAL_QSPIEX_WRITE_PAGE+0x5a>

200234e6 <HAL_QSPIEX_SECT_ERASE>:
200234e6:	b573      	push	{r0, r1, r4, r5, r6, lr}
200234e8:	4604      	mov	r4, r0
200234ea:	460d      	mov	r5, r1
200234ec:	f7ff fc3f 	bl	20022d6e <flash_handle_valid>
200234f0:	b1e8      	cbz	r0, 2002352e <HAL_QSPIEX_SECT_ERASE+0x48>
200234f2:	6963      	ldr	r3, [r4, #20]
200234f4:	460a      	mov	r2, r1
200234f6:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
200234fa:	f04f 0100 	mov.w	r1, #0
200234fe:	4620      	mov	r0, r4
20023500:	bf94      	ite	ls
20023502:	261b      	movls	r6, #27
20023504:	2629      	movhi	r6, #41	@ 0x29
20023506:	f7ff fa0a 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
2002350a:	2101      	movs	r1, #1
2002350c:	4620      	mov	r0, r4
2002350e:	f7fe ffcb 	bl	200224a8 <HAL_FLASH_WRITE_DLEN2>
20023512:	2301      	movs	r3, #1
20023514:	462a      	mov	r2, r5
20023516:	9300      	str	r3, [sp, #0]
20023518:	4631      	mov	r1, r6
2002351a:	2302      	movs	r3, #2
2002351c:	4620      	mov	r0, r4
2002351e:	f7ff fa31 	bl	20022984 <HAL_FLASH_ISSUE_CMD_SEQ>
20023522:	3800      	subs	r0, #0
20023524:	bf18      	it	ne
20023526:	2001      	movne	r0, #1
20023528:	4240      	negs	r0, r0
2002352a:	b002      	add	sp, #8
2002352c:	bd70      	pop	{r4, r5, r6, pc}
2002352e:	f04f 30ff 	mov.w	r0, #4294967295
20023532:	e7fa      	b.n	2002352a <HAL_QSPIEX_SECT_ERASE+0x44>

20023534 <HAL_QSPI_GET_SRC_CLK>:
20023534:	b508      	push	{r3, lr}
20023536:	b318      	cbz	r0, 20023580 <HAL_QSPI_GET_SRC_CLK+0x4c>
20023538:	6803      	ldr	r3, [r0, #0]
2002353a:	4a12      	ldr	r2, [pc, #72]	@ (20023584 <HAL_QSPI_GET_SRC_CLK+0x50>)
2002353c:	4293      	cmp	r3, r2
2002353e:	d010      	beq.n	20023562 <HAL_QSPI_GET_SRC_CLK+0x2e>
20023540:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
20023544:	4293      	cmp	r3, r2
20023546:	d00e      	beq.n	20023566 <HAL_QSPI_GET_SRC_CLK+0x32>
20023548:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
2002354c:	4293      	cmp	r3, r2
2002354e:	d117      	bne.n	20023580 <HAL_QSPI_GET_SRC_CLK+0x4c>
20023550:	2008      	movs	r0, #8
20023552:	f000 ff0d 	bl	20024370 <HAL_RCC_HCPU_GetClockSrc>
20023556:	2802      	cmp	r0, #2
20023558:	d107      	bne.n	2002356a <HAL_QSPI_GET_SRC_CLK+0x36>
2002355a:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002355e:	f000 bf4b 	b.w	200243f8 <HAL_RCC_HCPU_GetDLL2Freq>
20023562:	2004      	movs	r0, #4
20023564:	e7f5      	b.n	20023552 <HAL_QSPI_GET_SRC_CLK+0x1e>
20023566:	2006      	movs	r0, #6
20023568:	e7f3      	b.n	20023552 <HAL_QSPI_GET_SRC_CLK+0x1e>
2002356a:	2803      	cmp	r0, #3
2002356c:	d103      	bne.n	20023576 <HAL_QSPI_GET_SRC_CLK+0x42>
2002356e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023572:	f000 bf44 	b.w	200243fe <HAL_RCC_HCPU_GetDLL3Freq>
20023576:	2001      	movs	r0, #1
20023578:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002357c:	f000 bf92 	b.w	200244a4 <HAL_RCC_GetSysCLKFreq>
20023580:	2000      	movs	r0, #0
20023582:	bd08      	pop	{r3, pc}
20023584:	50041000 	.word	0x50041000

20023588 <HAL_QSPI_GET_CLK>:
20023588:	b538      	push	{r3, r4, r5, lr}
2002358a:	4605      	mov	r5, r0
2002358c:	b908      	cbnz	r0, 20023592 <HAL_QSPI_GET_CLK+0xa>
2002358e:	2000      	movs	r0, #0
20023590:	bd38      	pop	{r3, r4, r5, pc}
20023592:	f7fe ffe4 	bl	2002255e <HAL_FLASH_GET_DIV>
20023596:	4604      	mov	r4, r0
20023598:	2800      	cmp	r0, #0
2002359a:	d0f8      	beq.n	2002358e <HAL_QSPI_GET_CLK+0x6>
2002359c:	4628      	mov	r0, r5
2002359e:	f7ff ffc9 	bl	20023534 <HAL_QSPI_GET_SRC_CLK>
200235a2:	fbb0 f0f4 	udiv	r0, r0, r4
200235a6:	e7f3      	b.n	20023590 <HAL_QSPI_GET_CLK+0x8>

200235a8 <HAL_QSPI_READ_ID>:
200235a8:	b138      	cbz	r0, 200235ba <HAL_QSPI_READ_ID+0x12>
200235aa:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
200235ae:	b113      	cbz	r3, 200235b6 <HAL_QSPI_READ_ID+0xe>
200235b0:	2100      	movs	r1, #0
200235b2:	f7ff bc5a 	b.w	20022e6a <nand_read_id>
200235b6:	f7ff bb08 	b.w	20022bca <HAL_FLASH_GET_NOR_ID>
200235ba:	20ff      	movs	r0, #255	@ 0xff
200235bc:	4770      	bx	lr

200235be <HAL_NOR_CFG_DTR>:
200235be:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200235c0:	4604      	mov	r4, r0
200235c2:	460a      	mov	r2, r1
200235c4:	b351      	cbz	r1, 2002361c <HAL_NOR_CFG_DTR+0x5e>
200235c6:	68c5      	ldr	r5, [r0, #12]
200235c8:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
200235cc:	2b00      	cmp	r3, #0
200235ce:	d03b      	beq.n	20023648 <HAL_NOR_CFG_DTR+0x8a>
200235d0:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
200235d4:	b3c3      	cbz	r3, 20023648 <HAL_NOR_CFG_DTR+0x8a>
200235d6:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
200235da:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
200235de:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
200235e2:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
200235e6:	9603      	str	r6, [sp, #12]
200235e8:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
200235ec:	9602      	str	r6, [sp, #8]
200235ee:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
200235f2:	9601      	str	r6, [sp, #4]
200235f4:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
200235f8:	9500      	str	r5, [sp, #0]
200235fa:	f7fe fefe 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
200235fe:	68e3      	ldr	r3, [r4, #12]
20023600:	4620      	mov	r0, r4
20023602:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
20023606:	f7fe feed 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
2002360a:	2101      	movs	r1, #1
2002360c:	4620      	mov	r0, r4
2002360e:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
20023612:	f7ff f8b2 	bl	2002277a <HAL_MPI_CFG_DTR>
20023616:	2000      	movs	r0, #0
20023618:	b004      	add	sp, #16
2002361a:	bd70      	pop	{r4, r5, r6, pc}
2002361c:	f7ff f8ad 	bl	2002277a <HAL_MPI_CFG_DTR>
20023620:	6963      	ldr	r3, [r4, #20]
20023622:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20023626:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
2002362a:	d906      	bls.n	2002363a <HAL_NOR_CFG_DTR+0x7c>
2002362c:	b919      	cbnz	r1, 20023636 <HAL_NOR_CFG_DTR+0x78>
2002362e:	4620      	mov	r0, r4
20023630:	f7ff f911 	bl	20022856 <HAL_FLASH_CONFIG_FULL_AHB_READ>
20023634:	e7ef      	b.n	20023616 <HAL_NOR_CFG_DTR+0x58>
20023636:	2101      	movs	r1, #1
20023638:	e7f9      	b.n	2002362e <HAL_NOR_CFG_DTR+0x70>
2002363a:	b919      	cbnz	r1, 20023644 <HAL_NOR_CFG_DTR+0x86>
2002363c:	4620      	mov	r0, r4
2002363e:	f7ff f8c6 	bl	200227ce <HAL_FLASH_CONFIG_AHB_READ>
20023642:	e7e8      	b.n	20023616 <HAL_NOR_CFG_DTR+0x58>
20023644:	2101      	movs	r1, #1
20023646:	e7f9      	b.n	2002363c <HAL_NOR_CFG_DTR+0x7e>
20023648:	2001      	movs	r0, #1
2002364a:	e7e5      	b.n	20023618 <HAL_NOR_CFG_DTR+0x5a>

2002364c <HAL_FLASH_Init>:
2002364c:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20023650:	460e      	mov	r6, r1
20023652:	4690      	mov	r8, r2
20023654:	461f      	mov	r7, r3
20023656:	4604      	mov	r4, r0
20023658:	b087      	sub	sp, #28
2002365a:	2800      	cmp	r0, #0
2002365c:	f000 80e5 	beq.w	2002382a <HAL_FLASH_Init+0x1de>
20023660:	2900      	cmp	r1, #0
20023662:	f000 80e2 	beq.w	2002382a <HAL_FLASH_Init+0x1de>
20023666:	f7fe fe9b 	bl	200223a0 <HAL_QSPI_Init>
2002366a:	6820      	ldr	r0, [r4, #0]
2002366c:	f7ff fb85 	bl	20022d7a <HAL_GET_FLASH_MID>
20023670:	6933      	ldr	r3, [r6, #16]
20023672:	2100      	movs	r1, #0
20023674:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
20023678:	68b3      	ldr	r3, [r6, #8]
2002367a:	4605      	mov	r5, r0
2002367c:	64a3      	str	r3, [r4, #72]	@ 0x48
2002367e:	68f3      	ldr	r3, [r6, #12]
20023680:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
20023684:	051b      	lsls	r3, r3, #20
20023686:	64e3      	str	r3, [r4, #76]	@ 0x4c
20023688:	2302      	movs	r3, #2
2002368a:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
2002368e:	6933      	ldr	r3, [r6, #16]
20023690:	f8c4 8008 	str.w	r8, [r4, #8]
20023694:	1e5a      	subs	r2, r3, #1
20023696:	4253      	negs	r3, r2
20023698:	4153      	adcs	r3, r2
2002369a:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
2002369e:	f1b8 0f00 	cmp.w	r8, #0
200236a2:	d058      	beq.n	20023756 <HAL_FLASH_Init+0x10a>
200236a4:	2f00      	cmp	r7, #0
200236a6:	d056      	beq.n	20023756 <HAL_FLASH_Init+0x10a>
200236a8:	683b      	ldr	r3, [r7, #0]
200236aa:	f8c8 3000 	str.w	r3, [r8]
200236ae:	68a3      	ldr	r3, [r4, #8]
200236b0:	68fa      	ldr	r2, [r7, #12]
200236b2:	605a      	str	r2, [r3, #4]
200236b4:	2210      	movs	r2, #16
200236b6:	68a3      	ldr	r3, [r4, #8]
200236b8:	609a      	str	r2, [r3, #8]
200236ba:	2280      	movs	r2, #128	@ 0x80
200236bc:	68a3      	ldr	r3, [r4, #8]
200236be:	60d9      	str	r1, [r3, #12]
200236c0:	68a3      	ldr	r3, [r4, #8]
200236c2:	611a      	str	r2, [r3, #16]
200236c4:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
200236c8:	68a3      	ldr	r3, [r4, #8]
200236ca:	6159      	str	r1, [r3, #20]
200236cc:	68a3      	ldr	r3, [r4, #8]
200236ce:	6199      	str	r1, [r3, #24]
200236d0:	68a3      	ldr	r3, [r4, #8]
200236d2:	61d9      	str	r1, [r3, #28]
200236d4:	68a3      	ldr	r3, [r4, #8]
200236d6:	621a      	str	r2, [r3, #32]
200236d8:	68a3      	ldr	r3, [r4, #8]
200236da:	6259      	str	r1, [r3, #36]	@ 0x24
200236dc:	b1c0      	cbz	r0, 20023710 <HAL_FLASH_Init+0xc4>
200236de:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200236e2:	4298      	cmp	r0, r3
200236e4:	d014      	beq.n	20023710 <HAL_FLASH_Init+0xc4>
200236e6:	2701      	movs	r7, #1
200236e8:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200236ec:	2b00      	cmp	r3, #0
200236ee:	d13d      	bne.n	2002376c <HAL_FLASH_Init+0x120>
200236f0:	2f00      	cmp	r7, #0
200236f2:	d15a      	bne.n	200237aa <HAL_FLASH_Init+0x15e>
200236f4:	4620      	mov	r0, r4
200236f6:	f7ff fb1a 	bl	20022d2e <HAL_FLASH_RELEASE_DPD>
200236fa:	4638      	mov	r0, r7
200236fc:	f7fe f933 	bl	20021966 <HAL_Delay_us>
20023700:	2032      	movs	r0, #50	@ 0x32
20023702:	f7fe f930 	bl	20021966 <HAL_Delay_us>
20023706:	4620      	mov	r0, r4
20023708:	f7ff ff4e 	bl	200235a8 <HAL_QSPI_READ_ID>
2002370c:	4605      	mov	r5, r0
2002370e:	e04c      	b.n	200237aa <HAL_FLASH_Init+0x15e>
20023710:	2101      	movs	r1, #1
20023712:	4620      	mov	r0, r4
20023714:	f7fe ff18 	bl	20022548 <HAL_FLASH_SET_TXSLOT>
20023718:	4baf      	ldr	r3, [pc, #700]	@ (200239d8 <HAL_FLASH_Init+0x38c>)
2002371a:	69a2      	ldr	r2, [r4, #24]
2002371c:	4620      	mov	r0, r4
2002371e:	429a      	cmp	r2, r3
20023720:	f04f 0200 	mov.w	r2, #0
20023724:	bf8c      	ite	hi
20023726:	2101      	movhi	r1, #1
20023728:	4611      	movls	r1, r2
2002372a:	f7ff faf9 	bl	20022d20 <HAL_QSPI_SET_CLK_INV>
2002372e:	4620      	mov	r0, r4
20023730:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
20023734:	f7fe ff0f 	bl	20022556 <HAL_FLASH_SET_CLK_rom>
20023738:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
2002373c:	b12b      	cbz	r3, 2002374a <HAL_FLASH_Init+0xfe>
2002373e:	2b01      	cmp	r3, #1
20023740:	d110      	bne.n	20023764 <HAL_FLASH_Init+0x118>
20023742:	2100      	movs	r1, #0
20023744:	4620      	mov	r0, r4
20023746:	f7fe ffdd 	bl	20022704 <HAL_FLASH_SET_DUAL_MODE>
2002374a:	2101      	movs	r1, #1
2002374c:	4620      	mov	r0, r4
2002374e:	f7fe ff68 	bl	20022622 <HAL_FLASH_ENABLE_QSPI>
20023752:	2700      	movs	r7, #0
20023754:	e7c8      	b.n	200236e8 <HAL_FLASH_Init+0x9c>
20023756:	2d00      	cmp	r5, #0
20023758:	d0de      	beq.n	20023718 <HAL_FLASH_Init+0xcc>
2002375a:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
2002375e:	429d      	cmp	r5, r3
20023760:	d1c1      	bne.n	200236e6 <HAL_FLASH_Init+0x9a>
20023762:	e7d9      	b.n	20023718 <HAL_FLASH_Init+0xcc>
20023764:	2b02      	cmp	r3, #2
20023766:	d1f0      	bne.n	2002374a <HAL_FLASH_Init+0xfe>
20023768:	2101      	movs	r1, #1
2002376a:	e7eb      	b.n	20023744 <HAL_FLASH_Init+0xf8>
2002376c:	6822      	ldr	r2, [r4, #0]
2002376e:	2600      	movs	r6, #0
20023770:	6893      	ldr	r3, [r2, #8]
20023772:	4631      	mov	r1, r6
20023774:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
20023778:	6093      	str	r3, [r2, #8]
2002377a:	2301      	movs	r3, #1
2002377c:	4632      	mov	r2, r6
2002377e:	4620      	mov	r0, r4
20023780:	e9cd 6303 	strd	r6, r3, [sp, #12]
20023784:	e9cd 6601 	strd	r6, r6, [sp, #4]
20023788:	4633      	mov	r3, r6
2002378a:	9600      	str	r6, [sp, #0]
2002378c:	f7fe feec 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023790:	4632      	mov	r2, r6
20023792:	21ff      	movs	r1, #255	@ 0xff
20023794:	4620      	mov	r0, r4
20023796:	f7fe fea2 	bl	200224de <HAL_FLASH_SET_CMD>
2002379a:	4630      	mov	r0, r6
2002379c:	f7fe f8e3 	bl	20021966 <HAL_Delay_us>
200237a0:	20c8      	movs	r0, #200	@ 0xc8
200237a2:	f7fe f8e0 	bl	20021966 <HAL_Delay_us>
200237a6:	2f00      	cmp	r7, #0
200237a8:	d0ad      	beq.n	20023706 <HAL_FLASH_Init+0xba>
200237aa:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200237ae:	b2ee      	uxtb	r6, r5
200237b0:	f3c5 2807 	ubfx	r8, r5, #8, #8
200237b4:	6425      	str	r5, [r4, #64]	@ 0x40
200237b6:	f3c5 4507 	ubfx	r5, r5, #16, #8
200237ba:	4642      	mov	r2, r8
200237bc:	4629      	mov	r1, r5
200237be:	4630      	mov	r0, r6
200237c0:	b3ab      	cbz	r3, 2002382e <HAL_FLASH_Init+0x1e2>
200237c2:	f001 f891 	bl	200248e8 <spi_nand_get_cmd_by_id>
200237c6:	60e0      	str	r0, [r4, #12]
200237c8:	bba0      	cbnz	r0, 20023834 <HAL_FLASH_Init+0x1e8>
200237ca:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200237ce:	b32b      	cbz	r3, 2002381c <HAL_FLASH_Init+0x1d0>
200237d0:	2108      	movs	r1, #8
200237d2:	4620      	mov	r0, r4
200237d4:	f7ff fb49 	bl	20022e6a <nand_read_id>
200237d8:	f3c0 2807 	ubfx	r8, r0, #8, #8
200237dc:	f3c0 4507 	ubfx	r5, r0, #16, #8
200237e0:	b2c6      	uxtb	r6, r0
200237e2:	6420      	str	r0, [r4, #64]	@ 0x40
200237e4:	4642      	mov	r2, r8
200237e6:	4629      	mov	r1, r5
200237e8:	4630      	mov	r0, r6
200237ea:	f001 f87d 	bl	200248e8 <spi_nand_get_cmd_by_id>
200237ee:	60e0      	str	r0, [r4, #12]
200237f0:	bb00      	cbnz	r0, 20023834 <HAL_FLASH_Init+0x1e8>
200237f2:	210f      	movs	r1, #15
200237f4:	4620      	mov	r0, r4
200237f6:	f7ff fb38 	bl	20022e6a <nand_read_id>
200237fa:	f3c0 2807 	ubfx	r8, r0, #8, #8
200237fe:	f3c0 4507 	ubfx	r5, r0, #16, #8
20023802:	b2c6      	uxtb	r6, r0
20023804:	6420      	str	r0, [r4, #64]	@ 0x40
20023806:	4642      	mov	r2, r8
20023808:	4629      	mov	r1, r5
2002380a:	4630      	mov	r0, r6
2002380c:	f001 f86c 	bl	200248e8 <spi_nand_get_cmd_by_id>
20023810:	60e0      	str	r0, [r4, #12]
20023812:	b978      	cbnz	r0, 20023834 <HAL_FLASH_Init+0x1e8>
20023814:	f001 f880 	bl	20024918 <spi_nand_get_default_ctable>
20023818:	60e0      	str	r0, [r4, #12]
2002381a:	b958      	cbnz	r0, 20023834 <HAL_FLASH_Init+0x1e8>
2002381c:	2100      	movs	r1, #0
2002381e:	4620      	mov	r0, r4
20023820:	f7fe feff 	bl	20022622 <HAL_FLASH_ENABLE_QSPI>
20023824:	2300      	movs	r3, #0
20023826:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
2002382a:	2001      	movs	r0, #1
2002382c:	e052      	b.n	200238d4 <HAL_FLASH_Init+0x288>
2002382e:	f000 fffd 	bl	2002482c <spi_flash_get_cmd_by_id>
20023832:	e7c8      	b.n	200237c6 <HAL_FLASH_Init+0x17a>
20023834:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023838:	4642      	mov	r2, r8
2002383a:	4629      	mov	r1, r5
2002383c:	4630      	mov	r0, r6
2002383e:	2b00      	cmp	r3, #0
20023840:	d04b      	beq.n	200238da <HAL_FLASH_Init+0x28e>
20023842:	f001 f877 	bl	20024934 <spi_nand_get_size_by_id>
20023846:	4642      	mov	r2, r8
20023848:	4629      	mov	r1, r5
2002384a:	4681      	mov	r9, r0
2002384c:	4630      	mov	r0, r6
2002384e:	f001 f87b 	bl	20024948 <spi_nand_get_plane_select_flag>
20023852:	4642      	mov	r2, r8
20023854:	4629      	mov	r1, r5
20023856:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
2002385a:	4630      	mov	r0, r6
2002385c:	f001 f87d 	bl	2002495a <spi_nand_get_big_page_flag>
20023860:	4642      	mov	r2, r8
20023862:	4629      	mov	r1, r5
20023864:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
20023868:	4630      	mov	r0, r6
2002386a:	f001 f87f 	bl	2002496c <spi_nand_get_ecc_mode>
2002386e:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
20023872:	4642      	mov	r2, r8
20023874:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
20023878:	4629      	mov	r1, r5
2002387a:	4630      	mov	r0, r6
2002387c:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
20023880:	f001 f844 	bl	2002490c <spi_nand_get_ext_cfg_by_id>
20023884:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023886:	f1b9 0f00 	cmp.w	r9, #0
2002388a:	d003      	beq.n	20023894 <HAL_FLASH_Init+0x248>
2002388c:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
20023890:	f8c4 9014 	str.w	r9, [r4, #20]
20023894:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023898:	2b00      	cmp	r3, #0
2002389a:	d17d      	bne.n	20023998 <HAL_FLASH_Init+0x34c>
2002389c:	2f00      	cmp	r7, #0
2002389e:	d178      	bne.n	20023992 <HAL_FLASH_Init+0x346>
200238a0:	4620      	mov	r0, r4
200238a2:	f7ff f9ad 	bl	20022c00 <HAL_FLASH_CLR_PROTECT>
200238a6:	6963      	ldr	r3, [r4, #20]
200238a8:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
200238ac:	d945      	bls.n	2002393a <HAL_FLASH_Init+0x2ee>
200238ae:	463a      	mov	r2, r7
200238b0:	2121      	movs	r1, #33	@ 0x21
200238b2:	4620      	mov	r0, r4
200238b4:	f7ff f833 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200238b8:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200238bc:	bb0b      	cbnz	r3, 20023902 <HAL_FLASH_Init+0x2b6>
200238be:	4639      	mov	r1, r7
200238c0:	4620      	mov	r0, r4
200238c2:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
200238c6:	f7ff f975 	bl	20022bb4 <HAL_FLASH_FADDR_SET_QSPI>
200238ca:	2107      	movs	r1, #7
200238cc:	4620      	mov	r0, r4
200238ce:	f7fe ff02 	bl	200226d6 <HAL_FLASH_SET_ROW_BOUNDARY>
200238d2:	2000      	movs	r0, #0
200238d4:	b007      	add	sp, #28
200238d6:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200238da:	f000 ffbb 	bl	20024854 <spi_flash_get_size_by_id>
200238de:	4642      	mov	r2, r8
200238e0:	4629      	mov	r1, r5
200238e2:	4681      	mov	r9, r0
200238e4:	4630      	mov	r0, r6
200238e6:	f000 ffc9 	bl	2002487c <spi_flash_get_otp_base>
200238ea:	4642      	mov	r2, r8
200238ec:	63a0      	str	r0, [r4, #56]	@ 0x38
200238ee:	4629      	mov	r1, r5
200238f0:	4630      	mov	r0, r6
200238f2:	f000 ff73 	bl	200247dc <spi_nor_get_ext_cfg_by_id>
200238f6:	63e0      	str	r0, [r4, #60]	@ 0x3c
200238f8:	2800      	cmp	r0, #0
200238fa:	d0c4      	beq.n	20023886 <HAL_FLASH_Init+0x23a>
200238fc:	6803      	ldr	r3, [r0, #0]
200238fe:	63a3      	str	r3, [r4, #56]	@ 0x38
20023900:	e7c1      	b.n	20023886 <HAL_FLASH_Init+0x23a>
20023902:	2101      	movs	r1, #1
20023904:	4620      	mov	r0, r4
20023906:	f7ff f955 	bl	20022bb4 <HAL_FLASH_FADDR_SET_QSPI>
2002390a:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
2002390e:	f1b9 0f01 	cmp.w	r9, #1
20023912:	d1da      	bne.n	200238ca <HAL_FLASH_Init+0x27e>
20023914:	4642      	mov	r2, r8
20023916:	4629      	mov	r1, r5
20023918:	4630      	mov	r0, r6
2002391a:	f000 ffa5 	bl	20024868 <spi_flash_is_support_dtr>
2002391e:	b120      	cbz	r0, 2002392a <HAL_FLASH_Init+0x2de>
20023920:	4649      	mov	r1, r9
20023922:	4620      	mov	r0, r4
20023924:	f7ff fe4b 	bl	200235be <HAL_NOR_CFG_DTR>
20023928:	e7cf      	b.n	200238ca <HAL_FLASH_Init+0x27e>
2002392a:	463a      	mov	r2, r7
2002392c:	4639      	mov	r1, r7
2002392e:	4620      	mov	r0, r4
20023930:	f7fe ff23 	bl	2002277a <HAL_MPI_CFG_DTR>
20023934:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023938:	e7c7      	b.n	200238ca <HAL_FLASH_Init+0x27e>
2002393a:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
2002393e:	b933      	cbnz	r3, 2002394e <HAL_FLASH_Init+0x302>
20023940:	4639      	mov	r1, r7
20023942:	4620      	mov	r0, r4
20023944:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023948:	f7ff f929 	bl	20022b9e <HAL_FLASH_SET_QUAL_SPI>
2002394c:	e7c1      	b.n	200238d2 <HAL_FLASH_Init+0x286>
2002394e:	2101      	movs	r1, #1
20023950:	4620      	mov	r0, r4
20023952:	f7ff f924 	bl	20022b9e <HAL_FLASH_SET_QUAL_SPI>
20023956:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
2002395a:	f1b9 0f01 	cmp.w	r9, #1
2002395e:	d112      	bne.n	20023986 <HAL_FLASH_Init+0x33a>
20023960:	4642      	mov	r2, r8
20023962:	4629      	mov	r1, r5
20023964:	4630      	mov	r0, r6
20023966:	f000 ff7f 	bl	20024868 <spi_flash_is_support_dtr>
2002396a:	b120      	cbz	r0, 20023976 <HAL_FLASH_Init+0x32a>
2002396c:	4649      	mov	r1, r9
2002396e:	4620      	mov	r0, r4
20023970:	f7ff fe25 	bl	200235be <HAL_NOR_CFG_DTR>
20023974:	e7ad      	b.n	200238d2 <HAL_FLASH_Init+0x286>
20023976:	463a      	mov	r2, r7
20023978:	4639      	mov	r1, r7
2002397a:	4620      	mov	r0, r4
2002397c:	f7fe fefd 	bl	2002277a <HAL_MPI_CFG_DTR>
20023980:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023984:	e7a5      	b.n	200238d2 <HAL_FLASH_Init+0x286>
20023986:	463a      	mov	r2, r7
20023988:	4639      	mov	r1, r7
2002398a:	4620      	mov	r0, r4
2002398c:	f7fe fef5 	bl	2002277a <HAL_MPI_CFG_DTR>
20023990:	e79f      	b.n	200238d2 <HAL_FLASH_Init+0x286>
20023992:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023996:	e79c      	b.n	200238d2 <HAL_FLASH_Init+0x286>
20023998:	2101      	movs	r1, #1
2002399a:	4620      	mov	r0, r4
2002399c:	f7fe fd7a 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
200239a0:	68e3      	ldr	r3, [r4, #12]
200239a2:	2102      	movs	r1, #2
200239a4:	791a      	ldrb	r2, [r3, #4]
200239a6:	4620      	mov	r0, r4
200239a8:	f7fe ffb9 	bl	2002291e <HAL_FLASH_ISSUE_CMD>
200239ac:	4620      	mov	r0, r4
200239ae:	f7fe fdc7 	bl	20022540 <HAL_FLASH_READ32>
200239b2:	4605      	mov	r5, r0
200239b4:	200a      	movs	r0, #10
200239b6:	f7fd ffd6 	bl	20021966 <HAL_Delay_us>
200239ba:	07eb      	lsls	r3, r5, #31
200239bc:	d4ec      	bmi.n	20023998 <HAL_FLASH_Init+0x34c>
200239be:	4631      	mov	r1, r6
200239c0:	4620      	mov	r0, r4
200239c2:	f7ff fb9e 	bl	20023102 <nand_clear_status>
200239c6:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200239ca:	2b02      	cmp	r3, #2
200239cc:	d181      	bne.n	200238d2 <HAL_FLASH_Init+0x286>
200239ce:	2101      	movs	r1, #1
200239d0:	4620      	mov	r0, r4
200239d2:	f7ff fb65 	bl	200230a0 <HAL_NAND_EN_QUAL>
200239d6:	e77c      	b.n	200238d2 <HAL_FLASH_Init+0x286>
200239d8:	03938700 	.word	0x03938700

200239dc <HAL_MPI_OPSRAM_CAL_DELAY>:
200239dc:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200239e0:	4b21      	ldr	r3, [pc, #132]	@ (20023a68 <HAL_MPI_OPSRAM_CAL_DELAY+0x8c>)
200239e2:	4616      	mov	r6, r2
200239e4:	6982      	ldr	r2, [r0, #24]
200239e6:	4605      	mov	r5, r0
200239e8:	429a      	cmp	r2, r3
200239ea:	460f      	mov	r7, r1
200239ec:	d805      	bhi.n	200239fa <HAL_MPI_OPSRAM_CAL_DELAY+0x1e>
200239ee:	231f      	movs	r3, #31
200239f0:	2000      	movs	r0, #0
200239f2:	700b      	strb	r3, [r1, #0]
200239f4:	7033      	strb	r3, [r6, #0]
200239f6:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200239fa:	f04f 4200 	mov.w	r2, #2147483648	@ 0x80000000
200239fe:	6803      	ldr	r3, [r0, #0]
20023a00:	2000      	movs	r0, #0
20023a02:	65da      	str	r2, [r3, #92]	@ 0x5c
20023a04:	f7fd ffaf 	bl	20021966 <HAL_Delay_us>
20023a08:	2400      	movs	r4, #0
20023a0a:	682b      	ldr	r3, [r5, #0]
20023a0c:	0222      	lsls	r2, r4, #8
20023a0e:	659a      	str	r2, [r3, #88]	@ 0x58
20023a10:	200a      	movs	r0, #10
20023a12:	f7fd ffa8 	bl	20021966 <HAL_Delay_us>
20023a16:	682b      	ldr	r3, [r5, #0]
20023a18:	46a0      	mov	r8, r4
20023a1a:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023a1c:	3401      	adds	r4, #1
20023a1e:	03da      	lsls	r2, r3, #15
20023a20:	d502      	bpl.n	20023a28 <HAL_MPI_OPSRAM_CAL_DELAY+0x4c>
20023a22:	2c80      	cmp	r4, #128	@ 0x80
20023a24:	d1f1      	bne.n	20023a0a <HAL_MPI_OPSRAM_CAL_DELAY+0x2e>
20023a26:	46a0      	mov	r8, r4
20023a28:	f108 0401 	add.w	r4, r8, #1
20023a2c:	2c7f      	cmp	r4, #127	@ 0x7f
20023a2e:	d905      	bls.n	20023a3c <HAL_MPI_OPSRAM_CAL_DELAY+0x60>
20023a30:	2001      	movs	r0, #1
20023a32:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
20023a36:	682b      	ldr	r3, [r5, #0]
20023a38:	65da      	str	r2, [r3, #92]	@ 0x5c
20023a3a:	e7dc      	b.n	200239f6 <HAL_MPI_OPSRAM_CAL_DELAY+0x1a>
20023a3c:	682b      	ldr	r3, [r5, #0]
20023a3e:	0222      	lsls	r2, r4, #8
20023a40:	659a      	str	r2, [r3, #88]	@ 0x58
20023a42:	200a      	movs	r0, #10
20023a44:	f7fd ff8f 	bl	20021966 <HAL_Delay_us>
20023a48:	682b      	ldr	r3, [r5, #0]
20023a4a:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023a4c:	03db      	lsls	r3, r3, #15
20023a4e:	d401      	bmi.n	20023a54 <HAL_MPI_OPSRAM_CAL_DELAY+0x78>
20023a50:	3401      	adds	r4, #1
20023a52:	e7eb      	b.n	20023a2c <HAL_MPI_OPSRAM_CAL_DELAY+0x50>
20023a54:	eba4 0408 	sub.w	r4, r4, r8
20023a58:	f3c4 0447 	ubfx	r4, r4, #1, #8
20023a5c:	1f63      	subs	r3, r4, #5
20023a5e:	703b      	strb	r3, [r7, #0]
20023a60:	2000      	movs	r0, #0
20023a62:	7034      	strb	r4, [r6, #0]
20023a64:	e7e5      	b.n	20023a32 <HAL_MPI_OPSRAM_CAL_DELAY+0x56>
20023a66:	bf00      	nop
20023a68:	016e3600 	.word	0x016e3600

20023a6c <HAL_SPI_PSRAM_Init>:
20023a6c:	b537      	push	{r0, r1, r2, r4, r5, lr}
20023a6e:	4614      	mov	r4, r2
20023a70:	4605      	mov	r5, r0
20023a72:	2800      	cmp	r0, #0
20023a74:	d043      	beq.n	20023afe <HAL_SPI_PSRAM_Init+0x92>
20023a76:	2900      	cmp	r1, #0
20023a78:	d041      	beq.n	20023afe <HAL_SPI_PSRAM_Init+0x92>
20023a7a:	f7fe fc91 	bl	200223a0 <HAL_QSPI_Init>
20023a7e:	4628      	mov	r0, r5
20023a80:	b2e1      	uxtb	r1, r4
20023a82:	f7fe fd68 	bl	20022556 <HAL_FLASH_SET_CLK_rom>
20023a86:	4628      	mov	r0, r5
20023a88:	f7ff fd7e 	bl	20023588 <HAL_QSPI_GET_CLK>
20023a8c:	4b1d      	ldr	r3, [pc, #116]	@ (20023b04 <HAL_SPI_PSRAM_Init+0x98>)
20023a8e:	4298      	cmp	r0, r3
20023a90:	d930      	bls.n	20023af4 <HAL_SPI_PSRAM_Init+0x88>
20023a92:	4b1d      	ldr	r3, [pc, #116]	@ (20023b08 <HAL_SPI_PSRAM_Init+0x9c>)
20023a94:	4298      	cmp	r0, r3
20023a96:	d92f      	bls.n	20023af8 <HAL_SPI_PSRAM_Init+0x8c>
20023a98:	4b1c      	ldr	r3, [pc, #112]	@ (20023b0c <HAL_SPI_PSRAM_Init+0xa0>)
20023a9a:	4298      	cmp	r0, r3
20023a9c:	d922      	bls.n	20023ae4 <HAL_SPI_PSRAM_Init+0x78>
20023a9e:	f240 34b6 	movw	r4, #950	@ 0x3b6
20023aa2:	f240 4374 	movw	r3, #1140	@ 0x474
20023aa6:	4a1a      	ldr	r2, [pc, #104]	@ (20023b10 <HAL_SPI_PSRAM_Init+0xa4>)
20023aa8:	4290      	cmp	r0, r2
20023aaa:	bf88      	it	hi
20023aac:	461c      	movhi	r4, r3
20023aae:	2200      	movs	r2, #0
20023ab0:	2101      	movs	r1, #1
20023ab2:	4628      	mov	r0, r5
20023ab4:	f7ff f934 	bl	20022d20 <HAL_QSPI_SET_CLK_INV>
20023ab8:	2100      	movs	r1, #0
20023aba:	4622      	mov	r2, r4
20023abc:	2302      	movs	r3, #2
20023abe:	4628      	mov	r0, r5
20023ac0:	9100      	str	r1, [sp, #0]
20023ac2:	f7fe fdf3 	bl	200226ac <HAL_FLASH_SET_CS_TIME>
20023ac6:	4604      	mov	r4, r0
20023ac8:	b948      	cbnz	r0, 20023ade <HAL_SPI_PSRAM_Init+0x72>
20023aca:	2106      	movs	r1, #6
20023acc:	4628      	mov	r0, r5
20023ace:	f7fe fe02 	bl	200226d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20023ad2:	4604      	mov	r4, r0
20023ad4:	b918      	cbnz	r0, 20023ade <HAL_SPI_PSRAM_Init+0x72>
20023ad6:	2101      	movs	r1, #1
20023ad8:	4628      	mov	r0, r5
20023ada:	f7fe fda2 	bl	20022622 <HAL_FLASH_ENABLE_QSPI>
20023ade:	4620      	mov	r0, r4
20023ae0:	b003      	add	sp, #12
20023ae2:	bd30      	pop	{r4, r5, pc}
20023ae4:	4b0b      	ldr	r3, [pc, #44]	@ (20023b14 <HAL_SPI_PSRAM_Init+0xa8>)
20023ae6:	f44f 743e 	mov.w	r4, #760	@ 0x2f8
20023aea:	4298      	cmp	r0, r3
20023aec:	d8df      	bhi.n	20023aae <HAL_SPI_PSRAM_Init+0x42>
20023aee:	2200      	movs	r2, #0
20023af0:	4611      	mov	r1, r2
20023af2:	e7de      	b.n	20023ab2 <HAL_SPI_PSRAM_Init+0x46>
20023af4:	24b4      	movs	r4, #180	@ 0xb4
20023af6:	e7fa      	b.n	20023aee <HAL_SPI_PSRAM_Init+0x82>
20023af8:	f44f 74be 	mov.w	r4, #380	@ 0x17c
20023afc:	e7f7      	b.n	20023aee <HAL_SPI_PSRAM_Init+0x82>
20023afe:	2401      	movs	r4, #1
20023b00:	e7ed      	b.n	20023ade <HAL_SPI_PSRAM_Init+0x72>
20023b02:	bf00      	nop
20023b04:	016e3600 	.word	0x016e3600
20023b08:	02dc6c00 	.word	0x02dc6c00
20023b0c:	05b8d800 	.word	0x05b8d800
20023b10:	07270e00 	.word	0x07270e00
20023b14:	03938700 	.word	0x03938700

20023b18 <HAL_MPI_MR_WRITE>:
20023b18:	b5f0      	push	{r4, r5, r6, r7, lr}
20023b1a:	460e      	mov	r6, r1
20023b1c:	4617      	mov	r7, r2
20023b1e:	4605      	mov	r5, r0
20023b20:	b087      	sub	sp, #28
20023b22:	b1d8      	cbz	r0, 20023b5c <HAL_MPI_MR_WRITE+0x44>
20023b24:	2207      	movs	r2, #7
20023b26:	2400      	movs	r4, #0
20023b28:	2303      	movs	r3, #3
20023b2a:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023b2e:	2101      	movs	r1, #1
20023b30:	e9cd 4301 	strd	r4, r3, [sp, #4]
20023b34:	9400      	str	r4, [sp, #0]
20023b36:	4623      	mov	r3, r4
20023b38:	f7fe fd16 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023b3c:	2102      	movs	r1, #2
20023b3e:	4628      	mov	r0, r5
20023b40:	f7fe fca8 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20023b44:	4639      	mov	r1, r7
20023b46:	4628      	mov	r0, r5
20023b48:	f7fe fc9d 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20023b4c:	4632      	mov	r2, r6
20023b4e:	21c0      	movs	r1, #192	@ 0xc0
20023b50:	4628      	mov	r0, r5
20023b52:	f7fe fcc4 	bl	200224de <HAL_FLASH_SET_CMD>
20023b56:	4620      	mov	r0, r4
20023b58:	b007      	add	sp, #28
20023b5a:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023b5c:	2001      	movs	r0, #1
20023b5e:	e7fb      	b.n	20023b58 <HAL_MPI_MR_WRITE+0x40>

20023b60 <HAL_MPI_SET_FIXLAT>:
20023b60:	e92d 41ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, lr}
20023b64:	460c      	mov	r4, r1
20023b66:	4616      	mov	r6, r2
20023b68:	461f      	mov	r7, r3
20023b6a:	4605      	mov	r5, r0
20023b6c:	2800      	cmp	r0, #0
20023b6e:	d040      	beq.n	20023bf2 <HAL_MPI_SET_FIXLAT+0x92>
20023b70:	466b      	mov	r3, sp
20023b72:	4a21      	ldr	r2, [pc, #132]	@ (20023bf8 <HAL_MPI_SET_FIXLAT+0x98>)
20023b74:	6810      	ldr	r0, [r2, #0]
20023b76:	6851      	ldr	r1, [r2, #4]
20023b78:	c303      	stmia	r3!, {r0, r1}
20023b7a:	6890      	ldr	r0, [r2, #8]
20023b7c:	68d1      	ldr	r1, [r2, #12]
20023b7e:	c303      	stmia	r3!, {r0, r1}
20023b80:	4628      	mov	r0, r5
20023b82:	b2e1      	uxtb	r1, r4
20023b84:	f7fe fdda 	bl	2002273c <HAL_MPI_EN_FIXLAT>
20023b88:	f107 0310 	add.w	r3, r7, #16
20023b8c:	446b      	add	r3, sp
20023b8e:	f813 8c08 	ldrb.w	r8, [r3, #-8]
20023b92:	ea4f 1848 	mov.w	r8, r8, lsl #5
20023b96:	fa5f f888 	uxtb.w	r8, r8
20023b9a:	b30c      	cbz	r4, 20023be0 <HAL_MPI_SET_FIXLAT+0x80>
20023b9c:	ab04      	add	r3, sp, #16
20023b9e:	eb03 0356 	add.w	r3, r3, r6, lsr #1
20023ba2:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023ba6:	00a4      	lsls	r4, r4, #2
20023ba8:	f044 0421 	orr.w	r4, r4, #33	@ 0x21
20023bac:	b264      	sxtb	r4, r4
20023bae:	f004 02fd 	and.w	r2, r4, #253	@ 0xfd
20023bb2:	2100      	movs	r1, #0
20023bb4:	4628      	mov	r0, r5
20023bb6:	f7ff ffaf 	bl	20023b18 <HAL_MPI_MR_WRITE>
20023bba:	1e71      	subs	r1, r6, #1
20023bbc:	4628      	mov	r0, r5
20023bbe:	b249      	sxtb	r1, r1
20023bc0:	f7fe fde6 	bl	20022790 <HAL_MPI_MODIFY_RCMD_DELAY>
20023bc4:	4642      	mov	r2, r8
20023bc6:	2104      	movs	r1, #4
20023bc8:	4628      	mov	r0, r5
20023bca:	f7ff ffa5 	bl	20023b18 <HAL_MPI_MR_WRITE>
20023bce:	1e79      	subs	r1, r7, #1
20023bd0:	4628      	mov	r0, r5
20023bd2:	b249      	sxtb	r1, r1
20023bd4:	f7fe fde5 	bl	200227a2 <HAL_MPI_MODIFY_WCMD_DELAY>
20023bd8:	2000      	movs	r0, #0
20023bda:	b004      	add	sp, #16
20023bdc:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023be0:	f106 0310 	add.w	r3, r6, #16
20023be4:	446b      	add	r3, sp
20023be6:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023bea:	00a4      	lsls	r4, r4, #2
20023bec:	f044 0401 	orr.w	r4, r4, #1
20023bf0:	e7dc      	b.n	20023bac <HAL_MPI_SET_FIXLAT+0x4c>
20023bf2:	2001      	movs	r0, #1
20023bf4:	e7f1      	b.n	20023bda <HAL_MPI_SET_FIXLAT+0x7a>
20023bf6:	bf00      	nop
20023bf8:	2002700c 	.word	0x2002700c

20023bfc <HAL_LEGACY_MR_WRITE>:
20023bfc:	b5f0      	push	{r4, r5, r6, r7, lr}
20023bfe:	460e      	mov	r6, r1
20023c00:	4617      	mov	r7, r2
20023c02:	4604      	mov	r4, r0
20023c04:	b087      	sub	sp, #28
20023c06:	b1e0      	cbz	r0, 20023c42 <HAL_LEGACY_MR_WRITE+0x46>
20023c08:	2207      	movs	r2, #7
20023c0a:	2500      	movs	r5, #0
20023c0c:	2302      	movs	r3, #2
20023c0e:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023c12:	e9cd 5301 	strd	r5, r3, [sp, #4]
20023c16:	9500      	str	r5, [sp, #0]
20023c18:	f990 302e 	ldrsb.w	r3, [r0, #46]	@ 0x2e
20023c1c:	2101      	movs	r1, #1
20023c1e:	f7fe fca3 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023c22:	2104      	movs	r1, #4
20023c24:	4620      	mov	r0, r4
20023c26:	f7fe fc35 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20023c2a:	4639      	mov	r1, r7
20023c2c:	4620      	mov	r0, r4
20023c2e:	f7fe fc2a 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20023c32:	4632      	mov	r2, r6
20023c34:	21c0      	movs	r1, #192	@ 0xc0
20023c36:	4620      	mov	r0, r4
20023c38:	f7fe fc51 	bl	200224de <HAL_FLASH_SET_CMD>
20023c3c:	4628      	mov	r0, r5
20023c3e:	b007      	add	sp, #28
20023c40:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023c42:	2001      	movs	r0, #1
20023c44:	e7fb      	b.n	20023c3e <HAL_LEGACY_MR_WRITE+0x42>

20023c46 <HAL_LEGACY_CFG_READ>:
20023c46:	b530      	push	{r4, r5, lr}
20023c48:	4605      	mov	r5, r0
20023c4a:	b085      	sub	sp, #20
20023c4c:	b1a0      	cbz	r0, 20023c78 <HAL_LEGACY_CFG_READ+0x32>
20023c4e:	2400      	movs	r4, #0
20023c50:	2107      	movs	r1, #7
20023c52:	2302      	movs	r3, #2
20023c54:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20023c58:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023c5c:	0052      	lsls	r2, r2, #1
20023c5e:	e9cd 4300 	strd	r4, r3, [sp]
20023c62:	b252      	sxtb	r2, r2
20023c64:	4623      	mov	r3, r4
20023c66:	f7fe fbc8 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
20023c6a:	4621      	mov	r1, r4
20023c6c:	4628      	mov	r0, r5
20023c6e:	f7fe fbb9 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
20023c72:	4620      	mov	r0, r4
20023c74:	b005      	add	sp, #20
20023c76:	bd30      	pop	{r4, r5, pc}
20023c78:	2001      	movs	r0, #1
20023c7a:	e7fb      	b.n	20023c74 <HAL_LEGACY_CFG_READ+0x2e>

20023c7c <HAL_LEGACY_CFG_WRITE>:
20023c7c:	b530      	push	{r4, r5, lr}
20023c7e:	4605      	mov	r5, r0
20023c80:	b085      	sub	sp, #20
20023c82:	b190      	cbz	r0, 20023caa <HAL_LEGACY_CFG_WRITE+0x2e>
20023c84:	2107      	movs	r1, #7
20023c86:	2400      	movs	r4, #0
20023c88:	2302      	movs	r3, #2
20023c8a:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023c8e:	e9cd 4300 	strd	r4, r3, [sp]
20023c92:	4623      	mov	r3, r4
20023c94:	f990 202e 	ldrsb.w	r2, [r0, #46]	@ 0x2e
20023c98:	f7fe fbd8 	bl	2002244c <HAL_FLASH_CFG_AHB_WCMD>
20023c9c:	2180      	movs	r1, #128	@ 0x80
20023c9e:	4628      	mov	r0, r5
20023ca0:	f7fe fbc8 	bl	20022434 <HAL_FLASH_SET_AHB_WCMD>
20023ca4:	4620      	mov	r0, r4
20023ca6:	b005      	add	sp, #20
20023ca8:	bd30      	pop	{r4, r5, pc}
20023caa:	2001      	movs	r0, #1
20023cac:	e7fb      	b.n	20023ca6 <HAL_LEGACY_CFG_WRITE+0x2a>

20023cae <HAL_PSRAM_RESET>:
20023cae:	b5f0      	push	{r4, r5, r6, r7, lr}
20023cb0:	4604      	mov	r4, r0
20023cb2:	b087      	sub	sp, #28
20023cb4:	2800      	cmp	r0, #0
20023cb6:	d03b      	beq.n	20023d30 <HAL_PSRAM_RESET+0x82>
20023cb8:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
20023cbc:	2b05      	cmp	r3, #5
20023cbe:	d034      	beq.n	20023d2a <HAL_PSRAM_RESET+0x7c>
20023cc0:	3b03      	subs	r3, #3
20023cc2:	2b01      	cmp	r3, #1
20023cc4:	d82e      	bhi.n	20023d24 <HAL_PSRAM_RESET+0x76>
20023cc6:	2601      	movs	r6, #1
20023cc8:	2703      	movs	r7, #3
20023cca:	2300      	movs	r3, #0
20023ccc:	2507      	movs	r5, #7
20023cce:	b276      	sxtb	r6, r6
20023cd0:	b27f      	sxtb	r7, r7
20023cd2:	461a      	mov	r2, r3
20023cd4:	2101      	movs	r1, #1
20023cd6:	4620      	mov	r0, r4
20023cd8:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023cdc:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023ce0:	9600      	str	r6, [sp, #0]
20023ce2:	f7fe fc41 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023ce6:	2200      	movs	r2, #0
20023ce8:	21ff      	movs	r1, #255	@ 0xff
20023cea:	4620      	mov	r0, r4
20023cec:	f7fe fbf7 	bl	200224de <HAL_FLASH_SET_CMD>
20023cf0:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023cf4:	2b05      	cmp	r3, #5
20023cf6:	d10f      	bne.n	20023d18 <HAL_PSRAM_RESET+0x6a>
20023cf8:	2300      	movs	r3, #0
20023cfa:	2101      	movs	r1, #1
20023cfc:	461a      	mov	r2, r3
20023cfe:	4620      	mov	r0, r4
20023d00:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023d04:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023d08:	9600      	str	r6, [sp, #0]
20023d0a:	f7fe fc2d 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023d0e:	2200      	movs	r2, #0
20023d10:	21ff      	movs	r1, #255	@ 0xff
20023d12:	4620      	mov	r0, r4
20023d14:	f7fe fbe3 	bl	200224de <HAL_FLASH_SET_CMD>
20023d18:	2000      	movs	r0, #0
20023d1a:	f7fd fe24 	bl	20021966 <HAL_Delay_us>
20023d1e:	2003      	movs	r0, #3
20023d20:	f7fd fe21 	bl	20021966 <HAL_Delay_us>
20023d24:	2000      	movs	r0, #0
20023d26:	b007      	add	sp, #28
20023d28:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023d2a:	2603      	movs	r6, #3
20023d2c:	2702      	movs	r7, #2
20023d2e:	e7cc      	b.n	20023cca <HAL_PSRAM_RESET+0x1c>
20023d30:	2001      	movs	r0, #1
20023d32:	e7f8      	b.n	20023d26 <HAL_PSRAM_RESET+0x78>

20023d34 <HAL_OPI_PSRAM_Init>:
20023d34:	b530      	push	{r4, r5, lr}
20023d36:	4604      	mov	r4, r0
20023d38:	b085      	sub	sp, #20
20023d3a:	2800      	cmp	r0, #0
20023d3c:	d076      	beq.n	20023e2c <HAL_OPI_PSRAM_Init+0xf8>
20023d3e:	2900      	cmp	r1, #0
20023d40:	d074      	beq.n	20023e2c <HAL_OPI_PSRAM_Init+0xf8>
20023d42:	f7fe fb2d 	bl	200223a0 <HAL_QSPI_Init>
20023d46:	6823      	ldr	r3, [r4, #0]
20023d48:	2101      	movs	r1, #1
20023d4a:	4620      	mov	r0, r4
20023d4c:	681d      	ldr	r5, [r3, #0]
20023d4e:	f7fe fc76 	bl	2002263e <HAL_FLASH_ENABLE_OPI>
20023d52:	2101      	movs	r1, #1
20023d54:	4620      	mov	r0, r4
20023d56:	f7fe fbfe 	bl	20022556 <HAL_FLASH_SET_CLK_rom>
20023d5a:	4620      	mov	r0, r4
20023d5c:	f7ff fc14 	bl	20023588 <HAL_QSPI_GET_CLK>
20023d60:	0840      	lsrs	r0, r0, #1
20023d62:	61a0      	str	r0, [r4, #24]
20023d64:	f10d 020e 	add.w	r2, sp, #14
20023d68:	4620      	mov	r0, r4
20023d6a:	f10d 010f 	add.w	r1, sp, #15
20023d6e:	f7ff fe35 	bl	200239dc <HAL_MPI_OPSRAM_CAL_DELAY>
20023d72:	4603      	mov	r3, r0
20023d74:	b100      	cbz	r0, 20023d78 <HAL_OPI_PSRAM_Init+0x44>
20023d76:	e7fe      	b.n	20023d76 <HAL_OPI_PSRAM_Init+0x42>
20023d78:	69a2      	ldr	r2, [r4, #24]
20023d7a:	492d      	ldr	r1, [pc, #180]	@ (20023e30 <HAL_OPI_PSRAM_Init+0xfc>)
20023d7c:	428a      	cmp	r2, r1
20023d7e:	d93b      	bls.n	20023df8 <HAL_OPI_PSRAM_Init+0xc4>
20023d80:	4b2c      	ldr	r3, [pc, #176]	@ (20023e34 <HAL_OPI_PSRAM_Init+0x100>)
20023d82:	429a      	cmp	r2, r3
20023d84:	d93c      	bls.n	20023e00 <HAL_OPI_PSRAM_Init+0xcc>
20023d86:	440b      	add	r3, r1
20023d88:	429a      	cmp	r2, r3
20023d8a:	d93f      	bls.n	20023e0c <HAL_OPI_PSRAM_Init+0xd8>
20023d8c:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023d90:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023d94:	429a      	cmp	r2, r3
20023d96:	d93f      	bls.n	20023e18 <HAL_OPI_PSRAM_Init+0xe4>
20023d98:	2107      	movs	r1, #7
20023d9a:	2014      	movs	r0, #20
20023d9c:	2308      	movs	r3, #8
20023d9e:	f240 5232 	movw	r2, #1330	@ 0x532
20023da2:	f884 102d 	strb.w	r1, [r4, #45]	@ 0x2d
20023da6:	f884 102e 	strb.w	r1, [r4, #46]	@ 0x2e
20023daa:	2106      	movs	r1, #6
20023dac:	9000      	str	r0, [sp, #0]
20023dae:	4620      	mov	r0, r4
20023db0:	f7fe fc7c 	bl	200226ac <HAL_FLASH_SET_CS_TIME>
20023db4:	2107      	movs	r1, #7
20023db6:	4620      	mov	r0, r4
20023db8:	f7fe fc8d 	bl	200226d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20023dbc:	2101      	movs	r1, #1
20023dbe:	4620      	mov	r0, r4
20023dc0:	f7fe fcbe 	bl	20022740 <HAL_MPI_ENABLE_DQS>
20023dc4:	f89d 100e 	ldrb.w	r1, [sp, #14]
20023dc8:	4620      	mov	r0, r4
20023dca:	f7fe fcbd 	bl	20022748 <HAL_MPI_SET_DQS_DELAY>
20023dce:	2200      	movs	r2, #0
20023dd0:	f89d 100f 	ldrb.w	r1, [sp, #15]
20023dd4:	4620      	mov	r0, r4
20023dd6:	f7fe fcc2 	bl	2002275e <HAL_MPI_SET_SCK>
20023dda:	2101      	movs	r1, #1
20023ddc:	4620      	mov	r0, r4
20023dde:	f7fe fc20 	bl	20022622 <HAL_FLASH_ENABLE_QSPI>
20023de2:	07eb      	lsls	r3, r5, #31
20023de4:	d405      	bmi.n	20023df2 <HAL_OPI_PSRAM_Init+0xbe>
20023de6:	4b14      	ldr	r3, [pc, #80]	@ (20023e38 <HAL_OPI_PSRAM_Init+0x104>)
20023de8:	681b      	ldr	r3, [r3, #0]
20023dea:	f003 0303 	and.w	r3, r3, #3
20023dee:	2b03      	cmp	r3, #3
20023df0:	d118      	bne.n	20023e24 <HAL_OPI_PSRAM_Init+0xf0>
20023df2:	2000      	movs	r0, #0
20023df4:	b005      	add	sp, #20
20023df6:	bd30      	pop	{r4, r5, pc}
20023df8:	2103      	movs	r1, #3
20023dfa:	22b4      	movs	r2, #180	@ 0xb4
20023dfc:	4608      	mov	r0, r1
20023dfe:	e7d0      	b.n	20023da2 <HAL_OPI_PSRAM_Init+0x6e>
20023e00:	2105      	movs	r1, #5
20023e02:	200e      	movs	r0, #14
20023e04:	2303      	movs	r3, #3
20023e06:	f240 32b6 	movw	r2, #950	@ 0x3b6
20023e0a:	e7ca      	b.n	20023da2 <HAL_OPI_PSRAM_Init+0x6e>
20023e0c:	2106      	movs	r1, #6
20023e0e:	2011      	movs	r0, #17
20023e10:	2305      	movs	r3, #5
20023e12:	f240 4274 	movw	r2, #1140	@ 0x474
20023e16:	e7c4      	b.n	20023da2 <HAL_OPI_PSRAM_Init+0x6e>
20023e18:	2106      	movs	r1, #6
20023e1a:	2013      	movs	r0, #19
20023e1c:	460b      	mov	r3, r1
20023e1e:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20023e22:	e7be      	b.n	20023da2 <HAL_OPI_PSRAM_Init+0x6e>
20023e24:	4620      	mov	r0, r4
20023e26:	f7ff ff42 	bl	20023cae <HAL_PSRAM_RESET>
20023e2a:	e7e2      	b.n	20023df2 <HAL_OPI_PSRAM_Init+0xbe>
20023e2c:	2001      	movs	r0, #1
20023e2e:	e7e1      	b.n	20023df4 <HAL_OPI_PSRAM_Init+0xc0>
20023e30:	016e3600 	.word	0x016e3600
20023e34:	07270e00 	.word	0x07270e00
20023e38:	500c0000 	.word	0x500c0000

20023e3c <HAL_LEGACY_PSRAM_Init>:
20023e3c:	b5f0      	push	{r4, r5, r6, r7, lr}
20023e3e:	4604      	mov	r4, r0
20023e40:	b085      	sub	sp, #20
20023e42:	2800      	cmp	r0, #0
20023e44:	f000 809e 	beq.w	20023f84 <HAL_LEGACY_PSRAM_Init+0x148>
20023e48:	2900      	cmp	r1, #0
20023e4a:	f000 809b 	beq.w	20023f84 <HAL_LEGACY_PSRAM_Init+0x148>
20023e4e:	f7fe faa7 	bl	200223a0 <HAL_QSPI_Init>
20023e52:	6823      	ldr	r3, [r4, #0]
20023e54:	2101      	movs	r1, #1
20023e56:	4620      	mov	r0, r4
20023e58:	681e      	ldr	r6, [r3, #0]
20023e5a:	f7fe fbf0 	bl	2002263e <HAL_FLASH_ENABLE_OPI>
20023e5e:	2101      	movs	r1, #1
20023e60:	4620      	mov	r0, r4
20023e62:	f7fe fb78 	bl	20022556 <HAL_FLASH_SET_CLK_rom>
20023e66:	4620      	mov	r0, r4
20023e68:	f7ff fb8e 	bl	20023588 <HAL_QSPI_GET_CLK>
20023e6c:	0845      	lsrs	r5, r0, #1
20023e6e:	61a5      	str	r5, [r4, #24]
20023e70:	4620      	mov	r0, r4
20023e72:	f10d 020e 	add.w	r2, sp, #14
20023e76:	f10d 010f 	add.w	r1, sp, #15
20023e7a:	f7ff fdaf 	bl	200239dc <HAL_MPI_OPSRAM_CAL_DELAY>
20023e7e:	4603      	mov	r3, r0
20023e80:	b100      	cbz	r0, 20023e84 <HAL_LEGACY_PSRAM_Init+0x48>
20023e82:	e7fe      	b.n	20023e82 <HAL_LEGACY_PSRAM_Init+0x46>
20023e84:	4a40      	ldr	r2, [pc, #256]	@ (20023f88 <HAL_LEGACY_PSRAM_Init+0x14c>)
20023e86:	4f41      	ldr	r7, [pc, #260]	@ (20023f8c <HAL_LEGACY_PSRAM_Init+0x150>)
20023e88:	4295      	cmp	r5, r2
20023e8a:	d95a      	bls.n	20023f42 <HAL_LEGACY_PSRAM_Init+0x106>
20023e8c:	42bd      	cmp	r5, r7
20023e8e:	d95b      	bls.n	20023f48 <HAL_LEGACY_PSRAM_Init+0x10c>
20023e90:	4b3f      	ldr	r3, [pc, #252]	@ (20023f90 <HAL_LEGACY_PSRAM_Init+0x154>)
20023e92:	429d      	cmp	r5, r3
20023e94:	d95d      	bls.n	20023f52 <HAL_LEGACY_PSRAM_Init+0x116>
20023e96:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023e9a:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023e9e:	429d      	cmp	r5, r3
20023ea0:	d95c      	bls.n	20023f5c <HAL_LEGACY_PSRAM_Init+0x120>
20023ea2:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023ea6:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023eaa:	429d      	cmp	r5, r3
20023eac:	d85b      	bhi.n	20023f66 <HAL_LEGACY_PSRAM_Init+0x12a>
20023eae:	2114      	movs	r1, #20
20023eb0:	2308      	movs	r3, #8
20023eb2:	f240 5232 	movw	r2, #1330	@ 0x532
20023eb6:	9100      	str	r1, [sp, #0]
20023eb8:	4620      	mov	r0, r4
20023eba:	2106      	movs	r1, #6
20023ebc:	f7fe fbf6 	bl	200226ac <HAL_FLASH_SET_CS_TIME>
20023ec0:	2107      	movs	r1, #7
20023ec2:	4620      	mov	r0, r4
20023ec4:	f7fe fc07 	bl	200226d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20023ec8:	2101      	movs	r1, #1
20023eca:	4620      	mov	r0, r4
20023ecc:	f7fe fc38 	bl	20022740 <HAL_MPI_ENABLE_DQS>
20023ed0:	f89d 100e 	ldrb.w	r1, [sp, #14]
20023ed4:	4620      	mov	r0, r4
20023ed6:	f7fe fc37 	bl	20022748 <HAL_MPI_SET_DQS_DELAY>
20023eda:	2200      	movs	r2, #0
20023edc:	f89d 100f 	ldrb.w	r1, [sp, #15]
20023ee0:	4620      	mov	r0, r4
20023ee2:	f7fe fc3c 	bl	2002275e <HAL_MPI_SET_SCK>
20023ee6:	2101      	movs	r1, #1
20023ee8:	4620      	mov	r0, r4
20023eea:	f7fe fbfe 	bl	200226ea <HAL_FLASH_SET_LEGACY>
20023eee:	2101      	movs	r1, #1
20023ef0:	4620      	mov	r0, r4
20023ef2:	f7fe fb96 	bl	20022622 <HAL_FLASH_ENABLE_QSPI>
20023ef6:	07f3      	lsls	r3, r6, #31
20023ef8:	d405      	bmi.n	20023f06 <HAL_LEGACY_PSRAM_Init+0xca>
20023efa:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
20023efe:	b913      	cbnz	r3, 20023f06 <HAL_LEGACY_PSRAM_Init+0xca>
20023f00:	4620      	mov	r0, r4
20023f02:	f7ff fed4 	bl	20023cae <HAL_PSRAM_RESET>
20023f06:	42bd      	cmp	r5, r7
20023f08:	d932      	bls.n	20023f70 <HAL_LEGACY_PSRAM_Init+0x134>
20023f0a:	4b22      	ldr	r3, [pc, #136]	@ (20023f94 <HAL_LEGACY_PSRAM_Init+0x158>)
20023f0c:	429d      	cmp	r5, r3
20023f0e:	d934      	bls.n	20023f7a <HAL_LEGACY_PSRAM_Init+0x13e>
20023f10:	2206      	movs	r2, #6
20023f12:	2302      	movs	r3, #2
20023f14:	2588      	movs	r5, #136	@ 0x88
20023f16:	263b      	movs	r6, #59	@ 0x3b
20023f18:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023f1c:	2101      	movs	r1, #1
20023f1e:	f884 202d 	strb.w	r2, [r4, #45]	@ 0x2d
20023f22:	4620      	mov	r0, r4
20023f24:	f7fe fc0a 	bl	2002273c <HAL_MPI_EN_FIXLAT>
20023f28:	4632      	mov	r2, r6
20023f2a:	2100      	movs	r1, #0
20023f2c:	4620      	mov	r0, r4
20023f2e:	f7ff fe65 	bl	20023bfc <HAL_LEGACY_MR_WRITE>
20023f32:	462a      	mov	r2, r5
20023f34:	2104      	movs	r1, #4
20023f36:	4620      	mov	r0, r4
20023f38:	f7ff fe60 	bl	20023bfc <HAL_LEGACY_MR_WRITE>
20023f3c:	2000      	movs	r0, #0
20023f3e:	b005      	add	sp, #20
20023f40:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023f42:	2103      	movs	r1, #3
20023f44:	22b4      	movs	r2, #180	@ 0xb4
20023f46:	e7b6      	b.n	20023eb6 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f48:	210e      	movs	r1, #14
20023f4a:	2303      	movs	r3, #3
20023f4c:	f240 32b6 	movw	r2, #950	@ 0x3b6
20023f50:	e7b1      	b.n	20023eb6 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f52:	2111      	movs	r1, #17
20023f54:	2305      	movs	r3, #5
20023f56:	f240 4274 	movw	r2, #1140	@ 0x474
20023f5a:	e7ac      	b.n	20023eb6 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f5c:	2113      	movs	r1, #19
20023f5e:	2306      	movs	r3, #6
20023f60:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20023f64:	e7a7      	b.n	20023eb6 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f66:	2117      	movs	r1, #23
20023f68:	2309      	movs	r3, #9
20023f6a:	f44f 62be 	mov.w	r2, #1520	@ 0x5f0
20023f6e:	e7a2      	b.n	20023eb6 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f70:	2204      	movs	r2, #4
20023f72:	2300      	movs	r3, #0
20023f74:	2508      	movs	r5, #8
20023f76:	2633      	movs	r6, #51	@ 0x33
20023f78:	e7ce      	b.n	20023f18 <HAL_LEGACY_PSRAM_Init+0xdc>
20023f7a:	2205      	movs	r2, #5
20023f7c:	2300      	movs	r3, #0
20023f7e:	2508      	movs	r5, #8
20023f80:	2637      	movs	r6, #55	@ 0x37
20023f82:	e7c9      	b.n	20023f18 <HAL_LEGACY_PSRAM_Init+0xdc>
20023f84:	2001      	movs	r0, #1
20023f86:	e7da      	b.n	20023f3e <HAL_LEGACY_PSRAM_Init+0x102>
20023f88:	016e3600 	.word	0x016e3600
20023f8c:	07270e00 	.word	0x07270e00
20023f90:	08954400 	.word	0x08954400
20023f94:	094c5f00 	.word	0x094c5f00

20023f98 <HAL_HYPER_PSRAM_WriteCR>:
20023f98:	b570      	push	{r4, r5, r6, lr}
20023f9a:	460e      	mov	r6, r1
20023f9c:	4615      	mov	r5, r2
20023f9e:	4604      	mov	r4, r0
20023fa0:	b086      	sub	sp, #24
20023fa2:	b1f8      	cbz	r0, 20023fe4 <HAL_HYPER_PSRAM_WriteCR+0x4c>
20023fa4:	2207      	movs	r2, #7
20023fa6:	2303      	movs	r3, #3
20023fa8:	e9cd 2301 	strd	r2, r3, [sp, #4]
20023fac:	2300      	movs	r3, #0
20023fae:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023fb2:	9300      	str	r3, [sp, #0]
20023fb4:	2101      	movs	r1, #1
20023fb6:	f7fe fad7 	bl	20022568 <HAL_FLASH_MANUAL_CMD>
20023fba:	4631      	mov	r1, r6
20023fbc:	4620      	mov	r0, r4
20023fbe:	f7fe fa7d 	bl	200224bc <HAL_FLASH_WRITE_ABYTE>
20023fc2:	2102      	movs	r1, #2
20023fc4:	4620      	mov	r0, r4
20023fc6:	f7fe fa65 	bl	20022494 <HAL_FLASH_WRITE_DLEN>
20023fca:	4629      	mov	r1, r5
20023fcc:	4620      	mov	r0, r4
20023fce:	f7fe fa5a 	bl	20022486 <HAL_FLASH_WRITE_WORD>
20023fd2:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20023fd6:	2160      	movs	r1, #96	@ 0x60
20023fd8:	4620      	mov	r0, r4
20023fda:	b006      	add	sp, #24
20023fdc:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20023fe0:	f7fe ba7d 	b.w	200224de <HAL_FLASH_SET_CMD>
20023fe4:	b006      	add	sp, #24
20023fe6:	bd70      	pop	{r4, r5, r6, pc}

20023fe8 <HAL_HYPER_PSRAM_Init>:
20023fe8:	b538      	push	{r3, r4, r5, lr}
20023fea:	4605      	mov	r5, r0
20023fec:	2201      	movs	r2, #1
20023fee:	f7ff fea1 	bl	20023d34 <HAL_OPI_PSRAM_Init>
20023ff2:	69ac      	ldr	r4, [r5, #24]
20023ff4:	4b12      	ldr	r3, [pc, #72]	@ (20024040 <HAL_HYPER_PSRAM_Init+0x58>)
20023ff6:	429c      	cmp	r4, r3
20023ff8:	d91c      	bls.n	20024034 <HAL_HYPER_PSRAM_Init+0x4c>
20023ffa:	4b12      	ldr	r3, [pc, #72]	@ (20024044 <HAL_HYPER_PSRAM_Init+0x5c>)
20023ffc:	429c      	cmp	r4, r3
20023ffe:	d91b      	bls.n	20024038 <HAL_HYPER_PSRAM_Init+0x50>
20024000:	4b11      	ldr	r3, [pc, #68]	@ (20024048 <HAL_HYPER_PSRAM_Init+0x60>)
20024002:	429c      	cmp	r4, r3
20024004:	d91a      	bls.n	2002403c <HAL_HYPER_PSRAM_Init+0x54>
20024006:	4b11      	ldr	r3, [pc, #68]	@ (2002404c <HAL_HYPER_PSRAM_Init+0x64>)
20024008:	429c      	cmp	r4, r3
2002400a:	bf8c      	ite	hi
2002400c:	2402      	movhi	r4, #2
2002400e:	2401      	movls	r4, #1
20024010:	2101      	movs	r1, #1
20024012:	4628      	mov	r0, r5
20024014:	f7fe fb21 	bl	2002265a <HAL_FLASH_ENABLE_HYPER>
20024018:	f240 428f 	movw	r2, #1167	@ 0x48f
2002401c:	4628      	mov	r0, r5
2002401e:	ea42 3204 	orr.w	r2, r2, r4, lsl #12
20024022:	2100      	movs	r1, #0
20024024:	f7ff ffb8 	bl	20023f98 <HAL_HYPER_PSRAM_WriteCR>
20024028:	2101      	movs	r1, #1
2002402a:	4628      	mov	r0, r5
2002402c:	f7fe fb86 	bl	2002273c <HAL_MPI_EN_FIXLAT>
20024030:	2000      	movs	r0, #0
20024032:	bd38      	pop	{r3, r4, r5, pc}
20024034:	240e      	movs	r4, #14
20024036:	e7eb      	b.n	20024010 <HAL_HYPER_PSRAM_Init+0x28>
20024038:	240f      	movs	r4, #15
2002403a:	e7e9      	b.n	20024010 <HAL_HYPER_PSRAM_Init+0x28>
2002403c:	2400      	movs	r4, #0
2002403e:	e7e7      	b.n	20024010 <HAL_HYPER_PSRAM_Init+0x28>
20024040:	0510ff40 	.word	0x0510ff40
20024044:	0632ea00 	.word	0x0632ea00
20024048:	07ed6b40 	.word	0x07ed6b40
2002404c:	09e4f580 	.word	0x09e4f580

20024050 <HAL_HYPER_CFG_READ>:
20024050:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20024052:	b160      	cbz	r0, 2002406e <HAL_HYPER_CFG_READ+0x1e>
20024054:	2107      	movs	r1, #7
20024056:	2303      	movs	r3, #3
20024058:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
2002405c:	e9cd 1300 	strd	r1, r3, [sp]
20024060:	3a01      	subs	r2, #1
20024062:	2300      	movs	r3, #0
20024064:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024068:	b252      	sxtb	r2, r2
2002406a:	f7fe f9c6 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
2002406e:	b005      	add	sp, #20
20024070:	f85d fb04 	ldr.w	pc, [sp], #4

20024074 <HAL_HYPER_CFG_WRITE>:
20024074:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20024076:	b160      	cbz	r0, 20024092 <HAL_HYPER_CFG_WRITE+0x1e>
20024078:	2107      	movs	r1, #7
2002407a:	2303      	movs	r3, #3
2002407c:	f890 202e 	ldrb.w	r2, [r0, #46]	@ 0x2e
20024080:	e9cd 1300 	strd	r1, r3, [sp]
20024084:	3a01      	subs	r2, #1
20024086:	2300      	movs	r3, #0
20024088:	e9cd 1102 	strd	r1, r1, [sp, #8]
2002408c:	b252      	sxtb	r2, r2
2002408e:	f7fe f9dd 	bl	2002244c <HAL_FLASH_CFG_AHB_WCMD>
20024092:	b005      	add	sp, #20
20024094:	f85d fb04 	ldr.w	pc, [sp], #4

20024098 <HAL_MPI_PSRAM_Init>:
20024098:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
2002409c:	690b      	ldr	r3, [r1, #16]
2002409e:	4604      	mov	r4, r0
200240a0:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
200240a4:	690b      	ldr	r3, [r1, #16]
200240a6:	3b03      	subs	r3, #3
200240a8:	2b03      	cmp	r3, #3
200240aa:	f200 8085 	bhi.w	200241b8 <HAL_MPI_PSRAM_Init+0x120>
200240ae:	e8df f003 	tbb	[pc, r3]
200240b2:	6302      	.short	0x6302
200240b4:	7958      	.short	0x7958
200240b6:	4620      	mov	r0, r4
200240b8:	f7ff fe3c 	bl	20023d34 <HAL_OPI_PSRAM_Init>
200240bc:	2203      	movs	r2, #3
200240be:	4606      	mov	r6, r0
200240c0:	2108      	movs	r1, #8
200240c2:	4620      	mov	r0, r4
200240c4:	f7ff fd28 	bl	20023b18 <HAL_MPI_MR_WRITE>
200240c8:	4620      	mov	r0, r4
200240ca:	f7ff fa5d 	bl	20023588 <HAL_QSPI_GET_CLK>
200240ce:	4b4d      	ldr	r3, [pc, #308]	@ (20024204 <HAL_MPI_PSRAM_Init+0x16c>)
200240d0:	4298      	cmp	r0, r3
200240d2:	d95f      	bls.n	20024194 <HAL_MPI_PSRAM_Init+0xfc>
200240d4:	f103 63a4 	add.w	r3, r3, #85983232	@ 0x5200000
200240d8:	f503 4383 	add.w	r3, r3, #16768	@ 0x4180
200240dc:	4298      	cmp	r0, r3
200240de:	d95b      	bls.n	20024198 <HAL_MPI_PSRAM_Init+0x100>
200240e0:	f103 7337 	add.w	r3, r3, #47972352	@ 0x2dc0000
200240e4:	f503 43d8 	add.w	r3, r3, #27648	@ 0x6c00
200240e8:	4298      	cmp	r0, r3
200240ea:	d957      	bls.n	2002419c <HAL_MPI_PSRAM_Init+0x104>
200240ec:	4b46      	ldr	r3, [pc, #280]	@ (20024208 <HAL_MPI_PSRAM_Init+0x170>)
200240ee:	4298      	cmp	r0, r3
200240f0:	d956      	bls.n	200241a0 <HAL_MPI_PSRAM_Init+0x108>
200240f2:	4b46      	ldr	r3, [pc, #280]	@ (2002420c <HAL_MPI_PSRAM_Init+0x174>)
200240f4:	4298      	cmp	r0, r3
200240f6:	bf94      	ite	ls
200240f8:	2507      	movls	r5, #7
200240fa:	2500      	movhi	r5, #0
200240fc:	f04f 0800 	mov.w	r8, #0
20024100:	2707      	movs	r7, #7
20024102:	f04f 0a03 	mov.w	sl, #3
20024106:	ea4f 0945 	mov.w	r9, r5, lsl #1
2002410a:	4643      	mov	r3, r8
2002410c:	f109 32ff 	add.w	r2, r9, #4294967295
20024110:	4639      	mov	r1, r7
20024112:	4620      	mov	r0, r4
20024114:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024118:	e9cd 8a00 	strd	r8, sl, [sp]
2002411c:	f7fe f96d 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
20024120:	4641      	mov	r1, r8
20024122:	4620      	mov	r0, r4
20024124:	f7fe f95e 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
20024128:	4643      	mov	r3, r8
2002412a:	1e6a      	subs	r2, r5, #1
2002412c:	4639      	mov	r1, r7
2002412e:	4620      	mov	r0, r4
20024130:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024134:	e9cd 8a00 	strd	r8, sl, [sp]
20024138:	f7fe f988 	bl	2002244c <HAL_FLASH_CFG_AHB_WCMD>
2002413c:	2180      	movs	r1, #128	@ 0x80
2002413e:	4620      	mov	r0, r4
20024140:	f7fe f978 	bl	20022434 <HAL_FLASH_SET_AHB_WCMD>
20024144:	462b      	mov	r3, r5
20024146:	464a      	mov	r2, r9
20024148:	2101      	movs	r1, #1
2002414a:	4620      	mov	r0, r4
2002414c:	f7ff fd08 	bl	20023b60 <HAL_MPI_SET_FIXLAT>
20024150:	f64f 71ff 	movw	r1, #65535	@ 0xffff
20024154:	4620      	mov	r0, r4
20024156:	f7fe fb2d 	bl	200227b4 <HAL_FLASH_SET_WDT>
2002415a:	4630      	mov	r0, r6
2002415c:	b004      	add	sp, #16
2002415e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20024162:	4620      	mov	r0, r4
20024164:	f7ff fe6a 	bl	20023e3c <HAL_LEGACY_PSRAM_Init>
20024168:	4620      	mov	r0, r4
2002416a:	f7ff fd6c 	bl	20023c46 <HAL_LEGACY_CFG_READ>
2002416e:	4620      	mov	r0, r4
20024170:	f7ff fd84 	bl	20023c7c <HAL_LEGACY_CFG_WRITE>
20024174:	2600      	movs	r6, #0
20024176:	e7eb      	b.n	20024150 <HAL_MPI_PSRAM_Init+0xb8>
20024178:	4620      	mov	r0, r4
2002417a:	f7ff fddb 	bl	20023d34 <HAL_OPI_PSRAM_Init>
2002417e:	2243      	movs	r2, #67	@ 0x43
20024180:	4606      	mov	r6, r0
20024182:	2108      	movs	r1, #8
20024184:	4620      	mov	r0, r4
20024186:	f7ff fcc7 	bl	20023b18 <HAL_MPI_MR_WRITE>
2002418a:	2101      	movs	r1, #1
2002418c:	4620      	mov	r0, r4
2002418e:	f7fe fac7 	bl	20022720 <HAL_FLASH_SET_X16_MODE>
20024192:	e799      	b.n	200240c8 <HAL_MPI_PSRAM_Init+0x30>
20024194:	2503      	movs	r5, #3
20024196:	e7b1      	b.n	200240fc <HAL_MPI_PSRAM_Init+0x64>
20024198:	2504      	movs	r5, #4
2002419a:	e7af      	b.n	200240fc <HAL_MPI_PSRAM_Init+0x64>
2002419c:	2505      	movs	r5, #5
2002419e:	e7ad      	b.n	200240fc <HAL_MPI_PSRAM_Init+0x64>
200241a0:	2506      	movs	r5, #6
200241a2:	e7ab      	b.n	200240fc <HAL_MPI_PSRAM_Init+0x64>
200241a4:	4620      	mov	r0, r4
200241a6:	f7ff ff1f 	bl	20023fe8 <HAL_HYPER_PSRAM_Init>
200241aa:	4620      	mov	r0, r4
200241ac:	f7ff ff50 	bl	20024050 <HAL_HYPER_CFG_READ>
200241b0:	4620      	mov	r0, r4
200241b2:	f7ff ff5f 	bl	20024074 <HAL_HYPER_CFG_WRITE>
200241b6:	e7dd      	b.n	20024174 <HAL_MPI_PSRAM_Init+0xdc>
200241b8:	2600      	movs	r6, #0
200241ba:	2503      	movs	r5, #3
200241bc:	f04f 0801 	mov.w	r8, #1
200241c0:	2702      	movs	r7, #2
200241c2:	4620      	mov	r0, r4
200241c4:	f7ff fc52 	bl	20023a6c <HAL_SPI_PSRAM_Init>
200241c8:	4633      	mov	r3, r6
200241ca:	2206      	movs	r2, #6
200241cc:	4629      	mov	r1, r5
200241ce:	4620      	mov	r0, r4
200241d0:	e9cd 6700 	strd	r6, r7, [sp]
200241d4:	e9cd 5802 	strd	r5, r8, [sp, #8]
200241d8:	f7fe f90f 	bl	200223fa <HAL_FLASH_CFG_AHB_RCMD>
200241dc:	21eb      	movs	r1, #235	@ 0xeb
200241de:	4620      	mov	r0, r4
200241e0:	f7fe f900 	bl	200223e4 <HAL_FLASH_SET_AHB_RCMD>
200241e4:	4633      	mov	r3, r6
200241e6:	4632      	mov	r2, r6
200241e8:	4629      	mov	r1, r5
200241ea:	4620      	mov	r0, r4
200241ec:	e9cd 6700 	strd	r6, r7, [sp]
200241f0:	e9cd 5802 	strd	r5, r8, [sp, #8]
200241f4:	f7fe f92a 	bl	2002244c <HAL_FLASH_CFG_AHB_WCMD>
200241f8:	2138      	movs	r1, #56	@ 0x38
200241fa:	4620      	mov	r0, r4
200241fc:	f7fe f91a 	bl	20022434 <HAL_FLASH_SET_AHB_WCMD>
20024200:	4606      	mov	r6, r0
20024202:	e7a5      	b.n	20024150 <HAL_MPI_PSRAM_Init+0xb8>
20024204:	07de2901 	.word	0x07de2901
20024208:	13c9eb01 	.word	0x13c9eb01
2002420c:	17d78401 	.word	0x17d78401

20024210 <HAL_PIN_Set2>:
20024210:	0a03      	lsrs	r3, r0, #8
20024212:	1e5a      	subs	r2, r3, #1
20024214:	2a53      	cmp	r2, #83	@ 0x53
20024216:	b2c0      	uxtb	r0, r0
20024218:	d80e      	bhi.n	20024238 <HAL_PIN_Set2+0x28>
2002421a:	4a09      	ldr	r2, [pc, #36]	@ (20024240 <HAL_PIN_Set2+0x30>)
2002421c:	009b      	lsls	r3, r3, #2
2002421e:	441a      	add	r2, r3
20024220:	6813      	ldr	r3, [r2, #0]
20024222:	f401 7140 	and.w	r1, r1, #768	@ 0x300
20024226:	f36f 0309 	bfc	r3, #0, #10
2002422a:	430b      	orrs	r3, r1
2002422c:	4303      	orrs	r3, r0
2002422e:	f443 6380 	orr.w	r3, r3, #1024	@ 0x400
20024232:	2000      	movs	r0, #0
20024234:	6013      	str	r3, [r2, #0]
20024236:	4770      	bx	lr
20024238:	f04f 30ff 	mov.w	r0, #4294967295
2002423c:	4770      	bx	lr
2002423e:	bf00      	nop
20024240:	50002ffc 	.word	0x50002ffc

20024244 <HAL_PIN_Set>:
20024244:	3801      	subs	r0, #1
20024246:	2853      	cmp	r0, #83	@ 0x53
20024248:	b570      	push	{r4, r5, r6, lr}
2002424a:	f04f 0400 	mov.w	r4, #0
2002424e:	d824      	bhi.n	2002429a <HAL_PIN_Set+0x56>
20024250:	0083      	lsls	r3, r0, #2
20024252:	f1a1 0510 	sub.w	r5, r1, #16
20024256:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
2002425a:	2dee      	cmp	r5, #238	@ 0xee
2002425c:	f503 5340 	add.w	r3, r3, #12288	@ 0x3000
20024260:	d80c      	bhi.n	2002427c <HAL_PIN_Set+0x38>
20024262:	b2cc      	uxtb	r4, r1
20024264:	2000      	movs	r0, #0
20024266:	6819      	ldr	r1, [r3, #0]
20024268:	f402 7240 	and.w	r2, r2, #768	@ 0x300
2002426c:	4322      	orrs	r2, r4
2002426e:	f36f 0109 	bfc	r1, #0, #10
20024272:	430a      	orrs	r2, r1
20024274:	f442 6280 	orr.w	r2, r2, #1024	@ 0x400
20024278:	601a      	str	r2, [r3, #0]
2002427a:	bd70      	pop	{r4, r5, r6, pc}
2002427c:	4d08      	ldr	r5, [pc, #32]	@ (200242a0 <HAL_PIN_Set+0x5c>)
2002427e:	f855 0020 	ldr.w	r0, [r5, r0, lsl #2]
20024282:	f100 0640 	add.w	r6, r0, #64	@ 0x40
20024286:	8845      	ldrh	r5, [r0, #2]
20024288:	b13d      	cbz	r5, 2002429a <HAL_PIN_Set+0x56>
2002428a:	428d      	cmp	r5, r1
2002428c:	d101      	bne.n	20024292 <HAL_PIN_Set+0x4e>
2002428e:	7804      	ldrb	r4, [r0, #0]
20024290:	e7e8      	b.n	20024264 <HAL_PIN_Set+0x20>
20024292:	3004      	adds	r0, #4
20024294:	42b0      	cmp	r0, r6
20024296:	d1f6      	bne.n	20024286 <HAL_PIN_Set+0x42>
20024298:	e7e4      	b.n	20024264 <HAL_PIN_Set+0x20>
2002429a:	f04f 30ff 	mov.w	r0, #4294967295
2002429e:	e7ec      	b.n	2002427a <HAL_PIN_Set+0x36>
200242a0:	20026a08 	.word	0x20026a08

200242a4 <HAL_PIN_Set_DS0>:
200242a4:	2854      	cmp	r0, #84	@ 0x54
200242a6:	dc0e      	bgt.n	200242c6 <HAL_PIN_Set_DS0+0x22>
200242a8:	b168      	cbz	r0, 200242c6 <HAL_PIN_Set_DS0+0x22>
200242aa:	4b08      	ldr	r3, [pc, #32]	@ (200242cc <HAL_PIN_Set_DS0+0x28>)
200242ac:	0080      	lsls	r0, r0, #2
200242ae:	4403      	add	r3, r0
200242b0:	b12a      	cbz	r2, 200242be <HAL_PIN_Set_DS0+0x1a>
200242b2:	681a      	ldr	r2, [r3, #0]
200242b4:	f442 5200 	orr.w	r2, r2, #8192	@ 0x2000
200242b8:	2000      	movs	r0, #0
200242ba:	601a      	str	r2, [r3, #0]
200242bc:	4770      	bx	lr
200242be:	681a      	ldr	r2, [r3, #0]
200242c0:	f422 5200 	bic.w	r2, r2, #8192	@ 0x2000
200242c4:	e7f8      	b.n	200242b8 <HAL_PIN_Set_DS0+0x14>
200242c6:	f04f 30ff 	mov.w	r0, #4294967295
200242ca:	4770      	bx	lr
200242cc:	50002ffc 	.word	0x50002ffc

200242d0 <HAL_PIN_Set_DS1>:
200242d0:	2854      	cmp	r0, #84	@ 0x54
200242d2:	dc0e      	bgt.n	200242f2 <HAL_PIN_Set_DS1+0x22>
200242d4:	b168      	cbz	r0, 200242f2 <HAL_PIN_Set_DS1+0x22>
200242d6:	4b08      	ldr	r3, [pc, #32]	@ (200242f8 <HAL_PIN_Set_DS1+0x28>)
200242d8:	0080      	lsls	r0, r0, #2
200242da:	4403      	add	r3, r0
200242dc:	b12a      	cbz	r2, 200242ea <HAL_PIN_Set_DS1+0x1a>
200242de:	681a      	ldr	r2, [r3, #0]
200242e0:	f442 4280 	orr.w	r2, r2, #16384	@ 0x4000
200242e4:	2000      	movs	r0, #0
200242e6:	601a      	str	r2, [r3, #0]
200242e8:	4770      	bx	lr
200242ea:	681a      	ldr	r2, [r3, #0]
200242ec:	f422 4280 	bic.w	r2, r2, #16384	@ 0x4000
200242f0:	e7f8      	b.n	200242e4 <HAL_PIN_Set_DS1+0x14>
200242f2:	f04f 30ff 	mov.w	r0, #4294967295
200242f6:	4770      	bx	lr
200242f8:	50002ffc 	.word	0x50002ffc

200242fc <HAL_PMU_EnableDLL>:
200242fc:	4b05      	ldr	r3, [pc, #20]	@ (20024314 <HAL_PMU_EnableDLL+0x18>)
200242fe:	6eda      	ldr	r2, [r3, #108]	@ 0x6c
20024300:	b120      	cbz	r0, 2002430c <HAL_PMU_EnableDLL+0x10>
20024302:	f042 0220 	orr.w	r2, r2, #32
20024306:	2000      	movs	r0, #0
20024308:	66da      	str	r2, [r3, #108]	@ 0x6c
2002430a:	4770      	bx	lr
2002430c:	f022 0220 	bic.w	r2, r2, #32
20024310:	e7f9      	b.n	20024306 <HAL_PMU_EnableDLL+0xa>
20024312:	bf00      	nop
20024314:	500ca000 	.word	0x500ca000

20024318 <HAL_RCC_HCPU_ConfigSxModeVolt>:
20024318:	b507      	push	{r0, r1, r2, lr}
2002431a:	4a13      	ldr	r2, [pc, #76]	@ (20024368 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
2002431c:	4913      	ldr	r1, [pc, #76]	@ (2002436c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
2002431e:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
20024322:	f8d1 3098 	ldr.w	r3, [r1, #152]	@ 0x98
20024326:	7892      	ldrb	r2, [r2, #2]
20024328:	2802      	cmp	r0, #2
2002432a:	f362 0304 	bfi	r3, r2, #0, #5
2002432e:	f8c1 3098 	str.w	r3, [r1, #152]	@ 0x98
20024332:	f10d 0007 	add.w	r0, sp, #7
20024336:	d111      	bne.n	2002435c <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
20024338:	f003 fa9e 	bl	20027878 <HAL_PMU_GetHpsysVoutRef>
2002433c:	b110      	cbz	r0, 20024344 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
2002433e:	230b      	movs	r3, #11
20024340:	f88d 3007 	strb.w	r3, [sp, #7]
20024344:	4a09      	ldr	r2, [pc, #36]	@ (2002436c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20024346:	f89d 1007 	ldrb.w	r1, [sp, #7]
2002434a:	f8d2 3090 	ldr.w	r3, [r2, #144]	@ 0x90
2002434e:	f361 0303 	bfi	r3, r1, #0, #4
20024352:	f8c2 3090 	str.w	r3, [r2, #144]	@ 0x90
20024356:	b003      	add	sp, #12
20024358:	f85d fb04 	ldr.w	pc, [sp], #4
2002435c:	f003 fa98 	bl	20027890 <HAL_PMU_GetHpsysVoutRef2>
20024360:	2800      	cmp	r0, #0
20024362:	d0ef      	beq.n	20024344 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20024364:	230e      	movs	r3, #14
20024366:	e7eb      	b.n	20024340 <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
20024368:	2002702c 	.word	0x2002702c
2002436c:	500ca000 	.word	0x500ca000

20024370 <HAL_RCC_HCPU_GetClockSrc>:
20024370:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024374:	2810      	cmp	r0, #16
20024376:	6a1a      	ldr	r2, [r3, #32]
20024378:	d80c      	bhi.n	20024394 <HAL_RCC_HCPU_GetClockSrc+0x24>
2002437a:	4b07      	ldr	r3, [pc, #28]	@ (20024398 <HAL_RCC_HCPU_GetClockSrc+0x28>)
2002437c:	40c3      	lsrs	r3, r0
2002437e:	f013 0f01 	tst.w	r3, #1
20024382:	bf0c      	ite	eq
20024384:	2301      	moveq	r3, #1
20024386:	2303      	movne	r3, #3
20024388:	4083      	lsls	r3, r0
2002438a:	4013      	ands	r3, r2
2002438c:	fa23 f000 	lsr.w	r0, r3, r0
20024390:	b2c0      	uxtb	r0, r0
20024392:	4770      	bx	lr
20024394:	2301      	movs	r3, #1
20024396:	e7f7      	b.n	20024388 <HAL_RCC_HCPU_GetClockSrc+0x18>
20024398:	00012ff1 	.word	0x00012ff1

2002439c <HAL_RCC_HCPU_GetDLLFreq>:
2002439c:	2801      	cmp	r0, #1
2002439e:	d003      	beq.n	200243a8 <HAL_RCC_HCPU_GetDLLFreq+0xc>
200243a0:	2802      	cmp	r0, #2
200243a2:	d00e      	beq.n	200243c2 <HAL_RCC_HCPU_GetDLLFreq+0x26>
200243a4:	2000      	movs	r0, #0
200243a6:	4770      	bx	lr
200243a8:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200243ac:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
200243ae:	b163      	cbz	r3, 200243ca <HAL_RCC_HCPU_GetDLLFreq+0x2e>
200243b0:	f013 0001 	ands.w	r0, r3, #1
200243b4:	d00a      	beq.n	200243cc <HAL_RCC_HCPU_GetDLLFreq+0x30>
200243b6:	4806      	ldr	r0, [pc, #24]	@ (200243d0 <HAL_RCC_HCPU_GetDLLFreq+0x34>)
200243b8:	f3c3 0383 	ubfx	r3, r3, #2, #4
200243bc:	fb03 0000 	mla	r0, r3, r0, r0
200243c0:	4770      	bx	lr
200243c2:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200243c6:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
200243c8:	e7f1      	b.n	200243ae <HAL_RCC_HCPU_GetDLLFreq+0x12>
200243ca:	4618      	mov	r0, r3
200243cc:	4770      	bx	lr
200243ce:	bf00      	nop
200243d0:	016e3600 	.word	0x016e3600

200243d4 <HAL_RCC_HCPU_GetDLL1Freq>:
200243d4:	2001      	movs	r0, #1
200243d6:	f7ff bfe1 	b.w	2002439c <HAL_RCC_HCPU_GetDLLFreq>
	...

200243dc <HAL_RCC_GetSysCLKFreq.part.0>:
200243dc:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200243e0:	6a1b      	ldr	r3, [r3, #32]
200243e2:	f003 0303 	and.w	r3, r3, #3
200243e6:	2b03      	cmp	r3, #3
200243e8:	d101      	bne.n	200243ee <HAL_RCC_GetSysCLKFreq.part.0+0x12>
200243ea:	f7ff bff3 	b.w	200243d4 <HAL_RCC_HCPU_GetDLL1Freq>
200243ee:	4801      	ldr	r0, [pc, #4]	@ (200243f4 <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
200243f0:	4770      	bx	lr
200243f2:	bf00      	nop
200243f4:	02dc6c00 	.word	0x02dc6c00

200243f8 <HAL_RCC_HCPU_GetDLL2Freq>:
200243f8:	2002      	movs	r0, #2
200243fa:	f7ff bfcf 	b.w	2002439c <HAL_RCC_HCPU_GetDLLFreq>

200243fe <HAL_RCC_HCPU_GetDLL3Freq>:
200243fe:	2000      	movs	r0, #0
20024400:	4770      	bx	lr
	...

20024404 <HAL_RCC_HCPU_EnableDLL>:
20024404:	4b1a      	ldr	r3, [pc, #104]	@ (20024470 <HAL_RCC_HCPU_EnableDLL+0x6c>)
20024406:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
2002440a:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
2002440e:	4299      	cmp	r1, r3
20024410:	b510      	push	{r4, lr}
20024412:	d82a      	bhi.n	2002446a <HAL_RCC_HCPU_EnableDLL+0x66>
20024414:	2801      	cmp	r0, #1
20024416:	d002      	beq.n	2002441e <HAL_RCC_HCPU_EnableDLL+0x1a>
20024418:	2802      	cmp	r0, #2
2002441a:	d024      	beq.n	20024466 <HAL_RCC_HCPU_EnableDLL+0x62>
2002441c:	e7fe      	b.n	2002441c <HAL_RCC_HCPU_EnableDLL+0x18>
2002441e:	4c15      	ldr	r4, [pc, #84]	@ (20024474 <HAL_RCC_HCPU_EnableDLL+0x70>)
20024420:	4a15      	ldr	r2, [pc, #84]	@ (20024478 <HAL_RCC_HCPU_EnableDLL+0x74>)
20024422:	2000      	movs	r0, #0
20024424:	6c53      	ldr	r3, [r2, #68]	@ 0x44
20024426:	f043 0301 	orr.w	r3, r3, #1
2002442a:	6453      	str	r3, [r2, #68]	@ 0x44
2002442c:	4a13      	ldr	r2, [pc, #76]	@ (2002447c <HAL_RCC_HCPU_EnableDLL+0x78>)
2002442e:	6823      	ldr	r3, [r4, #0]
20024430:	fbb1 f1f2 	udiv	r1, r1, r2
20024434:	f023 0301 	bic.w	r3, r3, #1
20024438:	6023      	str	r3, [r4, #0]
2002443a:	6823      	ldr	r3, [r4, #0]
2002443c:	f423 4380 	bic.w	r3, r3, #16384	@ 0x4000
20024440:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
20024444:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
20024448:	f443 5300 	orr.w	r3, r3, #8192	@ 0x2000
2002444c:	f043 0301 	orr.w	r3, r3, #1
20024450:	6023      	str	r3, [r4, #0]
20024452:	f7fd fa88 	bl	20021966 <HAL_Delay_us>
20024456:	200a      	movs	r0, #10
20024458:	f7fd fa85 	bl	20021966 <HAL_Delay_us>
2002445c:	6823      	ldr	r3, [r4, #0]
2002445e:	2b00      	cmp	r3, #0
20024460:	dafc      	bge.n	2002445c <HAL_RCC_HCPU_EnableDLL+0x58>
20024462:	2000      	movs	r0, #0
20024464:	bd10      	pop	{r4, pc}
20024466:	4c06      	ldr	r4, [pc, #24]	@ (20024480 <HAL_RCC_HCPU_EnableDLL+0x7c>)
20024468:	e7da      	b.n	20024420 <HAL_RCC_HCPU_EnableDLL+0x1c>
2002446a:	2001      	movs	r0, #1
2002446c:	e7fa      	b.n	20024464 <HAL_RCC_HCPU_EnableDLL+0x60>
2002446e:	bf00      	nop
20024470:	15752a00 	.word	0x15752a00
20024474:	5000002c 	.word	0x5000002c
20024478:	5000b000 	.word	0x5000b000
2002447c:	016e3600 	.word	0x016e3600
20024480:	50000030 	.word	0x50000030

20024484 <HAL_RCC_HCPU_EnableDLL1>:
20024484:	4601      	mov	r1, r0
20024486:	2001      	movs	r0, #1
20024488:	f7ff bfbc 	b.w	20024404 <HAL_RCC_HCPU_EnableDLL>

2002448c <HAL_RCC_HCPU_EnableDLL2>:
2002448c:	4601      	mov	r1, r0
2002448e:	2002      	movs	r0, #2
20024490:	f7ff bfb8 	b.w	20024404 <HAL_RCC_HCPU_EnableDLL>

20024494 <HAL_RCC_HCPU_DisableDLL1>:
20024494:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024498:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
2002449a:	2000      	movs	r0, #0
2002449c:	f023 0301 	bic.w	r3, r3, #1
200244a0:	62d3      	str	r3, [r2, #44]	@ 0x2c
200244a2:	4770      	bx	lr

200244a4 <HAL_RCC_GetSysCLKFreq>:
200244a4:	2801      	cmp	r0, #1
200244a6:	d101      	bne.n	200244ac <HAL_RCC_GetSysCLKFreq+0x8>
200244a8:	f7ff bf98 	b.w	200243dc <HAL_RCC_GetSysCLKFreq.part.0>
200244ac:	4800      	ldr	r0, [pc, #0]	@ (200244b0 <HAL_RCC_GetSysCLKFreq+0xc>)
200244ae:	4770      	bx	lr
200244b0:	02dc6c00 	.word	0x02dc6c00

200244b4 <HAL_RCC_GetHCLKFreq>:
200244b4:	1e02      	subs	r2, r0, #0
200244b6:	bf08      	it	eq
200244b8:	2201      	moveq	r2, #1
200244ba:	b508      	push	{r3, lr}
200244bc:	4610      	mov	r0, r2
200244be:	f7ff fff1 	bl	200244a4 <HAL_RCC_GetSysCLKFreq>
200244c2:	2a01      	cmp	r2, #1
200244c4:	d002      	beq.n	200244cc <HAL_RCC_GetHCLKFreq+0x18>
200244c6:	2a02      	cmp	r2, #2
200244c8:	d00a      	beq.n	200244e0 <HAL_RCC_GetHCLKFreq+0x2c>
200244ca:	e7fe      	b.n	200244ca <HAL_RCC_GetHCLKFreq+0x16>
200244cc:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200244d0:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
200244d2:	b2db      	uxtb	r3, r3
200244d4:	2b01      	cmp	r3, #1
200244d6:	bfb8      	it	lt
200244d8:	2301      	movlt	r3, #1
200244da:	fbb0 f0f3 	udiv	r0, r0, r3
200244de:	bd08      	pop	{r3, pc}
200244e0:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
200244e4:	695b      	ldr	r3, [r3, #20]
200244e6:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
200244ea:	e7f3      	b.n	200244d4 <HAL_RCC_GetHCLKFreq+0x20>

200244ec <HAL_RCC_HCPU_ClockSelect>:
200244ec:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200244f0:	b510      	push	{r4, lr}
200244f2:	2810      	cmp	r0, #16
200244f4:	6a1b      	ldr	r3, [r3, #32]
200244f6:	d817      	bhi.n	20024528 <HAL_RCC_HCPU_ClockSelect+0x3c>
200244f8:	4a0c      	ldr	r2, [pc, #48]	@ (2002452c <HAL_RCC_HCPU_ClockSelect+0x40>)
200244fa:	40c2      	lsrs	r2, r0
200244fc:	f012 0f01 	tst.w	r2, #1
20024500:	bf0c      	ite	eq
20024502:	2201      	moveq	r2, #1
20024504:	2203      	movne	r2, #3
20024506:	fa02 f400 	lsl.w	r4, r2, r0
2002450a:	4011      	ands	r1, r2
2002450c:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024510:	ea23 0304 	bic.w	r3, r3, r4
20024514:	4081      	lsls	r1, r0
20024516:	430b      	orrs	r3, r1
20024518:	6213      	str	r3, [r2, #32]
2002451a:	b920      	cbnz	r0, 20024526 <HAL_RCC_HCPU_ClockSelect+0x3a>
2002451c:	2001      	movs	r0, #1
2002451e:	f7ff ffc9 	bl	200244b4 <HAL_RCC_GetHCLKFreq>
20024522:	4b03      	ldr	r3, [pc, #12]	@ (20024530 <HAL_RCC_HCPU_ClockSelect+0x44>)
20024524:	6018      	str	r0, [r3, #0]
20024526:	bd10      	pop	{r4, pc}
20024528:	2201      	movs	r2, #1
2002452a:	e7ec      	b.n	20024506 <HAL_RCC_HCPU_ClockSelect+0x1a>
2002452c:	00012ff1 	.word	0x00012ff1
20024530:	20042c14 	.word	0x20042c14

20024534 <HAL_RCC_HCPU_SetDiv>:
20024534:	2800      	cmp	r0, #0
20024536:	bfd8      	it	le
20024538:	2000      	movle	r0, #0
2002453a:	b508      	push	{r3, lr}
2002453c:	bfcc      	ite	gt
2002453e:	23ff      	movgt	r3, #255	@ 0xff
20024540:	4603      	movle	r3, r0
20024542:	2900      	cmp	r1, #0
20024544:	db12      	blt.n	2002456c <HAL_RCC_HCPU_SetDiv+0x38>
20024546:	2a00      	cmp	r2, #0
20024548:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
2002454c:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
20024550:	da0e      	bge.n	20024570 <HAL_RCC_HCPU_SetDiv+0x3c>
20024552:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
20024556:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
20024558:	ea22 0303 	bic.w	r3, r2, r3
2002455c:	4303      	orrs	r3, r0
2002455e:	624b      	str	r3, [r1, #36]	@ 0x24
20024560:	2001      	movs	r0, #1
20024562:	f7ff ffa7 	bl	200244b4 <HAL_RCC_GetHCLKFreq>
20024566:	4b07      	ldr	r3, [pc, #28]	@ (20024584 <HAL_RCC_HCPU_SetDiv+0x50>)
20024568:	6018      	str	r0, [r3, #0]
2002456a:	bd08      	pop	{r3, pc}
2002456c:	2a00      	cmp	r2, #0
2002456e:	db04      	blt.n	2002457a <HAL_RCC_HCPU_SetDiv+0x46>
20024570:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
20024574:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
20024578:	e7eb      	b.n	20024552 <HAL_RCC_HCPU_SetDiv+0x1e>
2002457a:	2b00      	cmp	r3, #0
2002457c:	d0f0      	beq.n	20024560 <HAL_RCC_HCPU_SetDiv+0x2c>
2002457e:	23ff      	movs	r3, #255	@ 0xff
20024580:	e7e7      	b.n	20024552 <HAL_RCC_HCPU_SetDiv+0x1e>
20024582:	bf00      	nop
20024584:	20042c14 	.word	0x20042c14

20024588 <HAL_RCC_HCPU_SwitchDvfsD2S>:
20024588:	b570      	push	{r4, r5, r6, lr}
2002458a:	460c      	mov	r4, r1
2002458c:	4d19      	ldr	r5, [pc, #100]	@ (200245f4 <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
2002458e:	4606      	mov	r6, r0
20024590:	f7ff fec2 	bl	20024318 <HAL_RCC_HCPU_ConfigSxModeVolt>
20024594:	692b      	ldr	r3, [r5, #16]
20024596:	20fa      	movs	r0, #250	@ 0xfa
20024598:	f023 0301 	bic.w	r3, r3, #1
2002459c:	612b      	str	r3, [r5, #16]
2002459e:	f7fd f9e2 	bl	20021966 <HAL_Delay_us>
200245a2:	2c30      	cmp	r4, #48	@ 0x30
200245a4:	d80d      	bhi.n	200245c2 <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
200245a6:	2100      	movs	r1, #0
200245a8:	4608      	mov	r0, r1
200245aa:	f7ff ff9f 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
200245ae:	2030      	movs	r0, #48	@ 0x30
200245b0:	2204      	movs	r2, #4
200245b2:	2100      	movs	r1, #0
200245b4:	fbb0 f0f4 	udiv	r0, r0, r4
200245b8:	f7ff ffbc 	bl	20024534 <HAL_RCC_HCPU_SetDiv>
200245bc:	2400      	movs	r4, #0
200245be:	4620      	mov	r0, r4
200245c0:	bd70      	pop	{r4, r5, r6, pc}
200245c2:	f7fd fed9 	bl	20022378 <HAL_HPAON_EnableXT48>
200245c6:	480c      	ldr	r0, [pc, #48]	@ (200245f8 <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
200245c8:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
200245cc:	6843      	ldr	r3, [r0, #4]
200245ce:	480b      	ldr	r0, [pc, #44]	@ (200245fc <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
200245d0:	61eb      	str	r3, [r5, #28]
200245d2:	4360      	muls	r0, r4
200245d4:	f7ff ff56 	bl	20024484 <HAL_RCC_HCPU_EnableDLL1>
200245d8:	4604      	mov	r4, r0
200245da:	2800      	cmp	r0, #0
200245dc:	d1ef      	bne.n	200245be <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
200245de:	2101      	movs	r1, #1
200245e0:	2206      	movs	r2, #6
200245e2:	4608      	mov	r0, r1
200245e4:	f7ff ffa6 	bl	20024534 <HAL_RCC_HCPU_SetDiv>
200245e8:	2103      	movs	r1, #3
200245ea:	4620      	mov	r0, r4
200245ec:	f7ff ff7e 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
200245f0:	e7e4      	b.n	200245bc <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
200245f2:	bf00      	nop
200245f4:	5000b000 	.word	0x5000b000
200245f8:	2002702c 	.word	0x2002702c
200245fc:	000f4240 	.word	0x000f4240

20024600 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
20024600:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20024604:	4c1d      	ldr	r4, [pc, #116]	@ (2002467c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
20024606:	4f1e      	ldr	r7, [pc, #120]	@ (20024680 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
20024608:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
2002460c:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
2002460e:	7892      	ldrb	r2, [r2, #2]
20024610:	4605      	mov	r5, r0
20024612:	f362 4396 	bfi	r3, r2, #18, #5
20024616:	ea4f 08c0 	mov.w	r8, r0, lsl #3
2002461a:	633b      	str	r3, [r7, #48]	@ 0x30
2002461c:	f10d 0007 	add.w	r0, sp, #7
20024620:	460e      	mov	r6, r1
20024622:	f003 f929 	bl	20027878 <HAL_PMU_GetHpsysVoutRef>
20024626:	b110      	cbz	r0, 2002462e <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
20024628:	230b      	movs	r3, #11
2002462a:	f88d 3007 	strb.w	r3, [sp, #7]
2002462e:	f89d 1007 	ldrb.w	r1, [sp, #7]
20024632:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
20024636:	6d3b      	ldr	r3, [r7, #80]	@ 0x50
20024638:	440a      	add	r2, r1
2002463a:	2100      	movs	r1, #0
2002463c:	f362 0385 	bfi	r3, r2, #2, #4
20024640:	4608      	mov	r0, r1
20024642:	653b      	str	r3, [r7, #80]	@ 0x50
20024644:	f7ff ff52 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
20024648:	2e30      	cmp	r6, #48	@ 0x30
2002464a:	d900      	bls.n	2002464e <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
2002464c:	e7fe      	b.n	2002464c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
2002464e:	2030      	movs	r0, #48	@ 0x30
20024650:	2204      	movs	r2, #4
20024652:	2100      	movs	r1, #0
20024654:	fbb0 f0f6 	udiv	r0, r0, r6
20024658:	f7ff ff6c 	bl	20024534 <HAL_RCC_HCPU_SetDiv>
2002465c:	f7ff ff1a 	bl	20024494 <HAL_RCC_HCPU_DisableDLL1>
20024660:	f7fd fe96 	bl	20022390 <HAL_HPAON_DisableXT48>
20024664:	4444      	add	r4, r8
20024666:	4b07      	ldr	r3, [pc, #28]	@ (20024684 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
20024668:	6862      	ldr	r2, [r4, #4]
2002466a:	61da      	str	r2, [r3, #28]
2002466c:	691a      	ldr	r2, [r3, #16]
2002466e:	f042 0201 	orr.w	r2, r2, #1
20024672:	611a      	str	r2, [r3, #16]
20024674:	b002      	add	sp, #8
20024676:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002467a:	bf00      	nop
2002467c:	2002702c 	.word	0x2002702c
20024680:	500ca000 	.word	0x500ca000
20024684:	5000b000 	.word	0x5000b000

20024688 <HAL_RCC_HCPU_ConfigDvfs>:
20024688:	b570      	push	{r4, r5, r6, lr}
2002468a:	4e31      	ldr	r6, [pc, #196]	@ (20024750 <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
2002468c:	4605      	mov	r5, r0
2002468e:	7833      	ldrb	r3, [r6, #0]
20024690:	460c      	mov	r4, r1
20024692:	2b01      	cmp	r3, #1
20024694:	d943      	bls.n	2002471e <HAL_RCC_HCPU_ConfigDvfs+0x96>
20024696:	3b02      	subs	r3, #2
20024698:	2b01      	cmp	r3, #1
2002469a:	d902      	bls.n	200246a2 <HAL_RCC_HCPU_ConfigDvfs+0x1a>
2002469c:	2501      	movs	r5, #1
2002469e:	4628      	mov	r0, r5
200246a0:	bd70      	pop	{r4, r5, r6, pc}
200246a2:	4b2c      	ldr	r3, [pc, #176]	@ (20024754 <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
200246a4:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
200246a8:	f7ff fea6 	bl	200243f8 <HAL_RCC_HCPU_GetDLL2Freq>
200246ac:	4290      	cmp	r0, r2
200246ae:	d8f5      	bhi.n	2002469c <HAL_RCC_HCPU_ConfigDvfs+0x14>
200246b0:	2901      	cmp	r1, #1
200246b2:	d805      	bhi.n	200246c0 <HAL_RCC_HCPU_ConfigDvfs+0x38>
200246b4:	4629      	mov	r1, r5
200246b6:	4620      	mov	r0, r4
200246b8:	f7ff ffa2 	bl	20024600 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
200246bc:	2500      	movs	r5, #0
200246be:	e035      	b.n	2002472c <HAL_RCC_HCPU_ConfigDvfs+0xa4>
200246c0:	2100      	movs	r1, #0
200246c2:	4608      	mov	r0, r1
200246c4:	f7ff ff12 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
200246c8:	4620      	mov	r0, r4
200246ca:	f7ff fe25 	bl	20024318 <HAL_RCC_HCPU_ConfigSxModeVolt>
200246ce:	20fa      	movs	r0, #250	@ 0xfa
200246d0:	f7fd f949 	bl	20021966 <HAL_Delay_us>
200246d4:	f7ff fede 	bl	20024494 <HAL_RCC_HCPU_DisableDLL1>
200246d8:	2d30      	cmp	r5, #48	@ 0x30
200246da:	d80d      	bhi.n	200246f8 <HAL_RCC_HCPU_ConfigDvfs+0x70>
200246dc:	f7fd fe58 	bl	20022390 <HAL_HPAON_DisableXT48>
200246e0:	2100      	movs	r1, #0
200246e2:	4608      	mov	r0, r1
200246e4:	f7ff ff02 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
200246e8:	2204      	movs	r2, #4
200246ea:	2100      	movs	r1, #0
200246ec:	2030      	movs	r0, #48	@ 0x30
200246ee:	fbb0 f0f5 	udiv	r0, r0, r5
200246f2:	f7ff ff1f 	bl	20024534 <HAL_RCC_HCPU_SetDiv>
200246f6:	e7e1      	b.n	200246bc <HAL_RCC_HCPU_ConfigDvfs+0x34>
200246f8:	f7fd fe3e 	bl	20022378 <HAL_HPAON_EnableXT48>
200246fc:	4816      	ldr	r0, [pc, #88]	@ (20024758 <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
200246fe:	4368      	muls	r0, r5
20024700:	f7ff fec0 	bl	20024484 <HAL_RCC_HCPU_EnableDLL1>
20024704:	4605      	mov	r5, r0
20024706:	2800      	cmp	r0, #0
20024708:	d1c8      	bne.n	2002469c <HAL_RCC_HCPU_ConfigDvfs+0x14>
2002470a:	2101      	movs	r1, #1
2002470c:	2206      	movs	r2, #6
2002470e:	4608      	mov	r0, r1
20024710:	f7ff ff10 	bl	20024534 <HAL_RCC_HCPU_SetDiv>
20024714:	2103      	movs	r1, #3
20024716:	4628      	mov	r0, r5
20024718:	f7ff fee8 	bl	200244ec <HAL_RCC_HCPU_ClockSelect>
2002471c:	e7ce      	b.n	200246bc <HAL_RCC_HCPU_ConfigDvfs+0x34>
2002471e:	2901      	cmp	r1, #1
20024720:	d909      	bls.n	20024736 <HAL_RCC_HCPU_ConfigDvfs+0xae>
20024722:	4601      	mov	r1, r0
20024724:	4620      	mov	r0, r4
20024726:	f7ff ff2f 	bl	20024588 <HAL_RCC_HCPU_SwitchDvfsD2S>
2002472a:	4605      	mov	r5, r0
2002472c:	2000      	movs	r0, #0
2002472e:	7034      	strb	r4, [r6, #0]
20024730:	f7fd f919 	bl	20021966 <HAL_Delay_us>
20024734:	e7b3      	b.n	2002469e <HAL_RCC_HCPU_ConfigDvfs+0x16>
20024736:	428b      	cmp	r3, r1
20024738:	d103      	bne.n	20024742 <HAL_RCC_HCPU_ConfigDvfs+0xba>
2002473a:	f04f 32ff 	mov.w	r2, #4294967295
2002473e:	4611      	mov	r1, r2
20024740:	e7d4      	b.n	200246ec <HAL_RCC_HCPU_ConfigDvfs+0x64>
20024742:	2190      	movs	r1, #144	@ 0x90
20024744:	2002      	movs	r0, #2
20024746:	f7ff ff1f 	bl	20024588 <HAL_RCC_HCPU_SwitchDvfsD2S>
2002474a:	2800      	cmp	r0, #0
2002474c:	d1a6      	bne.n	2002469c <HAL_RCC_HCPU_ConfigDvfs+0x14>
2002474e:	e7b1      	b.n	200246b4 <HAL_RCC_HCPU_ConfigDvfs+0x2c>
20024750:	20042c18 	.word	0x20042c18
20024754:	2002701c 	.word	0x2002701c
20024758:	000f4240 	.word	0x000f4240

2002475c <HAL_RCC_EnableModule>:
2002475c:	1c43      	adds	r3, r0, #1
2002475e:	d014      	beq.n	2002478a <HAL_RCC_EnableModule+0x2e>
20024760:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
20024764:	b282      	uxth	r2, r0
20024766:	d000      	beq.n	2002476a <HAL_RCC_EnableModule+0xe>
20024768:	e7fe      	b.n	20024768 <HAL_RCC_EnableModule+0xc>
2002476a:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
2002476e:	f3c0 2181 	ubfx	r1, r0, #10, #2
20024772:	f3c0 2301 	ubfx	r3, r0, #8, #2
20024776:	b2d2      	uxtb	r2, r2
20024778:	d108      	bne.n	2002478c <HAL_RCC_EnableModule+0x30>
2002477a:	009b      	lsls	r3, r3, #2
2002477c:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20024780:	3310      	adds	r3, #16
20024782:	2101      	movs	r1, #1
20024784:	fa01 f202 	lsl.w	r2, r1, r2
20024788:	601a      	str	r2, [r3, #0]
2002478a:	4770      	bx	lr
2002478c:	2901      	cmp	r1, #1
2002478e:	d104      	bne.n	2002479a <HAL_RCC_EnableModule+0x3e>
20024790:	009b      	lsls	r3, r3, #2
20024792:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
20024796:	3308      	adds	r3, #8
20024798:	e7f3      	b.n	20024782 <HAL_RCC_EnableModule+0x26>
2002479a:	2902      	cmp	r1, #2
2002479c:	d108      	bne.n	200247b0 <HAL_RCC_EnableModule+0x54>
2002479e:	2301      	movs	r3, #1
200247a0:	4904      	ldr	r1, [pc, #16]	@ (200247b4 <HAL_RCC_EnableModule+0x58>)
200247a2:	4093      	lsls	r3, r2
200247a4:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
200247a8:	4303      	orrs	r3, r0
200247aa:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
200247ae:	4770      	bx	lr
200247b0:	e7fe      	b.n	200247b0 <HAL_RCC_EnableModule+0x54>
200247b2:	bf00      	nop
200247b4:	50002000 	.word	0x50002000

200247b8 <HAL_RCC_HCPU_ConfigHCLK>:
200247b8:	28f0      	cmp	r0, #240	@ 0xf0
200247ba:	d80d      	bhi.n	200247d8 <HAL_RCC_HCPU_ConfigHCLK+0x20>
200247bc:	2890      	cmp	r0, #144	@ 0x90
200247be:	d807      	bhi.n	200247d0 <HAL_RCC_HCPU_ConfigHCLK+0x18>
200247c0:	2830      	cmp	r0, #48	@ 0x30
200247c2:	d807      	bhi.n	200247d4 <HAL_RCC_HCPU_ConfigHCLK+0x1c>
200247c4:	2818      	cmp	r0, #24
200247c6:	bf94      	ite	ls
200247c8:	2100      	movls	r1, #0
200247ca:	2101      	movhi	r1, #1
200247cc:	f7ff bf5c 	b.w	20024688 <HAL_RCC_HCPU_ConfigDvfs>
200247d0:	2103      	movs	r1, #3
200247d2:	e7fb      	b.n	200247cc <HAL_RCC_HCPU_ConfigHCLK+0x14>
200247d4:	2102      	movs	r1, #2
200247d6:	e7f9      	b.n	200247cc <HAL_RCC_HCPU_ConfigHCLK+0x14>
200247d8:	2001      	movs	r0, #1
200247da:	4770      	bx	lr

200247dc <spi_nor_get_ext_cfg_by_id>:
200247dc:	2000      	movs	r0, #0
200247de:	4770      	bx	lr

200247e0 <spi_nor_get_user_flash_cfg>:
200247e0:	2000      	movs	r0, #0
200247e2:	4770      	bx	lr

200247e4 <spi_flash_get_rdid>:
200247e4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200247e6:	4604      	mov	r4, r0
200247e8:	3801      	subs	r0, #1
200247ea:	b2c0      	uxtb	r0, r0
200247ec:	28fd      	cmp	r0, #253	@ 0xfd
200247ee:	d816      	bhi.n	2002481e <spi_flash_get_rdid+0x3a>
200247f0:	2500      	movs	r5, #0
200247f2:	4e0d      	ldr	r6, [pc, #52]	@ (20024828 <spi_flash_get_rdid+0x44>)
200247f4:	f856 0b04 	ldr.w	r0, [r6], #4
200247f8:	7807      	ldrb	r7, [r0, #0]
200247fa:	b937      	cbnz	r7, 2002480a <spi_flash_get_rdid+0x26>
200247fc:	3501      	adds	r5, #1
200247fe:	2d06      	cmp	r5, #6
20024800:	d1f8      	bne.n	200247f4 <spi_flash_get_rdid+0x10>
20024802:	4620      	mov	r0, r4
20024804:	f7ff ffec 	bl	200247e0 <spi_nor_get_user_flash_cfg>
20024808:	e00d      	b.n	20024826 <spi_flash_get_rdid+0x42>
2002480a:	42a7      	cmp	r7, r4
2002480c:	d105      	bne.n	2002481a <spi_flash_get_rdid+0x36>
2002480e:	7847      	ldrb	r7, [r0, #1]
20024810:	4297      	cmp	r7, r2
20024812:	d102      	bne.n	2002481a <spi_flash_get_rdid+0x36>
20024814:	7887      	ldrb	r7, [r0, #2]
20024816:	428f      	cmp	r7, r1
20024818:	d003      	beq.n	20024822 <spi_flash_get_rdid+0x3e>
2002481a:	3008      	adds	r0, #8
2002481c:	e7ec      	b.n	200247f8 <spi_flash_get_rdid+0x14>
2002481e:	2000      	movs	r0, #0
20024820:	e001      	b.n	20024826 <spi_flash_get_rdid+0x42>
20024822:	b103      	cbz	r3, 20024826 <spi_flash_get_rdid+0x42>
20024824:	701d      	strb	r5, [r3, #0]
20024826:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024828:	20042c1c 	.word	0x20042c1c

2002482c <spi_flash_get_cmd_by_id>:
2002482c:	b507      	push	{r0, r1, r2, lr}
2002482e:	f10d 0307 	add.w	r3, sp, #7
20024832:	f7ff ffd7 	bl	200247e4 <spi_flash_get_rdid>
20024836:	4b06      	ldr	r3, [pc, #24]	@ (20024850 <spi_flash_get_cmd_by_id+0x24>)
20024838:	b140      	cbz	r0, 2002484c <spi_flash_get_cmd_by_id+0x20>
2002483a:	f44f 7105 	mov.w	r1, #532	@ 0x214
2002483e:	f89d 2007 	ldrb.w	r2, [sp, #7]
20024842:	fb01 3002 	mla	r0, r1, r2, r3
20024846:	b003      	add	sp, #12
20024848:	f85d fb04 	ldr.w	pc, [sp], #4
2002484c:	4618      	mov	r0, r3
2002484e:	e7fa      	b.n	20024846 <spi_flash_get_cmd_by_id+0x1a>
20024850:	20042e64 	.word	0x20042e64

20024854 <spi_flash_get_size_by_id>:
20024854:	b508      	push	{r3, lr}
20024856:	2300      	movs	r3, #0
20024858:	f7ff ffc4 	bl	200247e4 <spi_flash_get_rdid>
2002485c:	b108      	cbz	r0, 20024862 <spi_flash_get_size_by_id+0xe>
2002485e:	6840      	ldr	r0, [r0, #4]
20024860:	bd08      	pop	{r3, pc}
20024862:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
20024866:	e7fb      	b.n	20024860 <spi_flash_get_size_by_id+0xc>

20024868 <spi_flash_is_support_dtr>:
20024868:	b508      	push	{r3, lr}
2002486a:	2300      	movs	r3, #0
2002486c:	f7ff ffba 	bl	200247e4 <spi_flash_get_rdid>
20024870:	b110      	cbz	r0, 20024878 <spi_flash_is_support_dtr+0x10>
20024872:	78c0      	ldrb	r0, [r0, #3]
20024874:	f000 0001 	and.w	r0, r0, #1
20024878:	bd08      	pop	{r3, pc}
	...

2002487c <spi_flash_get_otp_base>:
2002487c:	b508      	push	{r3, lr}
2002487e:	2300      	movs	r3, #0
20024880:	f7ff ffb0 	bl	200247e4 <spi_flash_get_rdid>
20024884:	b130      	cbz	r0, 20024894 <spi_flash_get_otp_base+0x18>
20024886:	78c3      	ldrb	r3, [r0, #3]
20024888:	4803      	ldr	r0, [pc, #12]	@ (20024898 <spi_flash_get_otp_base+0x1c>)
2002488a:	f003 0306 	and.w	r3, r3, #6
2002488e:	2b02      	cmp	r3, #2
20024890:	bf18      	it	ne
20024892:	2000      	movne	r0, #0
20024894:	bd08      	pop	{r3, pc}
20024896:	bf00      	nop
20024898:	00ffc000 	.word	0x00ffc000

2002489c <spi_nand_get_user_flash_cfg>:
2002489c:	2000      	movs	r0, #0
2002489e:	4770      	bx	lr

200248a0 <spi_nand_get_rdid>:
200248a0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200248a2:	4604      	mov	r4, r0
200248a4:	3801      	subs	r0, #1
200248a6:	b2c0      	uxtb	r0, r0
200248a8:	28fd      	cmp	r0, #253	@ 0xfd
200248aa:	d816      	bhi.n	200248da <spi_nand_get_rdid+0x3a>
200248ac:	2500      	movs	r5, #0
200248ae:	4e0d      	ldr	r6, [pc, #52]	@ (200248e4 <spi_nand_get_rdid+0x44>)
200248b0:	f856 0b04 	ldr.w	r0, [r6], #4
200248b4:	7807      	ldrb	r7, [r0, #0]
200248b6:	b937      	cbnz	r7, 200248c6 <spi_nand_get_rdid+0x26>
200248b8:	3501      	adds	r5, #1
200248ba:	2d06      	cmp	r5, #6
200248bc:	d1f8      	bne.n	200248b0 <spi_nand_get_rdid+0x10>
200248be:	4620      	mov	r0, r4
200248c0:	f7ff ffec 	bl	2002489c <spi_nand_get_user_flash_cfg>
200248c4:	e00d      	b.n	200248e2 <spi_nand_get_rdid+0x42>
200248c6:	42a7      	cmp	r7, r4
200248c8:	d105      	bne.n	200248d6 <spi_nand_get_rdid+0x36>
200248ca:	7847      	ldrb	r7, [r0, #1]
200248cc:	4297      	cmp	r7, r2
200248ce:	d102      	bne.n	200248d6 <spi_nand_get_rdid+0x36>
200248d0:	7887      	ldrb	r7, [r0, #2]
200248d2:	428f      	cmp	r7, r1
200248d4:	d003      	beq.n	200248de <spi_nand_get_rdid+0x3e>
200248d6:	3008      	adds	r0, #8
200248d8:	e7ec      	b.n	200248b4 <spi_nand_get_rdid+0x14>
200248da:	2000      	movs	r0, #0
200248dc:	e001      	b.n	200248e2 <spi_nand_get_rdid+0x42>
200248de:	b103      	cbz	r3, 200248e2 <spi_nand_get_rdid+0x42>
200248e0:	701d      	strb	r5, [r3, #0]
200248e2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200248e4:	20043adc 	.word	0x20043adc

200248e8 <spi_nand_get_cmd_by_id>:
200248e8:	b507      	push	{r0, r1, r2, lr}
200248ea:	f10d 0307 	add.w	r3, sp, #7
200248ee:	f7ff ffd7 	bl	200248a0 <spi_nand_get_rdid>
200248f2:	b130      	cbz	r0, 20024902 <spi_nand_get_cmd_by_id+0x1a>
200248f4:	f44f 7205 	mov.w	r2, #532	@ 0x214
200248f8:	f89d 3007 	ldrb.w	r3, [sp, #7]
200248fc:	4802      	ldr	r0, [pc, #8]	@ (20024908 <spi_nand_get_cmd_by_id+0x20>)
200248fe:	fb02 0003 	mla	r0, r2, r3, r0
20024902:	b003      	add	sp, #12
20024904:	f85d fb04 	ldr.w	pc, [sp], #4
20024908:	20043d24 	.word	0x20043d24

2002490c <spi_nand_get_ext_cfg_by_id>:
2002490c:	2000      	movs	r0, #0
2002490e:	4770      	bx	lr

20024910 <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
20024910:	f04f 30ff 	mov.w	r0, #4294967295
20024914:	4770      	bx	lr
	...

20024918 <spi_nand_get_default_ctable>:
20024918:	b508      	push	{r3, lr}
2002491a:	f7ff fff9 	bl	20024910 <HAL_GET_NAND_FLASH_DEFAUT_IDX>
2002491e:	1e03      	subs	r3, r0, #0
20024920:	bfa5      	ittet	ge
20024922:	f44f 7205 	movge.w	r2, #532	@ 0x214
20024926:	4802      	ldrge	r0, [pc, #8]	@ (20024930 <spi_nand_get_default_ctable+0x18>)
20024928:	2000      	movlt	r0, #0
2002492a:	fb02 0003 	mlage	r0, r2, r3, r0
2002492e:	bd08      	pop	{r3, pc}
20024930:	20043d24 	.word	0x20043d24

20024934 <spi_nand_get_size_by_id>:
20024934:	b508      	push	{r3, lr}
20024936:	2300      	movs	r3, #0
20024938:	f7ff ffb2 	bl	200248a0 <spi_nand_get_rdid>
2002493c:	b108      	cbz	r0, 20024942 <spi_nand_get_size_by_id+0xe>
2002493e:	6840      	ldr	r0, [r0, #4]
20024940:	bd08      	pop	{r3, pc}
20024942:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20024946:	e7fb      	b.n	20024940 <spi_nand_get_size_by_id+0xc>

20024948 <spi_nand_get_plane_select_flag>:
20024948:	b508      	push	{r3, lr}
2002494a:	2300      	movs	r3, #0
2002494c:	f7ff ffa8 	bl	200248a0 <spi_nand_get_rdid>
20024950:	b110      	cbz	r0, 20024958 <spi_nand_get_plane_select_flag+0x10>
20024952:	78c0      	ldrb	r0, [r0, #3]
20024954:	f3c0 0040 	ubfx	r0, r0, #1, #1
20024958:	bd08      	pop	{r3, pc}

2002495a <spi_nand_get_big_page_flag>:
2002495a:	b508      	push	{r3, lr}
2002495c:	2300      	movs	r3, #0
2002495e:	f7ff ff9f 	bl	200248a0 <spi_nand_get_rdid>
20024962:	b110      	cbz	r0, 2002496a <spi_nand_get_big_page_flag+0x10>
20024964:	78c0      	ldrb	r0, [r0, #3]
20024966:	f3c0 0081 	ubfx	r0, r0, #2, #2
2002496a:	bd08      	pop	{r3, pc}

2002496c <spi_nand_get_ecc_mode>:
2002496c:	b508      	push	{r3, lr}
2002496e:	2300      	movs	r3, #0
20024970:	f7ff ff96 	bl	200248a0 <spi_nand_get_rdid>
20024974:	b108      	cbz	r0, 2002497a <spi_nand_get_ecc_mode+0xe>
20024976:	78c0      	ldrb	r0, [r0, #3]
20024978:	0900      	lsrs	r0, r0, #4
2002497a:	bd08      	pop	{r3, pc}

2002497c <bbm_map_check.part.0>:
2002497c:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
2002497e:	4b21      	ldr	r3, [pc, #132]	@ (20024a04 <bbm_map_check.part.0+0x88>)
20024980:	4606      	mov	r6, r0
20024982:	681d      	ldr	r5, [r3, #0]
20024984:	4b20      	ldr	r3, [pc, #128]	@ (20024a08 <bbm_map_check.part.0+0x8c>)
20024986:	3d04      	subs	r5, #4
20024988:	681f      	ldr	r7, [r3, #0]
2002498a:	2300      	movs	r3, #0
2002498c:	f100 0e1a 	add.w	lr, r0, #26
20024990:	42ab      	cmp	r3, r5
20024992:	db02      	blt.n	2002499a <bbm_map_check.part.0+0x1e>
20024994:	2000      	movs	r0, #0
20024996:	b003      	add	sp, #12
20024998:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002499a:	8b31      	ldrh	r1, [r6, #24]
2002499c:	b321      	cbz	r1, 200249e8 <bbm_map_check.part.0+0x6c>
2002499e:	8b72      	ldrh	r2, [r6, #26]
200249a0:	b33a      	cbz	r2, 200249f2 <bbm_map_check.part.0+0x76>
200249a2:	42b9      	cmp	r1, r7
200249a4:	d201      	bcs.n	200249aa <bbm_map_check.part.0+0x2e>
200249a6:	4297      	cmp	r7, r2
200249a8:	d905      	bls.n	200249b6 <bbm_map_check.part.0+0x3a>
200249aa:	4b18      	ldr	r3, [pc, #96]	@ (20024a0c <bbm_map_check.part.0+0x90>)
200249ac:	681b      	ldr	r3, [r3, #0]
200249ae:	b10b      	cbz	r3, 200249b4 <bbm_map_check.part.0+0x38>
200249b0:	4817      	ldr	r0, [pc, #92]	@ (20024a10 <bbm_map_check.part.0+0x94>)
200249b2:	4798      	blx	r3
200249b4:	e7fe      	b.n	200249b4 <bbm_map_check.part.0+0x38>
200249b6:	3301      	adds	r3, #1
200249b8:	461c      	mov	r4, r3
200249ba:	42ac      	cmp	r4, r5
200249bc:	db01      	blt.n	200249c2 <bbm_map_check.part.0+0x46>
200249be:	3604      	adds	r6, #4
200249c0:	e7e6      	b.n	20024990 <bbm_map_check.part.0+0x14>
200249c2:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
200249c6:	f1bc 0f00 	cmp.w	ip, #0
200249ca:	d0f8      	beq.n	200249be <bbm_map_check.part.0+0x42>
200249cc:	4562      	cmp	r2, ip
200249ce:	d109      	bne.n	200249e4 <bbm_map_check.part.0+0x68>
200249d0:	4b0e      	ldr	r3, [pc, #56]	@ (20024a0c <bbm_map_check.part.0+0x90>)
200249d2:	681d      	ldr	r5, [r3, #0]
200249d4:	b12d      	cbz	r5, 200249e2 <bbm_map_check.part.0+0x66>
200249d6:	3406      	adds	r4, #6
200249d8:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
200249dc:	480d      	ldr	r0, [pc, #52]	@ (20024a14 <bbm_map_check.part.0+0x98>)
200249de:	9200      	str	r2, [sp, #0]
200249e0:	47a8      	blx	r5
200249e2:	e7fe      	b.n	200249e2 <bbm_map_check.part.0+0x66>
200249e4:	3401      	adds	r4, #1
200249e6:	e7e8      	b.n	200249ba <bbm_map_check.part.0+0x3e>
200249e8:	eb00 0283 	add.w	r2, r0, r3, lsl #2
200249ec:	8b52      	ldrh	r2, [r2, #26]
200249ee:	2a00      	cmp	r2, #0
200249f0:	d0d0      	beq.n	20024994 <bbm_map_check.part.0+0x18>
200249f2:	4a06      	ldr	r2, [pc, #24]	@ (20024a0c <bbm_map_check.part.0+0x90>)
200249f4:	6814      	ldr	r4, [r2, #0]
200249f6:	b124      	cbz	r4, 20024a02 <bbm_map_check.part.0+0x86>
200249f8:	eb00 0383 	add.w	r3, r0, r3, lsl #2
200249fc:	8b5a      	ldrh	r2, [r3, #26]
200249fe:	4806      	ldr	r0, [pc, #24]	@ (20024a18 <bbm_map_check.part.0+0x9c>)
20024a00:	47a0      	blx	r4
20024a02:	e7fe      	b.n	20024a02 <bbm_map_check.part.0+0x86>
20024a04:	2004ca7c 	.word	0x2004ca7c
20024a08:	2004ca80 	.word	0x2004ca80
20024a0c:	2004ca6c 	.word	0x2004ca6c
20024a10:	20026548 	.word	0x20026548
20024a14:	20026565 	.word	0x20026565
20024a18:	200265b2 	.word	0x200265b2

20024a1c <bbm_crc_check>:
20024a1c:	f04f 32ff 	mov.w	r2, #4294967295
20024a20:	b510      	push	{r4, lr}
20024a22:	4c07      	ldr	r4, [pc, #28]	@ (20024a40 <bbm_crc_check+0x24>)
20024a24:	4401      	add	r1, r0
20024a26:	4288      	cmp	r0, r1
20024a28:	d101      	bne.n	20024a2e <bbm_crc_check+0x12>
20024a2a:	43d0      	mvns	r0, r2
20024a2c:	bd10      	pop	{r4, pc}
20024a2e:	f810 3b01 	ldrb.w	r3, [r0], #1
20024a32:	4053      	eors	r3, r2
20024a34:	b2db      	uxtb	r3, r3
20024a36:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
20024a3a:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
20024a3e:	e7f2      	b.n	20024a26 <bbm_crc_check+0xa>
20024a40:	2002704c 	.word	0x2002704c

20024a44 <bbm_get_phy_blk>:
20024a44:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024a46:	4b14      	ldr	r3, [pc, #80]	@ (20024a98 <bbm_get_phy_blk+0x54>)
20024a48:	4601      	mov	r1, r0
20024a4a:	681e      	ldr	r6, [r3, #0]
20024a4c:	42b0      	cmp	r0, r6
20024a4e:	d21e      	bcs.n	20024a8e <bbm_get_phy_blk+0x4a>
20024a50:	b138      	cbz	r0, 20024a62 <bbm_get_phy_blk+0x1e>
20024a52:	4b12      	ldr	r3, [pc, #72]	@ (20024a9c <bbm_get_phy_blk+0x58>)
20024a54:	2200      	movs	r2, #0
20024a56:	681c      	ldr	r4, [r3, #0]
20024a58:	4b11      	ldr	r3, [pc, #68]	@ (20024aa0 <bbm_get_phy_blk+0x5c>)
20024a5a:	3c04      	subs	r4, #4
20024a5c:	461d      	mov	r5, r3
20024a5e:	4294      	cmp	r4, r2
20024a60:	dc00      	bgt.n	20024a64 <bbm_get_phy_blk+0x20>
20024a62:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024a64:	8b1f      	ldrh	r7, [r3, #24]
20024a66:	428f      	cmp	r7, r1
20024a68:	d10a      	bne.n	20024a80 <bbm_get_phy_blk+0x3c>
20024a6a:	eb05 0582 	add.w	r5, r5, r2, lsl #2
20024a6e:	8b6a      	ldrh	r2, [r5, #26]
20024a70:	4296      	cmp	r6, r2
20024a72:	dd0f      	ble.n	20024a94 <bbm_get_phy_blk+0x50>
20024a74:	4b0b      	ldr	r3, [pc, #44]	@ (20024aa4 <bbm_get_phy_blk+0x60>)
20024a76:	681b      	ldr	r3, [r3, #0]
20024a78:	b10b      	cbz	r3, 20024a7e <bbm_get_phy_blk+0x3a>
20024a7a:	480b      	ldr	r0, [pc, #44]	@ (20024aa8 <bbm_get_phy_blk+0x64>)
20024a7c:	4798      	blx	r3
20024a7e:	e7fe      	b.n	20024a7e <bbm_get_phy_blk+0x3a>
20024a80:	b917      	cbnz	r7, 20024a88 <bbm_get_phy_blk+0x44>
20024a82:	8b5f      	ldrh	r7, [r3, #26]
20024a84:	2f00      	cmp	r7, #0
20024a86:	d0ec      	beq.n	20024a62 <bbm_get_phy_blk+0x1e>
20024a88:	3201      	adds	r2, #1
20024a8a:	3304      	adds	r3, #4
20024a8c:	e7e7      	b.n	20024a5e <bbm_get_phy_blk+0x1a>
20024a8e:	f04f 30ff 	mov.w	r0, #4294967295
20024a92:	e7e6      	b.n	20024a62 <bbm_get_phy_blk+0x1e>
20024a94:	4610      	mov	r0, r2
20024a96:	e7e4      	b.n	20024a62 <bbm_get_phy_blk+0x1e>
20024a98:	2004ca80 	.word	0x2004ca80
20024a9c:	2004ca7c 	.word	0x2004ca7c
20024aa0:	2004ca84 	.word	0x2004ca84
20024aa4:	2004ca6c 	.word	0x2004ca6c
20024aa8:	200265d0 	.word	0x200265d0

20024aac <bbm_get_version_inblk>:
20024aac:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024ab0:	4607      	mov	r7, r0
20024ab2:	4688      	mov	r8, r1
20024ab4:	b087      	sub	sp, #28
20024ab6:	2900      	cmp	r1, #0
20024ab8:	d14b      	bne.n	20024b52 <bbm_get_version_inblk+0xa6>
20024aba:	2500      	movs	r5, #0
20024abc:	4628      	mov	r0, r5
20024abe:	b007      	add	sp, #28
20024ac0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024ac4:	2200      	movs	r2, #0
20024ac6:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024aca:	4e26      	ldr	r6, [pc, #152]	@ (20024b64 <bbm_get_version_inblk+0xb8>)
20024acc:	9100      	str	r1, [sp, #0]
20024ace:	4638      	mov	r0, r7
20024ad0:	4621      	mov	r1, r4
20024ad2:	6833      	ldr	r3, [r6, #0]
20024ad4:	f7fb fe76 	bl	200207c4 <port_read_page>
20024ad8:	2800      	cmp	r0, #0
20024ada:	dd32      	ble.n	20024b42 <bbm_get_version_inblk+0x96>
20024adc:	6832      	ldr	r2, [r6, #0]
20024ade:	6813      	ldr	r3, [r2, #0]
20024ae0:	455b      	cmp	r3, fp
20024ae2:	d123      	bne.n	20024b2c <bbm_get_version_inblk+0x80>
20024ae4:	6856      	ldr	r6, [r2, #4]
20024ae6:	f3c6 061e 	ubfx	r6, r6, #0, #31
20024aea:	42ae      	cmp	r6, r5
20024aec:	dd15      	ble.n	20024b1a <bbm_get_version_inblk+0x6e>
20024aee:	4610      	mov	r0, r2
20024af0:	2110      	movs	r1, #16
20024af2:	9205      	str	r2, [sp, #20]
20024af4:	f7ff ff92 	bl	20024a1c <bbm_crc_check>
20024af8:	9a05      	ldr	r2, [sp, #20]
20024afa:	6913      	ldr	r3, [r2, #16]
20024afc:	4283      	cmp	r3, r0
20024afe:	d113      	bne.n	20024b28 <bbm_get_version_inblk+0x7c>
20024b00:	f8c8 4000 	str.w	r4, [r8]
20024b04:	4635      	mov	r5, r6
20024b06:	3401      	adds	r4, #1
20024b08:	f8da 1000 	ldr.w	r1, [sl]
20024b0c:	f8d9 3000 	ldr.w	r3, [r9]
20024b10:	fbb3 f3f1 	udiv	r3, r3, r1
20024b14:	42a3      	cmp	r3, r4
20024b16:	d8d5      	bhi.n	20024ac4 <bbm_get_version_inblk+0x18>
20024b18:	e7d0      	b.n	20024abc <bbm_get_version_inblk+0x10>
20024b1a:	4b13      	ldr	r3, [pc, #76]	@ (20024b68 <bbm_get_version_inblk+0xbc>)
20024b1c:	681b      	ldr	r3, [r3, #0]
20024b1e:	b11b      	cbz	r3, 20024b28 <bbm_get_version_inblk+0x7c>
20024b20:	4632      	mov	r2, r6
20024b22:	4629      	mov	r1, r5
20024b24:	4811      	ldr	r0, [pc, #68]	@ (20024b6c <bbm_get_version_inblk+0xc0>)
20024b26:	4798      	blx	r3
20024b28:	462e      	mov	r6, r5
20024b2a:	e7eb      	b.n	20024b04 <bbm_get_version_inblk+0x58>
20024b2c:	1c5a      	adds	r2, r3, #1
20024b2e:	d0c5      	beq.n	20024abc <bbm_get_version_inblk+0x10>
20024b30:	4a0d      	ldr	r2, [pc, #52]	@ (20024b68 <bbm_get_version_inblk+0xbc>)
20024b32:	6815      	ldr	r5, [r2, #0]
20024b34:	2d00      	cmp	r5, #0
20024b36:	d0c0      	beq.n	20024aba <bbm_get_version_inblk+0xe>
20024b38:	4622      	mov	r2, r4
20024b3a:	4639      	mov	r1, r7
20024b3c:	480c      	ldr	r0, [pc, #48]	@ (20024b70 <bbm_get_version_inblk+0xc4>)
20024b3e:	47a8      	blx	r5
20024b40:	e7bb      	b.n	20024aba <bbm_get_version_inblk+0xe>
20024b42:	4b09      	ldr	r3, [pc, #36]	@ (20024b68 <bbm_get_version_inblk+0xbc>)
20024b44:	681b      	ldr	r3, [r3, #0]
20024b46:	2b00      	cmp	r3, #0
20024b48:	d0ee      	beq.n	20024b28 <bbm_get_version_inblk+0x7c>
20024b4a:	4622      	mov	r2, r4
20024b4c:	4639      	mov	r1, r7
20024b4e:	4809      	ldr	r0, [pc, #36]	@ (20024b74 <bbm_get_version_inblk+0xc8>)
20024b50:	e7e9      	b.n	20024b26 <bbm_get_version_inblk+0x7a>
20024b52:	2400      	movs	r4, #0
20024b54:	f8df a020 	ldr.w	sl, [pc, #32]	@ 20024b78 <bbm_get_version_inblk+0xcc>
20024b58:	4625      	mov	r5, r4
20024b5a:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 20024b7c <bbm_get_version_inblk+0xd0>
20024b5e:	f8df b020 	ldr.w	fp, [pc, #32]	@ 20024b80 <bbm_get_version_inblk+0xd4>
20024b62:	e7d1      	b.n	20024b08 <bbm_get_version_inblk+0x5c>
20024b64:	2004ca70 	.word	0x2004ca70
20024b68:	2004ca6c 	.word	0x2004ca6c
20024b6c:	200265ef 	.word	0x200265ef
20024b70:	2002661c 	.word	0x2002661c
20024b74:	2002664d 	.word	0x2002664d
20024b78:	2004499c 	.word	0x2004499c
20024b7c:	200449a0 	.word	0x200449a0
20024b80:	5366424d 	.word	0x5366424d

20024b84 <bbm_get_map_table>:
20024b84:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024b88:	2801      	cmp	r0, #1
20024b8a:	4607      	mov	r7, r0
20024b8c:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 20024cec <bbm_get_map_table+0x168>
20024b90:	b087      	sub	sp, #28
20024b92:	dd0a      	ble.n	20024baa <bbm_get_map_table+0x26>
20024b94:	f8db 3000 	ldr.w	r3, [fp]
20024b98:	b91b      	cbnz	r3, 20024ba2 <bbm_get_map_table+0x1e>
20024b9a:	2000      	movs	r0, #0
20024b9c:	b007      	add	sp, #28
20024b9e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024ba2:	4601      	mov	r1, r0
20024ba4:	4847      	ldr	r0, [pc, #284]	@ (20024cc4 <bbm_get_map_table+0x140>)
20024ba6:	4798      	blx	r3
20024ba8:	e7f7      	b.n	20024b9a <bbm_get_map_table+0x16>
20024baa:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 20024cf0 <bbm_get_map_table+0x16c>
20024bae:	2800      	cmp	r0, #0
20024bb0:	d163      	bne.n	20024c7a <bbm_get_map_table+0xf6>
20024bb2:	f8b8 6000 	ldrh.w	r6, [r8]
20024bb6:	f8b8 5002 	ldrh.w	r5, [r8, #2]
20024bba:	2e00      	cmp	r6, #0
20024bbc:	d062      	beq.n	20024c84 <bbm_get_map_table+0x100>
20024bbe:	4630      	mov	r0, r6
20024bc0:	a904      	add	r1, sp, #16
20024bc2:	f7ff ff73 	bl	20024aac <bbm_get_version_inblk>
20024bc6:	4681      	mov	r9, r0
20024bc8:	2d00      	cmp	r5, #0
20024bca:	d05d      	beq.n	20024c88 <bbm_get_map_table+0x104>
20024bcc:	4628      	mov	r0, r5
20024bce:	a905      	add	r1, sp, #20
20024bd0:	f7ff ff6c 	bl	20024aac <bbm_get_version_inblk>
20024bd4:	4604      	mov	r4, r0
20024bd6:	f8db a000 	ldr.w	sl, [fp]
20024bda:	f1ba 0f00 	cmp.w	sl, #0
20024bde:	d005      	beq.n	20024bec <bbm_get_map_table+0x68>
20024be0:	4623      	mov	r3, r4
20024be2:	4632      	mov	r2, r6
20024be4:	4649      	mov	r1, r9
20024be6:	4838      	ldr	r0, [pc, #224]	@ (20024cc8 <bbm_get_map_table+0x144>)
20024be8:	9500      	str	r5, [sp, #0]
20024bea:	47d0      	blx	sl
20024bec:	45a1      	cmp	r9, r4
20024bee:	d0d4      	beq.n	20024b9a <bbm_get_map_table+0x16>
20024bf0:	f04f 0200 	mov.w	r2, #0
20024bf4:	bf98      	it	ls
20024bf6:	462e      	movls	r6, r5
20024bf8:	f107 0308 	add.w	r3, r7, #8
20024bfc:	bf94      	ite	ls
20024bfe:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
20024c02:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
20024c06:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024c0a:	4b30      	ldr	r3, [pc, #192]	@ (20024ccc <bbm_get_map_table+0x148>)
20024c0c:	bf88      	it	hi
20024c0e:	f8dd a010 	ldrhi.w	sl, [sp, #16]
20024c12:	681b      	ldr	r3, [r3, #0]
20024c14:	bf98      	it	ls
20024c16:	f8dd a014 	ldrls.w	sl, [sp, #20]
20024c1a:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 20024cf4 <bbm_get_map_table+0x170>
20024c1e:	9300      	str	r3, [sp, #0]
20024c20:	4651      	mov	r1, sl
20024c22:	4630      	mov	r0, r6
20024c24:	f8d8 3000 	ldr.w	r3, [r8]
20024c28:	bf88      	it	hi
20024c2a:	464c      	movhi	r4, r9
20024c2c:	f7fb fdca 	bl	200207c4 <port_read_page>
20024c30:	2800      	cmp	r0, #0
20024c32:	f8db 5000 	ldr.w	r5, [fp]
20024c36:	dd38      	ble.n	20024caa <bbm_get_map_table+0x126>
20024c38:	f8d8 8000 	ldr.w	r8, [r8]
20024c3c:	4b24      	ldr	r3, [pc, #144]	@ (20024cd0 <bbm_get_map_table+0x14c>)
20024c3e:	f8d8 2000 	ldr.w	r2, [r8]
20024c42:	429a      	cmp	r2, r3
20024c44:	d12b      	bne.n	20024c9e <bbm_get_map_table+0x11a>
20024c46:	2110      	movs	r1, #16
20024c48:	4640      	mov	r0, r8
20024c4a:	f7ff fee7 	bl	20024a1c <bbm_crc_check>
20024c4e:	f8d8 2010 	ldr.w	r2, [r8, #16]
20024c52:	4601      	mov	r1, r0
20024c54:	4282      	cmp	r2, r0
20024c56:	d11e      	bne.n	20024c96 <bbm_get_map_table+0x112>
20024c58:	f8d8 1004 	ldr.w	r1, [r8, #4]
20024c5c:	f3c1 011e 	ubfx	r1, r1, #0, #31
20024c60:	42a1      	cmp	r1, r4
20024c62:	d113      	bne.n	20024c8c <bbm_get_map_table+0x108>
20024c64:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024c68:	481a      	ldr	r0, [pc, #104]	@ (20024cd4 <bbm_get_map_table+0x150>)
20024c6a:	4641      	mov	r1, r8
20024c6c:	fb02 0007 	mla	r0, r2, r7, r0
20024c70:	f001 f867 	bl	20025d42 <memcpy>
20024c74:	bb0d      	cbnz	r5, 20024cba <bbm_get_map_table+0x136>
20024c76:	4620      	mov	r0, r4
20024c78:	e790      	b.n	20024b9c <bbm_get_map_table+0x18>
20024c7a:	f8b8 6004 	ldrh.w	r6, [r8, #4]
20024c7e:	f8b8 5006 	ldrh.w	r5, [r8, #6]
20024c82:	e79a      	b.n	20024bba <bbm_get_map_table+0x36>
20024c84:	46b1      	mov	r9, r6
20024c86:	e79f      	b.n	20024bc8 <bbm_get_map_table+0x44>
20024c88:	462c      	mov	r4, r5
20024c8a:	e7a4      	b.n	20024bd6 <bbm_get_map_table+0x52>
20024c8c:	b115      	cbz	r5, 20024c94 <bbm_get_map_table+0x110>
20024c8e:	4622      	mov	r2, r4
20024c90:	4811      	ldr	r0, [pc, #68]	@ (20024cd8 <bbm_get_map_table+0x154>)
20024c92:	47a8      	blx	r5
20024c94:	e7fe      	b.n	20024c94 <bbm_get_map_table+0x110>
20024c96:	b10d      	cbz	r5, 20024c9c <bbm_get_map_table+0x118>
20024c98:	4810      	ldr	r0, [pc, #64]	@ (20024cdc <bbm_get_map_table+0x158>)
20024c9a:	47a8      	blx	r5
20024c9c:	e7fe      	b.n	20024c9c <bbm_get_map_table+0x118>
20024c9e:	b11d      	cbz	r5, 20024ca8 <bbm_get_map_table+0x124>
20024ca0:	4652      	mov	r2, sl
20024ca2:	4631      	mov	r1, r6
20024ca4:	480e      	ldr	r0, [pc, #56]	@ (20024ce0 <bbm_get_map_table+0x15c>)
20024ca6:	47a8      	blx	r5
20024ca8:	e7fe      	b.n	20024ca8 <bbm_get_map_table+0x124>
20024caa:	2d00      	cmp	r5, #0
20024cac:	f43f af75 	beq.w	20024b9a <bbm_get_map_table+0x16>
20024cb0:	4652      	mov	r2, sl
20024cb2:	4631      	mov	r1, r6
20024cb4:	480b      	ldr	r0, [pc, #44]	@ (20024ce4 <bbm_get_map_table+0x160>)
20024cb6:	47a8      	blx	r5
20024cb8:	e76f      	b.n	20024b9a <bbm_get_map_table+0x16>
20024cba:	4621      	mov	r1, r4
20024cbc:	480a      	ldr	r0, [pc, #40]	@ (20024ce8 <bbm_get_map_table+0x164>)
20024cbe:	47a8      	blx	r5
20024cc0:	e7d9      	b.n	20024c76 <bbm_get_map_table+0xf2>
20024cc2:	bf00      	nop
20024cc4:	2002666b 	.word	0x2002666b
20024cc8:	2002667f 	.word	0x2002667f
20024ccc:	2004499c 	.word	0x2004499c
20024cd0:	5366424d 	.word	0x5366424d
20024cd4:	2004ca84 	.word	0x2004ca84
20024cd8:	200266a5 	.word	0x200266a5
20024cdc:	200266ef 	.word	0x200266ef
20024ce0:	20026701 	.word	0x20026701
20024ce4:	20026736 	.word	0x20026736
20024ce8:	20026762 	.word	0x20026762
20024cec:	2004ca6c 	.word	0x2004ca6c
20024cf0:	2004ce94 	.word	0x2004ce94
20024cf4:	2004ca70 	.word	0x2004ca70

20024cf8 <bbm_get_page_num>:
20024cf8:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20024cfc:	4605      	mov	r5, r0
20024cfe:	2400      	movs	r4, #0
20024d00:	4f13      	ldr	r7, [pc, #76]	@ (20024d50 <bbm_get_page_num+0x58>)
20024d02:	4e14      	ldr	r6, [pc, #80]	@ (20024d54 <bbm_get_page_num+0x5c>)
20024d04:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 20024d58 <bbm_get_page_num+0x60>
20024d08:	b085      	sub	sp, #20
20024d0a:	6839      	ldr	r1, [r7, #0]
20024d0c:	6833      	ldr	r3, [r6, #0]
20024d0e:	fbb3 f3f1 	udiv	r3, r3, r1
20024d12:	42a3      	cmp	r3, r4
20024d14:	d802      	bhi.n	20024d1c <bbm_get_page_num+0x24>
20024d16:	f04f 34ff 	mov.w	r4, #4294967295
20024d1a:	e015      	b.n	20024d48 <bbm_get_page_num+0x50>
20024d1c:	2200      	movs	r2, #0
20024d1e:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024d22:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 20024d5c <bbm_get_page_num+0x64>
20024d26:	9100      	str	r1, [sp, #0]
20024d28:	4628      	mov	r0, r5
20024d2a:	4621      	mov	r1, r4
20024d2c:	f8d9 3000 	ldr.w	r3, [r9]
20024d30:	f7fb fd48 	bl	200207c4 <port_read_page>
20024d34:	b120      	cbz	r0, 20024d40 <bbm_get_page_num+0x48>
20024d36:	f8d9 3000 	ldr.w	r3, [r9]
20024d3a:	681b      	ldr	r3, [r3, #0]
20024d3c:	4543      	cmp	r3, r8
20024d3e:	d101      	bne.n	20024d44 <bbm_get_page_num+0x4c>
20024d40:	3401      	adds	r4, #1
20024d42:	e7e2      	b.n	20024d0a <bbm_get_page_num+0x12>
20024d44:	3301      	adds	r3, #1
20024d46:	d1fb      	bne.n	20024d40 <bbm_get_page_num+0x48>
20024d48:	4620      	mov	r0, r4
20024d4a:	b005      	add	sp, #20
20024d4c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20024d50:	2004499c 	.word	0x2004499c
20024d54:	200449a0 	.word	0x200449a0
20024d58:	5366424d 	.word	0x5366424d
20024d5c:	2004ca70 	.word	0x2004ca70

20024d60 <bbm_read_page>:
20024d60:	b5f0      	push	{r4, r5, r6, r7, lr}
20024d62:	4604      	mov	r4, r0
20024d64:	b085      	sub	sp, #20
20024d66:	b280      	uxth	r0, r0
20024d68:	461f      	mov	r7, r3
20024d6a:	460d      	mov	r5, r1
20024d6c:	4616      	mov	r6, r2
20024d6e:	f7ff fe69 	bl	20024a44 <bbm_get_phy_blk>
20024d72:	1c43      	adds	r3, r0, #1
20024d74:	d108      	bne.n	20024d88 <bbm_read_page+0x28>
20024d76:	4b0a      	ldr	r3, [pc, #40]	@ (20024da0 <bbm_read_page+0x40>)
20024d78:	681b      	ldr	r3, [r3, #0]
20024d7a:	b113      	cbz	r3, 20024d82 <bbm_read_page+0x22>
20024d7c:	4621      	mov	r1, r4
20024d7e:	4809      	ldr	r0, [pc, #36]	@ (20024da4 <bbm_read_page+0x44>)
20024d80:	4798      	blx	r3
20024d82:	2000      	movs	r0, #0
20024d84:	b005      	add	sp, #20
20024d86:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024d88:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
20024d8a:	4632      	mov	r2, r6
20024d8c:	9302      	str	r3, [sp, #8]
20024d8e:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
20024d90:	4629      	mov	r1, r5
20024d92:	9301      	str	r3, [sp, #4]
20024d94:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20024d96:	9300      	str	r3, [sp, #0]
20024d98:	463b      	mov	r3, r7
20024d9a:	f7fb fd13 	bl	200207c4 <port_read_page>
20024d9e:	e7f1      	b.n	20024d84 <bbm_read_page+0x24>
20024da0:	2004ca6c 	.word	0x2004ca6c
20024da4:	20026775 	.word	0x20026775

20024da8 <port_write_page>:
20024da8:	4b01      	ldr	r3, [pc, #4]	@ (20024db0 <port_write_page+0x8>)
20024daa:	6818      	ldr	r0, [r3, #0]
20024dac:	4770      	bx	lr
20024dae:	bf00      	nop
20024db0:	2004499c 	.word	0x2004499c

20024db4 <bbm_write_talbe.isra.0>:
20024db4:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024db6:	4604      	mov	r4, r0
20024db8:	4608      	mov	r0, r1
20024dba:	460e      	mov	r6, r1
20024dbc:	f7ff ff9c 	bl	20024cf8 <bbm_get_page_num>
20024dc0:	1e05      	subs	r5, r0, #0
20024dc2:	db25      	blt.n	20024e10 <bbm_write_talbe.isra.0+0x5c>
20024dc4:	4b13      	ldr	r3, [pc, #76]	@ (20024e14 <bbm_write_talbe.isra.0+0x60>)
20024dc6:	681a      	ldr	r2, [r3, #0]
20024dc8:	4b13      	ldr	r3, [pc, #76]	@ (20024e18 <bbm_write_talbe.isra.0+0x64>)
20024dca:	681b      	ldr	r3, [r3, #0]
20024dcc:	fbb3 f3f2 	udiv	r3, r3, r2
20024dd0:	429d      	cmp	r5, r3
20024dd2:	da1d      	bge.n	20024e10 <bbm_write_talbe.isra.0+0x5c>
20024dd4:	4f11      	ldr	r7, [pc, #68]	@ (20024e1c <bbm_write_talbe.isra.0+0x68>)
20024dd6:	21ff      	movs	r1, #255	@ 0xff
20024dd8:	6838      	ldr	r0, [r7, #0]
20024dda:	f000 ff43 	bl	20025c64 <memset>
20024dde:	4264      	negs	r4, r4
20024de0:	490f      	ldr	r1, [pc, #60]	@ (20024e20 <bbm_write_talbe.isra.0+0x6c>)
20024de2:	f404 7402 	and.w	r4, r4, #520	@ 0x208
20024de6:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024dea:	6838      	ldr	r0, [r7, #0]
20024dec:	4421      	add	r1, r4
20024dee:	f000 ffa8 	bl	20025d42 <memcpy>
20024df2:	6838      	ldr	r0, [r7, #0]
20024df4:	b160      	cbz	r0, 20024e10 <bbm_write_talbe.isra.0+0x5c>
20024df6:	6802      	ldr	r2, [r0, #0]
20024df8:	4b0a      	ldr	r3, [pc, #40]	@ (20024e24 <bbm_write_talbe.isra.0+0x70>)
20024dfa:	429a      	cmp	r2, r3
20024dfc:	d108      	bne.n	20024e10 <bbm_write_talbe.isra.0+0x5c>
20024dfe:	f7ff fdbd 	bl	2002497c <bbm_map_check.part.0>
20024e02:	2300      	movs	r3, #0
20024e04:	9300      	str	r3, [sp, #0]
20024e06:	4629      	mov	r1, r5
20024e08:	4630      	mov	r0, r6
20024e0a:	683a      	ldr	r2, [r7, #0]
20024e0c:	f7ff ffcc 	bl	20024da8 <port_write_page>
20024e10:	b003      	add	sp, #12
20024e12:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024e14:	2004499c 	.word	0x2004499c
20024e18:	200449a0 	.word	0x200449a0
20024e1c:	2004ca70 	.word	0x2004ca70
20024e20:	2004ca84 	.word	0x2004ca84
20024e24:	5366424d 	.word	0x5366424d

20024e28 <port_erase_block>:
20024e28:	2000      	movs	r0, #0
20024e2a:	4770      	bx	lr

20024e2c <bbm_init_table>:
20024e2c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024e30:	4c7c      	ldr	r4, [pc, #496]	@ (20025024 <bbm_init_table+0x1f8>)
20024e32:	4b7d      	ldr	r3, [pc, #500]	@ (20025028 <bbm_init_table+0x1fc>)
20024e34:	6822      	ldr	r2, [r4, #0]
20024e36:	b085      	sub	sp, #20
20024e38:	429a      	cmp	r2, r3
20024e3a:	f000 80ed 	beq.w	20025018 <bbm_init_table+0x1ec>
20024e3e:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
20024e42:	429a      	cmp	r2, r3
20024e44:	f000 80e8 	beq.w	20025018 <bbm_init_table+0x1ec>
20024e48:	6023      	str	r3, [r4, #0]
20024e4a:	2301      	movs	r3, #1
20024e4c:	6063      	str	r3, [r4, #4]
20024e4e:	2300      	movs	r3, #0
20024e50:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 2002505c <bbm_init_table+0x230>
20024e54:	8123      	strh	r3, [r4, #8]
20024e56:	f8d9 3000 	ldr.w	r3, [r9]
20024e5a:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 20025060 <bbm_init_table+0x234>
20024e5e:	3b04      	subs	r3, #4
20024e60:	f8df a200 	ldr.w	sl, [pc, #512]	@ 20025064 <bbm_init_table+0x238>
20024e64:	8163      	strh	r3, [r4, #10]
20024e66:	f8d8 3000 	ldr.w	r3, [r8]
20024e6a:	f8da 5000 	ldr.w	r5, [sl]
20024e6e:	3b01      	subs	r3, #1
20024e70:	4e6e      	ldr	r6, [pc, #440]	@ (2002502c <bbm_init_table+0x200>)
20024e72:	81a3      	strh	r3, [r4, #12]
20024e74:	81e5      	strh	r5, [r4, #14]
20024e76:	f8d8 3000 	ldr.w	r3, [r8]
20024e7a:	429d      	cmp	r5, r3
20024e7c:	db10      	blt.n	20024ea0 <bbm_init_table+0x74>
20024e7e:	2500      	movs	r5, #0
20024e80:	462f      	mov	r7, r5
20024e82:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 2002502c <bbm_init_table+0x200>
20024e86:	f8da 6000 	ldr.w	r6, [sl]
20024e8a:	42b5      	cmp	r5, r6
20024e8c:	db1d      	blt.n	20024eca <bbm_init_table+0x9e>
20024e8e:	8963      	ldrh	r3, [r4, #10]
20024e90:	2b00      	cmp	r3, #0
20024e92:	d148      	bne.n	20024f26 <bbm_init_table+0xfa>
20024e94:	4b65      	ldr	r3, [pc, #404]	@ (2002502c <bbm_init_table+0x200>)
20024e96:	681b      	ldr	r3, [r3, #0]
20024e98:	b10b      	cbz	r3, 20024e9e <bbm_init_table+0x72>
20024e9a:	4865      	ldr	r0, [pc, #404]	@ (20025030 <bbm_init_table+0x204>)
20024e9c:	4798      	blx	r3
20024e9e:	e7fe      	b.n	20024e9e <bbm_init_table+0x72>
20024ea0:	4628      	mov	r0, r5
20024ea2:	f7fb fcf5 	bl	20020890 <bbm_get_bb>
20024ea6:	b950      	cbnz	r0, 20024ebe <bbm_init_table+0x92>
20024ea8:	4628      	mov	r0, r5
20024eaa:	f7ff ffbd 	bl	20024e28 <port_erase_block>
20024eae:	b120      	cbz	r0, 20024eba <bbm_init_table+0x8e>
20024eb0:	6833      	ldr	r3, [r6, #0]
20024eb2:	b113      	cbz	r3, 20024eba <bbm_init_table+0x8e>
20024eb4:	4629      	mov	r1, r5
20024eb6:	485f      	ldr	r0, [pc, #380]	@ (20025034 <bbm_init_table+0x208>)
20024eb8:	4798      	blx	r3
20024eba:	3501      	adds	r5, #1
20024ebc:	e7db      	b.n	20024e76 <bbm_init_table+0x4a>
20024ebe:	6833      	ldr	r3, [r6, #0]
20024ec0:	2b00      	cmp	r3, #0
20024ec2:	d0fa      	beq.n	20024eba <bbm_init_table+0x8e>
20024ec4:	4629      	mov	r1, r5
20024ec6:	485c      	ldr	r0, [pc, #368]	@ (20025038 <bbm_init_table+0x20c>)
20024ec8:	e7f6      	b.n	20024eb8 <bbm_init_table+0x8c>
20024eca:	4628      	mov	r0, r5
20024ecc:	f7fb fce0 	bl	20020890 <bbm_get_bb>
20024ed0:	b338      	cbz	r0, 20024f22 <bbm_init_table+0xf6>
20024ed2:	f8db 3000 	ldr.w	r3, [fp]
20024ed6:	b113      	cbz	r3, 20024ede <bbm_init_table+0xb2>
20024ed8:	4629      	mov	r1, r5
20024eda:	4858      	ldr	r0, [pc, #352]	@ (2002503c <bbm_init_table+0x210>)
20024edc:	4798      	blx	r3
20024ede:	89a0      	ldrh	r0, [r4, #12]
20024ee0:	f7fb fcd6 	bl	20020890 <bbm_get_bb>
20024ee4:	89a3      	ldrh	r3, [r4, #12]
20024ee6:	4606      	mov	r6, r0
20024ee8:	3b01      	subs	r3, #1
20024eea:	81a3      	strh	r3, [r4, #12]
20024eec:	8963      	ldrh	r3, [r4, #10]
20024eee:	3b01      	subs	r3, #1
20024ef0:	b29b      	uxth	r3, r3
20024ef2:	8163      	strh	r3, [r4, #10]
20024ef4:	b108      	cbz	r0, 20024efa <bbm_init_table+0xce>
20024ef6:	2b00      	cmp	r3, #0
20024ef8:	d1f1      	bne.n	20024ede <bbm_init_table+0xb2>
20024efa:	f8db 3000 	ldr.w	r3, [fp]
20024efe:	b11b      	cbz	r3, 20024f08 <bbm_init_table+0xdc>
20024f00:	463a      	mov	r2, r7
20024f02:	4629      	mov	r1, r5
20024f04:	484e      	ldr	r0, [pc, #312]	@ (20025040 <bbm_init_table+0x214>)
20024f06:	4798      	blx	r3
20024f08:	b93e      	cbnz	r6, 20024f1a <bbm_init_table+0xee>
20024f0a:	89a2      	ldrh	r2, [r4, #12]
20024f0c:	1dbb      	adds	r3, r7, #6
20024f0e:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
20024f12:	3201      	adds	r2, #1
20024f14:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20024f18:	805a      	strh	r2, [r3, #2]
20024f1a:	8923      	ldrh	r3, [r4, #8]
20024f1c:	3701      	adds	r7, #1
20024f1e:	3301      	adds	r3, #1
20024f20:	8123      	strh	r3, [r4, #8]
20024f22:	3501      	adds	r5, #1
20024f24:	e7af      	b.n	20024e86 <bbm_init_table+0x5a>
20024f26:	2110      	movs	r1, #16
20024f28:	483e      	ldr	r0, [pc, #248]	@ (20025024 <bbm_init_table+0x1f8>)
20024f2a:	f7ff fd77 	bl	20024a1c <bbm_crc_check>
20024f2e:	f8d9 1000 	ldr.w	r1, [r9]
20024f32:	6120      	str	r0, [r4, #16]
20024f34:	3904      	subs	r1, #4
20024f36:	0089      	lsls	r1, r1, #2
20024f38:	4842      	ldr	r0, [pc, #264]	@ (20025044 <bbm_init_table+0x218>)
20024f3a:	f7ff fd6f 	bl	20024a1c <bbm_crc_check>
20024f3e:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024f42:	4938      	ldr	r1, [pc, #224]	@ (20025024 <bbm_init_table+0x1f8>)
20024f44:	6160      	str	r0, [r4, #20]
20024f46:	1888      	adds	r0, r1, r2
20024f48:	f000 fefb 	bl	20025d42 <memcpy>
20024f4c:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20024f50:	2110      	movs	r1, #16
20024f52:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20024f56:	483c      	ldr	r0, [pc, #240]	@ (20025048 <bbm_init_table+0x21c>)
20024f58:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20024f5c:	f7ff fd5e 	bl	20024a1c <bbm_crc_check>
20024f60:	2700      	movs	r7, #0
20024f62:	f8df a104 	ldr.w	sl, [pc, #260]	@ 20025068 <bbm_init_table+0x23c>
20024f66:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 2002506c <bbm_init_table+0x240>
20024f6a:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20024f6e:	f8d8 3000 	ldr.w	r3, [r8]
20024f72:	429e      	cmp	r6, r3
20024f74:	db08      	blt.n	20024f88 <bbm_init_table+0x15c>
20024f76:	2f03      	cmp	r7, #3
20024f78:	dc2f      	bgt.n	20024fda <bbm_init_table+0x1ae>
20024f7a:	4b2c      	ldr	r3, [pc, #176]	@ (2002502c <bbm_init_table+0x200>)
20024f7c:	681b      	ldr	r3, [r3, #0]
20024f7e:	b113      	cbz	r3, 20024f86 <bbm_init_table+0x15a>
20024f80:	4639      	mov	r1, r7
20024f82:	4832      	ldr	r0, [pc, #200]	@ (2002504c <bbm_init_table+0x220>)
20024f84:	4798      	blx	r3
20024f86:	e7fe      	b.n	20024f86 <bbm_init_table+0x15a>
20024f88:	4630      	mov	r0, r6
20024f8a:	f7fb fc81 	bl	20020890 <bbm_get_bb>
20024f8e:	4604      	mov	r4, r0
20024f90:	bb08      	cbnz	r0, 20024fd6 <bbm_init_table+0x1aa>
20024f92:	f8da 5000 	ldr.w	r5, [sl]
20024f96:	21ff      	movs	r1, #255	@ 0xff
20024f98:	462a      	mov	r2, r5
20024f9a:	f8d9 0000 	ldr.w	r0, [r9]
20024f9e:	f000 fe61 	bl	20025c64 <memset>
20024fa2:	e9cd 4401 	strd	r4, r4, [sp, #4]
20024fa6:	9500      	str	r5, [sp, #0]
20024fa8:	f8d9 3000 	ldr.w	r3, [r9]
20024fac:	4622      	mov	r2, r4
20024fae:	4621      	mov	r1, r4
20024fb0:	4630      	mov	r0, r6
20024fb2:	f7fb fc07 	bl	200207c4 <port_read_page>
20024fb6:	f8da 3000 	ldr.w	r3, [sl]
20024fba:	4298      	cmp	r0, r3
20024fbc:	d109      	bne.n	20024fd2 <bbm_init_table+0x1a6>
20024fbe:	f8d9 3000 	ldr.w	r3, [r9]
20024fc2:	681b      	ldr	r3, [r3, #0]
20024fc4:	3301      	adds	r3, #1
20024fc6:	bf01      	itttt	eq
20024fc8:	4b21      	ldreq	r3, [pc, #132]	@ (20025050 <bbm_init_table+0x224>)
20024fca:	1d3a      	addeq	r2, r7, #4
20024fcc:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
20024fd0:	3701      	addeq	r7, #1
20024fd2:	2f03      	cmp	r7, #3
20024fd4:	dc01      	bgt.n	20024fda <bbm_init_table+0x1ae>
20024fd6:	3601      	adds	r6, #1
20024fd8:	e7c9      	b.n	20024f6e <bbm_init_table+0x142>
20024fda:	2500      	movs	r5, #0
20024fdc:	4c1c      	ldr	r4, [pc, #112]	@ (20025050 <bbm_init_table+0x224>)
20024fde:	2000      	movs	r0, #0
20024fe0:	8921      	ldrh	r1, [r4, #8]
20024fe2:	f7ff fee7 	bl	20024db4 <bbm_write_talbe.isra.0>
20024fe6:	8923      	ldrh	r3, [r4, #8]
20024fe8:	2001      	movs	r0, #1
20024fea:	8961      	ldrh	r1, [r4, #10]
20024fec:	8023      	strh	r3, [r4, #0]
20024fee:	8223      	strh	r3, [r4, #16]
20024ff0:	8125      	strh	r5, [r4, #8]
20024ff2:	f7ff fedf 	bl	20024db4 <bbm_write_talbe.isra.0>
20024ff6:	8963      	ldrh	r3, [r4, #10]
20024ff8:	8165      	strh	r5, [r4, #10]
20024ffa:	80a3      	strh	r3, [r4, #4]
20024ffc:	8263      	strh	r3, [r4, #18]
20024ffe:	89a3      	ldrh	r3, [r4, #12]
20025000:	8063      	strh	r3, [r4, #2]
20025002:	89e3      	ldrh	r3, [r4, #14]
20025004:	80e3      	strh	r3, [r4, #6]
20025006:	4b09      	ldr	r3, [pc, #36]	@ (2002502c <bbm_init_table+0x200>)
20025008:	681b      	ldr	r3, [r3, #0]
2002500a:	b10b      	cbz	r3, 20025010 <bbm_init_table+0x1e4>
2002500c:	4811      	ldr	r0, [pc, #68]	@ (20025054 <bbm_init_table+0x228>)
2002500e:	4798      	blx	r3
20025010:	2000      	movs	r0, #0
20025012:	b005      	add	sp, #20
20025014:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025018:	4b04      	ldr	r3, [pc, #16]	@ (2002502c <bbm_init_table+0x200>)
2002501a:	681b      	ldr	r3, [r3, #0]
2002501c:	b10b      	cbz	r3, 20025022 <bbm_init_table+0x1f6>
2002501e:	480e      	ldr	r0, [pc, #56]	@ (20025058 <bbm_init_table+0x22c>)
20025020:	4798      	blx	r3
20025022:	e7fe      	b.n	20025022 <bbm_init_table+0x1f6>
20025024:	2004ca84 	.word	0x2004ca84
20025028:	5366424d 	.word	0x5366424d
2002502c:	2004ca6c 	.word	0x2004ca6c
20025030:	2002680a 	.word	0x2002680a
20025034:	20026798 	.word	0x20026798
20025038:	200267ba 	.word	0x200267ba
2002503c:	200267d7 	.word	0x200267d7
20025040:	200267f6 	.word	0x200267f6
20025044:	2004ca9c 	.word	0x2004ca9c
20025048:	2004cc8c 	.word	0x2004cc8c
2002504c:	20026824 	.word	0x20026824
20025050:	2004ce94 	.word	0x2004ce94
20025054:	2002684b 	.word	0x2002684b
20025058:	20026867 	.word	0x20026867
2002505c:	2004ca7c 	.word	0x2004ca7c
20025060:	2004ca78 	.word	0x2004ca78
20025064:	2004ca80 	.word	0x2004ca80
20025068:	2004499c 	.word	0x2004499c
2002506c:	2004ca70 	.word	0x2004ca70

20025070 <sif_bbm_init>:
20025070:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025074:	b087      	sub	sp, #28
20025076:	2900      	cmp	r1, #0
20025078:	f000 8129 	beq.w	200252ce <sif_bbm_init+0x25e>
2002507c:	4b95      	ldr	r3, [pc, #596]	@ (200252d4 <sif_bbm_init+0x264>)
2002507e:	681a      	ldr	r2, [r3, #0]
20025080:	2a01      	cmp	r2, #1
20025082:	d108      	bne.n	20025096 <sif_bbm_init+0x26>
20025084:	4b94      	ldr	r3, [pc, #592]	@ (200252d8 <sif_bbm_init+0x268>)
20025086:	681b      	ldr	r3, [r3, #0]
20025088:	b10b      	cbz	r3, 2002508e <sif_bbm_init+0x1e>
2002508a:	4894      	ldr	r0, [pc, #592]	@ (200252dc <sif_bbm_init+0x26c>)
2002508c:	4798      	blx	r3
2002508e:	2000      	movs	r0, #0
20025090:	b007      	add	sp, #28
20025092:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025096:	2201      	movs	r2, #1
20025098:	601a      	str	r2, [r3, #0]
2002509a:	4b91      	ldr	r3, [pc, #580]	@ (200252e0 <sif_bbm_init+0x270>)
2002509c:	681c      	ldr	r4, [r3, #0]
2002509e:	b904      	cbnz	r4, 200250a2 <sif_bbm_init+0x32>
200250a0:	e7fe      	b.n	200250a0 <sif_bbm_init+0x30>
200250a2:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 20025320 <sif_bbm_init+0x2b0>
200250a6:	f8da 2000 	ldr.w	r2, [sl]
200250aa:	b902      	cbnz	r2, 200250ae <sif_bbm_init+0x3e>
200250ac:	e7fe      	b.n	200250ac <sif_bbm_init+0x3c>
200250ae:	fbb0 f4f4 	udiv	r4, r0, r4
200250b2:	f04f 0800 	mov.w	r8, #0
200250b6:	4a8b      	ldr	r2, [pc, #556]	@ (200252e4 <sif_bbm_init+0x274>)
200250b8:	f8df b268 	ldr.w	fp, [pc, #616]	@ 20025324 <sif_bbm_init+0x2b4>
200250bc:	0963      	lsrs	r3, r4, #5
200250be:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20025328 <sif_bbm_init+0x2b8>
200250c2:	6013      	str	r3, [r2, #0]
200250c4:	f8cb 4000 	str.w	r4, [fp]
200250c8:	1ae4      	subs	r4, r4, r3
200250ca:	4b87      	ldr	r3, [pc, #540]	@ (200252e8 <sif_bbm_init+0x278>)
200250cc:	2218      	movs	r2, #24
200250ce:	f8c9 1000 	str.w	r1, [r9]
200250d2:	4886      	ldr	r0, [pc, #536]	@ (200252ec <sif_bbm_init+0x27c>)
200250d4:	2100      	movs	r1, #0
200250d6:	601c      	str	r4, [r3, #0]
200250d8:	f000 fdc4 	bl	20025c64 <memset>
200250dc:	f44f 6282 	mov.w	r2, #1040	@ 0x410
200250e0:	2100      	movs	r1, #0
200250e2:	4883      	ldr	r0, [pc, #524]	@ (200252f0 <sif_bbm_init+0x280>)
200250e4:	f000 fdbe 	bl	20025c64 <memset>
200250e8:	4647      	mov	r7, r8
200250ea:	4646      	mov	r6, r8
200250ec:	f8db 3000 	ldr.w	r3, [fp]
200250f0:	429c      	cmp	r4, r3
200250f2:	db02      	blt.n	200250fa <sif_bbm_init+0x8a>
200250f4:	f04f 35ff 	mov.w	r5, #4294967295
200250f8:	e064      	b.n	200251c4 <sif_bbm_init+0x154>
200250fa:	4620      	mov	r0, r4
200250fc:	f7fb fbc8 	bl	20020890 <bbm_get_bb>
20025100:	4605      	mov	r5, r0
20025102:	b138      	cbz	r0, 20025114 <sif_bbm_init+0xa4>
20025104:	4b74      	ldr	r3, [pc, #464]	@ (200252d8 <sif_bbm_init+0x268>)
20025106:	681b      	ldr	r3, [r3, #0]
20025108:	b113      	cbz	r3, 20025110 <sif_bbm_init+0xa0>
2002510a:	4621      	mov	r1, r4
2002510c:	4879      	ldr	r0, [pc, #484]	@ (200252f4 <sif_bbm_init+0x284>)
2002510e:	4798      	blx	r3
20025110:	3401      	adds	r4, #1
20025112:	e7eb      	b.n	200250ec <sif_bbm_init+0x7c>
20025114:	f8da 2000 	ldr.w	r2, [sl]
20025118:	21ff      	movs	r1, #255	@ 0xff
2002511a:	f8d9 0000 	ldr.w	r0, [r9]
2002511e:	9205      	str	r2, [sp, #20]
20025120:	f000 fda0 	bl	20025c64 <memset>
20025124:	9a05      	ldr	r2, [sp, #20]
20025126:	e9cd 5501 	strd	r5, r5, [sp, #4]
2002512a:	9200      	str	r2, [sp, #0]
2002512c:	f8d9 3000 	ldr.w	r3, [r9]
20025130:	462a      	mov	r2, r5
20025132:	4629      	mov	r1, r5
20025134:	4620      	mov	r0, r4
20025136:	f7fb fb45 	bl	200207c4 <port_read_page>
2002513a:	f8da 3000 	ldr.w	r3, [sl]
2002513e:	4298      	cmp	r0, r3
20025140:	d12e      	bne.n	200251a0 <sif_bbm_init+0x130>
20025142:	f8d9 1000 	ldr.w	r1, [r9]
20025146:	486c      	ldr	r0, [pc, #432]	@ (200252f8 <sif_bbm_init+0x288>)
20025148:	680b      	ldr	r3, [r1, #0]
2002514a:	b2a2      	uxth	r2, r4
2002514c:	4283      	cmp	r3, r0
2002514e:	4b67      	ldr	r3, [pc, #412]	@ (200252ec <sif_bbm_init+0x27c>)
20025150:	d11f      	bne.n	20025192 <sif_bbm_init+0x122>
20025152:	f991 1007 	ldrsb.w	r1, [r1, #7]
20025156:	2900      	cmp	r1, #0
20025158:	bfb5      	itete	lt
2002515a:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
2002515e:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
20025162:	808a      	strhlt	r2, [r1, #4]
20025164:	3601      	addge	r6, #1
20025166:	bfb8      	it	lt
20025168:	3701      	addlt	r7, #1
2002516a:	eb06 0208 	add.w	r2, r6, r8
2002516e:	443a      	add	r2, r7
20025170:	2a03      	cmp	r2, #3
20025172:	ddcd      	ble.n	20025110 <sif_bbm_init+0xa0>
20025174:	2e00      	cmp	r6, #0
20025176:	f000 8081 	beq.w	2002527c <sif_bbm_init+0x20c>
2002517a:	2f00      	cmp	r7, #0
2002517c:	d07e      	beq.n	2002527c <sif_bbm_init+0x20c>
2002517e:	2e01      	cmp	r6, #1
20025180:	d001      	beq.n	20025186 <sif_bbm_init+0x116>
20025182:	2f01      	cmp	r7, #1
20025184:	d11e      	bne.n	200251c4 <sif_bbm_init+0x154>
20025186:	8819      	ldrh	r1, [r3, #0]
20025188:	891a      	ldrh	r2, [r3, #8]
2002518a:	b981      	cbnz	r1, 200251ae <sif_bbm_init+0x13e>
2002518c:	801a      	strh	r2, [r3, #0]
2002518e:	895a      	ldrh	r2, [r3, #10]
20025190:	e013      	b.n	200251ba <sif_bbm_init+0x14a>
20025192:	f108 0104 	add.w	r1, r8, #4
20025196:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
2002519a:	f108 0801 	add.w	r8, r8, #1
2002519e:	e7e4      	b.n	2002516a <sif_bbm_init+0xfa>
200251a0:	4b4d      	ldr	r3, [pc, #308]	@ (200252d8 <sif_bbm_init+0x268>)
200251a2:	681b      	ldr	r3, [r3, #0]
200251a4:	2b00      	cmp	r3, #0
200251a6:	d0b3      	beq.n	20025110 <sif_bbm_init+0xa0>
200251a8:	4854      	ldr	r0, [pc, #336]	@ (200252fc <sif_bbm_init+0x28c>)
200251aa:	1c61      	adds	r1, r4, #1
200251ac:	e7af      	b.n	2002510e <sif_bbm_init+0x9e>
200251ae:	8859      	ldrh	r1, [r3, #2]
200251b0:	b909      	cbnz	r1, 200251b6 <sif_bbm_init+0x146>
200251b2:	805a      	strh	r2, [r3, #2]
200251b4:	e7eb      	b.n	2002518e <sif_bbm_init+0x11e>
200251b6:	2a00      	cmp	r2, #0
200251b8:	d0e9      	beq.n	2002518e <sif_bbm_init+0x11e>
200251ba:	8899      	ldrh	r1, [r3, #4]
200251bc:	2900      	cmp	r1, #0
200251be:	d158      	bne.n	20025272 <sif_bbm_init+0x202>
200251c0:	809a      	strh	r2, [r3, #4]
200251c2:	2502      	movs	r5, #2
200251c4:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 200252d8 <sif_bbm_init+0x268>
200251c8:	f8d9 4000 	ldr.w	r4, [r9]
200251cc:	b124      	cbz	r4, 200251d8 <sif_bbm_init+0x168>
200251ce:	4643      	mov	r3, r8
200251d0:	463a      	mov	r2, r7
200251d2:	4631      	mov	r1, r6
200251d4:	484a      	ldr	r0, [pc, #296]	@ (20025300 <sif_bbm_init+0x290>)
200251d6:	47a0      	blx	r4
200251d8:	f8d9 3000 	ldr.w	r3, [r9]
200251dc:	b113      	cbz	r3, 200251e4 <sif_bbm_init+0x174>
200251de:	4629      	mov	r1, r5
200251e0:	4848      	ldr	r0, [pc, #288]	@ (20025304 <sif_bbm_init+0x294>)
200251e2:	4798      	blx	r3
200251e4:	f035 0002 	bics.w	r0, r5, #2
200251e8:	d164      	bne.n	200252b4 <sif_bbm_init+0x244>
200251ea:	f7ff fccb 	bl	20024b84 <bbm_get_map_table>
200251ee:	4605      	mov	r5, r0
200251f0:	2001      	movs	r0, #1
200251f2:	f7ff fcc7 	bl	20024b84 <bbm_get_map_table>
200251f6:	f8d9 6000 	ldr.w	r6, [r9]
200251fa:	4604      	mov	r4, r0
200251fc:	b13e      	cbz	r6, 2002520e <sif_bbm_init+0x19e>
200251fe:	4a3b      	ldr	r2, [pc, #236]	@ (200252ec <sif_bbm_init+0x27c>)
20025200:	4629      	mov	r1, r5
20025202:	8a53      	ldrh	r3, [r2, #18]
20025204:	9300      	str	r3, [sp, #0]
20025206:	8a12      	ldrh	r2, [r2, #16]
20025208:	4603      	mov	r3, r0
2002520a:	483f      	ldr	r0, [pc, #252]	@ (20025308 <sif_bbm_init+0x298>)
2002520c:	47b0      	blx	r6
2002520e:	42a5      	cmp	r5, r4
20025210:	4c37      	ldr	r4, [pc, #220]	@ (200252f0 <sif_bbm_init+0x280>)
20025212:	dd35      	ble.n	20025280 <sif_bbm_init+0x210>
20025214:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025218:	4621      	mov	r1, r4
2002521a:	18a0      	adds	r0, r4, r2
2002521c:	f000 fd91 	bl	20025d42 <memcpy>
20025220:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025224:	2110      	movs	r1, #16
20025226:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
2002522a:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
2002522e:	f504 7002 	add.w	r0, r4, #520	@ 0x208
20025232:	f7ff fbf3 	bl	20024a1c <bbm_crc_check>
20025236:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
2002523a:	2001      	movs	r0, #1
2002523c:	4b2b      	ldr	r3, [pc, #172]	@ (200252ec <sif_bbm_init+0x27c>)
2002523e:	8a59      	ldrh	r1, [r3, #18]
20025240:	f7ff fdb8 	bl	20024db4 <bbm_write_talbe.isra.0>
20025244:	6822      	ldr	r2, [r4, #0]
20025246:	4b2c      	ldr	r3, [pc, #176]	@ (200252f8 <sif_bbm_init+0x288>)
20025248:	429a      	cmp	r2, r3
2002524a:	d12d      	bne.n	200252a8 <sif_bbm_init+0x238>
2002524c:	4828      	ldr	r0, [pc, #160]	@ (200252f0 <sif_bbm_init+0x280>)
2002524e:	f7ff fb95 	bl	2002497c <bbm_map_check.part.0>
20025252:	f8d9 4000 	ldr.w	r4, [r9]
20025256:	b12c      	cbz	r4, 20025264 <sif_bbm_init+0x1f4>
20025258:	4b2c      	ldr	r3, [pc, #176]	@ (2002530c <sif_bbm_init+0x29c>)
2002525a:	4924      	ldr	r1, [pc, #144]	@ (200252ec <sif_bbm_init+0x27c>)
2002525c:	482c      	ldr	r0, [pc, #176]	@ (20025310 <sif_bbm_init+0x2a0>)
2002525e:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
20025262:	47a0      	blx	r4
20025264:	f8d9 3000 	ldr.w	r3, [r9]
20025268:	2b00      	cmp	r3, #0
2002526a:	f43f af10 	beq.w	2002508e <sif_bbm_init+0x1e>
2002526e:	4829      	ldr	r0, [pc, #164]	@ (20025314 <sif_bbm_init+0x2a4>)
20025270:	e70c      	b.n	2002508c <sif_bbm_init+0x1c>
20025272:	88d9      	ldrh	r1, [r3, #6]
20025274:	2900      	cmp	r1, #0
20025276:	d1a4      	bne.n	200251c2 <sif_bbm_init+0x152>
20025278:	80da      	strh	r2, [r3, #6]
2002527a:	e7a2      	b.n	200251c2 <sif_bbm_init+0x152>
2002527c:	2501      	movs	r5, #1
2002527e:	e7a1      	b.n	200251c4 <sif_bbm_init+0x154>
20025280:	dae0      	bge.n	20025244 <sif_bbm_init+0x1d4>
20025282:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025286:	4620      	mov	r0, r4
20025288:	18a1      	adds	r1, r4, r2
2002528a:	f000 fd5a 	bl	20025d42 <memcpy>
2002528e:	79e3      	ldrb	r3, [r4, #7]
20025290:	2110      	movs	r1, #16
20025292:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
20025296:	71e3      	strb	r3, [r4, #7]
20025298:	4620      	mov	r0, r4
2002529a:	f7ff fbbf 	bl	20024a1c <bbm_crc_check>
2002529e:	4b13      	ldr	r3, [pc, #76]	@ (200252ec <sif_bbm_init+0x27c>)
200252a0:	6120      	str	r0, [r4, #16]
200252a2:	8a19      	ldrh	r1, [r3, #16]
200252a4:	2000      	movs	r0, #0
200252a6:	e7cb      	b.n	20025240 <sif_bbm_init+0x1d0>
200252a8:	f8d9 3000 	ldr.w	r3, [r9]
200252ac:	b10b      	cbz	r3, 200252b2 <sif_bbm_init+0x242>
200252ae:	481a      	ldr	r0, [pc, #104]	@ (20025318 <sif_bbm_init+0x2a8>)
200252b0:	4798      	blx	r3
200252b2:	e7fe      	b.n	200252b2 <sif_bbm_init+0x242>
200252b4:	2d01      	cmp	r5, #1
200252b6:	d102      	bne.n	200252be <sif_bbm_init+0x24e>
200252b8:	f7ff fdb8 	bl	20024e2c <bbm_init_table>
200252bc:	e7c9      	b.n	20025252 <sif_bbm_init+0x1e2>
200252be:	f8d9 3000 	ldr.w	r3, [r9]
200252c2:	b11b      	cbz	r3, 200252cc <sif_bbm_init+0x25c>
200252c4:	f04f 31ff 	mov.w	r1, #4294967295
200252c8:	4814      	ldr	r0, [pc, #80]	@ (2002531c <sif_bbm_init+0x2ac>)
200252ca:	4798      	blx	r3
200252cc:	e7fe      	b.n	200252cc <sif_bbm_init+0x25c>
200252ce:	f04f 30ff 	mov.w	r0, #4294967295
200252d2:	e6dd      	b.n	20025090 <sif_bbm_init+0x20>
200252d4:	2004ca74 	.word	0x2004ca74
200252d8:	2004ca6c 	.word	0x2004ca6c
200252dc:	2002687b 	.word	0x2002687b
200252e0:	200449a0 	.word	0x200449a0
200252e4:	2004ca7c 	.word	0x2004ca7c
200252e8:	2004ca80 	.word	0x2004ca80
200252ec:	2004ce94 	.word	0x2004ce94
200252f0:	2004ca84 	.word	0x2004ca84
200252f4:	200268a9 	.word	0x200268a9
200252f8:	5366424d 	.word	0x5366424d
200252fc:	200268b5 	.word	0x200268b5
20025300:	200268d4 	.word	0x200268d4
20025304:	200268f3 	.word	0x200268f3
20025308:	20026905 	.word	0x20026905
2002530c:	2004cc8c 	.word	0x2004cc8c
20025310:	20026960 	.word	0x20026960
20025314:	20026984 	.word	0x20026984
20025318:	20026929 	.word	0x20026929
2002531c:	2002693f 	.word	0x2002693f
20025320:	2004499c 	.word	0x2004499c
20025324:	2004ca78 	.word	0x2004ca78
20025328:	2004ca70 	.word	0x2004ca70

2002532c <bbm_set_page_size>:
2002532c:	4b01      	ldr	r3, [pc, #4]	@ (20025334 <bbm_set_page_size+0x8>)
2002532e:	6018      	str	r0, [r3, #0]
20025330:	4770      	bx	lr
20025332:	bf00      	nop
20025334:	2004499c 	.word	0x2004499c

20025338 <bbm_set_blk_size>:
20025338:	4b01      	ldr	r3, [pc, #4]	@ (20025340 <bbm_set_blk_size+0x8>)
2002533a:	6018      	str	r0, [r3, #0]
2002533c:	4770      	bx	lr
2002533e:	bf00      	nop
20025340:	200449a0 	.word	0x200449a0

20025344 <sf_crypto_cmac_gen_subkey>:
20025344:	2300      	movs	r3, #0
20025346:	b530      	push	{r4, r5, lr}
20025348:	f100 0210 	add.w	r2, r0, #16
2002534c:	f101 0410 	add.w	r4, r1, #16
20025350:	f812 5d01 	ldrb.w	r5, [r2, #-1]!
20025354:	ea43 0345 	orr.w	r3, r3, r5, lsl #1
20025358:	f804 3d01 	strb.w	r3, [r4, #-1]!
2002535c:	7813      	ldrb	r3, [r2, #0]
2002535e:	4282      	cmp	r2, r0
20025360:	ea4f 13d3 	mov.w	r3, r3, lsr #7
20025364:	d1f4      	bne.n	20025350 <sf_crypto_cmac_gen_subkey+0xc>
20025366:	f992 3000 	ldrsb.w	r3, [r2]
2002536a:	2b00      	cmp	r3, #0
2002536c:	bfbe      	ittt	lt
2002536e:	7bcb      	ldrblt	r3, [r1, #15]
20025370:	f083 0387 	eorlt.w	r3, r3, #135	@ 0x87
20025374:	73cb      	strblt	r3, [r1, #15]
20025376:	bd30      	pop	{r4, r5, pc}

20025378 <sf_crypto_aes_cmac_init>:
20025378:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
2002537c:	2a20      	cmp	r2, #32
2002537e:	4604      	mov	r4, r0
20025380:	460e      	mov	r6, r1
20025382:	4615      	mov	r5, r2
20025384:	b08c      	sub	sp, #48	@ 0x30
20025386:	d12e      	bne.n	200253e6 <sf_crypto_aes_cmac_init+0x6e>
20025388:	b380      	cbz	r0, 200253ec <sf_crypto_aes_cmac_init+0x74>
2002538a:	2710      	movs	r7, #16
2002538c:	ab04      	add	r3, sp, #16
2002538e:	6001      	str	r1, [r0, #0]
20025390:	8082      	strh	r2, [r0, #4]
20025392:	2100      	movs	r1, #0
20025394:	463a      	mov	r2, r7
20025396:	4618      	mov	r0, r3
20025398:	f000 fc64 	bl	20025c64 <memset>
2002539c:	2300      	movs	r3, #0
2002539e:	f10d 0820 	add.w	r8, sp, #32
200253a2:	4629      	mov	r1, r5
200253a4:	9000      	str	r0, [sp, #0]
200253a6:	461a      	mov	r2, r3
200253a8:	4630      	mov	r0, r6
200253aa:	e9cd 7801 	strd	r7, r8, [sp, #4]
200253ae:	f000 f8da 	bl	20025566 <sf_crypto_aes_enc_sync>
200253b2:	4605      	mov	r5, r0
200253b4:	b100      	cbz	r0, 200253b8 <sf_crypto_aes_cmac_init+0x40>
200253b6:	e7fe      	b.n	200253b6 <sf_crypto_aes_cmac_init+0x3e>
200253b8:	1da6      	adds	r6, r4, #6
200253ba:	4631      	mov	r1, r6
200253bc:	4640      	mov	r0, r8
200253be:	f7ff ffc1 	bl	20025344 <sf_crypto_cmac_gen_subkey>
200253c2:	4630      	mov	r0, r6
200253c4:	f104 0116 	add.w	r1, r4, #22
200253c8:	f7ff ffbc 	bl	20025344 <sf_crypto_cmac_gen_subkey>
200253cc:	463a      	mov	r2, r7
200253ce:	4629      	mov	r1, r5
200253d0:	f104 0028 	add.w	r0, r4, #40	@ 0x28
200253d4:	f000 fc46 	bl	20025c64 <memset>
200253d8:	f240 1301 	movw	r3, #257	@ 0x101
200253dc:	8723      	strh	r3, [r4, #56]	@ 0x38
200253de:	4628      	mov	r0, r5
200253e0:	b00c      	add	sp, #48	@ 0x30
200253e2:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200253e6:	f06f 0502 	mvn.w	r5, #2
200253ea:	e7f8      	b.n	200253de <sf_crypto_aes_cmac_init+0x66>
200253ec:	f04f 35ff 	mov.w	r5, #4294967295
200253f0:	e7f5      	b.n	200253de <sf_crypto_aes_cmac_init+0x66>

200253f2 <sf_crypto_aes_cmac_calc>:
200253f2:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200253f6:	b089      	sub	sp, #36	@ 0x24
200253f8:	460f      	mov	r7, r1
200253fa:	4604      	mov	r4, r0
200253fc:	9e10      	ldr	r6, [sp, #64]	@ 0x40
200253fe:	b138      	cbz	r0, 20025410 <sf_crypto_aes_cmac_calc+0x1e>
20025400:	b136      	cbz	r6, 20025410 <sf_crypto_aes_cmac_calc+0x1e>
20025402:	f890 1039 	ldrb.w	r1, [r0, #57]	@ 0x39
20025406:	2900      	cmp	r1, #0
20025408:	f000 80aa 	beq.w	20025560 <sf_crypto_aes_cmac_calc+0x16e>
2002540c:	b11a      	cbz	r2, 20025416 <sf_crypto_aes_cmac_calc+0x24>
2002540e:	b957      	cbnz	r7, 20025426 <sf_crypto_aes_cmac_calc+0x34>
20025410:	f04f 30ff 	mov.w	r0, #4294967295
20025414:	e0a1      	b.n	2002555a <sf_crypto_aes_cmac_calc+0x168>
20025416:	f890 1038 	ldrb.w	r1, [r0, #56]	@ 0x38
2002541a:	b109      	cbz	r1, 20025420 <sf_crypto_aes_cmac_calc+0x2e>
2002541c:	2b00      	cmp	r3, #0
2002541e:	d16e      	bne.n	200254fe <sf_crypto_aes_cmac_calc+0x10c>
20025420:	f06f 0003 	mvn.w	r0, #3
20025424:	e099      	b.n	2002555a <sf_crypto_aes_cmac_calc+0x168>
20025426:	f002 000f 	and.w	r0, r2, #15
2002542a:	b973      	cbnz	r3, 2002544a <sf_crypto_aes_cmac_calc+0x58>
2002542c:	2800      	cmp	r0, #0
2002542e:	d1f7      	bne.n	20025420 <sf_crypto_aes_cmac_calc+0x2e>
20025430:	e9cd 2601 	strd	r2, r6, [sp, #4]
20025434:	9700      	str	r7, [sp, #0]
20025436:	2303      	movs	r3, #3
20025438:	88a1      	ldrh	r1, [r4, #4]
2002543a:	6820      	ldr	r0, [r4, #0]
2002543c:	f104 0228 	add.w	r2, r4, #40	@ 0x28
20025440:	f000 f891 	bl	20025566 <sf_crypto_aes_enc_sync>
20025444:	2800      	cmp	r0, #0
20025446:	d07b      	beq.n	20025540 <sf_crypto_aes_cmac_calc+0x14e>
20025448:	e7fe      	b.n	20025448 <sf_crypto_aes_cmac_calc+0x56>
2002544a:	320f      	adds	r2, #15
2002544c:	ea4f 1812 	mov.w	r8, r2, lsr #4
20025450:	f108 31ff 	add.w	r1, r8, #4294967295
20025454:	eb07 1101 	add.w	r1, r7, r1, lsl #4
20025458:	b3c0      	cbz	r0, 200254cc <sf_crypto_aes_cmac_calc+0xda>
2002545a:	f1c0 0910 	rsb	r9, r0, #16
2002545e:	fa1f f989 	uxth.w	r9, r9
20025462:	f1c9 0510 	rsb	r5, r9, #16
20025466:	462a      	mov	r2, r5
20025468:	a804      	add	r0, sp, #16
2002546a:	f000 fc6a 	bl	20025d42 <memcpy>
2002546e:	f105 0320 	add.w	r3, r5, #32
20025472:	eb0d 0203 	add.w	r2, sp, r3
20025476:	2380      	movs	r3, #128	@ 0x80
20025478:	f802 3c10 	strb.w	r3, [r2, #-16]
2002547c:	ab08      	add	r3, sp, #32
2002547e:	eba3 0209 	sub.w	r2, r3, r9
20025482:	2100      	movs	r1, #0
20025484:	2301      	movs	r3, #1
20025486:	454b      	cmp	r3, r9
20025488:	d33f      	bcc.n	2002550a <sf_crypto_aes_cmac_calc+0x118>
2002548a:	aa04      	add	r2, sp, #16
2002548c:	f104 0315 	add.w	r3, r4, #21
20025490:	f104 0025 	add.w	r0, r4, #37	@ 0x25
20025494:	7811      	ldrb	r1, [r2, #0]
20025496:	f813 5f01 	ldrb.w	r5, [r3, #1]!
2002549a:	4069      	eors	r1, r5
2002549c:	4283      	cmp	r3, r0
2002549e:	f802 1b01 	strb.w	r1, [r2], #1
200254a2:	d1f7      	bne.n	20025494 <sf_crypto_aes_cmac_calc+0xa2>
200254a4:	f1b8 0f01 	cmp.w	r8, #1
200254a8:	f104 0528 	add.w	r5, r4, #40	@ 0x28
200254ac:	d93b      	bls.n	20025526 <sf_crypto_aes_cmac_calc+0x134>
200254ae:	f108 38ff 	add.w	r8, r8, #4294967295
200254b2:	ea4f 1308 	mov.w	r3, r8, lsl #4
200254b6:	e9cd 7300 	strd	r7, r3, [sp]
200254ba:	9602      	str	r6, [sp, #8]
200254bc:	2303      	movs	r3, #3
200254be:	462a      	mov	r2, r5
200254c0:	88a1      	ldrh	r1, [r4, #4]
200254c2:	6820      	ldr	r0, [r4, #0]
200254c4:	f000 f84f 	bl	20025566 <sf_crypto_aes_enc_sync>
200254c8:	b318      	cbz	r0, 20025512 <sf_crypto_aes_cmac_calc+0x120>
200254ca:	e7fe      	b.n	200254ca <sf_crypto_aes_cmac_calc+0xd8>
200254cc:	460b      	mov	r3, r1
200254ce:	ad04      	add	r5, sp, #16
200254d0:	f101 0c10 	add.w	ip, r1, #16
200254d4:	462a      	mov	r2, r5
200254d6:	6818      	ldr	r0, [r3, #0]
200254d8:	6859      	ldr	r1, [r3, #4]
200254da:	3308      	adds	r3, #8
200254dc:	c203      	stmia	r2!, {r0, r1}
200254de:	4563      	cmp	r3, ip
200254e0:	4615      	mov	r5, r2
200254e2:	d1f7      	bne.n	200254d4 <sf_crypto_aes_cmac_calc+0xe2>
200254e4:	ab04      	add	r3, sp, #16
200254e6:	1d62      	adds	r2, r4, #5
200254e8:	f104 0015 	add.w	r0, r4, #21
200254ec:	7819      	ldrb	r1, [r3, #0]
200254ee:	f812 5f01 	ldrb.w	r5, [r2, #1]!
200254f2:	4069      	eors	r1, r5
200254f4:	4282      	cmp	r2, r0
200254f6:	f803 1b01 	strb.w	r1, [r3], #1
200254fa:	d1f7      	bne.n	200254ec <sf_crypto_aes_cmac_calc+0xfa>
200254fc:	e7d2      	b.n	200254a4 <sf_crypto_aes_cmac_calc+0xb2>
200254fe:	4615      	mov	r5, r2
20025500:	f04f 0910 	mov.w	r9, #16
20025504:	f04f 0801 	mov.w	r8, #1
20025508:	e7b1      	b.n	2002546e <sf_crypto_aes_cmac_calc+0x7c>
2002550a:	f802 1f01 	strb.w	r1, [r2, #1]!
2002550e:	3301      	adds	r3, #1
20025510:	e7b9      	b.n	20025486 <sf_crypto_aes_cmac_calc+0x94>
20025512:	4633      	mov	r3, r6
20025514:	462a      	mov	r2, r5
20025516:	f106 0110 	add.w	r1, r6, #16
2002551a:	f853 0b04 	ldr.w	r0, [r3], #4
2002551e:	428b      	cmp	r3, r1
20025520:	f842 0b04 	str.w	r0, [r2], #4
20025524:	d1f9      	bne.n	2002551a <sf_crypto_aes_cmac_calc+0x128>
20025526:	2310      	movs	r3, #16
20025528:	9301      	str	r3, [sp, #4]
2002552a:	446b      	add	r3, sp
2002552c:	9300      	str	r3, [sp, #0]
2002552e:	9602      	str	r6, [sp, #8]
20025530:	2303      	movs	r3, #3
20025532:	462a      	mov	r2, r5
20025534:	88a1      	ldrh	r1, [r4, #4]
20025536:	6820      	ldr	r0, [r4, #0]
20025538:	f000 f815 	bl	20025566 <sf_crypto_aes_enc_sync>
2002553c:	b100      	cbz	r0, 20025540 <sf_crypto_aes_cmac_calc+0x14e>
2002553e:	e7fe      	b.n	2002553e <sf_crypto_aes_cmac_calc+0x14c>
20025540:	f104 0328 	add.w	r3, r4, #40	@ 0x28
20025544:	f106 0210 	add.w	r2, r6, #16
20025548:	f856 1b04 	ldr.w	r1, [r6], #4
2002554c:	4296      	cmp	r6, r2
2002554e:	f843 1b04 	str.w	r1, [r3], #4
20025552:	d1f9      	bne.n	20025548 <sf_crypto_aes_cmac_calc+0x156>
20025554:	2000      	movs	r0, #0
20025556:	f884 0038 	strb.w	r0, [r4, #56]	@ 0x38
2002555a:	b009      	add	sp, #36	@ 0x24
2002555c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20025560:	f06f 0001 	mvn.w	r0, #1
20025564:	e7f9      	b.n	2002555a <sf_crypto_aes_cmac_calc+0x168>

20025566 <sf_crypto_aes_enc_sync>:
20025566:	b508      	push	{r3, lr}
20025568:	f7fc fa5a 	bl	20021a20 <HAL_AES_init>
2002556c:	b100      	cbz	r0, 20025570 <sf_crypto_aes_enc_sync+0xa>
2002556e:	e7fe      	b.n	2002556e <sf_crypto_aes_enc_sync+0x8>
20025570:	2001      	movs	r0, #1
20025572:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
20025576:	9902      	ldr	r1, [sp, #8]
20025578:	f7fc fa98 	bl	20021aac <HAL_AES_run>
2002557c:	b100      	cbz	r0, 20025580 <sf_crypto_aes_enc_sync+0x1a>
2002557e:	e7fe      	b.n	2002557e <sf_crypto_aes_enc_sync+0x18>
20025580:	bd08      	pop	{r3, pc}
	...

20025584 <sbrk_aligned>:
20025584:	b570      	push	{r4, r5, r6, lr}
20025586:	4e0f      	ldr	r6, [pc, #60]	@ (200255c4 <sbrk_aligned+0x40>)
20025588:	460c      	mov	r4, r1
2002558a:	4605      	mov	r5, r0
2002558c:	6831      	ldr	r1, [r6, #0]
2002558e:	b911      	cbnz	r1, 20025596 <sbrk_aligned+0x12>
20025590:	f000 fba4 	bl	20025cdc <_sbrk_r>
20025594:	6030      	str	r0, [r6, #0]
20025596:	4621      	mov	r1, r4
20025598:	4628      	mov	r0, r5
2002559a:	f000 fb9f 	bl	20025cdc <_sbrk_r>
2002559e:	1c43      	adds	r3, r0, #1
200255a0:	d103      	bne.n	200255aa <sbrk_aligned+0x26>
200255a2:	f04f 34ff 	mov.w	r4, #4294967295
200255a6:	4620      	mov	r0, r4
200255a8:	bd70      	pop	{r4, r5, r6, pc}
200255aa:	1cc4      	adds	r4, r0, #3
200255ac:	f024 0403 	bic.w	r4, r4, #3
200255b0:	42a0      	cmp	r0, r4
200255b2:	d0f8      	beq.n	200255a6 <sbrk_aligned+0x22>
200255b4:	1a21      	subs	r1, r4, r0
200255b6:	4628      	mov	r0, r5
200255b8:	f000 fb90 	bl	20025cdc <_sbrk_r>
200255bc:	3001      	adds	r0, #1
200255be:	d1f2      	bne.n	200255a6 <sbrk_aligned+0x22>
200255c0:	e7ef      	b.n	200255a2 <sbrk_aligned+0x1e>
200255c2:	bf00      	nop
200255c4:	2004ceac 	.word	0x2004ceac

200255c8 <_malloc_r>:
200255c8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200255cc:	1ccd      	adds	r5, r1, #3
200255ce:	4606      	mov	r6, r0
200255d0:	f025 0503 	bic.w	r5, r5, #3
200255d4:	3508      	adds	r5, #8
200255d6:	2d0c      	cmp	r5, #12
200255d8:	bf38      	it	cc
200255da:	250c      	movcc	r5, #12
200255dc:	2d00      	cmp	r5, #0
200255de:	db01      	blt.n	200255e4 <_malloc_r+0x1c>
200255e0:	42a9      	cmp	r1, r5
200255e2:	d904      	bls.n	200255ee <_malloc_r+0x26>
200255e4:	230c      	movs	r3, #12
200255e6:	6033      	str	r3, [r6, #0]
200255e8:	2000      	movs	r0, #0
200255ea:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200255ee:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 200256c4 <_malloc_r+0xfc>
200255f2:	f000 f869 	bl	200256c8 <__malloc_lock>
200255f6:	f8d8 3000 	ldr.w	r3, [r8]
200255fa:	461c      	mov	r4, r3
200255fc:	bb44      	cbnz	r4, 20025650 <_malloc_r+0x88>
200255fe:	4629      	mov	r1, r5
20025600:	4630      	mov	r0, r6
20025602:	f7ff ffbf 	bl	20025584 <sbrk_aligned>
20025606:	1c43      	adds	r3, r0, #1
20025608:	4604      	mov	r4, r0
2002560a:	d158      	bne.n	200256be <_malloc_r+0xf6>
2002560c:	f8d8 4000 	ldr.w	r4, [r8]
20025610:	4627      	mov	r7, r4
20025612:	2f00      	cmp	r7, #0
20025614:	d143      	bne.n	2002569e <_malloc_r+0xd6>
20025616:	2c00      	cmp	r4, #0
20025618:	d04b      	beq.n	200256b2 <_malloc_r+0xea>
2002561a:	6823      	ldr	r3, [r4, #0]
2002561c:	4639      	mov	r1, r7
2002561e:	4630      	mov	r0, r6
20025620:	eb04 0903 	add.w	r9, r4, r3
20025624:	f000 fb5a 	bl	20025cdc <_sbrk_r>
20025628:	4581      	cmp	r9, r0
2002562a:	d142      	bne.n	200256b2 <_malloc_r+0xea>
2002562c:	6821      	ldr	r1, [r4, #0]
2002562e:	4630      	mov	r0, r6
20025630:	1a6d      	subs	r5, r5, r1
20025632:	4629      	mov	r1, r5
20025634:	f7ff ffa6 	bl	20025584 <sbrk_aligned>
20025638:	3001      	adds	r0, #1
2002563a:	d03a      	beq.n	200256b2 <_malloc_r+0xea>
2002563c:	6823      	ldr	r3, [r4, #0]
2002563e:	442b      	add	r3, r5
20025640:	6023      	str	r3, [r4, #0]
20025642:	f8d8 3000 	ldr.w	r3, [r8]
20025646:	685a      	ldr	r2, [r3, #4]
20025648:	bb62      	cbnz	r2, 200256a4 <_malloc_r+0xdc>
2002564a:	f8c8 7000 	str.w	r7, [r8]
2002564e:	e00f      	b.n	20025670 <_malloc_r+0xa8>
20025650:	6822      	ldr	r2, [r4, #0]
20025652:	1b52      	subs	r2, r2, r5
20025654:	d420      	bmi.n	20025698 <_malloc_r+0xd0>
20025656:	2a0b      	cmp	r2, #11
20025658:	d917      	bls.n	2002568a <_malloc_r+0xc2>
2002565a:	1961      	adds	r1, r4, r5
2002565c:	42a3      	cmp	r3, r4
2002565e:	6025      	str	r5, [r4, #0]
20025660:	bf18      	it	ne
20025662:	6059      	strne	r1, [r3, #4]
20025664:	6863      	ldr	r3, [r4, #4]
20025666:	bf08      	it	eq
20025668:	f8c8 1000 	streq.w	r1, [r8]
2002566c:	5162      	str	r2, [r4, r5]
2002566e:	604b      	str	r3, [r1, #4]
20025670:	4630      	mov	r0, r6
20025672:	f000 f82f 	bl	200256d4 <__malloc_unlock>
20025676:	f104 000b 	add.w	r0, r4, #11
2002567a:	1d23      	adds	r3, r4, #4
2002567c:	f020 0007 	bic.w	r0, r0, #7
20025680:	1ac2      	subs	r2, r0, r3
20025682:	bf1c      	itt	ne
20025684:	1a1b      	subne	r3, r3, r0
20025686:	50a3      	strne	r3, [r4, r2]
20025688:	e7af      	b.n	200255ea <_malloc_r+0x22>
2002568a:	6862      	ldr	r2, [r4, #4]
2002568c:	42a3      	cmp	r3, r4
2002568e:	bf0c      	ite	eq
20025690:	f8c8 2000 	streq.w	r2, [r8]
20025694:	605a      	strne	r2, [r3, #4]
20025696:	e7eb      	b.n	20025670 <_malloc_r+0xa8>
20025698:	4623      	mov	r3, r4
2002569a:	6864      	ldr	r4, [r4, #4]
2002569c:	e7ae      	b.n	200255fc <_malloc_r+0x34>
2002569e:	463c      	mov	r4, r7
200256a0:	687f      	ldr	r7, [r7, #4]
200256a2:	e7b6      	b.n	20025612 <_malloc_r+0x4a>
200256a4:	461a      	mov	r2, r3
200256a6:	685b      	ldr	r3, [r3, #4]
200256a8:	42a3      	cmp	r3, r4
200256aa:	d1fb      	bne.n	200256a4 <_malloc_r+0xdc>
200256ac:	2300      	movs	r3, #0
200256ae:	6053      	str	r3, [r2, #4]
200256b0:	e7de      	b.n	20025670 <_malloc_r+0xa8>
200256b2:	230c      	movs	r3, #12
200256b4:	4630      	mov	r0, r6
200256b6:	6033      	str	r3, [r6, #0]
200256b8:	f000 f80c 	bl	200256d4 <__malloc_unlock>
200256bc:	e794      	b.n	200255e8 <_malloc_r+0x20>
200256be:	6005      	str	r5, [r0, #0]
200256c0:	e7d6      	b.n	20025670 <_malloc_r+0xa8>
200256c2:	bf00      	nop
200256c4:	2004ceb0 	.word	0x2004ceb0

200256c8 <__malloc_lock>:
200256c8:	4801      	ldr	r0, [pc, #4]	@ (200256d0 <__malloc_lock+0x8>)
200256ca:	f000 bb2a 	b.w	20025d22 <__retarget_lock_acquire_recursive>
200256ce:	bf00      	nop
200256d0:	2004cff4 	.word	0x2004cff4

200256d4 <__malloc_unlock>:
200256d4:	4801      	ldr	r0, [pc, #4]	@ (200256dc <__malloc_unlock+0x8>)
200256d6:	f000 bb25 	b.w	20025d24 <__retarget_lock_release_recursive>
200256da:	bf00      	nop
200256dc:	2004cff4 	.word	0x2004cff4

200256e0 <__sflush_r>:
200256e0:	f9b1 200c 	ldrsh.w	r2, [r1, #12]
200256e4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200256e8:	0716      	lsls	r6, r2, #28
200256ea:	4605      	mov	r5, r0
200256ec:	460c      	mov	r4, r1
200256ee:	d451      	bmi.n	20025794 <__sflush_r+0xb4>
200256f0:	684b      	ldr	r3, [r1, #4]
200256f2:	2b00      	cmp	r3, #0
200256f4:	dc02      	bgt.n	200256fc <__sflush_r+0x1c>
200256f6:	6c0b      	ldr	r3, [r1, #64]	@ 0x40
200256f8:	2b00      	cmp	r3, #0
200256fa:	dd49      	ble.n	20025790 <__sflush_r+0xb0>
200256fc:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
200256fe:	2e00      	cmp	r6, #0
20025700:	d046      	beq.n	20025790 <__sflush_r+0xb0>
20025702:	2300      	movs	r3, #0
20025704:	f412 5280 	ands.w	r2, r2, #4096	@ 0x1000
20025708:	682f      	ldr	r7, [r5, #0]
2002570a:	602b      	str	r3, [r5, #0]
2002570c:	d031      	beq.n	20025772 <__sflush_r+0x92>
2002570e:	6d62      	ldr	r2, [r4, #84]	@ 0x54
20025710:	89a3      	ldrh	r3, [r4, #12]
20025712:	0759      	lsls	r1, r3, #29
20025714:	d505      	bpl.n	20025722 <__sflush_r+0x42>
20025716:	6863      	ldr	r3, [r4, #4]
20025718:	1ad2      	subs	r2, r2, r3
2002571a:	6b63      	ldr	r3, [r4, #52]	@ 0x34
2002571c:	b10b      	cbz	r3, 20025722 <__sflush_r+0x42>
2002571e:	6c23      	ldr	r3, [r4, #64]	@ 0x40
20025720:	1ad2      	subs	r2, r2, r3
20025722:	2300      	movs	r3, #0
20025724:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025726:	6a21      	ldr	r1, [r4, #32]
20025728:	4628      	mov	r0, r5
2002572a:	47b0      	blx	r6
2002572c:	1c42      	adds	r2, r0, #1
2002572e:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025732:	d106      	bne.n	20025742 <__sflush_r+0x62>
20025734:	6829      	ldr	r1, [r5, #0]
20025736:	291d      	cmp	r1, #29
20025738:	d845      	bhi.n	200257c6 <__sflush_r+0xe6>
2002573a:	4a28      	ldr	r2, [pc, #160]	@ (200257dc <__sflush_r+0xfc>)
2002573c:	40ca      	lsrs	r2, r1
2002573e:	07d6      	lsls	r6, r2, #31
20025740:	d541      	bpl.n	200257c6 <__sflush_r+0xe6>
20025742:	2200      	movs	r2, #0
20025744:	04d9      	lsls	r1, r3, #19
20025746:	6062      	str	r2, [r4, #4]
20025748:	6922      	ldr	r2, [r4, #16]
2002574a:	6022      	str	r2, [r4, #0]
2002574c:	d504      	bpl.n	20025758 <__sflush_r+0x78>
2002574e:	1c42      	adds	r2, r0, #1
20025750:	d101      	bne.n	20025756 <__sflush_r+0x76>
20025752:	682b      	ldr	r3, [r5, #0]
20025754:	b903      	cbnz	r3, 20025758 <__sflush_r+0x78>
20025756:	6560      	str	r0, [r4, #84]	@ 0x54
20025758:	6b61      	ldr	r1, [r4, #52]	@ 0x34
2002575a:	602f      	str	r7, [r5, #0]
2002575c:	b1c1      	cbz	r1, 20025790 <__sflush_r+0xb0>
2002575e:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025762:	4299      	cmp	r1, r3
20025764:	d002      	beq.n	2002576c <__sflush_r+0x8c>
20025766:	4628      	mov	r0, r5
20025768:	f000 faf8 	bl	20025d5c <_free_r>
2002576c:	2300      	movs	r3, #0
2002576e:	6363      	str	r3, [r4, #52]	@ 0x34
20025770:	e00e      	b.n	20025790 <__sflush_r+0xb0>
20025772:	2301      	movs	r3, #1
20025774:	6a21      	ldr	r1, [r4, #32]
20025776:	4628      	mov	r0, r5
20025778:	47b0      	blx	r6
2002577a:	4602      	mov	r2, r0
2002577c:	1c50      	adds	r0, r2, #1
2002577e:	d1c7      	bne.n	20025710 <__sflush_r+0x30>
20025780:	682b      	ldr	r3, [r5, #0]
20025782:	2b00      	cmp	r3, #0
20025784:	d0c4      	beq.n	20025710 <__sflush_r+0x30>
20025786:	2b1d      	cmp	r3, #29
20025788:	d001      	beq.n	2002578e <__sflush_r+0xae>
2002578a:	2b16      	cmp	r3, #22
2002578c:	d119      	bne.n	200257c2 <__sflush_r+0xe2>
2002578e:	602f      	str	r7, [r5, #0]
20025790:	2000      	movs	r0, #0
20025792:	e01d      	b.n	200257d0 <__sflush_r+0xf0>
20025794:	690f      	ldr	r7, [r1, #16]
20025796:	2f00      	cmp	r7, #0
20025798:	d0fa      	beq.n	20025790 <__sflush_r+0xb0>
2002579a:	0793      	lsls	r3, r2, #30
2002579c:	680e      	ldr	r6, [r1, #0]
2002579e:	600f      	str	r7, [r1, #0]
200257a0:	bf0c      	ite	eq
200257a2:	694b      	ldreq	r3, [r1, #20]
200257a4:	2300      	movne	r3, #0
200257a6:	eba6 0807 	sub.w	r8, r6, r7
200257aa:	608b      	str	r3, [r1, #8]
200257ac:	f1b8 0f00 	cmp.w	r8, #0
200257b0:	ddee      	ble.n	20025790 <__sflush_r+0xb0>
200257b2:	4643      	mov	r3, r8
200257b4:	463a      	mov	r2, r7
200257b6:	6a21      	ldr	r1, [r4, #32]
200257b8:	4628      	mov	r0, r5
200257ba:	6aa6      	ldr	r6, [r4, #40]	@ 0x28
200257bc:	47b0      	blx	r6
200257be:	2800      	cmp	r0, #0
200257c0:	dc08      	bgt.n	200257d4 <__sflush_r+0xf4>
200257c2:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200257c6:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
200257ca:	f04f 30ff 	mov.w	r0, #4294967295
200257ce:	81a3      	strh	r3, [r4, #12]
200257d0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200257d4:	4407      	add	r7, r0
200257d6:	eba8 0800 	sub.w	r8, r8, r0
200257da:	e7e7      	b.n	200257ac <__sflush_r+0xcc>
200257dc:	20400001 	.word	0x20400001

200257e0 <_fflush_r>:
200257e0:	b538      	push	{r3, r4, r5, lr}
200257e2:	690b      	ldr	r3, [r1, #16]
200257e4:	4605      	mov	r5, r0
200257e6:	460c      	mov	r4, r1
200257e8:	b913      	cbnz	r3, 200257f0 <_fflush_r+0x10>
200257ea:	2500      	movs	r5, #0
200257ec:	4628      	mov	r0, r5
200257ee:	bd38      	pop	{r3, r4, r5, pc}
200257f0:	b118      	cbz	r0, 200257fa <_fflush_r+0x1a>
200257f2:	6a03      	ldr	r3, [r0, #32]
200257f4:	b90b      	cbnz	r3, 200257fa <_fflush_r+0x1a>
200257f6:	f000 f8a9 	bl	2002594c <__sinit>
200257fa:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200257fe:	2b00      	cmp	r3, #0
20025800:	d0f3      	beq.n	200257ea <_fflush_r+0xa>
20025802:	6e62      	ldr	r2, [r4, #100]	@ 0x64
20025804:	07d0      	lsls	r0, r2, #31
20025806:	d404      	bmi.n	20025812 <_fflush_r+0x32>
20025808:	0599      	lsls	r1, r3, #22
2002580a:	d402      	bmi.n	20025812 <_fflush_r+0x32>
2002580c:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002580e:	f000 fa88 	bl	20025d22 <__retarget_lock_acquire_recursive>
20025812:	4628      	mov	r0, r5
20025814:	4621      	mov	r1, r4
20025816:	f7ff ff63 	bl	200256e0 <__sflush_r>
2002581a:	6e63      	ldr	r3, [r4, #100]	@ 0x64
2002581c:	4605      	mov	r5, r0
2002581e:	07da      	lsls	r2, r3, #31
20025820:	d4e4      	bmi.n	200257ec <_fflush_r+0xc>
20025822:	89a3      	ldrh	r3, [r4, #12]
20025824:	059b      	lsls	r3, r3, #22
20025826:	d4e1      	bmi.n	200257ec <_fflush_r+0xc>
20025828:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002582a:	f000 fa7b 	bl	20025d24 <__retarget_lock_release_recursive>
2002582e:	e7dd      	b.n	200257ec <_fflush_r+0xc>

20025830 <std>:
20025830:	2300      	movs	r3, #0
20025832:	b510      	push	{r4, lr}
20025834:	4604      	mov	r4, r0
20025836:	6083      	str	r3, [r0, #8]
20025838:	8181      	strh	r1, [r0, #12]
2002583a:	4619      	mov	r1, r3
2002583c:	6643      	str	r3, [r0, #100]	@ 0x64
2002583e:	81c2      	strh	r2, [r0, #14]
20025840:	2208      	movs	r2, #8
20025842:	6183      	str	r3, [r0, #24]
20025844:	e9c0 3300 	strd	r3, r3, [r0]
20025848:	e9c0 3304 	strd	r3, r3, [r0, #16]
2002584c:	305c      	adds	r0, #92	@ 0x5c
2002584e:	f000 fa09 	bl	20025c64 <memset>
20025852:	4b0d      	ldr	r3, [pc, #52]	@ (20025888 <std+0x58>)
20025854:	6224      	str	r4, [r4, #32]
20025856:	6263      	str	r3, [r4, #36]	@ 0x24
20025858:	4b0c      	ldr	r3, [pc, #48]	@ (2002588c <std+0x5c>)
2002585a:	62a3      	str	r3, [r4, #40]	@ 0x28
2002585c:	4b0c      	ldr	r3, [pc, #48]	@ (20025890 <std+0x60>)
2002585e:	62e3      	str	r3, [r4, #44]	@ 0x2c
20025860:	4b0c      	ldr	r3, [pc, #48]	@ (20025894 <std+0x64>)
20025862:	6323      	str	r3, [r4, #48]	@ 0x30
20025864:	4b0c      	ldr	r3, [pc, #48]	@ (20025898 <std+0x68>)
20025866:	429c      	cmp	r4, r3
20025868:	d006      	beq.n	20025878 <std+0x48>
2002586a:	f103 0268 	add.w	r2, r3, #104	@ 0x68
2002586e:	4294      	cmp	r4, r2
20025870:	d002      	beq.n	20025878 <std+0x48>
20025872:	33d0      	adds	r3, #208	@ 0xd0
20025874:	429c      	cmp	r4, r3
20025876:	d105      	bne.n	20025884 <std+0x54>
20025878:	f104 0058 	add.w	r0, r4, #88	@ 0x58
2002587c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025880:	f000 ba4e 	b.w	20025d20 <__retarget_lock_init_recursive>
20025884:	bd10      	pop	{r4, pc}
20025886:	bf00      	nop
20025888:	20025a99 	.word	0x20025a99
2002588c:	20025abb 	.word	0x20025abb
20025890:	20025af3 	.word	0x20025af3
20025894:	20025b19 	.word	0x20025b19
20025898:	2004ceb4 	.word	0x2004ceb4

2002589c <stdio_exit_handler>:
2002589c:	4a02      	ldr	r2, [pc, #8]	@ (200258a8 <stdio_exit_handler+0xc>)
2002589e:	4903      	ldr	r1, [pc, #12]	@ (200258ac <stdio_exit_handler+0x10>)
200258a0:	4803      	ldr	r0, [pc, #12]	@ (200258b0 <stdio_exit_handler+0x14>)
200258a2:	f000 b86b 	b.w	2002597c <_fwalk_sglue>
200258a6:	bf00      	nop
200258a8:	200449a4 	.word	0x200449a4
200258ac:	200257e1 	.word	0x200257e1
200258b0:	200449b4 	.word	0x200449b4

200258b4 <cleanup_stdio>:
200258b4:	6841      	ldr	r1, [r0, #4]
200258b6:	4b0c      	ldr	r3, [pc, #48]	@ (200258e8 <cleanup_stdio+0x34>)
200258b8:	4299      	cmp	r1, r3
200258ba:	b510      	push	{r4, lr}
200258bc:	4604      	mov	r4, r0
200258be:	d001      	beq.n	200258c4 <cleanup_stdio+0x10>
200258c0:	f7ff ff8e 	bl	200257e0 <_fflush_r>
200258c4:	68a1      	ldr	r1, [r4, #8]
200258c6:	4b09      	ldr	r3, [pc, #36]	@ (200258ec <cleanup_stdio+0x38>)
200258c8:	4299      	cmp	r1, r3
200258ca:	d002      	beq.n	200258d2 <cleanup_stdio+0x1e>
200258cc:	4620      	mov	r0, r4
200258ce:	f7ff ff87 	bl	200257e0 <_fflush_r>
200258d2:	68e1      	ldr	r1, [r4, #12]
200258d4:	4b06      	ldr	r3, [pc, #24]	@ (200258f0 <cleanup_stdio+0x3c>)
200258d6:	4299      	cmp	r1, r3
200258d8:	d004      	beq.n	200258e4 <cleanup_stdio+0x30>
200258da:	4620      	mov	r0, r4
200258dc:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200258e0:	f7ff bf7e 	b.w	200257e0 <_fflush_r>
200258e4:	bd10      	pop	{r4, pc}
200258e6:	bf00      	nop
200258e8:	2004ceb4 	.word	0x2004ceb4
200258ec:	2004cf1c 	.word	0x2004cf1c
200258f0:	2004cf84 	.word	0x2004cf84

200258f4 <global_stdio_init.part.0>:
200258f4:	4b0c      	ldr	r3, [pc, #48]	@ (20025928 <global_stdio_init.part.0+0x34>)
200258f6:	2104      	movs	r1, #4
200258f8:	4a0c      	ldr	r2, [pc, #48]	@ (2002592c <global_stdio_init.part.0+0x38>)
200258fa:	480d      	ldr	r0, [pc, #52]	@ (20025930 <global_stdio_init.part.0+0x3c>)
200258fc:	b510      	push	{r4, lr}
200258fe:	601a      	str	r2, [r3, #0]
20025900:	2200      	movs	r2, #0
20025902:	f7ff ff95 	bl	20025830 <std>
20025906:	4b0a      	ldr	r3, [pc, #40]	@ (20025930 <global_stdio_init.part.0+0x3c>)
20025908:	2201      	movs	r2, #1
2002590a:	2109      	movs	r1, #9
2002590c:	461c      	mov	r4, r3
2002590e:	f103 0068 	add.w	r0, r3, #104	@ 0x68
20025912:	f7ff ff8d 	bl	20025830 <std>
20025916:	2202      	movs	r2, #2
20025918:	f104 00d0 	add.w	r0, r4, #208	@ 0xd0
2002591c:	2112      	movs	r1, #18
2002591e:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025922:	f7ff bf85 	b.w	20025830 <std>
20025926:	bf00      	nop
20025928:	2004cfec 	.word	0x2004cfec
2002592c:	2002589d 	.word	0x2002589d
20025930:	2004ceb4 	.word	0x2004ceb4

20025934 <__sfp_lock_acquire>:
20025934:	4801      	ldr	r0, [pc, #4]	@ (2002593c <__sfp_lock_acquire+0x8>)
20025936:	f000 b9f4 	b.w	20025d22 <__retarget_lock_acquire_recursive>
2002593a:	bf00      	nop
2002593c:	2004cff5 	.word	0x2004cff5

20025940 <__sfp_lock_release>:
20025940:	4801      	ldr	r0, [pc, #4]	@ (20025948 <__sfp_lock_release+0x8>)
20025942:	f000 b9ef 	b.w	20025d24 <__retarget_lock_release_recursive>
20025946:	bf00      	nop
20025948:	2004cff5 	.word	0x2004cff5

2002594c <__sinit>:
2002594c:	b510      	push	{r4, lr}
2002594e:	4604      	mov	r4, r0
20025950:	f7ff fff0 	bl	20025934 <__sfp_lock_acquire>
20025954:	6a23      	ldr	r3, [r4, #32]
20025956:	b11b      	cbz	r3, 20025960 <__sinit+0x14>
20025958:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002595c:	f7ff bff0 	b.w	20025940 <__sfp_lock_release>
20025960:	4b04      	ldr	r3, [pc, #16]	@ (20025974 <__sinit+0x28>)
20025962:	6223      	str	r3, [r4, #32]
20025964:	4b04      	ldr	r3, [pc, #16]	@ (20025978 <__sinit+0x2c>)
20025966:	681b      	ldr	r3, [r3, #0]
20025968:	2b00      	cmp	r3, #0
2002596a:	d1f5      	bne.n	20025958 <__sinit+0xc>
2002596c:	f7ff ffc2 	bl	200258f4 <global_stdio_init.part.0>
20025970:	e7f2      	b.n	20025958 <__sinit+0xc>
20025972:	bf00      	nop
20025974:	200258b5 	.word	0x200258b5
20025978:	2004cfec 	.word	0x2004cfec

2002597c <_fwalk_sglue>:
2002597c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025980:	4607      	mov	r7, r0
20025982:	4688      	mov	r8, r1
20025984:	4614      	mov	r4, r2
20025986:	2600      	movs	r6, #0
20025988:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
2002598c:	f1b9 0901 	subs.w	r9, r9, #1
20025990:	d505      	bpl.n	2002599e <_fwalk_sglue+0x22>
20025992:	6824      	ldr	r4, [r4, #0]
20025994:	2c00      	cmp	r4, #0
20025996:	d1f7      	bne.n	20025988 <_fwalk_sglue+0xc>
20025998:	4630      	mov	r0, r6
2002599a:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002599e:	89ab      	ldrh	r3, [r5, #12]
200259a0:	2b01      	cmp	r3, #1
200259a2:	d907      	bls.n	200259b4 <_fwalk_sglue+0x38>
200259a4:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
200259a8:	3301      	adds	r3, #1
200259aa:	d003      	beq.n	200259b4 <_fwalk_sglue+0x38>
200259ac:	4629      	mov	r1, r5
200259ae:	4638      	mov	r0, r7
200259b0:	47c0      	blx	r8
200259b2:	4306      	orrs	r6, r0
200259b4:	3568      	adds	r5, #104	@ 0x68
200259b6:	e7e9      	b.n	2002598c <_fwalk_sglue+0x10>

200259b8 <iprintf>:
200259b8:	b40f      	push	{r0, r1, r2, r3}
200259ba:	b507      	push	{r0, r1, r2, lr}
200259bc:	4906      	ldr	r1, [pc, #24]	@ (200259d8 <iprintf+0x20>)
200259be:	ab04      	add	r3, sp, #16
200259c0:	6808      	ldr	r0, [r1, #0]
200259c2:	f853 2b04 	ldr.w	r2, [r3], #4
200259c6:	6881      	ldr	r1, [r0, #8]
200259c8:	9301      	str	r3, [sp, #4]
200259ca:	f000 fa3b 	bl	20025e44 <_vfiprintf_r>
200259ce:	b003      	add	sp, #12
200259d0:	f85d eb04 	ldr.w	lr, [sp], #4
200259d4:	b004      	add	sp, #16
200259d6:	4770      	bx	lr
200259d8:	200449b0 	.word	0x200449b0

200259dc <_puts_r>:
200259dc:	6a03      	ldr	r3, [r0, #32]
200259de:	b570      	push	{r4, r5, r6, lr}
200259e0:	4605      	mov	r5, r0
200259e2:	460e      	mov	r6, r1
200259e4:	6884      	ldr	r4, [r0, #8]
200259e6:	b90b      	cbnz	r3, 200259ec <_puts_r+0x10>
200259e8:	f7ff ffb0 	bl	2002594c <__sinit>
200259ec:	6e63      	ldr	r3, [r4, #100]	@ 0x64
200259ee:	07db      	lsls	r3, r3, #31
200259f0:	d405      	bmi.n	200259fe <_puts_r+0x22>
200259f2:	89a3      	ldrh	r3, [r4, #12]
200259f4:	0598      	lsls	r0, r3, #22
200259f6:	d402      	bmi.n	200259fe <_puts_r+0x22>
200259f8:	6da0      	ldr	r0, [r4, #88]	@ 0x58
200259fa:	f000 f992 	bl	20025d22 <__retarget_lock_acquire_recursive>
200259fe:	89a3      	ldrh	r3, [r4, #12]
20025a00:	0719      	lsls	r1, r3, #28
20025a02:	d502      	bpl.n	20025a0a <_puts_r+0x2e>
20025a04:	6923      	ldr	r3, [r4, #16]
20025a06:	2b00      	cmp	r3, #0
20025a08:	d135      	bne.n	20025a76 <_puts_r+0x9a>
20025a0a:	4621      	mov	r1, r4
20025a0c:	4628      	mov	r0, r5
20025a0e:	f000 f8c5 	bl	20025b9c <__swsetup_r>
20025a12:	b380      	cbz	r0, 20025a76 <_puts_r+0x9a>
20025a14:	f04f 35ff 	mov.w	r5, #4294967295
20025a18:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025a1a:	07da      	lsls	r2, r3, #31
20025a1c:	d405      	bmi.n	20025a2a <_puts_r+0x4e>
20025a1e:	89a3      	ldrh	r3, [r4, #12]
20025a20:	059b      	lsls	r3, r3, #22
20025a22:	d402      	bmi.n	20025a2a <_puts_r+0x4e>
20025a24:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025a26:	f000 f97d 	bl	20025d24 <__retarget_lock_release_recursive>
20025a2a:	4628      	mov	r0, r5
20025a2c:	bd70      	pop	{r4, r5, r6, pc}
20025a2e:	2b00      	cmp	r3, #0
20025a30:	da04      	bge.n	20025a3c <_puts_r+0x60>
20025a32:	69a2      	ldr	r2, [r4, #24]
20025a34:	4293      	cmp	r3, r2
20025a36:	db17      	blt.n	20025a68 <_puts_r+0x8c>
20025a38:	290a      	cmp	r1, #10
20025a3a:	d015      	beq.n	20025a68 <_puts_r+0x8c>
20025a3c:	6823      	ldr	r3, [r4, #0]
20025a3e:	1c5a      	adds	r2, r3, #1
20025a40:	6022      	str	r2, [r4, #0]
20025a42:	7019      	strb	r1, [r3, #0]
20025a44:	68a3      	ldr	r3, [r4, #8]
20025a46:	f816 1f01 	ldrb.w	r1, [r6, #1]!
20025a4a:	3b01      	subs	r3, #1
20025a4c:	60a3      	str	r3, [r4, #8]
20025a4e:	2900      	cmp	r1, #0
20025a50:	d1ed      	bne.n	20025a2e <_puts_r+0x52>
20025a52:	2b00      	cmp	r3, #0
20025a54:	da11      	bge.n	20025a7a <_puts_r+0x9e>
20025a56:	4622      	mov	r2, r4
20025a58:	210a      	movs	r1, #10
20025a5a:	4628      	mov	r0, r5
20025a5c:	f000 f860 	bl	20025b20 <__swbuf_r>
20025a60:	3001      	adds	r0, #1
20025a62:	d0d7      	beq.n	20025a14 <_puts_r+0x38>
20025a64:	250a      	movs	r5, #10
20025a66:	e7d7      	b.n	20025a18 <_puts_r+0x3c>
20025a68:	4622      	mov	r2, r4
20025a6a:	4628      	mov	r0, r5
20025a6c:	f000 f858 	bl	20025b20 <__swbuf_r>
20025a70:	3001      	adds	r0, #1
20025a72:	d1e7      	bne.n	20025a44 <_puts_r+0x68>
20025a74:	e7ce      	b.n	20025a14 <_puts_r+0x38>
20025a76:	3e01      	subs	r6, #1
20025a78:	e7e4      	b.n	20025a44 <_puts_r+0x68>
20025a7a:	6823      	ldr	r3, [r4, #0]
20025a7c:	1c5a      	adds	r2, r3, #1
20025a7e:	6022      	str	r2, [r4, #0]
20025a80:	220a      	movs	r2, #10
20025a82:	701a      	strb	r2, [r3, #0]
20025a84:	e7ee      	b.n	20025a64 <_puts_r+0x88>
	...

20025a88 <puts>:
20025a88:	4b02      	ldr	r3, [pc, #8]	@ (20025a94 <puts+0xc>)
20025a8a:	4601      	mov	r1, r0
20025a8c:	6818      	ldr	r0, [r3, #0]
20025a8e:	f7ff bfa5 	b.w	200259dc <_puts_r>
20025a92:	bf00      	nop
20025a94:	200449b0 	.word	0x200449b0

20025a98 <__sread>:
20025a98:	b510      	push	{r4, lr}
20025a9a:	460c      	mov	r4, r1
20025a9c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025aa0:	f000 f90a 	bl	20025cb8 <_read_r>
20025aa4:	2800      	cmp	r0, #0
20025aa6:	bfab      	itete	ge
20025aa8:	6d63      	ldrge	r3, [r4, #84]	@ 0x54
20025aaa:	89a3      	ldrhlt	r3, [r4, #12]
20025aac:	181b      	addge	r3, r3, r0
20025aae:	f423 5380 	biclt.w	r3, r3, #4096	@ 0x1000
20025ab2:	bfac      	ite	ge
20025ab4:	6563      	strge	r3, [r4, #84]	@ 0x54
20025ab6:	81a3      	strhlt	r3, [r4, #12]
20025ab8:	bd10      	pop	{r4, pc}

20025aba <__swrite>:
20025aba:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025abe:	461f      	mov	r7, r3
20025ac0:	898b      	ldrh	r3, [r1, #12]
20025ac2:	4605      	mov	r5, r0
20025ac4:	460c      	mov	r4, r1
20025ac6:	05db      	lsls	r3, r3, #23
20025ac8:	4616      	mov	r6, r2
20025aca:	d505      	bpl.n	20025ad8 <__swrite+0x1e>
20025acc:	2302      	movs	r3, #2
20025ace:	2200      	movs	r2, #0
20025ad0:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025ad4:	f000 f8de 	bl	20025c94 <_lseek_r>
20025ad8:	89a3      	ldrh	r3, [r4, #12]
20025ada:	4632      	mov	r2, r6
20025adc:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20025ae0:	4628      	mov	r0, r5
20025ae2:	f423 5380 	bic.w	r3, r3, #4096	@ 0x1000
20025ae6:	81a3      	strh	r3, [r4, #12]
20025ae8:	463b      	mov	r3, r7
20025aea:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
20025aee:	f000 b905 	b.w	20025cfc <_write_r>

20025af2 <__sseek>:
20025af2:	b510      	push	{r4, lr}
20025af4:	460c      	mov	r4, r1
20025af6:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025afa:	f000 f8cb 	bl	20025c94 <_lseek_r>
20025afe:	1c42      	adds	r2, r0, #1
20025b00:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025b04:	bf15      	itete	ne
20025b06:	6560      	strne	r0, [r4, #84]	@ 0x54
20025b08:	f423 5380 	biceq.w	r3, r3, #4096	@ 0x1000
20025b0c:	f443 5380 	orrne.w	r3, r3, #4096	@ 0x1000
20025b10:	81a3      	strheq	r3, [r4, #12]
20025b12:	bf18      	it	ne
20025b14:	81a3      	strhne	r3, [r4, #12]
20025b16:	bd10      	pop	{r4, pc}

20025b18 <__sclose>:
20025b18:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025b1c:	f000 b8aa 	b.w	20025c74 <_close_r>

20025b20 <__swbuf_r>:
20025b20:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025b22:	460e      	mov	r6, r1
20025b24:	4614      	mov	r4, r2
20025b26:	4605      	mov	r5, r0
20025b28:	b118      	cbz	r0, 20025b32 <__swbuf_r+0x12>
20025b2a:	6a03      	ldr	r3, [r0, #32]
20025b2c:	b90b      	cbnz	r3, 20025b32 <__swbuf_r+0x12>
20025b2e:	f7ff ff0d 	bl	2002594c <__sinit>
20025b32:	69a3      	ldr	r3, [r4, #24]
20025b34:	60a3      	str	r3, [r4, #8]
20025b36:	89a3      	ldrh	r3, [r4, #12]
20025b38:	071a      	lsls	r2, r3, #28
20025b3a:	d501      	bpl.n	20025b40 <__swbuf_r+0x20>
20025b3c:	6923      	ldr	r3, [r4, #16]
20025b3e:	b943      	cbnz	r3, 20025b52 <__swbuf_r+0x32>
20025b40:	4621      	mov	r1, r4
20025b42:	4628      	mov	r0, r5
20025b44:	f000 f82a 	bl	20025b9c <__swsetup_r>
20025b48:	b118      	cbz	r0, 20025b52 <__swbuf_r+0x32>
20025b4a:	f04f 37ff 	mov.w	r7, #4294967295
20025b4e:	4638      	mov	r0, r7
20025b50:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20025b52:	6823      	ldr	r3, [r4, #0]
20025b54:	b2f6      	uxtb	r6, r6
20025b56:	6922      	ldr	r2, [r4, #16]
20025b58:	4637      	mov	r7, r6
20025b5a:	1a98      	subs	r0, r3, r2
20025b5c:	6963      	ldr	r3, [r4, #20]
20025b5e:	4283      	cmp	r3, r0
20025b60:	dc05      	bgt.n	20025b6e <__swbuf_r+0x4e>
20025b62:	4621      	mov	r1, r4
20025b64:	4628      	mov	r0, r5
20025b66:	f7ff fe3b 	bl	200257e0 <_fflush_r>
20025b6a:	2800      	cmp	r0, #0
20025b6c:	d1ed      	bne.n	20025b4a <__swbuf_r+0x2a>
20025b6e:	68a3      	ldr	r3, [r4, #8]
20025b70:	3b01      	subs	r3, #1
20025b72:	60a3      	str	r3, [r4, #8]
20025b74:	6823      	ldr	r3, [r4, #0]
20025b76:	1c5a      	adds	r2, r3, #1
20025b78:	6022      	str	r2, [r4, #0]
20025b7a:	701e      	strb	r6, [r3, #0]
20025b7c:	1c43      	adds	r3, r0, #1
20025b7e:	6962      	ldr	r2, [r4, #20]
20025b80:	429a      	cmp	r2, r3
20025b82:	d004      	beq.n	20025b8e <__swbuf_r+0x6e>
20025b84:	89a3      	ldrh	r3, [r4, #12]
20025b86:	07db      	lsls	r3, r3, #31
20025b88:	d5e1      	bpl.n	20025b4e <__swbuf_r+0x2e>
20025b8a:	2e0a      	cmp	r6, #10
20025b8c:	d1df      	bne.n	20025b4e <__swbuf_r+0x2e>
20025b8e:	4621      	mov	r1, r4
20025b90:	4628      	mov	r0, r5
20025b92:	f7ff fe25 	bl	200257e0 <_fflush_r>
20025b96:	2800      	cmp	r0, #0
20025b98:	d0d9      	beq.n	20025b4e <__swbuf_r+0x2e>
20025b9a:	e7d6      	b.n	20025b4a <__swbuf_r+0x2a>

20025b9c <__swsetup_r>:
20025b9c:	b538      	push	{r3, r4, r5, lr}
20025b9e:	4b28      	ldr	r3, [pc, #160]	@ (20025c40 <__swsetup_r+0xa4>)
20025ba0:	4605      	mov	r5, r0
20025ba2:	460c      	mov	r4, r1
20025ba4:	6818      	ldr	r0, [r3, #0]
20025ba6:	b118      	cbz	r0, 20025bb0 <__swsetup_r+0x14>
20025ba8:	6a03      	ldr	r3, [r0, #32]
20025baa:	b90b      	cbnz	r3, 20025bb0 <__swsetup_r+0x14>
20025bac:	f7ff fece 	bl	2002594c <__sinit>
20025bb0:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025bb4:	071a      	lsls	r2, r3, #28
20025bb6:	d421      	bmi.n	20025bfc <__swsetup_r+0x60>
20025bb8:	06d8      	lsls	r0, r3, #27
20025bba:	d407      	bmi.n	20025bcc <__swsetup_r+0x30>
20025bbc:	2209      	movs	r2, #9
20025bbe:	602a      	str	r2, [r5, #0]
20025bc0:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
20025bc4:	f04f 30ff 	mov.w	r0, #4294967295
20025bc8:	81a3      	strh	r3, [r4, #12]
20025bca:	e030      	b.n	20025c2e <__swsetup_r+0x92>
20025bcc:	0759      	lsls	r1, r3, #29
20025bce:	d512      	bpl.n	20025bf6 <__swsetup_r+0x5a>
20025bd0:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20025bd2:	b141      	cbz	r1, 20025be6 <__swsetup_r+0x4a>
20025bd4:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025bd8:	4299      	cmp	r1, r3
20025bda:	d002      	beq.n	20025be2 <__swsetup_r+0x46>
20025bdc:	4628      	mov	r0, r5
20025bde:	f000 f8bd 	bl	20025d5c <_free_r>
20025be2:	2300      	movs	r3, #0
20025be4:	6363      	str	r3, [r4, #52]	@ 0x34
20025be6:	2200      	movs	r2, #0
20025be8:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025bec:	6062      	str	r2, [r4, #4]
20025bee:	f023 0324 	bic.w	r3, r3, #36	@ 0x24
20025bf2:	6922      	ldr	r2, [r4, #16]
20025bf4:	6022      	str	r2, [r4, #0]
20025bf6:	f043 0308 	orr.w	r3, r3, #8
20025bfa:	81a3      	strh	r3, [r4, #12]
20025bfc:	6922      	ldr	r2, [r4, #16]
20025bfe:	b93a      	cbnz	r2, 20025c10 <__swsetup_r+0x74>
20025c00:	059a      	lsls	r2, r3, #22
20025c02:	d501      	bpl.n	20025c08 <__swsetup_r+0x6c>
20025c04:	0618      	lsls	r0, r3, #24
20025c06:	d503      	bpl.n	20025c10 <__swsetup_r+0x74>
20025c08:	4621      	mov	r1, r4
20025c0a:	4628      	mov	r0, r5
20025c0c:	f000 fbe8 	bl	200263e0 <__smakebuf_r>
20025c10:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025c14:	f013 0201 	ands.w	r2, r3, #1
20025c18:	d00a      	beq.n	20025c30 <__swsetup_r+0x94>
20025c1a:	2200      	movs	r2, #0
20025c1c:	60a2      	str	r2, [r4, #8]
20025c1e:	6962      	ldr	r2, [r4, #20]
20025c20:	4252      	negs	r2, r2
20025c22:	61a2      	str	r2, [r4, #24]
20025c24:	6922      	ldr	r2, [r4, #16]
20025c26:	b942      	cbnz	r2, 20025c3a <__swsetup_r+0x9e>
20025c28:	f013 0080 	ands.w	r0, r3, #128	@ 0x80
20025c2c:	d1c8      	bne.n	20025bc0 <__swsetup_r+0x24>
20025c2e:	bd38      	pop	{r3, r4, r5, pc}
20025c30:	0799      	lsls	r1, r3, #30
20025c32:	bf58      	it	pl
20025c34:	6962      	ldrpl	r2, [r4, #20]
20025c36:	60a2      	str	r2, [r4, #8]
20025c38:	e7f4      	b.n	20025c24 <__swsetup_r+0x88>
20025c3a:	2000      	movs	r0, #0
20025c3c:	e7f7      	b.n	20025c2e <__swsetup_r+0x92>
20025c3e:	bf00      	nop
20025c40:	200449b0 	.word	0x200449b0

20025c44 <memcmp>:
20025c44:	3901      	subs	r1, #1
20025c46:	4402      	add	r2, r0
20025c48:	b510      	push	{r4, lr}
20025c4a:	4290      	cmp	r0, r2
20025c4c:	d101      	bne.n	20025c52 <memcmp+0xe>
20025c4e:	2000      	movs	r0, #0
20025c50:	e005      	b.n	20025c5e <memcmp+0x1a>
20025c52:	7803      	ldrb	r3, [r0, #0]
20025c54:	f811 4f01 	ldrb.w	r4, [r1, #1]!
20025c58:	42a3      	cmp	r3, r4
20025c5a:	d001      	beq.n	20025c60 <memcmp+0x1c>
20025c5c:	1b18      	subs	r0, r3, r4
20025c5e:	bd10      	pop	{r4, pc}
20025c60:	3001      	adds	r0, #1
20025c62:	e7f2      	b.n	20025c4a <memcmp+0x6>

20025c64 <memset>:
20025c64:	4402      	add	r2, r0
20025c66:	4603      	mov	r3, r0
20025c68:	4293      	cmp	r3, r2
20025c6a:	d100      	bne.n	20025c6e <memset+0xa>
20025c6c:	4770      	bx	lr
20025c6e:	f803 1b01 	strb.w	r1, [r3], #1
20025c72:	e7f9      	b.n	20025c68 <memset+0x4>

20025c74 <_close_r>:
20025c74:	b538      	push	{r3, r4, r5, lr}
20025c76:	2300      	movs	r3, #0
20025c78:	4d05      	ldr	r5, [pc, #20]	@ (20025c90 <_close_r+0x1c>)
20025c7a:	4604      	mov	r4, r0
20025c7c:	4608      	mov	r0, r1
20025c7e:	602b      	str	r3, [r5, #0]
20025c80:	f7fb fd0a 	bl	20021698 <_close>
20025c84:	1c43      	adds	r3, r0, #1
20025c86:	d102      	bne.n	20025c8e <_close_r+0x1a>
20025c88:	682b      	ldr	r3, [r5, #0]
20025c8a:	b103      	cbz	r3, 20025c8e <_close_r+0x1a>
20025c8c:	6023      	str	r3, [r4, #0]
20025c8e:	bd38      	pop	{r3, r4, r5, pc}
20025c90:	2004cff0 	.word	0x2004cff0

20025c94 <_lseek_r>:
20025c94:	b538      	push	{r3, r4, r5, lr}
20025c96:	4604      	mov	r4, r0
20025c98:	4d06      	ldr	r5, [pc, #24]	@ (20025cb4 <_lseek_r+0x20>)
20025c9a:	4608      	mov	r0, r1
20025c9c:	4611      	mov	r1, r2
20025c9e:	2200      	movs	r2, #0
20025ca0:	602a      	str	r2, [r5, #0]
20025ca2:	461a      	mov	r2, r3
20025ca4:	f7fb fcfb 	bl	2002169e <_lseek>
20025ca8:	1c43      	adds	r3, r0, #1
20025caa:	d102      	bne.n	20025cb2 <_lseek_r+0x1e>
20025cac:	682b      	ldr	r3, [r5, #0]
20025cae:	b103      	cbz	r3, 20025cb2 <_lseek_r+0x1e>
20025cb0:	6023      	str	r3, [r4, #0]
20025cb2:	bd38      	pop	{r3, r4, r5, pc}
20025cb4:	2004cff0 	.word	0x2004cff0

20025cb8 <_read_r>:
20025cb8:	b538      	push	{r3, r4, r5, lr}
20025cba:	4604      	mov	r4, r0
20025cbc:	4d06      	ldr	r5, [pc, #24]	@ (20025cd8 <_read_r+0x20>)
20025cbe:	4608      	mov	r0, r1
20025cc0:	4611      	mov	r1, r2
20025cc2:	2200      	movs	r2, #0
20025cc4:	602a      	str	r2, [r5, #0]
20025cc6:	461a      	mov	r2, r3
20025cc8:	f7fb fcec 	bl	200216a4 <_read>
20025ccc:	1c43      	adds	r3, r0, #1
20025cce:	d102      	bne.n	20025cd6 <_read_r+0x1e>
20025cd0:	682b      	ldr	r3, [r5, #0]
20025cd2:	b103      	cbz	r3, 20025cd6 <_read_r+0x1e>
20025cd4:	6023      	str	r3, [r4, #0]
20025cd6:	bd38      	pop	{r3, r4, r5, pc}
20025cd8:	2004cff0 	.word	0x2004cff0

20025cdc <_sbrk_r>:
20025cdc:	b538      	push	{r3, r4, r5, lr}
20025cde:	2300      	movs	r3, #0
20025ce0:	4d05      	ldr	r5, [pc, #20]	@ (20025cf8 <_sbrk_r+0x1c>)
20025ce2:	4604      	mov	r4, r0
20025ce4:	4608      	mov	r0, r1
20025ce6:	602b      	str	r3, [r5, #0]
20025ce8:	f000 fbd6 	bl	20026498 <_sbrk>
20025cec:	1c43      	adds	r3, r0, #1
20025cee:	d102      	bne.n	20025cf6 <_sbrk_r+0x1a>
20025cf0:	682b      	ldr	r3, [r5, #0]
20025cf2:	b103      	cbz	r3, 20025cf6 <_sbrk_r+0x1a>
20025cf4:	6023      	str	r3, [r4, #0]
20025cf6:	bd38      	pop	{r3, r4, r5, pc}
20025cf8:	2004cff0 	.word	0x2004cff0

20025cfc <_write_r>:
20025cfc:	b538      	push	{r3, r4, r5, lr}
20025cfe:	4604      	mov	r4, r0
20025d00:	4d06      	ldr	r5, [pc, #24]	@ (20025d1c <_write_r+0x20>)
20025d02:	4608      	mov	r0, r1
20025d04:	4611      	mov	r1, r2
20025d06:	2200      	movs	r2, #0
20025d08:	602a      	str	r2, [r5, #0]
20025d0a:	461a      	mov	r2, r3
20025d0c:	f7fb f8a6 	bl	20020e5c <_write>
20025d10:	1c43      	adds	r3, r0, #1
20025d12:	d102      	bne.n	20025d1a <_write_r+0x1e>
20025d14:	682b      	ldr	r3, [r5, #0]
20025d16:	b103      	cbz	r3, 20025d1a <_write_r+0x1e>
20025d18:	6023      	str	r3, [r4, #0]
20025d1a:	bd38      	pop	{r3, r4, r5, pc}
20025d1c:	2004cff0 	.word	0x2004cff0

20025d20 <__retarget_lock_init_recursive>:
20025d20:	4770      	bx	lr

20025d22 <__retarget_lock_acquire_recursive>:
20025d22:	4770      	bx	lr

20025d24 <__retarget_lock_release_recursive>:
20025d24:	4770      	bx	lr

20025d26 <memchr>:
20025d26:	b2c9      	uxtb	r1, r1
20025d28:	4603      	mov	r3, r0
20025d2a:	4402      	add	r2, r0
20025d2c:	b510      	push	{r4, lr}
20025d2e:	4293      	cmp	r3, r2
20025d30:	4618      	mov	r0, r3
20025d32:	d101      	bne.n	20025d38 <memchr+0x12>
20025d34:	2000      	movs	r0, #0
20025d36:	e003      	b.n	20025d40 <memchr+0x1a>
20025d38:	7804      	ldrb	r4, [r0, #0]
20025d3a:	3301      	adds	r3, #1
20025d3c:	428c      	cmp	r4, r1
20025d3e:	d1f6      	bne.n	20025d2e <memchr+0x8>
20025d40:	bd10      	pop	{r4, pc}

20025d42 <memcpy>:
20025d42:	440a      	add	r2, r1
20025d44:	1e43      	subs	r3, r0, #1
20025d46:	4291      	cmp	r1, r2
20025d48:	d100      	bne.n	20025d4c <memcpy+0xa>
20025d4a:	4770      	bx	lr
20025d4c:	b510      	push	{r4, lr}
20025d4e:	f811 4b01 	ldrb.w	r4, [r1], #1
20025d52:	4291      	cmp	r1, r2
20025d54:	f803 4f01 	strb.w	r4, [r3, #1]!
20025d58:	d1f9      	bne.n	20025d4e <memcpy+0xc>
20025d5a:	bd10      	pop	{r4, pc}

20025d5c <_free_r>:
20025d5c:	b538      	push	{r3, r4, r5, lr}
20025d5e:	4605      	mov	r5, r0
20025d60:	2900      	cmp	r1, #0
20025d62:	d041      	beq.n	20025de8 <_free_r+0x8c>
20025d64:	f851 3c04 	ldr.w	r3, [r1, #-4]
20025d68:	1f0c      	subs	r4, r1, #4
20025d6a:	2b00      	cmp	r3, #0
20025d6c:	bfb8      	it	lt
20025d6e:	18e4      	addlt	r4, r4, r3
20025d70:	f7ff fcaa 	bl	200256c8 <__malloc_lock>
20025d74:	4a1d      	ldr	r2, [pc, #116]	@ (20025dec <_free_r+0x90>)
20025d76:	6813      	ldr	r3, [r2, #0]
20025d78:	b933      	cbnz	r3, 20025d88 <_free_r+0x2c>
20025d7a:	6063      	str	r3, [r4, #4]
20025d7c:	6014      	str	r4, [r2, #0]
20025d7e:	4628      	mov	r0, r5
20025d80:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20025d84:	f7ff bca6 	b.w	200256d4 <__malloc_unlock>
20025d88:	42a3      	cmp	r3, r4
20025d8a:	d908      	bls.n	20025d9e <_free_r+0x42>
20025d8c:	6820      	ldr	r0, [r4, #0]
20025d8e:	1821      	adds	r1, r4, r0
20025d90:	428b      	cmp	r3, r1
20025d92:	bf01      	itttt	eq
20025d94:	6819      	ldreq	r1, [r3, #0]
20025d96:	685b      	ldreq	r3, [r3, #4]
20025d98:	1809      	addeq	r1, r1, r0
20025d9a:	6021      	streq	r1, [r4, #0]
20025d9c:	e7ed      	b.n	20025d7a <_free_r+0x1e>
20025d9e:	461a      	mov	r2, r3
20025da0:	685b      	ldr	r3, [r3, #4]
20025da2:	b10b      	cbz	r3, 20025da8 <_free_r+0x4c>
20025da4:	42a3      	cmp	r3, r4
20025da6:	d9fa      	bls.n	20025d9e <_free_r+0x42>
20025da8:	6811      	ldr	r1, [r2, #0]
20025daa:	1850      	adds	r0, r2, r1
20025dac:	42a0      	cmp	r0, r4
20025dae:	d10b      	bne.n	20025dc8 <_free_r+0x6c>
20025db0:	6820      	ldr	r0, [r4, #0]
20025db2:	4401      	add	r1, r0
20025db4:	1850      	adds	r0, r2, r1
20025db6:	6011      	str	r1, [r2, #0]
20025db8:	4283      	cmp	r3, r0
20025dba:	d1e0      	bne.n	20025d7e <_free_r+0x22>
20025dbc:	6818      	ldr	r0, [r3, #0]
20025dbe:	685b      	ldr	r3, [r3, #4]
20025dc0:	4408      	add	r0, r1
20025dc2:	6053      	str	r3, [r2, #4]
20025dc4:	6010      	str	r0, [r2, #0]
20025dc6:	e7da      	b.n	20025d7e <_free_r+0x22>
20025dc8:	d902      	bls.n	20025dd0 <_free_r+0x74>
20025dca:	230c      	movs	r3, #12
20025dcc:	602b      	str	r3, [r5, #0]
20025dce:	e7d6      	b.n	20025d7e <_free_r+0x22>
20025dd0:	6820      	ldr	r0, [r4, #0]
20025dd2:	1821      	adds	r1, r4, r0
20025dd4:	428b      	cmp	r3, r1
20025dd6:	bf02      	ittt	eq
20025dd8:	6819      	ldreq	r1, [r3, #0]
20025dda:	685b      	ldreq	r3, [r3, #4]
20025ddc:	1809      	addeq	r1, r1, r0
20025dde:	6063      	str	r3, [r4, #4]
20025de0:	bf08      	it	eq
20025de2:	6021      	streq	r1, [r4, #0]
20025de4:	6054      	str	r4, [r2, #4]
20025de6:	e7ca      	b.n	20025d7e <_free_r+0x22>
20025de8:	bd38      	pop	{r3, r4, r5, pc}
20025dea:	bf00      	nop
20025dec:	2004ceb0 	.word	0x2004ceb0

20025df0 <__sfputc_r>:
20025df0:	6893      	ldr	r3, [r2, #8]
20025df2:	3b01      	subs	r3, #1
20025df4:	2b00      	cmp	r3, #0
20025df6:	b410      	push	{r4}
20025df8:	6093      	str	r3, [r2, #8]
20025dfa:	da08      	bge.n	20025e0e <__sfputc_r+0x1e>
20025dfc:	6994      	ldr	r4, [r2, #24]
20025dfe:	42a3      	cmp	r3, r4
20025e00:	db01      	blt.n	20025e06 <__sfputc_r+0x16>
20025e02:	290a      	cmp	r1, #10
20025e04:	d103      	bne.n	20025e0e <__sfputc_r+0x1e>
20025e06:	f85d 4b04 	ldr.w	r4, [sp], #4
20025e0a:	f7ff be89 	b.w	20025b20 <__swbuf_r>
20025e0e:	6813      	ldr	r3, [r2, #0]
20025e10:	1c58      	adds	r0, r3, #1
20025e12:	6010      	str	r0, [r2, #0]
20025e14:	4608      	mov	r0, r1
20025e16:	7019      	strb	r1, [r3, #0]
20025e18:	f85d 4b04 	ldr.w	r4, [sp], #4
20025e1c:	4770      	bx	lr

20025e1e <__sfputs_r>:
20025e1e:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025e20:	4606      	mov	r6, r0
20025e22:	460f      	mov	r7, r1
20025e24:	4614      	mov	r4, r2
20025e26:	18d5      	adds	r5, r2, r3
20025e28:	42ac      	cmp	r4, r5
20025e2a:	d101      	bne.n	20025e30 <__sfputs_r+0x12>
20025e2c:	2000      	movs	r0, #0
20025e2e:	e007      	b.n	20025e40 <__sfputs_r+0x22>
20025e30:	463a      	mov	r2, r7
20025e32:	f814 1b01 	ldrb.w	r1, [r4], #1
20025e36:	4630      	mov	r0, r6
20025e38:	f7ff ffda 	bl	20025df0 <__sfputc_r>
20025e3c:	1c43      	adds	r3, r0, #1
20025e3e:	d1f3      	bne.n	20025e28 <__sfputs_r+0xa>
20025e40:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

20025e44 <_vfiprintf_r>:
20025e44:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025e48:	460d      	mov	r5, r1
20025e4a:	b09d      	sub	sp, #116	@ 0x74
20025e4c:	4614      	mov	r4, r2
20025e4e:	4698      	mov	r8, r3
20025e50:	4606      	mov	r6, r0
20025e52:	b118      	cbz	r0, 20025e5c <_vfiprintf_r+0x18>
20025e54:	6a03      	ldr	r3, [r0, #32]
20025e56:	b90b      	cbnz	r3, 20025e5c <_vfiprintf_r+0x18>
20025e58:	f7ff fd78 	bl	2002594c <__sinit>
20025e5c:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20025e5e:	07d9      	lsls	r1, r3, #31
20025e60:	d405      	bmi.n	20025e6e <_vfiprintf_r+0x2a>
20025e62:	89ab      	ldrh	r3, [r5, #12]
20025e64:	059a      	lsls	r2, r3, #22
20025e66:	d402      	bmi.n	20025e6e <_vfiprintf_r+0x2a>
20025e68:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025e6a:	f7ff ff5a 	bl	20025d22 <__retarget_lock_acquire_recursive>
20025e6e:	89ab      	ldrh	r3, [r5, #12]
20025e70:	071b      	lsls	r3, r3, #28
20025e72:	d501      	bpl.n	20025e78 <_vfiprintf_r+0x34>
20025e74:	692b      	ldr	r3, [r5, #16]
20025e76:	b99b      	cbnz	r3, 20025ea0 <_vfiprintf_r+0x5c>
20025e78:	4629      	mov	r1, r5
20025e7a:	4630      	mov	r0, r6
20025e7c:	f7ff fe8e 	bl	20025b9c <__swsetup_r>
20025e80:	b170      	cbz	r0, 20025ea0 <_vfiprintf_r+0x5c>
20025e82:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20025e84:	07dc      	lsls	r4, r3, #31
20025e86:	d504      	bpl.n	20025e92 <_vfiprintf_r+0x4e>
20025e88:	f04f 30ff 	mov.w	r0, #4294967295
20025e8c:	b01d      	add	sp, #116	@ 0x74
20025e8e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025e92:	89ab      	ldrh	r3, [r5, #12]
20025e94:	0598      	lsls	r0, r3, #22
20025e96:	d4f7      	bmi.n	20025e88 <_vfiprintf_r+0x44>
20025e98:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025e9a:	f7ff ff43 	bl	20025d24 <__retarget_lock_release_recursive>
20025e9e:	e7f3      	b.n	20025e88 <_vfiprintf_r+0x44>
20025ea0:	2300      	movs	r3, #0
20025ea2:	f8cd 800c 	str.w	r8, [sp, #12]
20025ea6:	f04f 0901 	mov.w	r9, #1
20025eaa:	f8df 81b4 	ldr.w	r8, [pc, #436]	@ 20026060 <_vfiprintf_r+0x21c>
20025eae:	9309      	str	r3, [sp, #36]	@ 0x24
20025eb0:	2320      	movs	r3, #32
20025eb2:	f88d 3029 	strb.w	r3, [sp, #41]	@ 0x29
20025eb6:	2330      	movs	r3, #48	@ 0x30
20025eb8:	f88d 302a 	strb.w	r3, [sp, #42]	@ 0x2a
20025ebc:	4623      	mov	r3, r4
20025ebe:	469a      	mov	sl, r3
20025ec0:	f813 2b01 	ldrb.w	r2, [r3], #1
20025ec4:	b10a      	cbz	r2, 20025eca <_vfiprintf_r+0x86>
20025ec6:	2a25      	cmp	r2, #37	@ 0x25
20025ec8:	d1f9      	bne.n	20025ebe <_vfiprintf_r+0x7a>
20025eca:	ebba 0b04 	subs.w	fp, sl, r4
20025ece:	d00b      	beq.n	20025ee8 <_vfiprintf_r+0xa4>
20025ed0:	465b      	mov	r3, fp
20025ed2:	4622      	mov	r2, r4
20025ed4:	4629      	mov	r1, r5
20025ed6:	4630      	mov	r0, r6
20025ed8:	f7ff ffa1 	bl	20025e1e <__sfputs_r>
20025edc:	3001      	adds	r0, #1
20025ede:	f000 80a7 	beq.w	20026030 <_vfiprintf_r+0x1ec>
20025ee2:	9a09      	ldr	r2, [sp, #36]	@ 0x24
20025ee4:	445a      	add	r2, fp
20025ee6:	9209      	str	r2, [sp, #36]	@ 0x24
20025ee8:	f89a 3000 	ldrb.w	r3, [sl]
20025eec:	2b00      	cmp	r3, #0
20025eee:	f000 809f 	beq.w	20026030 <_vfiprintf_r+0x1ec>
20025ef2:	2300      	movs	r3, #0
20025ef4:	f04f 32ff 	mov.w	r2, #4294967295
20025ef8:	f10a 0a01 	add.w	sl, sl, #1
20025efc:	9304      	str	r3, [sp, #16]
20025efe:	9307      	str	r3, [sp, #28]
20025f00:	f88d 3053 	strb.w	r3, [sp, #83]	@ 0x53
20025f04:	931a      	str	r3, [sp, #104]	@ 0x68
20025f06:	e9cd 2305 	strd	r2, r3, [sp, #20]
20025f0a:	4654      	mov	r4, sl
20025f0c:	2205      	movs	r2, #5
20025f0e:	4854      	ldr	r0, [pc, #336]	@ (20026060 <_vfiprintf_r+0x21c>)
20025f10:	f814 1b01 	ldrb.w	r1, [r4], #1
20025f14:	f7ff ff07 	bl	20025d26 <memchr>
20025f18:	9a04      	ldr	r2, [sp, #16]
20025f1a:	b9d8      	cbnz	r0, 20025f54 <_vfiprintf_r+0x110>
20025f1c:	06d1      	lsls	r1, r2, #27
20025f1e:	bf44      	itt	mi
20025f20:	2320      	movmi	r3, #32
20025f22:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20025f26:	0713      	lsls	r3, r2, #28
20025f28:	bf44      	itt	mi
20025f2a:	232b      	movmi	r3, #43	@ 0x2b
20025f2c:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20025f30:	f89a 3000 	ldrb.w	r3, [sl]
20025f34:	2b2a      	cmp	r3, #42	@ 0x2a
20025f36:	d015      	beq.n	20025f64 <_vfiprintf_r+0x120>
20025f38:	9a07      	ldr	r2, [sp, #28]
20025f3a:	4654      	mov	r4, sl
20025f3c:	2000      	movs	r0, #0
20025f3e:	f04f 0c0a 	mov.w	ip, #10
20025f42:	4621      	mov	r1, r4
20025f44:	f811 3b01 	ldrb.w	r3, [r1], #1
20025f48:	3b30      	subs	r3, #48	@ 0x30
20025f4a:	2b09      	cmp	r3, #9
20025f4c:	d94b      	bls.n	20025fe6 <_vfiprintf_r+0x1a2>
20025f4e:	b1b0      	cbz	r0, 20025f7e <_vfiprintf_r+0x13a>
20025f50:	9207      	str	r2, [sp, #28]
20025f52:	e014      	b.n	20025f7e <_vfiprintf_r+0x13a>
20025f54:	eba0 0308 	sub.w	r3, r0, r8
20025f58:	46a2      	mov	sl, r4
20025f5a:	fa09 f303 	lsl.w	r3, r9, r3
20025f5e:	4313      	orrs	r3, r2
20025f60:	9304      	str	r3, [sp, #16]
20025f62:	e7d2      	b.n	20025f0a <_vfiprintf_r+0xc6>
20025f64:	9b03      	ldr	r3, [sp, #12]
20025f66:	1d19      	adds	r1, r3, #4
20025f68:	681b      	ldr	r3, [r3, #0]
20025f6a:	2b00      	cmp	r3, #0
20025f6c:	9103      	str	r1, [sp, #12]
20025f6e:	bfbb      	ittet	lt
20025f70:	425b      	neglt	r3, r3
20025f72:	f042 0202 	orrlt.w	r2, r2, #2
20025f76:	9307      	strge	r3, [sp, #28]
20025f78:	9307      	strlt	r3, [sp, #28]
20025f7a:	bfb8      	it	lt
20025f7c:	9204      	strlt	r2, [sp, #16]
20025f7e:	7823      	ldrb	r3, [r4, #0]
20025f80:	2b2e      	cmp	r3, #46	@ 0x2e
20025f82:	d10a      	bne.n	20025f9a <_vfiprintf_r+0x156>
20025f84:	7863      	ldrb	r3, [r4, #1]
20025f86:	2b2a      	cmp	r3, #42	@ 0x2a
20025f88:	d132      	bne.n	20025ff0 <_vfiprintf_r+0x1ac>
20025f8a:	9b03      	ldr	r3, [sp, #12]
20025f8c:	3402      	adds	r4, #2
20025f8e:	1d1a      	adds	r2, r3, #4
20025f90:	681b      	ldr	r3, [r3, #0]
20025f92:	ea43 73e3 	orr.w	r3, r3, r3, asr #31
20025f96:	9203      	str	r2, [sp, #12]
20025f98:	9305      	str	r3, [sp, #20]
20025f9a:	f8df a0d4 	ldr.w	sl, [pc, #212]	@ 20026070 <_vfiprintf_r+0x22c>
20025f9e:	2203      	movs	r2, #3
20025fa0:	7821      	ldrb	r1, [r4, #0]
20025fa2:	4650      	mov	r0, sl
20025fa4:	f7ff febf 	bl	20025d26 <memchr>
20025fa8:	b138      	cbz	r0, 20025fba <_vfiprintf_r+0x176>
20025faa:	eba0 000a 	sub.w	r0, r0, sl
20025fae:	2240      	movs	r2, #64	@ 0x40
20025fb0:	9b04      	ldr	r3, [sp, #16]
20025fb2:	3401      	adds	r4, #1
20025fb4:	4082      	lsls	r2, r0
20025fb6:	4313      	orrs	r3, r2
20025fb8:	9304      	str	r3, [sp, #16]
20025fba:	f814 1b01 	ldrb.w	r1, [r4], #1
20025fbe:	2206      	movs	r2, #6
20025fc0:	4828      	ldr	r0, [pc, #160]	@ (20026064 <_vfiprintf_r+0x220>)
20025fc2:	f88d 1028 	strb.w	r1, [sp, #40]	@ 0x28
20025fc6:	f7ff feae 	bl	20025d26 <memchr>
20025fca:	2800      	cmp	r0, #0
20025fcc:	d03f      	beq.n	2002604e <_vfiprintf_r+0x20a>
20025fce:	4b26      	ldr	r3, [pc, #152]	@ (20026068 <_vfiprintf_r+0x224>)
20025fd0:	bb1b      	cbnz	r3, 2002601a <_vfiprintf_r+0x1d6>
20025fd2:	9b03      	ldr	r3, [sp, #12]
20025fd4:	3307      	adds	r3, #7
20025fd6:	f023 0307 	bic.w	r3, r3, #7
20025fda:	3308      	adds	r3, #8
20025fdc:	9303      	str	r3, [sp, #12]
20025fde:	9b09      	ldr	r3, [sp, #36]	@ 0x24
20025fe0:	443b      	add	r3, r7
20025fe2:	9309      	str	r3, [sp, #36]	@ 0x24
20025fe4:	e76a      	b.n	20025ebc <_vfiprintf_r+0x78>
20025fe6:	fb0c 3202 	mla	r2, ip, r2, r3
20025fea:	460c      	mov	r4, r1
20025fec:	2001      	movs	r0, #1
20025fee:	e7a8      	b.n	20025f42 <_vfiprintf_r+0xfe>
20025ff0:	2300      	movs	r3, #0
20025ff2:	3401      	adds	r4, #1
20025ff4:	f04f 0c0a 	mov.w	ip, #10
20025ff8:	4619      	mov	r1, r3
20025ffa:	9305      	str	r3, [sp, #20]
20025ffc:	4620      	mov	r0, r4
20025ffe:	f810 2b01 	ldrb.w	r2, [r0], #1
20026002:	3a30      	subs	r2, #48	@ 0x30
20026004:	2a09      	cmp	r2, #9
20026006:	d903      	bls.n	20026010 <_vfiprintf_r+0x1cc>
20026008:	2b00      	cmp	r3, #0
2002600a:	d0c6      	beq.n	20025f9a <_vfiprintf_r+0x156>
2002600c:	9105      	str	r1, [sp, #20]
2002600e:	e7c4      	b.n	20025f9a <_vfiprintf_r+0x156>
20026010:	fb0c 2101 	mla	r1, ip, r1, r2
20026014:	4604      	mov	r4, r0
20026016:	2301      	movs	r3, #1
20026018:	e7f0      	b.n	20025ffc <_vfiprintf_r+0x1b8>
2002601a:	ab03      	add	r3, sp, #12
2002601c:	462a      	mov	r2, r5
2002601e:	a904      	add	r1, sp, #16
20026020:	4630      	mov	r0, r6
20026022:	9300      	str	r3, [sp, #0]
20026024:	4b11      	ldr	r3, [pc, #68]	@ (2002606c <_vfiprintf_r+0x228>)
20026026:	f3af 8000 	nop.w
2002602a:	4607      	mov	r7, r0
2002602c:	1c78      	adds	r0, r7, #1
2002602e:	d1d6      	bne.n	20025fde <_vfiprintf_r+0x19a>
20026030:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20026032:	07d9      	lsls	r1, r3, #31
20026034:	d405      	bmi.n	20026042 <_vfiprintf_r+0x1fe>
20026036:	89ab      	ldrh	r3, [r5, #12]
20026038:	059a      	lsls	r2, r3, #22
2002603a:	d402      	bmi.n	20026042 <_vfiprintf_r+0x1fe>
2002603c:	6da8      	ldr	r0, [r5, #88]	@ 0x58
2002603e:	f7ff fe71 	bl	20025d24 <__retarget_lock_release_recursive>
20026042:	89ab      	ldrh	r3, [r5, #12]
20026044:	065b      	lsls	r3, r3, #25
20026046:	f53f af1f 	bmi.w	20025e88 <_vfiprintf_r+0x44>
2002604a:	9809      	ldr	r0, [sp, #36]	@ 0x24
2002604c:	e71e      	b.n	20025e8c <_vfiprintf_r+0x48>
2002604e:	ab03      	add	r3, sp, #12
20026050:	462a      	mov	r2, r5
20026052:	a904      	add	r1, sp, #16
20026054:	4630      	mov	r0, r6
20026056:	9300      	str	r3, [sp, #0]
20026058:	4b04      	ldr	r3, [pc, #16]	@ (2002606c <_vfiprintf_r+0x228>)
2002605a:	f000 f87d 	bl	20026158 <_printf_i>
2002605e:	e7e4      	b.n	2002602a <_vfiprintf_r+0x1e6>
20026060:	20026997 	.word	0x20026997
20026064:	200269a1 	.word	0x200269a1
20026068:	00000000 	.word	0x00000000
2002606c:	20025e1f 	.word	0x20025e1f
20026070:	2002699d 	.word	0x2002699d

20026074 <_printf_common>:
20026074:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20026078:	4616      	mov	r6, r2
2002607a:	4698      	mov	r8, r3
2002607c:	688a      	ldr	r2, [r1, #8]
2002607e:	4607      	mov	r7, r0
20026080:	690b      	ldr	r3, [r1, #16]
20026082:	460c      	mov	r4, r1
20026084:	f8dd 9020 	ldr.w	r9, [sp, #32]
20026088:	4293      	cmp	r3, r2
2002608a:	bfb8      	it	lt
2002608c:	4613      	movlt	r3, r2
2002608e:	6033      	str	r3, [r6, #0]
20026090:	f891 2043 	ldrb.w	r2, [r1, #67]	@ 0x43
20026094:	b10a      	cbz	r2, 2002609a <_printf_common+0x26>
20026096:	3301      	adds	r3, #1
20026098:	6033      	str	r3, [r6, #0]
2002609a:	6823      	ldr	r3, [r4, #0]
2002609c:	0699      	lsls	r1, r3, #26
2002609e:	bf42      	ittt	mi
200260a0:	6833      	ldrmi	r3, [r6, #0]
200260a2:	3302      	addmi	r3, #2
200260a4:	6033      	strmi	r3, [r6, #0]
200260a6:	6825      	ldr	r5, [r4, #0]
200260a8:	f015 0506 	ands.w	r5, r5, #6
200260ac:	d106      	bne.n	200260bc <_printf_common+0x48>
200260ae:	f104 0a19 	add.w	sl, r4, #25
200260b2:	68e3      	ldr	r3, [r4, #12]
200260b4:	6832      	ldr	r2, [r6, #0]
200260b6:	1a9b      	subs	r3, r3, r2
200260b8:	42ab      	cmp	r3, r5
200260ba:	dc2b      	bgt.n	20026114 <_printf_common+0xa0>
200260bc:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
200260c0:	6822      	ldr	r2, [r4, #0]
200260c2:	3b00      	subs	r3, #0
200260c4:	bf18      	it	ne
200260c6:	2301      	movne	r3, #1
200260c8:	0692      	lsls	r2, r2, #26
200260ca:	d430      	bmi.n	2002612e <_printf_common+0xba>
200260cc:	f104 0243 	add.w	r2, r4, #67	@ 0x43
200260d0:	4641      	mov	r1, r8
200260d2:	4638      	mov	r0, r7
200260d4:	47c8      	blx	r9
200260d6:	3001      	adds	r0, #1
200260d8:	d023      	beq.n	20026122 <_printf_common+0xae>
200260da:	6823      	ldr	r3, [r4, #0]
200260dc:	341a      	adds	r4, #26
200260de:	f854 2c0a 	ldr.w	r2, [r4, #-10]
200260e2:	f003 0306 	and.w	r3, r3, #6
200260e6:	2b04      	cmp	r3, #4
200260e8:	bf0a      	itet	eq
200260ea:	f854 5c0e 	ldreq.w	r5, [r4, #-14]
200260ee:	2500      	movne	r5, #0
200260f0:	6833      	ldreq	r3, [r6, #0]
200260f2:	f04f 0600 	mov.w	r6, #0
200260f6:	bf08      	it	eq
200260f8:	1aed      	subeq	r5, r5, r3
200260fa:	f854 3c12 	ldr.w	r3, [r4, #-18]
200260fe:	bf08      	it	eq
20026100:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
20026104:	4293      	cmp	r3, r2
20026106:	bfc4      	itt	gt
20026108:	1a9b      	subgt	r3, r3, r2
2002610a:	18ed      	addgt	r5, r5, r3
2002610c:	42b5      	cmp	r5, r6
2002610e:	d11a      	bne.n	20026146 <_printf_common+0xd2>
20026110:	2000      	movs	r0, #0
20026112:	e008      	b.n	20026126 <_printf_common+0xb2>
20026114:	2301      	movs	r3, #1
20026116:	4652      	mov	r2, sl
20026118:	4641      	mov	r1, r8
2002611a:	4638      	mov	r0, r7
2002611c:	47c8      	blx	r9
2002611e:	3001      	adds	r0, #1
20026120:	d103      	bne.n	2002612a <_printf_common+0xb6>
20026122:	f04f 30ff 	mov.w	r0, #4294967295
20026126:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002612a:	3501      	adds	r5, #1
2002612c:	e7c1      	b.n	200260b2 <_printf_common+0x3e>
2002612e:	18e1      	adds	r1, r4, r3
20026130:	1c5a      	adds	r2, r3, #1
20026132:	2030      	movs	r0, #48	@ 0x30
20026134:	3302      	adds	r3, #2
20026136:	4422      	add	r2, r4
20026138:	f881 0043 	strb.w	r0, [r1, #67]	@ 0x43
2002613c:	f894 1045 	ldrb.w	r1, [r4, #69]	@ 0x45
20026140:	f882 1043 	strb.w	r1, [r2, #67]	@ 0x43
20026144:	e7c2      	b.n	200260cc <_printf_common+0x58>
20026146:	2301      	movs	r3, #1
20026148:	4622      	mov	r2, r4
2002614a:	4641      	mov	r1, r8
2002614c:	4638      	mov	r0, r7
2002614e:	47c8      	blx	r9
20026150:	3001      	adds	r0, #1
20026152:	d0e6      	beq.n	20026122 <_printf_common+0xae>
20026154:	3601      	adds	r6, #1
20026156:	e7d9      	b.n	2002610c <_printf_common+0x98>

20026158 <_printf_i>:
20026158:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
2002615c:	7e0f      	ldrb	r7, [r1, #24]
2002615e:	4691      	mov	r9, r2
20026160:	4680      	mov	r8, r0
20026162:	460c      	mov	r4, r1
20026164:	2f78      	cmp	r7, #120	@ 0x78
20026166:	469a      	mov	sl, r3
20026168:	9e0c      	ldr	r6, [sp, #48]	@ 0x30
2002616a:	f101 0243 	add.w	r2, r1, #67	@ 0x43
2002616e:	d807      	bhi.n	20026180 <_printf_i+0x28>
20026170:	2f62      	cmp	r7, #98	@ 0x62
20026172:	d80a      	bhi.n	2002618a <_printf_i+0x32>
20026174:	2f00      	cmp	r7, #0
20026176:	f000 80d2 	beq.w	2002631e <_printf_i+0x1c6>
2002617a:	2f58      	cmp	r7, #88	@ 0x58
2002617c:	f000 80b7 	beq.w	200262ee <_printf_i+0x196>
20026180:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20026184:	f884 7042 	strb.w	r7, [r4, #66]	@ 0x42
20026188:	e03a      	b.n	20026200 <_printf_i+0xa8>
2002618a:	f1a7 0363 	sub.w	r3, r7, #99	@ 0x63
2002618e:	2b15      	cmp	r3, #21
20026190:	d8f6      	bhi.n	20026180 <_printf_i+0x28>
20026192:	a101      	add	r1, pc, #4	@ (adr r1, 20026198 <_printf_i+0x40>)
20026194:	f851 f023 	ldr.w	pc, [r1, r3, lsl #2]
20026198:	200261f1 	.word	0x200261f1
2002619c:	20026205 	.word	0x20026205
200261a0:	20026181 	.word	0x20026181
200261a4:	20026181 	.word	0x20026181
200261a8:	20026181 	.word	0x20026181
200261ac:	20026181 	.word	0x20026181
200261b0:	20026205 	.word	0x20026205
200261b4:	20026181 	.word	0x20026181
200261b8:	20026181 	.word	0x20026181
200261bc:	20026181 	.word	0x20026181
200261c0:	20026181 	.word	0x20026181
200261c4:	20026305 	.word	0x20026305
200261c8:	2002622f 	.word	0x2002622f
200261cc:	200262bb 	.word	0x200262bb
200261d0:	20026181 	.word	0x20026181
200261d4:	20026181 	.word	0x20026181
200261d8:	20026327 	.word	0x20026327
200261dc:	20026181 	.word	0x20026181
200261e0:	2002622f 	.word	0x2002622f
200261e4:	20026181 	.word	0x20026181
200261e8:	20026181 	.word	0x20026181
200261ec:	200262c3 	.word	0x200262c3
200261f0:	6833      	ldr	r3, [r6, #0]
200261f2:	1d1a      	adds	r2, r3, #4
200261f4:	681b      	ldr	r3, [r3, #0]
200261f6:	6032      	str	r2, [r6, #0]
200261f8:	f104 0642 	add.w	r6, r4, #66	@ 0x42
200261fc:	f884 3042 	strb.w	r3, [r4, #66]	@ 0x42
20026200:	2301      	movs	r3, #1
20026202:	e09d      	b.n	20026340 <_printf_i+0x1e8>
20026204:	6833      	ldr	r3, [r6, #0]
20026206:	6820      	ldr	r0, [r4, #0]
20026208:	1d19      	adds	r1, r3, #4
2002620a:	6031      	str	r1, [r6, #0]
2002620c:	0606      	lsls	r6, r0, #24
2002620e:	d501      	bpl.n	20026214 <_printf_i+0xbc>
20026210:	681d      	ldr	r5, [r3, #0]
20026212:	e003      	b.n	2002621c <_printf_i+0xc4>
20026214:	0645      	lsls	r5, r0, #25
20026216:	d5fb      	bpl.n	20026210 <_printf_i+0xb8>
20026218:	f9b3 5000 	ldrsh.w	r5, [r3]
2002621c:	2d00      	cmp	r5, #0
2002621e:	da03      	bge.n	20026228 <_printf_i+0xd0>
20026220:	232d      	movs	r3, #45	@ 0x2d
20026222:	426d      	negs	r5, r5
20026224:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026228:	4859      	ldr	r0, [pc, #356]	@ (20026390 <_printf_i+0x238>)
2002622a:	230a      	movs	r3, #10
2002622c:	e010      	b.n	20026250 <_printf_i+0xf8>
2002622e:	6821      	ldr	r1, [r4, #0]
20026230:	6833      	ldr	r3, [r6, #0]
20026232:	0608      	lsls	r0, r1, #24
20026234:	f853 5b04 	ldr.w	r5, [r3], #4
20026238:	d402      	bmi.n	20026240 <_printf_i+0xe8>
2002623a:	0649      	lsls	r1, r1, #25
2002623c:	bf48      	it	mi
2002623e:	b2ad      	uxthmi	r5, r5
20026240:	2f6f      	cmp	r7, #111	@ 0x6f
20026242:	4853      	ldr	r0, [pc, #332]	@ (20026390 <_printf_i+0x238>)
20026244:	6033      	str	r3, [r6, #0]
20026246:	d159      	bne.n	200262fc <_printf_i+0x1a4>
20026248:	2308      	movs	r3, #8
2002624a:	2100      	movs	r1, #0
2002624c:	f884 1043 	strb.w	r1, [r4, #67]	@ 0x43
20026250:	6866      	ldr	r6, [r4, #4]
20026252:	2e00      	cmp	r6, #0
20026254:	60a6      	str	r6, [r4, #8]
20026256:	db05      	blt.n	20026264 <_printf_i+0x10c>
20026258:	6821      	ldr	r1, [r4, #0]
2002625a:	432e      	orrs	r6, r5
2002625c:	f021 0104 	bic.w	r1, r1, #4
20026260:	6021      	str	r1, [r4, #0]
20026262:	d04d      	beq.n	20026300 <_printf_i+0x1a8>
20026264:	4616      	mov	r6, r2
20026266:	fbb5 f1f3 	udiv	r1, r5, r3
2002626a:	fb03 5711 	mls	r7, r3, r1, r5
2002626e:	5dc7      	ldrb	r7, [r0, r7]
20026270:	f806 7d01 	strb.w	r7, [r6, #-1]!
20026274:	462f      	mov	r7, r5
20026276:	460d      	mov	r5, r1
20026278:	42bb      	cmp	r3, r7
2002627a:	d9f4      	bls.n	20026266 <_printf_i+0x10e>
2002627c:	2b08      	cmp	r3, #8
2002627e:	d10b      	bne.n	20026298 <_printf_i+0x140>
20026280:	6823      	ldr	r3, [r4, #0]
20026282:	07df      	lsls	r7, r3, #31
20026284:	d508      	bpl.n	20026298 <_printf_i+0x140>
20026286:	6923      	ldr	r3, [r4, #16]
20026288:	6861      	ldr	r1, [r4, #4]
2002628a:	4299      	cmp	r1, r3
2002628c:	bfde      	ittt	le
2002628e:	2330      	movle	r3, #48	@ 0x30
20026290:	f806 3c01 	strble.w	r3, [r6, #-1]
20026294:	f106 36ff 	addle.w	r6, r6, #4294967295
20026298:	1b92      	subs	r2, r2, r6
2002629a:	6122      	str	r2, [r4, #16]
2002629c:	464b      	mov	r3, r9
2002629e:	aa03      	add	r2, sp, #12
200262a0:	4621      	mov	r1, r4
200262a2:	4640      	mov	r0, r8
200262a4:	f8cd a000 	str.w	sl, [sp]
200262a8:	f7ff fee4 	bl	20026074 <_printf_common>
200262ac:	3001      	adds	r0, #1
200262ae:	d14c      	bne.n	2002634a <_printf_i+0x1f2>
200262b0:	f04f 30ff 	mov.w	r0, #4294967295
200262b4:	b004      	add	sp, #16
200262b6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200262ba:	6823      	ldr	r3, [r4, #0]
200262bc:	f043 0320 	orr.w	r3, r3, #32
200262c0:	6023      	str	r3, [r4, #0]
200262c2:	2778      	movs	r7, #120	@ 0x78
200262c4:	4833      	ldr	r0, [pc, #204]	@ (20026394 <_printf_i+0x23c>)
200262c6:	6823      	ldr	r3, [r4, #0]
200262c8:	f884 7045 	strb.w	r7, [r4, #69]	@ 0x45
200262cc:	061f      	lsls	r7, r3, #24
200262ce:	6831      	ldr	r1, [r6, #0]
200262d0:	f851 5b04 	ldr.w	r5, [r1], #4
200262d4:	d402      	bmi.n	200262dc <_printf_i+0x184>
200262d6:	065f      	lsls	r7, r3, #25
200262d8:	bf48      	it	mi
200262da:	b2ad      	uxthmi	r5, r5
200262dc:	6031      	str	r1, [r6, #0]
200262de:	07d9      	lsls	r1, r3, #31
200262e0:	bf44      	itt	mi
200262e2:	f043 0320 	orrmi.w	r3, r3, #32
200262e6:	6023      	strmi	r3, [r4, #0]
200262e8:	b11d      	cbz	r5, 200262f2 <_printf_i+0x19a>
200262ea:	2310      	movs	r3, #16
200262ec:	e7ad      	b.n	2002624a <_printf_i+0xf2>
200262ee:	4828      	ldr	r0, [pc, #160]	@ (20026390 <_printf_i+0x238>)
200262f0:	e7e9      	b.n	200262c6 <_printf_i+0x16e>
200262f2:	6823      	ldr	r3, [r4, #0]
200262f4:	f023 0320 	bic.w	r3, r3, #32
200262f8:	6023      	str	r3, [r4, #0]
200262fa:	e7f6      	b.n	200262ea <_printf_i+0x192>
200262fc:	230a      	movs	r3, #10
200262fe:	e7a4      	b.n	2002624a <_printf_i+0xf2>
20026300:	4616      	mov	r6, r2
20026302:	e7bb      	b.n	2002627c <_printf_i+0x124>
20026304:	6833      	ldr	r3, [r6, #0]
20026306:	6825      	ldr	r5, [r4, #0]
20026308:	1d18      	adds	r0, r3, #4
2002630a:	6961      	ldr	r1, [r4, #20]
2002630c:	6030      	str	r0, [r6, #0]
2002630e:	062e      	lsls	r6, r5, #24
20026310:	681b      	ldr	r3, [r3, #0]
20026312:	d501      	bpl.n	20026318 <_printf_i+0x1c0>
20026314:	6019      	str	r1, [r3, #0]
20026316:	e002      	b.n	2002631e <_printf_i+0x1c6>
20026318:	0668      	lsls	r0, r5, #25
2002631a:	d5fb      	bpl.n	20026314 <_printf_i+0x1bc>
2002631c:	8019      	strh	r1, [r3, #0]
2002631e:	2300      	movs	r3, #0
20026320:	4616      	mov	r6, r2
20026322:	6123      	str	r3, [r4, #16]
20026324:	e7ba      	b.n	2002629c <_printf_i+0x144>
20026326:	6833      	ldr	r3, [r6, #0]
20026328:	2100      	movs	r1, #0
2002632a:	1d1a      	adds	r2, r3, #4
2002632c:	6032      	str	r2, [r6, #0]
2002632e:	681e      	ldr	r6, [r3, #0]
20026330:	6862      	ldr	r2, [r4, #4]
20026332:	4630      	mov	r0, r6
20026334:	f7ff fcf7 	bl	20025d26 <memchr>
20026338:	b108      	cbz	r0, 2002633e <_printf_i+0x1e6>
2002633a:	1b80      	subs	r0, r0, r6
2002633c:	6060      	str	r0, [r4, #4]
2002633e:	6863      	ldr	r3, [r4, #4]
20026340:	6123      	str	r3, [r4, #16]
20026342:	2300      	movs	r3, #0
20026344:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026348:	e7a8      	b.n	2002629c <_printf_i+0x144>
2002634a:	6923      	ldr	r3, [r4, #16]
2002634c:	4632      	mov	r2, r6
2002634e:	4649      	mov	r1, r9
20026350:	4640      	mov	r0, r8
20026352:	47d0      	blx	sl
20026354:	3001      	adds	r0, #1
20026356:	d0ab      	beq.n	200262b0 <_printf_i+0x158>
20026358:	6823      	ldr	r3, [r4, #0]
2002635a:	079b      	lsls	r3, r3, #30
2002635c:	d413      	bmi.n	20026386 <_printf_i+0x22e>
2002635e:	68e0      	ldr	r0, [r4, #12]
20026360:	9b03      	ldr	r3, [sp, #12]
20026362:	4298      	cmp	r0, r3
20026364:	bfb8      	it	lt
20026366:	4618      	movlt	r0, r3
20026368:	e7a4      	b.n	200262b4 <_printf_i+0x15c>
2002636a:	2301      	movs	r3, #1
2002636c:	4632      	mov	r2, r6
2002636e:	4649      	mov	r1, r9
20026370:	4640      	mov	r0, r8
20026372:	47d0      	blx	sl
20026374:	3001      	adds	r0, #1
20026376:	d09b      	beq.n	200262b0 <_printf_i+0x158>
20026378:	3501      	adds	r5, #1
2002637a:	68e3      	ldr	r3, [r4, #12]
2002637c:	9903      	ldr	r1, [sp, #12]
2002637e:	1a5b      	subs	r3, r3, r1
20026380:	42ab      	cmp	r3, r5
20026382:	dcf2      	bgt.n	2002636a <_printf_i+0x212>
20026384:	e7eb      	b.n	2002635e <_printf_i+0x206>
20026386:	2500      	movs	r5, #0
20026388:	f104 0619 	add.w	r6, r4, #25
2002638c:	e7f5      	b.n	2002637a <_printf_i+0x222>
2002638e:	bf00      	nop
20026390:	200269a8 	.word	0x200269a8
20026394:	200269b9 	.word	0x200269b9

20026398 <__swhatbuf_r>:
20026398:	b570      	push	{r4, r5, r6, lr}
2002639a:	460c      	mov	r4, r1
2002639c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200263a0:	b096      	sub	sp, #88	@ 0x58
200263a2:	4615      	mov	r5, r2
200263a4:	2900      	cmp	r1, #0
200263a6:	461e      	mov	r6, r3
200263a8:	da0a      	bge.n	200263c0 <__swhatbuf_r+0x28>
200263aa:	89a1      	ldrh	r1, [r4, #12]
200263ac:	f011 0180 	ands.w	r1, r1, #128	@ 0x80
200263b0:	d113      	bne.n	200263da <__swhatbuf_r+0x42>
200263b2:	f44f 6280 	mov.w	r2, #1024	@ 0x400
200263b6:	2000      	movs	r0, #0
200263b8:	6031      	str	r1, [r6, #0]
200263ba:	602a      	str	r2, [r5, #0]
200263bc:	b016      	add	sp, #88	@ 0x58
200263be:	bd70      	pop	{r4, r5, r6, pc}
200263c0:	466a      	mov	r2, sp
200263c2:	f000 f847 	bl	20026454 <_fstat_r>
200263c6:	2800      	cmp	r0, #0
200263c8:	dbef      	blt.n	200263aa <__swhatbuf_r+0x12>
200263ca:	9901      	ldr	r1, [sp, #4]
200263cc:	f401 4170 	and.w	r1, r1, #61440	@ 0xf000
200263d0:	f5a1 5300 	sub.w	r3, r1, #8192	@ 0x2000
200263d4:	4259      	negs	r1, r3
200263d6:	4159      	adcs	r1, r3
200263d8:	e7eb      	b.n	200263b2 <__swhatbuf_r+0x1a>
200263da:	2100      	movs	r1, #0
200263dc:	2240      	movs	r2, #64	@ 0x40
200263de:	e7ea      	b.n	200263b6 <__swhatbuf_r+0x1e>

200263e0 <__smakebuf_r>:
200263e0:	898b      	ldrh	r3, [r1, #12]
200263e2:	b573      	push	{r0, r1, r4, r5, r6, lr}
200263e4:	079e      	lsls	r6, r3, #30
200263e6:	4605      	mov	r5, r0
200263e8:	460c      	mov	r4, r1
200263ea:	d507      	bpl.n	200263fc <__smakebuf_r+0x1c>
200263ec:	f104 0347 	add.w	r3, r4, #71	@ 0x47
200263f0:	6023      	str	r3, [r4, #0]
200263f2:	6123      	str	r3, [r4, #16]
200263f4:	2301      	movs	r3, #1
200263f6:	6163      	str	r3, [r4, #20]
200263f8:	b002      	add	sp, #8
200263fa:	bd70      	pop	{r4, r5, r6, pc}
200263fc:	ab01      	add	r3, sp, #4
200263fe:	466a      	mov	r2, sp
20026400:	f7ff ffca 	bl	20026398 <__swhatbuf_r>
20026404:	9e00      	ldr	r6, [sp, #0]
20026406:	4628      	mov	r0, r5
20026408:	4631      	mov	r1, r6
2002640a:	f7ff f8dd 	bl	200255c8 <_malloc_r>
2002640e:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20026412:	b938      	cbnz	r0, 20026424 <__smakebuf_r+0x44>
20026414:	059a      	lsls	r2, r3, #22
20026416:	d4ef      	bmi.n	200263f8 <__smakebuf_r+0x18>
20026418:	f023 0303 	bic.w	r3, r3, #3
2002641c:	f043 0302 	orr.w	r3, r3, #2
20026420:	81a3      	strh	r3, [r4, #12]
20026422:	e7e3      	b.n	200263ec <__smakebuf_r+0xc>
20026424:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20026428:	6020      	str	r0, [r4, #0]
2002642a:	81a3      	strh	r3, [r4, #12]
2002642c:	9b01      	ldr	r3, [sp, #4]
2002642e:	e9c4 0604 	strd	r0, r6, [r4, #16]
20026432:	2b00      	cmp	r3, #0
20026434:	d0e0      	beq.n	200263f8 <__smakebuf_r+0x18>
20026436:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
2002643a:	4628      	mov	r0, r5
2002643c:	f000 f81c 	bl	20026478 <_isatty_r>
20026440:	2800      	cmp	r0, #0
20026442:	d0d9      	beq.n	200263f8 <__smakebuf_r+0x18>
20026444:	89a3      	ldrh	r3, [r4, #12]
20026446:	f023 0303 	bic.w	r3, r3, #3
2002644a:	f043 0301 	orr.w	r3, r3, #1
2002644e:	81a3      	strh	r3, [r4, #12]
20026450:	e7d2      	b.n	200263f8 <__smakebuf_r+0x18>
	...

20026454 <_fstat_r>:
20026454:	b538      	push	{r3, r4, r5, lr}
20026456:	2300      	movs	r3, #0
20026458:	4d06      	ldr	r5, [pc, #24]	@ (20026474 <_fstat_r+0x20>)
2002645a:	4604      	mov	r4, r0
2002645c:	4608      	mov	r0, r1
2002645e:	4611      	mov	r1, r2
20026460:	602b      	str	r3, [r5, #0]
20026462:	f7fb f921 	bl	200216a8 <_fstat>
20026466:	1c43      	adds	r3, r0, #1
20026468:	d102      	bne.n	20026470 <_fstat_r+0x1c>
2002646a:	682b      	ldr	r3, [r5, #0]
2002646c:	b103      	cbz	r3, 20026470 <_fstat_r+0x1c>
2002646e:	6023      	str	r3, [r4, #0]
20026470:	bd38      	pop	{r3, r4, r5, pc}
20026472:	bf00      	nop
20026474:	2004cff0 	.word	0x2004cff0

20026478 <_isatty_r>:
20026478:	b538      	push	{r3, r4, r5, lr}
2002647a:	2300      	movs	r3, #0
2002647c:	4d05      	ldr	r5, [pc, #20]	@ (20026494 <_isatty_r+0x1c>)
2002647e:	4604      	mov	r4, r0
20026480:	4608      	mov	r0, r1
20026482:	602b      	str	r3, [r5, #0]
20026484:	f7fb f912 	bl	200216ac <_isatty>
20026488:	1c43      	adds	r3, r0, #1
2002648a:	d102      	bne.n	20026492 <_isatty_r+0x1a>
2002648c:	682b      	ldr	r3, [r5, #0]
2002648e:	b103      	cbz	r3, 20026492 <_isatty_r+0x1a>
20026490:	6023      	str	r3, [r4, #0]
20026492:	bd38      	pop	{r3, r4, r5, pc}
20026494:	2004cff0 	.word	0x2004cff0

20026498 <_sbrk>:
20026498:	4a05      	ldr	r2, [pc, #20]	@ (200264b0 <_sbrk+0x18>)
2002649a:	4603      	mov	r3, r0
2002649c:	6810      	ldr	r0, [r2, #0]
2002649e:	b110      	cbz	r0, 200264a6 <_sbrk+0xe>
200264a0:	4403      	add	r3, r0
200264a2:	6013      	str	r3, [r2, #0]
200264a4:	4770      	bx	lr
200264a6:	4803      	ldr	r0, [pc, #12]	@ (200264b4 <_sbrk+0x1c>)
200264a8:	4403      	add	r3, r0
200264aa:	6013      	str	r3, [r2, #0]
200264ac:	4770      	bx	lr
200264ae:	bf00      	nop
200264b0:	2004cff8 	.word	0x2004cff8
200264b4:	20042000 	.word	0x20042000
200264b8:	61766e69 	.word	0x61766e69
200264bc:	2064696c 	.word	0x2064696c
200264c0:	746f6f62 	.word	0x746f6f62
200264c4:	76656420 	.word	0x76656420
200264c8:	00656369 	.word	0x00656369
200264cc:	693a4c42 	.word	0x693a4c42
200264d0:	6c61766e 	.word	0x6c61766e
200264d4:	66206469 	.word	0x66206469
200264d8:	20626174 	.word	0x20626174
200264dc:	6967616d 	.word	0x6967616d
200264e0:	72662063 	.word	0x72662063
200264e4:	64206d6f 	.word	0x64206d6f
200264e8:	63697665 	.word	0x63697665
200264ec:	64253a65 	.word	0x64253a65
200264f0:	4c42000a 	.word	0x4c42000a
200264f4:	6f6f623a 	.word	0x6f6f623a
200264f8:	65642074 	.word	0x65642074
200264fc:	65636976 	.word	0x65636976
20026500:	696e6920 	.word	0x696e6920
20026504:	61662074 	.word	0x61662074
20026508:	66206c69 	.word	0x66206c69
2002650c:	3a6d6f72 	.word	0x3a6d6f72
20026510:	000a6425 	.word	0x000a6425
20026514:	64616f6c 	.word	0x64616f6c
20026518:	6e616220 	.word	0x6e616220
2002651c:	6620306b 	.word	0x6620306b
20026520:	736c6961 	.word	0x736c6961
20026524:	616d6900 	.word	0x616d6900
20026528:	73206567 	.word	0x73206567
2002652c:	616e6769 	.word	0x616e6769
20026530:	65727574 	.word	0x65727574
20026534:	72657620 	.word	0x72657620
20026538:	63696669 	.word	0x63696669
2002653c:	6f697461 	.word	0x6f697461
20026540:	6166206e 	.word	0x6166206e
20026544:	00736c69 	.word	0x00736c69
20026548:	2070614d 	.word	0x2070614d
2002654c:	6f727265 	.word	0x6f727265
20026550:	6c203a72 	.word	0x6c203a72
20026554:	6369676f 	.word	0x6369676f
20026558:	2c642520 	.word	0x2c642520
2002655c:	79687020 	.word	0x79687020
20026560:	0a642520 	.word	0x0a642520
20026564:	52524500 	.word	0x52524500
20026568:	2032203a 	.word	0x2032203a
2002656c:	69676f6c 	.word	0x69676f6c
20026570:	6c622063 	.word	0x6c622063
20026574:	736b636f 	.word	0x736b636f
20026578:	70616d20 	.word	0x70616d20
2002657c:	206f7420 	.word	0x206f7420
20026580:	656d6173 	.word	0x656d6173
20026584:	6b6c6220 	.word	0x6b6c6220
20026588:	6f6c203a 	.word	0x6f6c203a
2002658c:	30636967 	.word	0x30636967
20026590:	2c642520 	.word	0x2c642520
20026594:	79687020 	.word	0x79687020
20026598:	64252030 	.word	0x64252030
2002659c:	6f6c202c 	.word	0x6f6c202c
200265a0:	31636967 	.word	0x31636967
200265a4:	2c642520 	.word	0x2c642520
200265a8:	79687020 	.word	0x79687020
200265ac:	64252031 	.word	0x64252031
200265b0:	614d000a 	.word	0x614d000a
200265b4:	72652070 	.word	0x72652070
200265b8:	30726f72 	.word	0x30726f72
200265bc:	6f6c203a 	.word	0x6f6c203a
200265c0:	20636967 	.word	0x20636967
200265c4:	202c6425 	.word	0x202c6425
200265c8:	20796870 	.word	0x20796870
200265cc:	000a6425 	.word	0x000a6425
200265d0:	20746547 	.word	0x20746547
200265d4:	2070616d 	.word	0x2070616d
200265d8:	636f6c62 	.word	0x636f6c62
200265dc:	7265206b 	.word	0x7265206b
200265e0:	20726f72 	.word	0x20726f72
200265e4:	2d206425 	.word	0x2d206425
200265e8:	25203e2d 	.word	0x25203e2d
200265ec:	42000a64 	.word	0x42000a64
200265f0:	76204d42 	.word	0x76204d42
200265f4:	69737265 	.word	0x69737265
200265f8:	6e206e6f 	.word	0x6e206e6f
200265fc:	6920746f 	.word	0x6920746f
20026600:	6572636e 	.word	0x6572636e
20026604:	64657361 	.word	0x64657361
20026608:	7270203a 	.word	0x7270203a
2002660c:	25207665 	.word	0x25207665
20026610:	63202c64 	.word	0x63202c64
20026614:	20727275 	.word	0x20727275
20026618:	000a6425 	.word	0x000a6425
2002661c:	41544144 	.word	0x41544144
20026620:	746f6e20 	.word	0x746f6e20
20026624:	61657220 	.word	0x61657220
20026628:	616e6f73 	.word	0x616e6f73
2002662c:	20656c62 	.word	0x20656c62
20026630:	42206e69 	.word	0x42206e69
20026634:	62204d42 	.word	0x62204d42
20026638:	25206b6c 	.word	0x25206b6c
2002663c:	61702064 	.word	0x61702064
20026640:	25206567 	.word	0x25206567
20026644:	30203a64 	.word	0x30203a64
20026648:	0a782578 	.word	0x0a782578
2002664c:	61655200 	.word	0x61655200
20026650:	62622064 	.word	0x62622064
20026654:	6c62206d 	.word	0x6c62206d
20026658:	6425206b 	.word	0x6425206b
2002665c:	67617020 	.word	0x67617020
20026660:	64252065 	.word	0x64252065
20026664:	69616620 	.word	0x69616620
20026668:	49000a6c 	.word	0x49000a6c
2002666c:	6c61766e 	.word	0x6c61766e
20026670:	42206469 	.word	0x42206469
20026674:	49204d42 	.word	0x49204d42
20026678:	25205844 	.word	0x25205844
2002667c:	56000a64 	.word	0x56000a64
20026680:	64252031 	.word	0x64252031
20026684:	206e6920 	.word	0x206e6920
20026688:	636f6c62 	.word	0x636f6c62
2002668c:	6425206b 	.word	0x6425206b
20026690:	3256202c 	.word	0x3256202c
20026694:	20642520 	.word	0x20642520
20026698:	62206e69 	.word	0x62206e69
2002669c:	6b636f6c 	.word	0x6b636f6c
200266a0:	0a642520 	.word	0x0a642520
200266a4:	6d615300 	.word	0x6d615300
200266a8:	69687465 	.word	0x69687465
200266ac:	6d20676e 	.word	0x6d20676e
200266b0:	20747375 	.word	0x20747375
200266b4:	77206562 	.word	0x77206562
200266b8:	676e6f72 	.word	0x676e6f72
200266bc:	6567202c 	.word	0x6567202c
200266c0:	656e2074 	.word	0x656e2074
200266c4:	65762077 	.word	0x65762077
200266c8:	6f697372 	.word	0x6f697372
200266cc:	6425206e 	.word	0x6425206e
200266d0:	206f6420 	.word	0x206f6420
200266d4:	20746f6e 	.word	0x20746f6e
200266d8:	656d6173 	.word	0x656d6173
200266dc:	206f7420 	.word	0x206f7420
200266e0:	76657270 	.word	0x76657270
200266e4:	65686320 	.word	0x65686320
200266e8:	25206b63 	.word	0x25206b63
200266ec:	43000a64 	.word	0x43000a64
200266f0:	63204352 	.word	0x63204352
200266f4:	6b636568 	.word	0x6b636568
200266f8:	72726520 	.word	0x72726520
200266fc:	0a20726f 	.word	0x0a20726f
20026700:	61655200 	.word	0x61655200
20026704:	62622064 	.word	0x62622064
20026708:	6c62206d 	.word	0x6c62206d
2002670c:	6425206b 	.word	0x6425206b
20026710:	67617020 	.word	0x67617020
20026714:	64252065 	.word	0x64252065
20026718:	74616420 	.word	0x74616420
2002671c:	6f6e2061 	.word	0x6f6e2061
20026720:	72772074 	.word	0x72772074
20026724:	20657469 	.word	0x20657469
20026728:	20726f66 	.word	0x20726f66
2002672c:	20646e32 	.word	0x20646e32
20026730:	656d6974 	.word	0x656d6974
20026734:	6552000a 	.word	0x6552000a
20026738:	62206461 	.word	0x62206461
2002673c:	62206d62 	.word	0x62206d62
20026740:	25206b6c 	.word	0x25206b6c
20026744:	61702064 	.word	0x61702064
20026748:	25206567 	.word	0x25206567
2002674c:	61662064 	.word	0x61662064
20026750:	66206c69 	.word	0x66206c69
20026754:	3220726f 	.word	0x3220726f
20026758:	7420646e 	.word	0x7420646e
2002675c:	3f656d69 	.word	0x3f656d69
20026760:	614c000a 	.word	0x614c000a
20026764:	74736574 	.word	0x74736574
20026768:	72657620 	.word	0x72657620
2002676c:	6e6f6973 	.word	0x6e6f6973
20026770:	0a642520 	.word	0x0a642520
20026774:	74654700 	.word	0x74654700
20026778:	79687020 	.word	0x79687020
2002677c:	6b6c6220 	.word	0x6b6c6220
20026780:	726f6620 	.word	0x726f6620
20026784:	20642520 	.word	0x20642520
20026788:	6c696166 	.word	0x6c696166
2002678c:	65687720 	.word	0x65687720
20026790:	6572206e 	.word	0x6572206e
20026794:	000a6461 	.word	0x000a6461
20026798:	636f6c42 	.word	0x636f6c42
2002679c:	6425206b 	.word	0x6425206b
200267a0:	61726520 	.word	0x61726520
200267a4:	66206573 	.word	0x66206573
200267a8:	2c6c6961 	.word	0x2c6c6961
200267ac:	72616d20 	.word	0x72616d20
200267b0:	7361206b 	.word	0x7361206b
200267b4:	64616220 	.word	0x64616220
200267b8:	6c42000a 	.word	0x6c42000a
200267bc:	206b636f 	.word	0x206b636f
200267c0:	63206425 	.word	0x63206425
200267c4:	6b636568 	.word	0x6b636568
200267c8:	20736120 	.word	0x20736120
200267cc:	20646162 	.word	0x20646162
200267d0:	636f6c62 	.word	0x636f6c62
200267d4:	42000a6b 	.word	0x42000a6b
200267d8:	6b636f6c 	.word	0x6b636f6c
200267dc:	20642520 	.word	0x20642520
200267e0:	62207369 	.word	0x62207369
200267e4:	69206461 	.word	0x69206461
200267e8:	7375206e 	.word	0x7375206e
200267ec:	62207265 	.word	0x62207265
200267f0:	6b636f6c 	.word	0x6b636f6c
200267f4:	6162000a 	.word	0x6162000a
200267f8:	64252064 	.word	0x64252064
200267fc:	6572202c 	.word	0x6572202c
20026800:	63616c70 	.word	0x63616c70
20026804:	64252065 	.word	0x64252065
20026808:	6f4e000a 	.word	0x6f4e000a
2002680c:	63616220 	.word	0x63616220
20026810:	2070756b 	.word	0x2070756b
20026814:	636f6c62 	.word	0x636f6c62
20026818:	6e61206b 	.word	0x6e61206b
2002681c:	6f6d2079 	.word	0x6f6d2079
20026820:	000a6572 	.word	0x000a6572
20026824:	74706d65 	.word	0x74706d65
20026828:	61742079 	.word	0x61742079
2002682c:	20656c62 	.word	0x20656c62
20026830:	6e206425 	.word	0x6e206425
20026834:	6520746f 	.word	0x6520746f
20026838:	67756f6e 	.word	0x67756f6e
2002683c:	6f662068 	.word	0x6f662068
20026840:	6e692072 	.word	0x6e692072
20026844:	61697469 	.word	0x61697469
20026848:	55000a6c 	.word	0x55000a6c
2002684c:	74616470 	.word	0x74616470
20026850:	61742065 	.word	0x61742065
20026854:	20656c62 	.word	0x20656c62
20026858:	66206f74 	.word	0x66206f74
2002685c:	6873616c 	.word	0x6873616c
20026860:	6e6f6420 	.word	0x6e6f6420
20026864:	49000a65 	.word	0x49000a65
20026868:	6974696e 	.word	0x6974696e
2002686c:	74206c61 	.word	0x74206c61
20026870:	656c6261 	.word	0x656c6261
20026874:	69616620 	.word	0x69616620
20026878:	42000a6c 	.word	0x42000a6c
2002687c:	69204d42 	.word	0x69204d42
20026880:	6974696e 	.word	0x6974696e
20026884:	7a696c61 	.word	0x7a696c61
20026888:	62206465 	.word	0x62206465
2002688c:	726f6665 	.word	0x726f6665
20026890:	64202c65 	.word	0x64202c65
20026894:	6f6e206f 	.word	0x6f6e206f
20026898:	6e692074 	.word	0x6e692074
2002689c:	61207469 	.word	0x61207469
200268a0:	6d20796e 	.word	0x6d20796e
200268a4:	0a65726f 	.word	0x0a65726f
200268a8:	54454400 	.word	0x54454400
200268ac:	20642520 	.word	0x20642520
200268b0:	0a646162 	.word	0x0a646162
200268b4:	4b4c4200 	.word	0x4b4c4200
200268b8:	20642520 	.word	0x20642520
200268bc:	64616572 	.word	0x64616572
200268c0:	69616620 	.word	0x69616620
200268c4:	6d202c6c 	.word	0x6d202c6c
200268c8:	206b7261 	.word	0x206b7261
200268cc:	62207361 	.word	0x62207361
200268d0:	000a6461 	.word	0x000a6461
200268d4:	20746564 	.word	0x20746564
200268d8:	206d6262 	.word	0x206d6262
200268dc:	6c626174 	.word	0x6c626174
200268e0:	69772065 	.word	0x69772065
200268e4:	25206874 	.word	0x25206874
200268e8:	25202c64 	.word	0x25202c64
200268ec:	25202c64 	.word	0x25202c64
200268f0:	64000a64 	.word	0x64000a64
200268f4:	63657465 	.word	0x63657465
200268f8:	65722074 	.word	0x65722074
200268fc:	746c7573 	.word	0x746c7573
20026900:	0a642520 	.word	0x0a642520
20026904:	20317600 	.word	0x20317600
20026908:	69206425 	.word	0x69206425
2002690c:	6c62206e 	.word	0x6c62206e
20026910:	6425206b 	.word	0x6425206b
20026914:	3276202c 	.word	0x3276202c
20026918:	20642520 	.word	0x20642520
2002691c:	62206e69 	.word	0x62206e69
20026920:	6b636f6c 	.word	0x6b636f6c
20026924:	0a642520 	.word	0x0a642520
20026928:	65684300 	.word	0x65684300
2002692c:	62206b63 	.word	0x62206b63
20026930:	74206d62 	.word	0x74206d62
20026934:	656c6261 	.word	0x656c6261
20026938:	69616620 	.word	0x69616620
2002693c:	64000a6c 	.word	0x64000a6c
20026940:	63657465 	.word	0x63657465
20026944:	65722074 	.word	0x65722074
20026948:	746c7573 	.word	0x746c7573
2002694c:	20642520 	.word	0x20642520
20026950:	20746f6e 	.word	0x20746f6e
20026954:	73616572 	.word	0x73616572
20026958:	62616e6f 	.word	0x62616e6f
2002695c:	000a656c 	.word	0x000a656c
20026960:	204d4242 	.word	0x204d4242
20026964:	3a4d454d 	.word	0x3a4d454d
20026968:	78746320 	.word	0x78746320
2002696c:	2c702520 	.word	0x2c702520
20026970:	70616d20 	.word	0x70616d20
20026974:	70252031 	.word	0x70252031
20026978:	616d202c 	.word	0x616d202c
2002697c:	25203270 	.word	0x25203270
20026980:	000a2070 	.word	0x000a2070
20026984:	5f666973 	.word	0x5f666973
20026988:	5f6d6262 	.word	0x5f6d6262
2002698c:	74696e69 	.word	0x74696e69
20026990:	6e6f6420 	.word	0x6e6f6420
20026994:	23000a65 	.word	0x23000a65
20026998:	202b302d 	.word	0x202b302d
2002699c:	4c6c6800 	.word	0x4c6c6800
200269a0:	67666500 	.word	0x67666500
200269a4:	00474645 	.word	0x00474645
200269a8:	33323130 	.word	0x33323130
200269ac:	37363534 	.word	0x37363534
200269b0:	42413938 	.word	0x42413938
200269b4:	46454443 	.word	0x46454443
200269b8:	32313000 	.word	0x32313000
200269bc:	36353433 	.word	0x36353433
200269c0:	61393837 	.word	0x61393837
200269c4:	65646362 	.word	0x65646362
200269c8:	00000066 	.word	0x00000066
200269cc:	50042000 	.word	0x50042000
200269d0:	00000002 	.word	0x00000002
200269d4:	12000000 	.word	0x12000000
200269d8:	00000004 	.word	0x00000004
200269dc:	00000000 	.word	0x00000000
200269e0:	50041000 	.word	0x50041000
200269e4:	00000002 	.word	0x00000002
200269e8:	10000000 	.word	0x10000000
200269ec:	00000004 	.word	0x00000004
200269f0:	00000000 	.word	0x00000000
200269f4:	50043000 	.word	0x50043000
200269f8:	00000002 	.word	0x00000002
200269fc:	14000000 	.word	0x14000000
20026a00:	00000004 	.word	0x00000004
20026a04:	00000000 	.word	0x00000000

20026a08 <pad_fsel_func_tbls>:
20026a08:	20027000 20026ff4 20026fe8 20026fdc     .p. .o. .o. .o. 
20026a18:	20026fd0 20026fc4 20026fb8 20026fac     .o. .o. .o. .o. 
20026a28:	20026fa0 20026f90 20026f84 20026f74     .o. .o. .o. to. 
20026a38:	20026f60 20026f58 20026f4c 20026f40     `o. Xo. Lo. @o. 
20026a48:	20026f34 20026f28 20026f1c 20026f0c     4o. (o. .o. .o. 
20026a58:	20026efc 20026eec 20026edc 20026ecc     .n. .n. .n. .n. 
20026a68:	20026ebc 20026ea8 20026e98 20026e8c     .n. .n. .n. .n. 
20026a78:	20026e78 20026e64 20026e50 20026e3c     xn. dn. Pn. <n. 
20026a88:	20026e28 20026e14 20026e00 20026df0     (n. .n. .n. .m. 
20026a98:	20026de4 20026dd0 20026dc0 20026db0     .m. .m. .m. .m. 
20026aa8:	20026da0 20026d90 20026d80 20026d70     .m. .m. .m. pm. 
20026ab8:	20026d60 20026d50 20026d40 20026d38     `m. Pm. @m. 8m. 
20026ac8:	20026d28 20026d18 20026d04 20026cf0     (m. .m. .m. .l. 
20026ad8:	20026ce0 20026cd0 20026cc0 20026cb0     .l. .l. .l. .l. 
20026ae8:	20026ca4 20026c94 20026c88 20026c7c     .l. .l. .l. |l. 
20026af8:	20026c74 20026c6c 20026c64 20026c50     tl. ll. dl. Pl. 
20026b08:	20026c40 20026c2c 20026c18 20026c08     @l. ,l. .l. .l. 
20026b18:	20026bf8 20026be8 20026bd8 20026bcc     .k. .k. .k. .k. 
20026b28:	20026bc0 20026bb4 20026ba8 20026b9c     .k. .k. .k. .k. 
20026b38:	20026b90 20026b88 20026b80 20026b78     .k. .k. .k. xk. 
20026b48:	20026b70 20026b68 20026b60 20026b58     pk. hk. `k. Xk. 

20026b58 <pad_pa57_fsel_func_tbl>:
20026b58:	01670000 00000000                       ..g.....

20026b60 <pad_pa56_fsel_func_tbl>:
20026b60:	01660000 00000000                       ..f.....

20026b68 <pad_pa55_fsel_func_tbl>:
20026b68:	01650000 00000000                       ..e.....

20026b70 <pad_pa54_fsel_func_tbl>:
20026b70:	01640000 00000000                       ..d.....

20026b78 <pad_pa53_fsel_func_tbl>:
20026b78:	01630000 00000000                       ..c.....

20026b80 <pad_pa52_fsel_func_tbl>:
20026b80:	01620000 00000000                       ..b.....

20026b88 <pad_pa51_fsel_func_tbl>:
20026b88:	01610000 00000000                       ..a.....

20026b90 <pad_pa50_fsel_func_tbl>:
20026b90:	01600000 01870003 00000000              ..`.........

20026b9c <pad_pa49_fsel_func_tbl>:
20026b9c:	015f0000 01860003 00000000              .._.........

20026ba8 <pad_pa48_fsel_func_tbl>:
20026ba8:	015e0000 01850003 00000000              ..^.........

20026bb4 <pad_pa47_fsel_func_tbl>:
20026bb4:	015d0000 01830003 00000000              ..].........

20026bc0 <pad_pa46_fsel_func_tbl>:
20026bc0:	015c0000 01890003 00000000              ..\.........

20026bcc <pad_pa45_fsel_func_tbl>:
20026bcc:	015b0000 01880003 00000000              ..[.........

20026bd8 <pad_pa44_fsel_func_tbl>:
20026bd8:	015a0000 018c0001 01b70007 00000000     ..Z.............

20026be8 <pad_pa43_fsel_func_tbl>:
20026be8:	01590000 018b0001 01b60007 00000000     ..Y.............

20026bf8 <pad_pa42_fsel_func_tbl>:
20026bf8:	01580000 017c0002 01b50007 00000000     ..X...|.........

20026c08 <pad_pa41_fsel_func_tbl>:
20026c08:	01570000 017b0002 01b40007 00000000     ..W...{.........

20026c18 <pad_pa40_fsel_func_tbl>:
20026c18:	01560000 01750001 017a0002 01b30007     ..V...u...z.....
20026c28:	00000000                                ....

20026c2c <pad_pa39_fsel_func_tbl>:
20026c2c:	01550000 01740001 01780002 01b20007     ..U...t...x.....
20026c3c:	00000000                                ....

20026c40 <pad_pa38_fsel_func_tbl>:
20026c40:	01540000 01760001 017e0002 00000000     ..T...v...~.....

20026c50 <pad_pa37_fsel_func_tbl>:
20026c50:	01530000 01770001 017d0002 01b10007     ..S...w...}.....
20026c60:	00000000                                ....

20026c64 <pad_pa36_fsel_func_tbl>:
20026c64:	01520000 00000000                       ..R.....

20026c6c <pad_pa35_fsel_func_tbl>:
20026c6c:	01510000 00000000                       ..Q.....

20026c74 <pad_pa34_fsel_func_tbl>:
20026c74:	01500000 00000000                       ..P.....

20026c7c <pad_pa33_fsel_func_tbl>:
20026c7c:	014f0000 01870003 00000000              ..O.........

20026c88 <pad_pa32_fsel_func_tbl>:
20026c88:	014e0000 01860003 00000000              ..N.........

20026c94 <pad_pa31_fsel_func_tbl>:
20026c94:	014d0000 01850003 01b00007 00000000     ..M.............

20026ca4 <pad_pa30_fsel_func_tbl>:
20026ca4:	014c0000 01830003 00000000              ..L.........

20026cb0 <pad_pa29_fsel_func_tbl>:
20026cb0:	014b0000 01710001 01890003 00000000     ..K...q.........

20026cc0 <pad_pa28_fsel_func_tbl>:
20026cc0:	014a0000 01700001 01880003 00000000     ..J...p.........

20026cd0 <pad_pa27_fsel_func_tbl>:
20026cd0:	01490000 017c0002 01870003 00000000     ..I...|.........

20026ce0 <pad_pa26_fsel_func_tbl>:
20026ce0:	01480000 017b0002 01860003 00000000     ..H...{.........

20026cf0 <pad_pa25_fsel_func_tbl>:
20026cf0:	01470000 01720001 017a0002 01850003     ..G...r...z.....
20026d00:	00000000                                ....

20026d04 <pad_pa24_fsel_func_tbl>:
20026d04:	01460000 01730001 01780002 01830003     ..F...s...x.....
20026d14:	00000000                                ....

20026d18 <pad_pa23_fsel_func_tbl>:
20026d18:	01450000 017e0002 01890003 00000000     ..E...~.........

20026d28 <pad_pa22_fsel_func_tbl>:
20026d28:	01440000 017d0002 01880003 00000000     ..D...}.........

20026d38 <pad_pa21_fsel_func_tbl>:
20026d38:	01430000 00000000                       ..C.....

20026d40 <pad_pa20_fsel_func_tbl>:
20026d40:	01420000 018d0001 01b80007 00000000     ..B.............

20026d50 <pad_pa19_fsel_func_tbl>:
20026d50:	01410000 00200001 018c0002 00000000     ..A... .........

20026d60 <pad_pa18_fsel_func_tbl>:
20026d60:	01400000 00210001 018b0002 00000000     ..@...!.........

20026d70 <pad_pa17_fsel_func_tbl>:
20026d70:	013f0000 012d0001 017c0002 00000000     ..?...-...|.....

20026d80 <pad_pa16_fsel_func_tbl>:
20026d80:	013e0000 01260001 017b0002 00000000     ..>...&...{.....

20026d90 <pad_pa15_fsel_func_tbl>:
20026d90:	013d0000 012a0001 017a0002 00000000     ..=...*...z.....

20026da0 <pad_pa14_fsel_func_tbl>:
20026da0:	013c0000 012c0001 01780002 00000000     ..<...,...x.....

20026db0 <pad_pa13_fsel_func_tbl>:
20026db0:	013b0000 012b0001 017e0002 00000000     ..;...+...~.....

20026dc0 <pad_pa12_fsel_func_tbl>:
20026dc0:	013a0000 01270001 017d0002 00000000     ..:...'...}.....

20026dd0 <pad_pa11_fsel_func_tbl>:
20026dd0:	01390000 01280001 017c0002 018a0007     ..9...(...|.....
20026de0:	00000000                                ....

20026de4 <pad_pa10_fsel_func_tbl>:
20026de4:	01380000 017b0002 00000000              ..8...{.....

20026df0 <pad_pa09_fsel_func_tbl>:
20026df0:	01370000 017a0002 01af0007 00000000     ..7...z.........

20026e00 <pad_pa08_fsel_func_tbl>:
20026e00:	01360000 016d0001 01780002 01ae0007     ..6...m...x.....
20026e10:	00000000                                ....

20026e14 <pad_pa07_fsel_func_tbl>:
20026e14:	01350000 016c0001 017e0002 01ad0007     ..5...l...~.....
20026e24:	00000000                                ....

20026e28 <pad_pa06_fsel_func_tbl>:
20026e28:	01340000 016b0001 017d0002 01ac0007     ..4...k...}.....
20026e38:	00000000                                ....

20026e3c <pad_pa05_fsel_func_tbl>:
20026e3c:	01330000 016a0001 01870003 01ab0007     ..3...j.........
20026e4c:	00000000                                ....

20026e50 <pad_pa04_fsel_func_tbl>:
20026e50:	01320000 01690001 01860003 01aa0007     ..2...i.........
20026e60:	00000000                                ....

20026e64 <pad_pa03_fsel_func_tbl>:
20026e64:	01310000 01680001 01850003 01a90007     ..1...h.........
20026e74:	00000000                                ....

20026e78 <pad_pa02_fsel_func_tbl>:
20026e78:	01300000 016f0001 01830003 01a80007     ..0...o.........
20026e88:	00000000                                ....

20026e8c <pad_pa01_fsel_func_tbl>:
20026e8c:	012f0000 01890003 00000000              ../.........

20026e98 <pad_pa00_fsel_func_tbl>:
20026e98:	012e0000 016e0001 01880003 00000000     ......n.........

20026ea8 <pad_sb12_fsel_func_tbl>:
20026ea8:	011a0001 011b0002 01180003 01160004     ................
20026eb8:	00000000                                ....

20026ebc <pad_sb11_fsel_func_tbl>:
20026ebc:	01250001 01160003 01210004 00000000     ..%.......!.....

20026ecc <pad_sb10_fsel_func_tbl>:
20026ecc:	01240001 011b0003 011e0004 00000000     ..$.............

20026edc <pad_sb09_fsel_func_tbl>:
20026edc:	01230001 01250003 01260004 00000000     ..#...%...&.....

20026eec <pad_sb08_fsel_func_tbl>:
20026eec:	01220001 01240003 012d0004 00000000     .."...$...-.....

20026efc <pad_sb07_fsel_func_tbl>:
20026efc:	01160001 01230003 012a0004 00000000     ......#...*.....

20026f0c <pad_sb06_fsel_func_tbl>:
20026f0c:	01170001 01220003 01180004 00000000     ......".........

20026f1c <pad_sb05_fsel_func_tbl>:
20026f1c:	01180001 011f0004 00000000              ............

20026f28 <pad_sb04_fsel_func_tbl>:
20026f28:	01210001 01200004 00000000              ..!... .....

20026f34 <pad_sb03_fsel_func_tbl>:
20026f34:	01200001 01270004 00000000              .. ...'.....

20026f40 <pad_sb02_fsel_func_tbl>:
20026f40:	011f0001 012b0004 00000000              ......+.....

20026f4c <pad_sb01_fsel_func_tbl>:
20026f4c:	011e0001 012c0004 00000000              ......,.....

20026f58 <pad_sb00_fsel_func_tbl>:
20026f58:	01190001 00000000                       ........

20026f60 <pad_sa12_fsel_func_tbl>:
20026f60:	010a0001 010b0002 01080003 01020004     ................
20026f70:	00000000                                ....

20026f74 <pad_sa11_fsel_func_tbl>:
20026f74:	01150001 01060003 01050004 00000000     ................

20026f84 <pad_sa10_fsel_func_tbl>:
20026f84:	01140001 01000004 00000000              ............

20026f90 <pad_sa09_fsel_func_tbl>:
20026f90:	01130001 010b0003 01050004 00000000     ................

20026fa0 <pad_sa08_fsel_func_tbl>:
20026fa0:	01120001 01150003 00000000              ............

20026fac <pad_sa07_fsel_func_tbl>:
20026fac:	01060001 01140003 00000000              ............

20026fb8 <pad_sa06_fsel_func_tbl>:
20026fb8:	01070001 01130003 00000000              ............

20026fc4 <pad_sa05_fsel_func_tbl>:
20026fc4:	01080001 01120003 00000000              ............

20026fd0 <pad_sa04_fsel_func_tbl>:
20026fd0:	01110001 01040004 00000000              ............

20026fdc <pad_sa03_fsel_func_tbl>:
20026fdc:	01100001 01010004 00000000              ............

20026fe8 <pad_sa02_fsel_func_tbl>:
20026fe8:	010f0001 01030004 00000000              ............

20026ff4 <pad_sa01_fsel_func_tbl>:
20026ff4:	010e0001 01040004 00000000              ............

20027000 <pad_sa00_fsel_func_tbl>:
20027000:	01090001 01010004 00000000 00000000     ................
20027010:	04030201 00000000 01060204              ............

2002701c <hpsys_dll2_limit>:
	...
20027024:	112a8800 112a8800                       ..*...*.

2002702c <hpsys_dvfs_config>:
2002702c:	000906fb 00100330 000a08fd 00110331     ....0.......1...
2002703c:	000d0b00 00130213 000f0e02 00130213     ................

2002704c <crc32tab>:
2002704c:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
2002705c:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
2002706c:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
2002707c:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
2002708c:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
2002709c:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
200270ac:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
200270bc:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
200270cc:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
200270dc:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
200270ec:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
200270fc:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
2002710c:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
2002711c:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
2002712c:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
2002713c:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
2002714c:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
2002715c:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
2002716c:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
2002717c:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
2002718c:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
2002719c:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
200271ac:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
200271bc:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
200271cc:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
200271dc:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
200271ec:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
200271fc:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
2002720c:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
2002721c:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
2002722c:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
2002723c:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
2002724c:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
2002725c:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
2002726c:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
2002727c:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
2002728c:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
2002729c:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
200272ac:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
200272bc:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
200272cc:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
200272dc:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
200272ec:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
200272fc:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
2002730c:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
2002731c:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
2002732c:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
2002733c:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
2002734c:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
2002735c:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
2002736c:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
2002737c:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
2002738c:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
2002739c:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
200273ac:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
200273bc:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
200273cc:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
200273dc:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
200273ec:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
200273fc:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
2002740c:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
2002741c:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
2002742c:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
2002743c:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

2002744c <_init>:
2002744c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002744e:	bf00      	nop
20027450:	bcf8      	pop	{r3, r4, r5, r6, r7}
20027452:	bc08      	pop	{r3}
20027454:	469e      	mov	lr, r3
20027456:	4770      	bx	lr

20027458 <_fini>:
20027458:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002745a:	bf00      	nop
2002745c:	bcf8      	pop	{r3, r4, r5, r6, r7}
2002745e:	bc08      	pop	{r3}
20027460:	469e      	mov	lr, r3
20027462:	4770      	bx	lr

20027464 <__EH_FRAME_BEGIN__>:
20027464:	0000 0000                                   ....

Disassembly of section .l1_ret_text_bsp_psram_init_info:

20027468 <bsp_psram_init_info>:
20027468:	b507      	push	{r0, r1, r2, lr}
2002746a:	2208      	movs	r2, #8
2002746c:	f10d 0107 	add.w	r1, sp, #7
20027470:	20e4      	movs	r0, #228	@ 0xe4
20027472:	f000 f9b1 	bl	200277d8 <HAL_EFUSE_Read2>
20027476:	2807      	cmp	r0, #7
20027478:	bfc1      	itttt	gt
2002747a:	f89d 3007 	ldrbgt.w	r3, [sp, #7]
2002747e:	4a06      	ldrgt	r2, [pc, #24]	@ (20027498 <bsp_psram_init_info+0x30>)
20027480:	f3c3 1301 	ubfxgt	r3, r3, #4, #2
20027484:	2000      	movgt	r0, #0
20027486:	bfd1      	iteee	le
20027488:	f06f 0001 	mvnle.w	r0, #1
2002748c:	7053      	strbgt	r3, [r2, #1]
2002748e:	2301      	movgt	r3, #1
20027490:	7013      	strbgt	r3, [r2, #0]
20027492:	b003      	add	sp, #12
20027494:	f85d fb04 	ldr.w	pc, [sp], #4
20027498:	2004c990 	.word	0x2004c990

Disassembly of section .l1_ret_text_bsp_psram_get_mpi_mode:

2002749c <bsp_psram_get_mpi_mode>:
2002749c:	2801      	cmp	r0, #1
2002749e:	b510      	push	{r4, lr}
200274a0:	d001      	beq.n	200274a6 <bsp_psram_get_mpi_mode+0xa>
200274a2:	2000      	movs	r0, #0
200274a4:	bd10      	pop	{r4, pc}
200274a6:	4c07      	ldr	r4, [pc, #28]	@ (200274c4 <bsp_psram_get_mpi_mode+0x28>)
200274a8:	7823      	ldrb	r3, [r4, #0]
200274aa:	b12b      	cbz	r3, 200274b8 <bsp_psram_get_mpi_mode+0x1c>
200274ac:	7863      	ldrb	r3, [r4, #1]
200274ae:	4a06      	ldr	r2, [pc, #24]	@ (200274c8 <bsp_psram_get_mpi_mode+0x2c>)
200274b0:	5cd0      	ldrb	r0, [r2, r3]
200274b2:	f000 000f 	and.w	r0, r0, #15
200274b6:	e7f5      	b.n	200274a4 <bsp_psram_get_mpi_mode+0x8>
200274b8:	f7ff ffd6 	bl	20027468 <bsp_psram_init_info>
200274bc:	2800      	cmp	r0, #0
200274be:	d0f5      	beq.n	200274ac <bsp_psram_get_mpi_mode+0x10>
200274c0:	e7ef      	b.n	200274a2 <bsp_psram_get_mpi_mode+0x6>
200274c2:	bf00      	nop
200274c4:	2004c990 	.word	0x2004c990
200274c8:	200278f8 	.word	0x200278f8

Disassembly of section .l1_ret_text_bsp_psram1_pinmux_init:

200274cc <bsp_psram1_pinmux_init>:
200274cc:	b538      	push	{r3, r4, r5, lr}
200274ce:	4c9c      	ldr	r4, [pc, #624]	@ (20027740 <bsp_psram1_pinmux_init+0x274>)
200274d0:	7823      	ldrb	r3, [r4, #0]
200274d2:	2b00      	cmp	r3, #0
200274d4:	d07b      	beq.n	200275ce <bsp_psram1_pinmux_init+0x102>
200274d6:	7863      	ldrb	r3, [r4, #1]
200274d8:	4a9a      	ldr	r2, [pc, #616]	@ (20027744 <bsp_psram1_pinmux_init+0x278>)
200274da:	5cd4      	ldrb	r4, [r2, r3]
200274dc:	0924      	lsrs	r4, r4, #4
200274de:	2c01      	cmp	r4, #1
200274e0:	d17d      	bne.n	200275de <bsp_psram1_pinmux_init+0x112>
200274e2:	4623      	mov	r3, r4
200274e4:	f44f 7280 	mov.w	r2, #256	@ 0x100
200274e8:	f44f 7187 	mov.w	r1, #270	@ 0x10e
200274ec:	2002      	movs	r0, #2
200274ee:	f7fc fea9 	bl	20024244 <HAL_PIN_Set>
200274f2:	4623      	mov	r3, r4
200274f4:	f44f 7280 	mov.w	r2, #256	@ 0x100
200274f8:	f240 110f 	movw	r1, #271	@ 0x10f
200274fc:	2003      	movs	r0, #3
200274fe:	f7fc fea1 	bl	20024244 <HAL_PIN_Set>
20027502:	4623      	mov	r3, r4
20027504:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027508:	f44f 7188 	mov.w	r1, #272	@ 0x110
2002750c:	2004      	movs	r0, #4
2002750e:	f7fc fe99 	bl	20024244 <HAL_PIN_Set>
20027512:	4623      	mov	r3, r4
20027514:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027518:	f240 1111 	movw	r1, #273	@ 0x111
2002751c:	2005      	movs	r0, #5
2002751e:	f7fc fe91 	bl	20024244 <HAL_PIN_Set>
20027522:	4623      	mov	r3, r4
20027524:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027528:	f44f 7189 	mov.w	r1, #274	@ 0x112
2002752c:	2009      	movs	r0, #9
2002752e:	f7fc fe89 	bl	20024244 <HAL_PIN_Set>
20027532:	4623      	mov	r3, r4
20027534:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027538:	f240 1113 	movw	r1, #275	@ 0x113
2002753c:	200a      	movs	r0, #10
2002753e:	f7fc fe81 	bl	20024244 <HAL_PIN_Set>
20027542:	4623      	mov	r3, r4
20027544:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027548:	f44f 718a 	mov.w	r1, #276	@ 0x114
2002754c:	200b      	movs	r0, #11
2002754e:	f7fc fe79 	bl	20024244 <HAL_PIN_Set>
20027552:	4623      	mov	r3, r4
20027554:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027558:	f240 1115 	movw	r1, #277	@ 0x115
2002755c:	200c      	movs	r0, #12
2002755e:	f7fc fe71 	bl	20024244 <HAL_PIN_Set>
20027562:	4623      	mov	r3, r4
20027564:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027568:	f240 1109 	movw	r1, #265	@ 0x109
2002756c:	4620      	mov	r0, r4
2002756e:	f7fc fe69 	bl	20024244 <HAL_PIN_Set>
20027572:	4623      	mov	r3, r4
20027574:	2200      	movs	r2, #0
20027576:	f44f 7184 	mov.w	r1, #264	@ 0x108
2002757a:	2006      	movs	r0, #6
2002757c:	f7fc fe62 	bl	20024244 <HAL_PIN_Set>
20027580:	4623      	mov	r3, r4
20027582:	2200      	movs	r2, #0
20027584:	f240 1107 	movw	r1, #263	@ 0x107
20027588:	2007      	movs	r0, #7
2002758a:	f7fc fe5b 	bl	20024244 <HAL_PIN_Set>
2002758e:	4623      	mov	r3, r4
20027590:	2200      	movs	r2, #0
20027592:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027596:	2008      	movs	r0, #8
20027598:	f7fc fe54 	bl	20024244 <HAL_PIN_Set>
2002759c:	4623      	mov	r3, r4
2002759e:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275a2:	f44f 7185 	mov.w	r1, #266	@ 0x10a
200275a6:	200d      	movs	r0, #13
200275a8:	f7fc fe4c 	bl	20024244 <HAL_PIN_Set>
200275ac:	2500      	movs	r5, #0
200275ae:	2400      	movs	r4, #0
200275b0:	2201      	movs	r2, #1
200275b2:	3401      	adds	r4, #1
200275b4:	4611      	mov	r1, r2
200275b6:	4620      	mov	r0, r4
200275b8:	f7fc fe74 	bl	200242a4 <HAL_PIN_Set_DS0>
200275bc:	2200      	movs	r2, #0
200275be:	2101      	movs	r1, #1
200275c0:	4620      	mov	r0, r4
200275c2:	f7fc fe85 	bl	200242d0 <HAL_PIN_Set_DS1>
200275c6:	2c0d      	cmp	r4, #13
200275c8:	d1f2      	bne.n	200275b0 <bsp_psram1_pinmux_init+0xe4>
200275ca:	4628      	mov	r0, r5
200275cc:	bd38      	pop	{r3, r4, r5, pc}
200275ce:	f7ff ff4b 	bl	20027468 <bsp_psram_init_info>
200275d2:	2800      	cmp	r0, #0
200275d4:	f43f af7f 	beq.w	200274d6 <bsp_psram1_pinmux_init+0xa>
200275d8:	f06f 0501 	mvn.w	r5, #1
200275dc:	e7f5      	b.n	200275ca <bsp_psram1_pinmux_init+0xfe>
200275de:	2c02      	cmp	r4, #2
200275e0:	d153      	bne.n	2002768a <bsp_psram1_pinmux_init+0x1be>
200275e2:	2301      	movs	r3, #1
200275e4:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275e8:	f44f 7187 	mov.w	r1, #270	@ 0x10e
200275ec:	4620      	mov	r0, r4
200275ee:	f7fc fe29 	bl	20024244 <HAL_PIN_Set>
200275f2:	2301      	movs	r3, #1
200275f4:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275f8:	f240 110f 	movw	r1, #271	@ 0x10f
200275fc:	2003      	movs	r0, #3
200275fe:	f7fc fe21 	bl	20024244 <HAL_PIN_Set>
20027602:	2301      	movs	r3, #1
20027604:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027608:	f44f 7188 	mov.w	r1, #272	@ 0x110
2002760c:	2004      	movs	r0, #4
2002760e:	f7fc fe19 	bl	20024244 <HAL_PIN_Set>
20027612:	2301      	movs	r3, #1
20027614:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027618:	f240 1111 	movw	r1, #273	@ 0x111
2002761c:	2005      	movs	r0, #5
2002761e:	f7fc fe11 	bl	20024244 <HAL_PIN_Set>
20027622:	2301      	movs	r3, #1
20027624:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027628:	f44f 7189 	mov.w	r1, #274	@ 0x112
2002762c:	2009      	movs	r0, #9
2002762e:	f7fc fe09 	bl	20024244 <HAL_PIN_Set>
20027632:	2301      	movs	r3, #1
20027634:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027638:	f240 1113 	movw	r1, #275	@ 0x113
2002763c:	200a      	movs	r0, #10
2002763e:	f7fc fe01 	bl	20024244 <HAL_PIN_Set>
20027642:	2301      	movs	r3, #1
20027644:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027648:	f44f 718a 	mov.w	r1, #276	@ 0x114
2002764c:	200b      	movs	r0, #11
2002764e:	f7fc fdf9 	bl	20024244 <HAL_PIN_Set>
20027652:	2301      	movs	r3, #1
20027654:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027658:	f240 1115 	movw	r1, #277	@ 0x115
2002765c:	200c      	movs	r0, #12
2002765e:	f7fc fdf1 	bl	20024244 <HAL_PIN_Set>
20027662:	2301      	movs	r3, #1
20027664:	2200      	movs	r2, #0
20027666:	f44f 7184 	mov.w	r1, #264	@ 0x108
2002766a:	2006      	movs	r0, #6
2002766c:	f7fc fdea 	bl	20024244 <HAL_PIN_Set>
20027670:	2301      	movs	r3, #1
20027672:	2200      	movs	r2, #0
20027674:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027678:	2008      	movs	r0, #8
2002767a:	f7fc fde3 	bl	20024244 <HAL_PIN_Set>
2002767e:	2301      	movs	r3, #1
20027680:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027684:	f240 110b 	movw	r1, #267	@ 0x10b
20027688:	e78d      	b.n	200275a6 <bsp_psram1_pinmux_init+0xda>
2002768a:	2c03      	cmp	r4, #3
2002768c:	d154      	bne.n	20027738 <bsp_psram1_pinmux_init+0x26c>
2002768e:	2301      	movs	r3, #1
20027690:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027694:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027698:	2002      	movs	r0, #2
2002769a:	f7fc fdd3 	bl	20024244 <HAL_PIN_Set>
2002769e:	2301      	movs	r3, #1
200276a0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276a4:	f240 110f 	movw	r1, #271	@ 0x10f
200276a8:	4620      	mov	r0, r4
200276aa:	f7fc fdcb 	bl	20024244 <HAL_PIN_Set>
200276ae:	2301      	movs	r3, #1
200276b0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276b4:	f44f 7188 	mov.w	r1, #272	@ 0x110
200276b8:	2004      	movs	r0, #4
200276ba:	f7fc fdc3 	bl	20024244 <HAL_PIN_Set>
200276be:	2301      	movs	r3, #1
200276c0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276c4:	f240 1111 	movw	r1, #273	@ 0x111
200276c8:	2005      	movs	r0, #5
200276ca:	f7fc fdbb 	bl	20024244 <HAL_PIN_Set>
200276ce:	2301      	movs	r3, #1
200276d0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276d4:	f44f 7189 	mov.w	r1, #274	@ 0x112
200276d8:	2006      	movs	r0, #6
200276da:	f7fc fdb3 	bl	20024244 <HAL_PIN_Set>
200276de:	2301      	movs	r3, #1
200276e0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276e4:	f240 1113 	movw	r1, #275	@ 0x113
200276e8:	2007      	movs	r0, #7
200276ea:	f7fc fdab 	bl	20024244 <HAL_PIN_Set>
200276ee:	2301      	movs	r3, #1
200276f0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276f4:	f44f 718a 	mov.w	r1, #276	@ 0x114
200276f8:	2008      	movs	r0, #8
200276fa:	f7fc fda3 	bl	20024244 <HAL_PIN_Set>
200276fe:	2301      	movs	r3, #1
20027700:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027704:	f240 1115 	movw	r1, #277	@ 0x115
20027708:	2009      	movs	r0, #9
2002770a:	f7fc fd9b 	bl	20024244 <HAL_PIN_Set>
2002770e:	2301      	movs	r3, #1
20027710:	2200      	movs	r2, #0
20027712:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027716:	200d      	movs	r0, #13
20027718:	f7fc fd94 	bl	20024244 <HAL_PIN_Set>
2002771c:	2301      	movs	r3, #1
2002771e:	2200      	movs	r2, #0
20027720:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027724:	200c      	movs	r0, #12
20027726:	f7fc fd8d 	bl	20024244 <HAL_PIN_Set>
2002772a:	2301      	movs	r3, #1
2002772c:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027730:	f240 110b 	movw	r1, #267	@ 0x10b
20027734:	200a      	movs	r0, #10
20027736:	e737      	b.n	200275a8 <bsp_psram1_pinmux_init+0xdc>
20027738:	f04f 35ff 	mov.w	r5, #4294967295
2002773c:	e737      	b.n	200275ae <bsp_psram1_pinmux_init+0xe2>
2002773e:	bf00      	nop
20027740:	2004c990 	.word	0x2004c990
20027744:	200278f8 	.word	0x200278f8

Disassembly of section .l1_ret_text_HAL_EFUSE_Extract:

20027748 <HAL_EFUSE_Extract>:
20027748:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
2002774c:	2800      	cmp	r0, #0
2002774e:	d041      	beq.n	200277d4 <HAL_EFUSE_Extract+0x8c>
20027750:	2a00      	cmp	r2, #0
20027752:	d03f      	beq.n	200277d4 <HAL_EFUSE_Extract+0x8c>
20027754:	18cc      	adds	r4, r1, r3
20027756:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
2002775a:	dc3b      	bgt.n	200277d4 <HAL_EFUSE_Extract+0x8c>
2002775c:	2400      	movs	r4, #0
2002775e:	46a4      	mov	ip, r4
20027760:	094e      	lsrs	r6, r1, #5
20027762:	1ddd      	adds	r5, r3, #7
20027764:	f850 7026 	ldr.w	r7, [r0, r6, lsl #2]
20027768:	f001 011f 	and.w	r1, r1, #31
2002776c:	f3c5 05cf 	ubfx	r5, r5, #3, #16
20027770:	42a5      	cmp	r5, r4
20027772:	d807      	bhi.n	20027784 <HAL_EFUSE_Extract+0x3c>
20027774:	2400      	movs	r4, #0
20027776:	46a6      	mov	lr, r4
20027778:	46a4      	mov	ip, r4
2002777a:	459c      	cmp	ip, r3
2002777c:	d106      	bne.n	2002778c <HAL_EFUSE_Extract+0x44>
2002777e:	4618      	mov	r0, r3
20027780:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027784:	f802 c004 	strb.w	ip, [r2, r4]
20027788:	3401      	adds	r4, #1
2002778a:	e7f1      	b.n	20027770 <HAL_EFUSE_Extract+0x28>
2002778c:	fa27 f501 	lsr.w	r5, r7, r1
20027790:	3101      	adds	r1, #1
20027792:	f812 800e 	ldrb.w	r8, [r2, lr]
20027796:	b289      	uxth	r1, r1
20027798:	f005 0501 	and.w	r5, r5, #1
2002779c:	2920      	cmp	r1, #32
2002779e:	fa05 f504 	lsl.w	r5, r5, r4
200277a2:	bf08      	it	eq
200277a4:	3601      	addeq	r6, #1
200277a6:	ea45 0508 	orr.w	r5, r5, r8
200277aa:	f104 0401 	add.w	r4, r4, #1
200277ae:	b2a4      	uxth	r4, r4
200277b0:	f802 500e 	strb.w	r5, [r2, lr]
200277b4:	bf02      	ittt	eq
200277b6:	b2b6      	uxtheq	r6, r6
200277b8:	2100      	moveq	r1, #0
200277ba:	f850 7026 	ldreq.w	r7, [r0, r6, lsl #2]
200277be:	2c08      	cmp	r4, #8
200277c0:	bf04      	itt	eq
200277c2:	f10e 0401 	addeq.w	r4, lr, #1
200277c6:	fa1f fe84 	uxtheq.w	lr, r4
200277ca:	f10c 0c01 	add.w	ip, ip, #1
200277ce:	bf08      	it	eq
200277d0:	2400      	moveq	r4, #0
200277d2:	e7d2      	b.n	2002777a <HAL_EFUSE_Extract+0x32>
200277d4:	2300      	movs	r3, #0
200277d6:	e7d2      	b.n	2002777e <HAL_EFUSE_Extract+0x36>

Disassembly of section .l1_ret_text_HAL_EFUSE_Read2:

200277d8 <HAL_EFUSE_Read2>:
200277d8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200277dc:	fa52 f380 	uxtab	r3, r2, r0
200277e0:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
200277e4:	4605      	mov	r5, r0
200277e6:	4688      	mov	r8, r1
200277e8:	4617      	mov	r7, r2
200277ea:	fa5f f980 	uxtb.w	r9, r0
200277ee:	dc1e      	bgt.n	2002782e <HAL_EFUSE_Read2+0x56>
200277f0:	f5b0 7f40 	cmp.w	r0, #768	@ 0x300
200277f4:	d21b      	bcs.n	2002782e <HAL_EFUSE_Read2+0x56>
200277f6:	2003      	movs	r0, #3
200277f8:	f7f9 ffbc 	bl	20021774 <pmu_ldo_inc>
200277fc:	4c15      	ldr	r4, [pc, #84]	@ (20027854 <HAL_EFUSE_Read2+0x7c>)
200277fe:	0a2d      	lsrs	r5, r5, #8
20027800:	00ab      	lsls	r3, r5, #2
20027802:	6023      	str	r3, [r4, #0]
20027804:	6823      	ldr	r3, [r4, #0]
20027806:	4606      	mov	r6, r0
20027808:	f043 0301 	orr.w	r3, r3, #1
2002780c:	6023      	str	r3, [r4, #0]
2002780e:	2300      	movs	r3, #0
20027810:	4911      	ldr	r1, [pc, #68]	@ (20027858 <HAL_EFUSE_Read2+0x80>)
20027812:	68a2      	ldr	r2, [r4, #8]
20027814:	07d2      	lsls	r2, r2, #31
20027816:	d401      	bmi.n	2002781c <HAL_EFUSE_Read2+0x44>
20027818:	428b      	cmp	r3, r1
2002781a:	d10c      	bne.n	20027836 <HAL_EFUSE_Read2+0x5e>
2002781c:	68a2      	ldr	r2, [r4, #8]
2002781e:	428b      	cmp	r3, r1
20027820:	f042 0201 	orr.w	r2, r2, #1
20027824:	60a2      	str	r2, [r4, #8]
20027826:	d108      	bne.n	2002783a <HAL_EFUSE_Read2+0x62>
20027828:	4630      	mov	r0, r6
2002782a:	f7f9 ffa5 	bl	20021778 <pmu_ldo_recover>
2002782e:	2400      	movs	r4, #0
20027830:	4620      	mov	r0, r4
20027832:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20027836:	3301      	adds	r3, #1
20027838:	e7eb      	b.n	20027812 <HAL_EFUSE_Read2+0x3a>
2002783a:	4808      	ldr	r0, [pc, #32]	@ (2002785c <HAL_EFUSE_Read2+0x84>)
2002783c:	463b      	mov	r3, r7
2002783e:	4642      	mov	r2, r8
20027840:	4649      	mov	r1, r9
20027842:	eb00 1045 	add.w	r0, r0, r5, lsl #5
20027846:	f7ff ff7f 	bl	20027748 <HAL_EFUSE_Extract>
2002784a:	4604      	mov	r4, r0
2002784c:	4630      	mov	r0, r6
2002784e:	f7f9 ff93 	bl	20021778 <pmu_ldo_recover>
20027852:	e7ed      	b.n	20027830 <HAL_EFUSE_Read2+0x58>
20027854:	5000c000 	.word	0x5000c000
20027858:	00bb8000 	.word	0x00bb8000
2002785c:	5000c030 	.word	0x5000c030

Disassembly of section .l1_ret_text_HAL_Set_backup:

20027860 <HAL_Set_backup>:
20027860:	4b01      	ldr	r3, [pc, #4]	@ (20027868 <HAL_Set_backup+0x8>)
20027862:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
20027866:	4770      	bx	lr
20027868:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

2002786c <HAL_Get_backup>:
2002786c:	4b01      	ldr	r3, [pc, #4]	@ (20027874 <HAL_Get_backup+0x8>)
2002786e:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
20027872:	4770      	bx	lr
20027874:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

20027878 <HAL_PMU_GetHpsysVoutRef>:
20027878:	4b04      	ldr	r3, [pc, #16]	@ (2002788c <HAL_PMU_GetHpsysVoutRef+0x14>)
2002787a:	781a      	ldrb	r2, [r3, #0]
2002787c:	b122      	cbz	r2, 20027888 <HAL_PMU_GetHpsysVoutRef+0x10>
2002787e:	b118      	cbz	r0, 20027888 <HAL_PMU_GetHpsysVoutRef+0x10>
20027880:	78db      	ldrb	r3, [r3, #3]
20027882:	7003      	strb	r3, [r0, #0]
20027884:	2000      	movs	r0, #0
20027886:	4770      	bx	lr
20027888:	2001      	movs	r0, #1
2002788a:	4770      	bx	lr
2002788c:	2004ca5c 	.word	0x2004ca5c

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

20027890 <HAL_PMU_GetHpsysVoutRef2>:
20027890:	4b04      	ldr	r3, [pc, #16]	@ (200278a4 <HAL_PMU_GetHpsysVoutRef2+0x14>)
20027892:	781a      	ldrb	r2, [r3, #0]
20027894:	b122      	cbz	r2, 200278a0 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027896:	b118      	cbz	r0, 200278a0 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027898:	7b5b      	ldrb	r3, [r3, #13]
2002789a:	7003      	strb	r3, [r0, #0]
2002789c:	2000      	movs	r0, #0
2002789e:	4770      	bx	lr
200278a0:	2001      	movs	r0, #1
200278a2:	4770      	bx	lr
200278a4:	2004ca5c 	.word	0x2004ca5c

Disassembly of section .l1_ret_text_HAL_PMU_ConfigPeriLdo:

200278a8 <HAL_PMU_ConfigPeriLdo>:
200278a8:	2810      	cmp	r0, #16
200278aa:	b510      	push	{r4, lr}
200278ac:	d81e      	bhi.n	200278ec <HAL_PMU_ConfigPeriLdo+0x44>
200278ae:	4b10      	ldr	r3, [pc, #64]	@ (200278f0 <HAL_PMU_ConfigPeriLdo+0x48>)
200278b0:	40c3      	lsrs	r3, r0
200278b2:	07db      	lsls	r3, r3, #31
200278b4:	d51a      	bpl.n	200278ec <HAL_PMU_ConfigPeriLdo+0x44>
200278b6:	2900      	cmp	r1, #0
200278b8:	bf0c      	ite	eq
200278ba:	2104      	moveq	r1, #4
200278bc:	2101      	movne	r1, #1
200278be:	4081      	lsls	r1, r0
200278c0:	b158      	cbz	r0, 200278da <HAL_PMU_ConfigPeriLdo+0x32>
200278c2:	2305      	movs	r3, #5
200278c4:	fa03 f000 	lsl.w	r0, r3, r0
200278c8:	4c0a      	ldr	r4, [pc, #40]	@ (200278f4 <HAL_PMU_ConfigPeriLdo+0x4c>)
200278ca:	6e23      	ldr	r3, [r4, #96]	@ 0x60
200278cc:	ea23 0300 	bic.w	r3, r3, r0
200278d0:	430b      	orrs	r3, r1
200278d2:	6623      	str	r3, [r4, #96]	@ 0x60
200278d4:	b92a      	cbnz	r2, 200278e2 <HAL_PMU_ConfigPeriLdo+0x3a>
200278d6:	2000      	movs	r0, #0
200278d8:	bd10      	pop	{r4, pc}
200278da:	207d      	movs	r0, #125	@ 0x7d
200278dc:	f041 0170 	orr.w	r1, r1, #112	@ 0x70
200278e0:	e7f2      	b.n	200278c8 <HAL_PMU_ConfigPeriLdo+0x20>
200278e2:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
200278e6:	f7fa f83e 	bl	20021966 <HAL_Delay_us>
200278ea:	e7f4      	b.n	200278d6 <HAL_PMU_ConfigPeriLdo+0x2e>
200278ec:	2001      	movs	r0, #1
200278ee:	e7f3      	b.n	200278d8 <HAL_PMU_ConfigPeriLdo+0x30>
200278f0:	00010101 	.word	0x00010101
200278f4:	500ca000 	.word	0x500ca000
