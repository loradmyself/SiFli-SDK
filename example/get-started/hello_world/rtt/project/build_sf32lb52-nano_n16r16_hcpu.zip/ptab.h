#ifndef __PTAB__H__
#define __PTAB__H__




/* mpi2 */
#undef  HCPU_FLASH_CODE_START_ADDR
#define HCPU_FLASH_CODE_START_ADDR                         (0x12020000)
#undef  HCPU_FLASH_CODE_SIZE
#define HCPU_FLASH_CODE_SIZE                               (0x00700000)
#undef  HCPU_FLASH_CODE_OFFSET
#define HCPU_FLASH_CODE_OFFSET                             (0x00020000)
#undef  HCPU_FLASH_CODE_MEM_TYPE
#define HCPU_FLASH_CODE_MEM_TYPE                           HAL_MEM_TYPE_NOR_FLASH
#undef  DFU_FLASH_CODE_START_ADDR
#define DFU_FLASH_CODE_START_ADDR                          (0x12720000)
#undef  DFU_FLASH_CODE_SIZE
#define DFU_FLASH_CODE_SIZE                                (0x00060000)
#undef  DFU_FLASH_CODE_OFFSET
#define DFU_FLASH_CODE_OFFSET                              (0x00720000)
#undef  DFU_FLASH_CODE_MEM_TYPE
#define DFU_FLASH_CODE_MEM_TYPE                            HAL_MEM_TYPE_NOR_FLASH
#undef  DFU_DOWNLOAD_REGION_START_ADDR
#define DFU_DOWNLOAD_REGION_START_ADDR                     (0x12780000)
#undef  DFU_DOWNLOAD_REGION_SIZE
#define DFU_DOWNLOAD_REGION_SIZE                           (0x00120000)
#undef  DFU_DOWNLOAD_REGION_OFFSET
#define DFU_DOWNLOAD_REGION_OFFSET                         (0x00780000)
#undef  DFU_DOWNLOAD_REGION_MEM_TYPE
#define DFU_DOWNLOAD_REGION_MEM_TYPE                       HAL_MEM_TYPE_NOR_FLASH
#undef  FS_REGION_START_ADDR
#define FS_REGION_START_ADDR                               (0x128A0000)
#undef  FS_REGION_SIZE
#define FS_REGION_SIZE                                     (0x00400000)
#undef  FS_REGION_OFFSET
#define FS_REGION_OFFSET                                   (0x008A0000)
#undef  FS_REGION_MEM_TYPE
#define FS_REGION_MEM_TYPE                                 HAL_MEM_TYPE_NOR_FLASH
#undef  FS_REGION_START_ADDR
#define FS_REGION_START_ADDR                               (0x128A0000)
#undef  FS_REGION_SIZE
#define FS_REGION_SIZE                                     (0x00400000)
#undef  FS_REGION_OFFSET
#define FS_REGION_OFFSET                                   (0x008A0000)
#undef  FS_REGION_MEM_TYPE
#define FS_REGION_MEM_TYPE                                 HAL_MEM_TYPE_NOR_FLASH
#undef  DFU_START_ADDR
#define DFU_START_ADDR                                     (0x12CA0000)
#undef  DFU_SIZE
#define DFU_SIZE                                           (0x00004000)
#undef  DFU_OFFSET
#define DFU_OFFSET                                         (0x00CA0000)
#undef  DFU_MEM_TYPE
#define DFU_MEM_TYPE                                       HAL_MEM_TYPE_NOR_FLASH
#undef  KVDB_DFU_REGION_START_ADDR
#define KVDB_DFU_REGION_START_ADDR                         (0x12CA0000)
#undef  KVDB_DFU_REGION_OFFSET
#define KVDB_DFU_REGION_OFFSET                             (0x00CA0000)
#undef  KVDB_DFU_REGION_SIZE
#define KVDB_DFU_REGION_SIZE                               (0x00004000)
#undef  KVDB_DFU_REGION_MEM_TYPE
#define KVDB_DFU_REGION_MEM_TYPE                           HAL_MEM_TYPE_NOR_FLASH
#undef  BLE_START_ADDR
#define BLE_START_ADDR                                     (0x12CA4000)
#undef  BLE_SIZE
#define BLE_SIZE                                           (0x00004000)
#undef  BLE_OFFSET
#define BLE_OFFSET                                         (0x00CA4000)
#undef  BLE_MEM_TYPE
#define BLE_MEM_TYPE                                       HAL_MEM_TYPE_NOR_FLASH
#undef  KVDB_BLE_REGION_START_ADDR
#define KVDB_BLE_REGION_START_ADDR                         (0x12CA4000)
#undef  KVDB_BLE_REGION_OFFSET
#define KVDB_BLE_REGION_OFFSET                             (0x00CA4000)
#undef  KVDB_BLE_REGION_SIZE
#define KVDB_BLE_REGION_SIZE                               (0x00004000)
#undef  KVDB_BLE_REGION_MEM_TYPE
#define KVDB_BLE_REGION_MEM_TYPE                           HAL_MEM_TYPE_NOR_FLASH
#undef  FLASH_TABLE_START_ADDR
#define FLASH_TABLE_START_ADDR                             (0x12000000)
#undef  FLASH_TABLE_SIZE
#define FLASH_TABLE_SIZE                                   (0x00008000)
#undef  FLASH_TABLE_OFFSET
#define FLASH_TABLE_OFFSET                                 (0x00000000)
#undef  FLASH_TABLE_MEM_TYPE
#define FLASH_TABLE_MEM_TYPE                               HAL_MEM_TYPE_NOR_FLASH
#undef  BOOTLOADER_START_ADDR
#define BOOTLOADER_START_ADDR                              (0x12010000)
#undef  BOOTLOADER_SIZE
#define BOOTLOADER_SIZE                                    (0x00010000)
#undef  BOOTLOADER_OFFSET
#define BOOTLOADER_OFFSET                                  (0x00010000)
#undef  BOOTLOADER_MEM_TYPE
#define BOOTLOADER_MEM_TYPE                                HAL_MEM_TYPE_NOR_FLASH
#undef  FLASH_BOOT_LOADER_START_ADDR
#define FLASH_BOOT_LOADER_START_ADDR                       (0x12010000)
#undef  FLASH_BOOT_LOADER_SIZE
#define FLASH_BOOT_LOADER_SIZE                             (0x00010000)
#undef  FLASH_BOOT_LOADER_OFFSET
#define FLASH_BOOT_LOADER_OFFSET                           (0x00010000)
#undef  FLASH_BOOT_LOADER_MEM_TYPE
#define FLASH_BOOT_LOADER_MEM_TYPE                         HAL_MEM_TYPE_NOR_FLASH


/* mpi1 */
#undef  PSRAM_DATA_START_ADDR
#define PSRAM_DATA_START_ADDR                              (0x60000000)
#undef  PSRAM_DATA_SIZE
#define PSRAM_DATA_SIZE                                    (0x00800000)
#undef  PSRAM_DATA_OFFSET
#define PSRAM_DATA_OFFSET                                  (0x00000000)
#undef  PSRAM_DATA_MEM_TYPE
#define PSRAM_DATA_MEM_TYPE                                HAL_MEM_TYPE_PSRAM


/* hpsys_ram */
#undef  HCPU_RAM_DATA_START_ADDR
#define HCPU_RAM_DATA_START_ADDR                           (0x20000000)
#undef  HCPU_RAM_DATA_SIZE
#define HCPU_RAM_DATA_SIZE                                 (0x0007FC00)
#undef  HCPU_RAM_DATA_OFFSET
#define HCPU_RAM_DATA_OFFSET                               (0x00000000)
#undef  BOOTLOADER_RAM_DATA_START_ADDR
#define BOOTLOADER_RAM_DATA_START_ADDR                     (0x20040000)
#undef  BOOTLOADER_RAM_DATA_SIZE
#define BOOTLOADER_RAM_DATA_SIZE                           (0x00010000)
#undef  BOOTLOADER_RAM_DATA_OFFSET
#define BOOTLOADER_RAM_DATA_OFFSET                         (0x00040000)


/* lpsys_ram */
#undef  LPSYS_RAM_START_ADDR
#define LPSYS_RAM_START_ADDR                               (0x20400000)
#undef  LPSYS_RAM_SIZE
#define LPSYS_RAM_SIZE                                     (0x00006000)
#undef  LPSYS_RAM_OFFSET
#define LPSYS_RAM_OFFSET                                   (0x00000000)


/* bootloader exec addr */
#undef  FLASH_BOOT_LOADER_EXEC_START_ADDR
#define FLASH_BOOT_LOADER_EXEC_START_ADDR                  (0x20020000)
#undef  FLASH_BOOT_LOADER_EXEC_SIZE
#define FLASH_BOOT_LOADER_EXEC_SIZE                        (0x00020000)
#undef  FLASH_BOOT_LOADER_EXEC_OFFSET
#define FLASH_BOOT_LOADER_EXEC_OFFSET                      (0x00020000)
#undef  FLASH_BOOT_LOADER_EXEC_MEM_TYPE


/* code start */
#undef  CODE_START_ADDR
#define CODE_START_ADDR                                    (0x12020000)
#undef  CODE_SIZE
#define CODE_SIZE                                          (0x00700000)


/* FAL Partition Table */
#ifndef FAL_PART_TABLE
#define FAL_PART_TABLE \
{ \
    {FAL_PART_MAGIC_WORD, "hcpu_flash_code", NOR_FLASH2_DEV_NAME, 0x00020000, 0x00700000, 0}, \
    {FAL_PART_MAGIC_WORD, "dfu_flash_code", NOR_FLASH2_DEV_NAME, 0x00720000, 0x00060000, 0}, \
    {FAL_PART_MAGIC_WORD, "fs_region", NOR_FLASH2_DEV_NAME, 0x008A0000, 0x00400000, 0}, \
    {FAL_PART_MAGIC_WORD, "dfu", NOR_FLASH2_DEV_NAME, 0x00CA0000, 0x00004000, 0}, \
    {FAL_PART_MAGIC_WORD, "ble", NOR_FLASH2_DEV_NAME, 0x00CA4000, 0x00004000, 0} \
}
#endif /* FAL_PART_TABLE */



#endif
