
build_sf32lb52-nano_n16r16_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020208 <boot_uart_tx>:
20020208:	2300      	movs	r3, #0
2002020a:	b510      	push	{r4, lr}
2002020c:	4293      	cmp	r3, r2
2002020e:	db00      	blt.n	20020212 <boot_uart_tx+0xa>
20020210:	bd10      	pop	{r4, pc}
20020212:	69c4      	ldr	r4, [r0, #28]
20020214:	0624      	lsls	r4, r4, #24
20020216:	d5fc      	bpl.n	20020212 <boot_uart_tx+0xa>
20020218:	5ccc      	ldrb	r4, [r1, r3]
2002021a:	3301      	adds	r3, #1
2002021c:	6284      	str	r4, [r0, #40]	@ 0x28
2002021e:	e7f5      	b.n	2002020c <boot_uart_tx+0x4>

20020220 <boot_error>:
20020220:	b507      	push	{r0, r1, r2, lr}
20020222:	2201      	movs	r2, #1
20020224:	f88d 0007 	strb.w	r0, [sp, #7]
20020228:	f10d 0107 	add.w	r1, sp, #7
2002022c:	480e      	ldr	r0, [pc, #56]	@ (20020268 <boot_error+0x48>)
2002022e:	f7ff ffeb 	bl	20020208 <boot_uart_tx>
20020232:	4b0e      	ldr	r3, [pc, #56]	@ (2002026c <boot_error+0x4c>)
20020234:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20020238:	f002 0203 	and.w	r2, r2, #3
2002023c:	2a03      	cmp	r2, #3
2002023e:	f102 0101 	add.w	r1, r2, #1
20020242:	d00f      	beq.n	20020264 <boot_error+0x44>
20020244:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20020248:	f022 0203 	bic.w	r2, r2, #3
2002024c:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20020250:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20020254:	430a      	orrs	r2, r1
20020256:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
2002025a:	f00c f94b 	bl	2002c4f4 <HAL_PMU_Reboot>
2002025e:	b003      	add	sp, #12
20020260:	f85d fb04 	ldr.w	pc, [sp], #4
20020264:	e7fe      	b.n	20020264 <boot_error+0x44>
20020266:	bf00      	nop
20020268:	50084000 	.word	0x50084000
2002026c:	500ca000 	.word	0x500ca000

20020270 <HAL_MspInit>:
20020270:	2234      	movs	r2, #52	@ 0x34
20020272:	4b01      	ldr	r3, [pc, #4]	@ (20020278 <HAL_MspInit+0x8>)
20020274:	60da      	str	r2, [r3, #12]
20020276:	4770      	bx	lr
20020278:	50094000 	.word	0x50094000

2002027c <mpu_config>:
2002027c:	4770      	bx	lr

2002027e <cache_enable>:
2002027e:	4770      	bx	lr

20020280 <board_pinmux_mpi1_puya_base>:
20020280:	b510      	push	{r4, lr}
20020282:	2301      	movs	r3, #1
20020284:	2200      	movs	r2, #0
20020286:	2103      	movs	r1, #3
20020288:	2002      	movs	r0, #2
2002028a:	f004 fccd 	bl	20024c28 <HAL_PIN_Set>
2002028e:	2301      	movs	r3, #1
20020290:	2200      	movs	r2, #0
20020292:	4619      	mov	r1, r3
20020294:	200a      	movs	r0, #10
20020296:	f004 fcc7 	bl	20024c28 <HAL_PIN_Set>
2002029a:	2301      	movs	r3, #1
2002029c:	2210      	movs	r2, #16
2002029e:	2109      	movs	r1, #9
200202a0:	2008      	movs	r0, #8
200202a2:	f004 fcc1 	bl	20024c28 <HAL_PIN_Set>
200202a6:	2301      	movs	r3, #1
200202a8:	2210      	movs	r2, #16
200202aa:	210a      	movs	r1, #10
200202ac:	2003      	movs	r0, #3
200202ae:	f004 fcbb 	bl	20024c28 <HAL_PIN_Set>
200202b2:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200202b6:	2301      	movs	r3, #1
200202b8:	2200      	movs	r2, #0
200202ba:	210c      	movs	r1, #12
200202bc:	200b      	movs	r0, #11
200202be:	f004 bcb3 	b.w	20024c28 <HAL_PIN_Set>

200202c2 <board_pinmux_mpi1_puya_ext>:
200202c2:	b510      	push	{r4, lr}
200202c4:	4604      	mov	r4, r0
200202c6:	2101      	movs	r1, #1
200202c8:	2005      	movs	r0, #5
200202ca:	f004 fe31 	bl	20024f30 <HAL_PIN_Set_Analog>
200202ce:	2101      	movs	r1, #1
200202d0:	2006      	movs	r0, #6
200202d2:	f004 fe2d 	bl	20024f30 <HAL_PIN_Set_Analog>
200202d6:	2101      	movs	r1, #1
200202d8:	2007      	movs	r0, #7
200202da:	f004 fe29 	bl	20024f30 <HAL_PIN_Set_Analog>
200202de:	2101      	movs	r1, #1
200202e0:	2009      	movs	r0, #9
200202e2:	f004 fe25 	bl	20024f30 <HAL_PIN_Set_Analog>
200202e6:	2101      	movs	r1, #1
200202e8:	200c      	movs	r0, #12
200202ea:	f004 fe21 	bl	20024f30 <HAL_PIN_Set_Analog>
200202ee:	2101      	movs	r1, #1
200202f0:	200d      	movs	r0, #13
200202f2:	f004 fe1d 	bl	20024f30 <HAL_PIN_Set_Analog>
200202f6:	2101      	movs	r1, #1
200202f8:	b154      	cbz	r4, 20020310 <board_pinmux_mpi1_puya_ext+0x4e>
200202fa:	4608      	mov	r0, r1
200202fc:	f004 fe18 	bl	20024f30 <HAL_PIN_Set_Analog>
20020300:	2301      	movs	r3, #1
20020302:	2230      	movs	r2, #48	@ 0x30
20020304:	210b      	movs	r1, #11
20020306:	2004      	movs	r0, #4
20020308:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002030c:	f004 bc8c 	b.w	20024c28 <HAL_PIN_Set>
20020310:	2004      	movs	r0, #4
20020312:	f004 fe0d 	bl	20024f30 <HAL_PIN_Set_Analog>
20020316:	2301      	movs	r3, #1
20020318:	2230      	movs	r2, #48	@ 0x30
2002031a:	210b      	movs	r1, #11
2002031c:	4618      	mov	r0, r3
2002031e:	e7f3      	b.n	20020308 <board_pinmux_mpi1_puya_ext+0x46>

20020320 <board_pinmux_mpi1_gd>:
20020320:	b508      	push	{r3, lr}
20020322:	2200      	movs	r2, #0
20020324:	2301      	movs	r3, #1
20020326:	2103      	movs	r1, #3
20020328:	2005      	movs	r0, #5
2002032a:	f004 fc7d 	bl	20024c28 <HAL_PIN_Set>
2002032e:	2301      	movs	r3, #1
20020330:	2200      	movs	r2, #0
20020332:	4619      	mov	r1, r3
20020334:	200a      	movs	r0, #10
20020336:	f004 fc77 	bl	20024c28 <HAL_PIN_Set>
2002033a:	2301      	movs	r3, #1
2002033c:	2210      	movs	r2, #16
2002033e:	2109      	movs	r1, #9
20020340:	200c      	movs	r0, #12
20020342:	f004 fc71 	bl	20024c28 <HAL_PIN_Set>
20020346:	2301      	movs	r3, #1
20020348:	2210      	movs	r2, #16
2002034a:	210a      	movs	r1, #10
2002034c:	2003      	movs	r0, #3
2002034e:	f004 fc6b 	bl	20024c28 <HAL_PIN_Set>
20020352:	2301      	movs	r3, #1
20020354:	2230      	movs	r2, #48	@ 0x30
20020356:	210b      	movs	r1, #11
20020358:	4618      	mov	r0, r3
2002035a:	f004 fc65 	bl	20024c28 <HAL_PIN_Set>
2002035e:	2301      	movs	r3, #1
20020360:	2230      	movs	r2, #48	@ 0x30
20020362:	210c      	movs	r1, #12
20020364:	2009      	movs	r0, #9
20020366:	f004 fc5f 	bl	20024c28 <HAL_PIN_Set>
2002036a:	2101      	movs	r1, #1
2002036c:	2002      	movs	r0, #2
2002036e:	f004 fddf 	bl	20024f30 <HAL_PIN_Set_Analog>
20020372:	2101      	movs	r1, #1
20020374:	2004      	movs	r0, #4
20020376:	f004 fddb 	bl	20024f30 <HAL_PIN_Set_Analog>
2002037a:	2101      	movs	r1, #1
2002037c:	2006      	movs	r0, #6
2002037e:	f004 fdd7 	bl	20024f30 <HAL_PIN_Set_Analog>
20020382:	2101      	movs	r1, #1
20020384:	2007      	movs	r0, #7
20020386:	f004 fdd3 	bl	20024f30 <HAL_PIN_Set_Analog>
2002038a:	2101      	movs	r1, #1
2002038c:	2008      	movs	r0, #8
2002038e:	f004 fdcf 	bl	20024f30 <HAL_PIN_Set_Analog>
20020392:	2101      	movs	r1, #1
20020394:	200b      	movs	r0, #11
20020396:	f004 fdcb 	bl	20024f30 <HAL_PIN_Set_Analog>
2002039a:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002039e:	2101      	movs	r1, #1
200203a0:	200d      	movs	r0, #13
200203a2:	f004 bdc5 	b.w	20024f30 <HAL_PIN_Set_Analog>

200203a6 <board_pinmux_mpi2>:
200203a6:	b510      	push	{r4, lr}
200203a8:	2301      	movs	r3, #1
200203aa:	2200      	movs	r2, #0
200203ac:	2119      	movs	r1, #25
200203ae:	201e      	movs	r0, #30
200203b0:	f004 fc3a 	bl	20024c28 <HAL_PIN_Set>
200203b4:	2301      	movs	r3, #1
200203b6:	2200      	movs	r2, #0
200203b8:	211b      	movs	r1, #27
200203ba:	201a      	movs	r0, #26
200203bc:	f004 fc34 	bl	20024c28 <HAL_PIN_Set>
200203c0:	2301      	movs	r3, #1
200203c2:	2210      	movs	r2, #16
200203c4:	2121      	movs	r1, #33	@ 0x21
200203c6:	201d      	movs	r0, #29
200203c8:	f004 fc2e 	bl	20024c28 <HAL_PIN_Set>
200203cc:	2301      	movs	r3, #1
200203ce:	2210      	movs	r2, #16
200203d0:	2122      	movs	r1, #34	@ 0x22
200203d2:	201b      	movs	r0, #27
200203d4:	f004 fc28 	bl	20024c28 <HAL_PIN_Set>
200203d8:	2301      	movs	r3, #1
200203da:	2230      	movs	r2, #48	@ 0x30
200203dc:	2123      	movs	r1, #35	@ 0x23
200203de:	201c      	movs	r0, #28
200203e0:	f004 fc22 	bl	20024c28 <HAL_PIN_Set>
200203e4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200203e8:	2301      	movs	r3, #1
200203ea:	2230      	movs	r2, #48	@ 0x30
200203ec:	2124      	movs	r1, #36	@ 0x24
200203ee:	201f      	movs	r0, #31
200203f0:	f004 bc1a 	b.w	20024c28 <HAL_PIN_Set>

200203f4 <board_pinmux_sd>:
200203f4:	b510      	push	{r4, lr}
200203f6:	2301      	movs	r3, #1
200203f8:	2230      	movs	r2, #48	@ 0x30
200203fa:	f44f 71da 	mov.w	r1, #436	@ 0x1b4
200203fe:	201d      	movs	r0, #29
20020400:	f004 fc12 	bl	20024c28 <HAL_PIN_Set>
20020404:	2014      	movs	r0, #20
20020406:	f001 fea8 	bl	2002215a <HAL_Delay_us>
2002040a:	2301      	movs	r3, #1
2002040c:	2200      	movs	r2, #0
2002040e:	f44f 71d9 	mov.w	r1, #434	@ 0x1b2
20020412:	201c      	movs	r0, #28
20020414:	f004 fc08 	bl	20024c28 <HAL_PIN_Set>
20020418:	2301      	movs	r3, #1
2002041a:	2230      	movs	r2, #48	@ 0x30
2002041c:	f240 11b5 	movw	r1, #437	@ 0x1b5
20020420:	201e      	movs	r0, #30
20020422:	f004 fc01 	bl	20024c28 <HAL_PIN_Set>
20020426:	2301      	movs	r3, #1
20020428:	2230      	movs	r2, #48	@ 0x30
2002042a:	f44f 71db 	mov.w	r1, #438	@ 0x1b6
2002042e:	201f      	movs	r0, #31
20020430:	f004 fbfa 	bl	20024c28 <HAL_PIN_Set>
20020434:	2301      	movs	r3, #1
20020436:	2230      	movs	r2, #48	@ 0x30
20020438:	f240 11b7 	movw	r1, #439	@ 0x1b7
2002043c:	201a      	movs	r0, #26
2002043e:	f004 fbf3 	bl	20024c28 <HAL_PIN_Set>
20020442:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20020446:	2301      	movs	r3, #1
20020448:	2230      	movs	r2, #48	@ 0x30
2002044a:	f44f 71dc 	mov.w	r1, #440	@ 0x1b8
2002044e:	201b      	movs	r0, #27
20020450:	f004 bbea 	b.w	20024c28 <HAL_PIN_Set>

20020454 <board_boot_from>:
20020454:	b510      	push	{r4, lr}
20020456:	4b0f      	ldr	r3, [pc, #60]	@ (20020494 <board_boot_from+0x40>)
20020458:	490f      	ldr	r1, [pc, #60]	@ (20020498 <board_boot_from+0x44>)
2002045a:	685b      	ldr	r3, [r3, #4]
2002045c:	680a      	ldr	r2, [r1, #0]
2002045e:	f3c3 2302 	ubfx	r3, r3, #8, #3
20020462:	f022 0208 	bic.w	r2, r2, #8
20020466:	2b07      	cmp	r3, #7
20020468:	600a      	str	r2, [r1, #0]
2002046a:	d10c      	bne.n	20020486 <board_boot_from+0x32>
2002046c:	2400      	movs	r4, #0
2002046e:	3401      	adds	r4, #1
20020470:	2101      	movs	r1, #1
20020472:	4620      	mov	r0, r4
20020474:	f004 fd5c 	bl	20024f30 <HAL_PIN_Set_Analog>
20020478:	2c0d      	cmp	r4, #13
2002047a:	d1f8      	bne.n	2002046e <board_boot_from+0x1a>
2002047c:	2000      	movs	r0, #0
2002047e:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20020482:	f00c b807 	b.w	2002c494 <HAL_Get_backup>
20020486:	b11b      	cbz	r3, 20020490 <board_boot_from+0x3c>
20020488:	2b01      	cmp	r3, #1
2002048a:	d1f7      	bne.n	2002047c <board_boot_from+0x28>
2002048c:	2002      	movs	r0, #2
2002048e:	bd10      	pop	{r4, pc}
20020490:	2001      	movs	r0, #1
20020492:	e7fc      	b.n	2002048e <board_boot_from+0x3a>
20020494:	5000b000 	.word	0x5000b000
20020498:	500ca000 	.word	0x500ca000

2002049c <board_flash_power_on>:
2002049c:	4770      	bx	lr

2002049e <board_pinmux_psram_func0>:
2002049e:	b508      	push	{r3, lr}
200204a0:	2210      	movs	r2, #16
200204a2:	2301      	movs	r3, #1
200204a4:	2109      	movs	r1, #9
200204a6:	2002      	movs	r0, #2
200204a8:	f004 fbbe 	bl	20024c28 <HAL_PIN_Set>
200204ac:	2301      	movs	r3, #1
200204ae:	2210      	movs	r2, #16
200204b0:	210a      	movs	r1, #10
200204b2:	2003      	movs	r0, #3
200204b4:	f004 fbb8 	bl	20024c28 <HAL_PIN_Set>
200204b8:	2301      	movs	r3, #1
200204ba:	2210      	movs	r2, #16
200204bc:	210b      	movs	r1, #11
200204be:	2004      	movs	r0, #4
200204c0:	f004 fbb2 	bl	20024c28 <HAL_PIN_Set>
200204c4:	2301      	movs	r3, #1
200204c6:	2210      	movs	r2, #16
200204c8:	210c      	movs	r1, #12
200204ca:	2005      	movs	r0, #5
200204cc:	f004 fbac 	bl	20024c28 <HAL_PIN_Set>
200204d0:	2301      	movs	r3, #1
200204d2:	2210      	movs	r2, #16
200204d4:	210d      	movs	r1, #13
200204d6:	2006      	movs	r0, #6
200204d8:	f004 fba6 	bl	20024c28 <HAL_PIN_Set>
200204dc:	2301      	movs	r3, #1
200204de:	2210      	movs	r2, #16
200204e0:	210e      	movs	r1, #14
200204e2:	2007      	movs	r0, #7
200204e4:	f004 fba0 	bl	20024c28 <HAL_PIN_Set>
200204e8:	2301      	movs	r3, #1
200204ea:	2210      	movs	r2, #16
200204ec:	210f      	movs	r1, #15
200204ee:	2008      	movs	r0, #8
200204f0:	f004 fb9a 	bl	20024c28 <HAL_PIN_Set>
200204f4:	2210      	movs	r2, #16
200204f6:	2301      	movs	r3, #1
200204f8:	4611      	mov	r1, r2
200204fa:	2009      	movs	r0, #9
200204fc:	f004 fb94 	bl	20024c28 <HAL_PIN_Set>
20020500:	2301      	movs	r3, #1
20020502:	2210      	movs	r2, #16
20020504:	2106      	movs	r1, #6
20020506:	200a      	movs	r0, #10
20020508:	f004 fb8e 	bl	20024c28 <HAL_PIN_Set>
2002050c:	2301      	movs	r3, #1
2002050e:	2200      	movs	r2, #0
20020510:	4619      	mov	r1, r3
20020512:	200b      	movs	r0, #11
20020514:	f004 fb88 	bl	20024c28 <HAL_PIN_Set>
20020518:	2301      	movs	r3, #1
2002051a:	2200      	movs	r2, #0
2002051c:	2103      	movs	r1, #3
2002051e:	200c      	movs	r0, #12
20020520:	f004 fb82 	bl	20024c28 <HAL_PIN_Set>
20020524:	2101      	movs	r1, #1
20020526:	4608      	mov	r0, r1
20020528:	f004 fd02 	bl	20024f30 <HAL_PIN_Set_Analog>
2002052c:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020530:	2101      	movs	r1, #1
20020532:	200d      	movs	r0, #13
20020534:	f004 bcfc 	b.w	20024f30 <HAL_PIN_Set_Analog>

20020538 <board_pinmux_psram_func1_2_4>:
20020538:	b510      	push	{r4, lr}
2002053a:	2301      	movs	r3, #1
2002053c:	4604      	mov	r4, r0
2002053e:	2210      	movs	r2, #16
20020540:	2109      	movs	r1, #9
20020542:	2002      	movs	r0, #2
20020544:	f004 fb70 	bl	20024c28 <HAL_PIN_Set>
20020548:	2301      	movs	r3, #1
2002054a:	2210      	movs	r2, #16
2002054c:	210a      	movs	r1, #10
2002054e:	2003      	movs	r0, #3
20020550:	f004 fb6a 	bl	20024c28 <HAL_PIN_Set>
20020554:	2301      	movs	r3, #1
20020556:	2210      	movs	r2, #16
20020558:	210b      	movs	r1, #11
2002055a:	2004      	movs	r0, #4
2002055c:	f004 fb64 	bl	20024c28 <HAL_PIN_Set>
20020560:	2301      	movs	r3, #1
20020562:	2210      	movs	r2, #16
20020564:	210c      	movs	r1, #12
20020566:	2005      	movs	r0, #5
20020568:	f004 fb5e 	bl	20024c28 <HAL_PIN_Set>
2002056c:	2301      	movs	r3, #1
2002056e:	2210      	movs	r2, #16
20020570:	210d      	movs	r1, #13
20020572:	2009      	movs	r0, #9
20020574:	f004 fb58 	bl	20024c28 <HAL_PIN_Set>
20020578:	2301      	movs	r3, #1
2002057a:	2210      	movs	r2, #16
2002057c:	210e      	movs	r1, #14
2002057e:	200a      	movs	r0, #10
20020580:	f004 fb52 	bl	20024c28 <HAL_PIN_Set>
20020584:	2301      	movs	r3, #1
20020586:	2210      	movs	r2, #16
20020588:	210f      	movs	r1, #15
2002058a:	200b      	movs	r0, #11
2002058c:	f004 fb4c 	bl	20024c28 <HAL_PIN_Set>
20020590:	2210      	movs	r2, #16
20020592:	2301      	movs	r3, #1
20020594:	4611      	mov	r1, r2
20020596:	200c      	movs	r0, #12
20020598:	f004 fb46 	bl	20024c28 <HAL_PIN_Set>
2002059c:	2301      	movs	r3, #1
2002059e:	2200      	movs	r2, #0
200205a0:	4619      	mov	r1, r3
200205a2:	2008      	movs	r0, #8
200205a4:	f004 fb40 	bl	20024c28 <HAL_PIN_Set>
200205a8:	2301      	movs	r3, #1
200205aa:	2200      	movs	r2, #0
200205ac:	2103      	movs	r1, #3
200205ae:	2006      	movs	r0, #6
200205b0:	f004 fb3a 	bl	20024c28 <HAL_PIN_Set>
200205b4:	2c02      	cmp	r4, #2
200205b6:	d013      	beq.n	200205e0 <board_pinmux_psram_func1_2_4+0xa8>
200205b8:	2c04      	cmp	r4, #4
200205ba:	d025      	beq.n	20020608 <board_pinmux_psram_func1_2_4+0xd0>
200205bc:	2c01      	cmp	r4, #1
200205be:	d12c      	bne.n	2002061a <board_pinmux_psram_func1_2_4+0xe2>
200205c0:	2106      	movs	r1, #6
200205c2:	4623      	mov	r3, r4
200205c4:	2210      	movs	r2, #16
200205c6:	200d      	movs	r0, #13
200205c8:	f004 fb2e 	bl	20024c28 <HAL_PIN_Set>
200205cc:	4621      	mov	r1, r4
200205ce:	4620      	mov	r0, r4
200205d0:	f004 fcae 	bl	20024f30 <HAL_PIN_Set_Analog>
200205d4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200205d8:	2101      	movs	r1, #1
200205da:	2007      	movs	r0, #7
200205dc:	f004 bca8 	b.w	20024f30 <HAL_PIN_Set_Analog>
200205e0:	2301      	movs	r3, #1
200205e2:	2210      	movs	r2, #16
200205e4:	2104      	movs	r1, #4
200205e6:	4618      	mov	r0, r3
200205e8:	f004 fb1e 	bl	20024c28 <HAL_PIN_Set>
200205ec:	2301      	movs	r3, #1
200205ee:	2210      	movs	r2, #16
200205f0:	2105      	movs	r1, #5
200205f2:	200d      	movs	r0, #13
200205f4:	f004 fb18 	bl	20024c28 <HAL_PIN_Set>
200205f8:	4621      	mov	r1, r4
200205fa:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200205fe:	2301      	movs	r3, #1
20020600:	2200      	movs	r2, #0
20020602:	2007      	movs	r0, #7
20020604:	f004 bb10 	b.w	20024c28 <HAL_PIN_Set>
20020608:	2106      	movs	r1, #6
2002060a:	2301      	movs	r3, #1
2002060c:	2200      	movs	r2, #0
2002060e:	200d      	movs	r0, #13
20020610:	f004 fb0a 	bl	20024c28 <HAL_PIN_Set>
20020614:	2101      	movs	r1, #1
20020616:	4608      	mov	r0, r1
20020618:	e7da      	b.n	200205d0 <board_pinmux_psram_func1_2_4+0x98>
2002061a:	bd10      	pop	{r4, pc}

2002061c <board_pinmux_psram_func3>:
2002061c:	b508      	push	{r3, lr}
2002061e:	2301      	movs	r3, #1
20020620:	2200      	movs	r2, #0
20020622:	4619      	mov	r1, r3
20020624:	200a      	movs	r0, #10
20020626:	f004 faff 	bl	20024c28 <HAL_PIN_Set>
2002062a:	2301      	movs	r3, #1
2002062c:	2200      	movs	r2, #0
2002062e:	2103      	movs	r1, #3
20020630:	2009      	movs	r0, #9
20020632:	f004 faf9 	bl	20024c28 <HAL_PIN_Set>
20020636:	2301      	movs	r3, #1
20020638:	2210      	movs	r2, #16
2002063a:	2109      	movs	r1, #9
2002063c:	2006      	movs	r0, #6
2002063e:	f004 faf3 	bl	20024c28 <HAL_PIN_Set>
20020642:	2301      	movs	r3, #1
20020644:	2210      	movs	r2, #16
20020646:	210a      	movs	r1, #10
20020648:	2008      	movs	r0, #8
2002064a:	f004 faed 	bl	20024c28 <HAL_PIN_Set>
2002064e:	2301      	movs	r3, #1
20020650:	2230      	movs	r2, #48	@ 0x30
20020652:	210b      	movs	r1, #11
20020654:	2007      	movs	r0, #7
20020656:	f004 fae7 	bl	20024c28 <HAL_PIN_Set>
2002065a:	2301      	movs	r3, #1
2002065c:	2230      	movs	r2, #48	@ 0x30
2002065e:	210c      	movs	r1, #12
20020660:	200b      	movs	r0, #11
20020662:	f004 fae1 	bl	20024c28 <HAL_PIN_Set>
20020666:	2101      	movs	r1, #1
20020668:	4608      	mov	r0, r1
2002066a:	f004 fc61 	bl	20024f30 <HAL_PIN_Set_Analog>
2002066e:	2101      	movs	r1, #1
20020670:	2002      	movs	r0, #2
20020672:	f004 fc5d 	bl	20024f30 <HAL_PIN_Set_Analog>
20020676:	2101      	movs	r1, #1
20020678:	2003      	movs	r0, #3
2002067a:	f004 fc59 	bl	20024f30 <HAL_PIN_Set_Analog>
2002067e:	2101      	movs	r1, #1
20020680:	2004      	movs	r0, #4
20020682:	f004 fc55 	bl	20024f30 <HAL_PIN_Set_Analog>
20020686:	2101      	movs	r1, #1
20020688:	2005      	movs	r0, #5
2002068a:	f004 fc51 	bl	20024f30 <HAL_PIN_Set_Analog>
2002068e:	2101      	movs	r1, #1
20020690:	200c      	movs	r0, #12
20020692:	f004 fc4d 	bl	20024f30 <HAL_PIN_Set_Analog>
20020696:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002069a:	2101      	movs	r1, #1
2002069c:	200d      	movs	r0, #13
2002069e:	f004 bc47 	b.w	20024f30 <HAL_PIN_Set_Analog>

200206a2 <bootloader_switch_clock>:
200206a2:	2102      	movs	r1, #2
200206a4:	2004      	movs	r0, #4
200206a6:	f004 bd6b 	b.w	20025180 <HAL_RCC_HCPU_ClockSelect>
	...

200206ac <boot_psram_init>:
200206ac:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200206b0:	2400      	movs	r4, #0
200206b2:	b08a      	sub	sp, #40	@ 0x28
200206b4:	4605      	mov	r5, r0
200206b6:	2240      	movs	r2, #64	@ 0x40
200206b8:	4621      	mov	r1, r4
200206ba:	4863      	ldr	r0, [pc, #396]	@ (20020848 <boot_psram_init+0x19c>)
200206bc:	f00a f9ae 	bl	2002aa1c <memset>
200206c0:	4b62      	ldr	r3, [pc, #392]	@ (2002084c <boot_psram_init+0x1a0>)
200206c2:	1ea8      	subs	r0, r5, #2
200206c4:	9305      	str	r3, [sp, #20]
200206c6:	f04f 5380 	mov.w	r3, #268435456	@ 0x10000000
200206ca:	9307      	str	r3, [sp, #28]
200206cc:	2303      	movs	r3, #3
200206ce:	9406      	str	r4, [sp, #24]
200206d0:	9309      	str	r3, [sp, #36]	@ 0x24
200206d2:	2804      	cmp	r0, #4
200206d4:	d804      	bhi.n	200206e0 <boot_psram_init+0x34>
200206d6:	e8df f000 	tbb	[pc, r0]
200206da:	6264      	.short	0x6264
200206dc:	5d04      	.short	0x5d04
200206de:	60          	.byte	0x60
200206df:	00          	.byte	0x00
200206e0:	e7fe      	b.n	200206e0 <boot_psram_init+0x34>
200206e2:	2305      	movs	r3, #5
200206e4:	9309      	str	r3, [sp, #36]	@ 0x24
200206e6:	2304      	movs	r3, #4
200206e8:	9d09      	ldr	r5, [sp, #36]	@ 0x24
200206ea:	9308      	str	r3, [sp, #32]
200206ec:	2d03      	cmp	r5, #3
200206ee:	d162      	bne.n	200207b6 <boot_psram_init+0x10a>
200206f0:	f001 fc42 	bl	20021f78 <BSP_GetFlash1DIV>
200206f4:	a905      	add	r1, sp, #20
200206f6:	4602      	mov	r2, r0
200206f8:	4853      	ldr	r0, [pc, #332]	@ (20020848 <boot_psram_init+0x19c>)
200206fa:	f004 f815 	bl	20024728 <HAL_OPI_PSRAM_Init>
200206fe:	462a      	mov	r2, r5
20020700:	2108      	movs	r1, #8
20020702:	4851      	ldr	r0, [pc, #324]	@ (20020848 <boot_psram_init+0x19c>)
20020704:	f003 ff02 	bl	2002450c <HAL_MPI_MR_WRITE>
20020708:	484f      	ldr	r0, [pc, #316]	@ (20020848 <boot_psram_init+0x19c>)
2002070a:	f003 fc1f 	bl	20023f4c <HAL_QSPI_GET_CLK>
2002070e:	4b50      	ldr	r3, [pc, #320]	@ (20020850 <boot_psram_init+0x1a4>)
20020710:	4298      	cmp	r0, r3
20020712:	d948      	bls.n	200207a6 <boot_psram_init+0xfa>
20020714:	f103 63a4 	add.w	r3, r3, #85983232	@ 0x5200000
20020718:	f503 4383 	add.w	r3, r3, #16768	@ 0x4180
2002071c:	4298      	cmp	r0, r3
2002071e:	d944      	bls.n	200207aa <boot_psram_init+0xfe>
20020720:	f103 7337 	add.w	r3, r3, #47972352	@ 0x2dc0000
20020724:	f503 43d8 	add.w	r3, r3, #27648	@ 0x6c00
20020728:	4298      	cmp	r0, r3
2002072a:	d940      	bls.n	200207ae <boot_psram_init+0x102>
2002072c:	4b49      	ldr	r3, [pc, #292]	@ (20020854 <boot_psram_init+0x1a8>)
2002072e:	4298      	cmp	r0, r3
20020730:	d93f      	bls.n	200207b2 <boot_psram_init+0x106>
20020732:	4b49      	ldr	r3, [pc, #292]	@ (20020858 <boot_psram_init+0x1ac>)
20020734:	4298      	cmp	r0, r3
20020736:	bf98      	it	ls
20020738:	2407      	movls	r4, #7
2002073a:	2600      	movs	r6, #0
2002073c:	2507      	movs	r5, #7
2002073e:	f04f 0803 	mov.w	r8, #3
20020742:	0067      	lsls	r7, r4, #1
20020744:	b2ff      	uxtb	r7, r7
20020746:	1e7a      	subs	r2, r7, #1
20020748:	4633      	mov	r3, r6
2002074a:	b252      	sxtb	r2, r2
2002074c:	4629      	mov	r1, r5
2002074e:	483e      	ldr	r0, [pc, #248]	@ (20020848 <boot_psram_init+0x19c>)
20020750:	e9cd 5502 	strd	r5, r5, [sp, #8]
20020754:	e9cd 6800 	strd	r6, r8, [sp]
20020758:	f002 fab0 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
2002075c:	4631      	mov	r1, r6
2002075e:	483a      	ldr	r0, [pc, #232]	@ (20020848 <boot_psram_init+0x19c>)
20020760:	f002 faa1 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20020764:	1e62      	subs	r2, r4, #1
20020766:	4633      	mov	r3, r6
20020768:	b252      	sxtb	r2, r2
2002076a:	4629      	mov	r1, r5
2002076c:	4836      	ldr	r0, [pc, #216]	@ (20020848 <boot_psram_init+0x19c>)
2002076e:	e9cd 5502 	strd	r5, r5, [sp, #8]
20020772:	e9cd 6800 	strd	r6, r8, [sp]
20020776:	f002 faca 	bl	20022d0e <HAL_FLASH_CFG_AHB_WCMD>
2002077a:	2180      	movs	r1, #128	@ 0x80
2002077c:	4832      	ldr	r0, [pc, #200]	@ (20020848 <boot_psram_init+0x19c>)
2002077e:	f002 faba 	bl	20022cf6 <HAL_FLASH_SET_AHB_WCMD>
20020782:	4623      	mov	r3, r4
20020784:	463a      	mov	r2, r7
20020786:	2101      	movs	r1, #1
20020788:	482f      	ldr	r0, [pc, #188]	@ (20020848 <boot_psram_init+0x19c>)
2002078a:	f003 fee3 	bl	20024554 <HAL_MPI_SET_FIXLAT>
2002078e:	b00a      	add	sp, #40	@ 0x28
20020790:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20020794:	2302      	movs	r3, #2
20020796:	9309      	str	r3, [sp, #36]	@ 0x24
20020798:	e7a6      	b.n	200206e8 <boot_psram_init+0x3c>
2002079a:	2306      	movs	r3, #6
2002079c:	9309      	str	r3, [sp, #36]	@ 0x24
2002079e:	2308      	movs	r3, #8
200207a0:	e7a2      	b.n	200206e8 <boot_psram_init+0x3c>
200207a2:	2310      	movs	r3, #16
200207a4:	e7a0      	b.n	200206e8 <boot_psram_init+0x3c>
200207a6:	462c      	mov	r4, r5
200207a8:	e7c7      	b.n	2002073a <boot_psram_init+0x8e>
200207aa:	2404      	movs	r4, #4
200207ac:	e7c5      	b.n	2002073a <boot_psram_init+0x8e>
200207ae:	2405      	movs	r4, #5
200207b0:	e7c3      	b.n	2002073a <boot_psram_init+0x8e>
200207b2:	2406      	movs	r4, #6
200207b4:	e7c1      	b.n	2002073a <boot_psram_init+0x8e>
200207b6:	2d05      	cmp	r5, #5
200207b8:	d10d      	bne.n	200207d6 <boot_psram_init+0x12a>
200207ba:	f001 fbdd 	bl	20021f78 <BSP_GetFlash1DIV>
200207be:	a905      	add	r1, sp, #20
200207c0:	4602      	mov	r2, r0
200207c2:	4821      	ldr	r0, [pc, #132]	@ (20020848 <boot_psram_init+0x19c>)
200207c4:	f004 f83c 	bl	20024840 <HAL_LEGACY_PSRAM_Init>
200207c8:	481f      	ldr	r0, [pc, #124]	@ (20020848 <boot_psram_init+0x19c>)
200207ca:	f003 ff36 	bl	2002463a <HAL_LEGACY_CFG_READ>
200207ce:	481e      	ldr	r0, [pc, #120]	@ (20020848 <boot_psram_init+0x19c>)
200207d0:	f003 ff4e 	bl	20024670 <HAL_LEGACY_CFG_WRITE>
200207d4:	e7db      	b.n	2002078e <boot_psram_init+0xe2>
200207d6:	2d06      	cmp	r5, #6
200207d8:	d10d      	bne.n	200207f6 <boot_psram_init+0x14a>
200207da:	f001 fbcd 	bl	20021f78 <BSP_GetFlash1DIV>
200207de:	a905      	add	r1, sp, #20
200207e0:	4602      	mov	r2, r0
200207e2:	4819      	ldr	r0, [pc, #100]	@ (20020848 <boot_psram_init+0x19c>)
200207e4:	f004 f908 	bl	200249f8 <HAL_HYPER_PSRAM_Init>
200207e8:	4817      	ldr	r0, [pc, #92]	@ (20020848 <boot_psram_init+0x19c>)
200207ea:	f004 f939 	bl	20024a60 <HAL_HYPER_CFG_READ>
200207ee:	4816      	ldr	r0, [pc, #88]	@ (20020848 <boot_psram_init+0x19c>)
200207f0:	f004 f948 	bl	20024a84 <HAL_HYPER_CFG_WRITE>
200207f4:	e7cb      	b.n	2002078e <boot_psram_init+0xe2>
200207f6:	f001 fbbf 	bl	20021f78 <BSP_GetFlash1DIV>
200207fa:	2500      	movs	r5, #0
200207fc:	2403      	movs	r4, #3
200207fe:	2701      	movs	r7, #1
20020800:	2602      	movs	r6, #2
20020802:	4602      	mov	r2, r0
20020804:	a905      	add	r1, sp, #20
20020806:	4810      	ldr	r0, [pc, #64]	@ (20020848 <boot_psram_init+0x19c>)
20020808:	f003 fe2a 	bl	20024460 <HAL_SPI_PSRAM_Init>
2002080c:	462b      	mov	r3, r5
2002080e:	2206      	movs	r2, #6
20020810:	4621      	mov	r1, r4
20020812:	e9cd 4702 	strd	r4, r7, [sp, #8]
20020816:	e9cd 5600 	strd	r5, r6, [sp]
2002081a:	480b      	ldr	r0, [pc, #44]	@ (20020848 <boot_psram_init+0x19c>)
2002081c:	f002 fa4e 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20020820:	21eb      	movs	r1, #235	@ 0xeb
20020822:	4809      	ldr	r0, [pc, #36]	@ (20020848 <boot_psram_init+0x19c>)
20020824:	f002 fa3f 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20020828:	4621      	mov	r1, r4
2002082a:	462b      	mov	r3, r5
2002082c:	462a      	mov	r2, r5
2002082e:	e9cd 4702 	strd	r4, r7, [sp, #8]
20020832:	e9cd 5600 	strd	r5, r6, [sp]
20020836:	4804      	ldr	r0, [pc, #16]	@ (20020848 <boot_psram_init+0x19c>)
20020838:	f002 fa69 	bl	20022d0e <HAL_FLASH_CFG_AHB_WCMD>
2002083c:	2138      	movs	r1, #56	@ 0x38
2002083e:	4802      	ldr	r0, [pc, #8]	@ (20020848 <boot_psram_init+0x19c>)
20020840:	f002 fa59 	bl	20022cf6 <HAL_FLASH_SET_AHB_WCMD>
20020844:	e7a3      	b.n	2002078e <boot_psram_init+0xe2>
20020846:	bf00      	nop
20020848:	200449f0 	.word	0x200449f0
2002084c:	50041000 	.word	0x50041000
20020850:	07de2901 	.word	0x07de2901
20020854:	13c9eb01 	.word	0x13c9eb01
20020858:	17d78401 	.word	0x17d78401

2002085c <board_init_psram>:
2002085c:	b510      	push	{r4, lr}
2002085e:	4b15      	ldr	r3, [pc, #84]	@ (200208b4 <board_init_psram+0x58>)
20020860:	685c      	ldr	r4, [r3, #4]
20020862:	f3c4 2402 	ubfx	r4, r4, #8, #3
20020866:	1ea3      	subs	r3, r4, #2
20020868:	2b04      	cmp	r3, #4
2002086a:	d821      	bhi.n	200208b0 <board_init_psram+0x54>
2002086c:	e8df f003 	tbb	[pc, r3]
20020870:	03151b1d 	.word	0x03151b1d
20020874:	19          	.byte	0x19
20020875:	00          	.byte	0x00
20020876:	f7ff fed1 	bl	2002061c <board_pinmux_psram_func3>
2002087a:	2201      	movs	r2, #1
2002087c:	2000      	movs	r0, #0
2002087e:	4611      	mov	r1, r2
20020880:	f00b fe0e 	bl	2002c4a0 <HAL_PMU_ConfigPeriLdo>
20020884:	2001      	movs	r0, #1
20020886:	f7ff ff0c 	bl	200206a2 <bootloader_switch_clock>
2002088a:	2002      	movs	r0, #2
2002088c:	f001 fb80 	bl	20021f90 <BSP_SetFlash1DIV>
20020890:	4620      	mov	r0, r4
20020892:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20020896:	f7ff bf09 	b.w	200206ac <boot_psram_init>
2002089a:	2002      	movs	r0, #2
2002089c:	f7ff fe4c 	bl	20020538 <board_pinmux_psram_func1_2_4>
200208a0:	e7eb      	b.n	2002087a <board_init_psram+0x1e>
200208a2:	2004      	movs	r0, #4
200208a4:	e7fa      	b.n	2002089c <board_init_psram+0x40>
200208a6:	2001      	movs	r0, #1
200208a8:	e7f8      	b.n	2002089c <board_init_psram+0x40>
200208aa:	f7ff fdf8 	bl	2002049e <board_pinmux_psram_func0>
200208ae:	e7e4      	b.n	2002087a <board_init_psram+0x1e>
200208b0:	bd10      	pop	{r4, pc}
200208b2:	bf00      	nop
200208b4:	5000b000 	.word	0x5000b000

200208b8 <erase_nor>:
200208b8:	4b15      	ldr	r3, [pc, #84]	@ (20020910 <erase_nor+0x58>)
200208ba:	b570      	push	{r4, r5, r6, lr}
200208bc:	f103 0654 	add.w	r6, r3, #84	@ 0x54
200208c0:	f1b0 5f90 	cmp.w	r0, #301989888	@ 0x12000000
200208c4:	bf38      	it	cc
200208c6:	461e      	movcc	r6, r3
200208c8:	6933      	ldr	r3, [r6, #16]
200208ca:	460c      	mov	r4, r1
200208cc:	4283      	cmp	r3, r0
200208ce:	d901      	bls.n	200208d4 <erase_nor+0x1c>
200208d0:	2001      	movs	r0, #1
200208d2:	bd70      	pop	{r4, r5, r6, pc}
200208d4:	6972      	ldr	r2, [r6, #20]
200208d6:	441a      	add	r2, r3
200208d8:	4282      	cmp	r2, r0
200208da:	d3f9      	bcc.n	200208d0 <erase_nor+0x18>
200208dc:	1ac0      	subs	r0, r0, r3
200208de:	f3c0 030b 	ubfx	r3, r0, #0, #12
200208e2:	b97b      	cbnz	r3, 20020904 <erase_nor+0x4c>
200208e4:	f3c1 030b 	ubfx	r3, r1, #0, #12
200208e8:	b97b      	cbnz	r3, 2002090a <erase_nor+0x52>
200208ea:	1845      	adds	r5, r0, r1
200208ec:	1b29      	subs	r1, r5, r4
200208ee:	b90c      	cbnz	r4, 200208f4 <erase_nor+0x3c>
200208f0:	4620      	mov	r0, r4
200208f2:	e7ee      	b.n	200208d2 <erase_nor+0x1a>
200208f4:	4630      	mov	r0, r6
200208f6:	f003 fade 	bl	20023eb6 <HAL_QSPIEX_SECT_ERASE>
200208fa:	2800      	cmp	r0, #0
200208fc:	d1e8      	bne.n	200208d0 <erase_nor+0x18>
200208fe:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
20020902:	e7f3      	b.n	200208ec <erase_nor+0x34>
20020904:	f04f 30ff 	mov.w	r0, #4294967295
20020908:	e7e3      	b.n	200208d2 <erase_nor+0x1a>
2002090a:	f06f 0001 	mvn.w	r0, #1
2002090e:	e7e0      	b.n	200208d2 <erase_nor+0x1a>
20020910:	20046f50 	.word	0x20046f50

20020914 <write_nor>:
20020914:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020918:	4b20      	ldr	r3, [pc, #128]	@ (2002099c <write_nor+0x88>)
2002091a:	460f      	mov	r7, r1
2002091c:	f103 0854 	add.w	r8, r3, #84	@ 0x54
20020920:	f1b0 5f90 	cmp.w	r0, #301989888	@ 0x12000000
20020924:	bf38      	it	cc
20020926:	4698      	movcc	r8, r3
20020928:	f8d8 5010 	ldr.w	r5, [r8, #16]
2002092c:	4616      	mov	r6, r2
2002092e:	4285      	cmp	r5, r0
20020930:	d902      	bls.n	20020938 <write_nor+0x24>
20020932:	2000      	movs	r0, #0
20020934:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20020938:	f8d8 2014 	ldr.w	r2, [r8, #20]
2002093c:	442a      	add	r2, r5
2002093e:	4282      	cmp	r2, r0
20020940:	d3f7      	bcc.n	20020932 <write_nor+0x1e>
20020942:	1b45      	subs	r5, r0, r5
20020944:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
20020948:	d012      	beq.n	20020970 <write_nor+0x5c>
2002094a:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
2002094e:	42b4      	cmp	r4, r6
20020950:	bf28      	it	cs
20020952:	4634      	movcs	r4, r6
20020954:	460a      	mov	r2, r1
20020956:	4623      	mov	r3, r4
20020958:	4629      	mov	r1, r5
2002095a:	4640      	mov	r0, r8
2002095c:	f003 f9c6 	bl	20023cec <HAL_QSPIEX_WRITE_PAGE>
20020960:	4284      	cmp	r4, r0
20020962:	d1e6      	bne.n	20020932 <write_nor+0x1e>
20020964:	4425      	add	r5, r4
20020966:	4427      	add	r7, r4
20020968:	1b34      	subs	r4, r6, r4
2002096a:	b91c      	cbnz	r4, 20020974 <write_nor+0x60>
2002096c:	4630      	mov	r0, r6
2002096e:	e7e1      	b.n	20020934 <write_nor+0x20>
20020970:	4634      	mov	r4, r6
20020972:	e7fa      	b.n	2002096a <write_nor+0x56>
20020974:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20020978:	46a1      	mov	r9, r4
2002097a:	bf28      	it	cs
2002097c:	f44f 7980 	movcs.w	r9, #256	@ 0x100
20020980:	463a      	mov	r2, r7
20020982:	464b      	mov	r3, r9
20020984:	4629      	mov	r1, r5
20020986:	4640      	mov	r0, r8
20020988:	f003 f9b0 	bl	20023cec <HAL_QSPIEX_WRITE_PAGE>
2002098c:	4581      	cmp	r9, r0
2002098e:	d1d0      	bne.n	20020932 <write_nor+0x1e>
20020990:	444d      	add	r5, r9
20020992:	444f      	add	r7, r9
20020994:	eba4 0409 	sub.w	r4, r4, r9
20020998:	e7e7      	b.n	2002096a <write_nor+0x56>
2002099a:	bf00      	nop
2002099c:	20046f50 	.word	0x20046f50

200209a0 <read_nor>:
200209a0:	460b      	mov	r3, r1
200209a2:	b510      	push	{r4, lr}
200209a4:	4614      	mov	r4, r2
200209a6:	4601      	mov	r1, r0
200209a8:	4618      	mov	r0, r3
200209aa:	f00a f851 	bl	2002aa50 <memcpy>
200209ae:	4620      	mov	r0, r4
200209b0:	bd10      	pop	{r4, pc}
	...

200209b4 <read_nand>:
200209b4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200209b8:	2600      	movs	r6, #0
200209ba:	460f      	mov	r7, r1
200209bc:	4615      	mov	r5, r2
200209be:	46b0      	mov	r8, r6
200209c0:	4b19      	ldr	r3, [pc, #100]	@ (20020a28 <read_nand+0x74>)
200209c2:	f8df a068 	ldr.w	sl, [pc, #104]	@ 20020a2c <read_nand+0x78>
200209c6:	681b      	ldr	r3, [r3, #0]
200209c8:	f8df b064 	ldr.w	fp, [pc, #100]	@ 20020a30 <read_nand+0x7c>
200209cc:	691b      	ldr	r3, [r3, #16]
200209ce:	4604      	mov	r4, r0
200209d0:	4283      	cmp	r3, r0
200209d2:	b085      	sub	sp, #20
200209d4:	bf98      	it	ls
200209d6:	1ac4      	subls	r4, r0, r3
200209d8:	b91d      	cbnz	r5, 200209e2 <read_nand+0x2e>
200209da:	4630      	mov	r0, r6
200209dc:	b005      	add	sp, #20
200209de:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200209e2:	f8da 1000 	ldr.w	r1, [sl]
200209e6:	f8db 0000 	ldr.w	r0, [fp]
200209ea:	42a9      	cmp	r1, r5
200209ec:	fbb0 fcf1 	udiv	ip, r0, r1
200209f0:	4689      	mov	r9, r1
200209f2:	f101 32ff 	add.w	r2, r1, #4294967295
200209f6:	bf28      	it	cs
200209f8:	46a9      	movcs	r9, r5
200209fa:	fbb4 f1f1 	udiv	r1, r4, r1
200209fe:	f10c 3cff 	add.w	ip, ip, #4294967295
20020a02:	fbb4 f0f0 	udiv	r0, r4, r0
20020a06:	e9cd 8801 	strd	r8, r8, [sp, #4]
20020a0a:	f8cd 9000 	str.w	r9, [sp]
20020a0e:	19bb      	adds	r3, r7, r6
20020a10:	4022      	ands	r2, r4
20020a12:	ea0c 0101 	and.w	r1, ip, r1
20020a16:	f005 f809 	bl	20025a2c <bbm_read_page>
20020a1a:	4548      	cmp	r0, r9
20020a1c:	d1dd      	bne.n	200209da <read_nand+0x26>
20020a1e:	4406      	add	r6, r0
20020a20:	1a2d      	subs	r5, r5, r0
20020a22:	4404      	add	r4, r0
20020a24:	e7d8      	b.n	200209d8 <read_nand+0x24>
20020a26:	bf00      	nop
20020a28:	20046d38 	.word	0x20046d38
20020a2c:	20042c04 	.word	0x20042c04
20020a30:	20042c00 	.word	0x20042c00

20020a34 <read_sdnand>:
20020a34:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20020a38:	4616      	mov	r6, r2
20020a3a:	4614      	mov	r4, r2
20020a3c:	f100 451e 	add.w	r5, r0, #2650800128	@ 0x9e000000
20020a40:	188f      	adds	r7, r1, r2
20020a42:	f5b4 5f00 	cmp.w	r4, #8192	@ 0x2000
20020a46:	eba7 0804 	sub.w	r8, r7, r4
20020a4a:	d221      	bcs.n	20020a90 <read_sdnand+0x5c>
20020a4c:	f424 77ff 	bic.w	r7, r4, #510	@ 0x1fe
20020a50:	f027 0701 	bic.w	r7, r7, #1
20020a54:	f5b7 6f80 	cmp.w	r7, #1024	@ 0x400
20020a58:	d309      	bcc.n	20020a6e <read_sdnand+0x3a>
20020a5a:	463a      	mov	r2, r7
20020a5c:	4641      	mov	r1, r8
20020a5e:	4628      	mov	r0, r5
20020a60:	f001 f902 	bl	20021c68 <sd_read_multi>
20020a64:	4287      	cmp	r7, r0
20020a66:	d11c      	bne.n	20020aa2 <read_sdnand+0x6e>
20020a68:	1be4      	subs	r4, r4, r7
20020a6a:	443d      	add	r5, r7
20020a6c:	44b8      	add	r8, r7
20020a6e:	b16c      	cbz	r4, 20020a8c <read_sdnand+0x58>
20020a70:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020a74:	4628      	mov	r0, r5
20020a76:	490f      	ldr	r1, [pc, #60]	@ (20020ab4 <read_sdnand+0x80>)
20020a78:	f001 f87a 	bl	20021b70 <sd_read_data>
20020a7c:	f5b0 7f00 	cmp.w	r0, #512	@ 0x200
20020a80:	d10f      	bne.n	20020aa2 <read_sdnand+0x6e>
20020a82:	4622      	mov	r2, r4
20020a84:	4640      	mov	r0, r8
20020a86:	490b      	ldr	r1, [pc, #44]	@ (20020ab4 <read_sdnand+0x80>)
20020a88:	f009 ffe2 	bl	2002aa50 <memcpy>
20020a8c:	4630      	mov	r0, r6
20020a8e:	e009      	b.n	20020aa4 <read_sdnand+0x70>
20020a90:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020a94:	4641      	mov	r1, r8
20020a96:	4628      	mov	r0, r5
20020a98:	f001 f8e6 	bl	20021c68 <sd_read_multi>
20020a9c:	f5b0 5f00 	cmp.w	r0, #8192	@ 0x2000
20020aa0:	d002      	beq.n	20020aa8 <read_sdnand+0x74>
20020aa2:	2000      	movs	r0, #0
20020aa4:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20020aa8:	f5a4 5400 	sub.w	r4, r4, #8192	@ 0x2000
20020aac:	f505 5500 	add.w	r5, r5, #8192	@ 0x2000
20020ab0:	e7c7      	b.n	20020a42 <read_sdnand+0xe>
20020ab2:	bf00      	nop
20020ab4:	20046b34 	.word	0x20046b34

20020ab8 <read_sdemmc>:
20020ab8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020abc:	f100 461e 	add.w	r6, r0, #2650800128	@ 0x9e000000
20020ac0:	460d      	mov	r5, r1
20020ac2:	4614      	mov	r4, r2
20020ac4:	4617      	mov	r7, r2
20020ac6:	46b0      	mov	r8, r6
20020ac8:	eb02 0901 	add.w	r9, r2, r1
20020acc:	f5b7 7f00 	cmp.w	r7, #512	@ 0x200
20020ad0:	eba9 0107 	sub.w	r1, r9, r7
20020ad4:	d218      	bcs.n	20020b08 <read_sdemmc+0x50>
20020ad6:	f3c4 0708 	ubfx	r7, r4, #0, #9
20020ada:	b197      	cbz	r7, 20020b02 <read_sdemmc+0x4a>
20020adc:	f424 70ff 	bic.w	r0, r4, #510	@ 0x1fe
20020ae0:	f020 0001 	bic.w	r0, r0, #1
20020ae4:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020ae8:	490c      	ldr	r1, [pc, #48]	@ (20020b1c <read_sdemmc+0x64>)
20020aea:	4430      	add	r0, r6
20020aec:	f000 fe5a 	bl	200217a4 <emmc_read_data>
20020af0:	f424 70ff 	bic.w	r0, r4, #510	@ 0x1fe
20020af4:	f020 0001 	bic.w	r0, r0, #1
20020af8:	463a      	mov	r2, r7
20020afa:	4908      	ldr	r1, [pc, #32]	@ (20020b1c <read_sdemmc+0x64>)
20020afc:	4428      	add	r0, r5
20020afe:	f009 ffa7 	bl	2002aa50 <memcpy>
20020b02:	4620      	mov	r0, r4
20020b04:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20020b08:	4640      	mov	r0, r8
20020b0a:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020b0e:	f000 fe49 	bl	200217a4 <emmc_read_data>
20020b12:	f5a7 7700 	sub.w	r7, r7, #512	@ 0x200
20020b16:	f508 7800 	add.w	r8, r8, #512	@ 0x200
20020b1a:	e7d7      	b.n	20020acc <read_sdemmc+0x14>
20020b1c:	20046b34 	.word	0x20046b34

20020b20 <port_read_page>:
20020b20:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020b24:	4615      	mov	r5, r2
20020b26:	460e      	mov	r6, r1
20020b28:	492a      	ldr	r1, [pc, #168]	@ (20020bd4 <port_read_page+0xb4>)
20020b2a:	461a      	mov	r2, r3
20020b2c:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
20020b30:	680f      	ldr	r7, [r1, #0]
20020b32:	18e9      	adds	r1, r5, r3
20020b34:	428f      	cmp	r7, r1
20020b36:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
20020b3a:	d200      	bcs.n	20020b3e <port_read_page+0x1e>
20020b3c:	e7fe      	b.n	20020b3c <port_read_page+0x1c>
20020b3e:	4926      	ldr	r1, [pc, #152]	@ (20020bd8 <port_read_page+0xb8>)
20020b40:	f107 0980 	add.w	r9, r7, #128	@ 0x80
20020b44:	f1b9 0f00 	cmp.w	r9, #0
20020b48:	6809      	ldr	r1, [r1, #0]
20020b4a:	dd17      	ble.n	20020b7c <port_read_page+0x5c>
20020b4c:	4c23      	ldr	r4, [pc, #140]	@ (20020bdc <port_read_page+0xbc>)
20020b4e:	6e64      	ldr	r4, [r4, #100]	@ 0x64
20020b50:	f004 081f 	and.w	r8, r4, #31
20020b54:	44c8      	add	r8, r9
20020b56:	f024 041f 	bic.w	r4, r4, #31
20020b5a:	f3bf 8f4f 	dsb	sy
20020b5e:	f8df a084 	ldr.w	sl, [pc, #132]	@ 20020be4 <port_read_page+0xc4>
20020b62:	44a0      	add	r8, r4
20020b64:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
20020b68:	3420      	adds	r4, #32
20020b6a:	eba8 0904 	sub.w	r9, r8, r4
20020b6e:	f1b9 0f00 	cmp.w	r9, #0
20020b72:	dcf7      	bgt.n	20020b64 <port_read_page+0x44>
20020b74:	f3bf 8f4f 	dsb	sy
20020b78:	f3bf 8f6f 	isb	sy
20020b7c:	07c4      	lsls	r4, r0, #31
20020b7e:	d51d      	bpl.n	20020bbc <port_read_page+0x9c>
20020b80:	4c16      	ldr	r4, [pc, #88]	@ (20020bdc <port_read_page+0xbc>)
20020b82:	f894 8083 	ldrb.w	r8, [r4, #131]	@ 0x83
20020b86:	f1b8 0f00 	cmp.w	r8, #0
20020b8a:	d017      	beq.n	20020bbc <port_read_page+0x9c>
20020b8c:	6e64      	ldr	r4, [r4, #100]	@ 0x64
20020b8e:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
20020b92:	f004 041f 	and.w	r4, r4, #31
20020b96:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020b9a:	f028 081f 	bic.w	r8, r8, #31
20020b9e:	f3bf 8f4f 	dsb	sy
20020ba2:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 20020be4 <port_read_page+0xc4>
20020ba6:	3c20      	subs	r4, #32
20020ba8:	2c00      	cmp	r4, #0
20020baa:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
20020bae:	f108 0820 	add.w	r8, r8, #32
20020bb2:	dcf8      	bgt.n	20020ba6 <port_read_page+0x86>
20020bb4:	f3bf 8f4f 	dsb	sy
20020bb8:	f3bf 8f6f 	isb	sy
20020bbc:	fb07 5506 	mla	r5, r7, r6, r5
20020bc0:	e9cd ce08 	strd	ip, lr, [sp, #32]
20020bc4:	fb01 5100 	mla	r1, r1, r0, r5
20020bc8:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020bcc:	4804      	ldr	r0, [pc, #16]	@ (20020be0 <port_read_page+0xc0>)
20020bce:	f002 bfab 	b.w	20023b28 <HAL_NAND_READ_WITHOOB>
20020bd2:	bf00      	nop
20020bd4:	20042c04 	.word	0x20042c04
20020bd8:	20042c00 	.word	0x20042c00
20020bdc:	20046f50 	.word	0x20046f50
20020be0:	20046fa4 	.word	0x20046fa4
20020be4:	e000ed00 	.word	0xe000ed00

20020be8 <bbm_get_bb>:
20020be8:	b410      	push	{r4}
20020bea:	4b1e      	ldr	r3, [pc, #120]	@ (20020c64 <bbm_get_bb+0x7c>)
20020bec:	4601      	mov	r1, r0
20020bee:	6818      	ldr	r0, [r3, #0]
20020bf0:	3080      	adds	r0, #128	@ 0x80
20020bf2:	2800      	cmp	r0, #0
20020bf4:	dd14      	ble.n	20020c20 <bbm_get_bb+0x38>
20020bf6:	4b1c      	ldr	r3, [pc, #112]	@ (20020c68 <bbm_get_bb+0x80>)
20020bf8:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
20020bfa:	f003 021f 	and.w	r2, r3, #31
20020bfe:	4402      	add	r2, r0
20020c00:	f023 031f 	bic.w	r3, r3, #31
20020c04:	f3bf 8f4f 	dsb	sy
20020c08:	4c18      	ldr	r4, [pc, #96]	@ (20020c6c <bbm_get_bb+0x84>)
20020c0a:	441a      	add	r2, r3
20020c0c:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
20020c10:	3320      	adds	r3, #32
20020c12:	1ad0      	subs	r0, r2, r3
20020c14:	2800      	cmp	r0, #0
20020c16:	dcf9      	bgt.n	20020c0c <bbm_get_bb+0x24>
20020c18:	f3bf 8f4f 	dsb	sy
20020c1c:	f3bf 8f6f 	isb	sy
20020c20:	07cb      	lsls	r3, r1, #31
20020c22:	d51a      	bpl.n	20020c5a <bbm_get_bb+0x72>
20020c24:	4b10      	ldr	r3, [pc, #64]	@ (20020c68 <bbm_get_bb+0x80>)
20020c26:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
20020c2a:	b1b2      	cbz	r2, 20020c5a <bbm_get_bb+0x72>
20020c2c:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
20020c2e:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
20020c32:	f003 031f 	and.w	r3, r3, #31
20020c36:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
20020c3a:	f022 021f 	bic.w	r2, r2, #31
20020c3e:	f3bf 8f4f 	dsb	sy
20020c42:	480a      	ldr	r0, [pc, #40]	@ (20020c6c <bbm_get_bb+0x84>)
20020c44:	3b20      	subs	r3, #32
20020c46:	2b00      	cmp	r3, #0
20020c48:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
20020c4c:	f102 0220 	add.w	r2, r2, #32
20020c50:	dcf8      	bgt.n	20020c44 <bbm_get_bb+0x5c>
20020c52:	f3bf 8f4f 	dsb	sy
20020c56:	f3bf 8f6f 	isb	sy
20020c5a:	4805      	ldr	r0, [pc, #20]	@ (20020c70 <bbm_get_bb+0x88>)
20020c5c:	f85d 4b04 	ldr.w	r4, [sp], #4
20020c60:	f003 b823 	b.w	20023caa <HAL_NAND_GET_BADBLK>
20020c64:	20042c04 	.word	0x20042c04
20020c68:	20046f50 	.word	0x20046f50
20020c6c:	e000ed00 	.word	0xe000ed00
20020c70:	20046fa4 	.word	0x20046fa4

20020c74 <dfu_flash_init>:
20020c74:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020c78:	b08c      	sub	sp, #48	@ 0x30
20020c7a:	f001 ffdf 	bl	20022c3c <HAL_HPAON_EnableXT48>
20020c7e:	2101      	movs	r1, #1
20020c80:	2000      	movs	r0, #0
20020c82:	f004 fa7d 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20020c86:	2101      	movs	r1, #1
20020c88:	200c      	movs	r0, #12
20020c8a:	f004 fa79 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20020c8e:	2001      	movs	r0, #1
20020c90:	f004 f96c 	bl	20024f6c <HAL_PMU_EnableDLL>
20020c94:	4fa3      	ldr	r7, [pc, #652]	@ (20020f24 <dfu_flash_init+0x2b0>)
20020c96:	2090      	movs	r0, #144	@ 0x90
20020c98:	f004 fbf3 	bl	20025482 <HAL_RCC_HCPU_ConfigHCLK>
20020c9c:	2000      	movs	r0, #0
20020c9e:	f001 fa5c 	bl	2002215a <HAL_Delay_us>
20020ca2:	683b      	ldr	r3, [r7, #0]
20020ca4:	4ca0      	ldr	r4, [pc, #640]	@ (20020f28 <dfu_flash_init+0x2b4>)
20020ca6:	3b01      	subs	r3, #1
20020ca8:	2b05      	cmp	r3, #5
20020caa:	f200 812a 	bhi.w	20020f02 <dfu_flash_init+0x28e>
20020cae:	e8df f013 	tbh	[pc, r3, lsl #1]
20020cb2:	0006      	.short	0x0006
20020cb4:	007d0006 	.word	0x007d0006
20020cb8:	0105007d 	.word	0x0105007d
20020cbc:	0119      	.short	0x0119
20020cbe:	489b      	ldr	r0, [pc, #620]	@ (20020f2c <dfu_flash_init+0x2b8>)
20020cc0:	f004 fa2e 	bl	20025120 <HAL_RCC_HCPU_EnableDLL2>
20020cc4:	4e9a      	ldr	r6, [pc, #616]	@ (20020f30 <dfu_flash_init+0x2bc>)
20020cc6:	2006      	movs	r0, #6
20020cc8:	f001 f962 	bl	20021f90 <BSP_SetFlash1DIV>
20020ccc:	ad02      	add	r5, sp, #8
20020cce:	2102      	movs	r1, #2
20020cd0:	2004      	movs	r0, #4
20020cd2:	f004 fa55 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20020cd6:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020cd8:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020cda:	6833      	ldr	r3, [r6, #0]
20020cdc:	2210      	movs	r2, #16
20020cde:	602b      	str	r3, [r5, #0]
20020ce0:	2100      	movs	r1, #0
20020ce2:	a808      	add	r0, sp, #32
20020ce4:	f009 fe9a 	bl	2002aa1c <memset>
20020ce8:	4b92      	ldr	r3, [pc, #584]	@ (20020f34 <dfu_flash_init+0x2c0>)
20020cea:	4d93      	ldr	r5, [pc, #588]	@ (20020f38 <dfu_flash_init+0x2c4>)
20020cec:	9307      	str	r3, [sp, #28]
20020cee:	2332      	movs	r3, #50	@ 0x32
20020cf0:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020cf4:	2301      	movs	r3, #1
20020cf6:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
20020cfa:	2300      	movs	r3, #0
20020cfc:	9303      	str	r3, [sp, #12]
20020cfe:	683b      	ldr	r3, [r7, #0]
20020d00:	2b01      	cmp	r3, #1
20020d02:	d14e      	bne.n	20020da2 <dfu_flash_init+0x12e>
20020d04:	f7ff fabc 	bl	20020280 <board_pinmux_mpi1_puya_base>
20020d08:	f001 f936 	bl	20021f78 <BSP_GetFlash1DIV>
20020d0c:	4a8b      	ldr	r2, [pc, #556]	@ (20020f3c <dfu_flash_init+0x2c8>)
20020d0e:	9000      	str	r0, [sp, #0]
20020d10:	ab07      	add	r3, sp, #28
20020d12:	4889      	ldr	r0, [pc, #548]	@ (20020f38 <dfu_flash_init+0x2c4>)
20020d14:	a902      	add	r1, sp, #8
20020d16:	f003 f99f 	bl	20024058 <HAL_FLASH_Init>
20020d1a:	683e      	ldr	r6, [r7, #0]
20020d1c:	2e01      	cmp	r6, #1
20020d1e:	d10d      	bne.n	20020d3c <dfu_flash_init+0xc8>
20020d20:	6c28      	ldr	r0, [r5, #64]	@ 0x40
20020d22:	4b87      	ldr	r3, [pc, #540]	@ (20020f40 <dfu_flash_init+0x2cc>)
20020d24:	1ac3      	subs	r3, r0, r3
20020d26:	4258      	negs	r0, r3
20020d28:	4158      	adcs	r0, r3
20020d2a:	f7ff faca 	bl	200202c2 <board_pinmux_mpi1_puya_ext>
20020d2e:	4631      	mov	r1, r6
20020d30:	4881      	ldr	r0, [pc, #516]	@ (20020f38 <dfu_flash_init+0x2c4>)
20020d32:	f002 fbee 	bl	20023512 <HAL_FLASH_SET_QUAL_SPI>
20020d36:	2302      	movs	r3, #2
20020d38:	f885 3028 	strb.w	r3, [r5, #40]	@ 0x28
20020d3c:	4b81      	ldr	r3, [pc, #516]	@ (20020f44 <dfu_flash_init+0x2d0>)
20020d3e:	4a82      	ldr	r2, [pc, #520]	@ (20020f48 <dfu_flash_init+0x2d4>)
20020d40:	6023      	str	r3, [r4, #0]
20020d42:	4b82      	ldr	r3, [pc, #520]	@ (20020f4c <dfu_flash_init+0x2d8>)
20020d44:	601a      	str	r2, [r3, #0]
20020d46:	4b82      	ldr	r3, [pc, #520]	@ (20020f50 <dfu_flash_init+0x2dc>)
20020d48:	4a82      	ldr	r2, [pc, #520]	@ (20020f54 <dfu_flash_init+0x2e0>)
20020d4a:	601a      	str	r2, [r3, #0]
20020d4c:	4b82      	ldr	r3, [pc, #520]	@ (20020f58 <dfu_flash_init+0x2e4>)
20020d4e:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020d50:	601a      	str	r2, [r3, #0]
20020d52:	4b82      	ldr	r3, [pc, #520]	@ (20020f5c <dfu_flash_init+0x2e8>)
20020d54:	601d      	str	r5, [r3, #0]
20020d56:	2505      	movs	r5, #5
20020d58:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 20020f60 <dfu_flash_init+0x2ec>
20020d5c:	4e7e      	ldr	r6, [pc, #504]	@ (20020f58 <dfu_flash_init+0x2e4>)
20020d5e:	f8df 9238 	ldr.w	r9, [pc, #568]	@ 20020f98 <dfu_flash_init+0x324>
20020d62:	6823      	ldr	r3, [r4, #0]
20020d64:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d68:	497d      	ldr	r1, [pc, #500]	@ (20020f60 <dfu_flash_init+0x2ec>)
20020d6a:	6830      	ldr	r0, [r6, #0]
20020d6c:	4798      	blx	r3
20020d6e:	f8d8 3000 	ldr.w	r3, [r8]
20020d72:	454b      	cmp	r3, r9
20020d74:	f040 80c9 	bne.w	20020f0a <dfu_flash_init+0x296>
20020d78:	683b      	ldr	r3, [r7, #0]
20020d7a:	2b04      	cmp	r3, #4
20020d7c:	f040 808e 	bne.w	20020e9c <dfu_flash_init+0x228>
20020d80:	f8d8 30a4 	ldr.w	r3, [r8, #164]	@ 0xa4
20020d84:	1e5a      	subs	r2, r3, #1
20020d86:	3203      	adds	r2, #3
20020d88:	f200 8088 	bhi.w	20020e9c <dfu_flash_init+0x228>
20020d8c:	4a75      	ldr	r2, [pc, #468]	@ (20020f64 <dfu_flash_init+0x2f0>)
20020d8e:	4974      	ldr	r1, [pc, #464]	@ (20020f60 <dfu_flash_init+0x2ec>)
20020d90:	6013      	str	r3, [r2, #0]
20020d92:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d96:	6823      	ldr	r3, [r4, #0]
20020d98:	6830      	ldr	r0, [r6, #0]
20020d9a:	b00c      	add	sp, #48	@ 0x30
20020d9c:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020da0:	4718      	bx	r3
20020da2:	f7ff fabd 	bl	20020320 <board_pinmux_mpi1_gd>
20020da6:	2302      	movs	r3, #2
20020da8:	9303      	str	r3, [sp, #12]
20020daa:	e7ad      	b.n	20020d08 <dfu_flash_init+0x94>
20020dac:	485f      	ldr	r0, [pc, #380]	@ (20020f2c <dfu_flash_init+0x2b8>)
20020dae:	f004 f9b7 	bl	20025120 <HAL_RCC_HCPU_EnableDLL2>
20020db2:	4e6d      	ldr	r6, [pc, #436]	@ (20020f68 <dfu_flash_init+0x2f4>)
20020db4:	2006      	movs	r0, #6
20020db6:	f001 f8f1 	bl	20021f9c <BSP_SetFlash2DIV>
20020dba:	ad02      	add	r5, sp, #8
20020dbc:	2102      	movs	r1, #2
20020dbe:	2006      	movs	r0, #6
20020dc0:	f004 f9de 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20020dc4:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020dc6:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020dc8:	f8d7 8000 	ldr.w	r8, [r7]
20020dcc:	6833      	ldr	r3, [r6, #0]
20020dce:	f1b8 0a03 	subs.w	sl, r8, #3
20020dd2:	602b      	str	r3, [r5, #0]
20020dd4:	f04f 0210 	mov.w	r2, #16
20020dd8:	f04f 0100 	mov.w	r1, #0
20020ddc:	a808      	add	r0, sp, #32
20020dde:	bf18      	it	ne
20020de0:	f04f 0a01 	movne.w	sl, #1
20020de4:	f009 fe1a 	bl	2002aa1c <memset>
20020de8:	4b60      	ldr	r3, [pc, #384]	@ (20020f6c <dfu_flash_init+0x2f8>)
20020dea:	2601      	movs	r6, #1
20020dec:	9307      	str	r3, [sp, #28]
20020dee:	2333      	movs	r3, #51	@ 0x33
20020df0:	960a      	str	r6, [sp, #40]	@ 0x28
20020df2:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020df6:	f7ff fad6 	bl	200203a6 <board_pinmux_mpi2>
20020dfa:	2302      	movs	r3, #2
20020dfc:	f1b8 0f03 	cmp.w	r8, #3
20020e00:	4d4d      	ldr	r5, [pc, #308]	@ (20020f38 <dfu_flash_init+0x2c4>)
20020e02:	9303      	str	r3, [sp, #12]
20020e04:	d04d      	beq.n	20020ea2 <dfu_flash_init+0x22e>
20020e06:	4b5a      	ldr	r3, [pc, #360]	@ (20020f70 <dfu_flash_init+0x2fc>)
20020e08:	9606      	str	r6, [sp, #24]
20020e0a:	6023      	str	r3, [r4, #0]
20020e0c:	9b04      	ldr	r3, [sp, #16]
20020e0e:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020e12:	9304      	str	r3, [sp, #16]
20020e14:	4b57      	ldr	r3, [pc, #348]	@ (20020f74 <dfu_flash_init+0x300>)
20020e16:	672b      	str	r3, [r5, #112]	@ 0x70
20020e18:	f04f 0901 	mov.w	r9, #1
20020e1c:	2000      	movs	r0, #0
20020e1e:	f001 f99c 	bl	2002215a <HAL_Delay_us>
20020e22:	f885 9099 	strb.w	r9, [r5, #153]	@ 0x99
20020e26:	f885 a098 	strb.w	sl, [r5, #152]	@ 0x98
20020e2a:	f001 f8ab 	bl	20021f84 <BSP_GetFlash2DIV>
20020e2e:	4a52      	ldr	r2, [pc, #328]	@ (20020f78 <dfu_flash_init+0x304>)
20020e30:	9000      	str	r0, [sp, #0]
20020e32:	ab07      	add	r3, sp, #28
20020e34:	4851      	ldr	r0, [pc, #324]	@ (20020f7c <dfu_flash_init+0x308>)
20020e36:	a902      	add	r1, sp, #8
20020e38:	f003 f90e 	bl	20024058 <HAL_FLASH_Init>
20020e3c:	4e4f      	ldr	r6, [pc, #316]	@ (20020f7c <dfu_flash_init+0x308>)
20020e3e:	bb98      	cbnz	r0, 20020ea8 <dfu_flash_init+0x234>
20020e40:	f1b8 0f03 	cmp.w	r8, #3
20020e44:	d033      	beq.n	20020eae <dfu_flash_init+0x23a>
20020e46:	4630      	mov	r0, r6
20020e48:	f002 fe63 	bl	20023b12 <HAL_NAND_PAGE_SIZE>
20020e4c:	f8df a114 	ldr.w	sl, [pc, #276]	@ 20020f64 <dfu_flash_init+0x2f0>
20020e50:	f8df 8148 	ldr.w	r8, [pc, #328]	@ 20020f9c <dfu_flash_init+0x328>
20020e54:	f8ca 0000 	str.w	r0, [sl]
20020e58:	4630      	mov	r0, r6
20020e5a:	f002 ff1a 	bl	20023c92 <HAL_NAND_BLOCK_SIZE>
20020e5e:	4649      	mov	r1, r9
20020e60:	f8c8 0000 	str.w	r0, [r8]
20020e64:	4630      	mov	r0, r6
20020e66:	f885 9082 	strb.w	r9, [r5, #130]	@ 0x82
20020e6a:	f002 fd12 	bl	20023892 <HAL_NAND_CONF_ECC>
20020e6e:	f8da 0000 	ldr.w	r0, [sl]
20020e72:	f005 f8c1 	bl	20025ff8 <bbm_set_page_size>
20020e76:	f8d8 0000 	ldr.w	r0, [r8]
20020e7a:	f005 f8c3 	bl	20026004 <bbm_set_blk_size>
20020e7e:	4940      	ldr	r1, [pc, #256]	@ (20020f80 <dfu_flash_init+0x30c>)
20020e80:	f8d5 00a0 	ldr.w	r0, [r5, #160]	@ 0xa0
20020e84:	f004 ff5a 	bl	20025d3c <sif_bbm_init>
20020e88:	4b33      	ldr	r3, [pc, #204]	@ (20020f58 <dfu_flash_init+0x2e4>)
20020e8a:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
20020e8e:	601a      	str	r2, [r3, #0]
20020e90:	4b32      	ldr	r3, [pc, #200]	@ (20020f5c <dfu_flash_init+0x2e8>)
20020e92:	601e      	str	r6, [r3, #0]
20020e94:	6823      	ldr	r3, [r4, #0]
20020e96:	2b00      	cmp	r3, #0
20020e98:	f47f af5d 	bne.w	20020d56 <dfu_flash_init+0xe2>
20020e9c:	b00c      	add	sp, #48	@ 0x30
20020e9e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020ea2:	4b28      	ldr	r3, [pc, #160]	@ (20020f44 <dfu_flash_init+0x2d0>)
20020ea4:	6023      	str	r3, [r4, #0]
20020ea6:	e7b7      	b.n	20020e18 <dfu_flash_init+0x1a4>
20020ea8:	f1b8 0f03 	cmp.w	r8, #3
20020eac:	d1ec      	bne.n	20020e88 <dfu_flash_init+0x214>
20020eae:	4b27      	ldr	r3, [pc, #156]	@ (20020f4c <dfu_flash_init+0x2d8>)
20020eb0:	4a25      	ldr	r2, [pc, #148]	@ (20020f48 <dfu_flash_init+0x2d4>)
20020eb2:	601a      	str	r2, [r3, #0]
20020eb4:	4b26      	ldr	r3, [pc, #152]	@ (20020f50 <dfu_flash_init+0x2dc>)
20020eb6:	4a27      	ldr	r2, [pc, #156]	@ (20020f54 <dfu_flash_init+0x2e0>)
20020eb8:	601a      	str	r2, [r3, #0]
20020eba:	e7e5      	b.n	20020e88 <dfu_flash_init+0x214>
20020ebc:	481b      	ldr	r0, [pc, #108]	@ (20020f2c <dfu_flash_init+0x2b8>)
20020ebe:	f004 f92f 	bl	20025120 <HAL_RCC_HCPU_EnableDLL2>
20020ec2:	f7ff fa97 	bl	200203f4 <board_pinmux_sd>
20020ec6:	f000 fd57 	bl	20021978 <sdmmc1_sdnand>
20020eca:	2801      	cmp	r0, #1
20020ecc:	d001      	beq.n	20020ed2 <dfu_flash_init+0x25e>
20020ece:	f7ff f9a7 	bl	20020220 <boot_error>
20020ed2:	4b2c      	ldr	r3, [pc, #176]	@ (20020f84 <dfu_flash_init+0x310>)
20020ed4:	4a2c      	ldr	r2, [pc, #176]	@ (20020f88 <dfu_flash_init+0x314>)
20020ed6:	6023      	str	r3, [r4, #0]
20020ed8:	4b1f      	ldr	r3, [pc, #124]	@ (20020f58 <dfu_flash_init+0x2e4>)
20020eda:	601a      	str	r2, [r3, #0]
20020edc:	2200      	movs	r2, #0
20020ede:	4b1f      	ldr	r3, [pc, #124]	@ (20020f5c <dfu_flash_init+0x2e8>)
20020ee0:	601a      	str	r2, [r3, #0]
20020ee2:	e738      	b.n	20020d56 <dfu_flash_init+0xe2>
20020ee4:	4811      	ldr	r0, [pc, #68]	@ (20020f2c <dfu_flash_init+0x2b8>)
20020ee6:	f004 f91b 	bl	20025120 <HAL_RCC_HCPU_EnableDLL2>
20020eea:	f7ff fa83 	bl	200203f4 <board_pinmux_sd>
20020eee:	f000 fb33 	bl	20021558 <sdio_emmc_init>
20020ef2:	4b26      	ldr	r3, [pc, #152]	@ (20020f8c <dfu_flash_init+0x318>)
20020ef4:	6018      	str	r0, [r3, #0]
20020ef6:	b110      	cbz	r0, 20020efe <dfu_flash_init+0x28a>
20020ef8:	b2c0      	uxtb	r0, r0
20020efa:	f7ff f991 	bl	20020220 <boot_error>
20020efe:	4b24      	ldr	r3, [pc, #144]	@ (20020f90 <dfu_flash_init+0x31c>)
20020f00:	e7e8      	b.n	20020ed4 <dfu_flash_init+0x260>
20020f02:	2053      	movs	r0, #83	@ 0x53
20020f04:	f7ff f98c 	bl	20020220 <boot_error>
20020f08:	e7c4      	b.n	20020e94 <dfu_flash_init+0x220>
20020f0a:	4822      	ldr	r0, [pc, #136]	@ (20020f94 <dfu_flash_init+0x320>)
20020f0c:	f001 f925 	bl	2002215a <HAL_Delay_us>
20020f10:	3d01      	subs	r5, #1
20020f12:	f47f af26 	bne.w	20020d62 <dfu_flash_init+0xee>
20020f16:	2043      	movs	r0, #67	@ 0x43
20020f18:	b00c      	add	sp, #48	@ 0x30
20020f1a:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020f1e:	f7ff b97f 	b.w	20020220 <boot_error>
20020f22:	bf00      	nop
20020f24:	20049fa4 	.word	0x20049fa4
20020f28:	20046d44 	.word	0x20046d44
20020f2c:	112a8800 	.word	0x112a8800
20020f30:	2002ab20 	.word	0x2002ab20
20020f34:	50081008 	.word	0x50081008
20020f38:	20046f50 	.word	0x20046f50
20020f3c:	20046d48 	.word	0x20046d48
20020f40:	00176085 	.word	0x00176085
20020f44:	200209a1 	.word	0x200209a1
20020f48:	20020915 	.word	0x20020915
20020f4c:	20046d40 	.word	0x20046d40
20020f50:	20046d3c 	.word	0x20046d3c
20020f54:	200208b9 	.word	0x200208b9
20020f58:	20046d34 	.word	0x20046d34
20020f5c:	20046d38 	.word	0x20046d38
20020f60:	20047394 	.word	0x20047394
20020f64:	20042c04 	.word	0x20042c04
20020f68:	2002ab34 	.word	0x2002ab34
20020f6c:	5008101c 	.word	0x5008101c
20020f70:	200209b5 	.word	0x200209b5
20020f74:	20045ab4 	.word	0x20045ab4
20020f78:	20046db0 	.word	0x20046db0
20020f7c:	20046fa4 	.word	0x20046fa4
20020f80:	20044a34 	.word	0x20044a34
20020f84:	20020a35 	.word	0x20020a35
20020f88:	62001000 	.word	0x62001000
20020f8c:	20044a30 	.word	0x20044a30
20020f90:	20020ab9 	.word	0x20020ab9
20020f94:	000f4240 	.word	0x000f4240
20020f98:	53454346 	.word	0x53454346
20020f9c:	20042c00 	.word	0x20042c00

20020fa0 <sifli_hw_efuse_read_bank>:
20020fa0:	2803      	cmp	r0, #3
20020fa2:	b508      	push	{r3, lr}
20020fa4:	d80c      	bhi.n	20020fc0 <sifli_hw_efuse_read_bank+0x20>
20020fa6:	0200      	lsls	r0, r0, #8
20020fa8:	2220      	movs	r2, #32
20020faa:	4907      	ldr	r1, [pc, #28]	@ (20020fc8 <sifli_hw_efuse_read_bank+0x28>)
20020fac:	f400 407f 	and.w	r0, r0, #65280	@ 0xff00
20020fb0:	f001 fdbe 	bl	20022b30 <HAL_EFUSE_Read>
20020fb4:	2800      	cmp	r0, #0
20020fb6:	bf0c      	ite	eq
20020fb8:	f06f 0001 	mvneq.w	r0, #1
20020fbc:	2000      	movne	r0, #0
20020fbe:	bd08      	pop	{r3, pc}
20020fc0:	f04f 30ff 	mov.w	r0, #4294967295
20020fc4:	e7fb      	b.n	20020fbe <sifli_hw_efuse_read_bank+0x1e>
20020fc6:	bf00      	nop
20020fc8:	20047314 	.word	0x20047314

20020fcc <sifli_hw_efuse_read>:
20020fcc:	b513      	push	{r0, r1, r4, lr}
20020fce:	3801      	subs	r0, #1
20020fd0:	460c      	mov	r4, r1
20020fd2:	2803      	cmp	r0, #3
20020fd4:	d81e      	bhi.n	20021014 <sifli_hw_efuse_read+0x48>
20020fd6:	e8df f000 	tbb	[pc, r0]
20020fda:	0c02      	.short	0x0c02
20020fdc:	1009      	.short	0x1009
20020fde:	2210      	movs	r2, #16
20020fe0:	2000      	movs	r0, #0
20020fe2:	b002      	add	sp, #8
20020fe4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20020fe8:	f001 bda2 	b.w	20022b30 <HAL_EFUSE_Read>
20020fec:	2208      	movs	r2, #8
20020fee:	2080      	movs	r0, #128	@ 0x80
20020ff0:	e7f7      	b.n	20020fe2 <sifli_hw_efuse_read+0x16>
20020ff2:	2220      	movs	r2, #32
20020ff4:	f44f 7040 	mov.w	r0, #768	@ 0x300
20020ff8:	e7f3      	b.n	20020fe2 <sifli_hw_efuse_read+0x16>
20020ffa:	2204      	movs	r2, #4
20020ffc:	20c0      	movs	r0, #192	@ 0xc0
20020ffe:	eb0d 0102 	add.w	r1, sp, r2
20021002:	f001 fd95 	bl	20022b30 <HAL_EFUSE_Read>
20021006:	2804      	cmp	r0, #4
20021008:	d104      	bne.n	20021014 <sifli_hw_efuse_read+0x48>
2002100a:	2001      	movs	r0, #1
2002100c:	9b01      	ldr	r3, [sp, #4]
2002100e:	7023      	strb	r3, [r4, #0]
20021010:	b002      	add	sp, #8
20021012:	bd10      	pop	{r4, pc}
20021014:	2000      	movs	r0, #0
20021016:	e7fb      	b.n	20021010 <sifli_hw_efuse_read+0x44>

20021018 <sifli_hw_init_xip_key>:
20021018:	b538      	push	{r3, r4, r5, lr}
2002101a:	4605      	mov	r5, r0
2002101c:	4c0f      	ldr	r4, [pc, #60]	@ (2002105c <sifli_hw_init_xip_key+0x44>)
2002101e:	2210      	movs	r2, #16
20021020:	68e3      	ldr	r3, [r4, #12]
20021022:	490f      	ldr	r1, [pc, #60]	@ (20021060 <sifli_hw_init_xip_key+0x48>)
20021024:	f043 0301 	orr.w	r3, r3, #1
20021028:	60e3      	str	r3, [r4, #12]
2002102a:	2001      	movs	r0, #1
2002102c:	f7ff ffce 	bl	20020fcc <sifli_hw_efuse_read>
20021030:	2220      	movs	r2, #32
20021032:	2100      	movs	r1, #0
20021034:	480b      	ldr	r0, [pc, #44]	@ (20021064 <sifli_hw_init_xip_key+0x4c>)
20021036:	f009 fcf1 	bl	2002aa1c <memset>
2002103a:	2302      	movs	r3, #2
2002103c:	2120      	movs	r1, #32
2002103e:	4a08      	ldr	r2, [pc, #32]	@ (20021060 <sifli_hw_init_xip_key+0x48>)
20021040:	2000      	movs	r0, #0
20021042:	f001 f903 	bl	2002224c <HAL_AES_init>
20021046:	2320      	movs	r3, #32
20021048:	4629      	mov	r1, r5
2002104a:	2000      	movs	r0, #0
2002104c:	4a05      	ldr	r2, [pc, #20]	@ (20021064 <sifli_hw_init_xip_key+0x4c>)
2002104e:	f001 f943 	bl	200222d8 <HAL_AES_run>
20021052:	68e3      	ldr	r3, [r4, #12]
20021054:	f023 0301 	bic.w	r3, r3, #1
20021058:	60e3      	str	r3, [r4, #12]
2002105a:	bd38      	pop	{r3, r4, r5, pc}
2002105c:	5000b000 	.word	0x5000b000
20021060:	20047344 	.word	0x20047344
20021064:	200472f4 	.word	0x200472f4

20021068 <sifli_hw_dec_key>:
20021068:	b538      	push	{r3, r4, r5, lr}
2002106a:	4604      	mov	r4, r0
2002106c:	460d      	mov	r5, r1
2002106e:	2210      	movs	r2, #16
20021070:	4908      	ldr	r1, [pc, #32]	@ (20021094 <sifli_hw_dec_key+0x2c>)
20021072:	2001      	movs	r0, #1
20021074:	f7ff ffaa 	bl	20020fcc <sifli_hw_efuse_read>
20021078:	2302      	movs	r3, #2
2002107a:	2120      	movs	r1, #32
2002107c:	4a05      	ldr	r2, [pc, #20]	@ (20021094 <sifli_hw_dec_key+0x2c>)
2002107e:	2000      	movs	r0, #0
20021080:	f001 f8e4 	bl	2002224c <HAL_AES_init>
20021084:	2320      	movs	r3, #32
20021086:	462a      	mov	r2, r5
20021088:	4621      	mov	r1, r4
2002108a:	2000      	movs	r0, #0
2002108c:	f001 f924 	bl	200222d8 <HAL_AES_run>
20021090:	2000      	movs	r0, #0
20021092:	bd38      	pop	{r3, r4, r5, pc}
20021094:	20047344 	.word	0x20047344

20021098 <dfu_get_counter>:
20021098:	b538      	push	{r3, r4, r5, lr}
2002109a:	4d0a      	ldr	r5, [pc, #40]	@ (200210c4 <dfu_get_counter+0x2c>)
2002109c:	4604      	mov	r4, r0
2002109e:	2208      	movs	r2, #8
200210a0:	4629      	mov	r1, r5
200210a2:	2003      	movs	r0, #3
200210a4:	f7ff ff92 	bl	20020fcc <sifli_hw_efuse_read>
200210a8:	2300      	movs	r3, #0
200210aa:	e9c5 3302 	strd	r3, r3, [r5, #8]
200210ae:	230f      	movs	r3, #15
200210b0:	0924      	lsrs	r4, r4, #4
200210b2:	b12c      	cbz	r4, 200210c0 <dfu_get_counter+0x28>
200210b4:	54ec      	strb	r4, [r5, r3]
200210b6:	3b01      	subs	r3, #1
200210b8:	2b0b      	cmp	r3, #11
200210ba:	ea4f 2414 	mov.w	r4, r4, lsr #8
200210be:	d1f8      	bne.n	200210b2 <dfu_get_counter+0x1a>
200210c0:	4800      	ldr	r0, [pc, #0]	@ (200210c4 <dfu_get_counter+0x2c>)
200210c2:	bd38      	pop	{r3, r4, r5, pc}
200210c4:	20047334 	.word	0x20047334

200210c8 <sifli_hw_dec>:
200210c8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200210cc:	4680      	mov	r8, r0
200210ce:	4689      	mov	r9, r1
200210d0:	4692      	mov	sl, r2
200210d2:	2100      	movs	r1, #0
200210d4:	f44f 7200 	mov.w	r2, #512	@ 0x200
200210d8:	4814      	ldr	r0, [pc, #80]	@ (2002112c <sifli_hw_dec+0x64>)
200210da:	461e      	mov	r6, r3
200210dc:	9f08      	ldr	r7, [sp, #32]
200210de:	2400      	movs	r4, #0
200210e0:	f009 fc9c 	bl	2002aa1c <memset>
200210e4:	42a6      	cmp	r6, r4
200210e6:	d802      	bhi.n	200210ee <sifli_hw_dec+0x26>
200210e8:	4620      	mov	r0, r4
200210ea:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200210ee:	1b35      	subs	r5, r6, r4
200210f0:	f5b5 7f00 	cmp.w	r5, #512	@ 0x200
200210f4:	bf28      	it	cs
200210f6:	f44f 7500 	movcs.w	r5, #512	@ 0x200
200210fa:	eb09 0104 	add.w	r1, r9, r4
200210fe:	462a      	mov	r2, r5
20021100:	480a      	ldr	r0, [pc, #40]	@ (2002112c <sifli_hw_dec+0x64>)
20021102:	f009 fca5 	bl	2002aa50 <memcpy>
20021106:	19e0      	adds	r0, r4, r7
20021108:	f7ff ffc6 	bl	20021098 <dfu_get_counter>
2002110c:	2301      	movs	r3, #1
2002110e:	4602      	mov	r2, r0
20021110:	2120      	movs	r1, #32
20021112:	4640      	mov	r0, r8
20021114:	f001 f89a 	bl	2002224c <HAL_AES_init>
20021118:	eb0a 0204 	add.w	r2, sl, r4
2002111c:	462b      	mov	r3, r5
2002111e:	2000      	movs	r0, #0
20021120:	4902      	ldr	r1, [pc, #8]	@ (2002112c <sifli_hw_dec+0x64>)
20021122:	f001 f8d9 	bl	200222d8 <HAL_AES_run>
20021126:	442c      	add	r4, r5
20021128:	e7dc      	b.n	200210e4 <sifli_hw_dec+0x1c>
2002112a:	bf00      	nop
2002112c:	200470f4 	.word	0x200470f4

20021130 <update_sec_flash>:
20021130:	b510      	push	{r4, lr}
20021132:	4604      	mov	r4, r0
20021134:	4b08      	ldr	r3, [pc, #32]	@ (20021158 <update_sec_flash+0x28>)
20021136:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
2002113a:	681b      	ldr	r3, [r3, #0]
2002113c:	f04f 5090 	mov.w	r0, #301989888	@ 0x12000000
20021140:	4798      	blx	r3
20021142:	4b06      	ldr	r3, [pc, #24]	@ (2002115c <update_sec_flash+0x2c>)
20021144:	4621      	mov	r1, r4
20021146:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002114a:	f642 4210 	movw	r2, #11280	@ 0x2c10
2002114e:	f04f 5090 	mov.w	r0, #301989888	@ 0x12000000
20021152:	681b      	ldr	r3, [r3, #0]
20021154:	4718      	bx	r3
20021156:	bf00      	nop
20021158:	20046d3c 	.word	0x20046d3c
2002115c:	20046d44 	.word	0x20046d44

20021160 <boot_ram>:
20021160:	4b05      	ldr	r3, [pc, #20]	@ (20021178 <boot_ram+0x18>)
20021162:	b082      	sub	sp, #8
20021164:	6b9b      	ldr	r3, [r3, #56]	@ 0x38
20021166:	9301      	str	r3, [sp, #4]
20021168:	9b01      	ldr	r3, [sp, #4]
2002116a:	b113      	cbz	r3, 20021172 <boot_ram+0x12>
2002116c:	9b01      	ldr	r3, [sp, #4]
2002116e:	b002      	add	sp, #8
20021170:	4718      	bx	r3
20021172:	b002      	add	sp, #8
20021174:	4770      	bx	lr
20021176:	bf00      	nop
20021178:	500c0000 	.word	0x500c0000

2002117c <is_addr_in_nor>:
2002117c:	4b09      	ldr	r3, [pc, #36]	@ (200211a4 <is_addr_in_nor+0x28>)
2002117e:	4602      	mov	r2, r0
20021180:	681b      	ldr	r3, [r3, #0]
20021182:	b163      	cbz	r3, 2002119e <is_addr_in_nor+0x22>
20021184:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
20021188:	b948      	cbnz	r0, 2002119e <is_addr_in_nor+0x22>
2002118a:	6919      	ldr	r1, [r3, #16]
2002118c:	4291      	cmp	r1, r2
2002118e:	d807      	bhi.n	200211a0 <is_addr_in_nor+0x24>
20021190:	695b      	ldr	r3, [r3, #20]
20021192:	4419      	add	r1, r3
20021194:	4291      	cmp	r1, r2
20021196:	bf94      	ite	ls
20021198:	2000      	movls	r0, #0
2002119a:	2001      	movhi	r0, #1
2002119c:	4770      	bx	lr
2002119e:	2000      	movs	r0, #0
200211a0:	4770      	bx	lr
200211a2:	bf00      	nop
200211a4:	20046d38 	.word	0x20046d38

200211a8 <dfu_boot_img_in_flash>:
200211a8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200211ac:	4f5e      	ldr	r7, [pc, #376]	@ (20021328 <dfu_boot_img_in_flash+0x180>)
200211ae:	1e84      	subs	r4, r0, #2
200211b0:	eb07 1300 	add.w	r3, r7, r0, lsl #4
200211b4:	eb07 2040 	add.w	r0, r7, r0, lsl #9
200211b8:	f8d3 8004 	ldr.w	r8, [r3, #4]
200211bc:	68dd      	ldr	r5, [r3, #12]
200211be:	f8b0 3c06 	ldrh.w	r3, [r0, #3078]	@ 0xc06
200211c2:	b085      	sub	sp, #20
200211c4:	07db      	lsls	r3, r3, #31
200211c6:	f140 8095 	bpl.w	200212f4 <dfu_boot_img_in_flash+0x14c>
200211ca:	f44f 7193 	mov.w	r1, #294	@ 0x126
200211ce:	f507 7082 	add.w	r0, r7, #260	@ 0x104
200211d2:	f000 fe6a 	bl	20021eaa <sifli_sigkey_pub_verify>
200211d6:	b110      	cbz	r0, 200211de <dfu_boot_img_in_flash+0x36>
200211d8:	2001      	movs	r0, #1
200211da:	f000 feb3 	bl	20021f44 <sifli_secboot_exception>
200211de:	2c07      	cmp	r4, #7
200211e0:	f300 8093 	bgt.w	2002130a <dfu_boot_img_in_flash+0x162>
200211e4:	2003      	movs	r0, #3
200211e6:	f7ff fedb 	bl	20020fa0 <sifli_hw_efuse_read_bank>
200211ea:	4262      	negs	r2, r4
200211ec:	f002 0203 	and.w	r2, r2, #3
200211f0:	f004 0303 	and.w	r3, r4, #3
200211f4:	bf58      	it	pl
200211f6:	4253      	negpl	r3, r2
200211f8:	2b02      	cmp	r3, #2
200211fa:	f200 8086 	bhi.w	2002130a <dfu_boot_img_in_flash+0x162>
200211fe:	4628      	mov	r0, r5
20021200:	f7ff ffbc 	bl	2002117c <is_addr_in_nor>
20021204:	f241 0308 	movw	r3, #4104	@ 0x1008
20021208:	4682      	mov	sl, r0
2002120a:	ea4f 2944 	mov.w	r9, r4, lsl #9
2002120e:	f8df c12c 	ldr.w	ip, [pc, #300]	@ 2002133c <dfu_boot_img_in_flash+0x194>
20021212:	eb07 0609 	add.w	r6, r7, r9
20021216:	441e      	add	r6, r3
20021218:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002121a:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
2002121e:	e896 000f 	ldmia.w	r6, {r0, r1, r2, r3}
20021222:	e88c 000f 	stmia.w	ip, {r0, r1, r2, r3}
20021226:	f1ba 0f00 	cmp.w	sl, #0
2002122a:	d04b      	beq.n	200212c4 <dfu_boot_img_in_flash+0x11c>
2002122c:	f104 0608 	add.w	r6, r4, #8
20021230:	f1ac 0010 	sub.w	r0, ip, #16
20021234:	0276      	lsls	r6, r6, #9
20021236:	f7ff feef 	bl	20021018 <sifli_hw_init_xip_key>
2002123a:	59ba      	ldr	r2, [r7, r6]
2002123c:	f8df a0f0 	ldr.w	sl, [pc, #240]	@ 20021330 <dfu_boot_img_in_flash+0x188>
20021240:	442a      	add	r2, r5
20021242:	2000      	movs	r0, #0
20021244:	f8da b000 	ldr.w	fp, [sl]
20021248:	9203      	str	r2, [sp, #12]
2002124a:	f7ff ff25 	bl	20021098 <dfu_get_counter>
2002124e:	4629      	mov	r1, r5
20021250:	4603      	mov	r3, r0
20021252:	9a03      	ldr	r2, [sp, #12]
20021254:	4658      	mov	r0, fp
20021256:	f002 faca 	bl	200237ee <HAL_FLASH_NONCE_CFG>
2002125a:	4629      	mov	r1, r5
2002125c:	f8da 0000 	ldr.w	r0, [sl]
20021260:	59ba      	ldr	r2, [r7, r6]
20021262:	eba8 0305 	sub.w	r3, r8, r5
20021266:	f002 fab1 	bl	200237cc <HAL_FLASH_ALIAS_CFG>
2002126a:	2101      	movs	r1, #1
2002126c:	f8da 0000 	ldr.w	r0, [sl]
20021270:	f002 fad5 	bl	2002381e <HAL_FLASH_AES_CFG>
20021274:	f104 0308 	add.w	r3, r4, #8
20021278:	f509 5081 	add.w	r0, r9, #4128	@ 0x1020
2002127c:	025b      	lsls	r3, r3, #9
2002127e:	3008      	adds	r0, #8
20021280:	462a      	mov	r2, r5
20021282:	58fb      	ldr	r3, [r7, r3]
20021284:	4929      	ldr	r1, [pc, #164]	@ (2002132c <dfu_boot_img_in_flash+0x184>)
20021286:	4438      	add	r0, r7
20021288:	f000 fe27 	bl	20021eda <sifli_img_sig_hash_verify>
2002128c:	b110      	cbz	r0, 20021294 <dfu_boot_img_in_flash+0xec>
2002128e:	2002      	movs	r0, #2
20021290:	f000 fe58 	bl	20021f44 <sifli_secboot_exception>
20021294:	f8d5 d000 	ldr.w	sp, [r5]
20021298:	f8d5 f004 	ldr.w	pc, [r5, #4]
2002129c:	4628      	mov	r0, r5
2002129e:	f7ff ff6d 	bl	2002117c <is_addr_in_nor>
200212a2:	2800      	cmp	r0, #0
200212a4:	d034      	beq.n	20021310 <dfu_boot_img_in_flash+0x168>
200212a6:	4822      	ldr	r0, [pc, #136]	@ (20021330 <dfu_boot_img_in_flash+0x188>)
200212a8:	3408      	adds	r4, #8
200212aa:	0264      	lsls	r4, r4, #9
200212ac:	4629      	mov	r1, r5
200212ae:	593a      	ldr	r2, [r7, r4]
200212b0:	6800      	ldr	r0, [r0, #0]
200212b2:	eba8 0305 	sub.w	r3, r8, r5
200212b6:	f002 fa89 	bl	200237cc <HAL_FLASH_ALIAS_CFG>
200212ba:	f8d5 d000 	ldr.w	sp, [r5]
200212be:	f8d5 f004 	ldr.w	pc, [r5, #4]
200212c2:	e022      	b.n	2002130a <dfu_boot_img_in_flash+0x162>
200212c4:	f1ac 0010 	sub.w	r0, ip, #16
200212c8:	2220      	movs	r2, #32
200212ca:	491a      	ldr	r1, [pc, #104]	@ (20021334 <dfu_boot_img_in_flash+0x18c>)
200212cc:	f7ff fecc 	bl	20021068 <sifli_hw_dec_key>
200212d0:	f104 0608 	add.w	r6, r4, #8
200212d4:	4b18      	ldr	r3, [pc, #96]	@ (20021338 <dfu_boot_img_in_flash+0x190>)
200212d6:	0276      	lsls	r6, r6, #9
200212d8:	4629      	mov	r1, r5
200212da:	59ba      	ldr	r2, [r7, r6]
200212dc:	4640      	mov	r0, r8
200212de:	681b      	ldr	r3, [r3, #0]
200212e0:	4798      	blx	r3
200212e2:	f8cd a000 	str.w	sl, [sp]
200212e6:	462a      	mov	r2, r5
200212e8:	4629      	mov	r1, r5
200212ea:	59bb      	ldr	r3, [r7, r6]
200212ec:	4811      	ldr	r0, [pc, #68]	@ (20021334 <dfu_boot_img_in_flash+0x18c>)
200212ee:	f7ff feeb 	bl	200210c8 <sifli_hw_dec>
200212f2:	e7bf      	b.n	20021274 <dfu_boot_img_in_flash+0xcc>
200212f4:	2c07      	cmp	r4, #7
200212f6:	dc08      	bgt.n	2002130a <dfu_boot_img_in_flash+0x162>
200212f8:	4262      	negs	r2, r4
200212fa:	f002 0203 	and.w	r2, r2, #3
200212fe:	f004 0303 	and.w	r3, r4, #3
20021302:	bf58      	it	pl
20021304:	4253      	negpl	r3, r2
20021306:	2b02      	cmp	r3, #2
20021308:	d9c8      	bls.n	2002129c <dfu_boot_img_in_flash+0xf4>
2002130a:	b005      	add	sp, #20
2002130c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20021310:	45a8      	cmp	r8, r5
20021312:	d0d2      	beq.n	200212ba <dfu_boot_img_in_flash+0x112>
20021314:	4b08      	ldr	r3, [pc, #32]	@ (20021338 <dfu_boot_img_in_flash+0x190>)
20021316:	3408      	adds	r4, #8
20021318:	0264      	lsls	r4, r4, #9
2002131a:	4629      	mov	r1, r5
2002131c:	4640      	mov	r0, r8
2002131e:	681b      	ldr	r3, [r3, #0]
20021320:	593a      	ldr	r2, [r7, r4]
20021322:	4798      	blx	r3
20021324:	e7c9      	b.n	200212ba <dfu_boot_img_in_flash+0x112>
20021326:	bf00      	nop
20021328:	20047394 	.word	0x20047394
2002132c:	20047498 	.word	0x20047498
20021330:	20046d38 	.word	0x20046d38
20021334:	20047354 	.word	0x20047354
20021338:	20046d44 	.word	0x20046d44
2002133c:	20047374 	.word	0x20047374

20021340 <boot_images_help>:
20021340:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20021344:	4e52      	ldr	r6, [pc, #328]	@ (20021490 <boot_images_help+0x150>)
20021346:	f8df a158 	ldr.w	sl, [pc, #344]	@ 200214a0 <boot_images_help+0x160>
2002134a:	6833      	ldr	r3, [r6, #0]
2002134c:	b085      	sub	sp, #20
2002134e:	4553      	cmp	r3, sl
20021350:	d150      	bne.n	200213f4 <boot_images_help+0xb4>
20021352:	2208      	movs	r2, #8
20021354:	2300      	movs	r3, #0
20021356:	f8df b14c 	ldr.w	fp, [pc, #332]	@ 200214a4 <boot_images_help+0x164>
2002135a:	eb0d 0102 	add.w	r1, sp, r2
2002135e:	e9cd 3302 	strd	r3, r3, [sp, #8]
20021362:	484c      	ldr	r0, [pc, #304]	@ (20021494 <boot_images_help+0x154>)
20021364:	f8db 3000 	ldr.w	r3, [fp]
20021368:	4798      	blx	r3
2002136a:	2008      	movs	r0, #8
2002136c:	f00b f892 	bl	2002c494 <HAL_Get_backup>
20021370:	4605      	mov	r5, r0
20021372:	2005      	movs	r0, #5
20021374:	f00b f88e 	bl	2002c494 <HAL_Get_backup>
20021378:	f8df 912c 	ldr.w	r9, [pc, #300]	@ 200214a8 <boot_images_help+0x168>
2002137c:	4946      	ldr	r1, [pc, #280]	@ (20021498 <boot_images_help+0x158>)
2002137e:	f8d9 4000 	ldr.w	r4, [r9]
20021382:	f8df 8128 	ldr.w	r8, [pc, #296]	@ 200214ac <boot_images_help+0x16c>
20021386:	f642 4210 	movw	r2, #11280	@ 0x2c10
2002138a:	f8db 3000 	ldr.w	r3, [fp]
2002138e:	4607      	mov	r7, r0
20021390:	f8c8 1000 	str.w	r1, [r8]
20021394:	4620      	mov	r0, r4
20021396:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
2002139a:	4798      	blx	r3
2002139c:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
200213a0:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
200213a4:	4593      	cmp	fp, r2
200213a6:	d14e      	bne.n	20021446 <boot_images_help+0x106>
200213a8:	b2eb      	uxtb	r3, r5
200213aa:	2b04      	cmp	r3, #4
200213ac:	d025      	beq.n	200213fa <boot_images_help+0xba>
200213ae:	2b06      	cmp	r3, #6
200213b0:	d039      	beq.n	20021426 <boot_images_help+0xe6>
200213b2:	2b01      	cmp	r3, #1
200213b4:	d142      	bne.n	2002143c <boot_images_help+0xfc>
200213b6:	2005      	movs	r0, #5
200213b8:	f00b f86c 	bl	2002c494 <HAL_Get_backup>
200213bc:	2802      	cmp	r0, #2
200213be:	d006      	beq.n	200213ce <boot_images_help+0x8e>
200213c0:	9b02      	ldr	r3, [sp, #8]
200213c2:	4553      	cmp	r3, sl
200213c4:	d106      	bne.n	200213d4 <boot_images_help+0x94>
200213c6:	f89d 300d 	ldrb.w	r3, [sp, #13]
200213ca:	2b7f      	cmp	r3, #127	@ 0x7f
200213cc:	d102      	bne.n	200213d4 <boot_images_help+0x94>
200213ce:	4b33      	ldr	r3, [pc, #204]	@ (2002149c <boot_images_help+0x15c>)
200213d0:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
200213d4:	f8d6 3c08 	ldr.w	r3, [r6, #3080]	@ 0xc08
200213d8:	1c5a      	adds	r2, r3, #1
200213da:	d00b      	beq.n	200213f4 <boot_images_help+0xb4>
200213dc:	f8d9 4000 	ldr.w	r4, [r9]
200213e0:	1b1c      	subs	r4, r3, r4
200213e2:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
200213e6:	0a64      	lsrs	r4, r4, #9
200213e8:	3402      	adds	r4, #2
200213ea:	f7ff fa37 	bl	2002085c <board_init_psram>
200213ee:	4620      	mov	r0, r4
200213f0:	f7ff feda 	bl	200211a8 <dfu_boot_img_in_flash>
200213f4:	b005      	add	sp, #20
200213f6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200213fa:	2008      	movs	r0, #8
200213fc:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20021400:	2106      	movs	r1, #6
20021402:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20021406:	f00b f83f 	bl	2002c488 <HAL_Set_backup>
2002140a:	f8d8 0000 	ldr.w	r0, [r8]
2002140e:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20021412:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20021416:	b11f      	cbz	r7, 20021420 <boot_images_help+0xe0>
20021418:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
2002141c:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20021420:	f7ff fe86 	bl	20021130 <update_sec_flash>
20021424:	e7c7      	b.n	200213b6 <boot_images_help+0x76>
20021426:	2101      	movs	r1, #1
20021428:	2008      	movs	r0, #8
2002142a:	f00b f82d 	bl	2002c488 <HAL_Set_backup>
2002142e:	f8d8 0000 	ldr.w	r0, [r8]
20021432:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20021436:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
2002143a:	e7f1      	b.n	20021420 <boot_images_help+0xe0>
2002143c:	2101      	movs	r1, #1
2002143e:	2008      	movs	r0, #8
20021440:	f00b f822 	bl	2002c488 <HAL_Set_backup>
20021444:	e7b7      	b.n	200213b6 <boot_images_help+0x76>
20021446:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
2002144a:	45a3      	cmp	fp, r4
2002144c:	d1b3      	bne.n	200213b6 <boot_images_help+0x76>
2002144e:	b2eb      	uxtb	r3, r5
20021450:	2b03      	cmp	r3, #3
20021452:	d005      	beq.n	20021460 <boot_images_help+0x120>
20021454:	2b05      	cmp	r3, #5
20021456:	d018      	beq.n	2002148a <boot_images_help+0x14a>
20021458:	2b02      	cmp	r3, #2
2002145a:	d0ac      	beq.n	200213b6 <boot_images_help+0x76>
2002145c:	2102      	movs	r1, #2
2002145e:	e7ee      	b.n	2002143e <boot_images_help+0xfe>
20021460:	2008      	movs	r0, #8
20021462:	2105      	movs	r1, #5
20021464:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20021468:	9201      	str	r2, [sp, #4]
2002146a:	f00b f80d 	bl	2002c488 <HAL_Set_backup>
2002146e:	f8d8 0000 	ldr.w	r0, [r8]
20021472:	9a01      	ldr	r2, [sp, #4]
20021474:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20021478:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
2002147c:	2f00      	cmp	r7, #0
2002147e:	d0cf      	beq.n	20021420 <boot_images_help+0xe0>
20021480:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20021484:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20021488:	e7ca      	b.n	20021420 <boot_images_help+0xe0>
2002148a:	2102      	movs	r1, #2
2002148c:	e7cc      	b.n	20021428 <boot_images_help+0xe8>
2002148e:	bf00      	nop
20021490:	20047394 	.word	0x20047394
20021494:	12780000 	.word	0x12780000
20021498:	20049fac 	.word	0x20049fac
2002149c:	12001000 	.word	0x12001000
200214a0:	53454346 	.word	0x53454346
200214a4:	20046d44 	.word	0x20046d44
200214a8:	20046d34 	.word	0x20046d34
200214ac:	20049fa8 	.word	0x20049fa8

200214b0 <hw_preinit0>:
200214b0:	b508      	push	{r3, lr}
200214b2:	4b0e      	ldr	r3, [pc, #56]	@ (200214ec <hw_preinit0+0x3c>)
200214b4:	685b      	ldr	r3, [r3, #4]
200214b6:	b2db      	uxtb	r3, r3
200214b8:	2b06      	cmp	r3, #6
200214ba:	d80a      	bhi.n	200214d2 <hw_preinit0+0x22>
200214bc:	4a0c      	ldr	r2, [pc, #48]	@ (200214f0 <hw_preinit0+0x40>)
200214be:	6a93      	ldr	r3, [r2, #40]	@ 0x28
200214c0:	f023 037f 	bic.w	r3, r3, #127	@ 0x7f
200214c4:	f043 0306 	orr.w	r3, r3, #6
200214c8:	6293      	str	r3, [r2, #40]	@ 0x28
200214ca:	6853      	ldr	r3, [r2, #4]
200214cc:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
200214d0:	6053      	str	r3, [r2, #4]
200214d2:	2000      	movs	r0, #0
200214d4:	f000 fe41 	bl	2002215a <HAL_Delay_us>
200214d8:	4b06      	ldr	r3, [pc, #24]	@ (200214f4 <hw_preinit0+0x44>)
200214da:	4a07      	ldr	r2, [pc, #28]	@ (200214f8 <hw_preinit0+0x48>)
200214dc:	2000      	movs	r0, #0
200214de:	605a      	str	r2, [r3, #4]
200214e0:	f7ff fd5e 	bl	20020fa0 <sifli_hw_efuse_read_bank>
200214e4:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200214e8:	f7ff be3a 	b.w	20021160 <boot_ram>
200214ec:	5000b000 	.word	0x5000b000
200214f0:	500ca000 	.word	0x500ca000
200214f4:	5000c000 	.word	0x5000c000
200214f8:	0002d08f 	.word	0x0002d08f

200214fc <entry>:
200214fc:	4c14      	ldr	r4, [pc, #80]	@ (20021550 <entry+0x54>)
200214fe:	b508      	push	{r3, lr}
20021500:	2000      	movs	r0, #0
20021502:	f000 fe2a 	bl	2002215a <HAL_Delay_us>
20021506:	6863      	ldr	r3, [r4, #4]
20021508:	4d12      	ldr	r5, [pc, #72]	@ (20021554 <entry+0x58>)
2002150a:	b2db      	uxtb	r3, r3
2002150c:	2b06      	cmp	r3, #6
2002150e:	d90f      	bls.n	20021530 <entry+0x34>
20021510:	f7fe ffc4 	bl	2002049c <board_flash_power_on>
20021514:	f7fe feac 	bl	20020270 <HAL_MspInit>
20021518:	f7fe ff9c 	bl	20020454 <board_boot_from>
2002151c:	6028      	str	r0, [r5, #0]
2002151e:	68e3      	ldr	r3, [r4, #12]
20021520:	f023 0301 	bic.w	r3, r3, #1
20021524:	60e3      	str	r3, [r4, #12]
20021526:	f7ff fba5 	bl	20020c74 <dfu_flash_init>
2002152a:	f7ff ff09 	bl	20021340 <boot_images_help>
2002152e:	e7fe      	b.n	2002152e <entry+0x32>
20021530:	f7fe ff90 	bl	20020454 <board_boot_from>
20021534:	6028      	str	r0, [r5, #0]
20021536:	f7fe ffb1 	bl	2002049c <board_flash_power_on>
2002153a:	f7fe fe99 	bl	20020270 <HAL_MspInit>
2002153e:	68e3      	ldr	r3, [r4, #12]
20021540:	f023 0301 	bic.w	r3, r3, #1
20021544:	60e3      	str	r3, [r4, #12]
20021546:	f7ff fb95 	bl	20020c74 <dfu_flash_init>
2002154a:	f7ff fef9 	bl	20021340 <boot_images_help>
2002154e:	e7ee      	b.n	2002152e <entry+0x32>
20021550:	5000b000 	.word	0x5000b000
20021554:	20049fa4 	.word	0x20049fa4

20021558 <sdio_emmc_init>:
20021558:	b570      	push	{r4, r5, r6, lr}
2002155a:	b08c      	sub	sp, #48	@ 0x30
2002155c:	f000 f968 	bl	20021830 <sd1_init>
20021560:	4c8d      	ldr	r4, [pc, #564]	@ (20021798 <sdio_emmc_init+0x240>)
20021562:	4b8e      	ldr	r3, [pc, #568]	@ (2002179c <sdio_emmc_init+0x244>)
20021564:	2500      	movs	r5, #0
20021566:	6323      	str	r3, [r4, #48]	@ 0x30
20021568:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002156a:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
2002156e:	f043 0302 	orr.w	r3, r3, #2
20021572:	6323      	str	r3, [r4, #48]	@ 0x30
20021574:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
20021578:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002157a:	6223      	str	r3, [r4, #32]
2002157c:	f000 fded 	bl	2002215a <HAL_Delay_us>
20021580:	4629      	mov	r1, r5
20021582:	4628      	mov	r0, r5
20021584:	f000 f986 	bl	20021894 <sd1_send_cmd>
20021588:	2301      	movs	r3, #1
2002158a:	65e3      	str	r3, [r4, #92]	@ 0x5c
2002158c:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
2002158e:	079d      	lsls	r5, r3, #30
20021590:	d5fc      	bpl.n	2002158c <sdio_emmc_init+0x34>
20021592:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021594:	f043 0320 	orr.w	r3, r3, #32
20021598:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002159a:	4981      	ldr	r1, [pc, #516]	@ (200217a0 <sdio_emmc_init+0x248>)
2002159c:	2001      	movs	r0, #1
2002159e:	ad07      	add	r5, sp, #28
200215a0:	f000 f978 	bl	20021894 <sd1_send_cmd>
200215a4:	ab06      	add	r3, sp, #24
200215a6:	aa05      	add	r2, sp, #20
200215a8:	a904      	add	r1, sp, #16
200215aa:	f10d 000f 	add.w	r0, sp, #15
200215ae:	9500      	str	r5, [sp, #0]
200215b0:	f000 f9ae 	bl	20021910 <sd1_get_rsp>
200215b4:	2014      	movs	r0, #20
200215b6:	f000 fdd0 	bl	2002215a <HAL_Delay_us>
200215ba:	9b04      	ldr	r3, [sp, #16]
200215bc:	2b00      	cmp	r3, #0
200215be:	daec      	bge.n	2002159a <sdio_emmc_init+0x42>
200215c0:	2014      	movs	r0, #20
200215c2:	f000 fdca 	bl	2002215a <HAL_Delay_us>
200215c6:	2100      	movs	r1, #0
200215c8:	2002      	movs	r0, #2
200215ca:	f000 f963 	bl	20021894 <sd1_send_cmd>
200215ce:	2801      	cmp	r0, #1
200215d0:	f000 8081 	beq.w	200216d6 <sdio_emmc_init+0x17e>
200215d4:	2802      	cmp	r0, #2
200215d6:	d07e      	beq.n	200216d6 <sdio_emmc_init+0x17e>
200215d8:	ab08      	add	r3, sp, #32
200215da:	aa0a      	add	r2, sp, #40	@ 0x28
200215dc:	a90b      	add	r1, sp, #44	@ 0x2c
200215de:	9300      	str	r3, [sp, #0]
200215e0:	f10d 000f 	add.w	r0, sp, #15
200215e4:	ab09      	add	r3, sp, #36	@ 0x24
200215e6:	f000 f993 	bl	20021910 <sd1_get_rsp>
200215ea:	2014      	movs	r0, #20
200215ec:	f000 fdb5 	bl	2002215a <HAL_Delay_us>
200215f0:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200215f4:	2003      	movs	r0, #3
200215f6:	f000 f94d 	bl	20021894 <sd1_send_cmd>
200215fa:	2801      	cmp	r0, #1
200215fc:	f000 80ab 	beq.w	20021756 <sdio_emmc_init+0x1fe>
20021600:	2802      	cmp	r0, #2
20021602:	f000 80aa 	beq.w	2002175a <sdio_emmc_init+0x202>
20021606:	ab06      	add	r3, sp, #24
20021608:	9500      	str	r5, [sp, #0]
2002160a:	aa05      	add	r2, sp, #20
2002160c:	a904      	add	r1, sp, #16
2002160e:	f10d 000f 	add.w	r0, sp, #15
20021612:	f000 f97d 	bl	20021910 <sd1_get_rsp>
20021616:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002161a:	2b03      	cmp	r3, #3
2002161c:	f040 809f 	bne.w	2002175e <sdio_emmc_init+0x206>
20021620:	4c5d      	ldr	r4, [pc, #372]	@ (20021798 <sdio_emmc_init+0x240>)
20021622:	2014      	movs	r0, #20
20021624:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021626:	f023 0320 	bic.w	r3, r3, #32
2002162a:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002162c:	f000 fd95 	bl	2002215a <HAL_Delay_us>
20021630:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021634:	2009      	movs	r0, #9
20021636:	f000 f92d 	bl	20021894 <sd1_send_cmd>
2002163a:	2801      	cmp	r0, #1
2002163c:	f000 8091 	beq.w	20021762 <sdio_emmc_init+0x20a>
20021640:	2802      	cmp	r0, #2
20021642:	f000 8090 	beq.w	20021766 <sdio_emmc_init+0x20e>
20021646:	aa05      	add	r2, sp, #20
20021648:	a904      	add	r1, sp, #16
2002164a:	ab06      	add	r3, sp, #24
2002164c:	f10d 000f 	add.w	r0, sp, #15
20021650:	9500      	str	r5, [sp, #0]
20021652:	f000 f95d 	bl	20021910 <sd1_get_rsp>
20021656:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
2002165a:	6323      	str	r3, [r4, #48]	@ 0x30
2002165c:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002165e:	2014      	movs	r0, #20
20021660:	f043 0302 	orr.w	r3, r3, #2
20021664:	6323      	str	r3, [r4, #48]	@ 0x30
20021666:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
2002166a:	6223      	str	r3, [r4, #32]
2002166c:	2302      	movs	r3, #2
2002166e:	63e3      	str	r3, [r4, #60]	@ 0x3c
20021670:	f000 fd73 	bl	2002215a <HAL_Delay_us>
20021674:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021678:	2007      	movs	r0, #7
2002167a:	f000 f90b 	bl	20021894 <sd1_send_cmd>
2002167e:	2801      	cmp	r0, #1
20021680:	d073      	beq.n	2002176a <sdio_emmc_init+0x212>
20021682:	2802      	cmp	r0, #2
20021684:	d073      	beq.n	2002176e <sdio_emmc_init+0x216>
20021686:	ab06      	add	r3, sp, #24
20021688:	9500      	str	r5, [sp, #0]
2002168a:	aa05      	add	r2, sp, #20
2002168c:	a904      	add	r1, sp, #16
2002168e:	f10d 000f 	add.w	r0, sp, #15
20021692:	f000 f93d 	bl	20021910 <sd1_get_rsp>
20021696:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002169a:	2b07      	cmp	r3, #7
2002169c:	d169      	bne.n	20021772 <sdio_emmc_init+0x21a>
2002169e:	f04f 33ff 	mov.w	r3, #4294967295
200216a2:	2101      	movs	r1, #1
200216a4:	2000      	movs	r0, #0
200216a6:	6023      	str	r3, [r4, #0]
200216a8:	f000 f942 	bl	20021930 <sd1_read>
200216ac:	2100      	movs	r1, #0
200216ae:	2008      	movs	r0, #8
200216b0:	f000 f8f0 	bl	20021894 <sd1_send_cmd>
200216b4:	2801      	cmp	r0, #1
200216b6:	d05e      	beq.n	20021776 <sdio_emmc_init+0x21e>
200216b8:	2802      	cmp	r0, #2
200216ba:	d05e      	beq.n	2002177a <sdio_emmc_init+0x222>
200216bc:	ab06      	add	r3, sp, #24
200216be:	9500      	str	r5, [sp, #0]
200216c0:	aa05      	add	r2, sp, #20
200216c2:	a904      	add	r1, sp, #16
200216c4:	f10d 000f 	add.w	r0, sp, #15
200216c8:	f000 f922 	bl	20021910 <sd1_get_rsp>
200216cc:	f89d 300f 	ldrb.w	r3, [sp, #15]
200216d0:	2b08      	cmp	r3, #8
200216d2:	d002      	beq.n	200216da <sdio_emmc_init+0x182>
200216d4:	200d      	movs	r0, #13
200216d6:	b00c      	add	sp, #48	@ 0x30
200216d8:	bd70      	pop	{r4, r5, r6, pc}
200216da:	2320      	movs	r3, #32
200216dc:	62e3      	str	r3, [r4, #44]	@ 0x2c
200216de:	f000 f937 	bl	20021950 <sd1_wait_read>
200216e2:	6823      	ldr	r3, [r4, #0]
200216e4:	0618      	lsls	r0, r3, #24
200216e6:	d4f5      	bmi.n	200216d4 <sdio_emmc_init+0x17c>
200216e8:	6823      	ldr	r3, [r4, #0]
200216ea:	0659      	lsls	r1, r3, #25
200216ec:	d447      	bmi.n	2002177e <sdio_emmc_init+0x226>
200216ee:	2680      	movs	r6, #128	@ 0x80
200216f0:	3e01      	subs	r6, #1
200216f2:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
200216f6:	d1fb      	bne.n	200216f0 <sdio_emmc_init+0x198>
200216f8:	2101      	movs	r1, #1
200216fa:	4630      	mov	r0, r6
200216fc:	f000 f918 	bl	20021930 <sd1_read>
20021700:	2014      	movs	r0, #20
20021702:	f000 fd2a 	bl	2002215a <HAL_Delay_us>
20021706:	f04f 33ff 	mov.w	r3, #4294967295
2002170a:	4631      	mov	r1, r6
2002170c:	2011      	movs	r0, #17
2002170e:	6023      	str	r3, [r4, #0]
20021710:	f000 f8c0 	bl	20021894 <sd1_send_cmd>
20021714:	2801      	cmp	r0, #1
20021716:	d034      	beq.n	20021782 <sdio_emmc_init+0x22a>
20021718:	2802      	cmp	r0, #2
2002171a:	d034      	beq.n	20021786 <sdio_emmc_init+0x22e>
2002171c:	ab06      	add	r3, sp, #24
2002171e:	9500      	str	r5, [sp, #0]
20021720:	aa05      	add	r2, sp, #20
20021722:	a904      	add	r1, sp, #16
20021724:	f10d 000f 	add.w	r0, sp, #15
20021728:	f000 f8f2 	bl	20021910 <sd1_get_rsp>
2002172c:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021730:	2b11      	cmp	r3, #17
20021732:	d12a      	bne.n	2002178a <sdio_emmc_init+0x232>
20021734:	2320      	movs	r3, #32
20021736:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021738:	f000 f90a 	bl	20021950 <sd1_wait_read>
2002173c:	6823      	ldr	r3, [r4, #0]
2002173e:	061a      	lsls	r2, r3, #24
20021740:	d425      	bmi.n	2002178e <sdio_emmc_init+0x236>
20021742:	6823      	ldr	r3, [r4, #0]
20021744:	065b      	lsls	r3, r3, #25
20021746:	d424      	bmi.n	20021792 <sdio_emmc_init+0x23a>
20021748:	2080      	movs	r0, #128	@ 0x80
2002174a:	4b13      	ldr	r3, [pc, #76]	@ (20021798 <sdio_emmc_init+0x240>)
2002174c:	3801      	subs	r0, #1
2002174e:	f8d3 2200 	ldr.w	r2, [r3, #512]	@ 0x200
20021752:	d1fb      	bne.n	2002174c <sdio_emmc_init+0x1f4>
20021754:	e7bf      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021756:	2003      	movs	r0, #3
20021758:	e7bd      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002175a:	2004      	movs	r0, #4
2002175c:	e7bb      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002175e:	2005      	movs	r0, #5
20021760:	e7b9      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021762:	2006      	movs	r0, #6
20021764:	e7b7      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021766:	2007      	movs	r0, #7
20021768:	e7b5      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002176a:	2008      	movs	r0, #8
2002176c:	e7b3      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002176e:	2009      	movs	r0, #9
20021770:	e7b1      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021772:	200a      	movs	r0, #10
20021774:	e7af      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021776:	200b      	movs	r0, #11
20021778:	e7ad      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002177a:	200c      	movs	r0, #12
2002177c:	e7ab      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002177e:	200e      	movs	r0, #14
20021780:	e7a9      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021782:	2011      	movs	r0, #17
20021784:	e7a7      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021786:	2012      	movs	r0, #18
20021788:	e7a5      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002178a:	2013      	movs	r0, #19
2002178c:	e7a3      	b.n	200216d6 <sdio_emmc_init+0x17e>
2002178e:	2014      	movs	r0, #20
20021790:	e7a1      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021792:	2015      	movs	r0, #21
20021794:	e79f      	b.n	200216d6 <sdio_emmc_init+0x17e>
20021796:	bf00      	nop
20021798:	50045000 	.word	0x50045000
2002179c:	00016700 	.word	0x00016700
200217a0:	40000080 	.word	0x40000080

200217a4 <emmc_read_data>:
200217a4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200217a8:	4607      	mov	r7, r0
200217aa:	f04f 38ff 	mov.w	r8, #4294967295
200217ae:	b088      	sub	sp, #32
200217b0:	2000      	movs	r0, #0
200217b2:	460d      	mov	r5, r1
200217b4:	4e1d      	ldr	r6, [pc, #116]	@ (2002182c <emmc_read_data+0x88>)
200217b6:	2101      	movs	r1, #1
200217b8:	4614      	mov	r4, r2
200217ba:	f000 f8b9 	bl	20021930 <sd1_read>
200217be:	2014      	movs	r0, #20
200217c0:	f000 fccb 	bl	2002215a <HAL_Delay_us>
200217c4:	2011      	movs	r0, #17
200217c6:	f8c6 8000 	str.w	r8, [r6]
200217ca:	0a79      	lsrs	r1, r7, #9
200217cc:	f000 f862 	bl	20021894 <sd1_send_cmd>
200217d0:	4440      	add	r0, r8
200217d2:	b2c0      	uxtb	r0, r0
200217d4:	2801      	cmp	r0, #1
200217d6:	d803      	bhi.n	200217e0 <emmc_read_data+0x3c>
200217d8:	2000      	movs	r0, #0
200217da:	b008      	add	sp, #32
200217dc:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200217e0:	ab07      	add	r3, sp, #28
200217e2:	9300      	str	r3, [sp, #0]
200217e4:	aa05      	add	r2, sp, #20
200217e6:	ab06      	add	r3, sp, #24
200217e8:	a904      	add	r1, sp, #16
200217ea:	f10d 000f 	add.w	r0, sp, #15
200217ee:	f000 f88f 	bl	20021910 <sd1_get_rsp>
200217f2:	f89d 300f 	ldrb.w	r3, [sp, #15]
200217f6:	2b11      	cmp	r3, #17
200217f8:	d1ee      	bne.n	200217d8 <emmc_read_data+0x34>
200217fa:	2320      	movs	r3, #32
200217fc:	f8c6 8000 	str.w	r8, [r6]
20021800:	62f3      	str	r3, [r6, #44]	@ 0x2c
20021802:	f000 f8a5 	bl	20021950 <sd1_wait_read>
20021806:	6833      	ldr	r3, [r6, #0]
20021808:	061a      	lsls	r2, r3, #24
2002180a:	d4e5      	bmi.n	200217d8 <emmc_read_data+0x34>
2002180c:	6833      	ldr	r3, [r6, #0]
2002180e:	065b      	lsls	r3, r3, #25
20021810:	d4e2      	bmi.n	200217d8 <emmc_read_data+0x34>
20021812:	f024 0303 	bic.w	r3, r4, #3
20021816:	442b      	add	r3, r5
20021818:	429d      	cmp	r5, r3
2002181a:	d101      	bne.n	20021820 <emmc_read_data+0x7c>
2002181c:	4620      	mov	r0, r4
2002181e:	e7dc      	b.n	200217da <emmc_read_data+0x36>
20021820:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
20021824:	f845 2b04 	str.w	r2, [r5], #4
20021828:	e7f6      	b.n	20021818 <emmc_read_data+0x74>
2002182a:	bf00      	nop
2002182c:	50045000 	.word	0x50045000

20021830 <sd1_init>:
20021830:	b510      	push	{r4, lr}
20021832:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20021836:	68e3      	ldr	r3, [r4, #12]
20021838:	2064      	movs	r0, #100	@ 0x64
2002183a:	f023 0310 	bic.w	r3, r3, #16
2002183e:	60e3      	str	r3, [r4, #12]
20021840:	f000 fc8b 	bl	2002215a <HAL_Delay_us>
20021844:	68e3      	ldr	r3, [r4, #12]
20021846:	4a07      	ldr	r2, [pc, #28]	@ (20021864 <sd1_init+0x34>)
20021848:	f043 0310 	orr.w	r3, r3, #16
2002184c:	60e3      	str	r3, [r4, #12]
2002184e:	6913      	ldr	r3, [r2, #16]
20021850:	f043 0302 	orr.w	r3, r3, #2
20021854:	6113      	str	r3, [r2, #16]
20021856:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002185a:	4b03      	ldr	r3, [pc, #12]	@ (20021868 <sd1_init+0x38>)
2002185c:	631a      	str	r2, [r3, #48]	@ 0x30
2002185e:	2200      	movs	r2, #0
20021860:	63da      	str	r2, [r3, #60]	@ 0x3c
20021862:	bd10      	pop	{r4, pc}
20021864:	5000b000 	.word	0x5000b000
20021868:	50045000 	.word	0x50045000

2002186c <sd1_wait_cmd>:
2002186c:	4b08      	ldr	r3, [pc, #32]	@ (20021890 <sd1_wait_cmd+0x24>)
2002186e:	681a      	ldr	r2, [r3, #0]
20021870:	f012 0f0a 	tst.w	r2, #10
20021874:	d0fb      	beq.n	2002186e <sd1_wait_cmd+0x2>
20021876:	2202      	movs	r2, #2
20021878:	601a      	str	r2, [r3, #0]
2002187a:	681a      	ldr	r2, [r3, #0]
2002187c:	0712      	lsls	r2, r2, #28
2002187e:	bf5f      	itttt	pl
20021880:	6818      	ldrpl	r0, [r3, #0]
20021882:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20021886:	0040      	lslpl	r0, r0, #1
20021888:	b2c0      	uxtbpl	r0, r0
2002188a:	bf48      	it	mi
2002188c:	2001      	movmi	r0, #1
2002188e:	4770      	bx	lr
20021890:	50045000 	.word	0x50045000

20021894 <sd1_send_cmd>:
20021894:	4b0e      	ldr	r3, [pc, #56]	@ (200218d0 <sd1_send_cmd+0x3c>)
20021896:	280f      	cmp	r0, #15
20021898:	6099      	str	r1, [r3, #8]
2002189a:	ea4f 4380 	mov.w	r3, r0, lsl #18
2002189e:	d813      	bhi.n	200218c8 <sd1_send_cmd+0x34>
200218a0:	2201      	movs	r2, #1
200218a2:	f248 0111 	movw	r1, #32785	@ 0x8011
200218a6:	4082      	lsls	r2, r0
200218a8:	420a      	tst	r2, r1
200218aa:	d105      	bne.n	200218b8 <sd1_send_cmd+0x24>
200218ac:	f240 6104 	movw	r1, #1540	@ 0x604
200218b0:	420a      	tst	r2, r1
200218b2:	d009      	beq.n	200218c8 <sd1_send_cmd+0x34>
200218b4:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
200218b8:	4a05      	ldr	r2, [pc, #20]	@ (200218d0 <sd1_send_cmd+0x3c>)
200218ba:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
200218be:	f043 0301 	orr.w	r3, r3, #1
200218c2:	6053      	str	r3, [r2, #4]
200218c4:	f7ff bfd2 	b.w	2002186c <sd1_wait_cmd>
200218c8:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
200218cc:	e7f4      	b.n	200218b8 <sd1_send_cmd+0x24>
200218ce:	bf00      	nop
200218d0:	50045000 	.word	0x50045000

200218d4 <sd1_send_acmd>:
200218d4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200218d6:	4605      	mov	r5, r0
200218d8:	460f      	mov	r7, r1
200218da:	2037      	movs	r0, #55	@ 0x37
200218dc:	0411      	lsls	r1, r2, #16
200218de:	f7ff ffd9 	bl	20021894 <sd1_send_cmd>
200218e2:	4604      	mov	r4, r0
200218e4:	b968      	cbnz	r0, 20021902 <sd1_send_acmd+0x2e>
200218e6:	4b08      	ldr	r3, [pc, #32]	@ (20021908 <sd1_send_acmd+0x34>)
200218e8:	4e08      	ldr	r6, [pc, #32]	@ (2002190c <sd1_send_acmd+0x38>)
200218ea:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
200218ee:	60b7      	str	r7, [r6, #8]
200218f0:	6073      	str	r3, [r6, #4]
200218f2:	f7ff ffbb 	bl	2002186c <sd1_wait_cmd>
200218f6:	2802      	cmp	r0, #2
200218f8:	d104      	bne.n	20021904 <sd1_send_acmd+0x30>
200218fa:	2d29      	cmp	r5, #41	@ 0x29
200218fc:	d102      	bne.n	20021904 <sd1_send_acmd+0x30>
200218fe:	2304      	movs	r3, #4
20021900:	6033      	str	r3, [r6, #0]
20021902:	4620      	mov	r0, r4
20021904:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021906:	bf00      	nop
20021908:	00010101 	.word	0x00010101
2002190c:	50045000 	.word	0x50045000

20021910 <sd1_get_rsp>:
20021910:	b530      	push	{r4, r5, lr}
20021912:	4c06      	ldr	r4, [pc, #24]	@ (2002192c <sd1_get_rsp+0x1c>)
20021914:	68e5      	ldr	r5, [r4, #12]
20021916:	7005      	strb	r5, [r0, #0]
20021918:	6920      	ldr	r0, [r4, #16]
2002191a:	6008      	str	r0, [r1, #0]
2002191c:	6961      	ldr	r1, [r4, #20]
2002191e:	6011      	str	r1, [r2, #0]
20021920:	69a2      	ldr	r2, [r4, #24]
20021922:	601a      	str	r2, [r3, #0]
20021924:	69e2      	ldr	r2, [r4, #28]
20021926:	9b03      	ldr	r3, [sp, #12]
20021928:	601a      	str	r2, [r3, #0]
2002192a:	bd30      	pop	{r4, r5, pc}
2002192c:	50045000 	.word	0x50045000

20021930 <sd1_read>:
20021930:	f04f 33ff 	mov.w	r3, #4294967295
20021934:	4a04      	ldr	r2, [pc, #16]	@ (20021948 <sd1_read+0x18>)
20021936:	eb03 2341 	add.w	r3, r3, r1, lsl #9
2002193a:	6293      	str	r3, [r2, #40]	@ 0x28
2002193c:	4b03      	ldr	r3, [pc, #12]	@ (2002194c <sd1_read+0x1c>)
2002193e:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20021942:	6253      	str	r3, [r2, #36]	@ 0x24
20021944:	4770      	bx	lr
20021946:	bf00      	nop
20021948:	50045000 	.word	0x50045000
2002194c:	01ff0301 	.word	0x01ff0301

20021950 <sd1_wait_read>:
20021950:	4b08      	ldr	r3, [pc, #32]	@ (20021974 <sd1_wait_read+0x24>)
20021952:	681a      	ldr	r2, [r3, #0]
20021954:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20021958:	d0fb      	beq.n	20021952 <sd1_wait_read+0x2>
2002195a:	2220      	movs	r2, #32
2002195c:	601a      	str	r2, [r3, #0]
2002195e:	681a      	ldr	r2, [r3, #0]
20021960:	0612      	lsls	r2, r2, #24
20021962:	bf5f      	itttt	pl
20021964:	6818      	ldrpl	r0, [r3, #0]
20021966:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
2002196a:	0040      	lslpl	r0, r0, #1
2002196c:	b2c0      	uxtbpl	r0, r0
2002196e:	bf48      	it	mi
20021970:	2001      	movmi	r0, #1
20021972:	4770      	bx	lr
20021974:	50045000 	.word	0x50045000

20021978 <sdmmc1_sdnand>:
20021978:	b5f0      	push	{r4, r5, r6, r7, lr}
2002197a:	b08d      	sub	sp, #52	@ 0x34
2002197c:	f7ff ff58 	bl	20021830 <sd1_init>
20021980:	4c76      	ldr	r4, [pc, #472]	@ (20021b5c <sdmmc1_sdnand+0x1e4>)
20021982:	4b77      	ldr	r3, [pc, #476]	@ (20021b60 <sdmmc1_sdnand+0x1e8>)
20021984:	2500      	movs	r5, #0
20021986:	6323      	str	r3, [r4, #48]	@ 0x30
20021988:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002198a:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
2002198e:	f043 0302 	orr.w	r3, r3, #2
20021992:	6323      	str	r3, [r4, #48]	@ 0x30
20021994:	f44f 1380 	mov.w	r3, #1048576	@ 0x100000
20021998:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002199a:	6223      	str	r3, [r4, #32]
2002199c:	f000 fbdd 	bl	2002215a <HAL_Delay_us>
200219a0:	4629      	mov	r1, r5
200219a2:	4628      	mov	r0, r5
200219a4:	f7ff ff76 	bl	20021894 <sd1_send_cmd>
200219a8:	2301      	movs	r3, #1
200219aa:	65e3      	str	r3, [r4, #92]	@ 0x5c
200219ac:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
200219ae:	079b      	lsls	r3, r3, #30
200219b0:	d5fc      	bpl.n	200219ac <sdmmc1_sdnand+0x34>
200219b2:	2014      	movs	r0, #20
200219b4:	f000 fbd1 	bl	2002215a <HAL_Delay_us>
200219b8:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
200219bc:	2008      	movs	r0, #8
200219be:	f7ff ff69 	bl	20021894 <sd1_send_cmd>
200219c2:	3801      	subs	r0, #1
200219c4:	b2c0      	uxtb	r0, r0
200219c6:	2801      	cmp	r0, #1
200219c8:	d802      	bhi.n	200219d0 <sdmmc1_sdnand+0x58>
200219ca:	2038      	movs	r0, #56	@ 0x38
200219cc:	b00d      	add	sp, #52	@ 0x34
200219ce:	bdf0      	pop	{r4, r5, r6, r7, pc}
200219d0:	ac07      	add	r4, sp, #28
200219d2:	ab06      	add	r3, sp, #24
200219d4:	9400      	str	r4, [sp, #0]
200219d6:	aa05      	add	r2, sp, #20
200219d8:	a904      	add	r1, sp, #16
200219da:	f10d 000f 	add.w	r0, sp, #15
200219de:	f7ff ff97 	bl	20021910 <sd1_get_rsp>
200219e2:	f89d 300f 	ldrb.w	r3, [sp, #15]
200219e6:	2b08      	cmp	r3, #8
200219e8:	d1ef      	bne.n	200219ca <sdmmc1_sdnand+0x52>
200219ea:	9b04      	ldr	r3, [sp, #16]
200219ec:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
200219f0:	d1eb      	bne.n	200219ca <sdmmc1_sdnand+0x52>
200219f2:	2014      	movs	r0, #20
200219f4:	f000 fbb1 	bl	2002215a <HAL_Delay_us>
200219f8:	2200      	movs	r2, #0
200219fa:	2029      	movs	r0, #41	@ 0x29
200219fc:	4959      	ldr	r1, [pc, #356]	@ (20021b64 <sdmmc1_sdnand+0x1ec>)
200219fe:	f7ff ff69 	bl	200218d4 <sd1_send_acmd>
20021a02:	2801      	cmp	r0, #1
20021a04:	f000 80a2 	beq.w	20021b4c <sdmmc1_sdnand+0x1d4>
20021a08:	ab06      	add	r3, sp, #24
20021a0a:	9400      	str	r4, [sp, #0]
20021a0c:	aa05      	add	r2, sp, #20
20021a0e:	a904      	add	r1, sp, #16
20021a10:	f10d 000f 	add.w	r0, sp, #15
20021a14:	f7ff ff7c 	bl	20021910 <sd1_get_rsp>
20021a18:	9b04      	ldr	r3, [sp, #16]
20021a1a:	2b00      	cmp	r3, #0
20021a1c:	db03      	blt.n	20021a26 <sdmmc1_sdnand+0xae>
20021a1e:	2002      	movs	r0, #2
20021a20:	f000 fb9b 	bl	2002215a <HAL_Delay_us>
20021a24:	e7e5      	b.n	200219f2 <sdmmc1_sdnand+0x7a>
20021a26:	2014      	movs	r0, #20
20021a28:	f000 fb97 	bl	2002215a <HAL_Delay_us>
20021a2c:	2100      	movs	r1, #0
20021a2e:	2002      	movs	r0, #2
20021a30:	f7ff ff30 	bl	20021894 <sd1_send_cmd>
20021a34:	3801      	subs	r0, #1
20021a36:	b2c0      	uxtb	r0, r0
20021a38:	2801      	cmp	r0, #1
20021a3a:	f240 8089 	bls.w	20021b50 <sdmmc1_sdnand+0x1d8>
20021a3e:	ab08      	add	r3, sp, #32
20021a40:	aa0a      	add	r2, sp, #40	@ 0x28
20021a42:	a90b      	add	r1, sp, #44	@ 0x2c
20021a44:	9300      	str	r3, [sp, #0]
20021a46:	f10d 000f 	add.w	r0, sp, #15
20021a4a:	ab09      	add	r3, sp, #36	@ 0x24
20021a4c:	f7ff ff60 	bl	20021910 <sd1_get_rsp>
20021a50:	2014      	movs	r0, #20
20021a52:	f000 fb82 	bl	2002215a <HAL_Delay_us>
20021a56:	2100      	movs	r1, #0
20021a58:	2003      	movs	r0, #3
20021a5a:	f7ff ff1b 	bl	20021894 <sd1_send_cmd>
20021a5e:	3801      	subs	r0, #1
20021a60:	b2c0      	uxtb	r0, r0
20021a62:	2801      	cmp	r0, #1
20021a64:	d801      	bhi.n	20021a6a <sdmmc1_sdnand+0xf2>
20021a66:	2033      	movs	r0, #51	@ 0x33
20021a68:	e7b0      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021a6a:	ab06      	add	r3, sp, #24
20021a6c:	9400      	str	r4, [sp, #0]
20021a6e:	aa05      	add	r2, sp, #20
20021a70:	a904      	add	r1, sp, #16
20021a72:	f10d 000f 	add.w	r0, sp, #15
20021a76:	f7ff ff4b 	bl	20021910 <sd1_get_rsp>
20021a7a:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021a7e:	2b03      	cmp	r3, #3
20021a80:	d1f1      	bne.n	20021a66 <sdmmc1_sdnand+0xee>
20021a82:	9d04      	ldr	r5, [sp, #16]
20021a84:	2014      	movs	r0, #20
20021a86:	0c2e      	lsrs	r6, r5, #16
20021a88:	0436      	lsls	r6, r6, #16
20021a8a:	f000 fb66 	bl	2002215a <HAL_Delay_us>
20021a8e:	4631      	mov	r1, r6
20021a90:	2009      	movs	r0, #9
20021a92:	f7ff feff 	bl	20021894 <sd1_send_cmd>
20021a96:	3801      	subs	r0, #1
20021a98:	b2c0      	uxtb	r0, r0
20021a9a:	2801      	cmp	r0, #1
20021a9c:	d95a      	bls.n	20021b54 <sdmmc1_sdnand+0x1dc>
20021a9e:	ab06      	add	r3, sp, #24
20021aa0:	aa05      	add	r2, sp, #20
20021aa2:	a904      	add	r1, sp, #16
20021aa4:	f10d 000f 	add.w	r0, sp, #15
20021aa8:	9400      	str	r4, [sp, #0]
20021aaa:	f7ff ff31 	bl	20021910 <sd1_get_rsp>
20021aae:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021ab2:	9f06      	ldr	r7, [sp, #24]
20021ab4:	9907      	ldr	r1, [sp, #28]
20021ab6:	0e3b      	lsrs	r3, r7, #24
20021ab8:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
20021abc:	0e01      	lsrs	r1, r0, #24
20021abe:	ea41 2107 	orr.w	r1, r1, r7, lsl #8
20021ac2:	9105      	str	r1, [sp, #20]
20021ac4:	0e11      	lsrs	r1, r2, #24
20021ac6:	9304      	str	r3, [sp, #16]
20021ac8:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
20021acc:	0212      	lsls	r2, r2, #8
20021ace:	0f9b      	lsrs	r3, r3, #30
20021ad0:	9106      	str	r1, [sp, #24]
20021ad2:	9207      	str	r2, [sp, #28]
20021ad4:	d01d      	beq.n	20021b12 <sdmmc1_sdnand+0x19a>
20021ad6:	2b01      	cmp	r3, #1
20021ad8:	d13e      	bne.n	20021b58 <sdmmc1_sdnand+0x1e0>
20021ada:	2300      	movs	r3, #0
20021adc:	4a22      	ldr	r2, [pc, #136]	@ (20021b68 <sdmmc1_sdnand+0x1f0>)
20021ade:	2014      	movs	r0, #20
20021ae0:	7013      	strb	r3, [r2, #0]
20021ae2:	f44f 7200 	mov.w	r2, #512	@ 0x200
20021ae6:	4b1d      	ldr	r3, [pc, #116]	@ (20021b5c <sdmmc1_sdnand+0x1e4>)
20021ae8:	631a      	str	r2, [r3, #48]	@ 0x30
20021aea:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
20021aec:	f042 0202 	orr.w	r2, r2, #2
20021af0:	631a      	str	r2, [r3, #48]	@ 0x30
20021af2:	4a1e      	ldr	r2, [pc, #120]	@ (20021b6c <sdmmc1_sdnand+0x1f4>)
20021af4:	621a      	str	r2, [r3, #32]
20021af6:	2200      	movs	r2, #0
20021af8:	63da      	str	r2, [r3, #60]	@ 0x3c
20021afa:	f000 fb2e 	bl	2002215a <HAL_Delay_us>
20021afe:	4631      	mov	r1, r6
20021b00:	2007      	movs	r0, #7
20021b02:	f7ff fec7 	bl	20021894 <sd1_send_cmd>
20021b06:	3801      	subs	r0, #1
20021b08:	b2c0      	uxtb	r0, r0
20021b0a:	2801      	cmp	r0, #1
20021b0c:	d803      	bhi.n	20021b16 <sdmmc1_sdnand+0x19e>
20021b0e:	2037      	movs	r0, #55	@ 0x37
20021b10:	e75c      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b12:	2301      	movs	r3, #1
20021b14:	e7e2      	b.n	20021adc <sdmmc1_sdnand+0x164>
20021b16:	ab06      	add	r3, sp, #24
20021b18:	9400      	str	r4, [sp, #0]
20021b1a:	aa05      	add	r2, sp, #20
20021b1c:	a904      	add	r1, sp, #16
20021b1e:	f10d 000f 	add.w	r0, sp, #15
20021b22:	f7ff fef5 	bl	20021910 <sd1_get_rsp>
20021b26:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021b2a:	2b07      	cmp	r3, #7
20021b2c:	d1ef      	bne.n	20021b0e <sdmmc1_sdnand+0x196>
20021b2e:	2014      	movs	r0, #20
20021b30:	f000 fb13 	bl	2002215a <HAL_Delay_us>
20021b34:	2102      	movs	r1, #2
20021b36:	2006      	movs	r0, #6
20021b38:	0c2a      	lsrs	r2, r5, #16
20021b3a:	f7ff fecb 	bl	200218d4 <sd1_send_acmd>
20021b3e:	3801      	subs	r0, #1
20021b40:	b2c0      	uxtb	r0, r0
20021b42:	2801      	cmp	r0, #1
20021b44:	bf8c      	ite	hi
20021b46:	2001      	movhi	r0, #1
20021b48:	2036      	movls	r0, #54	@ 0x36
20021b4a:	e73f      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b4c:	2034      	movs	r0, #52	@ 0x34
20021b4e:	e73d      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b50:	2032      	movs	r0, #50	@ 0x32
20021b52:	e73b      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b54:	2039      	movs	r0, #57	@ 0x39
20021b56:	e739      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b58:	2054      	movs	r0, #84	@ 0x54
20021b5a:	e737      	b.n	200219cc <sdmmc1_sdnand+0x54>
20021b5c:	50045000 	.word	0x50045000
20021b60:	00016700 	.word	0x00016700
20021b64:	40ff8000 	.word	0x40ff8000
20021b68:	20042c08 	.word	0x20042c08
20021b6c:	00249f00 	.word	0x00249f00

20021b70 <sd_read_data>:
20021b70:	b570      	push	{r4, r5, r6, lr}
20021b72:	f1b1 4fc0 	cmp.w	r1, #1610612736	@ 0x60000000
20021b76:	4605      	mov	r5, r0
20021b78:	4614      	mov	r4, r2
20021b7a:	b088      	sub	sp, #32
20021b7c:	d314      	bcc.n	20021ba8 <sd_read_data+0x38>
20021b7e:	2a00      	cmp	r2, #0
20021b80:	dd12      	ble.n	20021ba8 <sd_read_data+0x38>
20021b82:	f001 021f 	and.w	r2, r1, #31
20021b86:	4422      	add	r2, r4
20021b88:	f021 031f 	bic.w	r3, r1, #31
20021b8c:	f3bf 8f4f 	dsb	sy
20021b90:	4e30      	ldr	r6, [pc, #192]	@ (20021c54 <sd_read_data+0xe4>)
20021b92:	441a      	add	r2, r3
20021b94:	f8c6 325c 	str.w	r3, [r6, #604]	@ 0x25c
20021b98:	3320      	adds	r3, #32
20021b9a:	1ad0      	subs	r0, r2, r3
20021b9c:	2800      	cmp	r0, #0
20021b9e:	dcf9      	bgt.n	20021b94 <sd_read_data+0x24>
20021ba0:	f3bf 8f4f 	dsb	sy
20021ba4:	f3bf 8f6f 	isb	sy
20021ba8:	2200      	movs	r2, #0
20021baa:	4b2b      	ldr	r3, [pc, #172]	@ (20021c58 <sd_read_data+0xe8>)
20021bac:	631a      	str	r2, [r3, #48]	@ 0x30
20021bae:	4a2b      	ldr	r2, [pc, #172]	@ (20021c5c <sd_read_data+0xec>)
20021bb0:	639a      	str	r2, [r3, #56]	@ 0x38
20021bb2:	2280      	movs	r2, #128	@ 0x80
20021bb4:	63d9      	str	r1, [r3, #60]	@ 0x3c
20021bb6:	635a      	str	r2, [r3, #52]	@ 0x34
20021bb8:	f8d3 20a8 	ldr.w	r2, [r3, #168]	@ 0xa8
20021bbc:	2101      	movs	r1, #1
20021bbe:	f422 127c 	bic.w	r2, r2, #4128768	@ 0x3f0000
20021bc2:	f442 1264 	orr.w	r2, r2, #3735552	@ 0x390000
20021bc6:	f8c3 20a8 	str.w	r2, [r3, #168]	@ 0xa8
20021bca:	f44f 6228 	mov.w	r2, #2688	@ 0xa80
20021bce:	631a      	str	r2, [r3, #48]	@ 0x30
20021bd0:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
20021bd2:	4608      	mov	r0, r1
20021bd4:	f022 0220 	bic.w	r2, r2, #32
20021bd8:	631a      	str	r2, [r3, #48]	@ 0x30
20021bda:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
20021bdc:	f042 0201 	orr.w	r2, r2, #1
20021be0:	631a      	str	r2, [r3, #48]	@ 0x30
20021be2:	f7ff fea5 	bl	20021930 <sd1_read>
20021be6:	2014      	movs	r0, #20
20021be8:	f000 fab7 	bl	2002215a <HAL_Delay_us>
20021bec:	4b1c      	ldr	r3, [pc, #112]	@ (20021c60 <sd_read_data+0xf0>)
20021bee:	781b      	ldrb	r3, [r3, #0]
20021bf0:	b903      	cbnz	r3, 20021bf4 <sd_read_data+0x84>
20021bf2:	0a6d      	lsrs	r5, r5, #9
20021bf4:	4629      	mov	r1, r5
20021bf6:	2011      	movs	r0, #17
20021bf8:	f7ff fe4c 	bl	20021894 <sd1_send_cmd>
20021bfc:	3801      	subs	r0, #1
20021bfe:	b2c0      	uxtb	r0, r0
20021c00:	2801      	cmp	r0, #1
20021c02:	d802      	bhi.n	20021c0a <sd_read_data+0x9a>
20021c04:	2000      	movs	r0, #0
20021c06:	b008      	add	sp, #32
20021c08:	bd70      	pop	{r4, r5, r6, pc}
20021c0a:	ab07      	add	r3, sp, #28
20021c0c:	9300      	str	r3, [sp, #0]
20021c0e:	aa05      	add	r2, sp, #20
20021c10:	ab06      	add	r3, sp, #24
20021c12:	a904      	add	r1, sp, #16
20021c14:	f10d 000f 	add.w	r0, sp, #15
20021c18:	f7ff fe7a 	bl	20021910 <sd1_get_rsp>
20021c1c:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021c20:	2b11      	cmp	r3, #17
20021c22:	d1ef      	bne.n	20021c04 <sd_read_data+0x94>
20021c24:	f04f 33ff 	mov.w	r3, #4294967295
20021c28:	4d0e      	ldr	r5, [pc, #56]	@ (20021c64 <sd_read_data+0xf4>)
20021c2a:	602b      	str	r3, [r5, #0]
20021c2c:	2320      	movs	r3, #32
20021c2e:	62eb      	str	r3, [r5, #44]	@ 0x2c
20021c30:	f7ff fe8e 	bl	20021950 <sd1_wait_read>
20021c34:	682b      	ldr	r3, [r5, #0]
20021c36:	061a      	lsls	r2, r3, #24
20021c38:	d4e4      	bmi.n	20021c04 <sd_read_data+0x94>
20021c3a:	682b      	ldr	r3, [r5, #0]
20021c3c:	065b      	lsls	r3, r3, #25
20021c3e:	d4e1      	bmi.n	20021c04 <sd_read_data+0x94>
20021c40:	4b05      	ldr	r3, [pc, #20]	@ (20021c58 <sd_read_data+0xe8>)
20021c42:	6b5a      	ldr	r2, [r3, #52]	@ 0x34
20021c44:	2a00      	cmp	r2, #0
20021c46:	d1fc      	bne.n	20021c42 <sd_read_data+0xd2>
20021c48:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
20021c4a:	4620      	mov	r0, r4
20021c4c:	f022 0201 	bic.w	r2, r2, #1
20021c50:	631a      	str	r2, [r3, #48]	@ 0x30
20021c52:	e7d8      	b.n	20021c06 <sd_read_data+0x96>
20021c54:	e000ed00 	.word	0xe000ed00
20021c58:	50081000 	.word	0x50081000
20021c5c:	50045200 	.word	0x50045200
20021c60:	20042c08 	.word	0x20042c08
20021c64:	50045000 	.word	0x50045000

20021c68 <sd_read_multi>:
20021c68:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20021c6c:	4680      	mov	r8, r0
20021c6e:	460e      	mov	r6, r1
20021c70:	4615      	mov	r5, r2
20021c72:	b089      	sub	sp, #36	@ 0x24
20021c74:	2a00      	cmp	r2, #0
20021c76:	d059      	beq.n	20021d2c <sd_read_multi+0xc4>
20021c78:	f3c2 0308 	ubfx	r3, r2, #0, #9
20021c7c:	2b00      	cmp	r3, #0
20021c7e:	d155      	bne.n	20021d2c <sd_read_multi+0xc4>
20021c80:	4691      	mov	r9, r2
20021c82:	4c4d      	ldr	r4, [pc, #308]	@ (20021db8 <sd_read_multi+0x150>)
20021c84:	f8df b140 	ldr.w	fp, [pc, #320]	@ 20021dc8 <sd_read_multi+0x160>
20021c88:	f8d4 30a8 	ldr.w	r3, [r4, #168]	@ 0xa8
20021c8c:	f423 137c 	bic.w	r3, r3, #4128768	@ 0x3f0000
20021c90:	f443 1364 	orr.w	r3, r3, #3735552	@ 0x390000
20021c94:	f8c4 30a8 	str.w	r3, [r4, #168]	@ 0xa8
20021c98:	f5b9 3f00 	cmp.w	r9, #131072	@ 0x20000
20021c9c:	bf2c      	ite	cs
20021c9e:	21ff      	movcs	r1, #255	@ 0xff
20021ca0:	ea4f 2159 	movcc.w	r1, r9, lsr #9
20021ca4:	f1b6 4fc0 	cmp.w	r6, #1610612736	@ 0x60000000
20021ca8:	ea4f 2741 	mov.w	r7, r1, lsl #9
20021cac:	d312      	bcc.n	20021cd4 <sd_read_multi+0x6c>
20021cae:	b18f      	cbz	r7, 20021cd4 <sd_read_multi+0x6c>
20021cb0:	f006 021f 	and.w	r2, r6, #31
20021cb4:	443a      	add	r2, r7
20021cb6:	f026 031f 	bic.w	r3, r6, #31
20021cba:	f3bf 8f4f 	dsb	sy
20021cbe:	441a      	add	r2, r3
20021cc0:	f8cb 325c 	str.w	r3, [fp, #604]	@ 0x25c
20021cc4:	3320      	adds	r3, #32
20021cc6:	1ad0      	subs	r0, r2, r3
20021cc8:	2800      	cmp	r0, #0
20021cca:	dcf9      	bgt.n	20021cc0 <sd_read_multi+0x58>
20021ccc:	f3bf 8f4f 	dsb	sy
20021cd0:	f3bf 8f6f 	isb	sy
20021cd4:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021cd6:	f04f 32ff 	mov.w	r2, #4294967295
20021cda:	f023 0301 	bic.w	r3, r3, #1
20021cde:	6323      	str	r3, [r4, #48]	@ 0x30
20021ce0:	4b36      	ldr	r3, [pc, #216]	@ (20021dbc <sd_read_multi+0x154>)
20021ce2:	2001      	movs	r0, #1
20021ce4:	63a3      	str	r3, [r4, #56]	@ 0x38
20021ce6:	08bb      	lsrs	r3, r7, #2
20021ce8:	63e6      	str	r6, [r4, #60]	@ 0x3c
20021cea:	6363      	str	r3, [r4, #52]	@ 0x34
20021cec:	f44f 6328 	mov.w	r3, #2688	@ 0xa80
20021cf0:	6323      	str	r3, [r4, #48]	@ 0x30
20021cf2:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021cf4:	b2c9      	uxtb	r1, r1
20021cf6:	f023 0320 	bic.w	r3, r3, #32
20021cfa:	6323      	str	r3, [r4, #48]	@ 0x30
20021cfc:	4b30      	ldr	r3, [pc, #192]	@ (20021dc0 <sd_read_multi+0x158>)
20021cfe:	601a      	str	r2, [r3, #0]
20021d00:	f7ff fe16 	bl	20021930 <sd1_read>
20021d04:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021d06:	f043 0301 	orr.w	r3, r3, #1
20021d0a:	6323      	str	r3, [r4, #48]	@ 0x30
20021d0c:	4b2d      	ldr	r3, [pc, #180]	@ (20021dc4 <sd_read_multi+0x15c>)
20021d0e:	781b      	ldrb	r3, [r3, #0]
20021d10:	b983      	cbnz	r3, 20021d34 <sd_read_multi+0xcc>
20021d12:	ea4f 2158 	mov.w	r1, r8, lsr #9
20021d16:	2012      	movs	r0, #18
20021d18:	f7ff fdbc 	bl	20021894 <sd1_send_cmd>
20021d1c:	3801      	subs	r0, #1
20021d1e:	2801      	cmp	r0, #1
20021d20:	d80a      	bhi.n	20021d38 <sd_read_multi+0xd0>
20021d22:	4a25      	ldr	r2, [pc, #148]	@ (20021db8 <sd_read_multi+0x150>)
20021d24:	6b13      	ldr	r3, [r2, #48]	@ 0x30
20021d26:	f023 0301 	bic.w	r3, r3, #1
20021d2a:	6313      	str	r3, [r2, #48]	@ 0x30
20021d2c:	2000      	movs	r0, #0
20021d2e:	b009      	add	sp, #36	@ 0x24
20021d30:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20021d34:	4641      	mov	r1, r8
20021d36:	e7ee      	b.n	20021d16 <sd_read_multi+0xae>
20021d38:	ab07      	add	r3, sp, #28
20021d3a:	9300      	str	r3, [sp, #0]
20021d3c:	aa05      	add	r2, sp, #20
20021d3e:	ab06      	add	r3, sp, #24
20021d40:	a904      	add	r1, sp, #16
20021d42:	f10d 000f 	add.w	r0, sp, #15
20021d46:	f7ff fde3 	bl	20021910 <sd1_get_rsp>
20021d4a:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021d4e:	2b12      	cmp	r3, #18
20021d50:	d1e7      	bne.n	20021d22 <sd_read_multi+0xba>
20021d52:	2220      	movs	r2, #32
20021d54:	f8df a068 	ldr.w	sl, [pc, #104]	@ 20021dc0 <sd_read_multi+0x158>
20021d58:	f8ca 202c 	str.w	r2, [sl, #44]	@ 0x2c
20021d5c:	f7ff fdf8 	bl	20021950 <sd1_wait_read>
20021d60:	f8da 3000 	ldr.w	r3, [sl]
20021d64:	f013 0fc0 	tst.w	r3, #192	@ 0xc0
20021d68:	d008      	beq.n	20021d7c <sd_read_multi+0x114>
20021d6a:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021d6c:	2100      	movs	r1, #0
20021d6e:	f023 0301 	bic.w	r3, r3, #1
20021d72:	6323      	str	r3, [r4, #48]	@ 0x30
20021d74:	200c      	movs	r0, #12
20021d76:	f7ff fd8d 	bl	20021894 <sd1_send_cmd>
20021d7a:	e7d7      	b.n	20021d2c <sd_read_multi+0xc4>
20021d7c:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20021d7e:	2900      	cmp	r1, #0
20021d80:	d1fc      	bne.n	20021d7c <sd_read_multi+0x114>
20021d82:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021d84:	200c      	movs	r0, #12
20021d86:	f023 0301 	bic.w	r3, r3, #1
20021d8a:	6323      	str	r3, [r4, #48]	@ 0x30
20021d8c:	f7ff fd82 	bl	20021894 <sd1_send_cmd>
20021d90:	3801      	subs	r0, #1
20021d92:	2801      	cmp	r0, #1
20021d94:	d9ca      	bls.n	20021d2c <sd_read_multi+0xc4>
20021d96:	ab07      	add	r3, sp, #28
20021d98:	9300      	str	r3, [sp, #0]
20021d9a:	aa05      	add	r2, sp, #20
20021d9c:	ab06      	add	r3, sp, #24
20021d9e:	a904      	add	r1, sp, #16
20021da0:	f10d 000f 	add.w	r0, sp, #15
20021da4:	f7ff fdb4 	bl	20021910 <sd1_get_rsp>
20021da8:	ebb9 0907 	subs.w	r9, r9, r7
20021dac:	443e      	add	r6, r7
20021dae:	44b8      	add	r8, r7
20021db0:	f47f af72 	bne.w	20021c98 <sd_read_multi+0x30>
20021db4:	4628      	mov	r0, r5
20021db6:	e7ba      	b.n	20021d2e <sd_read_multi+0xc6>
20021db8:	50081000 	.word	0x50081000
20021dbc:	50045200 	.word	0x50045200
20021dc0:	50045000 	.word	0x50045000
20021dc4:	20042c08 	.word	0x20042c08
20021dc8:	e000ed00 	.word	0xe000ed00

20021dcc <sifli_hash_calculate>:
20021dcc:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20021dd0:	460c      	mov	r4, r1
20021dd2:	4615      	mov	r5, r2
20021dd4:	4699      	mov	r9, r3
20021dd6:	4680      	mov	r8, r0
20021dd8:	2800      	cmp	r0, #0
20021dda:	d03f      	beq.n	20021e5c <sifli_hash_calculate+0x90>
20021ddc:	2900      	cmp	r1, #0
20021dde:	d03d      	beq.n	20021e5c <sifli_hash_calculate+0x90>
20021de0:	2a00      	cmp	r2, #0
20021de2:	d03b      	beq.n	20021e5c <sifli_hash_calculate+0x90>
20021de4:	2b03      	cmp	r3, #3
20021de6:	d839      	bhi.n	20021e5c <sifli_hash_calculate+0x90>
20021de8:	f000 facc 	bl	20022384 <HAL_HASH_reset>
20021dec:	2200      	movs	r2, #0
20021dee:	4649      	mov	r1, r9
20021df0:	4610      	mov	r0, r2
20021df2:	f000 facf 	bl	20022394 <HAL_HASH_init>
20021df6:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20021dfa:	d929      	bls.n	20021e50 <sifli_hash_calculate+0x84>
20021dfc:	2600      	movs	r6, #0
20021dfe:	4637      	mov	r7, r6
20021e00:	f506 7680 	add.w	r6, r6, #256	@ 0x100
20021e04:	42a6      	cmp	r6, r4
20021e06:	bf34      	ite	cc
20021e08:	f04f 0a00 	movcc.w	sl, #0
20021e0c:	f04f 0a01 	movcs.w	sl, #1
20021e10:	b14f      	cbz	r7, 20021e26 <sifli_hash_calculate+0x5a>
20021e12:	f000 fab7 	bl	20022384 <HAL_HASH_reset>
20021e16:	42a6      	cmp	r6, r4
20021e18:	bf2c      	ite	cs
20021e1a:	463a      	movcs	r2, r7
20021e1c:	2200      	movcc	r2, #0
20021e1e:	4649      	mov	r1, r9
20021e20:	4628      	mov	r0, r5
20021e22:	f000 fab7 	bl	20022394 <HAL_HASH_init>
20021e26:	42a6      	cmp	r6, r4
20021e28:	bf34      	ite	cc
20021e2a:	f44f 7180 	movcc.w	r1, #256	@ 0x100
20021e2e:	1be1      	subcs	r1, r4, r7
20021e30:	4652      	mov	r2, sl
20021e32:	eb08 0007 	add.w	r0, r8, r7
20021e36:	f000 fa87 	bl	20022348 <HAL_HASH_run>
20021e3a:	4628      	mov	r0, r5
20021e3c:	f000 fad8 	bl	200223f0 <HAL_HASH_result>
20021e40:	42a6      	cmp	r6, r4
20021e42:	d3dc      	bcc.n	20021dfe <sifli_hash_calculate+0x32>
20021e44:	4628      	mov	r0, r5
20021e46:	f000 fad3 	bl	200223f0 <HAL_HASH_result>
20021e4a:	2000      	movs	r0, #0
20021e4c:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20021e50:	2201      	movs	r2, #1
20021e52:	4621      	mov	r1, r4
20021e54:	4640      	mov	r0, r8
20021e56:	f000 fa77 	bl	20022348 <HAL_HASH_run>
20021e5a:	e7f3      	b.n	20021e44 <sifli_hash_calculate+0x78>
20021e5c:	f04f 30ff 	mov.w	r0, #4294967295
20021e60:	e7f4      	b.n	20021e4c <sifli_hash_calculate+0x80>

20021e62 <sifli_hash_verify>:
20021e62:	b5f0      	push	{r4, r5, r6, r7, lr}
20021e64:	4605      	mov	r5, r0
20021e66:	b089      	sub	sp, #36	@ 0x24
20021e68:	460f      	mov	r7, r1
20021e6a:	4614      	mov	r4, r2
20021e6c:	2100      	movs	r1, #0
20021e6e:	2220      	movs	r2, #32
20021e70:	4668      	mov	r0, sp
20021e72:	461e      	mov	r6, r3
20021e74:	f008 fdd2 	bl	2002aa1c <memset>
20021e78:	b91d      	cbnz	r5, 20021e82 <sifli_hash_verify+0x20>
20021e7a:	f04f 30ff 	mov.w	r0, #4294967295
20021e7e:	b009      	add	sp, #36	@ 0x24
20021e80:	bdf0      	pop	{r4, r5, r6, r7, pc}
20021e82:	2c00      	cmp	r4, #0
20021e84:	d0f9      	beq.n	20021e7a <sifli_hash_verify+0x18>
20021e86:	2302      	movs	r3, #2
20021e88:	466a      	mov	r2, sp
20021e8a:	4639      	mov	r1, r7
20021e8c:	4628      	mov	r0, r5
20021e8e:	f7ff ff9d 	bl	20021dcc <sifli_hash_calculate>
20021e92:	2800      	cmp	r0, #0
20021e94:	d1f1      	bne.n	20021e7a <sifli_hash_verify+0x18>
20021e96:	4632      	mov	r2, r6
20021e98:	4621      	mov	r1, r4
20021e9a:	4668      	mov	r0, sp
20021e9c:	f008 fdae 	bl	2002a9fc <memcmp>
20021ea0:	3800      	subs	r0, #0
20021ea2:	bf18      	it	ne
20021ea4:	2001      	movne	r0, #1
20021ea6:	4240      	negs	r0, r0
20021ea8:	e7e9      	b.n	20021e7e <sifli_hash_verify+0x1c>

20021eaa <sifli_sigkey_pub_verify>:
20021eaa:	2300      	movs	r3, #0
20021eac:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021eae:	4604      	mov	r4, r0
20021eb0:	460d      	mov	r5, r1
20021eb2:	2208      	movs	r2, #8
20021eb4:	4669      	mov	r1, sp
20021eb6:	2003      	movs	r0, #3
20021eb8:	e9cd 3300 	strd	r3, r3, [sp]
20021ebc:	f7ff f886 	bl	20020fcc <sifli_hw_efuse_read>
20021ec0:	2808      	cmp	r0, #8
20021ec2:	4603      	mov	r3, r0
20021ec4:	d106      	bne.n	20021ed4 <sifli_sigkey_pub_verify+0x2a>
20021ec6:	466a      	mov	r2, sp
20021ec8:	4629      	mov	r1, r5
20021eca:	4620      	mov	r0, r4
20021ecc:	f7ff ffc9 	bl	20021e62 <sifli_hash_verify>
20021ed0:	b003      	add	sp, #12
20021ed2:	bd30      	pop	{r4, r5, pc}
20021ed4:	f04f 30ff 	mov.w	r0, #4294967295
20021ed8:	e7fa      	b.n	20021ed0 <sifli_sigkey_pub_verify+0x26>

20021eda <sifli_img_sig_hash_verify>:
20021eda:	b5f0      	push	{r4, r5, r6, r7, lr}
20021edc:	461f      	mov	r7, r3
20021ede:	4616      	mov	r6, r2
20021ee0:	b08d      	sub	sp, #52	@ 0x34
20021ee2:	2220      	movs	r2, #32
20021ee4:	4604      	mov	r4, r0
20021ee6:	460d      	mov	r5, r1
20021ee8:	a804      	add	r0, sp, #16
20021eea:	2100      	movs	r1, #0
20021eec:	f008 fd96 	bl	2002aa1c <memset>
20021ef0:	2302      	movs	r3, #2
20021ef2:	4639      	mov	r1, r7
20021ef4:	4630      	mov	r0, r6
20021ef6:	aa04      	add	r2, sp, #16
20021ef8:	f7ff ff68 	bl	20021dcc <sifli_hash_calculate>
20021efc:	b118      	cbz	r0, 20021f06 <sifli_img_sig_hash_verify+0x2c>
20021efe:	f04f 30ff 	mov.w	r0, #4294967295
20021f02:	b00d      	add	sp, #52	@ 0x34
20021f04:	bdf0      	pop	{r4, r5, r6, r7, pc}
20021f06:	a802      	add	r0, sp, #8
20021f08:	f007 fafc 	bl	20029504 <mbedtls_pk_init>
20021f0c:	4629      	mov	r1, r5
20021f0e:	f44f 7293 	mov.w	r2, #294	@ 0x126
20021f12:	a802      	add	r0, sp, #8
20021f14:	f007 fc02 	bl	2002971c <mbedtls_pk_parse_public_key>
20021f18:	4601      	mov	r1, r0
20021f1a:	2800      	cmp	r0, #0
20021f1c:	d1ef      	bne.n	20021efe <sifli_img_sig_hash_verify+0x24>
20021f1e:	2206      	movs	r2, #6
20021f20:	9803      	ldr	r0, [sp, #12]
20021f22:	f007 fca2 	bl	2002986a <mbedtls_rsa_set_padding>
20021f26:	f44f 7380 	mov.w	r3, #256	@ 0x100
20021f2a:	2106      	movs	r1, #6
20021f2c:	e9cd 4300 	strd	r4, r3, [sp]
20021f30:	aa04      	add	r2, sp, #16
20021f32:	2320      	movs	r3, #32
20021f34:	a802      	add	r0, sp, #8
20021f36:	f007 fb19 	bl	2002956c <mbedtls_pk_verify>
20021f3a:	3800      	subs	r0, #0
20021f3c:	bf18      	it	ne
20021f3e:	2001      	movne	r0, #1
20021f40:	4240      	negs	r0, r0
20021f42:	e7de      	b.n	20021f02 <sifli_img_sig_hash_verify+0x28>

20021f44 <sifli_secboot_exception>:
20021f44:	2801      	cmp	r0, #1
20021f46:	b508      	push	{r3, lr}
20021f48:	d004      	beq.n	20021f54 <sifli_secboot_exception+0x10>
20021f4a:	2802      	cmp	r0, #2
20021f4c:	d009      	beq.n	20021f62 <sifli_secboot_exception+0x1e>
20021f4e:	2213      	movs	r2, #19
20021f50:	4905      	ldr	r1, [pc, #20]	@ (20021f68 <sifli_secboot_exception+0x24>)
20021f52:	e001      	b.n	20021f58 <sifli_secboot_exception+0x14>
20021f54:	2217      	movs	r2, #23
20021f56:	4905      	ldr	r1, [pc, #20]	@ (20021f6c <sifli_secboot_exception+0x28>)
20021f58:	4805      	ldr	r0, [pc, #20]	@ (20021f70 <sifli_secboot_exception+0x2c>)
20021f5a:	f7fe f955 	bl	20020208 <boot_uart_tx>
20021f5e:	e7fe      	b.n	20021f5e <sifli_secboot_exception+0x1a>
20021f60:	bd08      	pop	{r3, pc}
20021f62:	2219      	movs	r2, #25
20021f64:	4903      	ldr	r1, [pc, #12]	@ (20021f74 <sifli_secboot_exception+0x30>)
20021f66:	e7f7      	b.n	20021f58 <sifli_secboot_exception+0x14>
20021f68:	2002ab7a 	.word	0x2002ab7a
20021f6c:	2002ab48 	.word	0x2002ab48
20021f70:	50084000 	.word	0x50084000
20021f74:	2002ab60 	.word	0x2002ab60

20021f78 <BSP_GetFlash1DIV>:
20021f78:	4b01      	ldr	r3, [pc, #4]	@ (20021f80 <BSP_GetFlash1DIV+0x8>)
20021f7a:	8818      	ldrh	r0, [r3, #0]
20021f7c:	4770      	bx	lr
20021f7e:	bf00      	nop
20021f80:	20042c0c 	.word	0x20042c0c

20021f84 <BSP_GetFlash2DIV>:
20021f84:	4b01      	ldr	r3, [pc, #4]	@ (20021f8c <BSP_GetFlash2DIV+0x8>)
20021f86:	8818      	ldrh	r0, [r3, #0]
20021f88:	4770      	bx	lr
20021f8a:	bf00      	nop
20021f8c:	20042c0a 	.word	0x20042c0a

20021f90 <BSP_SetFlash1DIV>:
20021f90:	4b01      	ldr	r3, [pc, #4]	@ (20021f98 <BSP_SetFlash1DIV+0x8>)
20021f92:	8018      	strh	r0, [r3, #0]
20021f94:	4770      	bx	lr
20021f96:	bf00      	nop
20021f98:	20042c0c 	.word	0x20042c0c

20021f9c <BSP_SetFlash2DIV>:
20021f9c:	4b01      	ldr	r3, [pc, #4]	@ (20021fa4 <BSP_SetFlash2DIV+0x8>)
20021f9e:	8018      	strh	r0, [r3, #0]
20021fa0:	4770      	bx	lr
20021fa2:	bf00      	nop
20021fa4:	20042c0a 	.word	0x20042c0a

20021fa8 <boot_images>:
20021fa8:	4770      	bx	lr

20021faa <SystemPowerOnModeInit>:
20021faa:	4770      	bx	lr

20021fac <SystemInit>:
20021fac:	b508      	push	{r3, lr}
20021fae:	4a10      	ldr	r2, [pc, #64]	@ (20021ff0 <SystemInit+0x44>)
20021fb0:	4b10      	ldr	r3, [pc, #64]	@ (20021ff4 <SystemInit+0x48>)
20021fb2:	609a      	str	r2, [r3, #8]
20021fb4:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021fb8:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021fbc:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021fc0:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021fc4:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
20021fc8:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021fcc:	f7ff fa70 	bl	200214b0 <hw_preinit0>
20021fd0:	f7fe f954 	bl	2002027c <mpu_config>
20021fd4:	4b08      	ldr	r3, [pc, #32]	@ (20021ff8 <SystemInit+0x4c>)
20021fd6:	681b      	ldr	r3, [r3, #0]
20021fd8:	07db      	lsls	r3, r3, #31
20021fda:	d401      	bmi.n	20021fe0 <SystemInit+0x34>
20021fdc:	f7ff ffe4 	bl	20021fa8 <boot_images>
20021fe0:	f7fe f94d 	bl	2002027e <cache_enable>
20021fe4:	f7ff ffe1 	bl	20021faa <SystemPowerOnModeInit>
20021fe8:	4b04      	ldr	r3, [pc, #16]	@ (20021ffc <SystemInit+0x50>)
20021fea:	4a05      	ldr	r2, [pc, #20]	@ (20022000 <SystemInit+0x54>)
20021fec:	601a      	str	r2, [r3, #0]
20021fee:	bd08      	pop	{r3, pc}
20021ff0:	20020000 	.word	0x20020000
20021ff4:	e000ed00 	.word	0xe000ed00
20021ff8:	5000b000 	.word	0x5000b000
20021ffc:	20042c10 	.word	0x20042c10
20022000:	017d7840 	.word	0x017d7840

20022004 <pmu_ldo_inc>:
20022004:	b510      	push	{r4, lr}
20022006:	4b08      	ldr	r3, [pc, #32]	@ (20022028 <pmu_ldo_inc+0x24>)
20022008:	f8d3 4094 	ldr.w	r4, [r3, #148]	@ 0x94
2002200c:	4420      	add	r0, r4
2002200e:	280e      	cmp	r0, #14
20022010:	bf38      	it	cc
20022012:	200e      	movcc	r0, #14
20022014:	280f      	cmp	r0, #15
20022016:	bf28      	it	cs
20022018:	200f      	movcs	r0, #15
2002201a:	f8c3 0094 	str.w	r0, [r3, #148]	@ 0x94
2002201e:	2014      	movs	r0, #20
20022020:	f000 f89b 	bl	2002215a <HAL_Delay_us>
20022024:	4620      	mov	r0, r4
20022026:	bd10      	pop	{r4, pc}
20022028:	500ca000 	.word	0x500ca000

2002202c <pmu_ldo_recover>:
2002202c:	4b01      	ldr	r3, [pc, #4]	@ (20022034 <pmu_ldo_recover+0x8>)
2002202e:	f8c3 0094 	str.w	r0, [r3, #148]	@ 0x94
20022032:	4770      	bx	lr
20022034:	500ca000 	.word	0x500ca000

20022038 <Reset_Handler>:
20022038:	f8df d048 	ldr.w	sp, [pc, #72]	@ 20022084 <AES_IRQHandler+0x2>
2002203c:	4812      	ldr	r0, [pc, #72]	@ (20022088 <AES_IRQHandler+0x6>)
2002203e:	f380 880a 	msr	MSPLIM, r0
20022042:	f7ff ffb3 	bl	20021fac <SystemInit>
20022046:	4c11      	ldr	r4, [pc, #68]	@ (2002208c <AES_IRQHandler+0xa>)
20022048:	4d11      	ldr	r5, [pc, #68]	@ (20022090 <AES_IRQHandler+0xe>)
2002204a:	42ac      	cmp	r4, r5
2002204c:	da09      	bge.n	20022062 <Reset_Handler+0x2a>
2002204e:	6821      	ldr	r1, [r4, #0]
20022050:	6862      	ldr	r2, [r4, #4]
20022052:	68a3      	ldr	r3, [r4, #8]
20022054:	3b04      	subs	r3, #4
20022056:	bfa2      	ittt	ge
20022058:	58c8      	ldrge	r0, [r1, r3]
2002205a:	50d0      	strge	r0, [r2, r3]
2002205c:	e7fa      	bge.n	20022054 <Reset_Handler+0x1c>
2002205e:	340c      	adds	r4, #12
20022060:	e7f3      	b.n	2002204a <Reset_Handler+0x12>
20022062:	4b0c      	ldr	r3, [pc, #48]	@ (20022094 <AES_IRQHandler+0x12>)
20022064:	4c0c      	ldr	r4, [pc, #48]	@ (20022098 <AES_IRQHandler+0x16>)
20022066:	42a3      	cmp	r3, r4
20022068:	da08      	bge.n	2002207c <Reset_Handler+0x44>
2002206a:	6819      	ldr	r1, [r3, #0]
2002206c:	685a      	ldr	r2, [r3, #4]
2002206e:	2000      	movs	r0, #0
20022070:	3a04      	subs	r2, #4
20022072:	bfa4      	itt	ge
20022074:	5088      	strge	r0, [r1, r2]
20022076:	e7fb      	bge.n	20022070 <Reset_Handler+0x38>
20022078:	3308      	adds	r3, #8
2002207a:	e7f4      	b.n	20022066 <Reset_Handler+0x2e>
2002207c:	f7ff fa3e 	bl	200214fc <entry>

20022080 <HardFault_Handler>:
20022080:	e7fe      	b.n	20022080 <HardFault_Handler>

20022082 <AES_IRQHandler>:
20022082:	e7fe      	b.n	20022082 <AES_IRQHandler>
20022084:	20042000 	.word	0x20042000
20022088:	20040000 	.word	0x20040000
2002208c:	2002c5c4 	.word	0x2002c5c4
20022090:	2002c5d0 	.word	0x2002c5d0
20022094:	2002c5d0 	.word	0x2002c5d0
20022098:	2002c5d8 	.word	0x2002c5d8

2002209c <__aeabi_unwind_cpp_pr0>:
2002209c:	2000      	movs	r0, #0
2002209e:	4770      	bx	lr

200220a0 <HAL_GetTick>:
200220a0:	4b01      	ldr	r3, [pc, #4]	@ (200220a8 <HAL_GetTick+0x8>)
200220a2:	6818      	ldr	r0, [r3, #0]
200220a4:	4770      	bx	lr
200220a6:	bf00      	nop
200220a8:	2004cbc0 	.word	0x2004cbc0

200220ac <HAL_Delay_us_>:
200220ac:	b538      	push	{r3, r4, r5, lr}
200220ae:	4604      	mov	r4, r0
200220b0:	4d16      	ldr	r5, [pc, #88]	@ (2002210c <HAL_Delay_us_+0x60>)
200220b2:	b128      	cbz	r0, 200220c0 <HAL_Delay_us_+0x14>
200220b4:	682b      	ldr	r3, [r5, #0]
200220b6:	b11b      	cbz	r3, 200220c0 <HAL_Delay_us_+0x14>
200220b8:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
200220bc:	d90a      	bls.n	200220d4 <HAL_Delay_us_+0x28>
200220be:	e7fe      	b.n	200220be <HAL_Delay_us_+0x12>
200220c0:	2000      	movs	r0, #0
200220c2:	f003 f841 	bl	20025148 <HAL_RCC_GetHCLKFreq>
200220c6:	4b12      	ldr	r3, [pc, #72]	@ (20022110 <HAL_Delay_us_+0x64>)
200220c8:	fbb0 f0f3 	udiv	r0, r0, r3
200220cc:	6028      	str	r0, [r5, #0]
200220ce:	2c00      	cmp	r4, #0
200220d0:	d1f2      	bne.n	200220b8 <HAL_Delay_us_+0xc>
200220d2:	bd38      	pop	{r3, r4, r5, pc}
200220d4:	4a0f      	ldr	r2, [pc, #60]	@ (20022114 <HAL_Delay_us_+0x68>)
200220d6:	6813      	ldr	r3, [r2, #0]
200220d8:	f013 0301 	ands.w	r3, r3, #1
200220dc:	d10d      	bne.n	200220fa <HAL_Delay_us_+0x4e>
200220de:	480e      	ldr	r0, [pc, #56]	@ (20022118 <HAL_Delay_us_+0x6c>)
200220e0:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
200220e4:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
200220e8:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
200220ec:	6053      	str	r3, [r2, #4]
200220ee:	6813      	ldr	r3, [r2, #0]
200220f0:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
200220f4:	f043 0301 	orr.w	r3, r3, #1
200220f8:	6013      	str	r3, [r2, #0]
200220fa:	682b      	ldr	r3, [r5, #0]
200220fc:	4a05      	ldr	r2, [pc, #20]	@ (20022114 <HAL_Delay_us_+0x68>)
200220fe:	435c      	muls	r4, r3
20022100:	6851      	ldr	r1, [r2, #4]
20022102:	6853      	ldr	r3, [r2, #4]
20022104:	1a5b      	subs	r3, r3, r1
20022106:	429c      	cmp	r4, r3
20022108:	d8fb      	bhi.n	20022102 <HAL_Delay_us_+0x56>
2002210a:	e7e2      	b.n	200220d2 <HAL_Delay_us_+0x26>
2002210c:	2004cbbc 	.word	0x2004cbbc
20022110:	000f4240 	.word	0x000f4240
20022114:	e0001000 	.word	0xe0001000
20022118:	e000ed00 	.word	0xe000ed00

2002211c <HAL_Delay_us2_>:
2002211c:	b537      	push	{r0, r1, r2, r4, r5, lr}
2002211e:	9001      	str	r0, [sp, #4]
20022120:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
20022124:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20022128:	6944      	ldr	r4, [r0, #20]
2002212a:	9b01      	ldr	r3, [sp, #4]
2002212c:	4363      	muls	r3, r4
2002212e:	fbb3 f3f2 	udiv	r3, r3, r2
20022132:	9301      	str	r3, [sp, #4]
20022134:	2300      	movs	r3, #0
20022136:	6981      	ldr	r1, [r0, #24]
20022138:	6982      	ldr	r2, [r0, #24]
2002213a:	428a      	cmp	r2, r1
2002213c:	d0fc      	beq.n	20022138 <HAL_Delay_us2_+0x1c>
2002213e:	bf25      	ittet	cs
20022140:	1aa5      	subcs	r5, r4, r2
20022142:	195b      	addcs	r3, r3, r5
20022144:	185b      	addcc	r3, r3, r1
20022146:	185b      	addcs	r3, r3, r1
20022148:	9901      	ldr	r1, [sp, #4]
2002214a:	bf38      	it	cc
2002214c:	1a9b      	subcc	r3, r3, r2
2002214e:	4299      	cmp	r1, r3
20022150:	d801      	bhi.n	20022156 <HAL_Delay_us2_+0x3a>
20022152:	b003      	add	sp, #12
20022154:	bd30      	pop	{r4, r5, pc}
20022156:	4611      	mov	r1, r2
20022158:	e7ee      	b.n	20022138 <HAL_Delay_us2_+0x1c>

2002215a <HAL_Delay_us>:
2002215a:	4603      	mov	r3, r0
2002215c:	b570      	push	{r4, r5, r6, lr}
2002215e:	b1b8      	cbz	r0, 20022190 <HAL_Delay_us+0x36>
20022160:	f242 7510 	movw	r5, #10000	@ 0x2710
20022164:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
20022168:	42ab      	cmp	r3, r5
2002216a:	bf84      	itt	hi
2002216c:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
20022170:	f242 7310 	movwhi	r3, #10000	@ 0x2710
20022174:	6932      	ldr	r2, [r6, #16]
20022176:	bf98      	it	ls
20022178:	2400      	movls	r4, #0
2002217a:	4618      	mov	r0, r3
2002217c:	bf88      	it	hi
2002217e:	3c10      	subhi	r4, #16
20022180:	07d3      	lsls	r3, r2, #31
20022182:	d508      	bpl.n	20022196 <HAL_Delay_us+0x3c>
20022184:	f7ff ffca 	bl	2002211c <HAL_Delay_us2_>
20022188:	4623      	mov	r3, r4
2002218a:	2c00      	cmp	r4, #0
2002218c:	d1ec      	bne.n	20022168 <HAL_Delay_us+0xe>
2002218e:	e001      	b.n	20022194 <HAL_Delay_us+0x3a>
20022190:	f7ff ff8c 	bl	200220ac <HAL_Delay_us_>
20022194:	bd70      	pop	{r4, r5, r6, pc}
20022196:	f7ff ff89 	bl	200220ac <HAL_Delay_us_>
2002219a:	e7f5      	b.n	20022188 <HAL_Delay_us+0x2e>

2002219c <WDT_IRQHandler>:
2002219c:	4770      	bx	lr

2002219e <DBG_Trigger_IRQHandler>:
2002219e:	4770      	bx	lr

200221a0 <NMI_Handler>:
200221a0:	b508      	push	{r3, lr}
200221a2:	4b05      	ldr	r3, [pc, #20]	@ (200221b8 <NMI_Handler+0x18>)
200221a4:	6a1b      	ldr	r3, [r3, #32]
200221a6:	005b      	lsls	r3, r3, #1
200221a8:	d502      	bpl.n	200221b0 <NMI_Handler+0x10>
200221aa:	f7ff fff8 	bl	2002219e <DBG_Trigger_IRQHandler>
200221ae:	bd08      	pop	{r3, pc}
200221b0:	f7ff fff4 	bl	2002219c <WDT_IRQHandler>
200221b4:	e7fb      	b.n	200221ae <NMI_Handler+0xe>
200221b6:	bf00      	nop
200221b8:	5000b000 	.word	0x5000b000

200221bc <HAL_AES_run_help>:
200221bc:	b510      	push	{r4, lr}
200221be:	f101 4470 	add.w	r4, r1, #4026531840	@ 0xf0000000
200221c2:	f1b4 5f80 	cmp.w	r4, #268435456	@ 0x10000000
200221c6:	4c0e      	ldr	r4, [pc, #56]	@ (20022200 <HAL_AES_run_help+0x44>)
200221c8:	bf38      	it	cc
200221ca:	f101 41a0 	addcc.w	r1, r1, #1342177280	@ 0x50000000
200221ce:	6161      	str	r1, [r4, #20]
200221d0:	f102 4170 	add.w	r1, r2, #4026531840	@ 0xf0000000
200221d4:	f1b1 5f80 	cmp.w	r1, #268435456	@ 0x10000000
200221d8:	f103 030f 	add.w	r3, r3, #15
200221dc:	ea4f 1323 	mov.w	r3, r3, asr #4
200221e0:	bf38      	it	cc
200221e2:	f102 42a0 	addcc.w	r2, r2, #1342177280	@ 0x50000000
200221e6:	61a2      	str	r2, [r4, #24]
200221e8:	61e3      	str	r3, [r4, #28]
200221ea:	6923      	ldr	r3, [r4, #16]
200221ec:	b108      	cbz	r0, 200221f2 <HAL_AES_run_help+0x36>
200221ee:	ea43 13c0 	orr.w	r3, r3, r0, lsl #7
200221f2:	4a03      	ldr	r2, [pc, #12]	@ (20022200 <HAL_AES_run_help+0x44>)
200221f4:	6123      	str	r3, [r4, #16]
200221f6:	6813      	ldr	r3, [r2, #0]
200221f8:	f043 0301 	orr.w	r3, r3, #1
200221fc:	6013      	str	r3, [r2, #0]
200221fe:	bd10      	pop	{r4, pc}
20022200:	5000d000 	.word	0x5000d000

20022204 <HAL_HASH_run_help.isra.0>:
20022204:	f100 4370 	add.w	r3, r0, #4026531840	@ 0xf0000000
20022208:	b510      	push	{r4, lr}
2002220a:	f1b3 5f80 	cmp.w	r3, #268435456	@ 0x10000000
2002220e:	4c09      	ldr	r4, [pc, #36]	@ (20022234 <HAL_HASH_run_help.isra.0+0x30>)
20022210:	bf38      	it	cc
20022212:	f100 40a0 	addcc.w	r0, r0, #1342177280	@ 0x50000000
20022216:	6560      	str	r0, [r4, #84]	@ 0x54
20022218:	65a1      	str	r1, [r4, #88]	@ 0x58
2002221a:	b11a      	cbz	r2, 20022224 <HAL_HASH_run_help.isra.0+0x20>
2002221c:	6d23      	ldr	r3, [r4, #80]	@ 0x50
2002221e:	f043 0308 	orr.w	r3, r3, #8
20022222:	6523      	str	r3, [r4, #80]	@ 0x50
20022224:	6d21      	ldr	r1, [r4, #80]	@ 0x50
20022226:	4804      	ldr	r0, [pc, #16]	@ (20022238 <HAL_HASH_run_help.isra.0+0x34>)
20022228:	f000 fcda 	bl	20022be0 <HAL_DBG_printf>
2002222c:	2304      	movs	r3, #4
2002222e:	6023      	str	r3, [r4, #0]
20022230:	bd10      	pop	{r4, pc}
20022232:	bf00      	nop
20022234:	5000d000 	.word	0x5000d000
20022238:	2002ab8e 	.word	0x2002ab8e

2002223c <HAL_AES_reset>:
2002223c:	2202      	movs	r2, #2
2002223e:	2000      	movs	r0, #0
20022240:	4b01      	ldr	r3, [pc, #4]	@ (20022248 <HAL_AES_reset+0xc>)
20022242:	601a      	str	r2, [r3, #0]
20022244:	6018      	str	r0, [r3, #0]
20022246:	4770      	bx	lr
20022248:	5000d000 	.word	0x5000d000

2002224c <HAL_AES_init>:
2002224c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002224e:	4604      	mov	r4, r0
20022250:	200c      	movs	r0, #12
20022252:	461e      	mov	r6, r3
20022254:	460d      	mov	r5, r1
20022256:	4617      	mov	r7, r2
20022258:	f003 f8f4 	bl	20025444 <HAL_RCC_EnableModule>
2002225c:	4b1c      	ldr	r3, [pc, #112]	@ (200222d0 <HAL_AES_init+0x84>)
2002225e:	685b      	ldr	r3, [r3, #4]
20022260:	07db      	lsls	r3, r3, #31
20022262:	d501      	bpl.n	20022268 <HAL_AES_init+0x1c>
20022264:	f7ff ffea 	bl	2002223c <HAL_AES_reset>
20022268:	fab4 f184 	clz	r1, r4
2002226c:	2d18      	cmp	r5, #24
2002226e:	ea4f 1151 	mov.w	r1, r1, lsr #5
20022272:	ea4f 1141 	mov.w	r1, r1, lsl #5
20022276:	d01b      	beq.n	200222b0 <HAL_AES_init+0x64>
20022278:	2d20      	cmp	r5, #32
2002227a:	d01b      	beq.n	200222b4 <HAL_AES_init+0x68>
2002227c:	2d10      	cmp	r5, #16
2002227e:	d124      	bne.n	200222ca <HAL_AES_init+0x7e>
20022280:	2300      	movs	r3, #0
20022282:	b164      	cbz	r4, 2002229e <HAL_AES_init+0x52>
20022284:	4620      	mov	r0, r4
20022286:	4a13      	ldr	r2, [pc, #76]	@ (200222d4 <HAL_AES_init+0x88>)
20022288:	f025 0503 	bic.w	r5, r5, #3
2002228c:	4425      	add	r5, r4
2002228e:	1b12      	subs	r2, r2, r4
20022290:	1814      	adds	r4, r2, r0
20022292:	f850 cb04 	ldr.w	ip, [r0], #4
20022296:	4285      	cmp	r5, r0
20022298:	f8c4 c000 	str.w	ip, [r4]
2002229c:	d1f8      	bne.n	20022290 <HAL_AES_init+0x44>
2002229e:	4331      	orrs	r1, r6
200222a0:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
200222a4:	4b0a      	ldr	r3, [pc, #40]	@ (200222d0 <HAL_AES_init+0x84>)
200222a6:	6119      	str	r1, [r3, #16]
200222a8:	b106      	cbz	r6, 200222ac <HAL_AES_init+0x60>
200222aa:	b92f      	cbnz	r7, 200222b8 <HAL_AES_init+0x6c>
200222ac:	2000      	movs	r0, #0
200222ae:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200222b0:	2301      	movs	r3, #1
200222b2:	e7e6      	b.n	20022282 <HAL_AES_init+0x36>
200222b4:	2302      	movs	r3, #2
200222b6:	e7e4      	b.n	20022282 <HAL_AES_init+0x36>
200222b8:	683a      	ldr	r2, [r7, #0]
200222ba:	621a      	str	r2, [r3, #32]
200222bc:	687a      	ldr	r2, [r7, #4]
200222be:	625a      	str	r2, [r3, #36]	@ 0x24
200222c0:	68ba      	ldr	r2, [r7, #8]
200222c2:	629a      	str	r2, [r3, #40]	@ 0x28
200222c4:	68fa      	ldr	r2, [r7, #12]
200222c6:	62da      	str	r2, [r3, #44]	@ 0x2c
200222c8:	e7f0      	b.n	200222ac <HAL_AES_init+0x60>
200222ca:	f04f 30ff 	mov.w	r0, #4294967295
200222ce:	e7ee      	b.n	200222ae <HAL_AES_init+0x62>
200222d0:	5000d000 	.word	0x5000d000
200222d4:	5000d030 	.word	0x5000d030

200222d8 <HAL_AES_run>:
200222d8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200222da:	2708      	movs	r7, #8
200222dc:	4e17      	ldr	r6, [pc, #92]	@ (2002233c <HAL_AES_run+0x64>)
200222de:	4614      	mov	r4, r2
200222e0:	461d      	mov	r5, r3
200222e2:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
200222e6:	f3bf 8f4f 	dsb	sy
200222ea:	f3bf 8f6f 	isb	sy
200222ee:	2700      	movs	r7, #0
200222f0:	4e13      	ldr	r6, [pc, #76]	@ (20022340 <HAL_AES_run+0x68>)
200222f2:	60f7      	str	r7, [r6, #12]
200222f4:	f7ff ff62 	bl	200221bc <HAL_AES_run_help>
200222f8:	6873      	ldr	r3, [r6, #4]
200222fa:	07db      	lsls	r3, r3, #31
200222fc:	d4fc      	bmi.n	200222f8 <HAL_AES_run+0x20>
200222fe:	68b0      	ldr	r0, [r6, #8]
20022300:	f000 0006 	and.w	r0, r0, #6
20022304:	3800      	subs	r0, #0
20022306:	bf18      	it	ne
20022308:	2001      	movne	r0, #1
2002230a:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
2002230e:	d314      	bcc.n	2002233a <HAL_AES_run+0x62>
20022310:	2d00      	cmp	r5, #0
20022312:	dd12      	ble.n	2002233a <HAL_AES_run+0x62>
20022314:	f004 031f 	and.w	r3, r4, #31
20022318:	442b      	add	r3, r5
2002231a:	f024 021f 	bic.w	r2, r4, #31
2002231e:	f3bf 8f4f 	dsb	sy
20022322:	4c08      	ldr	r4, [pc, #32]	@ (20022344 <HAL_AES_run+0x6c>)
20022324:	4413      	add	r3, r2
20022326:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
2002232a:	3220      	adds	r2, #32
2002232c:	1a99      	subs	r1, r3, r2
2002232e:	2900      	cmp	r1, #0
20022330:	dcf9      	bgt.n	20022326 <HAL_AES_run+0x4e>
20022332:	f3bf 8f4f 	dsb	sy
20022336:	f3bf 8f6f 	isb	sy
2002233a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002233c:	e000e100 	.word	0xe000e100
20022340:	5000d000 	.word	0x5000d000
20022344:	e000ed00 	.word	0xe000ed00

20022348 <HAL_HASH_run>:
20022348:	b510      	push	{r4, lr}
2002234a:	2408      	movs	r4, #8
2002234c:	4b0b      	ldr	r3, [pc, #44]	@ (2002237c <HAL_HASH_run+0x34>)
2002234e:	f8c3 4088 	str.w	r4, [r3, #136]	@ 0x88
20022352:	f3bf 8f4f 	dsb	sy
20022356:	f3bf 8f6f 	isb	sy
2002235a:	f7ff ff53 	bl	20022204 <HAL_HASH_run_help.isra.0>
2002235e:	4b08      	ldr	r3, [pc, #32]	@ (20022380 <HAL_HASH_run+0x38>)
20022360:	685a      	ldr	r2, [r3, #4]
20022362:	0752      	lsls	r2, r2, #29
20022364:	d4fc      	bmi.n	20022360 <HAL_HASH_run+0x18>
20022366:	689a      	ldr	r2, [r3, #8]
20022368:	f002 0238 	and.w	r2, r2, #56	@ 0x38
2002236c:	609a      	str	r2, [r3, #8]
2002236e:	6898      	ldr	r0, [r3, #8]
20022370:	f000 0030 	and.w	r0, r0, #48	@ 0x30
20022374:	3800      	subs	r0, #0
20022376:	bf18      	it	ne
20022378:	2001      	movne	r0, #1
2002237a:	bd10      	pop	{r4, pc}
2002237c:	e000e100 	.word	0xe000e100
20022380:	5000d000 	.word	0x5000d000

20022384 <HAL_HASH_reset>:
20022384:	2208      	movs	r2, #8
20022386:	2000      	movs	r0, #0
20022388:	4b01      	ldr	r3, [pc, #4]	@ (20022390 <HAL_HASH_reset+0xc>)
2002238a:	601a      	str	r2, [r3, #0]
2002238c:	6018      	str	r0, [r3, #0]
2002238e:	4770      	bx	lr
20022390:	5000d000 	.word	0x5000d000

20022394 <HAL_HASH_init>:
20022394:	0693      	lsls	r3, r2, #26
20022396:	b570      	push	{r4, r5, r6, lr}
20022398:	4606      	mov	r6, r0
2002239a:	460c      	mov	r4, r1
2002239c:	4615      	mov	r5, r2
2002239e:	d11c      	bne.n	200223da <HAL_HASH_init+0x46>
200223a0:	2903      	cmp	r1, #3
200223a2:	d81a      	bhi.n	200223da <HAL_HASH_init+0x46>
200223a4:	f7ff ffee 	bl	20022384 <HAL_HASH_reset>
200223a8:	b13e      	cbz	r6, 200223ba <HAL_HASH_init+0x26>
200223aa:	4b0d      	ldr	r3, [pc, #52]	@ (200223e0 <HAL_HASH_init+0x4c>)
200223ac:	480d      	ldr	r0, [pc, #52]	@ (200223e4 <HAL_HASH_init+0x50>)
200223ae:	5c5a      	ldrb	r2, [r3, r1]
200223b0:	4631      	mov	r1, r6
200223b2:	f008 fb4d 	bl	2002aa50 <memcpy>
200223b6:	f044 0420 	orr.w	r4, r4, #32
200223ba:	4b0b      	ldr	r3, [pc, #44]	@ (200223e8 <HAL_HASH_init+0x54>)
200223bc:	f044 0180 	orr.w	r1, r4, #128	@ 0x80
200223c0:	6519      	str	r1, [r3, #80]	@ 0x50
200223c2:	b11d      	cbz	r5, 200223cc <HAL_HASH_init+0x38>
200223c4:	f8c3 509c 	str.w	r5, [r3, #156]	@ 0x9c
200223c8:	f444 71c0 	orr.w	r1, r4, #384	@ 0x180
200223cc:	4807      	ldr	r0, [pc, #28]	@ (200223ec <HAL_HASH_init+0x58>)
200223ce:	462a      	mov	r2, r5
200223d0:	6519      	str	r1, [r3, #80]	@ 0x50
200223d2:	f000 fc05 	bl	20022be0 <HAL_DBG_printf>
200223d6:	2000      	movs	r0, #0
200223d8:	bd70      	pop	{r4, r5, r6, pc}
200223da:	f04f 30ff 	mov.w	r0, #4294967295
200223de:	e7fb      	b.n	200223d8 <HAL_HASH_init+0x44>
200223e0:	2002ba24 	.word	0x2002ba24
200223e4:	5000d05c 	.word	0x5000d05c
200223e8:	5000d000 	.word	0x5000d000
200223ec:	2002aba1 	.word	0x2002aba1

200223f0 <HAL_HASH_result>:
200223f0:	b510      	push	{r4, lr}
200223f2:	4c08      	ldr	r4, [pc, #32]	@ (20022414 <HAL_HASH_result+0x24>)
200223f4:	4a08      	ldr	r2, [pc, #32]	@ (20022418 <HAL_HASH_result+0x28>)
200223f6:	6d23      	ldr	r3, [r4, #80]	@ 0x50
200223f8:	f104 017c 	add.w	r1, r4, #124	@ 0x7c
200223fc:	f003 0307 	and.w	r3, r3, #7
20022400:	5cd2      	ldrb	r2, [r2, r3]
20022402:	f008 fb25 	bl	2002aa50 <memcpy>
20022406:	f8d4 10a4 	ldr.w	r1, [r4, #164]	@ 0xa4
2002240a:	4804      	ldr	r0, [pc, #16]	@ (2002241c <HAL_HASH_result+0x2c>)
2002240c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20022410:	f000 bbe6 	b.w	20022be0 <HAL_DBG_printf>
20022414:	5000d000 	.word	0x5000d000
20022418:	2002ba24 	.word	0x2002ba24
2002241c:	2002abd5 	.word	0x2002abd5

20022420 <HAL_NVIC_EnableIRQ>:
20022420:	2800      	cmp	r0, #0
20022422:	da00      	bge.n	20022426 <HAL_NVIC_EnableIRQ+0x6>
20022424:	e7fe      	b.n	20022424 <HAL_NVIC_EnableIRQ+0x4>
20022426:	2301      	movs	r3, #1
20022428:	0941      	lsrs	r1, r0, #5
2002242a:	4a03      	ldr	r2, [pc, #12]	@ (20022438 <HAL_NVIC_EnableIRQ+0x18>)
2002242c:	f000 001f 	and.w	r0, r0, #31
20022430:	4083      	lsls	r3, r0
20022432:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20022436:	4770      	bx	lr
20022438:	e000e100 	.word	0xe000e100

2002243c <HAL_NVIC_DisableIRQ>:
2002243c:	2800      	cmp	r0, #0
2002243e:	da00      	bge.n	20022442 <HAL_NVIC_DisableIRQ+0x6>
20022440:	e7fe      	b.n	20022440 <HAL_NVIC_DisableIRQ+0x4>
20022442:	2201      	movs	r2, #1
20022444:	4906      	ldr	r1, [pc, #24]	@ (20022460 <HAL_NVIC_DisableIRQ+0x24>)
20022446:	0943      	lsrs	r3, r0, #5
20022448:	f000 001f 	and.w	r0, r0, #31
2002244c:	4082      	lsls	r2, r0
2002244e:	3320      	adds	r3, #32
20022450:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20022454:	f3bf 8f4f 	dsb	sy
20022458:	f3bf 8f6f 	isb	sy
2002245c:	4770      	bx	lr
2002245e:	bf00      	nop
20022460:	e000e100 	.word	0xe000e100

20022464 <DMA_Init>:
20022464:	2302      	movs	r3, #2
20022466:	b530      	push	{r4, r5, lr}
20022468:	6a42      	ldr	r2, [r0, #36]	@ 0x24
2002246a:	f880 302d 	strb.w	r3, [r0, #45]	@ 0x2d
2002246e:	6803      	ldr	r3, [r0, #0]
20022470:	611a      	str	r2, [r3, #16]
20022472:	e9d0 3402 	ldrd	r3, r4, [r0, #8]
20022476:	4323      	orrs	r3, r4
20022478:	6904      	ldr	r4, [r0, #16]
2002247a:	6801      	ldr	r1, [r0, #0]
2002247c:	4323      	orrs	r3, r4
2002247e:	6944      	ldr	r4, [r0, #20]
20022480:	680a      	ldr	r2, [r1, #0]
20022482:	4323      	orrs	r3, r4
20022484:	6984      	ldr	r4, [r0, #24]
20022486:	f36f 120e 	bfc	r2, #4, #11
2002248a:	4323      	orrs	r3, r4
2002248c:	69c4      	ldr	r4, [r0, #28]
2002248e:	4323      	orrs	r3, r4
20022490:	6a04      	ldr	r4, [r0, #32]
20022492:	4323      	orrs	r3, r4
20022494:	4313      	orrs	r3, r2
20022496:	600b      	str	r3, [r1, #0]
20022498:	6883      	ldr	r3, [r0, #8]
2002249a:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
2002249e:	d01f      	beq.n	200224e0 <DMA_Init+0x7c>
200224a0:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
200224a2:	f3c3 0387 	ubfx	r3, r3, #2, #8
200224a6:	f3ef 8110 	mrs	r1, PRIMASK
200224aa:	2201      	movs	r2, #1
200224ac:	f382 8810 	msr	PRIMASK, r2
200224b0:	075c      	lsls	r4, r3, #29
200224b2:	6c82      	ldr	r2, [r0, #72]	@ 0x48
200224b4:	d41d      	bmi.n	200224f2 <DMA_Init+0x8e>
200224b6:	253f      	movs	r5, #63	@ 0x3f
200224b8:	f003 0307 	and.w	r3, r3, #7
200224bc:	f8d2 40a8 	ldr.w	r4, [r2, #168]	@ 0xa8
200224c0:	00db      	lsls	r3, r3, #3
200224c2:	409d      	lsls	r5, r3
200224c4:	ea24 0405 	bic.w	r4, r4, r5
200224c8:	f8c2 40a8 	str.w	r4, [r2, #168]	@ 0xa8
200224cc:	6c84      	ldr	r4, [r0, #72]	@ 0x48
200224ce:	6842      	ldr	r2, [r0, #4]
200224d0:	f8d4 50a8 	ldr.w	r5, [r4, #168]	@ 0xa8
200224d4:	409a      	lsls	r2, r3
200224d6:	432a      	orrs	r2, r5
200224d8:	f8c4 20a8 	str.w	r2, [r4, #168]	@ 0xa8
200224dc:	f381 8810 	msr	PRIMASK, r1
200224e0:	6982      	ldr	r2, [r0, #24]
200224e2:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
200224e6:	d018      	beq.n	2002251a <DMA_Init+0xb6>
200224e8:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
200224ec:	d01f      	beq.n	2002252e <DMA_Init+0xca>
200224ee:	b1aa      	cbz	r2, 2002251c <DMA_Init+0xb8>
200224f0:	e7fe      	b.n	200224f0 <DMA_Init+0x8c>
200224f2:	253f      	movs	r5, #63	@ 0x3f
200224f4:	f003 0303 	and.w	r3, r3, #3
200224f8:	f8d2 40ac 	ldr.w	r4, [r2, #172]	@ 0xac
200224fc:	00db      	lsls	r3, r3, #3
200224fe:	409d      	lsls	r5, r3
20022500:	ea24 0405 	bic.w	r4, r4, r5
20022504:	f8c2 40ac 	str.w	r4, [r2, #172]	@ 0xac
20022508:	6c84      	ldr	r4, [r0, #72]	@ 0x48
2002250a:	6842      	ldr	r2, [r0, #4]
2002250c:	f8d4 50ac 	ldr.w	r5, [r4, #172]	@ 0xac
20022510:	409a      	lsls	r2, r3
20022512:	432a      	orrs	r2, r5
20022514:	f8c4 20ac 	str.w	r2, [r4, #172]	@ 0xac
20022518:	e7e0      	b.n	200224dc <DMA_Init+0x78>
2002251a:	2201      	movs	r2, #1
2002251c:	6943      	ldr	r3, [r0, #20]
2002251e:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20022522:	d006      	beq.n	20022532 <DMA_Init+0xce>
20022524:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20022528:	d02b      	beq.n	20022582 <DMA_Init+0x11e>
2002252a:	b11b      	cbz	r3, 20022534 <DMA_Init+0xd0>
2002252c:	e7fe      	b.n	2002252c <DMA_Init+0xc8>
2002252e:	2202      	movs	r2, #2
20022530:	e7f4      	b.n	2002251c <DMA_Init+0xb8>
20022532:	2301      	movs	r3, #1
20022534:	6901      	ldr	r1, [r0, #16]
20022536:	f1a1 0480 	sub.w	r4, r1, #128	@ 0x80
2002253a:	4261      	negs	r1, r4
2002253c:	4161      	adcs	r1, r4
2002253e:	68c4      	ldr	r4, [r0, #12]
20022540:	f1a4 0540 	sub.w	r5, r4, #64	@ 0x40
20022544:	426c      	negs	r4, r5
20022546:	416c      	adcs	r4, r5
20022548:	6885      	ldr	r5, [r0, #8]
2002254a:	2d10      	cmp	r5, #16
2002254c:	bf1f      	itttt	ne
2002254e:	f880 1065 	strbne.w	r1, [r0, #101]	@ 0x65
20022552:	4619      	movne	r1, r3
20022554:	4613      	movne	r3, r2
20022556:	460a      	movne	r2, r1
20022558:	f880 3067 	strb.w	r3, [r0, #103]	@ 0x67
2002255c:	f880 2066 	strb.w	r2, [r0, #102]	@ 0x66
20022560:	f04f 0300 	mov.w	r3, #0
20022564:	f04f 0201 	mov.w	r2, #1
20022568:	6443      	str	r3, [r0, #68]	@ 0x44
2002256a:	bf06      	itte	eq
2002256c:	f880 4065 	strbeq.w	r4, [r0, #101]	@ 0x65
20022570:	f880 1064 	strbeq.w	r1, [r0, #100]	@ 0x64
20022574:	f880 4064 	strbne.w	r4, [r0, #100]	@ 0x64
20022578:	f880 202d 	strb.w	r2, [r0, #45]	@ 0x2d
2002257c:	f880 302c 	strb.w	r3, [r0, #44]	@ 0x2c
20022580:	bd30      	pop	{r4, r5, pc}
20022582:	2302      	movs	r3, #2
20022584:	e7d6      	b.n	20022534 <DMA_Init+0xd0>
	...

20022588 <DMA_IsChannelOwner>:
20022588:	b510      	push	{r4, lr}
2002258a:	4911      	ldr	r1, [pc, #68]	@ (200225d0 <DMA_IsChannelOwner+0x48>)
2002258c:	6c83      	ldr	r3, [r0, #72]	@ 0x48
2002258e:	4602      	mov	r2, r0
20022590:	428b      	cmp	r3, r1
20022592:	d003      	beq.n	2002259c <DMA_IsChannelOwner+0x14>
20022594:	490f      	ldr	r1, [pc, #60]	@ (200225d4 <DMA_IsChannelOwner+0x4c>)
20022596:	428b      	cmp	r3, r1
20022598:	d007      	beq.n	200225aa <DMA_IsChannelOwner+0x22>
2002259a:	e7fe      	b.n	2002259a <DMA_IsChannelOwner+0x12>
2002259c:	4b0e      	ldr	r3, [pc, #56]	@ (200225d8 <DMA_IsChannelOwner+0x50>)
2002259e:	6cd0      	ldr	r0, [r2, #76]	@ 0x4c
200225a0:	281f      	cmp	r0, #31
200225a2:	ea4f 0190 	mov.w	r1, r0, lsr #2
200225a6:	d902      	bls.n	200225ae <DMA_IsChannelOwner+0x26>
200225a8:	e7fe      	b.n	200225a8 <DMA_IsChannelOwner+0x20>
200225aa:	4b0c      	ldr	r3, [pc, #48]	@ (200225dc <DMA_IsChannelOwner+0x54>)
200225ac:	e7f7      	b.n	2002259e <DMA_IsChannelOwner+0x16>
200225ae:	f3ef 8410 	mrs	r4, PRIMASK
200225b2:	2001      	movs	r0, #1
200225b4:	f380 8810 	msr	PRIMASK, r0
200225b8:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
200225bc:	7900      	ldrb	r0, [r0, #4]
200225be:	b120      	cbz	r0, 200225ca <DMA_IsChannelOwner+0x42>
200225c0:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
200225c4:	1a83      	subs	r3, r0, r2
200225c6:	4258      	negs	r0, r3
200225c8:	4158      	adcs	r0, r3
200225ca:	f384 8810 	msr	PRIMASK, r4
200225ce:	bd10      	pop	{r4, pc}
200225d0:	50081000 	.word	0x50081000
200225d4:	40001000 	.word	0x40001000
200225d8:	2004cc04 	.word	0x2004cc04
200225dc:	2004cbc4 	.word	0x2004cbc4

200225e0 <DMA_AllocChannel>:
200225e0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200225e2:	4b2e      	ldr	r3, [pc, #184]	@ (2002269c <DMA_AllocChannel+0xbc>)
200225e4:	6802      	ldr	r2, [r0, #0]
200225e6:	4413      	add	r3, r2
200225e8:	2ba0      	cmp	r3, #160	@ 0xa0
200225ea:	d904      	bls.n	200225f6 <DMA_AllocChannel+0x16>
200225ec:	4b2c      	ldr	r3, [pc, #176]	@ (200226a0 <DMA_AllocChannel+0xc0>)
200225ee:	4413      	add	r3, r2
200225f0:	2ba0      	cmp	r3, #160	@ 0xa0
200225f2:	d90f      	bls.n	20022614 <DMA_AllocChannel+0x34>
200225f4:	e7fe      	b.n	200225f4 <DMA_AllocChannel+0x14>
200225f6:	2632      	movs	r6, #50	@ 0x32
200225f8:	f8df c0b0 	ldr.w	ip, [pc, #176]	@ 200226ac <DMA_AllocChannel+0xcc>
200225fc:	4b29      	ldr	r3, [pc, #164]	@ (200226a4 <DMA_AllocChannel+0xc4>)
200225fe:	f3ef 8710 	mrs	r7, PRIMASK
20022602:	2201      	movs	r2, #1
20022604:	f382 8810 	msr	PRIMASK, r2
20022608:	6cc5      	ldr	r5, [r0, #76]	@ 0x4c
2002260a:	2d1f      	cmp	r5, #31
2002260c:	ea4f 0495 	mov.w	r4, r5, lsr #2
20022610:	d905      	bls.n	2002261e <DMA_AllocChannel+0x3e>
20022612:	e7fe      	b.n	20022612 <DMA_AllocChannel+0x32>
20022614:	2602      	movs	r6, #2
20022616:	f8df c098 	ldr.w	ip, [pc, #152]	@ 200226b0 <DMA_AllocChannel+0xd0>
2002261a:	4b23      	ldr	r3, [pc, #140]	@ (200226a8 <DMA_AllocChannel+0xc8>)
2002261c:	e7ef      	b.n	200225fe <DMA_AllocChannel+0x1e>
2002261e:	eb03 05c4 	add.w	r5, r3, r4, lsl #3
20022622:	f895 e004 	ldrb.w	lr, [r5, #4]
20022626:	f1be 0f00 	cmp.w	lr, #0
2002262a:	d032      	beq.n	20022692 <DMA_AllocChannel+0xb2>
2002262c:	f853 2034 	ldr.w	r2, [r3, r4, lsl #3]
20022630:	4282      	cmp	r2, r0
20022632:	d103      	bne.n	2002263c <DMA_AllocChannel+0x5c>
20022634:	f387 8810 	msr	PRIMASK, r7
20022638:	2002      	movs	r0, #2
2002263a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002263c:	2200      	movs	r2, #0
2002263e:	791c      	ldrb	r4, [r3, #4]
20022640:	461d      	mov	r5, r3
20022642:	bb04      	cbnz	r4, 20022686 <DMA_AllocChannel+0xa6>
20022644:	2301      	movs	r3, #1
20022646:	712b      	strb	r3, [r5, #4]
20022648:	2314      	movs	r3, #20
2002264a:	fb03 c302 	mla	r3, r3, r2, ip
2002264e:	4416      	add	r6, r2
20022650:	0092      	lsls	r2, r2, #2
20022652:	b274      	sxtb	r4, r6
20022654:	6003      	str	r3, [r0, #0]
20022656:	64c2      	str	r2, [r0, #76]	@ 0x4c
20022658:	f387 8810 	msr	PRIMASK, r7
2002265c:	b121      	cbz	r1, 20022668 <DMA_AllocChannel+0x88>
2002265e:	682b      	ldr	r3, [r5, #0]
20022660:	4283      	cmp	r3, r0
20022662:	d001      	beq.n	20022668 <DMA_AllocChannel+0x88>
20022664:	f7ff fefe 	bl	20022464 <DMA_Init>
20022668:	6028      	str	r0, [r5, #0]
2002266a:	6a83      	ldr	r3, [r0, #40]	@ 0x28
2002266c:	f104 4260 	add.w	r2, r4, #3758096384	@ 0xe0000000
20022670:	015b      	lsls	r3, r3, #5
20022672:	b2db      	uxtb	r3, r3
20022674:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20022678:	4620      	mov	r0, r4
2002267a:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
2002267e:	f7ff fecf 	bl	20022420 <HAL_NVIC_EnableIRQ>
20022682:	2000      	movs	r0, #0
20022684:	e7d9      	b.n	2002263a <DMA_AllocChannel+0x5a>
20022686:	3201      	adds	r2, #1
20022688:	2a08      	cmp	r2, #8
2002268a:	f103 0308 	add.w	r3, r3, #8
2002268e:	d1d6      	bne.n	2002263e <DMA_AllocChannel+0x5e>
20022690:	e7d0      	b.n	20022634 <DMA_AllocChannel+0x54>
20022692:	4434      	add	r4, r6
20022694:	712a      	strb	r2, [r5, #4]
20022696:	b264      	sxtb	r4, r4
20022698:	e7de      	b.n	20022658 <DMA_AllocChannel+0x78>
2002269a:	bf00      	nop
2002269c:	aff7eff8 	.word	0xaff7eff8
200226a0:	bfffeff8 	.word	0xbfffeff8
200226a4:	2004cc04 	.word	0x2004cc04
200226a8:	2004cbc4 	.word	0x2004cbc4
200226ac:	50081008 	.word	0x50081008
200226b0:	40001008 	.word	0x40001008

200226b4 <DMA_FreeChannel.isra.0>:
200226b4:	b538      	push	{r3, r4, r5, lr}
200226b6:	4a13      	ldr	r2, [pc, #76]	@ (20022704 <DMA_FreeChannel.isra.0+0x50>)
200226b8:	6c83      	ldr	r3, [r0, #72]	@ 0x48
200226ba:	4293      	cmp	r3, r2
200226bc:	d003      	beq.n	200226c6 <DMA_FreeChannel.isra.0+0x12>
200226be:	4a12      	ldr	r2, [pc, #72]	@ (20022708 <DMA_FreeChannel.isra.0+0x54>)
200226c0:	4293      	cmp	r3, r2
200226c2:	d008      	beq.n	200226d6 <DMA_FreeChannel.isra.0+0x22>
200226c4:	e7fe      	b.n	200226c4 <DMA_FreeChannel.isra.0+0x10>
200226c6:	2132      	movs	r1, #50	@ 0x32
200226c8:	4a10      	ldr	r2, [pc, #64]	@ (2002270c <DMA_FreeChannel.isra.0+0x58>)
200226ca:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
200226cc:	2c1f      	cmp	r4, #31
200226ce:	ea4f 0394 	mov.w	r3, r4, lsr #2
200226d2:	d903      	bls.n	200226dc <DMA_FreeChannel.isra.0+0x28>
200226d4:	e7fe      	b.n	200226d4 <DMA_FreeChannel.isra.0+0x20>
200226d6:	2102      	movs	r1, #2
200226d8:	4a0d      	ldr	r2, [pc, #52]	@ (20022710 <DMA_FreeChannel.isra.0+0x5c>)
200226da:	e7f6      	b.n	200226ca <DMA_FreeChannel.isra.0+0x16>
200226dc:	f3ef 8410 	mrs	r4, PRIMASK
200226e0:	2501      	movs	r5, #1
200226e2:	f385 8810 	msr	PRIMASK, r5
200226e6:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
200226ea:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
200226ee:	4290      	cmp	r0, r2
200226f0:	d105      	bne.n	200226fe <DMA_FreeChannel.isra.0+0x4a>
200226f2:	1858      	adds	r0, r3, r1
200226f4:	b240      	sxtb	r0, r0
200226f6:	f7ff fea1 	bl	2002243c <HAL_NVIC_DisableIRQ>
200226fa:	2300      	movs	r3, #0
200226fc:	712b      	strb	r3, [r5, #4]
200226fe:	f384 8810 	msr	PRIMASK, r4
20022702:	bd38      	pop	{r3, r4, r5, pc}
20022704:	50081000 	.word	0x50081000
20022708:	40001000 	.word	0x40001000
2002270c:	2004cc04 	.word	0x2004cc04
20022710:	2004cbc4 	.word	0x2004cbc4

20022714 <HAL_DMA_Init>:
20022714:	b538      	push	{r3, r4, r5, lr}
20022716:	4604      	mov	r4, r0
20022718:	2800      	cmp	r0, #0
2002271a:	d052      	beq.n	200227c2 <HAL_DMA_Init+0xae>
2002271c:	6883      	ldr	r3, [r0, #8]
2002271e:	f033 0210 	bics.w	r2, r3, #16
20022722:	d003      	beq.n	2002272c <HAL_DMA_Init+0x18>
20022724:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20022728:	d000      	beq.n	2002272c <HAL_DMA_Init+0x18>
2002272a:	e7fe      	b.n	2002272a <HAL_DMA_Init+0x16>
2002272c:	68e3      	ldr	r3, [r4, #12]
2002272e:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20022732:	d000      	beq.n	20022736 <HAL_DMA_Init+0x22>
20022734:	e7fe      	b.n	20022734 <HAL_DMA_Init+0x20>
20022736:	6923      	ldr	r3, [r4, #16]
20022738:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
2002273c:	d000      	beq.n	20022740 <HAL_DMA_Init+0x2c>
2002273e:	e7fe      	b.n	2002273e <HAL_DMA_Init+0x2a>
20022740:	6963      	ldr	r3, [r4, #20]
20022742:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20022746:	d003      	beq.n	20022750 <HAL_DMA_Init+0x3c>
20022748:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
2002274c:	d000      	beq.n	20022750 <HAL_DMA_Init+0x3c>
2002274e:	e7fe      	b.n	2002274e <HAL_DMA_Init+0x3a>
20022750:	69a3      	ldr	r3, [r4, #24]
20022752:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20022756:	d003      	beq.n	20022760 <HAL_DMA_Init+0x4c>
20022758:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
2002275c:	d000      	beq.n	20022760 <HAL_DMA_Init+0x4c>
2002275e:	e7fe      	b.n	2002275e <HAL_DMA_Init+0x4a>
20022760:	69e3      	ldr	r3, [r4, #28]
20022762:	f033 0320 	bics.w	r3, r3, #32
20022766:	d000      	beq.n	2002276a <HAL_DMA_Init+0x56>
20022768:	e7fe      	b.n	20022768 <HAL_DMA_Init+0x54>
2002276a:	6a23      	ldr	r3, [r4, #32]
2002276c:	f433 5340 	bics.w	r3, r3, #12288	@ 0x3000
20022770:	d000      	beq.n	20022774 <HAL_DMA_Init+0x60>
20022772:	e7fe      	b.n	20022772 <HAL_DMA_Init+0x5e>
20022774:	6863      	ldr	r3, [r4, #4]
20022776:	2b51      	cmp	r3, #81	@ 0x51
20022778:	d900      	bls.n	2002277c <HAL_DMA_Init+0x68>
2002277a:	e7fe      	b.n	2002277a <HAL_DMA_Init+0x66>
2002277c:	6822      	ldr	r2, [r4, #0]
2002277e:	4b13      	ldr	r3, [pc, #76]	@ (200227cc <HAL_DMA_Init+0xb8>)
20022780:	4413      	add	r3, r2
20022782:	2b8c      	cmp	r3, #140	@ 0x8c
20022784:	d813      	bhi.n	200227ae <HAL_DMA_Init+0x9a>
20022786:	2214      	movs	r2, #20
20022788:	fbb3 f3f2 	udiv	r3, r3, r2
2002278c:	4a10      	ldr	r2, [pc, #64]	@ (200227d0 <HAL_DMA_Init+0xbc>)
2002278e:	009b      	lsls	r3, r3, #2
20022790:	2100      	movs	r1, #0
20022792:	4620      	mov	r0, r4
20022794:	e9c4 2312 	strd	r2, r3, [r4, #72]	@ 0x48
20022798:	f7ff ff22 	bl	200225e0 <DMA_AllocChannel>
2002279c:	4605      	mov	r5, r0
2002279e:	b990      	cbnz	r0, 200227c6 <HAL_DMA_Init+0xb2>
200227a0:	4620      	mov	r0, r4
200227a2:	f7ff fe5f 	bl	20022464 <DMA_Init>
200227a6:	f7ff ff85 	bl	200226b4 <DMA_FreeChannel.isra.0>
200227aa:	4628      	mov	r0, r5
200227ac:	bd38      	pop	{r3, r4, r5, pc}
200227ae:	4b09      	ldr	r3, [pc, #36]	@ (200227d4 <HAL_DMA_Init+0xc0>)
200227b0:	4413      	add	r3, r2
200227b2:	2b8c      	cmp	r3, #140	@ 0x8c
200227b4:	d805      	bhi.n	200227c2 <HAL_DMA_Init+0xae>
200227b6:	2214      	movs	r2, #20
200227b8:	fbb3 f3f2 	udiv	r3, r3, r2
200227bc:	4a06      	ldr	r2, [pc, #24]	@ (200227d8 <HAL_DMA_Init+0xc4>)
200227be:	009b      	lsls	r3, r3, #2
200227c0:	e7e6      	b.n	20022790 <HAL_DMA_Init+0x7c>
200227c2:	2501      	movs	r5, #1
200227c4:	e7f1      	b.n	200227aa <HAL_DMA_Init+0x96>
200227c6:	2502      	movs	r5, #2
200227c8:	e7ef      	b.n	200227aa <HAL_DMA_Init+0x96>
200227ca:	bf00      	nop
200227cc:	aff7eff8 	.word	0xaff7eff8
200227d0:	50081000 	.word	0x50081000
200227d4:	bfffeff8 	.word	0xbfffeff8
200227d8:	40001000 	.word	0x40001000

200227dc <HAL_DMA_DeInit>:
200227dc:	b538      	push	{r3, r4, r5, lr}
200227de:	4604      	mov	r4, r0
200227e0:	2800      	cmp	r0, #0
200227e2:	d05e      	beq.n	200228a2 <HAL_DMA_DeInit+0xc6>
200227e4:	6802      	ldr	r2, [r0, #0]
200227e6:	4b30      	ldr	r3, [pc, #192]	@ (200228a8 <HAL_DMA_DeInit+0xcc>)
200227e8:	4413      	add	r3, r2
200227ea:	2b8c      	cmp	r3, #140	@ 0x8c
200227ec:	d841      	bhi.n	20022872 <HAL_DMA_DeInit+0x96>
200227ee:	2214      	movs	r2, #20
200227f0:	fbb3 f3f2 	udiv	r3, r3, r2
200227f4:	009b      	lsls	r3, r3, #2
200227f6:	64c3      	str	r3, [r0, #76]	@ 0x4c
200227f8:	4b2c      	ldr	r3, [pc, #176]	@ (200228ac <HAL_DMA_DeInit+0xd0>)
200227fa:	64a3      	str	r3, [r4, #72]	@ 0x48
200227fc:	4620      	mov	r0, r4
200227fe:	f7ff fec3 	bl	20022588 <DMA_IsChannelOwner>
20022802:	b3a0      	cbz	r0, 2002286e <HAL_DMA_DeInit+0x92>
20022804:	6822      	ldr	r2, [r4, #0]
20022806:	6813      	ldr	r3, [r2, #0]
20022808:	f023 0301 	bic.w	r3, r3, #1
2002280c:	6013      	str	r3, [r2, #0]
2002280e:	2200      	movs	r2, #0
20022810:	6823      	ldr	r3, [r4, #0]
20022812:	601a      	str	r2, [r3, #0]
20022814:	2201      	movs	r2, #1
20022816:	e9d4 1312 	ldrd	r1, r3, [r4, #72]	@ 0x48
2002281a:	f003 031c 	and.w	r3, r3, #28
2002281e:	fa02 f303 	lsl.w	r3, r2, r3
20022822:	604b      	str	r3, [r1, #4]
20022824:	f3ef 8510 	mrs	r5, PRIMASK
20022828:	f382 8810 	msr	PRIMASK, r2
2002282c:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
2002282e:	6ca1      	ldr	r1, [r4, #72]	@ 0x48
20022830:	2b0f      	cmp	r3, #15
20022832:	ea4f 0293 	mov.w	r2, r3, lsr #2
20022836:	d827      	bhi.n	20022888 <HAL_DMA_DeInit+0xac>
20022838:	203f      	movs	r0, #63	@ 0x3f
2002283a:	005b      	lsls	r3, r3, #1
2002283c:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
20022840:	f003 0338 	and.w	r3, r3, #56	@ 0x38
20022844:	fa00 f303 	lsl.w	r3, r0, r3
20022848:	ea22 0303 	bic.w	r3, r2, r3
2002284c:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
20022850:	f385 8810 	msr	PRIMASK, r5
20022854:	4620      	mov	r0, r4
20022856:	f7ff ff2d 	bl	200226b4 <DMA_FreeChannel.isra.0>
2002285a:	2300      	movs	r3, #0
2002285c:	e9c4 330d 	strd	r3, r3, [r4, #52]	@ 0x34
20022860:	e9c4 330f 	strd	r3, r3, [r4, #60]	@ 0x3c
20022864:	6463      	str	r3, [r4, #68]	@ 0x44
20022866:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
2002286a:	f884 302d 	strb.w	r3, [r4, #45]	@ 0x2d
2002286e:	2000      	movs	r0, #0
20022870:	bd38      	pop	{r3, r4, r5, pc}
20022872:	4b0f      	ldr	r3, [pc, #60]	@ (200228b0 <HAL_DMA_DeInit+0xd4>)
20022874:	4413      	add	r3, r2
20022876:	2b8c      	cmp	r3, #140	@ 0x8c
20022878:	d8c0      	bhi.n	200227fc <HAL_DMA_DeInit+0x20>
2002287a:	2214      	movs	r2, #20
2002287c:	fbb3 f3f2 	udiv	r3, r3, r2
20022880:	009b      	lsls	r3, r3, #2
20022882:	64c3      	str	r3, [r0, #76]	@ 0x4c
20022884:	4b0b      	ldr	r3, [pc, #44]	@ (200228b4 <HAL_DMA_DeInit+0xd8>)
20022886:	e7b8      	b.n	200227fa <HAL_DMA_DeInit+0x1e>
20022888:	f002 0303 	and.w	r3, r2, #3
2002288c:	223f      	movs	r2, #63	@ 0x3f
2002288e:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20022892:	00db      	lsls	r3, r3, #3
20022894:	fa02 f303 	lsl.w	r3, r2, r3
20022898:	ea20 0303 	bic.w	r3, r0, r3
2002289c:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
200228a0:	e7d6      	b.n	20022850 <HAL_DMA_DeInit+0x74>
200228a2:	2001      	movs	r0, #1
200228a4:	e7e4      	b.n	20022870 <HAL_DMA_DeInit+0x94>
200228a6:	bf00      	nop
200228a8:	aff7eff8 	.word	0xaff7eff8
200228ac:	50081000 	.word	0x50081000
200228b0:	bfffeff8 	.word	0xbfffeff8
200228b4:	40001000 	.word	0x40001000

200228b8 <HAL_DMA_PollForTransfer>:
200228b8:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
200228bc:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
200228c0:	4617      	mov	r7, r2
200228c2:	2b02      	cmp	r3, #2
200228c4:	4604      	mov	r4, r0
200228c6:	4688      	mov	r8, r1
200228c8:	b2da      	uxtb	r2, r3
200228ca:	d005      	beq.n	200228d8 <HAL_DMA_PollForTransfer+0x20>
200228cc:	2304      	movs	r3, #4
200228ce:	6443      	str	r3, [r0, #68]	@ 0x44
200228d0:	2300      	movs	r3, #0
200228d2:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
200228d6:	e006      	b.n	200228e6 <HAL_DMA_PollForTransfer+0x2e>
200228d8:	6803      	ldr	r3, [r0, #0]
200228da:	681b      	ldr	r3, [r3, #0]
200228dc:	0699      	lsls	r1, r3, #26
200228de:	d505      	bpl.n	200228ec <HAL_DMA_PollForTransfer+0x34>
200228e0:	f44f 7380 	mov.w	r3, #256	@ 0x100
200228e4:	6443      	str	r3, [r0, #68]	@ 0x44
200228e6:	2001      	movs	r0, #1
200228e8:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
200228ec:	6cc5      	ldr	r5, [r0, #76]	@ 0x4c
200228ee:	f005 051c 	and.w	r5, r5, #28
200228f2:	f1b8 0f00 	cmp.w	r8, #0
200228f6:	d123      	bne.n	20022940 <HAL_DMA_PollForTransfer+0x88>
200228f8:	fa02 f505 	lsl.w	r5, r2, r5
200228fc:	f7ff fbd0 	bl	200220a0 <HAL_GetTick>
20022900:	f04f 0a08 	mov.w	sl, #8
20022904:	4681      	mov	r9, r0
20022906:	e9d4 6312 	ldrd	r6, r3, [r4, #72]	@ 0x48
2002290a:	f003 031c 	and.w	r3, r3, #28
2002290e:	fa0a f103 	lsl.w	r1, sl, r3
20022912:	6832      	ldr	r2, [r6, #0]
20022914:	ea12 0b05 	ands.w	fp, r2, r5
20022918:	d016      	beq.n	20022948 <HAL_DMA_PollForTransfer+0x90>
2002291a:	f1b8 0f00 	cmp.w	r8, #0
2002291e:	d136      	bne.n	2002298e <HAL_DMA_PollForTransfer+0xd6>
20022920:	2202      	movs	r2, #2
20022922:	fa02 f303 	lsl.w	r3, r2, r3
20022926:	6073      	str	r3, [r6, #4]
20022928:	6d23      	ldr	r3, [r4, #80]	@ 0x50
2002292a:	b92b      	cbnz	r3, 20022938 <HAL_DMA_PollForTransfer+0x80>
2002292c:	4620      	mov	r0, r4
2002292e:	f7ff fec1 	bl	200226b4 <DMA_FreeChannel.isra.0>
20022932:	2301      	movs	r3, #1
20022934:	f884 302d 	strb.w	r3, [r4, #45]	@ 0x2d
20022938:	2000      	movs	r0, #0
2002293a:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
2002293e:	e7d3      	b.n	200228e8 <HAL_DMA_PollForTransfer+0x30>
20022940:	2304      	movs	r3, #4
20022942:	fa03 f505 	lsl.w	r5, r3, r5
20022946:	e7d9      	b.n	200228fc <HAL_DMA_PollForTransfer+0x44>
20022948:	6832      	ldr	r2, [r6, #0]
2002294a:	4211      	tst	r1, r2
2002294c:	d00c      	beq.n	20022968 <HAL_DMA_PollForTransfer+0xb0>
2002294e:	2501      	movs	r5, #1
20022950:	fa05 f303 	lsl.w	r3, r5, r3
20022954:	6073      	str	r3, [r6, #4]
20022956:	4620      	mov	r0, r4
20022958:	6465      	str	r5, [r4, #68]	@ 0x44
2002295a:	f7ff feab 	bl	200226b4 <DMA_FreeChannel.isra.0>
2002295e:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20022962:	f884 b02c 	strb.w	fp, [r4, #44]	@ 0x2c
20022966:	e7be      	b.n	200228e6 <HAL_DMA_PollForTransfer+0x2e>
20022968:	1c7a      	adds	r2, r7, #1
2002296a:	d0d2      	beq.n	20022912 <HAL_DMA_PollForTransfer+0x5a>
2002296c:	f7ff fb98 	bl	200220a0 <HAL_GetTick>
20022970:	eba0 0009 	sub.w	r0, r0, r9
20022974:	42b8      	cmp	r0, r7
20022976:	d801      	bhi.n	2002297c <HAL_DMA_PollForTransfer+0xc4>
20022978:	2f00      	cmp	r7, #0
2002297a:	d1c4      	bne.n	20022906 <HAL_DMA_PollForTransfer+0x4e>
2002297c:	2320      	movs	r3, #32
2002297e:	4620      	mov	r0, r4
20022980:	6463      	str	r3, [r4, #68]	@ 0x44
20022982:	f7ff fe97 	bl	200226b4 <DMA_FreeChannel.isra.0>
20022986:	2301      	movs	r3, #1
20022988:	f884 302d 	strb.w	r3, [r4, #45]	@ 0x2d
2002298c:	e7a0      	b.n	200228d0 <HAL_DMA_PollForTransfer+0x18>
2002298e:	2204      	movs	r2, #4
20022990:	fa02 f303 	lsl.w	r3, r2, r3
20022994:	6073      	str	r3, [r6, #4]
20022996:	e7cf      	b.n	20022938 <HAL_DMA_PollForTransfer+0x80>

20022998 <DMA_Remap>:
20022998:	b530      	push	{r4, r5, lr}
2002299a:	4b15      	ldr	r3, [pc, #84]	@ (200229f0 <DMA_Remap+0x58>)
2002299c:	6c84      	ldr	r4, [r0, #72]	@ 0x48
2002299e:	429c      	cmp	r4, r3
200229a0:	d11b      	bne.n	200229da <DMA_Remap+0x42>
200229a2:	6883      	ldr	r3, [r0, #8]
200229a4:	2b10      	cmp	r3, #16
200229a6:	d002      	beq.n	200229ae <DMA_Remap+0x16>
200229a8:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
200229ac:	d108      	bne.n	200229c0 <DMA_Remap+0x28>
200229ae:	680b      	ldr	r3, [r1, #0]
200229b0:	4c10      	ldr	r4, [pc, #64]	@ (200229f4 <DMA_Remap+0x5c>)
200229b2:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
200229b6:	42a5      	cmp	r5, r4
200229b8:	bf98      	it	ls
200229ba:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
200229be:	600b      	str	r3, [r1, #0]
200229c0:	6883      	ldr	r3, [r0, #8]
200229c2:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
200229c6:	d108      	bne.n	200229da <DMA_Remap+0x42>
200229c8:	6813      	ldr	r3, [r2, #0]
200229ca:	480a      	ldr	r0, [pc, #40]	@ (200229f4 <DMA_Remap+0x5c>)
200229cc:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
200229d0:	4284      	cmp	r4, r0
200229d2:	bf98      	it	ls
200229d4:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
200229d8:	6013      	str	r3, [r2, #0]
200229da:	680b      	ldr	r3, [r1, #0]
200229dc:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
200229e0:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
200229e4:	bf3c      	itt	cc
200229e6:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
200229ea:	600b      	strcc	r3, [r1, #0]
200229ec:	bd30      	pop	{r4, r5, pc}
200229ee:	bf00      	nop
200229f0:	40001000 	.word	0x40001000
200229f4:	0007fffe 	.word	0x0007fffe

200229f8 <DMA_Start>:
200229f8:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
200229fc:	f64f 75ff 	movw	r5, #65535	@ 0xffff
20022a00:	6d03      	ldr	r3, [r0, #80]	@ 0x50
20022a02:	6802      	ldr	r2, [r0, #0]
20022a04:	429d      	cmp	r5, r3
20022a06:	bf28      	it	cs
20022a08:	461d      	movcs	r5, r3
20022a0a:	1b5b      	subs	r3, r3, r5
20022a0c:	6503      	str	r3, [r0, #80]	@ 0x50
20022a0e:	6585      	str	r5, [r0, #88]	@ 0x58
20022a10:	6813      	ldr	r3, [r2, #0]
20022a12:	f890 7066 	ldrb.w	r7, [r0, #102]	@ 0x66
20022a16:	f023 0301 	bic.w	r3, r3, #1
20022a1a:	f890 8067 	ldrb.w	r8, [r0, #103]	@ 0x67
20022a1e:	6013      	str	r3, [r2, #0]
20022a20:	e9d0 2317 	ldrd	r2, r3, [r0, #92]	@ 0x5c
20022a24:	460e      	mov	r6, r1
20022a26:	e9cd 2300 	strd	r2, r3, [sp]
20022a2a:	e9d0 2312 	ldrd	r2, r3, [r0, #72]	@ 0x48
20022a2e:	f003 011c 	and.w	r1, r3, #28
20022a32:	2301      	movs	r3, #1
20022a34:	4604      	mov	r4, r0
20022a36:	408b      	lsls	r3, r1
20022a38:	6053      	str	r3, [r2, #4]
20022a3a:	6803      	ldr	r3, [r0, #0]
20022a3c:	4669      	mov	r1, sp
20022a3e:	605d      	str	r5, [r3, #4]
20022a40:	aa01      	add	r2, sp, #4
20022a42:	f7ff ffa9 	bl	20022998 <DMA_Remap>
20022a46:	e9dd 0300 	ldrd	r0, r3, [sp]
20022a4a:	68a1      	ldr	r1, [r4, #8]
20022a4c:	6822      	ldr	r2, [r4, #0]
20022a4e:	2910      	cmp	r1, #16
20022a50:	bf0b      	itete	eq
20022a52:	6093      	streq	r3, [r2, #8]
20022a54:	6090      	strne	r0, [r2, #8]
20022a56:	6823      	ldreq	r3, [r4, #0]
20022a58:	6822      	ldrne	r2, [r4, #0]
20022a5a:	bf0c      	ite	eq
20022a5c:	60d8      	streq	r0, [r3, #12]
20022a5e:	60d3      	strne	r3, [r2, #12]
20022a60:	f894 3064 	ldrb.w	r3, [r4, #100]	@ 0x64
20022a64:	b123      	cbz	r3, 20022a70 <DMA_Start+0x78>
20022a66:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20022a68:	fa05 f707 	lsl.w	r7, r5, r7
20022a6c:	443b      	add	r3, r7
20022a6e:	65e3      	str	r3, [r4, #92]	@ 0x5c
20022a70:	f894 3065 	ldrb.w	r3, [r4, #101]	@ 0x65
20022a74:	b123      	cbz	r3, 20022a80 <DMA_Start+0x88>
20022a76:	6e23      	ldr	r3, [r4, #96]	@ 0x60
20022a78:	fa05 f508 	lsl.w	r5, r5, r8
20022a7c:	442b      	add	r3, r5
20022a7e:	6623      	str	r3, [r4, #96]	@ 0x60
20022a80:	b136      	cbz	r6, 20022a90 <DMA_Start+0x98>
20022a82:	6ba2      	ldr	r2, [r4, #56]	@ 0x38
20022a84:	6823      	ldr	r3, [r4, #0]
20022a86:	b15a      	cbz	r2, 20022aa0 <DMA_Start+0xa8>
20022a88:	681a      	ldr	r2, [r3, #0]
20022a8a:	f042 020e 	orr.w	r2, r2, #14
20022a8e:	601a      	str	r2, [r3, #0]
20022a90:	6822      	ldr	r2, [r4, #0]
20022a92:	6813      	ldr	r3, [r2, #0]
20022a94:	f043 0301 	orr.w	r3, r3, #1
20022a98:	6013      	str	r3, [r2, #0]
20022a9a:	b002      	add	sp, #8
20022a9c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022aa0:	681a      	ldr	r2, [r3, #0]
20022aa2:	f022 0204 	bic.w	r2, r2, #4
20022aa6:	601a      	str	r2, [r3, #0]
20022aa8:	6822      	ldr	r2, [r4, #0]
20022aaa:	6813      	ldr	r3, [r2, #0]
20022aac:	f043 030a 	orr.w	r3, r3, #10
20022ab0:	6013      	str	r3, [r2, #0]
20022ab2:	e7ed      	b.n	20022a90 <DMA_Start+0x98>

20022ab4 <HAL_DMA_Start>:
20022ab4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022ab6:	461d      	mov	r5, r3
20022ab8:	69c3      	ldr	r3, [r0, #28]
20022aba:	4604      	mov	r4, r0
20022abc:	2b20      	cmp	r3, #32
20022abe:	460f      	mov	r7, r1
20022ac0:	4616      	mov	r6, r2
20022ac2:	d105      	bne.n	20022ad0 <HAL_DMA_Start+0x1c>
20022ac4:	f64f 73fd 	movw	r3, #65533	@ 0xfffd
20022ac8:	1e6a      	subs	r2, r5, #1
20022aca:	429a      	cmp	r2, r3
20022acc:	d900      	bls.n	20022ad0 <HAL_DMA_Start+0x1c>
20022ace:	e7fe      	b.n	20022ace <HAL_DMA_Start+0x1a>
20022ad0:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
20022ad4:	2b01      	cmp	r3, #1
20022ad6:	d00e      	beq.n	20022af6 <HAL_DMA_Start+0x42>
20022ad8:	2301      	movs	r3, #1
20022ada:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
20022ade:	f894 302d 	ldrb.w	r3, [r4, #45]	@ 0x2d
20022ae2:	2b01      	cmp	r3, #1
20022ae4:	b2d9      	uxtb	r1, r3
20022ae6:	d103      	bne.n	20022af0 <HAL_DMA_Start+0x3c>
20022ae8:	4620      	mov	r0, r4
20022aea:	f7ff fd79 	bl	200225e0 <DMA_AllocChannel>
20022aee:	b120      	cbz	r0, 20022afa <HAL_DMA_Start+0x46>
20022af0:	2300      	movs	r3, #0
20022af2:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
20022af6:	2002      	movs	r0, #2
20022af8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20022afa:	2302      	movs	r3, #2
20022afc:	e9c4 5514 	strd	r5, r5, [r4, #80]	@ 0x50
20022b00:	e9c4 7617 	strd	r7, r6, [r4, #92]	@ 0x5c
20022b04:	f884 302d 	strb.w	r3, [r4, #45]	@ 0x2d
20022b08:	6460      	str	r0, [r4, #68]	@ 0x44
20022b0a:	6d20      	ldr	r0, [r4, #80]	@ 0x50
20022b0c:	2800      	cmp	r0, #0
20022b0e:	d0f3      	beq.n	20022af8 <HAL_DMA_Start+0x44>
20022b10:	2100      	movs	r1, #0
20022b12:	4620      	mov	r0, r4
20022b14:	f7ff ff70 	bl	200229f8 <DMA_Start>
20022b18:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20022b1a:	2b00      	cmp	r3, #0
20022b1c:	d0f5      	beq.n	20022b0a <HAL_DMA_Start+0x56>
20022b1e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20022b22:	2100      	movs	r1, #0
20022b24:	4620      	mov	r0, r4
20022b26:	f7ff fec7 	bl	200228b8 <HAL_DMA_PollForTransfer>
20022b2a:	2800      	cmp	r0, #0
20022b2c:	d0ed      	beq.n	20022b0a <HAL_DMA_Start+0x56>
20022b2e:	e7e3      	b.n	20022af8 <HAL_DMA_Start+0x44>

20022b30 <HAL_EFUSE_Read>:
20022b30:	2a20      	cmp	r2, #32
20022b32:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20022b36:	4607      	mov	r7, r0
20022b38:	460c      	mov	r4, r1
20022b3a:	4690      	mov	r8, r2
20022b3c:	dc25      	bgt.n	20022b8a <HAL_EFUSE_Read+0x5a>
20022b3e:	f3c0 09c4 	ubfx	r9, r0, #3, #5
20022b42:	eb09 0302 	add.w	r3, r9, r2
20022b46:	2b20      	cmp	r3, #32
20022b48:	dc1f      	bgt.n	20022b8a <HAL_EFUSE_Read+0x5a>
20022b4a:	f012 0f03 	tst.w	r2, #3
20022b4e:	d11c      	bne.n	20022b8a <HAL_EFUSE_Read+0x5a>
20022b50:	f010 051f 	ands.w	r5, r0, #31
20022b54:	d119      	bne.n	20022b8a <HAL_EFUSE_Read+0x5a>
20022b56:	2003      	movs	r0, #3
20022b58:	f7ff fa54 	bl	20022004 <pmu_ldo_inc>
20022b5c:	4629      	mov	r1, r5
20022b5e:	4e1d      	ldr	r6, [pc, #116]	@ (20022bd4 <HAL_EFUSE_Read+0xa4>)
20022b60:	0a3f      	lsrs	r7, r7, #8
20022b62:	00bb      	lsls	r3, r7, #2
20022b64:	6033      	str	r3, [r6, #0]
20022b66:	6833      	ldr	r3, [r6, #0]
20022b68:	4a1b      	ldr	r2, [pc, #108]	@ (20022bd8 <HAL_EFUSE_Read+0xa8>)
20022b6a:	f043 0301 	orr.w	r3, r3, #1
20022b6e:	6033      	str	r3, [r6, #0]
20022b70:	68b3      	ldr	r3, [r6, #8]
20022b72:	07db      	lsls	r3, r3, #31
20022b74:	d401      	bmi.n	20022b7a <HAL_EFUSE_Read+0x4a>
20022b76:	4291      	cmp	r1, r2
20022b78:	d10c      	bne.n	20022b94 <HAL_EFUSE_Read+0x64>
20022b7a:	68b3      	ldr	r3, [r6, #8]
20022b7c:	4291      	cmp	r1, r2
20022b7e:	f043 0301 	orr.w	r3, r3, #1
20022b82:	60b3      	str	r3, [r6, #8]
20022b84:	d108      	bne.n	20022b98 <HAL_EFUSE_Read+0x68>
20022b86:	f7ff fa51 	bl	2002202c <pmu_ldo_recover>
20022b8a:	f04f 0800 	mov.w	r8, #0
20022b8e:	4640      	mov	r0, r8
20022b90:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20022b94:	3101      	adds	r1, #1
20022b96:	e7eb      	b.n	20022b70 <HAL_EFUSE_Read+0x40>
20022b98:	4a10      	ldr	r2, [pc, #64]	@ (20022bdc <HAL_EFUSE_Read+0xac>)
20022b9a:	f009 031c 	and.w	r3, r9, #28
20022b9e:	eb03 1347 	add.w	r3, r3, r7, lsl #5
20022ba2:	f028 0103 	bic.w	r1, r8, #3
20022ba6:	441a      	add	r2, r3
20022ba8:	4421      	add	r1, r4
20022baa:	428c      	cmp	r4, r1
20022bac:	d102      	bne.n	20022bb4 <HAL_EFUSE_Read+0x84>
20022bae:	f7ff fa3d 	bl	2002202c <pmu_ldo_recover>
20022bb2:	e7ec      	b.n	20022b8e <HAL_EFUSE_Read+0x5e>
20022bb4:	f852 3b04 	ldr.w	r3, [r2], #4
20022bb8:	3404      	adds	r4, #4
20022bba:	0a1d      	lsrs	r5, r3, #8
20022bbc:	f804 3c04 	strb.w	r3, [r4, #-4]
20022bc0:	f804 5c03 	strb.w	r5, [r4, #-3]
20022bc4:	0c1d      	lsrs	r5, r3, #16
20022bc6:	0e1b      	lsrs	r3, r3, #24
20022bc8:	f804 5c02 	strb.w	r5, [r4, #-2]
20022bcc:	f804 3c01 	strb.w	r3, [r4, #-1]
20022bd0:	e7eb      	b.n	20022baa <HAL_EFUSE_Read+0x7a>
20022bd2:	bf00      	nop
20022bd4:	5000c000 	.word	0x5000c000
20022bd8:	00bb8000 	.word	0x00bb8000
20022bdc:	5000c030 	.word	0x5000c030

20022be0 <HAL_DBG_printf>:
20022be0:	b40f      	push	{r0, r1, r2, r3}
20022be2:	b004      	add	sp, #16
20022be4:	4770      	bx	lr
	...

20022be8 <HAL_HPAON_WakeCore>:
20022be8:	2802      	cmp	r0, #2
20022bea:	b510      	push	{r4, lr}
20022bec:	d120      	bne.n	20022c30 <HAL_HPAON_WakeCore+0x48>
20022bee:	4c11      	ldr	r4, [pc, #68]	@ (20022c34 <HAL_HPAON_WakeCore+0x4c>)
20022bf0:	20e6      	movs	r0, #230	@ 0xe6
20022bf2:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
20022bf4:	f043 0301 	orr.w	r3, r3, #1
20022bf8:	62e3      	str	r3, [r4, #44]	@ 0x2c
20022bfa:	f7ff faae 	bl	2002215a <HAL_Delay_us>
20022bfe:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
20022c00:	069a      	lsls	r2, r3, #26
20022c02:	d5fc      	bpl.n	20022bfe <HAL_HPAON_WakeCore+0x16>
20022c04:	201e      	movs	r0, #30
20022c06:	f7ff faa8 	bl	2002215a <HAL_Delay_us>
20022c0a:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
20022c0c:	069b      	lsls	r3, r3, #26
20022c0e:	d5fc      	bpl.n	20022c0a <HAL_HPAON_WakeCore+0x22>
20022c10:	f3ef 8110 	mrs	r1, PRIMASK
20022c14:	2301      	movs	r3, #1
20022c16:	f383 8810 	msr	PRIMASK, r3
20022c1a:	4a07      	ldr	r2, [pc, #28]	@ (20022c38 <HAL_HPAON_WakeCore+0x50>)
20022c1c:	7813      	ldrb	r3, [r2, #0]
20022c1e:	2b13      	cmp	r3, #19
20022c20:	d900      	bls.n	20022c24 <HAL_HPAON_WakeCore+0x3c>
20022c22:	e7fe      	b.n	20022c22 <HAL_HPAON_WakeCore+0x3a>
20022c24:	3301      	adds	r3, #1
20022c26:	7013      	strb	r3, [r2, #0]
20022c28:	f381 8810 	msr	PRIMASK, r1
20022c2c:	2000      	movs	r0, #0
20022c2e:	bd10      	pop	{r4, pc}
20022c30:	2001      	movs	r0, #1
20022c32:	e7fc      	b.n	20022c2e <HAL_HPAON_WakeCore+0x46>
20022c34:	500c0000 	.word	0x500c0000
20022c38:	2004cc44 	.word	0x2004cc44

20022c3c <HAL_HPAON_EnableXT48>:
20022c3c:	4b04      	ldr	r3, [pc, #16]	@ (20022c50 <HAL_HPAON_EnableXT48+0x14>)
20022c3e:	691a      	ldr	r2, [r3, #16]
20022c40:	f042 0202 	orr.w	r2, r2, #2
20022c44:	611a      	str	r2, [r3, #16]
20022c46:	691a      	ldr	r2, [r3, #16]
20022c48:	2a00      	cmp	r2, #0
20022c4a:	dafc      	bge.n	20022c46 <HAL_HPAON_EnableXT48+0xa>
20022c4c:	4770      	bx	lr
20022c4e:	bf00      	nop
20022c50:	500c0000 	.word	0x500c0000

20022c54 <HAL_HPAON_DisableXT48>:
20022c54:	4a02      	ldr	r2, [pc, #8]	@ (20022c60 <HAL_HPAON_DisableXT48+0xc>)
20022c56:	6913      	ldr	r3, [r2, #16]
20022c58:	f023 0302 	bic.w	r3, r3, #2
20022c5c:	6113      	str	r3, [r2, #16]
20022c5e:	4770      	bx	lr
20022c60:	500c0000 	.word	0x500c0000

20022c64 <HAL_QSPI_Init>:
20022c64:	b510      	push	{r4, lr}
20022c66:	b1e0      	cbz	r0, 20022ca2 <HAL_QSPI_Init+0x3e>
20022c68:	b1d9      	cbz	r1, 20022ca2 <HAL_QSPI_Init+0x3e>
20022c6a:	2300      	movs	r3, #0
20022c6c:	2201      	movs	r2, #1
20022c6e:	6043      	str	r3, [r0, #4]
20022c70:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
20022c74:	680c      	ldr	r4, [r1, #0]
20022c76:	6004      	str	r4, [r0, #0]
20022c78:	684a      	ldr	r2, [r1, #4]
20022c7a:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
20022c7e:	688a      	ldr	r2, [r1, #8]
20022c80:	6102      	str	r2, [r0, #16]
20022c82:	68ca      	ldr	r2, [r1, #12]
20022c84:	0512      	lsls	r2, r2, #20
20022c86:	6142      	str	r2, [r0, #20]
20022c88:	22ff      	movs	r2, #255	@ 0xff
20022c8a:	f8c4 2084 	str.w	r2, [r4, #132]	@ 0x84
20022c8e:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
20022c92:	6801      	ldr	r1, [r0, #0]
20022c94:	678c      	str	r4, [r1, #120]	@ 0x78
20022c96:	6801      	ldr	r1, [r0, #0]
20022c98:	620a      	str	r2, [r1, #32]
20022c9a:	6801      	ldr	r1, [r0, #0]
20022c9c:	4618      	mov	r0, r3
20022c9e:	644a      	str	r2, [r1, #68]	@ 0x44
20022ca0:	bd10      	pop	{r4, pc}
20022ca2:	2001      	movs	r0, #1
20022ca4:	e7fc      	b.n	20022ca0 <HAL_QSPI_Init+0x3c>

20022ca6 <HAL_FLASH_SET_AHB_RCMD>:
20022ca6:	b138      	cbz	r0, 20022cb8 <HAL_FLASH_SET_AHB_RCMD+0x12>
20022ca8:	6802      	ldr	r2, [r0, #0]
20022caa:	2000      	movs	r0, #0
20022cac:	6c13      	ldr	r3, [r2, #64]	@ 0x40
20022cae:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
20022cb2:	4319      	orrs	r1, r3
20022cb4:	6411      	str	r1, [r2, #64]	@ 0x40
20022cb6:	4770      	bx	lr
20022cb8:	2001      	movs	r0, #1
20022cba:	4770      	bx	lr

20022cbc <HAL_FLASH_CFG_AHB_RCMD>:
20022cbc:	b570      	push	{r4, r5, r6, lr}
20022cbe:	b1c8      	cbz	r0, 20022cf4 <HAL_FLASH_CFG_AHB_RCMD+0x38>
20022cc0:	6805      	ldr	r5, [r0, #0]
20022cc2:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022cc6:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022cca:	6cac      	ldr	r4, [r5, #72]	@ 0x48
20022ccc:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022cd0:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022cd4:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022cd8:	f36f 0414 	bfc	r4, #0, #21
20022cdc:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022ce0:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022ce4:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022ce8:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
20022cec:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
20022cf0:	4321      	orrs	r1, r4
20022cf2:	64a9      	str	r1, [r5, #72]	@ 0x48
20022cf4:	bd70      	pop	{r4, r5, r6, pc}

20022cf6 <HAL_FLASH_SET_AHB_WCMD>:
20022cf6:	b140      	cbz	r0, 20022d0a <HAL_FLASH_SET_AHB_WCMD+0x14>
20022cf8:	6802      	ldr	r2, [r0, #0]
20022cfa:	2000      	movs	r0, #0
20022cfc:	6c13      	ldr	r3, [r2, #64]	@ 0x40
20022cfe:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
20022d02:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
20022d06:	6411      	str	r1, [r2, #64]	@ 0x40
20022d08:	4770      	bx	lr
20022d0a:	2001      	movs	r0, #1
20022d0c:	4770      	bx	lr

20022d0e <HAL_FLASH_CFG_AHB_WCMD>:
20022d0e:	b570      	push	{r4, r5, r6, lr}
20022d10:	b1c8      	cbz	r0, 20022d46 <HAL_FLASH_CFG_AHB_WCMD+0x38>
20022d12:	6805      	ldr	r5, [r0, #0]
20022d14:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022d18:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022d1c:	6d2c      	ldr	r4, [r5, #80]	@ 0x50
20022d1e:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022d22:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022d26:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022d2a:	f36f 0414 	bfc	r4, #0, #21
20022d2e:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022d32:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022d36:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022d3a:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
20022d3e:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
20022d42:	4321      	orrs	r1, r4
20022d44:	6529      	str	r1, [r5, #80]	@ 0x50
20022d46:	bd70      	pop	{r4, r5, r6, pc}

20022d48 <HAL_FLASH_WRITE_WORD>:
20022d48:	b118      	cbz	r0, 20022d52 <HAL_FLASH_WRITE_WORD+0xa>
20022d4a:	6803      	ldr	r3, [r0, #0]
20022d4c:	2000      	movs	r0, #0
20022d4e:	6059      	str	r1, [r3, #4]
20022d50:	4770      	bx	lr
20022d52:	2001      	movs	r0, #1
20022d54:	4770      	bx	lr

20022d56 <HAL_FLASH_WRITE_DLEN>:
20022d56:	b130      	cbz	r0, 20022d66 <HAL_FLASH_WRITE_DLEN+0x10>
20022d58:	6803      	ldr	r3, [r0, #0]
20022d5a:	3901      	subs	r1, #1
20022d5c:	f3c1 0113 	ubfx	r1, r1, #0, #20
20022d60:	2000      	movs	r0, #0
20022d62:	6259      	str	r1, [r3, #36]	@ 0x24
20022d64:	4770      	bx	lr
20022d66:	2001      	movs	r0, #1
20022d68:	4770      	bx	lr

20022d6a <HAL_FLASH_WRITE_DLEN2>:
20022d6a:	b130      	cbz	r0, 20022d7a <HAL_FLASH_WRITE_DLEN2+0x10>
20022d6c:	6803      	ldr	r3, [r0, #0]
20022d6e:	3901      	subs	r1, #1
20022d70:	f3c1 0113 	ubfx	r1, r1, #0, #20
20022d74:	2000      	movs	r0, #0
20022d76:	6399      	str	r1, [r3, #56]	@ 0x38
20022d78:	4770      	bx	lr
20022d7a:	2001      	movs	r0, #1
20022d7c:	4770      	bx	lr

20022d7e <HAL_FLASH_WRITE_ABYTE>:
20022d7e:	b108      	cbz	r0, 20022d84 <HAL_FLASH_WRITE_ABYTE+0x6>
20022d80:	6803      	ldr	r3, [r0, #0]
20022d82:	6219      	str	r1, [r3, #32]
20022d84:	4770      	bx	lr

20022d86 <HAL_FLASH_IS_CMD_DONE>:
20022d86:	b118      	cbz	r0, 20022d90 <HAL_FLASH_IS_CMD_DONE+0xa>
20022d88:	6803      	ldr	r3, [r0, #0]
20022d8a:	6918      	ldr	r0, [r3, #16]
20022d8c:	f000 0001 	and.w	r0, r0, #1
20022d90:	4770      	bx	lr

20022d92 <HAL_FLASH_CLR_CMD_DONE>:
20022d92:	b120      	cbz	r0, 20022d9e <HAL_FLASH_CLR_CMD_DONE+0xc>
20022d94:	6802      	ldr	r2, [r0, #0]
20022d96:	6953      	ldr	r3, [r2, #20]
20022d98:	f043 0301 	orr.w	r3, r3, #1
20022d9c:	6153      	str	r3, [r2, #20]
20022d9e:	4770      	bx	lr

20022da0 <HAL_FLASH_SET_CMD>:
20022da0:	b538      	push	{r3, r4, r5, lr}
20022da2:	460d      	mov	r5, r1
20022da4:	4604      	mov	r4, r0
20022da6:	b1a8      	cbz	r0, 20022dd4 <HAL_FLASH_SET_CMD+0x34>
20022da8:	6803      	ldr	r3, [r0, #0]
20022daa:	61da      	str	r2, [r3, #28]
20022dac:	6b43      	ldr	r3, [r0, #52]	@ 0x34
20022dae:	b10b      	cbz	r3, 20022db4 <HAL_FLASH_SET_CMD+0x14>
20022db0:	2001      	movs	r0, #1
20022db2:	4798      	blx	r3
20022db4:	6823      	ldr	r3, [r4, #0]
20022db6:	619d      	str	r5, [r3, #24]
20022db8:	4620      	mov	r0, r4
20022dba:	f7ff ffe4 	bl	20022d86 <HAL_FLASH_IS_CMD_DONE>
20022dbe:	2800      	cmp	r0, #0
20022dc0:	d0fa      	beq.n	20022db8 <HAL_FLASH_SET_CMD+0x18>
20022dc2:	4620      	mov	r0, r4
20022dc4:	f7ff ffe5 	bl	20022d92 <HAL_FLASH_CLR_CMD_DONE>
20022dc8:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20022dca:	b10b      	cbz	r3, 20022dd0 <HAL_FLASH_SET_CMD+0x30>
20022dcc:	2000      	movs	r0, #0
20022dce:	4798      	blx	r3
20022dd0:	2000      	movs	r0, #0
20022dd2:	bd38      	pop	{r3, r4, r5, pc}
20022dd4:	2001      	movs	r0, #1
20022dd6:	e7fc      	b.n	20022dd2 <HAL_FLASH_SET_CMD+0x32>

20022dd8 <HAL_FLASH_CLR_STATUS>:
20022dd8:	b118      	cbz	r0, 20022de2 <HAL_FLASH_CLR_STATUS+0xa>
20022dda:	6802      	ldr	r2, [r0, #0]
20022ddc:	6953      	ldr	r3, [r2, #20]
20022dde:	4319      	orrs	r1, r3
20022de0:	6151      	str	r1, [r2, #20]
20022de2:	4770      	bx	lr

20022de4 <HAL_FLASH_STATUS_MATCH>:
20022de4:	b118      	cbz	r0, 20022dee <HAL_FLASH_STATUS_MATCH+0xa>
20022de6:	6803      	ldr	r3, [r0, #0]
20022de8:	6918      	ldr	r0, [r3, #16]
20022dea:	f3c0 00c0 	ubfx	r0, r0, #3, #1
20022dee:	4770      	bx	lr

20022df0 <HAL_FLASH_IS_PROG_DONE>:
20022df0:	b128      	cbz	r0, 20022dfe <HAL_FLASH_IS_PROG_DONE+0xe>
20022df2:	6803      	ldr	r3, [r0, #0]
20022df4:	6858      	ldr	r0, [r3, #4]
20022df6:	43c0      	mvns	r0, r0
20022df8:	f000 0001 	and.w	r0, r0, #1
20022dfc:	4770      	bx	lr
20022dfe:	2001      	movs	r0, #1
20022e00:	4770      	bx	lr

20022e02 <HAL_FLASH_READ32>:
20022e02:	b108      	cbz	r0, 20022e08 <HAL_FLASH_READ32+0x6>
20022e04:	6803      	ldr	r3, [r0, #0]
20022e06:	6858      	ldr	r0, [r3, #4]
20022e08:	4770      	bx	lr

20022e0a <HAL_FLASH_SET_TXSLOT>:
20022e0a:	b120      	cbz	r0, 20022e16 <HAL_FLASH_SET_TXSLOT+0xc>
20022e0c:	6802      	ldr	r2, [r0, #0]
20022e0e:	6d53      	ldr	r3, [r2, #84]	@ 0x54
20022e10:	f361 238e 	bfi	r3, r1, #10, #5
20022e14:	6553      	str	r3, [r2, #84]	@ 0x54
20022e16:	4770      	bx	lr

20022e18 <HAL_FLASH_SET_CLK_rom>:
20022e18:	b108      	cbz	r0, 20022e1e <HAL_FLASH_SET_CLK_rom+0x6>
20022e1a:	6803      	ldr	r3, [r0, #0]
20022e1c:	60d9      	str	r1, [r3, #12]
20022e1e:	4770      	bx	lr

20022e20 <HAL_FLASH_GET_DIV>:
20022e20:	b110      	cbz	r0, 20022e28 <HAL_FLASH_GET_DIV+0x8>
20022e22:	6803      	ldr	r3, [r0, #0]
20022e24:	68d8      	ldr	r0, [r3, #12]
20022e26:	b2c0      	uxtb	r0, r0
20022e28:	4770      	bx	lr

20022e2a <HAL_FLASH_MANUAL_CMD>:
20022e2a:	b570      	push	{r4, r5, r6, lr}
20022e2c:	b1e8      	cbz	r0, 20022e6a <HAL_FLASH_MANUAL_CMD+0x40>
20022e2e:	6805      	ldr	r5, [r0, #0]
20022e30:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022e34:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022e38:	6aac      	ldr	r4, [r5, #40]	@ 0x28
20022e3a:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022e3e:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022e42:	f36f 0415 	bfc	r4, #0, #22
20022e46:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022e4a:	f99d 6014 	ldrsb.w	r6, [sp, #20]
20022e4e:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
20022e52:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022e56:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022e5a:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
20022e5e:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
20022e62:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
20022e66:	4321      	orrs	r1, r4
20022e68:	62a9      	str	r1, [r5, #40]	@ 0x28
20022e6a:	bd70      	pop	{r4, r5, r6, pc}

20022e6c <HAL_FLASH_MANUAL_CMD2>:
20022e6c:	b570      	push	{r4, r5, r6, lr}
20022e6e:	b1e8      	cbz	r0, 20022eac <HAL_FLASH_MANUAL_CMD2+0x40>
20022e70:	6805      	ldr	r5, [r0, #0]
20022e72:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022e76:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022e7a:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
20022e7c:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022e80:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022e84:	f36f 0415 	bfc	r4, #0, #22
20022e88:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022e8c:	f99d 6014 	ldrsb.w	r6, [sp, #20]
20022e90:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
20022e94:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022e98:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022e9c:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
20022ea0:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
20022ea4:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
20022ea8:	4321      	orrs	r1, r4
20022eaa:	63e9      	str	r1, [r5, #60]	@ 0x3c
20022eac:	bd70      	pop	{r4, r5, r6, pc}
	...

20022eb0 <HAL_FLASH_SET_ALIAS_RANGE>:
20022eb0:	b510      	push	{r4, lr}
20022eb2:	b158      	cbz	r0, 20022ecc <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
20022eb4:	4b06      	ldr	r3, [pc, #24]	@ (20022ed0 <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
20022eb6:	6804      	ldr	r4, [r0, #0]
20022eb8:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
20022ebc:	440a      	add	r2, r1
20022ebe:	4019      	ands	r1, r3
20022ec0:	66e1      	str	r1, [r4, #108]	@ 0x6c
20022ec2:	401a      	ands	r2, r3
20022ec4:	6803      	ldr	r3, [r0, #0]
20022ec6:	2000      	movs	r0, #0
20022ec8:	671a      	str	r2, [r3, #112]	@ 0x70
20022eca:	bd10      	pop	{r4, pc}
20022ecc:	2001      	movs	r0, #1
20022ece:	e7fc      	b.n	20022eca <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
20022ed0:	fffffc00 	.word	0xfffffc00

20022ed4 <HAL_FLASH_SET_ALIAS_OFFSET>:
20022ed4:	b128      	cbz	r0, 20022ee2 <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
20022ed6:	6803      	ldr	r3, [r0, #0]
20022ed8:	f36f 0109 	bfc	r1, #0, #10
20022edc:	2000      	movs	r0, #0
20022ede:	6759      	str	r1, [r3, #116]	@ 0x74
20022ee0:	4770      	bx	lr
20022ee2:	2001      	movs	r0, #1
20022ee4:	4770      	bx	lr
	...

20022ee8 <HAL_FLASH_SET_CTR>:
20022ee8:	b510      	push	{r4, lr}
20022eea:	b150      	cbz	r0, 20022f02 <HAL_FLASH_SET_CTR+0x1a>
20022eec:	4b06      	ldr	r3, [pc, #24]	@ (20022f08 <HAL_FLASH_SET_CTR+0x20>)
20022eee:	6804      	ldr	r4, [r0, #0]
20022ef0:	4019      	ands	r1, r3
20022ef2:	65e1      	str	r1, [r4, #92]	@ 0x5c
20022ef4:	6801      	ldr	r1, [r0, #0]
20022ef6:	2000      	movs	r0, #0
20022ef8:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
20022efc:	401a      	ands	r2, r3
20022efe:	660a      	str	r2, [r1, #96]	@ 0x60
20022f00:	bd10      	pop	{r4, pc}
20022f02:	2001      	movs	r0, #1
20022f04:	e7fc      	b.n	20022f00 <HAL_FLASH_SET_CTR+0x18>
20022f06:	bf00      	nop
20022f08:	fffffc00 	.word	0xfffffc00

20022f0c <HAL_FLASH_SET_NONCE>:
20022f0c:	b150      	cbz	r0, 20022f24 <HAL_FLASH_SET_NONCE+0x18>
20022f0e:	b149      	cbz	r1, 20022f24 <HAL_FLASH_SET_NONCE+0x18>
20022f10:	680b      	ldr	r3, [r1, #0]
20022f12:	6802      	ldr	r2, [r0, #0]
20022f14:	ba1b      	rev	r3, r3
20022f16:	6653      	str	r3, [r2, #100]	@ 0x64
20022f18:	684b      	ldr	r3, [r1, #4]
20022f1a:	6802      	ldr	r2, [r0, #0]
20022f1c:	ba1b      	rev	r3, r3
20022f1e:	2000      	movs	r0, #0
20022f20:	6693      	str	r3, [r2, #104]	@ 0x68
20022f22:	4770      	bx	lr
20022f24:	2001      	movs	r0, #1
20022f26:	4770      	bx	lr

20022f28 <HAL_FLASH_SET_AES>:
20022f28:	b158      	cbz	r0, 20022f42 <HAL_FLASH_SET_AES+0x1a>
20022f2a:	6803      	ldr	r3, [r0, #0]
20022f2c:	2901      	cmp	r1, #1
20022f2e:	681a      	ldr	r2, [r3, #0]
20022f30:	d104      	bne.n	20022f3c <HAL_FLASH_SET_AES+0x14>
20022f32:	f042 0280 	orr.w	r2, r2, #128	@ 0x80
20022f36:	2000      	movs	r0, #0
20022f38:	601a      	str	r2, [r3, #0]
20022f3a:	4770      	bx	lr
20022f3c:	f022 0280 	bic.w	r2, r2, #128	@ 0x80
20022f40:	e7f9      	b.n	20022f36 <HAL_FLASH_SET_AES+0xe>
20022f42:	2001      	movs	r0, #1
20022f44:	4770      	bx	lr

20022f46 <HAL_FLASH_ENABLE_AES>:
20022f46:	b150      	cbz	r0, 20022f5e <HAL_FLASH_ENABLE_AES+0x18>
20022f48:	6803      	ldr	r3, [r0, #0]
20022f4a:	681a      	ldr	r2, [r3, #0]
20022f4c:	b121      	cbz	r1, 20022f58 <HAL_FLASH_ENABLE_AES+0x12>
20022f4e:	f042 0240 	orr.w	r2, r2, #64	@ 0x40
20022f52:	2000      	movs	r0, #0
20022f54:	601a      	str	r2, [r3, #0]
20022f56:	4770      	bx	lr
20022f58:	f022 0240 	bic.w	r2, r2, #64	@ 0x40
20022f5c:	e7f9      	b.n	20022f52 <HAL_FLASH_ENABLE_AES+0xc>
20022f5e:	2001      	movs	r0, #1
20022f60:	4770      	bx	lr

20022f62 <HAL_FLASH_ENABLE_QSPI>:
20022f62:	b150      	cbz	r0, 20022f7a <HAL_FLASH_ENABLE_QSPI+0x18>
20022f64:	6803      	ldr	r3, [r0, #0]
20022f66:	681a      	ldr	r2, [r3, #0]
20022f68:	b121      	cbz	r1, 20022f74 <HAL_FLASH_ENABLE_QSPI+0x12>
20022f6a:	f042 0201 	orr.w	r2, r2, #1
20022f6e:	2000      	movs	r0, #0
20022f70:	601a      	str	r2, [r3, #0]
20022f72:	4770      	bx	lr
20022f74:	f022 0201 	bic.w	r2, r2, #1
20022f78:	e7f9      	b.n	20022f6e <HAL_FLASH_ENABLE_QSPI+0xc>
20022f7a:	2001      	movs	r0, #1
20022f7c:	4770      	bx	lr

20022f7e <HAL_FLASH_ENABLE_OPI>:
20022f7e:	b150      	cbz	r0, 20022f96 <HAL_FLASH_ENABLE_OPI+0x18>
20022f80:	6803      	ldr	r3, [r0, #0]
20022f82:	681a      	ldr	r2, [r3, #0]
20022f84:	b121      	cbz	r1, 20022f90 <HAL_FLASH_ENABLE_OPI+0x12>
20022f86:	f442 1200 	orr.w	r2, r2, #2097152	@ 0x200000
20022f8a:	2000      	movs	r0, #0
20022f8c:	601a      	str	r2, [r3, #0]
20022f8e:	4770      	bx	lr
20022f90:	f422 1200 	bic.w	r2, r2, #2097152	@ 0x200000
20022f94:	e7f9      	b.n	20022f8a <HAL_FLASH_ENABLE_OPI+0xc>
20022f96:	2001      	movs	r0, #1
20022f98:	4770      	bx	lr

20022f9a <HAL_FLASH_ENABLE_HYPER>:
20022f9a:	b150      	cbz	r0, 20022fb2 <HAL_FLASH_ENABLE_HYPER+0x18>
20022f9c:	6803      	ldr	r3, [r0, #0]
20022f9e:	689a      	ldr	r2, [r3, #8]
20022fa0:	b121      	cbz	r1, 20022fac <HAL_FLASH_ENABLE_HYPER+0x12>
20022fa2:	f042 0210 	orr.w	r2, r2, #16
20022fa6:	2000      	movs	r0, #0
20022fa8:	609a      	str	r2, [r3, #8]
20022faa:	4770      	bx	lr
20022fac:	f022 0210 	bic.w	r2, r2, #16
20022fb0:	e7f9      	b.n	20022fa6 <HAL_FLASH_ENABLE_HYPER+0xc>
20022fb2:	2001      	movs	r0, #1
20022fb4:	4770      	bx	lr

20022fb6 <HAL_FLASH_ENABLE_CMD2>:
20022fb6:	b150      	cbz	r0, 20022fce <HAL_FLASH_ENABLE_CMD2+0x18>
20022fb8:	6803      	ldr	r3, [r0, #0]
20022fba:	681a      	ldr	r2, [r3, #0]
20022fbc:	b121      	cbz	r1, 20022fc8 <HAL_FLASH_ENABLE_CMD2+0x12>
20022fbe:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
20022fc2:	2000      	movs	r0, #0
20022fc4:	601a      	str	r2, [r3, #0]
20022fc6:	4770      	bx	lr
20022fc8:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
20022fcc:	e7f9      	b.n	20022fc2 <HAL_FLASH_ENABLE_CMD2+0xc>
20022fce:	2001      	movs	r0, #1
20022fd0:	4770      	bx	lr

20022fd2 <HAL_FLASH_STAUS_MATCH_CMD2>:
20022fd2:	b150      	cbz	r0, 20022fea <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
20022fd4:	6803      	ldr	r3, [r0, #0]
20022fd6:	681a      	ldr	r2, [r3, #0]
20022fd8:	b121      	cbz	r1, 20022fe4 <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
20022fda:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
20022fde:	2000      	movs	r0, #0
20022fe0:	601a      	str	r2, [r3, #0]
20022fe2:	4770      	bx	lr
20022fe4:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
20022fe8:	e7f9      	b.n	20022fde <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
20022fea:	2001      	movs	r0, #1
20022fec:	4770      	bx	lr

20022fee <HAL_FLASH_SET_CS_TIME>:
20022fee:	b530      	push	{r4, r5, lr}
20022ff0:	b180      	cbz	r0, 20023014 <HAL_FLASH_SET_CS_TIME+0x26>
20022ff2:	6805      	ldr	r5, [r0, #0]
20022ff4:	f8bd 000c 	ldrh.w	r0, [sp, #12]
20022ff8:	68ac      	ldr	r4, [r5, #8]
20022ffa:	0680      	lsls	r0, r0, #26
20022ffc:	ea40 5383 	orr.w	r3, r0, r3, lsl #22
20023000:	2000      	movs	r0, #0
20023002:	ea43 4181 	orr.w	r1, r3, r1, lsl #18
20023006:	f36f 149e 	bfc	r4, #6, #25
2002300a:	ea41 1282 	orr.w	r2, r1, r2, lsl #6
2002300e:	4322      	orrs	r2, r4
20023010:	60aa      	str	r2, [r5, #8]
20023012:	bd30      	pop	{r4, r5, pc}
20023014:	2001      	movs	r0, #1
20023016:	e7fc      	b.n	20023012 <HAL_FLASH_SET_CS_TIME+0x24>

20023018 <HAL_FLASH_SET_ROW_BOUNDARY>:
20023018:	b130      	cbz	r0, 20023028 <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
2002301a:	6802      	ldr	r2, [r0, #0]
2002301c:	2000      	movs	r0, #0
2002301e:	6893      	ldr	r3, [r2, #8]
20023020:	f361 0302 	bfi	r3, r1, #0, #3
20023024:	6093      	str	r3, [r2, #8]
20023026:	4770      	bx	lr
20023028:	2001      	movs	r0, #1
2002302a:	4770      	bx	lr

2002302c <HAL_FLASH_SET_LEGACY>:
2002302c:	b150      	cbz	r0, 20023044 <HAL_FLASH_SET_LEGACY+0x18>
2002302e:	6803      	ldr	r3, [r0, #0]
20023030:	689a      	ldr	r2, [r3, #8]
20023032:	b121      	cbz	r1, 2002303e <HAL_FLASH_SET_LEGACY+0x12>
20023034:	f042 0220 	orr.w	r2, r2, #32
20023038:	2000      	movs	r0, #0
2002303a:	609a      	str	r2, [r3, #8]
2002303c:	4770      	bx	lr
2002303e:	f022 0220 	bic.w	r2, r2, #32
20023042:	e7f9      	b.n	20023038 <HAL_FLASH_SET_LEGACY+0xc>
20023044:	2001      	movs	r0, #1
20023046:	4770      	bx	lr

20023048 <HAL_FLASH_SET_DUAL_MODE>:
20023048:	b150      	cbz	r0, 20023060 <HAL_FLASH_SET_DUAL_MODE+0x18>
2002304a:	6803      	ldr	r3, [r0, #0]
2002304c:	681a      	ldr	r2, [r3, #0]
2002304e:	b121      	cbz	r1, 2002305a <HAL_FLASH_SET_DUAL_MODE+0x12>
20023050:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
20023054:	2000      	movs	r0, #0
20023056:	601a      	str	r2, [r3, #0]
20023058:	4770      	bx	lr
2002305a:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
2002305e:	e7f9      	b.n	20023054 <HAL_FLASH_SET_DUAL_MODE+0xc>
20023060:	2001      	movs	r0, #1
20023062:	4770      	bx	lr

20023064 <HAL_MPI_EN_FIXLAT>:
20023064:	b150      	cbz	r0, 2002307c <HAL_MPI_EN_FIXLAT+0x18>
20023066:	6803      	ldr	r3, [r0, #0]
20023068:	689a      	ldr	r2, [r3, #8]
2002306a:	b121      	cbz	r1, 20023076 <HAL_MPI_EN_FIXLAT+0x12>
2002306c:	f042 4200 	orr.w	r2, r2, #2147483648	@ 0x80000000
20023070:	2000      	movs	r0, #0
20023072:	609a      	str	r2, [r3, #8]
20023074:	4770      	bx	lr
20023076:	f022 4200 	bic.w	r2, r2, #2147483648	@ 0x80000000
2002307a:	e7f9      	b.n	20023070 <HAL_MPI_EN_FIXLAT+0xc>
2002307c:	2001      	movs	r0, #1
2002307e:	4770      	bx	lr

20023080 <HAL_MPI_ENABLE_DQS>:
20023080:	b150      	cbz	r0, 20023098 <HAL_MPI_ENABLE_DQS+0x18>
20023082:	6803      	ldr	r3, [r0, #0]
20023084:	689a      	ldr	r2, [r3, #8]
20023086:	b121      	cbz	r1, 20023092 <HAL_MPI_ENABLE_DQS+0x12>
20023088:	f042 0208 	orr.w	r2, r2, #8
2002308c:	2000      	movs	r0, #0
2002308e:	609a      	str	r2, [r3, #8]
20023090:	4770      	bx	lr
20023092:	f022 0208 	bic.w	r2, r2, #8
20023096:	e7f9      	b.n	2002308c <HAL_MPI_ENABLE_DQS+0xc>
20023098:	2001      	movs	r0, #1
2002309a:	4770      	bx	lr

2002309c <HAL_MPI_SET_DQS_DELAY>:
2002309c:	b140      	cbz	r0, 200230b0 <HAL_MPI_SET_DQS_DELAY+0x14>
2002309e:	6802      	ldr	r2, [r0, #0]
200230a0:	2000      	movs	r0, #0
200230a2:	6d93      	ldr	r3, [r2, #88]	@ 0x58
200230a4:	f423 037f 	bic.w	r3, r3, #16711680	@ 0xff0000
200230a8:	ea43 4101 	orr.w	r1, r3, r1, lsl #16
200230ac:	6591      	str	r1, [r2, #88]	@ 0x58
200230ae:	4770      	bx	lr
200230b0:	2001      	movs	r0, #1
200230b2:	4770      	bx	lr

200230b4 <HAL_MPI_SET_SCK>:
200230b4:	b160      	cbz	r0, 200230d0 <HAL_MPI_SET_SCK+0x1c>
200230b6:	6800      	ldr	r0, [r0, #0]
200230b8:	0652      	lsls	r2, r2, #25
200230ba:	6d83      	ldr	r3, [r0, #88]	@ 0x58
200230bc:	ea42 2101 	orr.w	r1, r2, r1, lsl #8
200230c0:	f023 7300 	bic.w	r3, r3, #33554432	@ 0x2000000
200230c4:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
200230c8:	4319      	orrs	r1, r3
200230ca:	6581      	str	r1, [r0, #88]	@ 0x58
200230cc:	2000      	movs	r0, #0
200230ce:	4770      	bx	lr
200230d0:	2001      	movs	r0, #1
200230d2:	4770      	bx	lr

200230d4 <HAL_MPI_CFG_DTR>:
200230d4:	b510      	push	{r4, lr}
200230d6:	b1f0      	cbz	r0, 20023116 <HAL_MPI_CFG_DTR+0x42>
200230d8:	6804      	ldr	r4, [r0, #0]
200230da:	6da0      	ldr	r0, [r4, #88]	@ 0x58
200230dc:	b1b1      	cbz	r1, 2002310c <HAL_MPI_CFG_DTR+0x38>
200230de:	2a02      	cmp	r2, #2
200230e0:	bf84      	itt	hi
200230e2:	3a02      	subhi	r2, #2
200230e4:	b2d2      	uxtbhi	r2, r2
200230e6:	0213      	lsls	r3, r2, #8
200230e8:	f36f 000f 	bfc	r0, #0, #16
200230ec:	f403 43fe 	and.w	r3, r3, #32512	@ 0x7f00
200230f0:	4303      	orrs	r3, r0
200230f2:	0612      	lsls	r2, r2, #24
200230f4:	bf54      	ite	pl
200230f6:	f043 6380 	orrpl.w	r3, r3, #67108864	@ 0x4000000
200230fa:	f043 63a0 	orrmi.w	r3, r3, #83886080	@ 0x5000000
200230fe:	f043 030a 	orr.w	r3, r3, #10
20023102:	f023 7300 	bic.w	r3, r3, #33554432	@ 0x2000000
20023106:	2000      	movs	r0, #0
20023108:	65a3      	str	r3, [r4, #88]	@ 0x58
2002310a:	bd10      	pop	{r4, pc}
2002310c:	4b03      	ldr	r3, [pc, #12]	@ (2002311c <HAL_MPI_CFG_DTR+0x48>)
2002310e:	4003      	ands	r3, r0
20023110:	f043 7300 	orr.w	r3, r3, #33554432	@ 0x2000000
20023114:	e7f7      	b.n	20023106 <HAL_MPI_CFG_DTR+0x32>
20023116:	2001      	movs	r0, #1
20023118:	e7f7      	b.n	2002310a <HAL_MPI_CFG_DTR+0x36>
2002311a:	bf00      	nop
2002311c:	faff0000 	.word	0xfaff0000

20023120 <HAL_MPI_MODIFY_RCMD_DELAY>:
20023120:	b130      	cbz	r0, 20023130 <HAL_MPI_MODIFY_RCMD_DELAY+0x10>
20023122:	6802      	ldr	r2, [r0, #0]
20023124:	6c93      	ldr	r3, [r2, #72]	@ 0x48
20023126:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
2002312a:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
2002312e:	6491      	str	r1, [r2, #72]	@ 0x48
20023130:	4770      	bx	lr

20023132 <HAL_MPI_MODIFY_WCMD_DELAY>:
20023132:	b130      	cbz	r0, 20023142 <HAL_MPI_MODIFY_WCMD_DELAY+0x10>
20023134:	6802      	ldr	r2, [r0, #0]
20023136:	6d13      	ldr	r3, [r2, #80]	@ 0x50
20023138:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
2002313c:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
20023140:	6511      	str	r1, [r2, #80]	@ 0x50
20023142:	4770      	bx	lr

20023144 <HAL_FLASH_CONFIG_AHB_READ>:
20023144:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20023146:	4605      	mov	r5, r0
20023148:	2800      	cmp	r0, #0
2002314a:	d03d      	beq.n	200231c8 <HAL_FLASH_CONFIG_AHB_READ+0x84>
2002314c:	68c4      	ldr	r4, [r0, #12]
2002314e:	b301      	cbz	r1, 20023192 <HAL_FLASH_CONFIG_AHB_READ+0x4e>
20023150:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
20023154:	2b00      	cmp	r3, #0
20023156:	d037      	beq.n	200231c8 <HAL_FLASH_CONFIG_AHB_READ+0x84>
20023158:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
2002315c:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
20023160:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
20023164:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
20023168:	9603      	str	r6, [sp, #12]
2002316a:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
2002316e:	9602      	str	r6, [sp, #8]
20023170:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
20023174:	9601      	str	r6, [sp, #4]
20023176:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
2002317a:	9400      	str	r4, [sp, #0]
2002317c:	f7ff fd9e 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20023180:	68eb      	ldr	r3, [r5, #12]
20023182:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
20023186:	4628      	mov	r0, r5
20023188:	f7ff fd8d 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
2002318c:	2000      	movs	r0, #0
2002318e:	b004      	add	sp, #16
20023190:	bd70      	pop	{r4, r5, r6, pc}
20023192:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
20023196:	b1bb      	cbz	r3, 200231c8 <HAL_FLASH_CONFIG_AHB_READ+0x84>
20023198:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
2002319c:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
200231a0:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
200231a4:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
200231a8:	9603      	str	r6, [sp, #12]
200231aa:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
200231ae:	9602      	str	r6, [sp, #8]
200231b0:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
200231b4:	9601      	str	r6, [sp, #4]
200231b6:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
200231ba:	9400      	str	r4, [sp, #0]
200231bc:	f7ff fd7e 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
200231c0:	68eb      	ldr	r3, [r5, #12]
200231c2:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
200231c6:	e7de      	b.n	20023186 <HAL_FLASH_CONFIG_AHB_READ+0x42>
200231c8:	2001      	movs	r0, #1
200231ca:	e7e0      	b.n	2002318e <HAL_FLASH_CONFIG_AHB_READ+0x4a>

200231cc <HAL_FLASH_CONFIG_FULL_AHB_READ>:
200231cc:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200231ce:	4605      	mov	r5, r0
200231d0:	2800      	cmp	r0, #0
200231d2:	d036      	beq.n	20023242 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
200231d4:	68c4      	ldr	r4, [r0, #12]
200231d6:	b1e1      	cbz	r1, 20023212 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
200231d8:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
200231dc:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
200231e0:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
200231e4:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
200231e8:	9603      	str	r6, [sp, #12]
200231ea:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
200231ee:	9602      	str	r6, [sp, #8]
200231f0:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
200231f4:	9601      	str	r6, [sp, #4]
200231f6:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
200231fa:	9400      	str	r4, [sp, #0]
200231fc:	f7ff fd5e 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20023200:	68eb      	ldr	r3, [r5, #12]
20023202:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
20023206:	4628      	mov	r0, r5
20023208:	f7ff fd4d 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
2002320c:	2000      	movs	r0, #0
2002320e:	b004      	add	sp, #16
20023210:	bd70      	pop	{r4, r5, r6, pc}
20023212:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
20023216:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
2002321a:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
2002321e:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
20023222:	9603      	str	r6, [sp, #12]
20023224:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
20023228:	9602      	str	r6, [sp, #8]
2002322a:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
2002322e:	9601      	str	r6, [sp, #4]
20023230:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
20023234:	9400      	str	r4, [sp, #0]
20023236:	f7ff fd41 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
2002323a:	68eb      	ldr	r3, [r5, #12]
2002323c:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
20023240:	e7e1      	b.n	20023206 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
20023242:	2001      	movs	r0, #1
20023244:	e7e3      	b.n	2002320e <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

20023246 <HAL_FLASH_PRE_CMD>:
20023246:	b530      	push	{r4, r5, lr}
20023248:	68c4      	ldr	r4, [r0, #12]
2002324a:	b087      	sub	sp, #28
2002324c:	b304      	cbz	r4, 20023290 <HAL_FLASH_PRE_CMD+0x4a>
2002324e:	2938      	cmp	r1, #56	@ 0x38
20023250:	d81e      	bhi.n	20023290 <HAL_FLASH_PRE_CMD+0x4a>
20023252:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
20023256:	440c      	add	r4, r1
20023258:	7c23      	ldrb	r3, [r4, #16]
2002325a:	b1cb      	cbz	r3, 20023290 <HAL_FLASH_PRE_CMD+0x4a>
2002325c:	f994 5018 	ldrsb.w	r5, [r4, #24]
20023260:	f994 3013 	ldrsb.w	r3, [r4, #19]
20023264:	f994 2012 	ldrsb.w	r2, [r4, #18]
20023268:	f994 1011 	ldrsb.w	r1, [r4, #17]
2002326c:	9504      	str	r5, [sp, #16]
2002326e:	f994 5017 	ldrsb.w	r5, [r4, #23]
20023272:	9503      	str	r5, [sp, #12]
20023274:	f994 5016 	ldrsb.w	r5, [r4, #22]
20023278:	9502      	str	r5, [sp, #8]
2002327a:	f994 5015 	ldrsb.w	r5, [r4, #21]
2002327e:	9501      	str	r5, [sp, #4]
20023280:	f994 4014 	ldrsb.w	r4, [r4, #20]
20023284:	9400      	str	r4, [sp, #0]
20023286:	f7ff fdd0 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
2002328a:	2000      	movs	r0, #0
2002328c:	b007      	add	sp, #28
2002328e:	bd30      	pop	{r4, r5, pc}
20023290:	2001      	movs	r0, #1
20023292:	e7fb      	b.n	2002328c <HAL_FLASH_PRE_CMD+0x46>

20023294 <HAL_FLASH_ISSUE_CMD>:
20023294:	b5f0      	push	{r4, r5, r6, r7, lr}
20023296:	68c4      	ldr	r4, [r0, #12]
20023298:	4606      	mov	r6, r0
2002329a:	4617      	mov	r7, r2
2002329c:	b087      	sub	sp, #28
2002329e:	b354      	cbz	r4, 200232f6 <HAL_FLASH_ISSUE_CMD+0x62>
200232a0:	2938      	cmp	r1, #56	@ 0x38
200232a2:	d828      	bhi.n	200232f6 <HAL_FLASH_ISSUE_CMD+0x62>
200232a4:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
200232a8:	442c      	add	r4, r5
200232aa:	7c23      	ldrb	r3, [r4, #16]
200232ac:	b31b      	cbz	r3, 200232f6 <HAL_FLASH_ISSUE_CMD+0x62>
200232ae:	f994 c018 	ldrsb.w	ip, [r4, #24]
200232b2:	f994 3013 	ldrsb.w	r3, [r4, #19]
200232b6:	f994 2012 	ldrsb.w	r2, [r4, #18]
200232ba:	f994 1011 	ldrsb.w	r1, [r4, #17]
200232be:	f8cd c010 	str.w	ip, [sp, #16]
200232c2:	f994 c017 	ldrsb.w	ip, [r4, #23]
200232c6:	f8cd c00c 	str.w	ip, [sp, #12]
200232ca:	f994 c016 	ldrsb.w	ip, [r4, #22]
200232ce:	f8cd c008 	str.w	ip, [sp, #8]
200232d2:	f994 c015 	ldrsb.w	ip, [r4, #21]
200232d6:	f8cd c004 	str.w	ip, [sp, #4]
200232da:	f994 4014 	ldrsb.w	r4, [r4, #20]
200232de:	9400      	str	r4, [sp, #0]
200232e0:	f7ff fda3 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
200232e4:	68f3      	ldr	r3, [r6, #12]
200232e6:	463a      	mov	r2, r7
200232e8:	442b      	add	r3, r5
200232ea:	4630      	mov	r0, r6
200232ec:	7c19      	ldrb	r1, [r3, #16]
200232ee:	f7ff fd57 	bl	20022da0 <HAL_FLASH_SET_CMD>
200232f2:	b007      	add	sp, #28
200232f4:	bdf0      	pop	{r4, r5, r6, r7, pc}
200232f6:	2001      	movs	r0, #1
200232f8:	e7fb      	b.n	200232f2 <HAL_FLASH_ISSUE_CMD+0x5e>

200232fa <HAL_FLASH_ISSUE_CMD_SEQ>:
200232fa:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200232fe:	4690      	mov	r8, r2
20023300:	68c2      	ldr	r2, [r0, #12]
20023302:	4604      	mov	r4, r0
20023304:	b086      	sub	sp, #24
20023306:	2a00      	cmp	r2, #0
20023308:	d072      	beq.n	200233f0 <HAL_FLASH_ISSUE_CMD_SEQ+0xf6>
2002330a:	2938      	cmp	r1, #56	@ 0x38
2002330c:	d870      	bhi.n	200233f0 <HAL_FLASH_ISSUE_CMD_SEQ+0xf6>
2002330e:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
20023312:	19d6      	adds	r6, r2, r7
20023314:	7c31      	ldrb	r1, [r6, #16]
20023316:	2900      	cmp	r1, #0
20023318:	d06a      	beq.n	200233f0 <HAL_FLASH_ISSUE_CMD_SEQ+0xf6>
2002331a:	2b38      	cmp	r3, #56	@ 0x38
2002331c:	d868      	bhi.n	200233f0 <HAL_FLASH_ISSUE_CMD_SEQ+0xf6>
2002331e:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
20023322:	442a      	add	r2, r5
20023324:	7c13      	ldrb	r3, [r2, #16]
20023326:	2b00      	cmp	r3, #0
20023328:	d062      	beq.n	200233f0 <HAL_FLASH_ISSUE_CMD_SEQ+0xf6>
2002332a:	f996 c018 	ldrsb.w	ip, [r6, #24]
2002332e:	f996 3013 	ldrsb.w	r3, [r6, #19]
20023332:	f996 2012 	ldrsb.w	r2, [r6, #18]
20023336:	f996 1011 	ldrsb.w	r1, [r6, #17]
2002333a:	f8cd c010 	str.w	ip, [sp, #16]
2002333e:	f996 c017 	ldrsb.w	ip, [r6, #23]
20023342:	f8cd c00c 	str.w	ip, [sp, #12]
20023346:	f996 c016 	ldrsb.w	ip, [r6, #22]
2002334a:	f8cd c008 	str.w	ip, [sp, #8]
2002334e:	f996 c015 	ldrsb.w	ip, [r6, #21]
20023352:	f8cd c004 	str.w	ip, [sp, #4]
20023356:	f996 6014 	ldrsb.w	r6, [r6, #20]
2002335a:	9600      	str	r6, [sp, #0]
2002335c:	f7ff fd65 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
20023360:	68e0      	ldr	r0, [r4, #12]
20023362:	4428      	add	r0, r5
20023364:	f990 6018 	ldrsb.w	r6, [r0, #24]
20023368:	f990 3013 	ldrsb.w	r3, [r0, #19]
2002336c:	f990 2012 	ldrsb.w	r2, [r0, #18]
20023370:	f990 1011 	ldrsb.w	r1, [r0, #17]
20023374:	9604      	str	r6, [sp, #16]
20023376:	f990 6017 	ldrsb.w	r6, [r0, #23]
2002337a:	9603      	str	r6, [sp, #12]
2002337c:	f990 6016 	ldrsb.w	r6, [r0, #22]
20023380:	9602      	str	r6, [sp, #8]
20023382:	f990 6015 	ldrsb.w	r6, [r0, #21]
20023386:	9601      	str	r6, [sp, #4]
20023388:	f990 0014 	ldrsb.w	r0, [r0, #20]
2002338c:	9000      	str	r0, [sp, #0]
2002338e:	4620      	mov	r0, r4
20023390:	f7ff fd6c 	bl	20022e6c <HAL_FLASH_MANUAL_CMD2>
20023394:	2200      	movs	r2, #0
20023396:	6823      	ldr	r3, [r4, #0]
20023398:	2101      	movs	r1, #1
2002339a:	67da      	str	r2, [r3, #124]	@ 0x7c
2002339c:	68e3      	ldr	r3, [r4, #12]
2002339e:	6822      	ldr	r2, [r4, #0]
200233a0:	442b      	add	r3, r5
200233a2:	7c1b      	ldrb	r3, [r3, #16]
200233a4:	4620      	mov	r0, r4
200233a6:	62d3      	str	r3, [r2, #44]	@ 0x2c
200233a8:	6823      	ldr	r3, [r4, #0]
200233aa:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
200233ac:	f8c3 2080 	str.w	r2, [r3, #128]	@ 0x80
200233b0:	f7ff fe01 	bl	20022fb6 <HAL_FLASH_ENABLE_CMD2>
200233b4:	4620      	mov	r0, r4
200233b6:	f7ff fe0c 	bl	20022fd2 <HAL_FLASH_STAUS_MATCH_CMD2>
200233ba:	6823      	ldr	r3, [r4, #0]
200233bc:	f8c3 801c 	str.w	r8, [r3, #28]
200233c0:	68e3      	ldr	r3, [r4, #12]
200233c2:	6822      	ldr	r2, [r4, #0]
200233c4:	443b      	add	r3, r7
200233c6:	7c1b      	ldrb	r3, [r3, #16]
200233c8:	6193      	str	r3, [r2, #24]
200233ca:	4620      	mov	r0, r4
200233cc:	f7ff fd0a 	bl	20022de4 <HAL_FLASH_STATUS_MATCH>
200233d0:	2800      	cmp	r0, #0
200233d2:	d0fa      	beq.n	200233ca <HAL_FLASH_ISSUE_CMD_SEQ+0xd0>
200233d4:	2109      	movs	r1, #9
200233d6:	4620      	mov	r0, r4
200233d8:	f7ff fcfe 	bl	20022dd8 <HAL_FLASH_CLR_STATUS>
200233dc:	2100      	movs	r1, #0
200233de:	f7ff fdea 	bl	20022fb6 <HAL_FLASH_ENABLE_CMD2>
200233e2:	4620      	mov	r0, r4
200233e4:	f7ff fdf5 	bl	20022fd2 <HAL_FLASH_STAUS_MATCH_CMD2>
200233e8:	4608      	mov	r0, r1
200233ea:	b006      	add	sp, #24
200233ec:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200233f0:	2001      	movs	r0, #1
200233f2:	e7fa      	b.n	200233ea <HAL_FLASH_ISSUE_CMD_SEQ+0xf0>

200233f4 <nor_qspi_switch>:
200233f4:	b570      	push	{r4, r5, r6, lr}
200233f6:	4604      	mov	r4, r0
200233f8:	b3e0      	cbz	r0, 20023474 <nor_qspi_switch+0x80>
200233fa:	68c3      	ldr	r3, [r0, #12]
200233fc:	b3d3      	cbz	r3, 20023474 <nor_qspi_switch+0x80>
200233fe:	b3c9      	cbz	r1, 20023474 <nor_qspi_switch+0x80>
20023400:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20023404:	2101      	movs	r1, #1
20023406:	b3b5      	cbz	r5, 20023476 <nor_qspi_switch+0x82>
20023408:	f7ff fca5 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002340c:	2200      	movs	r2, #0
2002340e:	2114      	movs	r1, #20
20023410:	4620      	mov	r0, r4
20023412:	f7ff ff3f 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023416:	4620      	mov	r0, r4
20023418:	f7ff fcf3 	bl	20022e02 <HAL_FLASH_READ32>
2002341c:	f010 0501 	ands.w	r5, r0, #1
20023420:	d000      	beq.n	20023424 <nor_qspi_switch+0x30>
20023422:	e7fe      	b.n	20023422 <nor_qspi_switch+0x2e>
20023424:	462a      	mov	r2, r5
20023426:	2115      	movs	r1, #21
20023428:	4620      	mov	r0, r4
2002342a:	f7ff ff33 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
2002342e:	4606      	mov	r6, r0
20023430:	b120      	cbz	r0, 2002343c <nor_qspi_switch+0x48>
20023432:	462a      	mov	r2, r5
20023434:	4629      	mov	r1, r5
20023436:	4620      	mov	r0, r4
20023438:	f7ff ff2c 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
2002343c:	2102      	movs	r1, #2
2002343e:	4620      	mov	r0, r4
20023440:	f7ff fc82 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023444:	2101      	movs	r1, #1
20023446:	4620      	mov	r0, r4
20023448:	f7ff fc85 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002344c:	2200      	movs	r2, #0
2002344e:	212b      	movs	r1, #43	@ 0x2b
20023450:	4620      	mov	r0, r4
20023452:	f7ff ff1f 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023456:	b16e      	cbz	r6, 20023474 <nor_qspi_switch+0x80>
20023458:	2101      	movs	r1, #1
2002345a:	4620      	mov	r0, r4
2002345c:	f7ff fc7b 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023460:	2200      	movs	r2, #0
20023462:	2102      	movs	r1, #2
20023464:	4620      	mov	r0, r4
20023466:	f7ff ff15 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
2002346a:	4620      	mov	r0, r4
2002346c:	f7ff fcc0 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
20023470:	2800      	cmp	r0, #0
20023472:	d0f5      	beq.n	20023460 <nor_qspi_switch+0x6c>
20023474:	bd70      	pop	{r4, r5, r6, pc}
20023476:	f7ff fc6e 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002347a:	462a      	mov	r2, r5
2002347c:	2102      	movs	r1, #2
2002347e:	4620      	mov	r0, r4
20023480:	f7ff ff08 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023484:	4620      	mov	r0, r4
20023486:	f7ff fcbc 	bl	20022e02 <HAL_FLASH_READ32>
2002348a:	462a      	mov	r2, r5
2002348c:	2114      	movs	r1, #20
2002348e:	4620      	mov	r0, r4
20023490:	f7ff ff00 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023494:	b910      	cbnz	r0, 2002349c <nor_qspi_switch+0xa8>
20023496:	4620      	mov	r0, r4
20023498:	f7ff fcb3 	bl	20022e02 <HAL_FLASH_READ32>
2002349c:	68e3      	ldr	r3, [r4, #12]
2002349e:	7a1b      	ldrb	r3, [r3, #8]
200234a0:	b3ab      	cbz	r3, 2002350e <nor_qspi_switch+0x11a>
200234a2:	2101      	movs	r1, #1
200234a4:	f003 050f 	and.w	r5, r3, #15
200234a8:	091b      	lsrs	r3, r3, #4
200234aa:	fa01 f303 	lsl.w	r3, r1, r3
200234ae:	b2db      	uxtb	r3, r3
200234b0:	b10d      	cbz	r5, 200234b6 <nor_qspi_switch+0xc2>
200234b2:	461d      	mov	r5, r3
200234b4:	2300      	movs	r3, #0
200234b6:	2200      	movs	r2, #0
200234b8:	2115      	movs	r1, #21
200234ba:	4620      	mov	r0, r4
200234bc:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
200234c0:	f7ff fee8 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200234c4:	4606      	mov	r6, r0
200234c6:	b120      	cbz	r0, 200234d2 <nor_qspi_switch+0xde>
200234c8:	2200      	movs	r2, #0
200234ca:	4620      	mov	r0, r4
200234cc:	4611      	mov	r1, r2
200234ce:	f7ff fee1 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200234d2:	4629      	mov	r1, r5
200234d4:	4620      	mov	r0, r4
200234d6:	f7ff fc37 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
200234da:	2102      	movs	r1, #2
200234dc:	4620      	mov	r0, r4
200234de:	f7ff fc3a 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200234e2:	2200      	movs	r2, #0
200234e4:	2103      	movs	r1, #3
200234e6:	4620      	mov	r0, r4
200234e8:	f7ff fed4 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200234ec:	2e00      	cmp	r6, #0
200234ee:	d0c1      	beq.n	20023474 <nor_qspi_switch+0x80>
200234f0:	2101      	movs	r1, #1
200234f2:	4620      	mov	r0, r4
200234f4:	f7ff fc2f 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200234f8:	2200      	movs	r2, #0
200234fa:	2102      	movs	r1, #2
200234fc:	4620      	mov	r0, r4
200234fe:	f7ff fec9 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023502:	4620      	mov	r0, r4
20023504:	f7ff fc74 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
20023508:	2800      	cmp	r0, #0
2002350a:	d0f5      	beq.n	200234f8 <nor_qspi_switch+0x104>
2002350c:	e7b2      	b.n	20023474 <nor_qspi_switch+0x80>
2002350e:	2502      	movs	r5, #2
20023510:	e7d1      	b.n	200234b6 <nor_qspi_switch+0xc2>

20023512 <HAL_FLASH_SET_QUAL_SPI>:
20023512:	b538      	push	{r3, r4, r5, lr}
20023514:	4604      	mov	r4, r0
20023516:	460d      	mov	r5, r1
20023518:	f7ff ff6c 	bl	200233f4 <nor_qspi_switch>
2002351c:	4629      	mov	r1, r5
2002351e:	4620      	mov	r0, r4
20023520:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20023524:	f7ff be0e 	b.w	20023144 <HAL_FLASH_CONFIG_AHB_READ>

20023528 <HAL_FLASH_FADDR_SET_QSPI>:
20023528:	b538      	push	{r3, r4, r5, lr}
2002352a:	4604      	mov	r4, r0
2002352c:	460d      	mov	r5, r1
2002352e:	f7ff ff61 	bl	200233f4 <nor_qspi_switch>
20023532:	4629      	mov	r1, r5
20023534:	4620      	mov	r0, r4
20023536:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
2002353a:	f7ff be47 	b.w	200231cc <HAL_FLASH_CONFIG_FULL_AHB_READ>

2002353e <HAL_FLASH_GET_NOR_ID>:
2002353e:	b510      	push	{r4, lr}
20023540:	4604      	mov	r4, r0
20023542:	b140      	cbz	r0, 20023556 <HAL_FLASH_GET_NOR_ID+0x18>
20023544:	6802      	ldr	r2, [r0, #0]
20023546:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20023548:	f36f 0315 	bfc	r3, #0, #22
2002354c:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
20023550:	f043 0301 	orr.w	r3, r3, #1
20023554:	6293      	str	r3, [r2, #40]	@ 0x28
20023556:	2103      	movs	r1, #3
20023558:	4620      	mov	r0, r4
2002355a:	f7ff fbfc 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002355e:	2200      	movs	r2, #0
20023560:	219f      	movs	r1, #159	@ 0x9f
20023562:	4620      	mov	r0, r4
20023564:	f7ff fc1c 	bl	20022da0 <HAL_FLASH_SET_CMD>
20023568:	4620      	mov	r0, r4
2002356a:	f7ff fc4a 	bl	20022e02 <HAL_FLASH_READ32>
2002356e:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20023572:	bd10      	pop	{r4, pc}

20023574 <HAL_FLASH_CLR_PROTECT>:
20023574:	b570      	push	{r4, r5, r6, lr}
20023576:	4604      	mov	r4, r0
20023578:	2800      	cmp	r0, #0
2002357a:	d03e      	beq.n	200235fa <HAL_FLASH_CLR_PROTECT+0x86>
2002357c:	68c3      	ldr	r3, [r0, #12]
2002357e:	2101      	movs	r1, #1
20023580:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20023584:	2d00      	cmp	r5, #0
20023586:	d03b      	beq.n	20023600 <HAL_FLASH_CLR_PROTECT+0x8c>
20023588:	f7ff fbe5 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002358c:	2200      	movs	r2, #0
2002358e:	2102      	movs	r1, #2
20023590:	4620      	mov	r0, r4
20023592:	f7ff fe7f 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023596:	bb88      	cbnz	r0, 200235fc <HAL_FLASH_CLR_PROTECT+0x88>
20023598:	4620      	mov	r0, r4
2002359a:	f7ff fc32 	bl	20022e02 <HAL_FLASH_READ32>
2002359e:	b2c0      	uxtb	r0, r0
200235a0:	68e3      	ldr	r3, [r4, #12]
200235a2:	79dd      	ldrb	r5, [r3, #7]
200235a4:	b10d      	cbz	r5, 200235aa <HAL_FLASH_CLR_PROTECT+0x36>
200235a6:	ea20 0505 	bic.w	r5, r0, r5
200235aa:	2200      	movs	r2, #0
200235ac:	2115      	movs	r1, #21
200235ae:	4620      	mov	r0, r4
200235b0:	f7ff fe70 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200235b4:	4606      	mov	r6, r0
200235b6:	b120      	cbz	r0, 200235c2 <HAL_FLASH_CLR_PROTECT+0x4e>
200235b8:	2200      	movs	r2, #0
200235ba:	4620      	mov	r0, r4
200235bc:	4611      	mov	r1, r2
200235be:	f7ff fe69 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200235c2:	4629      	mov	r1, r5
200235c4:	4620      	mov	r0, r4
200235c6:	f7ff fbbf 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
200235ca:	2101      	movs	r1, #1
200235cc:	4620      	mov	r0, r4
200235ce:	f7ff fbc2 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200235d2:	2200      	movs	r2, #0
200235d4:	2103      	movs	r1, #3
200235d6:	4620      	mov	r0, r4
200235d8:	f7ff fe5c 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200235dc:	b16e      	cbz	r6, 200235fa <HAL_FLASH_CLR_PROTECT+0x86>
200235de:	2101      	movs	r1, #1
200235e0:	4620      	mov	r0, r4
200235e2:	f7ff fbb8 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200235e6:	2200      	movs	r2, #0
200235e8:	2102      	movs	r1, #2
200235ea:	4620      	mov	r0, r4
200235ec:	f7ff fe52 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200235f0:	4620      	mov	r0, r4
200235f2:	f7ff fbfd 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
200235f6:	2800      	cmp	r0, #0
200235f8:	d0f5      	beq.n	200235e6 <HAL_FLASH_CLR_PROTECT+0x72>
200235fa:	bd70      	pop	{r4, r5, r6, pc}
200235fc:	2000      	movs	r0, #0
200235fe:	e7cf      	b.n	200235a0 <HAL_FLASH_CLR_PROTECT+0x2c>
20023600:	f7ff fba9 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023604:	462a      	mov	r2, r5
20023606:	2102      	movs	r1, #2
20023608:	4620      	mov	r0, r4
2002360a:	f7ff fe43 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
2002360e:	2800      	cmp	r0, #0
20023610:	d13e      	bne.n	20023690 <HAL_FLASH_CLR_PROTECT+0x11c>
20023612:	4620      	mov	r0, r4
20023614:	f7ff fbf5 	bl	20022e02 <HAL_FLASH_READ32>
20023618:	b2c6      	uxtb	r6, r0
2002361a:	2200      	movs	r2, #0
2002361c:	2114      	movs	r1, #20
2002361e:	4620      	mov	r0, r4
20023620:	f7ff fe38 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023624:	b918      	cbnz	r0, 2002362e <HAL_FLASH_CLR_PROTECT+0xba>
20023626:	4620      	mov	r0, r4
20023628:	f7ff fbeb 	bl	20022e02 <HAL_FLASH_READ32>
2002362c:	b2c5      	uxtb	r5, r0
2002362e:	68e3      	ldr	r3, [r4, #12]
20023630:	79d9      	ldrb	r1, [r3, #7]
20023632:	b109      	cbz	r1, 20023638 <HAL_FLASH_CLR_PROTECT+0xc4>
20023634:	ea26 0101 	bic.w	r1, r6, r1
20023638:	2200      	movs	r2, #0
2002363a:	4620      	mov	r0, r4
2002363c:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20023640:	2115      	movs	r1, #21
20023642:	f7ff fe27 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023646:	4606      	mov	r6, r0
20023648:	b120      	cbz	r0, 20023654 <HAL_FLASH_CLR_PROTECT+0xe0>
2002364a:	2200      	movs	r2, #0
2002364c:	4620      	mov	r0, r4
2002364e:	4611      	mov	r1, r2
20023650:	f7ff fe20 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023654:	4629      	mov	r1, r5
20023656:	4620      	mov	r0, r4
20023658:	f7ff fb76 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
2002365c:	2102      	movs	r1, #2
2002365e:	4620      	mov	r0, r4
20023660:	f7ff fb79 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023664:	2200      	movs	r2, #0
20023666:	2103      	movs	r1, #3
20023668:	4620      	mov	r0, r4
2002366a:	f7ff fe13 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
2002366e:	2e00      	cmp	r6, #0
20023670:	d0c3      	beq.n	200235fa <HAL_FLASH_CLR_PROTECT+0x86>
20023672:	2101      	movs	r1, #1
20023674:	4620      	mov	r0, r4
20023676:	f7ff fb6e 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002367a:	2200      	movs	r2, #0
2002367c:	2102      	movs	r1, #2
2002367e:	4620      	mov	r0, r4
20023680:	f7ff fe08 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023684:	4620      	mov	r0, r4
20023686:	f7ff fbb3 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
2002368a:	2800      	cmp	r0, #0
2002368c:	d0f5      	beq.n	2002367a <HAL_FLASH_CLR_PROTECT+0x106>
2002368e:	e7b4      	b.n	200235fa <HAL_FLASH_CLR_PROTECT+0x86>
20023690:	462e      	mov	r6, r5
20023692:	e7c2      	b.n	2002361a <HAL_FLASH_CLR_PROTECT+0xa6>

20023694 <HAL_QSPI_SET_CLK_INV>:
20023694:	b160      	cbz	r0, 200236b0 <HAL_QSPI_SET_CLK_INV+0x1c>
20023696:	6800      	ldr	r0, [r0, #0]
20023698:	b150      	cbz	r0, 200236b0 <HAL_QSPI_SET_CLK_INV+0x1c>
2002369a:	6d83      	ldr	r3, [r0, #88]	@ 0x58
2002369c:	0609      	lsls	r1, r1, #24
2002369e:	f023 7380 	bic.w	r3, r3, #16777216	@ 0x1000000
200236a2:	f001 7180 	and.w	r1, r1, #16777216	@ 0x1000000
200236a6:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
200236aa:	4311      	orrs	r1, r2
200236ac:	4319      	orrs	r1, r3
200236ae:	6581      	str	r1, [r0, #88]	@ 0x58
200236b0:	4770      	bx	lr

200236b2 <HAL_FLASH_RELEASE_DPD>:
200236b2:	b538      	push	{r3, r4, r5, lr}
200236b4:	4604      	mov	r4, r0
200236b6:	b1d0      	cbz	r0, 200236ee <HAL_FLASH_RELEASE_DPD+0x3c>
200236b8:	6803      	ldr	r3, [r0, #0]
200236ba:	21ab      	movs	r1, #171	@ 0xab
200236bc:	681d      	ldr	r5, [r3, #0]
200236be:	f015 0501 	ands.w	r5, r5, #1
200236c2:	bf02      	ittt	eq
200236c4:	681a      	ldreq	r2, [r3, #0]
200236c6:	f042 0201 	orreq.w	r2, r2, #1
200236ca:	601a      	streq	r2, [r3, #0]
200236cc:	6802      	ldr	r2, [r0, #0]
200236ce:	6a93      	ldr	r3, [r2, #40]	@ 0x28
200236d0:	f36f 0315 	bfc	r3, #0, #22
200236d4:	f043 0301 	orr.w	r3, r3, #1
200236d8:	6293      	str	r3, [r2, #40]	@ 0x28
200236da:	2200      	movs	r2, #0
200236dc:	f7ff fb60 	bl	20022da0 <HAL_FLASH_SET_CMD>
200236e0:	b925      	cbnz	r5, 200236ec <HAL_FLASH_RELEASE_DPD+0x3a>
200236e2:	6822      	ldr	r2, [r4, #0]
200236e4:	6813      	ldr	r3, [r2, #0]
200236e6:	f023 0301 	bic.w	r3, r3, #1
200236ea:	6013      	str	r3, [r2, #0]
200236ec:	bd38      	pop	{r3, r4, r5, pc}
200236ee:	2001      	movs	r0, #1
200236f0:	e7fc      	b.n	200236ec <HAL_FLASH_RELEASE_DPD+0x3a>

200236f2 <flash_handle_valid>:
200236f2:	b118      	cbz	r0, 200236fc <flash_handle_valid+0xa>
200236f4:	68c0      	ldr	r0, [r0, #12]
200236f6:	3800      	subs	r0, #0
200236f8:	bf18      	it	ne
200236fa:	2001      	movne	r0, #1
200236fc:	4770      	bx	lr

200236fe <HAL_GET_FLASH_MID>:
200236fe:	2000      	movs	r0, #0
20023700:	4770      	bx	lr

20023702 <HAL_FLASH_DMA_START>:
20023702:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20023706:	4688      	mov	r8, r1
20023708:	4699      	mov	r9, r3
2002370a:	4604      	mov	r4, r0
2002370c:	2800      	cmp	r0, #0
2002370e:	d045      	beq.n	2002379c <HAL_FLASH_DMA_START+0x9a>
20023710:	6883      	ldr	r3, [r0, #8]
20023712:	2b00      	cmp	r3, #0
20023714:	d042      	beq.n	2002379c <HAL_FLASH_DMA_START+0x9a>
20023716:	f1b9 0f00 	cmp.w	r9, #0
2002371a:	d03f      	beq.n	2002379c <HAL_FLASH_DMA_START+0x9a>
2002371c:	6801      	ldr	r1, [r0, #0]
2002371e:	680f      	ldr	r7, [r1, #0]
20023720:	b332      	cbz	r2, 20023770 <HAL_FLASH_DMA_START+0x6e>
20023722:	2210      	movs	r2, #16
20023724:	609a      	str	r2, [r3, #8]
20023726:	2300      	movs	r3, #0
20023728:	6882      	ldr	r2, [r0, #8]
2002372a:	464e      	mov	r6, r9
2002372c:	6153      	str	r3, [r2, #20]
2002372e:	6882      	ldr	r2, [r0, #8]
20023730:	6193      	str	r3, [r2, #24]
20023732:	6882      	ldr	r2, [r0, #8]
20023734:	60d3      	str	r3, [r2, #12]
20023736:	2280      	movs	r2, #128	@ 0x80
20023738:	6883      	ldr	r3, [r0, #8]
2002373a:	611a      	str	r2, [r3, #16]
2002373c:	6805      	ldr	r5, [r0, #0]
2002373e:	3504      	adds	r5, #4
20023740:	68a0      	ldr	r0, [r4, #8]
20023742:	f7ff f84b 	bl	200227dc <HAL_DMA_DeInit>
20023746:	bb50      	cbnz	r0, 2002379e <HAL_FLASH_DMA_START+0x9c>
20023748:	68a0      	ldr	r0, [r4, #8]
2002374a:	f7fe ffe3 	bl	20022714 <HAL_DMA_Init>
2002374e:	bb30      	cbnz	r0, 2002379e <HAL_FLASH_DMA_START+0x9c>
20023750:	6823      	ldr	r3, [r4, #0]
20023752:	f047 0720 	orr.w	r7, r7, #32
20023756:	601f      	str	r7, [r3, #0]
20023758:	6822      	ldr	r2, [r4, #0]
2002375a:	f109 33ff 	add.w	r3, r9, #4294967295
2002375e:	6253      	str	r3, [r2, #36]	@ 0x24
20023760:	4641      	mov	r1, r8
20023762:	4633      	mov	r3, r6
20023764:	462a      	mov	r2, r5
20023766:	68a0      	ldr	r0, [r4, #8]
20023768:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
2002376c:	f7ff b9a2 	b.w	20022ab4 <HAL_DMA_Start>
20023770:	f44f 7100 	mov.w	r1, #512	@ 0x200
20023774:	609a      	str	r2, [r3, #8]
20023776:	6883      	ldr	r3, [r0, #8]
20023778:	f109 0603 	add.w	r6, r9, #3
2002377c:	6159      	str	r1, [r3, #20]
2002377e:	f44f 6100 	mov.w	r1, #2048	@ 0x800
20023782:	6883      	ldr	r3, [r0, #8]
20023784:	4645      	mov	r5, r8
20023786:	6199      	str	r1, [r3, #24]
20023788:	6883      	ldr	r3, [r0, #8]
2002378a:	08b6      	lsrs	r6, r6, #2
2002378c:	60da      	str	r2, [r3, #12]
2002378e:	2280      	movs	r2, #128	@ 0x80
20023790:	6883      	ldr	r3, [r0, #8]
20023792:	611a      	str	r2, [r3, #16]
20023794:	6803      	ldr	r3, [r0, #0]
20023796:	f103 0804 	add.w	r8, r3, #4
2002379a:	e7d1      	b.n	20023740 <HAL_FLASH_DMA_START+0x3e>
2002379c:	2001      	movs	r0, #1
2002379e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

200237a2 <HAL_FLASH_DMA_WAIT_DONE>:
200237a2:	b510      	push	{r4, lr}
200237a4:	460a      	mov	r2, r1
200237a6:	4604      	mov	r4, r0
200237a8:	b170      	cbz	r0, 200237c8 <HAL_FLASH_DMA_WAIT_DONE+0x26>
200237aa:	6880      	ldr	r0, [r0, #8]
200237ac:	b160      	cbz	r0, 200237c8 <HAL_FLASH_DMA_WAIT_DONE+0x26>
200237ae:	6b61      	ldr	r1, [r4, #52]	@ 0x34
200237b0:	b111      	cbz	r1, 200237b8 <HAL_FLASH_DMA_WAIT_DONE+0x16>
200237b2:	f04f 32ff 	mov.w	r2, #4294967295
200237b6:	2100      	movs	r1, #0
200237b8:	f7ff f87e 	bl	200228b8 <HAL_DMA_PollForTransfer>
200237bc:	6822      	ldr	r2, [r4, #0]
200237be:	6813      	ldr	r3, [r2, #0]
200237c0:	f023 0320 	bic.w	r3, r3, #32
200237c4:	6013      	str	r3, [r2, #0]
200237c6:	bd10      	pop	{r4, pc}
200237c8:	2001      	movs	r0, #1
200237ca:	e7fc      	b.n	200237c6 <HAL_FLASH_DMA_WAIT_DONE+0x24>

200237cc <HAL_FLASH_ALIAS_CFG>:
200237cc:	b538      	push	{r3, r4, r5, lr}
200237ce:	461d      	mov	r5, r3
200237d0:	4604      	mov	r4, r0
200237d2:	b158      	cbz	r0, 200237ec <HAL_FLASH_ALIAS_CFG+0x20>
200237d4:	6903      	ldr	r3, [r0, #16]
200237d6:	428b      	cmp	r3, r1
200237d8:	bf98      	it	ls
200237da:	1ac9      	subls	r1, r1, r3
200237dc:	f7ff fb68 	bl	20022eb0 <HAL_FLASH_SET_ALIAS_RANGE>
200237e0:	4629      	mov	r1, r5
200237e2:	4620      	mov	r0, r4
200237e4:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200237e8:	f7ff bb74 	b.w	20022ed4 <HAL_FLASH_SET_ALIAS_OFFSET>
200237ec:	bd38      	pop	{r3, r4, r5, pc}

200237ee <HAL_FLASH_NONCE_CFG>:
200237ee:	b570      	push	{r4, r5, r6, lr}
200237f0:	460c      	mov	r4, r1
200237f2:	4615      	mov	r5, r2
200237f4:	4619      	mov	r1, r3
200237f6:	4606      	mov	r6, r0
200237f8:	b180      	cbz	r0, 2002381c <HAL_FLASH_NONCE_CFG+0x2e>
200237fa:	b17b      	cbz	r3, 2002381c <HAL_FLASH_NONCE_CFG+0x2e>
200237fc:	f7ff fb86 	bl	20022f0c <HAL_FLASH_SET_NONCE>
20023800:	6933      	ldr	r3, [r6, #16]
20023802:	4630      	mov	r0, r6
20023804:	42a3      	cmp	r3, r4
20023806:	bf98      	it	ls
20023808:	1ae4      	subls	r4, r4, r3
2002380a:	42ab      	cmp	r3, r5
2002380c:	bf98      	it	ls
2002380e:	1aed      	subls	r5, r5, r3
20023810:	462a      	mov	r2, r5
20023812:	4621      	mov	r1, r4
20023814:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20023818:	f7ff bb66 	b.w	20022ee8 <HAL_FLASH_SET_CTR>
2002381c:	bd70      	pop	{r4, r5, r6, pc}

2002381e <HAL_FLASH_AES_CFG>:
2002381e:	b510      	push	{r4, lr}
20023820:	4604      	mov	r4, r0
20023822:	b148      	cbz	r0, 20023838 <HAL_FLASH_AES_CFG+0x1a>
20023824:	b101      	cbz	r1, 20023828 <HAL_FLASH_AES_CFG+0xa>
20023826:	2101      	movs	r1, #1
20023828:	f7ff fb7e 	bl	20022f28 <HAL_FLASH_SET_AES>
2002382c:	4620      	mov	r0, r4
2002382e:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20023832:	2101      	movs	r1, #1
20023834:	f7ff bb87 	b.w	20022f46 <HAL_FLASH_ENABLE_AES>
20023838:	bd10      	pop	{r4, pc}

2002383a <nand_read_id>:
2002383a:	b510      	push	{r4, lr}
2002383c:	460b      	mov	r3, r1
2002383e:	4604      	mov	r4, r0
20023840:	b086      	sub	sp, #24
20023842:	b320      	cbz	r0, 2002388e <nand_read_id+0x54>
20023844:	2908      	cmp	r1, #8
20023846:	f04f 0100 	mov.w	r1, #0
2002384a:	f04f 0201 	mov.w	r2, #1
2002384e:	bf83      	ittte	hi
20023850:	460b      	movhi	r3, r1
20023852:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
20023856:	e9cd 1100 	strdhi	r1, r1, [sp]
2002385a:	e9cd 1102 	strdls	r1, r1, [sp, #8]
2002385e:	bf8e      	itee	hi
20023860:	4619      	movhi	r1, r3
20023862:	e9cd 1100 	strdls	r1, r1, [sp]
20023866:	b25b      	sxtbls	r3, r3
20023868:	9204      	str	r2, [sp, #16]
2002386a:	f7ff fade 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
2002386e:	2103      	movs	r1, #3
20023870:	4620      	mov	r0, r4
20023872:	f7ff fa70 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023876:	2200      	movs	r2, #0
20023878:	219f      	movs	r1, #159	@ 0x9f
2002387a:	4620      	mov	r0, r4
2002387c:	f7ff fa90 	bl	20022da0 <HAL_FLASH_SET_CMD>
20023880:	4620      	mov	r0, r4
20023882:	f7ff fabe 	bl	20022e02 <HAL_FLASH_READ32>
20023886:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
2002388a:	b006      	add	sp, #24
2002388c:	bd10      	pop	{r4, pc}
2002388e:	20ff      	movs	r0, #255	@ 0xff
20023890:	e7fb      	b.n	2002388a <nand_read_id+0x50>

20023892 <HAL_NAND_CONF_ECC>:
20023892:	b538      	push	{r3, r4, r5, lr}
20023894:	460d      	mov	r5, r1
20023896:	4604      	mov	r4, r0
20023898:	b398      	cbz	r0, 20023902 <HAL_NAND_CONF_ECC+0x70>
2002389a:	68c3      	ldr	r3, [r0, #12]
2002389c:	b38b      	cbz	r3, 20023902 <HAL_NAND_CONF_ECC+0x70>
2002389e:	799a      	ldrb	r2, [r3, #6]
200238a0:	b392      	cbz	r2, 20023908 <HAL_NAND_CONF_ECC+0x76>
200238a2:	7a9b      	ldrb	r3, [r3, #10]
200238a4:	b383      	cbz	r3, 20023908 <HAL_NAND_CONF_ECC+0x76>
200238a6:	2101      	movs	r1, #1
200238a8:	f7ff fa55 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200238ac:	68e3      	ldr	r3, [r4, #12]
200238ae:	2102      	movs	r1, #2
200238b0:	799a      	ldrb	r2, [r3, #6]
200238b2:	4620      	mov	r0, r4
200238b4:	f7ff fcee 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200238b8:	4620      	mov	r0, r4
200238ba:	f7ff faa2 	bl	20022e02 <HAL_FLASH_READ32>
200238be:	68e3      	ldr	r3, [r4, #12]
200238c0:	7a9b      	ldrb	r3, [r3, #10]
200238c2:	b1dd      	cbz	r5, 200238fc <HAL_NAND_CONF_ECC+0x6a>
200238c4:	ea43 0100 	orr.w	r1, r3, r0
200238c8:	4620      	mov	r0, r4
200238ca:	f7ff fa3d 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
200238ce:	2101      	movs	r1, #1
200238d0:	4620      	mov	r0, r4
200238d2:	f7ff fa40 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200238d6:	68e3      	ldr	r3, [r4, #12]
200238d8:	2103      	movs	r1, #3
200238da:	799a      	ldrb	r2, [r3, #6]
200238dc:	4620      	mov	r0, r4
200238de:	f7ff fcd9 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200238e2:	68e3      	ldr	r3, [r4, #12]
200238e4:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
200238e8:	2102      	movs	r1, #2
200238ea:	799a      	ldrb	r2, [r3, #6]
200238ec:	4620      	mov	r0, r4
200238ee:	f7ff fcd1 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200238f2:	4620      	mov	r0, r4
200238f4:	f7ff fa85 	bl	20022e02 <HAL_FLASH_READ32>
200238f8:	2000      	movs	r0, #0
200238fa:	bd38      	pop	{r3, r4, r5, pc}
200238fc:	ea20 0103 	bic.w	r1, r0, r3
20023900:	e7e2      	b.n	200238c8 <HAL_NAND_CONF_ECC+0x36>
20023902:	f04f 30ff 	mov.w	r0, #4294967295
20023906:	e7f8      	b.n	200238fa <HAL_NAND_CONF_ECC+0x68>
20023908:	f06f 0001 	mvn.w	r0, #1
2002390c:	e7f5      	b.n	200238fa <HAL_NAND_CONF_ECC+0x68>

2002390e <HAL_NAND_GET_ECC_STATUS>:
2002390e:	b510      	push	{r4, lr}
20023910:	4604      	mov	r4, r0
20023912:	b320      	cbz	r0, 2002395e <HAL_NAND_GET_ECC_STATUS+0x50>
20023914:	68c2      	ldr	r2, [r0, #12]
20023916:	b31a      	cbz	r2, 20023960 <HAL_NAND_GET_ECC_STATUS+0x52>
20023918:	7913      	ldrb	r3, [r2, #4]
2002391a:	b31b      	cbz	r3, 20023964 <HAL_NAND_GET_ECC_STATUS+0x56>
2002391c:	79d3      	ldrb	r3, [r2, #7]
2002391e:	b30b      	cbz	r3, 20023964 <HAL_NAND_GET_ECC_STATUS+0x56>
20023920:	2101      	movs	r1, #1
20023922:	f7ff fa18 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023926:	68e3      	ldr	r3, [r4, #12]
20023928:	2102      	movs	r1, #2
2002392a:	791a      	ldrb	r2, [r3, #4]
2002392c:	4620      	mov	r0, r4
2002392e:	f7ff fcb1 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023932:	4620      	mov	r0, r4
20023934:	f7ff fa65 	bl	20022e02 <HAL_FLASH_READ32>
20023938:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
2002393c:	2a3f      	cmp	r2, #63	@ 0x3f
2002393e:	ea4f 1312 	mov.w	r3, r2, lsr #4
20023942:	d804      	bhi.n	2002394e <HAL_NAND_GET_ECC_STATUS+0x40>
20023944:	2b01      	cmp	r3, #1
20023946:	d808      	bhi.n	2002395a <HAL_NAND_GET_ECC_STATUS+0x4c>
20023948:	f000 0030 	and.w	r0, r0, #48	@ 0x30
2002394c:	e007      	b.n	2002395e <HAL_NAND_GET_ECC_STATUS+0x50>
2002394e:	3b04      	subs	r3, #4
20023950:	2b01      	cmp	r3, #1
20023952:	d8f9      	bhi.n	20023948 <HAL_NAND_GET_ECC_STATUS+0x3a>
20023954:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
20023958:	e001      	b.n	2002395e <HAL_NAND_GET_ECC_STATUS+0x50>
2002395a:	f000 0070 	and.w	r0, r0, #112	@ 0x70
2002395e:	bd10      	pop	{r4, pc}
20023960:	4610      	mov	r0, r2
20023962:	e7fc      	b.n	2002395e <HAL_NAND_GET_ECC_STATUS+0x50>
20023964:	4618      	mov	r0, r3
20023966:	e7fa      	b.n	2002395e <HAL_NAND_GET_ECC_STATUS+0x50>

20023968 <HAL_NAND_CHECK_ECC>:
20023968:	4603      	mov	r3, r0
2002396a:	1108      	asrs	r0, r1, #4
2002396c:	b172      	cbz	r2, 2002398c <HAL_NAND_CHECK_ECC+0x24>
2002396e:	2b07      	cmp	r3, #7
20023970:	d80c      	bhi.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
20023972:	e8df f003 	tbb	[pc, r3]
20023976:	0d04      	.short	0x0d04
20023978:	3f352e18 	.word	0x3f352e18
2002397c:	4c47      	.short	0x4c47
2002397e:	b128      	cbz	r0, 2002398c <HAL_NAND_CHECK_ECC+0x24>
20023980:	2801      	cmp	r0, #1
20023982:	6813      	ldr	r3, [r2, #0]
20023984:	d10a      	bne.n	2002399c <HAL_NAND_CHECK_ECC+0x34>
20023986:	f043 0301 	orr.w	r3, r3, #1
2002398a:	6013      	str	r3, [r2, #0]
2002398c:	2000      	movs	r0, #0
2002398e:	4770      	bx	lr
20023990:	f020 0302 	bic.w	r3, r0, #2
20023994:	2b01      	cmp	r3, #1
20023996:	d003      	beq.n	200239a0 <HAL_NAND_CHECK_ECC+0x38>
20023998:	b1d0      	cbz	r0, 200239d0 <HAL_NAND_CHECK_ECC+0x68>
2002399a:	6813      	ldr	r3, [r2, #0]
2002399c:	4303      	orrs	r3, r0
2002399e:	e016      	b.n	200239ce <HAL_NAND_CHECK_ECC+0x66>
200239a0:	6813      	ldr	r3, [r2, #0]
200239a2:	4303      	orrs	r3, r0
200239a4:	e7f1      	b.n	2002398a <HAL_NAND_CHECK_ECC+0x22>
200239a6:	2805      	cmp	r0, #5
200239a8:	d8f7      	bhi.n	2002399a <HAL_NAND_CHECK_ECC+0x32>
200239aa:	a301      	add	r3, pc, #4	@ (adr r3, 200239b0 <HAL_NAND_CHECK_ECC+0x48>)
200239ac:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
200239b0:	2002398d 	.word	0x2002398d
200239b4:	200239a1 	.word	0x200239a1
200239b8:	200239c9 	.word	0x200239c9
200239bc:	200239a1 	.word	0x200239a1
200239c0:	2002399b 	.word	0x2002399b
200239c4:	200239a1 	.word	0x200239a1
200239c8:	6813      	ldr	r3, [r2, #0]
200239ca:	f043 0302 	orr.w	r3, r3, #2
200239ce:	6013      	str	r3, [r2, #0]
200239d0:	4770      	bx	lr
200239d2:	2800      	cmp	r0, #0
200239d4:	d0da      	beq.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
200239d6:	1e43      	subs	r3, r0, #1
200239d8:	2b05      	cmp	r3, #5
200239da:	6813      	ldr	r3, [r2, #0]
200239dc:	d9e1      	bls.n	200239a2 <HAL_NAND_CHECK_ECC+0x3a>
200239de:	e7dd      	b.n	2002399c <HAL_NAND_CHECK_ECC+0x34>
200239e0:	07c3      	lsls	r3, r0, #31
200239e2:	f000 0103 	and.w	r1, r0, #3
200239e6:	d402      	bmi.n	200239ee <HAL_NAND_CHECK_ECC+0x86>
200239e8:	2900      	cmp	r1, #0
200239ea:	d0cf      	beq.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
200239ec:	e7d5      	b.n	2002399a <HAL_NAND_CHECK_ECC+0x32>
200239ee:	6813      	ldr	r3, [r2, #0]
200239f0:	430b      	orrs	r3, r1
200239f2:	e7ca      	b.n	2002398a <HAL_NAND_CHECK_ECC+0x22>
200239f4:	2800      	cmp	r0, #0
200239f6:	d0c9      	beq.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
200239f8:	6813      	ldr	r3, [r2, #0]
200239fa:	2808      	cmp	r0, #8
200239fc:	ea43 0300 	orr.w	r3, r3, r0
20023a00:	dce5      	bgt.n	200239ce <HAL_NAND_CHECK_ECC+0x66>
20023a02:	e7c2      	b.n	2002398a <HAL_NAND_CHECK_ECC+0x22>
20023a04:	2800      	cmp	r0, #0
20023a06:	d0c1      	beq.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
20023a08:	1e43      	subs	r3, r0, #1
20023a0a:	2b01      	cmp	r3, #1
20023a0c:	e7e5      	b.n	200239da <HAL_NAND_CHECK_ECC+0x72>
20023a0e:	2800      	cmp	r0, #0
20023a10:	d0bc      	beq.n	2002398c <HAL_NAND_CHECK_ECC+0x24>
20023a12:	1e43      	subs	r3, r0, #1
20023a14:	2b02      	cmp	r3, #2
20023a16:	e7e0      	b.n	200239da <HAL_NAND_CHECK_ECC+0x72>

20023a18 <HAL_NAND_GET_ECC_RESULT>:
20023a18:	b510      	push	{r4, lr}
20023a1a:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
20023a1e:	4604      	mov	r4, r0
20023a20:	b90b      	cbnz	r3, 20023a26 <HAL_NAND_GET_ECC_RESULT+0xe>
20023a22:	2000      	movs	r0, #0
20023a24:	bd10      	pop	{r4, pc}
20023a26:	f7ff ff72 	bl	2002390e <HAL_NAND_GET_ECC_STATUS>
20023a2a:	4601      	mov	r1, r0
20023a2c:	2800      	cmp	r0, #0
20023a2e:	d0f8      	beq.n	20023a22 <HAL_NAND_GET_ECC_RESULT+0xa>
20023a30:	6862      	ldr	r2, [r4, #4]
20023a32:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
20023a34:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
20023a38:	6062      	str	r2, [r4, #4]
20023a3a:	b938      	cbnz	r0, 20023a4c <HAL_NAND_GET_ECC_RESULT+0x34>
20023a3c:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
20023a40:	1d22      	adds	r2, r4, #4
20023a42:	0900      	lsrs	r0, r0, #4
20023a44:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20023a48:	f7ff bf8e 	b.w	20023968 <HAL_NAND_CHECK_ECC>
20023a4c:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
20023a50:	ea4f 1321 	mov.w	r3, r1, asr #4
20023a54:	db00      	blt.n	20023a58 <HAL_NAND_GET_ECC_RESULT+0x40>
20023a56:	e7fe      	b.n	20023a56 <HAL_NAND_GET_ECC_RESULT+0x3e>
20023a58:	6801      	ldr	r1, [r0, #0]
20023a5a:	40d9      	lsrs	r1, r3
20023a5c:	f011 0f01 	tst.w	r1, #1
20023a60:	bf18      	it	ne
20023a62:	4618      	movne	r0, r3
20023a64:	ea43 0302 	orr.w	r3, r3, r2
20023a68:	bf08      	it	eq
20023a6a:	2000      	moveq	r0, #0
20023a6c:	6063      	str	r3, [r4, #4]
20023a6e:	e7d9      	b.n	20023a24 <HAL_NAND_GET_ECC_RESULT+0xc>

20023a70 <HAL_NAND_EN_QUAL>:
20023a70:	b538      	push	{r3, r4, r5, lr}
20023a72:	460d      	mov	r5, r1
20023a74:	4604      	mov	r4, r0
20023a76:	b348      	cbz	r0, 20023acc <HAL_NAND_EN_QUAL+0x5c>
20023a78:	68c3      	ldr	r3, [r0, #12]
20023a7a:	b33b      	cbz	r3, 20023acc <HAL_NAND_EN_QUAL+0x5c>
20023a7c:	799a      	ldrb	r2, [r3, #6]
20023a7e:	b10a      	cbz	r2, 20023a84 <HAL_NAND_EN_QUAL+0x14>
20023a80:	7a1b      	ldrb	r3, [r3, #8]
20023a82:	b90b      	cbnz	r3, 20023a88 <HAL_NAND_EN_QUAL+0x18>
20023a84:	2000      	movs	r0, #0
20023a86:	bd38      	pop	{r3, r4, r5, pc}
20023a88:	2101      	movs	r1, #1
20023a8a:	f7ff f964 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023a8e:	68e3      	ldr	r3, [r4, #12]
20023a90:	2102      	movs	r1, #2
20023a92:	799a      	ldrb	r2, [r3, #6]
20023a94:	4620      	mov	r0, r4
20023a96:	f7ff fbfd 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023a9a:	4620      	mov	r0, r4
20023a9c:	f7ff f9b1 	bl	20022e02 <HAL_FLASH_READ32>
20023aa0:	68e3      	ldr	r3, [r4, #12]
20023aa2:	7a1b      	ldrb	r3, [r3, #8]
20023aa4:	b17d      	cbz	r5, 20023ac6 <HAL_NAND_EN_QUAL+0x56>
20023aa6:	ea43 0100 	orr.w	r1, r3, r0
20023aaa:	4620      	mov	r0, r4
20023aac:	f7ff f94c 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023ab0:	2101      	movs	r1, #1
20023ab2:	4620      	mov	r0, r4
20023ab4:	f7ff f94f 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023ab8:	68e3      	ldr	r3, [r4, #12]
20023aba:	2103      	movs	r1, #3
20023abc:	4620      	mov	r0, r4
20023abe:	799a      	ldrb	r2, [r3, #6]
20023ac0:	f7ff fbe8 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023ac4:	e7de      	b.n	20023a84 <HAL_NAND_EN_QUAL+0x14>
20023ac6:	ea20 0103 	bic.w	r1, r0, r3
20023aca:	e7ee      	b.n	20023aaa <HAL_NAND_EN_QUAL+0x3a>
20023acc:	f04f 30ff 	mov.w	r0, #4294967295
20023ad0:	e7d9      	b.n	20023a86 <HAL_NAND_EN_QUAL+0x16>

20023ad2 <nand_clear_status>:
20023ad2:	b538      	push	{r3, r4, r5, lr}
20023ad4:	460d      	mov	r5, r1
20023ad6:	2101      	movs	r1, #1
20023ad8:	4604      	mov	r4, r0
20023ada:	f7ff f93c 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023ade:	2dc9      	cmp	r5, #201	@ 0xc9
20023ae0:	d001      	beq.n	20023ae6 <nand_clear_status+0x14>
20023ae2:	2d01      	cmp	r5, #1
20023ae4:	d109      	bne.n	20023afa <nand_clear_status+0x28>
20023ae6:	2102      	movs	r1, #2
20023ae8:	4620      	mov	r0, r4
20023aea:	f7ff f92d 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023aee:	68e3      	ldr	r3, [r4, #12]
20023af0:	2103      	movs	r1, #3
20023af2:	4620      	mov	r0, r4
20023af4:	795a      	ldrb	r2, [r3, #5]
20023af6:	f7ff fbcd 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023afa:	2100      	movs	r1, #0
20023afc:	4620      	mov	r0, r4
20023afe:	f7ff f923 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023b02:	68e3      	ldr	r3, [r4, #12]
20023b04:	2103      	movs	r1, #3
20023b06:	4620      	mov	r0, r4
20023b08:	795a      	ldrb	r2, [r3, #5]
20023b0a:	f7ff fbc3 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023b0e:	2000      	movs	r0, #0
20023b10:	bd38      	pop	{r3, r4, r5, pc}

20023b12 <HAL_NAND_PAGE_SIZE>:
20023b12:	b140      	cbz	r0, 20023b26 <HAL_NAND_PAGE_SIZE+0x14>
20023b14:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
20023b18:	f013 0f01 	tst.w	r3, #1
20023b1c:	bf14      	ite	ne
20023b1e:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
20023b22:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
20023b26:	4770      	bx	lr

20023b28 <HAL_NAND_READ_WITHOOB>:
20023b28:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023b2c:	b085      	sub	sp, #20
20023b2e:	460e      	mov	r6, r1
20023b30:	4691      	mov	r9, r2
20023b32:	461d      	mov	r5, r3
20023b34:	4604      	mov	r4, r0
20023b36:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
20023b38:	b1b0      	cbz	r0, 20023b68 <HAL_NAND_READ_WITHOOB+0x40>
20023b3a:	68c3      	ldr	r3, [r0, #12]
20023b3c:	b1a3      	cbz	r3, 20023b68 <HAL_NAND_READ_WITHOOB+0x40>
20023b3e:	69c3      	ldr	r3, [r0, #28]
20023b40:	b193      	cbz	r3, 20023b68 <HAL_NAND_READ_WITHOOB+0x40>
20023b42:	2f80      	cmp	r7, #128	@ 0x80
20023b44:	d810      	bhi.n	20023b68 <HAL_NAND_READ_WITHOOB+0x40>
20023b46:	f7ff ffe4 	bl	20023b12 <HAL_NAND_PAGE_SIZE>
20023b4a:	f100 3aff 	add.w	sl, r0, #4294967295
20023b4e:	ea0a 0a01 	and.w	sl, sl, r1
20023b52:	eb0a 0305 	add.w	r3, sl, r5
20023b56:	4283      	cmp	r3, r0
20023b58:	4680      	mov	r8, r0
20023b5a:	d907      	bls.n	20023b6c <HAL_NAND_READ_WITHOOB+0x44>
20023b5c:	2002      	movs	r0, #2
20023b5e:	6060      	str	r0, [r4, #4]
20023b60:	2000      	movs	r0, #0
20023b62:	b005      	add	sp, #20
20023b64:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20023b68:	2001      	movs	r0, #1
20023b6a:	e7f8      	b.n	20023b5e <HAL_NAND_READ_WITHOOB+0x36>
20023b6c:	2300      	movs	r3, #0
20023b6e:	6063      	str	r3, [r4, #4]
20023b70:	6923      	ldr	r3, [r4, #16]
20023b72:	f04f 0b00 	mov.w	fp, #0
20023b76:	428b      	cmp	r3, r1
20023b78:	bf98      	it	ls
20023b7a:	1ace      	subls	r6, r1, r3
20023b7c:	fbb6 f2f0 	udiv	r2, r6, r0
20023b80:	2104      	movs	r1, #4
20023b82:	4620      	mov	r0, r4
20023b84:	f7ff fb86 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023b88:	2014      	movs	r0, #20
20023b8a:	f7fe fa8f 	bl	200220ac <HAL_Delay_us_>
20023b8e:	2101      	movs	r1, #1
20023b90:	4620      	mov	r0, r4
20023b92:	f7ff f8e0 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023b96:	2005      	movs	r0, #5
20023b98:	f7fe fa88 	bl	200220ac <HAL_Delay_us_>
20023b9c:	68e2      	ldr	r2, [r4, #12]
20023b9e:	2102      	movs	r1, #2
20023ba0:	7912      	ldrb	r2, [r2, #4]
20023ba2:	4620      	mov	r0, r4
20023ba4:	f7ff fb76 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023ba8:	4620      	mov	r0, r4
20023baa:	f7ff f92a 	bl	20022e02 <HAL_FLASH_READ32>
20023bae:	07c1      	lsls	r1, r0, #31
20023bb0:	d4f1      	bmi.n	20023b96 <HAL_NAND_READ_WITHOOB+0x6e>
20023bb2:	f1bb 0f00 	cmp.w	fp, #0
20023bb6:	d102      	bne.n	20023bbe <HAL_NAND_READ_WITHOOB+0x96>
20023bb8:	f04f 0b01 	mov.w	fp, #1
20023bbc:	e7eb      	b.n	20023b96 <HAL_NAND_READ_WITHOOB+0x6e>
20023bbe:	4620      	mov	r0, r4
20023bc0:	f7ff ff2a 	bl	20023a18 <HAL_NAND_GET_ECC_RESULT>
20023bc4:	b110      	cbz	r0, 20023bcc <HAL_NAND_READ_WITHOOB+0xa4>
20023bc6:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
20023bca:	e7c8      	b.n	20023b5e <HAL_NAND_READ_WITHOOB+0x36>
20023bcc:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
20023bd0:	68e3      	ldr	r3, [r4, #12]
20023bd2:	bbb2      	cbnz	r2, 20023c42 <HAL_NAND_READ_WITHOOB+0x11a>
20023bd4:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023bd8:	4620      	mov	r0, r4
20023bda:	f7ff f864 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20023bde:	68e0      	ldr	r0, [r4, #12]
20023be0:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
20023be4:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023be8:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
20023bec:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
20023bf0:	f8cd c00c 	str.w	ip, [sp, #12]
20023bf4:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023bf8:	f8cd c008 	str.w	ip, [sp, #8]
20023bfc:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
20023c00:	f8cd c004 	str.w	ip, [sp, #4]
20023c04:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
20023c08:	9000      	str	r0, [sp, #0]
20023c0a:	4620      	mov	r0, r4
20023c0c:	f7ff f856 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20023c10:	03b2      	lsls	r2, r6, #14
20023c12:	f8d4 b010 	ldr.w	fp, [r4, #16]
20023c16:	d504      	bpl.n	20023c22 <HAL_NAND_READ_WITHOOB+0xfa>
20023c18:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
20023c1c:	b10a      	cbz	r2, 20023c22 <HAL_NAND_READ_WITHOOB+0xfa>
20023c1e:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
20023c22:	ea49 0205 	orr.w	r2, r9, r5
20023c26:	ea42 020a 	orr.w	r2, r2, sl
20023c2a:	0793      	lsls	r3, r2, #30
20023c2c:	d102      	bne.n	20023c34 <HAL_NAND_READ_WITHOOB+0x10c>
20023c2e:	1e6a      	subs	r2, r5, #1
20023c30:	2afe      	cmp	r2, #254	@ 0xfe
20023c32:	d821      	bhi.n	20023c78 <HAL_NAND_READ_WITHOOB+0x150>
20023c34:	462a      	mov	r2, r5
20023c36:	4648      	mov	r0, r9
20023c38:	eb0b 010a 	add.w	r1, fp, sl
20023c3c:	f006 ff08 	bl	2002aa50 <memcpy>
20023c40:	e01d      	b.n	20023c7e <HAL_NAND_READ_WITHOOB+0x156>
20023c42:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
20023c46:	4620      	mov	r0, r4
20023c48:	f7ff f82d 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20023c4c:	68e0      	ldr	r0, [r4, #12]
20023c4e:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
20023c52:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
20023c56:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
20023c5a:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
20023c5e:	f8cd c00c 	str.w	ip, [sp, #12]
20023c62:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
20023c66:	f8cd c008 	str.w	ip, [sp, #8]
20023c6a:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
20023c6e:	f8cd c004 	str.w	ip, [sp, #4]
20023c72:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
20023c76:	e7c7      	b.n	20023c08 <HAL_NAND_READ_WITHOOB+0xe0>
20023c78:	f1b9 0f00 	cmp.w	r9, #0
20023c7c:	d1da      	bne.n	20023c34 <HAL_NAND_READ_WITHOOB+0x10c>
20023c7e:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
20023c80:	b12b      	cbz	r3, 20023c8e <HAL_NAND_READ_WITHOOB+0x166>
20023c82:	463a      	mov	r2, r7
20023c84:	4618      	mov	r0, r3
20023c86:	eb0b 0108 	add.w	r1, fp, r8
20023c8a:	f006 fee1 	bl	2002aa50 <memcpy>
20023c8e:	1978      	adds	r0, r7, r5
20023c90:	e767      	b.n	20023b62 <HAL_NAND_READ_WITHOOB+0x3a>

20023c92 <HAL_NAND_BLOCK_SIZE>:
20023c92:	b508      	push	{r3, lr}
20023c94:	4602      	mov	r2, r0
20023c96:	f7ff ff3c 	bl	20023b12 <HAL_NAND_PAGE_SIZE>
20023c9a:	b128      	cbz	r0, 20023ca8 <HAL_NAND_BLOCK_SIZE+0x16>
20023c9c:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20023ca0:	079b      	lsls	r3, r3, #30
20023ca2:	bf4c      	ite	mi
20023ca4:	01c0      	lslmi	r0, r0, #7
20023ca6:	0180      	lslpl	r0, r0, #6
20023ca8:	bd08      	pop	{r3, pc}

20023caa <HAL_NAND_GET_BADBLK>:
20023caa:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20023cac:	4604      	mov	r4, r0
20023cae:	b910      	cbnz	r0, 20023cb6 <HAL_NAND_GET_BADBLK+0xc>
20023cb0:	2000      	movs	r0, #0
20023cb2:	b004      	add	sp, #16
20023cb4:	bd10      	pop	{r4, pc}
20023cb6:	6a03      	ldr	r3, [r0, #32]
20023cb8:	2b00      	cmp	r3, #0
20023cba:	d0f9      	beq.n	20023cb0 <HAL_NAND_GET_BADBLK+0x6>
20023cbc:	f7ff ffe9 	bl	20023c92 <HAL_NAND_BLOCK_SIZE>
20023cc0:	2304      	movs	r3, #4
20023cc2:	9301      	str	r3, [sp, #4]
20023cc4:	ab03      	add	r3, sp, #12
20023cc6:	9300      	str	r3, [sp, #0]
20023cc8:	2300      	movs	r3, #0
20023cca:	4341      	muls	r1, r0
20023ccc:	461a      	mov	r2, r3
20023cce:	4620      	mov	r0, r4
20023cd0:	f7ff ff2a 	bl	20023b28 <HAL_NAND_READ_WITHOOB>
20023cd4:	b140      	cbz	r0, 20023ce8 <HAL_NAND_GET_BADBLK+0x3e>
20023cd6:	f89d 300c 	ldrb.w	r3, [sp, #12]
20023cda:	2bff      	cmp	r3, #255	@ 0xff
20023cdc:	d0e8      	beq.n	20023cb0 <HAL_NAND_GET_BADBLK+0x6>
20023cde:	9803      	ldr	r0, [sp, #12]
20023ce0:	2800      	cmp	r0, #0
20023ce2:	bf08      	it	eq
20023ce4:	2001      	moveq	r0, #1
20023ce6:	e7e4      	b.n	20023cb2 <HAL_NAND_GET_BADBLK+0x8>
20023ce8:	2001      	movs	r0, #1
20023cea:	e7e2      	b.n	20023cb2 <HAL_NAND_GET_BADBLK+0x8>

20023cec <HAL_QSPIEX_WRITE_PAGE>:
20023cec:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023cf0:	b099      	sub	sp, #100	@ 0x64
20023cf2:	4604      	mov	r4, r0
20023cf4:	460e      	mov	r6, r1
20023cf6:	4691      	mov	r9, r2
20023cf8:	f7ff fcfb 	bl	200236f2 <flash_handle_valid>
20023cfc:	b318      	cbz	r0, 20023d46 <HAL_QSPIEX_WRITE_PAGE+0x5a>
20023cfe:	2b00      	cmp	r3, #0
20023d00:	f000 80d7 	beq.w	20023eb2 <HAL_QSPIEX_WRITE_PAGE+0x1c6>
20023d04:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20023d08:	bf28      	it	cs
20023d0a:	f44f 7380 	movcs.w	r3, #256	@ 0x100
20023d0e:	68a1      	ldr	r1, [r4, #8]
20023d10:	461d      	mov	r5, r3
20023d12:	6962      	ldr	r2, [r4, #20]
20023d14:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023d18:	2900      	cmp	r1, #0
20023d1a:	d03b      	beq.n	20023d94 <HAL_QSPIEX_WRITE_PAGE+0xa8>
20023d1c:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023d20:	d914      	bls.n	20023d4c <HAL_QSPIEX_WRITE_PAGE+0x60>
20023d22:	2b02      	cmp	r3, #2
20023d24:	bf14      	ite	ne
20023d26:	2727      	movne	r7, #39	@ 0x27
20023d28:	2728      	moveq	r7, #40	@ 0x28
20023d2a:	4639      	mov	r1, r7
20023d2c:	4620      	mov	r0, r4
20023d2e:	f7ff fa8a 	bl	20023246 <HAL_FLASH_PRE_CMD>
20023d32:	4649      	mov	r1, r9
20023d34:	462b      	mov	r3, r5
20023d36:	2201      	movs	r2, #1
20023d38:	4620      	mov	r0, r4
20023d3a:	f7ff fce2 	bl	20023702 <HAL_FLASH_DMA_START>
20023d3e:	4601      	mov	r1, r0
20023d40:	b148      	cbz	r0, 20023d56 <HAL_QSPIEX_WRITE_PAGE+0x6a>
20023d42:	2500      	movs	r5, #0
20023d44:	4628      	mov	r0, r5
20023d46:	b019      	add	sp, #100	@ 0x64
20023d48:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20023d4c:	2b02      	cmp	r3, #2
20023d4e:	bf14      	ite	ne
20023d50:	2716      	movne	r7, #22
20023d52:	2717      	moveq	r7, #23
20023d54:	e7e9      	b.n	20023d2a <HAL_QSPIEX_WRITE_PAGE+0x3e>
20023d56:	4632      	mov	r2, r6
20023d58:	4620      	mov	r0, r4
20023d5a:	f7ff fa9b 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023d5e:	2101      	movs	r1, #1
20023d60:	4620      	mov	r0, r4
20023d62:	f7ff f802 	bl	20022d6a <HAL_FLASH_WRITE_DLEN2>
20023d66:	2301      	movs	r3, #1
20023d68:	4632      	mov	r2, r6
20023d6a:	9300      	str	r3, [sp, #0]
20023d6c:	4639      	mov	r1, r7
20023d6e:	2302      	movs	r3, #2
20023d70:	4620      	mov	r0, r4
20023d72:	f7ff fac2 	bl	200232fa <HAL_FLASH_ISSUE_CMD_SEQ>
20023d76:	2800      	cmp	r0, #0
20023d78:	d1e3      	bne.n	20023d42 <HAL_QSPIEX_WRITE_PAGE+0x56>
20023d7a:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
20023d7e:	4620      	mov	r0, r4
20023d80:	f7ff fd0f 	bl	200237a2 <HAL_FLASH_DMA_WAIT_DONE>
20023d84:	2800      	cmp	r0, #0
20023d86:	d1dc      	bne.n	20023d42 <HAL_QSPIEX_WRITE_PAGE+0x56>
20023d88:	6822      	ldr	r2, [r4, #0]
20023d8a:	6813      	ldr	r3, [r2, #0]
20023d8c:	f023 0320 	bic.w	r3, r3, #32
20023d90:	6013      	str	r3, [r2, #0]
20023d92:	e7d7      	b.n	20023d44 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023d94:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023d98:	f240 8082 	bls.w	20023ea0 <HAL_QSPIEX_WRITE_PAGE+0x1b4>
20023d9c:	2b02      	cmp	r3, #2
20023d9e:	bf14      	ite	ne
20023da0:	2327      	movne	r3, #39	@ 0x27
20023da2:	2328      	moveq	r3, #40	@ 0x28
20023da4:	462f      	mov	r7, r5
20023da6:	f04f 0800 	mov.w	r8, #0
20023daa:	9303      	str	r3, [sp, #12]
20023dac:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
20023db0:	2f40      	cmp	r7, #64	@ 0x40
20023db2:	bfd4      	ite	le
20023db4:	ea0a 0a07 	andle.w	sl, sl, r7
20023db8:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
20023dbc:	f1ba 0f00 	cmp.w	sl, #0
20023dc0:	d03f      	beq.n	20023e42 <HAL_QSPIEX_WRITE_PAGE+0x156>
20023dc2:	2200      	movs	r2, #0
20023dc4:	4620      	mov	r0, r4
20023dc6:	4611      	mov	r1, r2
20023dc8:	f7ff fa64 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023dcc:	eb09 0308 	add.w	r3, r9, r8
20023dd0:	f10d 0c20 	add.w	ip, sp, #32
20023dd4:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023dd8:	4662      	mov	r2, ip
20023dda:	6818      	ldr	r0, [r3, #0]
20023ddc:	6859      	ldr	r1, [r3, #4]
20023dde:	3308      	adds	r3, #8
20023de0:	c203      	stmia	r2!, {r0, r1}
20023de2:	4573      	cmp	r3, lr
20023de4:	4694      	mov	ip, r2
20023de6:	d1f7      	bne.n	20023dd8 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023de8:	f04f 0b00 	mov.w	fp, #0
20023dec:	ea4f 02aa 	mov.w	r2, sl, asr #2
20023df0:	ab08      	add	r3, sp, #32
20023df2:	f853 1b04 	ldr.w	r1, [r3], #4
20023df6:	4620      	mov	r0, r4
20023df8:	9205      	str	r2, [sp, #20]
20023dfa:	9304      	str	r3, [sp, #16]
20023dfc:	f7fe ffa4 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023e00:	9a05      	ldr	r2, [sp, #20]
20023e02:	f10b 0b01 	add.w	fp, fp, #1
20023e06:	4593      	cmp	fp, r2
20023e08:	9b04      	ldr	r3, [sp, #16]
20023e0a:	d1f2      	bne.n	20023df2 <HAL_QSPIEX_WRITE_PAGE+0x106>
20023e0c:	4651      	mov	r1, sl
20023e0e:	4620      	mov	r0, r4
20023e10:	f7fe ffa1 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023e14:	4620      	mov	r0, r4
20023e16:	9903      	ldr	r1, [sp, #12]
20023e18:	eb06 0208 	add.w	r2, r6, r8
20023e1c:	f7ff fa3a 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023e20:	2101      	movs	r1, #1
20023e22:	4620      	mov	r0, r4
20023e24:	f7fe ff97 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023e28:	2200      	movs	r2, #0
20023e2a:	2102      	movs	r1, #2
20023e2c:	4620      	mov	r0, r4
20023e2e:	f7ff fa31 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023e32:	4620      	mov	r0, r4
20023e34:	f7fe ffdc 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
20023e38:	2800      	cmp	r0, #0
20023e3a:	d0f1      	beq.n	20023e20 <HAL_QSPIEX_WRITE_PAGE+0x134>
20023e3c:	eba7 070a 	sub.w	r7, r7, sl
20023e40:	44d0      	add	r8, sl
20023e42:	1e7b      	subs	r3, r7, #1
20023e44:	2b02      	cmp	r3, #2
20023e46:	d830      	bhi.n	20023eaa <HAL_QSPIEX_WRITE_PAGE+0x1be>
20023e48:	6923      	ldr	r3, [r4, #16]
20023e4a:	4446      	add	r6, r8
20023e4c:	4333      	orrs	r3, r6
20023e4e:	681b      	ldr	r3, [r3, #0]
20023e50:	463a      	mov	r2, r7
20023e52:	eb09 0108 	add.w	r1, r9, r8
20023e56:	a807      	add	r0, sp, #28
20023e58:	9307      	str	r3, [sp, #28]
20023e5a:	f006 fdf9 	bl	2002aa50 <memcpy>
20023e5e:	2200      	movs	r2, #0
20023e60:	4620      	mov	r0, r4
20023e62:	4611      	mov	r1, r2
20023e64:	f7ff fa16 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023e68:	9907      	ldr	r1, [sp, #28]
20023e6a:	4620      	mov	r0, r4
20023e6c:	f7fe ff6c 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20023e70:	2104      	movs	r1, #4
20023e72:	4620      	mov	r0, r4
20023e74:	f7fe ff6f 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023e78:	4632      	mov	r2, r6
20023e7a:	4620      	mov	r0, r4
20023e7c:	9903      	ldr	r1, [sp, #12]
20023e7e:	f7ff fa09 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023e82:	2101      	movs	r1, #1
20023e84:	4620      	mov	r0, r4
20023e86:	f7fe ff66 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20023e8a:	2200      	movs	r2, #0
20023e8c:	2102      	movs	r1, #2
20023e8e:	4620      	mov	r0, r4
20023e90:	f7ff fa00 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023e94:	4620      	mov	r0, r4
20023e96:	f7fe ffab 	bl	20022df0 <HAL_FLASH_IS_PROG_DONE>
20023e9a:	2800      	cmp	r0, #0
20023e9c:	d0f1      	beq.n	20023e82 <HAL_QSPIEX_WRITE_PAGE+0x196>
20023e9e:	e751      	b.n	20023d44 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023ea0:	2b02      	cmp	r3, #2
20023ea2:	bf14      	ite	ne
20023ea4:	2316      	movne	r3, #22
20023ea6:	2317      	moveq	r3, #23
20023ea8:	e77c      	b.n	20023da4 <HAL_QSPIEX_WRITE_PAGE+0xb8>
20023eaa:	2f00      	cmp	r7, #0
20023eac:	f73f af7e 	bgt.w	20023dac <HAL_QSPIEX_WRITE_PAGE+0xc0>
20023eb0:	e748      	b.n	20023d44 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023eb2:	4618      	mov	r0, r3
20023eb4:	e747      	b.n	20023d46 <HAL_QSPIEX_WRITE_PAGE+0x5a>

20023eb6 <HAL_QSPIEX_SECT_ERASE>:
20023eb6:	b573      	push	{r0, r1, r4, r5, r6, lr}
20023eb8:	4604      	mov	r4, r0
20023eba:	460d      	mov	r5, r1
20023ebc:	f7ff fc19 	bl	200236f2 <flash_handle_valid>
20023ec0:	b1e8      	cbz	r0, 20023efe <HAL_QSPIEX_SECT_ERASE+0x48>
20023ec2:	6963      	ldr	r3, [r4, #20]
20023ec4:	460a      	mov	r2, r1
20023ec6:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023eca:	f04f 0100 	mov.w	r1, #0
20023ece:	4620      	mov	r0, r4
20023ed0:	bf94      	ite	ls
20023ed2:	261b      	movls	r6, #27
20023ed4:	2629      	movhi	r6, #41	@ 0x29
20023ed6:	f7ff f9dd 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
20023eda:	2101      	movs	r1, #1
20023edc:	4620      	mov	r0, r4
20023ede:	f7fe ff44 	bl	20022d6a <HAL_FLASH_WRITE_DLEN2>
20023ee2:	2301      	movs	r3, #1
20023ee4:	462a      	mov	r2, r5
20023ee6:	9300      	str	r3, [sp, #0]
20023ee8:	4631      	mov	r1, r6
20023eea:	2302      	movs	r3, #2
20023eec:	4620      	mov	r0, r4
20023eee:	f7ff fa04 	bl	200232fa <HAL_FLASH_ISSUE_CMD_SEQ>
20023ef2:	3800      	subs	r0, #0
20023ef4:	bf18      	it	ne
20023ef6:	2001      	movne	r0, #1
20023ef8:	4240      	negs	r0, r0
20023efa:	b002      	add	sp, #8
20023efc:	bd70      	pop	{r4, r5, r6, pc}
20023efe:	f04f 30ff 	mov.w	r0, #4294967295
20023f02:	e7fa      	b.n	20023efa <HAL_QSPIEX_SECT_ERASE+0x44>

20023f04 <HAL_QSPI_GET_SRC_CLK>:
20023f04:	b508      	push	{r3, lr}
20023f06:	b1e8      	cbz	r0, 20023f44 <HAL_QSPI_GET_SRC_CLK+0x40>
20023f08:	6803      	ldr	r3, [r0, #0]
20023f0a:	4a0f      	ldr	r2, [pc, #60]	@ (20023f48 <HAL_QSPI_GET_SRC_CLK+0x44>)
20023f0c:	4293      	cmp	r3, r2
20023f0e:	d00c      	beq.n	20023f2a <HAL_QSPI_GET_SRC_CLK+0x26>
20023f10:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
20023f14:	4293      	cmp	r3, r2
20023f16:	d115      	bne.n	20023f44 <HAL_QSPI_GET_SRC_CLK+0x40>
20023f18:	2006      	movs	r0, #6
20023f1a:	f001 f861 	bl	20024fe0 <HAL_RCC_HCPU_GetClockSrc>
20023f1e:	2802      	cmp	r0, #2
20023f20:	d105      	bne.n	20023f2e <HAL_QSPI_GET_SRC_CLK+0x2a>
20023f22:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023f26:	f001 b89f 	b.w	20025068 <HAL_RCC_HCPU_GetDLL2Freq>
20023f2a:	2004      	movs	r0, #4
20023f2c:	e7f5      	b.n	20023f1a <HAL_QSPI_GET_SRC_CLK+0x16>
20023f2e:	2803      	cmp	r0, #3
20023f30:	d103      	bne.n	20023f3a <HAL_QSPI_GET_SRC_CLK+0x36>
20023f32:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023f36:	f001 b89a 	b.w	2002506e <HAL_RCC_HCPU_GetDLL3Freq>
20023f3a:	2001      	movs	r0, #1
20023f3c:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023f40:	f001 b8fa 	b.w	20025138 <HAL_RCC_GetSysCLKFreq>
20023f44:	2000      	movs	r0, #0
20023f46:	bd08      	pop	{r3, pc}
20023f48:	50041000 	.word	0x50041000

20023f4c <HAL_QSPI_GET_CLK>:
20023f4c:	b538      	push	{r3, r4, r5, lr}
20023f4e:	4605      	mov	r5, r0
20023f50:	b908      	cbnz	r0, 20023f56 <HAL_QSPI_GET_CLK+0xa>
20023f52:	2000      	movs	r0, #0
20023f54:	bd38      	pop	{r3, r4, r5, pc}
20023f56:	f7fe ff63 	bl	20022e20 <HAL_FLASH_GET_DIV>
20023f5a:	4604      	mov	r4, r0
20023f5c:	2800      	cmp	r0, #0
20023f5e:	d0f8      	beq.n	20023f52 <HAL_QSPI_GET_CLK+0x6>
20023f60:	4628      	mov	r0, r5
20023f62:	f7ff ffcf 	bl	20023f04 <HAL_QSPI_GET_SRC_CLK>
20023f66:	fbb0 f0f4 	udiv	r0, r0, r4
20023f6a:	e7f3      	b.n	20023f54 <HAL_QSPI_GET_CLK+0x8>

20023f6c <HAL_QSPI_READ_ID>:
20023f6c:	b138      	cbz	r0, 20023f7e <HAL_QSPI_READ_ID+0x12>
20023f6e:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
20023f72:	b113      	cbz	r3, 20023f7a <HAL_QSPI_READ_ID+0xe>
20023f74:	2100      	movs	r1, #0
20023f76:	f7ff bc60 	b.w	2002383a <nand_read_id>
20023f7a:	f7ff bae0 	b.w	2002353e <HAL_FLASH_GET_NOR_ID>
20023f7e:	20ff      	movs	r0, #255	@ 0xff
20023f80:	4770      	bx	lr

20023f82 <HAL_NOR_CFG_DTR>:
20023f82:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20023f84:	4604      	mov	r4, r0
20023f86:	460a      	mov	r2, r1
20023f88:	b351      	cbz	r1, 20023fe0 <HAL_NOR_CFG_DTR+0x5e>
20023f8a:	68c5      	ldr	r5, [r0, #12]
20023f8c:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
20023f90:	2b00      	cmp	r3, #0
20023f92:	d03b      	beq.n	2002400c <HAL_NOR_CFG_DTR+0x8a>
20023f94:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
20023f98:	b3c3      	cbz	r3, 2002400c <HAL_NOR_CFG_DTR+0x8a>
20023f9a:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
20023f9e:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
20023fa2:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
20023fa6:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
20023faa:	9603      	str	r6, [sp, #12]
20023fac:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
20023fb0:	9602      	str	r6, [sp, #8]
20023fb2:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
20023fb6:	9601      	str	r6, [sp, #4]
20023fb8:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
20023fbc:	9500      	str	r5, [sp, #0]
20023fbe:	f7fe fe7d 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20023fc2:	68e3      	ldr	r3, [r4, #12]
20023fc4:	4620      	mov	r0, r4
20023fc6:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
20023fca:	f7fe fe6c 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20023fce:	2101      	movs	r1, #1
20023fd0:	4620      	mov	r0, r4
20023fd2:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
20023fd6:	f7ff f87d 	bl	200230d4 <HAL_MPI_CFG_DTR>
20023fda:	2000      	movs	r0, #0
20023fdc:	b004      	add	sp, #16
20023fde:	bd70      	pop	{r4, r5, r6, pc}
20023fe0:	f7ff f878 	bl	200230d4 <HAL_MPI_CFG_DTR>
20023fe4:	6963      	ldr	r3, [r4, #20]
20023fe6:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20023fea:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023fee:	d906      	bls.n	20023ffe <HAL_NOR_CFG_DTR+0x7c>
20023ff0:	b919      	cbnz	r1, 20023ffa <HAL_NOR_CFG_DTR+0x78>
20023ff2:	4620      	mov	r0, r4
20023ff4:	f7ff f8ea 	bl	200231cc <HAL_FLASH_CONFIG_FULL_AHB_READ>
20023ff8:	e7ef      	b.n	20023fda <HAL_NOR_CFG_DTR+0x58>
20023ffa:	2101      	movs	r1, #1
20023ffc:	e7f9      	b.n	20023ff2 <HAL_NOR_CFG_DTR+0x70>
20023ffe:	b919      	cbnz	r1, 20024008 <HAL_NOR_CFG_DTR+0x86>
20024000:	4620      	mov	r0, r4
20024002:	f7ff f89f 	bl	20023144 <HAL_FLASH_CONFIG_AHB_READ>
20024006:	e7e8      	b.n	20023fda <HAL_NOR_CFG_DTR+0x58>
20024008:	2101      	movs	r1, #1
2002400a:	e7f9      	b.n	20024000 <HAL_NOR_CFG_DTR+0x7e>
2002400c:	2001      	movs	r0, #1
2002400e:	e7e5      	b.n	20023fdc <HAL_NOR_CFG_DTR+0x5a>

20024010 <HAL_NOR_DTR_CAL>:
20024010:	b510      	push	{r4, lr}
20024012:	4604      	mov	r4, r0
20024014:	b1f0      	cbz	r0, 20024054 <HAL_NOR_DTR_CAL+0x44>
20024016:	6802      	ldr	r2, [r0, #0]
20024018:	2014      	movs	r0, #20
2002401a:	f8d2 3094 	ldr.w	r3, [r2, #148]	@ 0x94
2002401e:	f043 4300 	orr.w	r3, r3, #2147483648	@ 0x80000000
20024022:	f8c2 3094 	str.w	r3, [r2, #148]	@ 0x94
20024026:	f7fe f898 	bl	2002215a <HAL_Delay_us>
2002402a:	6823      	ldr	r3, [r4, #0]
2002402c:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
20024030:	05d2      	lsls	r2, r2, #23
20024032:	d5fb      	bpl.n	2002402c <HAL_NOR_DTR_CAL+0x1c>
20024034:	f8d3 0094 	ldr.w	r0, [r3, #148]	@ 0x94
20024038:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
2002403c:	b2c0      	uxtb	r0, r0
2002403e:	f022 4200 	bic.w	r2, r2, #2147483648	@ 0x80000000
20024042:	f8c3 2094 	str.w	r2, [r3, #148]	@ 0x94
20024046:	f894 302d 	ldrb.w	r3, [r4, #45]	@ 0x2d
2002404a:	f023 037f 	bic.w	r3, r3, #127	@ 0x7f
2002404e:	4303      	orrs	r3, r0
20024050:	f884 302d 	strb.w	r3, [r4, #45]	@ 0x2d
20024054:	bd10      	pop	{r4, pc}
	...

20024058 <HAL_FLASH_Init>:
20024058:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
2002405c:	460e      	mov	r6, r1
2002405e:	4690      	mov	r8, r2
20024060:	461f      	mov	r7, r3
20024062:	4604      	mov	r4, r0
20024064:	b087      	sub	sp, #28
20024066:	2800      	cmp	r0, #0
20024068:	f000 80e5 	beq.w	20024236 <HAL_FLASH_Init+0x1de>
2002406c:	2900      	cmp	r1, #0
2002406e:	f000 80e2 	beq.w	20024236 <HAL_FLASH_Init+0x1de>
20024072:	f7fe fdf7 	bl	20022c64 <HAL_QSPI_Init>
20024076:	6820      	ldr	r0, [r4, #0]
20024078:	f7ff fb41 	bl	200236fe <HAL_GET_FLASH_MID>
2002407c:	6933      	ldr	r3, [r6, #16]
2002407e:	2100      	movs	r1, #0
20024080:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
20024084:	68b3      	ldr	r3, [r6, #8]
20024086:	4605      	mov	r5, r0
20024088:	64a3      	str	r3, [r4, #72]	@ 0x48
2002408a:	68f3      	ldr	r3, [r6, #12]
2002408c:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
20024090:	051b      	lsls	r3, r3, #20
20024092:	64e3      	str	r3, [r4, #76]	@ 0x4c
20024094:	2302      	movs	r3, #2
20024096:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
2002409a:	6933      	ldr	r3, [r6, #16]
2002409c:	f8c4 8008 	str.w	r8, [r4, #8]
200240a0:	1e5a      	subs	r2, r3, #1
200240a2:	4253      	negs	r3, r2
200240a4:	4153      	adcs	r3, r2
200240a6:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
200240aa:	f1b8 0f00 	cmp.w	r8, #0
200240ae:	d058      	beq.n	20024162 <HAL_FLASH_Init+0x10a>
200240b0:	2f00      	cmp	r7, #0
200240b2:	d056      	beq.n	20024162 <HAL_FLASH_Init+0x10a>
200240b4:	683b      	ldr	r3, [r7, #0]
200240b6:	f8c8 3000 	str.w	r3, [r8]
200240ba:	68a3      	ldr	r3, [r4, #8]
200240bc:	68fa      	ldr	r2, [r7, #12]
200240be:	605a      	str	r2, [r3, #4]
200240c0:	2210      	movs	r2, #16
200240c2:	68a3      	ldr	r3, [r4, #8]
200240c4:	609a      	str	r2, [r3, #8]
200240c6:	2280      	movs	r2, #128	@ 0x80
200240c8:	68a3      	ldr	r3, [r4, #8]
200240ca:	60d9      	str	r1, [r3, #12]
200240cc:	68a3      	ldr	r3, [r4, #8]
200240ce:	611a      	str	r2, [r3, #16]
200240d0:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
200240d4:	68a3      	ldr	r3, [r4, #8]
200240d6:	6159      	str	r1, [r3, #20]
200240d8:	68a3      	ldr	r3, [r4, #8]
200240da:	6199      	str	r1, [r3, #24]
200240dc:	68a3      	ldr	r3, [r4, #8]
200240de:	61d9      	str	r1, [r3, #28]
200240e0:	68a3      	ldr	r3, [r4, #8]
200240e2:	621a      	str	r2, [r3, #32]
200240e4:	68a3      	ldr	r3, [r4, #8]
200240e6:	6259      	str	r1, [r3, #36]	@ 0x24
200240e8:	b1c0      	cbz	r0, 2002411c <HAL_FLASH_Init+0xc4>
200240ea:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200240ee:	4298      	cmp	r0, r3
200240f0:	d014      	beq.n	2002411c <HAL_FLASH_Init+0xc4>
200240f2:	2701      	movs	r7, #1
200240f4:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200240f8:	2b00      	cmp	r3, #0
200240fa:	d13d      	bne.n	20024178 <HAL_FLASH_Init+0x120>
200240fc:	2f00      	cmp	r7, #0
200240fe:	d15a      	bne.n	200241b6 <HAL_FLASH_Init+0x15e>
20024100:	4620      	mov	r0, r4
20024102:	f7ff fad6 	bl	200236b2 <HAL_FLASH_RELEASE_DPD>
20024106:	4638      	mov	r0, r7
20024108:	f7fe f827 	bl	2002215a <HAL_Delay_us>
2002410c:	2032      	movs	r0, #50	@ 0x32
2002410e:	f7fe f824 	bl	2002215a <HAL_Delay_us>
20024112:	4620      	mov	r0, r4
20024114:	f7ff ff2a 	bl	20023f6c <HAL_QSPI_READ_ID>
20024118:	4605      	mov	r5, r0
2002411a:	e04c      	b.n	200241b6 <HAL_FLASH_Init+0x15e>
2002411c:	2101      	movs	r1, #1
2002411e:	4620      	mov	r0, r4
20024120:	f7fe fe73 	bl	20022e0a <HAL_FLASH_SET_TXSLOT>
20024124:	4bb3      	ldr	r3, [pc, #716]	@ (200243f4 <HAL_FLASH_Init+0x39c>)
20024126:	69a2      	ldr	r2, [r4, #24]
20024128:	4620      	mov	r0, r4
2002412a:	429a      	cmp	r2, r3
2002412c:	f04f 0200 	mov.w	r2, #0
20024130:	bf8c      	ite	hi
20024132:	2101      	movhi	r1, #1
20024134:	4611      	movls	r1, r2
20024136:	f7ff faad 	bl	20023694 <HAL_QSPI_SET_CLK_INV>
2002413a:	4620      	mov	r0, r4
2002413c:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
20024140:	f7fe fe6a 	bl	20022e18 <HAL_FLASH_SET_CLK_rom>
20024144:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
20024148:	b12b      	cbz	r3, 20024156 <HAL_FLASH_Init+0xfe>
2002414a:	2b01      	cmp	r3, #1
2002414c:	d110      	bne.n	20024170 <HAL_FLASH_Init+0x118>
2002414e:	2100      	movs	r1, #0
20024150:	4620      	mov	r0, r4
20024152:	f7fe ff79 	bl	20023048 <HAL_FLASH_SET_DUAL_MODE>
20024156:	2101      	movs	r1, #1
20024158:	4620      	mov	r0, r4
2002415a:	f7fe ff02 	bl	20022f62 <HAL_FLASH_ENABLE_QSPI>
2002415e:	2700      	movs	r7, #0
20024160:	e7c8      	b.n	200240f4 <HAL_FLASH_Init+0x9c>
20024162:	2d00      	cmp	r5, #0
20024164:	d0de      	beq.n	20024124 <HAL_FLASH_Init+0xcc>
20024166:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
2002416a:	429d      	cmp	r5, r3
2002416c:	d1c1      	bne.n	200240f2 <HAL_FLASH_Init+0x9a>
2002416e:	e7d9      	b.n	20024124 <HAL_FLASH_Init+0xcc>
20024170:	2b02      	cmp	r3, #2
20024172:	d1f0      	bne.n	20024156 <HAL_FLASH_Init+0xfe>
20024174:	2101      	movs	r1, #1
20024176:	e7eb      	b.n	20024150 <HAL_FLASH_Init+0xf8>
20024178:	6822      	ldr	r2, [r4, #0]
2002417a:	2600      	movs	r6, #0
2002417c:	6893      	ldr	r3, [r2, #8]
2002417e:	4631      	mov	r1, r6
20024180:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
20024184:	6093      	str	r3, [r2, #8]
20024186:	2301      	movs	r3, #1
20024188:	4632      	mov	r2, r6
2002418a:	4620      	mov	r0, r4
2002418c:	e9cd 6303 	strd	r6, r3, [sp, #12]
20024190:	e9cd 6601 	strd	r6, r6, [sp, #4]
20024194:	4633      	mov	r3, r6
20024196:	9600      	str	r6, [sp, #0]
20024198:	f7fe fe47 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
2002419c:	4632      	mov	r2, r6
2002419e:	21ff      	movs	r1, #255	@ 0xff
200241a0:	4620      	mov	r0, r4
200241a2:	f7fe fdfd 	bl	20022da0 <HAL_FLASH_SET_CMD>
200241a6:	4630      	mov	r0, r6
200241a8:	f7fd ffd7 	bl	2002215a <HAL_Delay_us>
200241ac:	20c8      	movs	r0, #200	@ 0xc8
200241ae:	f7fd ffd4 	bl	2002215a <HAL_Delay_us>
200241b2:	2f00      	cmp	r7, #0
200241b4:	d0ad      	beq.n	20024112 <HAL_FLASH_Init+0xba>
200241b6:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200241ba:	b2ee      	uxtb	r6, r5
200241bc:	f3c5 2807 	ubfx	r8, r5, #8, #8
200241c0:	6425      	str	r5, [r4, #64]	@ 0x40
200241c2:	f3c5 4507 	ubfx	r5, r5, #16, #8
200241c6:	4642      	mov	r2, r8
200241c8:	4629      	mov	r1, r5
200241ca:	4630      	mov	r0, r6
200241cc:	b3ab      	cbz	r3, 2002423a <HAL_FLASH_Init+0x1e2>
200241ce:	f001 f9f1 	bl	200255b4 <spi_nand_get_cmd_by_id>
200241d2:	60e0      	str	r0, [r4, #12]
200241d4:	bba0      	cbnz	r0, 20024240 <HAL_FLASH_Init+0x1e8>
200241d6:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200241da:	b32b      	cbz	r3, 20024228 <HAL_FLASH_Init+0x1d0>
200241dc:	2108      	movs	r1, #8
200241de:	4620      	mov	r0, r4
200241e0:	f7ff fb2b 	bl	2002383a <nand_read_id>
200241e4:	f3c0 2807 	ubfx	r8, r0, #8, #8
200241e8:	f3c0 4507 	ubfx	r5, r0, #16, #8
200241ec:	b2c6      	uxtb	r6, r0
200241ee:	6420      	str	r0, [r4, #64]	@ 0x40
200241f0:	4642      	mov	r2, r8
200241f2:	4629      	mov	r1, r5
200241f4:	4630      	mov	r0, r6
200241f6:	f001 f9dd 	bl	200255b4 <spi_nand_get_cmd_by_id>
200241fa:	60e0      	str	r0, [r4, #12]
200241fc:	bb00      	cbnz	r0, 20024240 <HAL_FLASH_Init+0x1e8>
200241fe:	210f      	movs	r1, #15
20024200:	4620      	mov	r0, r4
20024202:	f7ff fb1a 	bl	2002383a <nand_read_id>
20024206:	f3c0 2807 	ubfx	r8, r0, #8, #8
2002420a:	f3c0 4507 	ubfx	r5, r0, #16, #8
2002420e:	b2c6      	uxtb	r6, r0
20024210:	6420      	str	r0, [r4, #64]	@ 0x40
20024212:	4642      	mov	r2, r8
20024214:	4629      	mov	r1, r5
20024216:	4630      	mov	r0, r6
20024218:	f001 f9cc 	bl	200255b4 <spi_nand_get_cmd_by_id>
2002421c:	60e0      	str	r0, [r4, #12]
2002421e:	b978      	cbnz	r0, 20024240 <HAL_FLASH_Init+0x1e8>
20024220:	f001 f9e0 	bl	200255e4 <spi_nand_get_default_ctable>
20024224:	60e0      	str	r0, [r4, #12]
20024226:	b958      	cbnz	r0, 20024240 <HAL_FLASH_Init+0x1e8>
20024228:	2100      	movs	r1, #0
2002422a:	4620      	mov	r0, r4
2002422c:	f7fe fe99 	bl	20022f62 <HAL_FLASH_ENABLE_QSPI>
20024230:	2300      	movs	r3, #0
20024232:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
20024236:	2001      	movs	r0, #1
20024238:	e053      	b.n	200242e2 <HAL_FLASH_Init+0x28a>
2002423a:	f001 f95d 	bl	200254f8 <spi_flash_get_cmd_by_id>
2002423e:	e7c8      	b.n	200241d2 <HAL_FLASH_Init+0x17a>
20024240:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20024244:	4642      	mov	r2, r8
20024246:	4629      	mov	r1, r5
20024248:	4630      	mov	r0, r6
2002424a:	2b00      	cmp	r3, #0
2002424c:	d04c      	beq.n	200242e8 <HAL_FLASH_Init+0x290>
2002424e:	f001 f9d7 	bl	20025600 <spi_nand_get_size_by_id>
20024252:	4642      	mov	r2, r8
20024254:	4629      	mov	r1, r5
20024256:	4681      	mov	r9, r0
20024258:	4630      	mov	r0, r6
2002425a:	f001 f9db 	bl	20025614 <spi_nand_get_plane_select_flag>
2002425e:	4642      	mov	r2, r8
20024260:	4629      	mov	r1, r5
20024262:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
20024266:	4630      	mov	r0, r6
20024268:	f001 f9dd 	bl	20025626 <spi_nand_get_big_page_flag>
2002426c:	4642      	mov	r2, r8
2002426e:	4629      	mov	r1, r5
20024270:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
20024274:	4630      	mov	r0, r6
20024276:	f001 f9df 	bl	20025638 <spi_nand_get_ecc_mode>
2002427a:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
2002427e:	4642      	mov	r2, r8
20024280:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
20024284:	4629      	mov	r1, r5
20024286:	4630      	mov	r0, r6
20024288:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
2002428c:	f001 f9a4 	bl	200255d8 <spi_nand_get_ext_cfg_by_id>
20024290:	63e0      	str	r0, [r4, #60]	@ 0x3c
20024292:	f1b9 0f00 	cmp.w	r9, #0
20024296:	d003      	beq.n	200242a0 <HAL_FLASH_Init+0x248>
20024298:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
2002429c:	f8c4 9014 	str.w	r9, [r4, #20]
200242a0:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200242a4:	2b00      	cmp	r3, #0
200242a6:	f040 8084 	bne.w	200243b2 <HAL_FLASH_Init+0x35a>
200242aa:	2f00      	cmp	r7, #0
200242ac:	d17e      	bne.n	200243ac <HAL_FLASH_Init+0x354>
200242ae:	4620      	mov	r0, r4
200242b0:	f7ff f960 	bl	20023574 <HAL_FLASH_CLR_PROTECT>
200242b4:	6963      	ldr	r3, [r4, #20]
200242b6:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
200242ba:	d948      	bls.n	2002434e <HAL_FLASH_Init+0x2f6>
200242bc:	463a      	mov	r2, r7
200242be:	2121      	movs	r1, #33	@ 0x21
200242c0:	4620      	mov	r0, r4
200242c2:	f7fe ffe7 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200242c6:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200242ca:	bb0b      	cbnz	r3, 20024310 <HAL_FLASH_Init+0x2b8>
200242cc:	4639      	mov	r1, r7
200242ce:	4620      	mov	r0, r4
200242d0:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
200242d4:	f7ff f928 	bl	20023528 <HAL_FLASH_FADDR_SET_QSPI>
200242d8:	2107      	movs	r1, #7
200242da:	4620      	mov	r0, r4
200242dc:	f7fe fe9c 	bl	20023018 <HAL_FLASH_SET_ROW_BOUNDARY>
200242e0:	2000      	movs	r0, #0
200242e2:	b007      	add	sp, #28
200242e4:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200242e8:	f001 f91a 	bl	20025520 <spi_flash_get_size_by_id>
200242ec:	4642      	mov	r2, r8
200242ee:	4629      	mov	r1, r5
200242f0:	4681      	mov	r9, r0
200242f2:	4630      	mov	r0, r6
200242f4:	f001 f928 	bl	20025548 <spi_flash_get_otp_base>
200242f8:	4642      	mov	r2, r8
200242fa:	63a0      	str	r0, [r4, #56]	@ 0x38
200242fc:	4629      	mov	r1, r5
200242fe:	4630      	mov	r0, r6
20024300:	f001 f8d1 	bl	200254a6 <spi_nor_get_ext_cfg_by_id>
20024304:	63e0      	str	r0, [r4, #60]	@ 0x3c
20024306:	2800      	cmp	r0, #0
20024308:	d0c3      	beq.n	20024292 <HAL_FLASH_Init+0x23a>
2002430a:	6803      	ldr	r3, [r0, #0]
2002430c:	63a3      	str	r3, [r4, #56]	@ 0x38
2002430e:	e7c0      	b.n	20024292 <HAL_FLASH_Init+0x23a>
20024310:	2101      	movs	r1, #1
20024312:	4620      	mov	r0, r4
20024314:	f7ff f908 	bl	20023528 <HAL_FLASH_FADDR_SET_QSPI>
20024318:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
2002431c:	f1b9 0f01 	cmp.w	r9, #1
20024320:	d1da      	bne.n	200242d8 <HAL_FLASH_Init+0x280>
20024322:	4642      	mov	r2, r8
20024324:	4629      	mov	r1, r5
20024326:	4630      	mov	r0, r6
20024328:	f001 f904 	bl	20025534 <spi_flash_is_support_dtr>
2002432c:	b138      	cbz	r0, 2002433e <HAL_FLASH_Init+0x2e6>
2002432e:	4620      	mov	r0, r4
20024330:	f7ff fe6e 	bl	20024010 <HAL_NOR_DTR_CAL>
20024334:	4649      	mov	r1, r9
20024336:	4620      	mov	r0, r4
20024338:	f7ff fe23 	bl	20023f82 <HAL_NOR_CFG_DTR>
2002433c:	e7cc      	b.n	200242d8 <HAL_FLASH_Init+0x280>
2002433e:	463a      	mov	r2, r7
20024340:	4639      	mov	r1, r7
20024342:	4620      	mov	r0, r4
20024344:	f7fe fec6 	bl	200230d4 <HAL_MPI_CFG_DTR>
20024348:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
2002434c:	e7c4      	b.n	200242d8 <HAL_FLASH_Init+0x280>
2002434e:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20024352:	b933      	cbnz	r3, 20024362 <HAL_FLASH_Init+0x30a>
20024354:	4639      	mov	r1, r7
20024356:	4620      	mov	r0, r4
20024358:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
2002435c:	f7ff f8d9 	bl	20023512 <HAL_FLASH_SET_QUAL_SPI>
20024360:	e7be      	b.n	200242e0 <HAL_FLASH_Init+0x288>
20024362:	2101      	movs	r1, #1
20024364:	4620      	mov	r0, r4
20024366:	f7ff f8d4 	bl	20023512 <HAL_FLASH_SET_QUAL_SPI>
2002436a:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
2002436e:	f1b9 0f01 	cmp.w	r9, #1
20024372:	d115      	bne.n	200243a0 <HAL_FLASH_Init+0x348>
20024374:	4642      	mov	r2, r8
20024376:	4629      	mov	r1, r5
20024378:	4630      	mov	r0, r6
2002437a:	f001 f8db 	bl	20025534 <spi_flash_is_support_dtr>
2002437e:	b138      	cbz	r0, 20024390 <HAL_FLASH_Init+0x338>
20024380:	4620      	mov	r0, r4
20024382:	f7ff fe45 	bl	20024010 <HAL_NOR_DTR_CAL>
20024386:	4649      	mov	r1, r9
20024388:	4620      	mov	r0, r4
2002438a:	f7ff fdfa 	bl	20023f82 <HAL_NOR_CFG_DTR>
2002438e:	e7a7      	b.n	200242e0 <HAL_FLASH_Init+0x288>
20024390:	463a      	mov	r2, r7
20024392:	4639      	mov	r1, r7
20024394:	4620      	mov	r0, r4
20024396:	f7fe fe9d 	bl	200230d4 <HAL_MPI_CFG_DTR>
2002439a:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
2002439e:	e79f      	b.n	200242e0 <HAL_FLASH_Init+0x288>
200243a0:	463a      	mov	r2, r7
200243a2:	4639      	mov	r1, r7
200243a4:	4620      	mov	r0, r4
200243a6:	f7fe fe95 	bl	200230d4 <HAL_MPI_CFG_DTR>
200243aa:	e799      	b.n	200242e0 <HAL_FLASH_Init+0x288>
200243ac:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
200243b0:	e796      	b.n	200242e0 <HAL_FLASH_Init+0x288>
200243b2:	2101      	movs	r1, #1
200243b4:	4620      	mov	r0, r4
200243b6:	f7fe fcce 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200243ba:	68e3      	ldr	r3, [r4, #12]
200243bc:	2102      	movs	r1, #2
200243be:	791a      	ldrb	r2, [r3, #4]
200243c0:	4620      	mov	r0, r4
200243c2:	f7fe ff67 	bl	20023294 <HAL_FLASH_ISSUE_CMD>
200243c6:	4620      	mov	r0, r4
200243c8:	f7fe fd1b 	bl	20022e02 <HAL_FLASH_READ32>
200243cc:	4605      	mov	r5, r0
200243ce:	200a      	movs	r0, #10
200243d0:	f7fd fec3 	bl	2002215a <HAL_Delay_us>
200243d4:	07eb      	lsls	r3, r5, #31
200243d6:	d4ec      	bmi.n	200243b2 <HAL_FLASH_Init+0x35a>
200243d8:	4631      	mov	r1, r6
200243da:	4620      	mov	r0, r4
200243dc:	f7ff fb79 	bl	20023ad2 <nand_clear_status>
200243e0:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200243e4:	2b02      	cmp	r3, #2
200243e6:	f47f af7b 	bne.w	200242e0 <HAL_FLASH_Init+0x288>
200243ea:	2101      	movs	r1, #1
200243ec:	4620      	mov	r0, r4
200243ee:	f7ff fb3f 	bl	20023a70 <HAL_NAND_EN_QUAL>
200243f2:	e775      	b.n	200242e0 <HAL_FLASH_Init+0x288>
200243f4:	05f5e100 	.word	0x05f5e100

200243f8 <HAL_MPI_OPSRAM_CAL_DELAY>:
200243f8:	b570      	push	{r4, r5, r6, lr}
200243fa:	460e      	mov	r6, r1
200243fc:	4615      	mov	r5, r2
200243fe:	4604      	mov	r4, r0
20024400:	b358      	cbz	r0, 2002445a <HAL_MPI_OPSRAM_CAL_DELAY+0x62>
20024402:	2202      	movs	r2, #2
20024404:	6803      	ldr	r3, [r0, #0]
20024406:	60da      	str	r2, [r3, #12]
20024408:	6802      	ldr	r2, [r0, #0]
2002440a:	6d93      	ldr	r3, [r2, #88]	@ 0x58
2002440c:	f023 7300 	bic.w	r3, r3, #33554432	@ 0x2000000
20024410:	6593      	str	r3, [r2, #88]	@ 0x58
20024412:	6802      	ldr	r2, [r0, #0]
20024414:	2000      	movs	r0, #0
20024416:	f8d2 3094 	ldr.w	r3, [r2, #148]	@ 0x94
2002441a:	f043 4300 	orr.w	r3, r3, #2147483648	@ 0x80000000
2002441e:	f8c2 3094 	str.w	r3, [r2, #148]	@ 0x94
20024422:	f7fd fe9a 	bl	2002215a <HAL_Delay_us>
20024426:	2014      	movs	r0, #20
20024428:	f7fd fe97 	bl	2002215a <HAL_Delay_us>
2002442c:	6820      	ldr	r0, [r4, #0]
2002442e:	f8d0 3094 	ldr.w	r3, [r0, #148]	@ 0x94
20024432:	05db      	lsls	r3, r3, #23
20024434:	d5fb      	bpl.n	2002442e <HAL_MPI_OPSRAM_CAL_DELAY+0x36>
20024436:	f8d0 3094 	ldr.w	r3, [r0, #148]	@ 0x94
2002443a:	f8d0 2094 	ldr.w	r2, [r0, #148]	@ 0x94
2002443e:	b2db      	uxtb	r3, r3
20024440:	f022 4200 	bic.w	r2, r2, #2147483648	@ 0x80000000
20024444:	f8c0 2094 	str.w	r2, [r0, #148]	@ 0x94
20024448:	1e5a      	subs	r2, r3, #1
2002444a:	7032      	strb	r2, [r6, #0]
2002444c:	2201      	movs	r2, #1
2002444e:	2000      	movs	r0, #0
20024450:	3b04      	subs	r3, #4
20024452:	702b      	strb	r3, [r5, #0]
20024454:	6823      	ldr	r3, [r4, #0]
20024456:	60da      	str	r2, [r3, #12]
20024458:	bd70      	pop	{r4, r5, r6, pc}
2002445a:	2001      	movs	r0, #1
2002445c:	e7fc      	b.n	20024458 <HAL_MPI_OPSRAM_CAL_DELAY+0x60>
	...

20024460 <HAL_SPI_PSRAM_Init>:
20024460:	b537      	push	{r0, r1, r2, r4, r5, lr}
20024462:	4614      	mov	r4, r2
20024464:	4605      	mov	r5, r0
20024466:	2800      	cmp	r0, #0
20024468:	d043      	beq.n	200244f2 <HAL_SPI_PSRAM_Init+0x92>
2002446a:	2900      	cmp	r1, #0
2002446c:	d041      	beq.n	200244f2 <HAL_SPI_PSRAM_Init+0x92>
2002446e:	f7fe fbf9 	bl	20022c64 <HAL_QSPI_Init>
20024472:	4628      	mov	r0, r5
20024474:	b2e1      	uxtb	r1, r4
20024476:	f7fe fccf 	bl	20022e18 <HAL_FLASH_SET_CLK_rom>
2002447a:	4628      	mov	r0, r5
2002447c:	f7ff fd66 	bl	20023f4c <HAL_QSPI_GET_CLK>
20024480:	4b1d      	ldr	r3, [pc, #116]	@ (200244f8 <HAL_SPI_PSRAM_Init+0x98>)
20024482:	4298      	cmp	r0, r3
20024484:	d930      	bls.n	200244e8 <HAL_SPI_PSRAM_Init+0x88>
20024486:	4b1d      	ldr	r3, [pc, #116]	@ (200244fc <HAL_SPI_PSRAM_Init+0x9c>)
20024488:	4298      	cmp	r0, r3
2002448a:	d92f      	bls.n	200244ec <HAL_SPI_PSRAM_Init+0x8c>
2002448c:	4b1c      	ldr	r3, [pc, #112]	@ (20024500 <HAL_SPI_PSRAM_Init+0xa0>)
2002448e:	4298      	cmp	r0, r3
20024490:	d922      	bls.n	200244d8 <HAL_SPI_PSRAM_Init+0x78>
20024492:	f240 34b6 	movw	r4, #950	@ 0x3b6
20024496:	f240 4374 	movw	r3, #1140	@ 0x474
2002449a:	4a1a      	ldr	r2, [pc, #104]	@ (20024504 <HAL_SPI_PSRAM_Init+0xa4>)
2002449c:	4290      	cmp	r0, r2
2002449e:	bf88      	it	hi
200244a0:	461c      	movhi	r4, r3
200244a2:	2200      	movs	r2, #0
200244a4:	2101      	movs	r1, #1
200244a6:	4628      	mov	r0, r5
200244a8:	f7ff f8f4 	bl	20023694 <HAL_QSPI_SET_CLK_INV>
200244ac:	2100      	movs	r1, #0
200244ae:	4622      	mov	r2, r4
200244b0:	2302      	movs	r3, #2
200244b2:	4628      	mov	r0, r5
200244b4:	9100      	str	r1, [sp, #0]
200244b6:	f7fe fd9a 	bl	20022fee <HAL_FLASH_SET_CS_TIME>
200244ba:	4604      	mov	r4, r0
200244bc:	b948      	cbnz	r0, 200244d2 <HAL_SPI_PSRAM_Init+0x72>
200244be:	2106      	movs	r1, #6
200244c0:	4628      	mov	r0, r5
200244c2:	f7fe fda9 	bl	20023018 <HAL_FLASH_SET_ROW_BOUNDARY>
200244c6:	4604      	mov	r4, r0
200244c8:	b918      	cbnz	r0, 200244d2 <HAL_SPI_PSRAM_Init+0x72>
200244ca:	2101      	movs	r1, #1
200244cc:	4628      	mov	r0, r5
200244ce:	f7fe fd48 	bl	20022f62 <HAL_FLASH_ENABLE_QSPI>
200244d2:	4620      	mov	r0, r4
200244d4:	b003      	add	sp, #12
200244d6:	bd30      	pop	{r4, r5, pc}
200244d8:	4b0b      	ldr	r3, [pc, #44]	@ (20024508 <HAL_SPI_PSRAM_Init+0xa8>)
200244da:	f44f 743e 	mov.w	r4, #760	@ 0x2f8
200244de:	4298      	cmp	r0, r3
200244e0:	d8df      	bhi.n	200244a2 <HAL_SPI_PSRAM_Init+0x42>
200244e2:	2200      	movs	r2, #0
200244e4:	4611      	mov	r1, r2
200244e6:	e7de      	b.n	200244a6 <HAL_SPI_PSRAM_Init+0x46>
200244e8:	24b4      	movs	r4, #180	@ 0xb4
200244ea:	e7fa      	b.n	200244e2 <HAL_SPI_PSRAM_Init+0x82>
200244ec:	f44f 74be 	mov.w	r4, #380	@ 0x17c
200244f0:	e7f7      	b.n	200244e2 <HAL_SPI_PSRAM_Init+0x82>
200244f2:	2401      	movs	r4, #1
200244f4:	e7ed      	b.n	200244d2 <HAL_SPI_PSRAM_Init+0x72>
200244f6:	bf00      	nop
200244f8:	016e3600 	.word	0x016e3600
200244fc:	02dc6c00 	.word	0x02dc6c00
20024500:	05b8d800 	.word	0x05b8d800
20024504:	07270e00 	.word	0x07270e00
20024508:	03938700 	.word	0x03938700

2002450c <HAL_MPI_MR_WRITE>:
2002450c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002450e:	460e      	mov	r6, r1
20024510:	4617      	mov	r7, r2
20024512:	4605      	mov	r5, r0
20024514:	b087      	sub	sp, #28
20024516:	b1d8      	cbz	r0, 20024550 <HAL_MPI_MR_WRITE+0x44>
20024518:	2207      	movs	r2, #7
2002451a:	2400      	movs	r4, #0
2002451c:	2303      	movs	r3, #3
2002451e:	e9cd 2203 	strd	r2, r2, [sp, #12]
20024522:	2101      	movs	r1, #1
20024524:	e9cd 4301 	strd	r4, r3, [sp, #4]
20024528:	9400      	str	r4, [sp, #0]
2002452a:	4623      	mov	r3, r4
2002452c:	f7fe fc7d 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
20024530:	2102      	movs	r1, #2
20024532:	4628      	mov	r0, r5
20024534:	f7fe fc0f 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
20024538:	4639      	mov	r1, r7
2002453a:	4628      	mov	r0, r5
2002453c:	f7fe fc04 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20024540:	4632      	mov	r2, r6
20024542:	21c0      	movs	r1, #192	@ 0xc0
20024544:	4628      	mov	r0, r5
20024546:	f7fe fc2b 	bl	20022da0 <HAL_FLASH_SET_CMD>
2002454a:	4620      	mov	r0, r4
2002454c:	b007      	add	sp, #28
2002454e:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024550:	2001      	movs	r0, #1
20024552:	e7fb      	b.n	2002454c <HAL_MPI_MR_WRITE+0x40>

20024554 <HAL_MPI_SET_FIXLAT>:
20024554:	e92d 41ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, lr}
20024558:	460c      	mov	r4, r1
2002455a:	4616      	mov	r6, r2
2002455c:	461f      	mov	r7, r3
2002455e:	4605      	mov	r5, r0
20024560:	2800      	cmp	r0, #0
20024562:	d040      	beq.n	200245e6 <HAL_MPI_SET_FIXLAT+0x92>
20024564:	466b      	mov	r3, sp
20024566:	4a21      	ldr	r2, [pc, #132]	@ (200245ec <HAL_MPI_SET_FIXLAT+0x98>)
20024568:	6810      	ldr	r0, [r2, #0]
2002456a:	6851      	ldr	r1, [r2, #4]
2002456c:	c303      	stmia	r3!, {r0, r1}
2002456e:	6890      	ldr	r0, [r2, #8]
20024570:	68d1      	ldr	r1, [r2, #12]
20024572:	c303      	stmia	r3!, {r0, r1}
20024574:	4628      	mov	r0, r5
20024576:	b2e1      	uxtb	r1, r4
20024578:	f7fe fd74 	bl	20023064 <HAL_MPI_EN_FIXLAT>
2002457c:	f107 0310 	add.w	r3, r7, #16
20024580:	446b      	add	r3, sp
20024582:	f813 8c08 	ldrb.w	r8, [r3, #-8]
20024586:	ea4f 1848 	mov.w	r8, r8, lsl #5
2002458a:	fa5f f888 	uxtb.w	r8, r8
2002458e:	b30c      	cbz	r4, 200245d4 <HAL_MPI_SET_FIXLAT+0x80>
20024590:	ab04      	add	r3, sp, #16
20024592:	eb03 0356 	add.w	r3, r3, r6, lsr #1
20024596:	f813 4c10 	ldrb.w	r4, [r3, #-16]
2002459a:	00a4      	lsls	r4, r4, #2
2002459c:	f044 0421 	orr.w	r4, r4, #33	@ 0x21
200245a0:	b264      	sxtb	r4, r4
200245a2:	f004 02fd 	and.w	r2, r4, #253	@ 0xfd
200245a6:	2100      	movs	r1, #0
200245a8:	4628      	mov	r0, r5
200245aa:	f7ff ffaf 	bl	2002450c <HAL_MPI_MR_WRITE>
200245ae:	1e71      	subs	r1, r6, #1
200245b0:	4628      	mov	r0, r5
200245b2:	b249      	sxtb	r1, r1
200245b4:	f7fe fdb4 	bl	20023120 <HAL_MPI_MODIFY_RCMD_DELAY>
200245b8:	4642      	mov	r2, r8
200245ba:	2104      	movs	r1, #4
200245bc:	4628      	mov	r0, r5
200245be:	f7ff ffa5 	bl	2002450c <HAL_MPI_MR_WRITE>
200245c2:	1e79      	subs	r1, r7, #1
200245c4:	4628      	mov	r0, r5
200245c6:	b249      	sxtb	r1, r1
200245c8:	f7fe fdb3 	bl	20023132 <HAL_MPI_MODIFY_WCMD_DELAY>
200245cc:	2000      	movs	r0, #0
200245ce:	b004      	add	sp, #16
200245d0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200245d4:	f106 0310 	add.w	r3, r6, #16
200245d8:	446b      	add	r3, sp
200245da:	f813 4c10 	ldrb.w	r4, [r3, #-16]
200245de:	00a4      	lsls	r4, r4, #2
200245e0:	f044 0401 	orr.w	r4, r4, #1
200245e4:	e7dc      	b.n	200245a0 <HAL_MPI_SET_FIXLAT+0x4c>
200245e6:	2001      	movs	r0, #1
200245e8:	e7f1      	b.n	200245ce <HAL_MPI_SET_FIXLAT+0x7a>
200245ea:	bf00      	nop
200245ec:	2002ba28 	.word	0x2002ba28

200245f0 <HAL_LEGACY_MR_WRITE>:
200245f0:	b5f0      	push	{r4, r5, r6, r7, lr}
200245f2:	460e      	mov	r6, r1
200245f4:	4617      	mov	r7, r2
200245f6:	4604      	mov	r4, r0
200245f8:	b087      	sub	sp, #28
200245fa:	b1e0      	cbz	r0, 20024636 <HAL_LEGACY_MR_WRITE+0x46>
200245fc:	2207      	movs	r2, #7
200245fe:	2500      	movs	r5, #0
20024600:	2302      	movs	r3, #2
20024602:	e9cd 2203 	strd	r2, r2, [sp, #12]
20024606:	e9cd 5301 	strd	r5, r3, [sp, #4]
2002460a:	9500      	str	r5, [sp, #0]
2002460c:	f990 302e 	ldrsb.w	r3, [r0, #46]	@ 0x2e
20024610:	2101      	movs	r1, #1
20024612:	f7fe fc0a 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
20024616:	2104      	movs	r1, #4
20024618:	4620      	mov	r0, r4
2002461a:	f7fe fb9c 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
2002461e:	4639      	mov	r1, r7
20024620:	4620      	mov	r0, r4
20024622:	f7fe fb91 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
20024626:	4632      	mov	r2, r6
20024628:	21c0      	movs	r1, #192	@ 0xc0
2002462a:	4620      	mov	r0, r4
2002462c:	f7fe fbb8 	bl	20022da0 <HAL_FLASH_SET_CMD>
20024630:	4628      	mov	r0, r5
20024632:	b007      	add	sp, #28
20024634:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024636:	2001      	movs	r0, #1
20024638:	e7fb      	b.n	20024632 <HAL_LEGACY_MR_WRITE+0x42>

2002463a <HAL_LEGACY_CFG_READ>:
2002463a:	b530      	push	{r4, r5, lr}
2002463c:	4605      	mov	r5, r0
2002463e:	b085      	sub	sp, #20
20024640:	b1a0      	cbz	r0, 2002466c <HAL_LEGACY_CFG_READ+0x32>
20024642:	2400      	movs	r4, #0
20024644:	2107      	movs	r1, #7
20024646:	2302      	movs	r3, #2
20024648:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
2002464c:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024650:	0052      	lsls	r2, r2, #1
20024652:	e9cd 4300 	strd	r4, r3, [sp]
20024656:	b252      	sxtb	r2, r2
20024658:	4623      	mov	r3, r4
2002465a:	f7fe fb2f 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
2002465e:	4621      	mov	r1, r4
20024660:	4628      	mov	r0, r5
20024662:	f7fe fb20 	bl	20022ca6 <HAL_FLASH_SET_AHB_RCMD>
20024666:	4620      	mov	r0, r4
20024668:	b005      	add	sp, #20
2002466a:	bd30      	pop	{r4, r5, pc}
2002466c:	2001      	movs	r0, #1
2002466e:	e7fb      	b.n	20024668 <HAL_LEGACY_CFG_READ+0x2e>

20024670 <HAL_LEGACY_CFG_WRITE>:
20024670:	b530      	push	{r4, r5, lr}
20024672:	4605      	mov	r5, r0
20024674:	b085      	sub	sp, #20
20024676:	b190      	cbz	r0, 2002469e <HAL_LEGACY_CFG_WRITE+0x2e>
20024678:	2107      	movs	r1, #7
2002467a:	2400      	movs	r4, #0
2002467c:	2302      	movs	r3, #2
2002467e:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024682:	e9cd 4300 	strd	r4, r3, [sp]
20024686:	4623      	mov	r3, r4
20024688:	f990 202e 	ldrsb.w	r2, [r0, #46]	@ 0x2e
2002468c:	f7fe fb3f 	bl	20022d0e <HAL_FLASH_CFG_AHB_WCMD>
20024690:	2180      	movs	r1, #128	@ 0x80
20024692:	4628      	mov	r0, r5
20024694:	f7fe fb2f 	bl	20022cf6 <HAL_FLASH_SET_AHB_WCMD>
20024698:	4620      	mov	r0, r4
2002469a:	b005      	add	sp, #20
2002469c:	bd30      	pop	{r4, r5, pc}
2002469e:	2001      	movs	r0, #1
200246a0:	e7fb      	b.n	2002469a <HAL_LEGACY_CFG_WRITE+0x2a>

200246a2 <HAL_PSRAM_RESET>:
200246a2:	b5f0      	push	{r4, r5, r6, r7, lr}
200246a4:	4604      	mov	r4, r0
200246a6:	b087      	sub	sp, #28
200246a8:	2800      	cmp	r0, #0
200246aa:	d03b      	beq.n	20024724 <HAL_PSRAM_RESET+0x82>
200246ac:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
200246b0:	2b05      	cmp	r3, #5
200246b2:	d034      	beq.n	2002471e <HAL_PSRAM_RESET+0x7c>
200246b4:	3b03      	subs	r3, #3
200246b6:	2b01      	cmp	r3, #1
200246b8:	d82e      	bhi.n	20024718 <HAL_PSRAM_RESET+0x76>
200246ba:	2601      	movs	r6, #1
200246bc:	2703      	movs	r7, #3
200246be:	2300      	movs	r3, #0
200246c0:	2507      	movs	r5, #7
200246c2:	b276      	sxtb	r6, r6
200246c4:	b27f      	sxtb	r7, r7
200246c6:	461a      	mov	r2, r3
200246c8:	2101      	movs	r1, #1
200246ca:	4620      	mov	r0, r4
200246cc:	e9cd 5503 	strd	r5, r5, [sp, #12]
200246d0:	e9cd 5701 	strd	r5, r7, [sp, #4]
200246d4:	9600      	str	r6, [sp, #0]
200246d6:	f7fe fba8 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
200246da:	2200      	movs	r2, #0
200246dc:	21ff      	movs	r1, #255	@ 0xff
200246de:	4620      	mov	r0, r4
200246e0:	f7fe fb5e 	bl	20022da0 <HAL_FLASH_SET_CMD>
200246e4:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200246e8:	2b05      	cmp	r3, #5
200246ea:	d10f      	bne.n	2002470c <HAL_PSRAM_RESET+0x6a>
200246ec:	2300      	movs	r3, #0
200246ee:	2101      	movs	r1, #1
200246f0:	461a      	mov	r2, r3
200246f2:	4620      	mov	r0, r4
200246f4:	e9cd 5503 	strd	r5, r5, [sp, #12]
200246f8:	e9cd 5701 	strd	r5, r7, [sp, #4]
200246fc:	9600      	str	r6, [sp, #0]
200246fe:	f7fe fb94 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
20024702:	2200      	movs	r2, #0
20024704:	21ff      	movs	r1, #255	@ 0xff
20024706:	4620      	mov	r0, r4
20024708:	f7fe fb4a 	bl	20022da0 <HAL_FLASH_SET_CMD>
2002470c:	2000      	movs	r0, #0
2002470e:	f7fd fd24 	bl	2002215a <HAL_Delay_us>
20024712:	2003      	movs	r0, #3
20024714:	f7fd fd21 	bl	2002215a <HAL_Delay_us>
20024718:	2000      	movs	r0, #0
2002471a:	b007      	add	sp, #28
2002471c:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002471e:	2603      	movs	r6, #3
20024720:	2702      	movs	r7, #2
20024722:	e7cc      	b.n	200246be <HAL_PSRAM_RESET+0x1c>
20024724:	2001      	movs	r0, #1
20024726:	e7f8      	b.n	2002471a <HAL_PSRAM_RESET+0x78>

20024728 <HAL_OPI_PSRAM_Init>:
20024728:	b530      	push	{r4, r5, lr}
2002472a:	4604      	mov	r4, r0
2002472c:	b085      	sub	sp, #20
2002472e:	2800      	cmp	r0, #0
20024730:	d07e      	beq.n	20024830 <HAL_OPI_PSRAM_Init+0x108>
20024732:	2900      	cmp	r1, #0
20024734:	d07c      	beq.n	20024830 <HAL_OPI_PSRAM_Init+0x108>
20024736:	f7fe fa95 	bl	20022c64 <HAL_QSPI_Init>
2002473a:	6823      	ldr	r3, [r4, #0]
2002473c:	2101      	movs	r1, #1
2002473e:	4620      	mov	r0, r4
20024740:	681d      	ldr	r5, [r3, #0]
20024742:	f7fe fc1c 	bl	20022f7e <HAL_FLASH_ENABLE_OPI>
20024746:	2101      	movs	r1, #1
20024748:	4620      	mov	r0, r4
2002474a:	f7fe fb65 	bl	20022e18 <HAL_FLASH_SET_CLK_rom>
2002474e:	4620      	mov	r0, r4
20024750:	f7ff fbfc 	bl	20023f4c <HAL_QSPI_GET_CLK>
20024754:	0840      	lsrs	r0, r0, #1
20024756:	61a0      	str	r0, [r4, #24]
20024758:	f10d 020e 	add.w	r2, sp, #14
2002475c:	4620      	mov	r0, r4
2002475e:	f10d 010f 	add.w	r1, sp, #15
20024762:	f7ff fe49 	bl	200243f8 <HAL_MPI_OPSRAM_CAL_DELAY>
20024766:	4603      	mov	r3, r0
20024768:	b100      	cbz	r0, 2002476c <HAL_OPI_PSRAM_Init+0x44>
2002476a:	e7fe      	b.n	2002476a <HAL_OPI_PSRAM_Init+0x42>
2002476c:	69a2      	ldr	r2, [r4, #24]
2002476e:	4931      	ldr	r1, [pc, #196]	@ (20024834 <HAL_OPI_PSRAM_Init+0x10c>)
20024770:	428a      	cmp	r2, r1
20024772:	d832      	bhi.n	200247da <HAL_OPI_PSRAM_Init+0xb2>
20024774:	2220      	movs	r2, #32
20024776:	2103      	movs	r1, #3
20024778:	f88d 200e 	strb.w	r2, [sp, #14]
2002477c:	f88d 200f 	strb.w	r2, [sp, #15]
20024780:	4608      	mov	r0, r1
20024782:	22b4      	movs	r2, #180	@ 0xb4
20024784:	f884 102d 	strb.w	r1, [r4, #45]	@ 0x2d
20024788:	f884 102e 	strb.w	r1, [r4, #46]	@ 0x2e
2002478c:	2106      	movs	r1, #6
2002478e:	9000      	str	r0, [sp, #0]
20024790:	4620      	mov	r0, r4
20024792:	f7fe fc2c 	bl	20022fee <HAL_FLASH_SET_CS_TIME>
20024796:	2107      	movs	r1, #7
20024798:	4620      	mov	r0, r4
2002479a:	f7fe fc3d 	bl	20023018 <HAL_FLASH_SET_ROW_BOUNDARY>
2002479e:	2101      	movs	r1, #1
200247a0:	4620      	mov	r0, r4
200247a2:	f7fe fc6d 	bl	20023080 <HAL_MPI_ENABLE_DQS>
200247a6:	f89d 100e 	ldrb.w	r1, [sp, #14]
200247aa:	4620      	mov	r0, r4
200247ac:	f7fe fc76 	bl	2002309c <HAL_MPI_SET_DQS_DELAY>
200247b0:	2200      	movs	r2, #0
200247b2:	f89d 100f 	ldrb.w	r1, [sp, #15]
200247b6:	4620      	mov	r0, r4
200247b8:	f7fe fc7c 	bl	200230b4 <HAL_MPI_SET_SCK>
200247bc:	2101      	movs	r1, #1
200247be:	4620      	mov	r0, r4
200247c0:	f7fe fbcf 	bl	20022f62 <HAL_FLASH_ENABLE_QSPI>
200247c4:	07eb      	lsls	r3, r5, #31
200247c6:	d405      	bmi.n	200247d4 <HAL_OPI_PSRAM_Init+0xac>
200247c8:	4b1b      	ldr	r3, [pc, #108]	@ (20024838 <HAL_OPI_PSRAM_Init+0x110>)
200247ca:	681b      	ldr	r3, [r3, #0]
200247cc:	f003 0303 	and.w	r3, r3, #3
200247d0:	2b03      	cmp	r3, #3
200247d2:	d129      	bne.n	20024828 <HAL_OPI_PSRAM_Init+0x100>
200247d4:	2000      	movs	r0, #0
200247d6:	b005      	add	sp, #20
200247d8:	bd30      	pop	{r4, r5, pc}
200247da:	4b18      	ldr	r3, [pc, #96]	@ (2002483c <HAL_OPI_PSRAM_Init+0x114>)
200247dc:	429a      	cmp	r2, r3
200247de:	d911      	bls.n	20024804 <HAL_OPI_PSRAM_Init+0xdc>
200247e0:	f103 73b7 	add.w	r3, r3, #23986176	@ 0x16e0000
200247e4:	f503 5358 	add.w	r3, r3, #13824	@ 0x3600
200247e8:	429a      	cmp	r2, r3
200247ea:	d911      	bls.n	20024810 <HAL_OPI_PSRAM_Init+0xe8>
200247ec:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
200247f0:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
200247f4:	429a      	cmp	r2, r3
200247f6:	d911      	bls.n	2002481c <HAL_OPI_PSRAM_Init+0xf4>
200247f8:	2107      	movs	r1, #7
200247fa:	2014      	movs	r0, #20
200247fc:	2308      	movs	r3, #8
200247fe:	f240 5232 	movw	r2, #1330	@ 0x532
20024802:	e7bf      	b.n	20024784 <HAL_OPI_PSRAM_Init+0x5c>
20024804:	2105      	movs	r1, #5
20024806:	200e      	movs	r0, #14
20024808:	2303      	movs	r3, #3
2002480a:	f240 32b6 	movw	r2, #950	@ 0x3b6
2002480e:	e7b9      	b.n	20024784 <HAL_OPI_PSRAM_Init+0x5c>
20024810:	2106      	movs	r1, #6
20024812:	2011      	movs	r0, #17
20024814:	2305      	movs	r3, #5
20024816:	f240 4274 	movw	r2, #1140	@ 0x474
2002481a:	e7b3      	b.n	20024784 <HAL_OPI_PSRAM_Init+0x5c>
2002481c:	2106      	movs	r1, #6
2002481e:	2013      	movs	r0, #19
20024820:	460b      	mov	r3, r1
20024822:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20024826:	e7ad      	b.n	20024784 <HAL_OPI_PSRAM_Init+0x5c>
20024828:	4620      	mov	r0, r4
2002482a:	f7ff ff3a 	bl	200246a2 <HAL_PSRAM_RESET>
2002482e:	e7d1      	b.n	200247d4 <HAL_OPI_PSRAM_Init+0xac>
20024830:	2001      	movs	r0, #1
20024832:	e7d0      	b.n	200247d6 <HAL_OPI_PSRAM_Init+0xae>
20024834:	016e3600 	.word	0x016e3600
20024838:	500c0000 	.word	0x500c0000
2002483c:	07270e00 	.word	0x07270e00

20024840 <HAL_LEGACY_PSRAM_Init>:
20024840:	b5f0      	push	{r4, r5, r6, r7, lr}
20024842:	4604      	mov	r4, r0
20024844:	b085      	sub	sp, #20
20024846:	2800      	cmp	r0, #0
20024848:	f000 80a3 	beq.w	20024992 <HAL_LEGACY_PSRAM_Init+0x152>
2002484c:	2900      	cmp	r1, #0
2002484e:	f000 80a0 	beq.w	20024992 <HAL_LEGACY_PSRAM_Init+0x152>
20024852:	f7fe fa07 	bl	20022c64 <HAL_QSPI_Init>
20024856:	6823      	ldr	r3, [r4, #0]
20024858:	2101      	movs	r1, #1
2002485a:	4620      	mov	r0, r4
2002485c:	681e      	ldr	r6, [r3, #0]
2002485e:	f7fe fb8e 	bl	20022f7e <HAL_FLASH_ENABLE_OPI>
20024862:	2101      	movs	r1, #1
20024864:	4620      	mov	r0, r4
20024866:	f7fe fad7 	bl	20022e18 <HAL_FLASH_SET_CLK_rom>
2002486a:	4620      	mov	r0, r4
2002486c:	f7ff fb6e 	bl	20023f4c <HAL_QSPI_GET_CLK>
20024870:	0845      	lsrs	r5, r0, #1
20024872:	61a5      	str	r5, [r4, #24]
20024874:	4620      	mov	r0, r4
20024876:	f10d 020e 	add.w	r2, sp, #14
2002487a:	f10d 010f 	add.w	r1, sp, #15
2002487e:	f7ff fdbb 	bl	200243f8 <HAL_MPI_OPSRAM_CAL_DELAY>
20024882:	4603      	mov	r3, r0
20024884:	b100      	cbz	r0, 20024888 <HAL_LEGACY_PSRAM_Init+0x48>
20024886:	e7fe      	b.n	20024886 <HAL_LEGACY_PSRAM_Init+0x46>
20024888:	4a43      	ldr	r2, [pc, #268]	@ (20024998 <HAL_LEGACY_PSRAM_Init+0x158>)
2002488a:	4f44      	ldr	r7, [pc, #272]	@ (2002499c <HAL_LEGACY_PSRAM_Init+0x15c>)
2002488c:	4295      	cmp	r5, r2
2002488e:	d84c      	bhi.n	2002492a <HAL_LEGACY_PSRAM_Init+0xea>
20024890:	2220      	movs	r2, #32
20024892:	2103      	movs	r1, #3
20024894:	f88d 200e 	strb.w	r2, [sp, #14]
20024898:	f88d 200f 	strb.w	r2, [sp, #15]
2002489c:	22b4      	movs	r2, #180	@ 0xb4
2002489e:	9100      	str	r1, [sp, #0]
200248a0:	4620      	mov	r0, r4
200248a2:	2106      	movs	r1, #6
200248a4:	f7fe fba3 	bl	20022fee <HAL_FLASH_SET_CS_TIME>
200248a8:	2107      	movs	r1, #7
200248aa:	4620      	mov	r0, r4
200248ac:	f7fe fbb4 	bl	20023018 <HAL_FLASH_SET_ROW_BOUNDARY>
200248b0:	2101      	movs	r1, #1
200248b2:	4620      	mov	r0, r4
200248b4:	f7fe fbe4 	bl	20023080 <HAL_MPI_ENABLE_DQS>
200248b8:	f89d 100e 	ldrb.w	r1, [sp, #14]
200248bc:	4620      	mov	r0, r4
200248be:	f7fe fbed 	bl	2002309c <HAL_MPI_SET_DQS_DELAY>
200248c2:	2200      	movs	r2, #0
200248c4:	f89d 100f 	ldrb.w	r1, [sp, #15]
200248c8:	4620      	mov	r0, r4
200248ca:	f7fe fbf3 	bl	200230b4 <HAL_MPI_SET_SCK>
200248ce:	2101      	movs	r1, #1
200248d0:	4620      	mov	r0, r4
200248d2:	f7fe fbab 	bl	2002302c <HAL_FLASH_SET_LEGACY>
200248d6:	2101      	movs	r1, #1
200248d8:	4620      	mov	r0, r4
200248da:	f7fe fb42 	bl	20022f62 <HAL_FLASH_ENABLE_QSPI>
200248de:	07f3      	lsls	r3, r6, #31
200248e0:	d405      	bmi.n	200248ee <HAL_LEGACY_PSRAM_Init+0xae>
200248e2:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
200248e6:	b913      	cbnz	r3, 200248ee <HAL_LEGACY_PSRAM_Init+0xae>
200248e8:	4620      	mov	r0, r4
200248ea:	f7ff feda 	bl	200246a2 <HAL_PSRAM_RESET>
200248ee:	42bd      	cmp	r5, r7
200248f0:	d945      	bls.n	2002497e <HAL_LEGACY_PSRAM_Init+0x13e>
200248f2:	4b2b      	ldr	r3, [pc, #172]	@ (200249a0 <HAL_LEGACY_PSRAM_Init+0x160>)
200248f4:	429d      	cmp	r5, r3
200248f6:	d947      	bls.n	20024988 <HAL_LEGACY_PSRAM_Init+0x148>
200248f8:	2206      	movs	r2, #6
200248fa:	2302      	movs	r3, #2
200248fc:	2588      	movs	r5, #136	@ 0x88
200248fe:	263b      	movs	r6, #59	@ 0x3b
20024900:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20024904:	2101      	movs	r1, #1
20024906:	f884 202d 	strb.w	r2, [r4, #45]	@ 0x2d
2002490a:	4620      	mov	r0, r4
2002490c:	f7fe fbaa 	bl	20023064 <HAL_MPI_EN_FIXLAT>
20024910:	4632      	mov	r2, r6
20024912:	2100      	movs	r1, #0
20024914:	4620      	mov	r0, r4
20024916:	f7ff fe6b 	bl	200245f0 <HAL_LEGACY_MR_WRITE>
2002491a:	462a      	mov	r2, r5
2002491c:	2104      	movs	r1, #4
2002491e:	4620      	mov	r0, r4
20024920:	f7ff fe66 	bl	200245f0 <HAL_LEGACY_MR_WRITE>
20024924:	2000      	movs	r0, #0
20024926:	b005      	add	sp, #20
20024928:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002492a:	42bd      	cmp	r5, r7
2002492c:	d913      	bls.n	20024956 <HAL_LEGACY_PSRAM_Init+0x116>
2002492e:	4b1d      	ldr	r3, [pc, #116]	@ (200249a4 <HAL_LEGACY_PSRAM_Init+0x164>)
20024930:	429d      	cmp	r5, r3
20024932:	d915      	bls.n	20024960 <HAL_LEGACY_PSRAM_Init+0x120>
20024934:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20024938:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
2002493c:	429d      	cmp	r5, r3
2002493e:	d914      	bls.n	2002496a <HAL_LEGACY_PSRAM_Init+0x12a>
20024940:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20024944:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20024948:	429d      	cmp	r5, r3
2002494a:	d813      	bhi.n	20024974 <HAL_LEGACY_PSRAM_Init+0x134>
2002494c:	2114      	movs	r1, #20
2002494e:	2308      	movs	r3, #8
20024950:	f240 5232 	movw	r2, #1330	@ 0x532
20024954:	e7a3      	b.n	2002489e <HAL_LEGACY_PSRAM_Init+0x5e>
20024956:	210e      	movs	r1, #14
20024958:	2303      	movs	r3, #3
2002495a:	f240 32b6 	movw	r2, #950	@ 0x3b6
2002495e:	e79e      	b.n	2002489e <HAL_LEGACY_PSRAM_Init+0x5e>
20024960:	2111      	movs	r1, #17
20024962:	2305      	movs	r3, #5
20024964:	f240 4274 	movw	r2, #1140	@ 0x474
20024968:	e799      	b.n	2002489e <HAL_LEGACY_PSRAM_Init+0x5e>
2002496a:	2113      	movs	r1, #19
2002496c:	2306      	movs	r3, #6
2002496e:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20024972:	e794      	b.n	2002489e <HAL_LEGACY_PSRAM_Init+0x5e>
20024974:	2117      	movs	r1, #23
20024976:	2309      	movs	r3, #9
20024978:	f44f 62be 	mov.w	r2, #1520	@ 0x5f0
2002497c:	e78f      	b.n	2002489e <HAL_LEGACY_PSRAM_Init+0x5e>
2002497e:	2204      	movs	r2, #4
20024980:	2300      	movs	r3, #0
20024982:	2508      	movs	r5, #8
20024984:	2633      	movs	r6, #51	@ 0x33
20024986:	e7bb      	b.n	20024900 <HAL_LEGACY_PSRAM_Init+0xc0>
20024988:	2205      	movs	r2, #5
2002498a:	2300      	movs	r3, #0
2002498c:	2508      	movs	r5, #8
2002498e:	2637      	movs	r6, #55	@ 0x37
20024990:	e7b6      	b.n	20024900 <HAL_LEGACY_PSRAM_Init+0xc0>
20024992:	2001      	movs	r0, #1
20024994:	e7c7      	b.n	20024926 <HAL_LEGACY_PSRAM_Init+0xe6>
20024996:	bf00      	nop
20024998:	016e3600 	.word	0x016e3600
2002499c:	07270e00 	.word	0x07270e00
200249a0:	094c5f00 	.word	0x094c5f00
200249a4:	08954400 	.word	0x08954400

200249a8 <HAL_HYPER_PSRAM_WriteCR>:
200249a8:	b570      	push	{r4, r5, r6, lr}
200249aa:	460e      	mov	r6, r1
200249ac:	4615      	mov	r5, r2
200249ae:	4604      	mov	r4, r0
200249b0:	b086      	sub	sp, #24
200249b2:	b1f8      	cbz	r0, 200249f4 <HAL_HYPER_PSRAM_WriteCR+0x4c>
200249b4:	2207      	movs	r2, #7
200249b6:	2303      	movs	r3, #3
200249b8:	e9cd 2301 	strd	r2, r3, [sp, #4]
200249bc:	2300      	movs	r3, #0
200249be:	e9cd 2203 	strd	r2, r2, [sp, #12]
200249c2:	9300      	str	r3, [sp, #0]
200249c4:	2101      	movs	r1, #1
200249c6:	f7fe fa30 	bl	20022e2a <HAL_FLASH_MANUAL_CMD>
200249ca:	4631      	mov	r1, r6
200249cc:	4620      	mov	r0, r4
200249ce:	f7fe f9d6 	bl	20022d7e <HAL_FLASH_WRITE_ABYTE>
200249d2:	2102      	movs	r1, #2
200249d4:	4620      	mov	r0, r4
200249d6:	f7fe f9be 	bl	20022d56 <HAL_FLASH_WRITE_DLEN>
200249da:	4629      	mov	r1, r5
200249dc:	4620      	mov	r0, r4
200249de:	f7fe f9b3 	bl	20022d48 <HAL_FLASH_WRITE_WORD>
200249e2:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
200249e6:	2160      	movs	r1, #96	@ 0x60
200249e8:	4620      	mov	r0, r4
200249ea:	b006      	add	sp, #24
200249ec:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
200249f0:	f7fe b9d6 	b.w	20022da0 <HAL_FLASH_SET_CMD>
200249f4:	b006      	add	sp, #24
200249f6:	bd70      	pop	{r4, r5, r6, pc}

200249f8 <HAL_HYPER_PSRAM_Init>:
200249f8:	b538      	push	{r3, r4, r5, lr}
200249fa:	4605      	mov	r5, r0
200249fc:	2201      	movs	r2, #1
200249fe:	f7ff fe93 	bl	20024728 <HAL_OPI_PSRAM_Init>
20024a02:	69ac      	ldr	r4, [r5, #24]
20024a04:	4b12      	ldr	r3, [pc, #72]	@ (20024a50 <HAL_HYPER_PSRAM_Init+0x58>)
20024a06:	429c      	cmp	r4, r3
20024a08:	d91c      	bls.n	20024a44 <HAL_HYPER_PSRAM_Init+0x4c>
20024a0a:	4b12      	ldr	r3, [pc, #72]	@ (20024a54 <HAL_HYPER_PSRAM_Init+0x5c>)
20024a0c:	429c      	cmp	r4, r3
20024a0e:	d91b      	bls.n	20024a48 <HAL_HYPER_PSRAM_Init+0x50>
20024a10:	4b11      	ldr	r3, [pc, #68]	@ (20024a58 <HAL_HYPER_PSRAM_Init+0x60>)
20024a12:	429c      	cmp	r4, r3
20024a14:	d91a      	bls.n	20024a4c <HAL_HYPER_PSRAM_Init+0x54>
20024a16:	4b11      	ldr	r3, [pc, #68]	@ (20024a5c <HAL_HYPER_PSRAM_Init+0x64>)
20024a18:	429c      	cmp	r4, r3
20024a1a:	bf8c      	ite	hi
20024a1c:	2402      	movhi	r4, #2
20024a1e:	2401      	movls	r4, #1
20024a20:	2101      	movs	r1, #1
20024a22:	4628      	mov	r0, r5
20024a24:	f7fe fab9 	bl	20022f9a <HAL_FLASH_ENABLE_HYPER>
20024a28:	f240 428f 	movw	r2, #1167	@ 0x48f
20024a2c:	4628      	mov	r0, r5
20024a2e:	ea42 3204 	orr.w	r2, r2, r4, lsl #12
20024a32:	2100      	movs	r1, #0
20024a34:	f7ff ffb8 	bl	200249a8 <HAL_HYPER_PSRAM_WriteCR>
20024a38:	2101      	movs	r1, #1
20024a3a:	4628      	mov	r0, r5
20024a3c:	f7fe fb12 	bl	20023064 <HAL_MPI_EN_FIXLAT>
20024a40:	2000      	movs	r0, #0
20024a42:	bd38      	pop	{r3, r4, r5, pc}
20024a44:	240e      	movs	r4, #14
20024a46:	e7eb      	b.n	20024a20 <HAL_HYPER_PSRAM_Init+0x28>
20024a48:	240f      	movs	r4, #15
20024a4a:	e7e9      	b.n	20024a20 <HAL_HYPER_PSRAM_Init+0x28>
20024a4c:	2400      	movs	r4, #0
20024a4e:	e7e7      	b.n	20024a20 <HAL_HYPER_PSRAM_Init+0x28>
20024a50:	0510ff40 	.word	0x0510ff40
20024a54:	0632ea00 	.word	0x0632ea00
20024a58:	07ed6b40 	.word	0x07ed6b40
20024a5c:	09e4f580 	.word	0x09e4f580

20024a60 <HAL_HYPER_CFG_READ>:
20024a60:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20024a62:	b160      	cbz	r0, 20024a7e <HAL_HYPER_CFG_READ+0x1e>
20024a64:	2107      	movs	r1, #7
20024a66:	2303      	movs	r3, #3
20024a68:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20024a6c:	e9cd 1300 	strd	r1, r3, [sp]
20024a70:	3a01      	subs	r2, #1
20024a72:	2300      	movs	r3, #0
20024a74:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024a78:	b252      	sxtb	r2, r2
20024a7a:	f7fe f91f 	bl	20022cbc <HAL_FLASH_CFG_AHB_RCMD>
20024a7e:	b005      	add	sp, #20
20024a80:	f85d fb04 	ldr.w	pc, [sp], #4

20024a84 <HAL_HYPER_CFG_WRITE>:
20024a84:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20024a86:	b160      	cbz	r0, 20024aa2 <HAL_HYPER_CFG_WRITE+0x1e>
20024a88:	2107      	movs	r1, #7
20024a8a:	2303      	movs	r3, #3
20024a8c:	f890 202e 	ldrb.w	r2, [r0, #46]	@ 0x2e
20024a90:	e9cd 1300 	strd	r1, r3, [sp]
20024a94:	3a01      	subs	r2, #1
20024a96:	2300      	movs	r3, #0
20024a98:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024a9c:	b252      	sxtb	r2, r2
20024a9e:	f7fe f936 	bl	20022d0e <HAL_FLASH_CFG_AHB_WCMD>
20024aa2:	b005      	add	sp, #20
20024aa4:	f85d fb04 	ldr.w	pc, [sp], #4

20024aa8 <HAL_PIN_SetUartFunc.part.0>:
20024aa8:	108b      	asrs	r3, r1, #2
20024aaa:	f1a3 0248 	sub.w	r2, r3, #72	@ 0x48
20024aae:	b5f0      	push	{r4, r5, r6, r7, lr}
20024ab0:	b2d6      	uxtb	r6, r2
20024ab2:	2e04      	cmp	r6, #4
20024ab4:	d849      	bhi.n	20024b4a <HAL_PIN_SetUartFunc.part.0+0xa2>
20024ab6:	2e02      	cmp	r6, #2
20024ab8:	d810      	bhi.n	20024adc <HAL_PIN_SetUartFunc.part.0+0x34>
20024aba:	4d25      	ldr	r5, [pc, #148]	@ (20024b50 <HAL_PIN_SetUartFunc.part.0+0xa8>)
20024abc:	240e      	movs	r4, #14
20024abe:	eb05 0582 	add.w	r5, r5, r2, lsl #2
20024ac2:	f240 22b2 	movw	r2, #690	@ 0x2b2
20024ac6:	eba1 0386 	sub.w	r3, r1, r6, lsl #2
20024aca:	b29b      	uxth	r3, r3
20024acc:	f5a3 7390 	sub.w	r3, r3, #288	@ 0x120
20024ad0:	2b03      	cmp	r3, #3
20024ad2:	d83a      	bhi.n	20024b4a <HAL_PIN_SetUartFunc.part.0+0xa2>
20024ad4:	e8df f003 	tbb	[pc, r3]
20024ad8:	20271a09 	.word	0x20271a09
20024adc:	4d1d      	ldr	r5, [pc, #116]	@ (20024b54 <HAL_PIN_SetUartFunc.part.0+0xac>)
20024ade:	009b      	lsls	r3, r3, #2
20024ae0:	243d      	movs	r4, #61	@ 0x3d
20024ae2:	f240 3221 	movw	r2, #801	@ 0x321
20024ae6:	441d      	add	r5, r3
20024ae8:	e7ed      	b.n	20024ac6 <HAL_PIN_SetUartFunc.part.0+0x1e>
20024aea:	2c0e      	cmp	r4, #14
20024aec:	f04f 0608 	mov.w	r6, #8
20024af0:	d120      	bne.n	20024b34 <HAL_PIN_SetUartFunc.part.0+0x8c>
20024af2:	f44f 517c 	mov.w	r1, #16128	@ 0x3f00
20024af6:	682f      	ldr	r7, [r5, #0]
20024af8:	1b03      	subs	r3, r0, r4
20024afa:	40b3      	lsls	r3, r6
20024afc:	407b      	eors	r3, r7
20024afe:	400b      	ands	r3, r1
20024b00:	4410      	add	r0, r2
20024b02:	407b      	eors	r3, r7
20024b04:	1b00      	subs	r0, r0, r4
20024b06:	602b      	str	r3, [r5, #0]
20024b08:	b280      	uxth	r0, r0
20024b0a:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024b0c:	2c0e      	cmp	r4, #14
20024b0e:	f04f 0600 	mov.w	r6, #0
20024b12:	d112      	bne.n	20024b3a <HAL_PIN_SetUartFunc.part.0+0x92>
20024b14:	213f      	movs	r1, #63	@ 0x3f
20024b16:	e7ee      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b18:	2c0e      	cmp	r4, #14
20024b1a:	f04f 0610 	mov.w	r6, #16
20024b1e:	d10e      	bne.n	20024b3e <HAL_PIN_SetUartFunc.part.0+0x96>
20024b20:	f44f 117c 	mov.w	r1, #4128768	@ 0x3f0000
20024b24:	e7e7      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b26:	2c0e      	cmp	r4, #14
20024b28:	f04f 0618 	mov.w	r6, #24
20024b2c:	d10a      	bne.n	20024b44 <HAL_PIN_SetUartFunc.part.0+0x9c>
20024b2e:	f04f 517c 	mov.w	r1, #1056964608	@ 0x3f000000
20024b32:	e7e0      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b34:	f44f 61e0 	mov.w	r1, #1792	@ 0x700
20024b38:	e7dd      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b3a:	2107      	movs	r1, #7
20024b3c:	e7db      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b3e:	f44f 21e0 	mov.w	r1, #458752	@ 0x70000
20024b42:	e7d8      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b44:	f04f 61e0 	mov.w	r1, #117440512	@ 0x7000000
20024b48:	e7d5      	b.n	20024af6 <HAL_PIN_SetUartFunc.part.0+0x4e>
20024b4a:	2000      	movs	r0, #0
20024b4c:	e7dd      	b.n	20024b0a <HAL_PIN_SetUartFunc.part.0+0x62>
20024b4e:	bf00      	nop
20024b50:	5000b058 	.word	0x5000b058
20024b54:	4000ef0c 	.word	0x4000ef0c

20024b58 <HAL_PIN_SetAonPE>:
20024b58:	2a00      	cmp	r2, #0
20024b5a:	d031      	beq.n	20024bc0 <HAL_PIN_SetAonPE+0x68>
20024b5c:	282f      	cmp	r0, #47	@ 0x2f
20024b5e:	dd16      	ble.n	20024b8e <HAL_PIN_SetAonPE+0x36>
20024b60:	283a      	cmp	r0, #58	@ 0x3a
20024b62:	dc2d      	bgt.n	20024bc0 <HAL_PIN_SetAonPE+0x68>
20024b64:	2301      	movs	r3, #1
20024b66:	4a17      	ldr	r2, [pc, #92]	@ (20024bc4 <HAL_PIN_SetAonPE+0x6c>)
20024b68:	382a      	subs	r0, #42	@ 0x2a
20024b6a:	4083      	lsls	r3, r0
20024b6c:	6f10      	ldr	r0, [r2, #112]	@ 0x70
20024b6e:	f011 0f20 	tst.w	r1, #32
20024b72:	bf14      	ite	ne
20024b74:	4318      	orrne	r0, r3
20024b76:	4398      	biceq	r0, r3
20024b78:	6710      	str	r0, [r2, #112]	@ 0x70
20024b7a:	4a12      	ldr	r2, [pc, #72]	@ (20024bc4 <HAL_PIN_SetAonPE+0x6c>)
20024b7c:	f011 0f10 	tst.w	r1, #16
20024b80:	6ed1      	ldr	r1, [r2, #108]	@ 0x6c
20024b82:	bf14      	ite	ne
20024b84:	430b      	orrne	r3, r1
20024b86:	ea21 0303 	biceq.w	r3, r1, r3
20024b8a:	66d3      	str	r3, [r2, #108]	@ 0x6c
20024b8c:	4770      	bx	lr
20024b8e:	3826      	subs	r0, #38	@ 0x26
20024b90:	2803      	cmp	r0, #3
20024b92:	d815      	bhi.n	20024bc0 <HAL_PIN_SetAonPE+0x68>
20024b94:	4b0c      	ldr	r3, [pc, #48]	@ (20024bc8 <HAL_PIN_SetAonPE+0x70>)
20024b96:	f011 0f20 	tst.w	r1, #32
20024b9a:	f853 2020 	ldr.w	r2, [r3, r0, lsl #2]
20024b9e:	bf14      	ite	ne
20024ba0:	f042 0210 	orrne.w	r2, r2, #16
20024ba4:	f022 0210 	biceq.w	r2, r2, #16
20024ba8:	f843 2020 	str.w	r2, [r3, r0, lsl #2]
20024bac:	f853 2020 	ldr.w	r2, [r3, r0, lsl #2]
20024bb0:	06c9      	lsls	r1, r1, #27
20024bb2:	bf4c      	ite	mi
20024bb4:	f042 0208 	orrmi.w	r2, r2, #8
20024bb8:	f022 0208 	bicpl.w	r2, r2, #8
20024bbc:	f843 2020 	str.w	r2, [r3, r0, lsl #2]
20024bc0:	4770      	bx	lr
20024bc2:	bf00      	nop
20024bc4:	500cb000 	.word	0x500cb000
20024bc8:	500cb05c 	.word	0x500cb05c

20024bcc <HAL_PIN_Get_Base>:
20024bcc:	b138      	cbz	r0, 20024bde <HAL_PIN_Get_Base+0x12>
20024bce:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024bd2:	6893      	ldr	r3, [r2, #8]
20024bd4:	4806      	ldr	r0, [pc, #24]	@ (20024bf0 <HAL_PIN_Get_Base+0x24>)
20024bd6:	f043 0304 	orr.w	r3, r3, #4
20024bda:	6093      	str	r3, [r2, #8]
20024bdc:	4770      	bx	lr
20024bde:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
20024be2:	6853      	ldr	r3, [r2, #4]
20024be4:	4803      	ldr	r0, [pc, #12]	@ (20024bf4 <HAL_PIN_Get_Base+0x28>)
20024be6:	f043 0308 	orr.w	r3, r3, #8
20024bea:	6053      	str	r3, [r2, #4]
20024bec:	4770      	bx	lr
20024bee:	bf00      	nop
20024bf0:	50003000 	.word	0x50003000
20024bf4:	40003000 	.word	0x40003000

20024bf8 <HAL_PIN_Func2Idx>:
20024bf8:	283b      	cmp	r0, #59	@ 0x3b
20024bfa:	bfc8      	it	gt
20024bfc:	383c      	subgt	r0, #60	@ 0x3c
20024bfe:	0143      	lsls	r3, r0, #5
20024c00:	b162      	cbz	r2, 20024c1c <HAL_PIN_Func2Idx+0x24>
20024c02:	4a07      	ldr	r2, [pc, #28]	@ (20024c20 <HAL_PIN_Func2Idx+0x28>)
20024c04:	2000      	movs	r0, #0
20024c06:	4413      	add	r3, r2
20024c08:	f833 2010 	ldrh.w	r2, [r3, r0, lsl #1]
20024c0c:	428a      	cmp	r2, r1
20024c0e:	d004      	beq.n	20024c1a <HAL_PIN_Func2Idx+0x22>
20024c10:	3001      	adds	r0, #1
20024c12:	2810      	cmp	r0, #16
20024c14:	d1f8      	bne.n	20024c08 <HAL_PIN_Func2Idx+0x10>
20024c16:	f04f 30ff 	mov.w	r0, #4294967295
20024c1a:	4770      	bx	lr
20024c1c:	4a01      	ldr	r2, [pc, #4]	@ (20024c24 <HAL_PIN_Func2Idx+0x2c>)
20024c1e:	e7f1      	b.n	20024c04 <HAL_PIN_Func2Idx+0xc>
20024c20:	2002b2c4 	.word	0x2002b2c4
20024c24:	2002b224 	.word	0x2002b224

20024c28 <HAL_PIN_Set>:
20024c28:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20024c2c:	4615      	mov	r5, r2
20024c2e:	4604      	mov	r4, r0
20024c30:	b918      	cbnz	r0, 20024c3a <HAL_PIN_Set+0x12>
20024c32:	f04f 30ff 	mov.w	r0, #4294967295
20024c36:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20024c3a:	283a      	cmp	r0, #58	@ 0x3a
20024c3c:	bfcd      	iteet	gt
20024c3e:	2700      	movgt	r7, #0
20024c40:	2701      	movle	r7, #1
20024c42:	4606      	movle	r6, r0
20024c44:	f1a0 063c 	subgt.w	r6, r0, #60	@ 0x3c
20024c48:	4638      	mov	r0, r7
20024c4a:	f7ff ffbf 	bl	20024bcc <HAL_PIN_Get_Base>
20024c4e:	4680      	mov	r8, r0
20024c50:	2f00      	cmp	r7, #0
20024c52:	f000 8150 	beq.w	20024ef6 <HAL_PIN_Set+0x2ce>
20024c56:	f1a4 0026 	sub.w	r0, r4, #38	@ 0x26
20024c5a:	2803      	cmp	r0, #3
20024c5c:	d80a      	bhi.n	20024c74 <HAL_PIN_Set+0x4c>
20024c5e:	f8df c2c4 	ldr.w	ip, [pc, #708]	@ 20024f24 <HAL_PIN_Set+0x2fc>
20024c62:	f104 4380 	add.w	r3, r4, #1073741824	@ 0x40000000
20024c66:	3b26      	subs	r3, #38	@ 0x26
20024c68:	f85c 2023 	ldr.w	r2, [ip, r3, lsl #2]
20024c6c:	f022 0202 	bic.w	r2, r2, #2
20024c70:	f84c 2023 	str.w	r2, [ip, r3, lsl #2]
20024c74:	f5a1 7390 	sub.w	r3, r1, #288	@ 0x120
20024c78:	b29b      	uxth	r3, r3
20024c7a:	2b0b      	cmp	r3, #11
20024c7c:	d804      	bhi.n	20024c88 <HAL_PIN_Set+0x60>
20024c7e:	4620      	mov	r0, r4
20024c80:	f7ff ff12 	bl	20024aa8 <HAL_PIN_SetUartFunc.part.0>
20024c84:	4601      	mov	r1, r0
20024c86:	e025      	b.n	20024cd4 <HAL_PIN_Set+0xac>
20024c88:	f5a1 739c 	sub.w	r3, r1, #312	@ 0x138
20024c8c:	b29b      	uxth	r3, r3
20024c8e:	2b07      	cmp	r3, #7
20024c90:	d844      	bhi.n	20024d1c <HAL_PIN_Set+0xf4>
20024c92:	104a      	asrs	r2, r1, #1
20024c94:	3a9c      	subs	r2, #156	@ 0x9c
20024c96:	eba1 0142 	sub.w	r1, r1, r2, lsl #1
20024c9a:	b289      	uxth	r1, r1
20024c9c:	f5b1 7f9c 	cmp.w	r1, #312	@ 0x138
20024ca0:	d037      	beq.n	20024d12 <HAL_PIN_Set+0xea>
20024ca2:	f240 1339 	movw	r3, #313	@ 0x139
20024ca6:	4299      	cmp	r1, r3
20024ca8:	f040 812c 	bne.w	20024f04 <HAL_PIN_Set+0x2dc>
20024cac:	f04f 0e08 	mov.w	lr, #8
20024cb0:	f44f 5c7c 	mov.w	ip, #16128	@ 0x3f00
20024cb4:	4994      	ldr	r1, [pc, #592]	@ (20024f08 <HAL_PIN_Set+0x2e0>)
20024cb6:	f1a4 030e 	sub.w	r3, r4, #14
20024cba:	f851 0022 	ldr.w	r0, [r1, r2, lsl #2]
20024cbe:	fa03 f30e 	lsl.w	r3, r3, lr
20024cc2:	4043      	eors	r3, r0
20024cc4:	ea03 030c 	and.w	r3, r3, ip
20024cc8:	4043      	eors	r3, r0
20024cca:	f841 3022 	str.w	r3, [r1, r2, lsl #2]
20024cce:	f504 7129 	add.w	r1, r4, #676	@ 0x2a4
20024cd2:	b289      	uxth	r1, r1
20024cd4:	463a      	mov	r2, r7
20024cd6:	4620      	mov	r0, r4
20024cd8:	f7ff ff8e 	bl	20024bf8 <HAL_PIN_Func2Idx>
20024cdc:	f1b0 0900 	subs.w	r9, r0, #0
20024ce0:	dba7      	blt.n	20024c32 <HAL_PIN_Set+0xa>
20024ce2:	f106 4680 	add.w	r6, r6, #1073741824	@ 0x40000000
20024ce6:	4629      	mov	r1, r5
20024ce8:	4620      	mov	r0, r4
20024cea:	3e01      	subs	r6, #1
20024cec:	463a      	mov	r2, r7
20024cee:	f7ff ff33 	bl	20024b58 <HAL_PIN_SetAonPE>
20024cf2:	f858 3026 	ldr.w	r3, [r8, r6, lsl #2]
20024cf6:	f009 000f 	and.w	r0, r9, #15
20024cfa:	f005 0530 	and.w	r5, r5, #48	@ 0x30
20024cfe:	4305      	orrs	r5, r0
20024d00:	f023 033f 	bic.w	r3, r3, #63	@ 0x3f
20024d04:	431d      	orrs	r5, r3
20024d06:	f045 0540 	orr.w	r5, r5, #64	@ 0x40
20024d0a:	2000      	movs	r0, #0
20024d0c:	f848 5026 	str.w	r5, [r8, r6, lsl #2]
20024d10:	e791      	b.n	20024c36 <HAL_PIN_Set+0xe>
20024d12:	f04f 0e00 	mov.w	lr, #0
20024d16:	f04f 0c3f 	mov.w	ip, #63	@ 0x3f
20024d1a:	e7cb      	b.n	20024cb4 <HAL_PIN_Set+0x8c>
20024d1c:	f5a1 73ec 	sub.w	r3, r1, #472	@ 0x1d8
20024d20:	b29a      	uxth	r2, r3
20024d22:	2a09      	cmp	r2, #9
20024d24:	d837      	bhi.n	20024d96 <HAL_PIN_Set+0x16e>
20024d26:	2205      	movs	r2, #5
20024d28:	fbb3 f3f2 	udiv	r3, r3, r2
20024d2c:	ebc3 3283 	rsb	r2, r3, r3, lsl #14
20024d30:	ebc3 0282 	rsb	r2, r3, r2, lsl #2
20024d34:	440a      	add	r2, r1
20024d36:	b292      	uxth	r2, r2
20024d38:	f5a2 71ec 	sub.w	r1, r2, #472	@ 0x1d8
20024d3c:	b288      	uxth	r0, r1
20024d3e:	2803      	cmp	r0, #3
20024d40:	d814      	bhi.n	20024d6c <HAL_PIN_Set+0x144>
20024d42:	f04f 0e3f 	mov.w	lr, #63	@ 0x3f
20024d46:	4871      	ldr	r0, [pc, #452]	@ (20024f0c <HAL_PIN_Set+0x2e4>)
20024d48:	00c9      	lsls	r1, r1, #3
20024d4a:	f850 c023 	ldr.w	ip, [r0, r3, lsl #2]
20024d4e:	f1a4 020e 	sub.w	r2, r4, #14
20024d52:	408a      	lsls	r2, r1
20024d54:	ea82 020c 	eor.w	r2, r2, ip
20024d58:	fa0e f101 	lsl.w	r1, lr, r1
20024d5c:	400a      	ands	r2, r1
20024d5e:	ea82 020c 	eor.w	r2, r2, ip
20024d62:	f840 2023 	str.w	r2, [r0, r3, lsl #2]
20024d66:	f204 2155 	addw	r1, r4, #597	@ 0x255
20024d6a:	e7b2      	b.n	20024cd2 <HAL_PIN_Set+0xaa>
20024d6c:	f5b2 7fee 	cmp.w	r2, #476	@ 0x1dc
20024d70:	f040 80c8 	bne.w	20024f04 <HAL_PIN_Set+0x2dc>
20024d74:	213f      	movs	r1, #63	@ 0x3f
20024d76:	4866      	ldr	r0, [pc, #408]	@ (20024f10 <HAL_PIN_Set+0x2e8>)
20024d78:	00da      	lsls	r2, r3, #3
20024d7a:	f8d0 c06c 	ldr.w	ip, [r0, #108]	@ 0x6c
20024d7e:	f1a4 030e 	sub.w	r3, r4, #14
20024d82:	4093      	lsls	r3, r2
20024d84:	ea83 030c 	eor.w	r3, r3, ip
20024d88:	fa01 f202 	lsl.w	r2, r1, r2
20024d8c:	4013      	ands	r3, r2
20024d8e:	ea83 030c 	eor.w	r3, r3, ip
20024d92:	66c3      	str	r3, [r0, #108]	@ 0x6c
20024d94:	e7e7      	b.n	20024d66 <HAL_PIN_Set+0x13e>
20024d96:	f46f 7c01 	mvn.w	ip, #516	@ 0x204
20024d9a:	eb01 020c 	add.w	r2, r1, ip
20024d9e:	b293      	uxth	r3, r2
20024da0:	2b05      	cmp	r3, #5
20024da2:	d828      	bhi.n	20024df6 <HAL_PIN_Set+0x1ce>
20024da4:	2303      	movs	r3, #3
20024da6:	fbb2 f2f3 	udiv	r2, r2, r3
20024daa:	ebc2 3382 	rsb	r3, r2, r2, lsl #14
20024dae:	eb02 0383 	add.w	r3, r2, r3, lsl #2
20024db2:	440b      	add	r3, r1
20024db4:	f46f 7101 	mvn.w	r1, #516	@ 0x204
20024db8:	b29b      	uxth	r3, r3
20024dba:	eb03 0c01 	add.w	ip, r3, r1
20024dbe:	fa1f fc8c 	uxth.w	ip, ip
20024dc2:	f1bc 0f02 	cmp.w	ip, #2
20024dc6:	f200 809d 	bhi.w	20024f04 <HAL_PIN_Set+0x2dc>
20024dca:	00db      	lsls	r3, r3, #3
20024dcc:	f5a3 5381 	sub.w	r3, r3, #4128	@ 0x1020
20024dd0:	4950      	ldr	r1, [pc, #320]	@ (20024f14 <HAL_PIN_Set+0x2ec>)
20024dd2:	f1a4 0e0e 	sub.w	lr, r4, #14
20024dd6:	3b08      	subs	r3, #8
20024dd8:	fa0e f303 	lsl.w	r3, lr, r3
20024ddc:	f8df e148 	ldr.w	lr, [pc, #328]	@ 20024f28 <HAL_PIN_Set+0x300>
20024de0:	f851 0022 	ldr.w	r0, [r1, r2, lsl #2]
20024de4:	f85e c02c 	ldr.w	ip, [lr, ip, lsl #2]
20024de8:	4043      	eors	r3, r0
20024dea:	ea03 030c 	and.w	r3, r3, ip
20024dee:	4043      	eors	r3, r0
20024df0:	f841 3022 	str.w	r3, [r1, r2, lsl #2]
20024df4:	e7b7      	b.n	20024d66 <HAL_PIN_Set+0x13e>
20024df6:	f46f 72f8 	mvn.w	r2, #496	@ 0x1f0
20024dfa:	188b      	adds	r3, r1, r2
20024dfc:	b29a      	uxth	r2, r3
20024dfe:	2a09      	cmp	r2, #9
20024e00:	d82a      	bhi.n	20024e58 <HAL_PIN_Set+0x230>
20024e02:	f5b1 7ffc 	cmp.w	r1, #504	@ 0x1f8
20024e06:	d216      	bcs.n	20024e36 <HAL_PIN_Set+0x20e>
20024e08:	0859      	lsrs	r1, r3, #1
20024e0a:	f013 0f01 	tst.w	r3, #1
20024e0e:	4b42      	ldr	r3, [pc, #264]	@ (20024f18 <HAL_PIN_Set+0x2f0>)
20024e10:	f04f 003f 	mov.w	r0, #63	@ 0x3f
20024e14:	4a41      	ldr	r2, [pc, #260]	@ (20024f1c <HAL_PIN_Set+0x2f4>)
20024e16:	bf18      	it	ne
20024e18:	461a      	movne	r2, r3
20024e1a:	00c9      	lsls	r1, r1, #3
20024e1c:	4088      	lsls	r0, r1
20024e1e:	f8d2 c000 	ldr.w	ip, [r2]
20024e22:	f1a4 030e 	sub.w	r3, r4, #14
20024e26:	408b      	lsls	r3, r1
20024e28:	ea83 030c 	eor.w	r3, r3, ip
20024e2c:	4003      	ands	r3, r0
20024e2e:	ea83 030c 	eor.w	r3, r3, ip
20024e32:	6013      	str	r3, [r2, #0]
20024e34:	e797      	b.n	20024d66 <HAL_PIN_Set+0x13e>
20024e36:	d007      	beq.n	20024e48 <HAL_PIN_Set+0x220>
20024e38:	f240 13f9 	movw	r3, #505	@ 0x1f9
20024e3c:	4299      	cmp	r1, r3
20024e3e:	d107      	bne.n	20024e50 <HAL_PIN_Set+0x228>
20024e40:	2100      	movs	r1, #0
20024e42:	203f      	movs	r0, #63	@ 0x3f
20024e44:	4a36      	ldr	r2, [pc, #216]	@ (20024f20 <HAL_PIN_Set+0x2f8>)
20024e46:	e7ea      	b.n	20024e1e <HAL_PIN_Set+0x1f6>
20024e48:	2110      	movs	r1, #16
20024e4a:	f44f 107c 	mov.w	r0, #4128768	@ 0x3f0000
20024e4e:	e7f9      	b.n	20024e44 <HAL_PIN_Set+0x21c>
20024e50:	2108      	movs	r1, #8
20024e52:	f44f 507c 	mov.w	r0, #16128	@ 0x3f00
20024e56:	e7f5      	b.n	20024e44 <HAL_PIN_Set+0x21c>
20024e58:	f46f 7358 	mvn.w	r3, #864	@ 0x360
20024e5c:	18cb      	adds	r3, r1, r3
20024e5e:	b29b      	uxth	r3, r3
20024e60:	2b05      	cmp	r3, #5
20024e62:	f63f af37 	bhi.w	20024cd4 <HAL_PIN_Set+0xac>
20024e66:	2803      	cmp	r0, #3
20024e68:	d84c      	bhi.n	20024f04 <HAL_PIN_Set+0x2dc>
20024e6a:	f104 4380 	add.w	r3, r4, #1073741824	@ 0x40000000
20024e6e:	f2a1 3262 	subw	r2, r1, #866	@ 0x362
20024e72:	f8df c0b0 	ldr.w	ip, [pc, #176]	@ 20024f24 <HAL_PIN_Set+0x2fc>
20024e76:	3b26      	subs	r3, #38	@ 0x26
20024e78:	2a04      	cmp	r2, #4
20024e7a:	d815      	bhi.n	20024ea8 <HAL_PIN_Set+0x280>
20024e7c:	e8df f002 	tbb	[pc, r2]
20024e80:	31032a38 	.word	0x31032a38
20024e84:	23          	.byte	0x23
20024e85:	00          	.byte	0x00
20024e86:	f44f 5240 	mov.w	r2, #12288	@ 0x3000
20024e8a:	f04f 4ae0 	mov.w	sl, #1879048192	@ 0x70000000
20024e8e:	f04f 5e00 	mov.w	lr, #536870912	@ 0x20000000
20024e92:	f8df 9098 	ldr.w	r9, [pc, #152]	@ 20024f2c <HAL_PIN_Set+0x304>
20024e96:	f8d9 0004 	ldr.w	r0, [r9, #4]
20024e9a:	ea20 000a 	bic.w	r0, r0, sl
20024e9e:	ea40 000e 	orr.w	r0, r0, lr
20024ea2:	f8c9 0004 	str.w	r0, [r9, #4]
20024ea6:	e000      	b.n	20024eaa <HAL_PIN_Set+0x282>
20024ea8:	2200      	movs	r2, #0
20024eaa:	f85c 0023 	ldr.w	r0, [ip, r3, lsl #2]
20024eae:	f420 40e0 	bic.w	r0, r0, #28672	@ 0x7000
20024eb2:	4302      	orrs	r2, r0
20024eb4:	f84c 2023 	str.w	r2, [ip, r3, lsl #2]
20024eb8:	f85c 2023 	ldr.w	r2, [ip, r3, lsl #2]
20024ebc:	f042 0202 	orr.w	r2, r2, #2
20024ec0:	f84c 2023 	str.w	r2, [ip, r3, lsl #2]
20024ec4:	e706      	b.n	20024cd4 <HAL_PIN_Set+0xac>
20024ec6:	f44f 5240 	mov.w	r2, #12288	@ 0x3000
20024eca:	f04f 4ae0 	mov.w	sl, #1879048192	@ 0x70000000
20024ece:	f04f 5e40 	mov.w	lr, #805306368	@ 0x30000000
20024ed2:	e7de      	b.n	20024e92 <HAL_PIN_Set+0x26a>
20024ed4:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20024ed8:	f04f 6a60 	mov.w	sl, #234881024	@ 0xe000000
20024edc:	f04f 6e80 	mov.w	lr, #67108864	@ 0x4000000
20024ee0:	e7d7      	b.n	20024e92 <HAL_PIN_Set+0x26a>
20024ee2:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20024ee6:	f04f 6a60 	mov.w	sl, #234881024	@ 0xe000000
20024eea:	f04f 6ec0 	mov.w	lr, #100663296	@ 0x6000000
20024eee:	e7d0      	b.n	20024e92 <HAL_PIN_Set+0x26a>
20024ef0:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20024ef4:	e7d9      	b.n	20024eaa <HAL_PIN_Set+0x282>
20024ef6:	f5a1 7396 	sub.w	r3, r1, #300	@ 0x12c
20024efa:	b29b      	uxth	r3, r3
20024efc:	2b07      	cmp	r3, #7
20024efe:	f63f aee9 	bhi.w	20024cd4 <HAL_PIN_Set+0xac>
20024f02:	e6bc      	b.n	20024c7e <HAL_PIN_Set+0x56>
20024f04:	2100      	movs	r1, #0
20024f06:	e6e5      	b.n	20024cd4 <HAL_PIN_Set+0xac>
20024f08:	5000b048 	.word	0x5000b048
20024f0c:	5000b064 	.word	0x5000b064
20024f10:	5000b000 	.word	0x5000b000
20024f14:	5000b070 	.word	0x5000b070
20024f18:	5000b07c 	.word	0x5000b07c
20024f1c:	5000b078 	.word	0x5000b078
20024f20:	5000b080 	.word	0x5000b080
20024f24:	500cb05c 	.word	0x500cb05c
20024f28:	2002ba38 	.word	0x2002ba38
20024f2c:	500c0000 	.word	0x500c0000

20024f30 <HAL_PIN_Set_Analog>:
20024f30:	283a      	cmp	r0, #58	@ 0x3a
20024f32:	b538      	push	{r3, r4, r5, lr}
20024f34:	bfcd      	iteet	gt
20024f36:	2500      	movgt	r5, #0
20024f38:	2501      	movle	r5, #1
20024f3a:	4601      	movle	r1, r0
20024f3c:	f1a0 013c 	subgt.w	r1, r0, #60	@ 0x3c
20024f40:	4604      	mov	r4, r0
20024f42:	4628      	mov	r0, r5
20024f44:	f7ff fe42 	bl	20024bcc <HAL_PIN_Get_Base>
20024f48:	f101 4380 	add.w	r3, r1, #1073741824	@ 0x40000000
20024f4c:	3b01      	subs	r3, #1
20024f4e:	f850 1023 	ldr.w	r1, [r0, r3, lsl #2]
20024f52:	462a      	mov	r2, r5
20024f54:	f021 015f 	bic.w	r1, r1, #95	@ 0x5f
20024f58:	f041 010f 	orr.w	r1, r1, #15
20024f5c:	f840 1023 	str.w	r1, [r0, r3, lsl #2]
20024f60:	4620      	mov	r0, r4
20024f62:	2100      	movs	r1, #0
20024f64:	f7ff fdf8 	bl	20024b58 <HAL_PIN_SetAonPE>
20024f68:	2000      	movs	r0, #0
20024f6a:	bd38      	pop	{r3, r4, r5, pc}

20024f6c <HAL_PMU_EnableDLL>:
20024f6c:	4b05      	ldr	r3, [pc, #20]	@ (20024f84 <HAL_PMU_EnableDLL+0x18>)
20024f6e:	6e9a      	ldr	r2, [r3, #104]	@ 0x68
20024f70:	b120      	cbz	r0, 20024f7c <HAL_PMU_EnableDLL+0x10>
20024f72:	f042 0220 	orr.w	r2, r2, #32
20024f76:	2000      	movs	r0, #0
20024f78:	669a      	str	r2, [r3, #104]	@ 0x68
20024f7a:	4770      	bx	lr
20024f7c:	f022 0220 	bic.w	r2, r2, #32
20024f80:	e7f9      	b.n	20024f76 <HAL_PMU_EnableDLL+0xa>
20024f82:	bf00      	nop
20024f84:	500ca000 	.word	0x500ca000

20024f88 <HAL_RCC_HCPU_ConfigSxModeVolt>:
20024f88:	b507      	push	{r0, r1, r2, lr}
20024f8a:	4a13      	ldr	r2, [pc, #76]	@ (20024fd8 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
20024f8c:	4913      	ldr	r1, [pc, #76]	@ (20024fdc <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20024f8e:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
20024f92:	f8d1 309c 	ldr.w	r3, [r1, #156]	@ 0x9c
20024f96:	7892      	ldrb	r2, [r2, #2]
20024f98:	2802      	cmp	r0, #2
20024f9a:	f362 0303 	bfi	r3, r2, #0, #4
20024f9e:	f8c1 309c 	str.w	r3, [r1, #156]	@ 0x9c
20024fa2:	f10d 0007 	add.w	r0, sp, #7
20024fa6:	d111      	bne.n	20024fcc <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
20024fa8:	f007 faec 	bl	2002c584 <HAL_PMU_GetHpsysVoutRef>
20024fac:	b110      	cbz	r0, 20024fb4 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20024fae:	230b      	movs	r3, #11
20024fb0:	f88d 3007 	strb.w	r3, [sp, #7]
20024fb4:	4a09      	ldr	r2, [pc, #36]	@ (20024fdc <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20024fb6:	f89d 1007 	ldrb.w	r1, [sp, #7]
20024fba:	f8d2 3094 	ldr.w	r3, [r2, #148]	@ 0x94
20024fbe:	f361 0303 	bfi	r3, r1, #0, #4
20024fc2:	f8c2 3094 	str.w	r3, [r2, #148]	@ 0x94
20024fc6:	b003      	add	sp, #12
20024fc8:	f85d fb04 	ldr.w	pc, [sp], #4
20024fcc:	f007 fae6 	bl	2002c59c <HAL_PMU_GetHpsysVoutRef2>
20024fd0:	2800      	cmp	r0, #0
20024fd2:	d0ef      	beq.n	20024fb4 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20024fd4:	230d      	movs	r3, #13
20024fd6:	e7eb      	b.n	20024fb0 <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
20024fd8:	2002ba54 	.word	0x2002ba54
20024fdc:	500ca000 	.word	0x500ca000

20024fe0 <HAL_RCC_HCPU_GetClockSrc>:
20024fe0:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024fe4:	280d      	cmp	r0, #13
20024fe6:	6a1a      	ldr	r2, [r3, #32]
20024fe8:	d80d      	bhi.n	20025006 <HAL_RCC_HCPU_GetClockSrc+0x26>
20024fea:	f642 73f1 	movw	r3, #12273	@ 0x2ff1
20024fee:	40c3      	lsrs	r3, r0
20024ff0:	f013 0f01 	tst.w	r3, #1
20024ff4:	bf0c      	ite	eq
20024ff6:	2301      	moveq	r3, #1
20024ff8:	2303      	movne	r3, #3
20024ffa:	4083      	lsls	r3, r0
20024ffc:	4013      	ands	r3, r2
20024ffe:	fa23 f000 	lsr.w	r0, r3, r0
20025002:	b2c0      	uxtb	r0, r0
20025004:	4770      	bx	lr
20025006:	2301      	movs	r3, #1
20025008:	e7f7      	b.n	20024ffa <HAL_RCC_HCPU_GetClockSrc+0x1a>
	...

2002500c <HAL_RCC_HCPU_GetDLLFreq>:
2002500c:	2801      	cmp	r0, #1
2002500e:	d003      	beq.n	20025018 <HAL_RCC_HCPU_GetDLLFreq+0xc>
20025010:	2802      	cmp	r0, #2
20025012:	d00e      	beq.n	20025032 <HAL_RCC_HCPU_GetDLLFreq+0x26>
20025014:	2000      	movs	r0, #0
20025016:	4770      	bx	lr
20025018:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002501c:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
2002501e:	b163      	cbz	r3, 2002503a <HAL_RCC_HCPU_GetDLLFreq+0x2e>
20025020:	f013 0001 	ands.w	r0, r3, #1
20025024:	d00a      	beq.n	2002503c <HAL_RCC_HCPU_GetDLLFreq+0x30>
20025026:	4806      	ldr	r0, [pc, #24]	@ (20025040 <HAL_RCC_HCPU_GetDLLFreq+0x34>)
20025028:	f3c3 0383 	ubfx	r3, r3, #2, #4
2002502c:	fb03 0000 	mla	r0, r3, r0, r0
20025030:	4770      	bx	lr
20025032:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20025036:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
20025038:	e7f1      	b.n	2002501e <HAL_RCC_HCPU_GetDLLFreq+0x12>
2002503a:	4618      	mov	r0, r3
2002503c:	4770      	bx	lr
2002503e:	bf00      	nop
20025040:	016e3600 	.word	0x016e3600

20025044 <HAL_RCC_HCPU_GetDLL1Freq>:
20025044:	2001      	movs	r0, #1
20025046:	f7ff bfe1 	b.w	2002500c <HAL_RCC_HCPU_GetDLLFreq>
	...

2002504c <HAL_RCC_GetSysCLKFreq.part.0>:
2002504c:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20025050:	6a1b      	ldr	r3, [r3, #32]
20025052:	f003 0303 	and.w	r3, r3, #3
20025056:	2b03      	cmp	r3, #3
20025058:	d101      	bne.n	2002505e <HAL_RCC_GetSysCLKFreq.part.0+0x12>
2002505a:	f7ff bff3 	b.w	20025044 <HAL_RCC_HCPU_GetDLL1Freq>
2002505e:	4801      	ldr	r0, [pc, #4]	@ (20025064 <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
20025060:	4770      	bx	lr
20025062:	bf00      	nop
20025064:	02dc6c00 	.word	0x02dc6c00

20025068 <HAL_RCC_HCPU_GetDLL2Freq>:
20025068:	2002      	movs	r0, #2
2002506a:	f7ff bfcf 	b.w	2002500c <HAL_RCC_HCPU_GetDLLFreq>

2002506e <HAL_RCC_HCPU_GetDLL3Freq>:
2002506e:	2000      	movs	r0, #0
20025070:	4770      	bx	lr
	...

20025074 <HAL_RCC_HCPU_EnableDLL>:
20025074:	4b23      	ldr	r3, [pc, #140]	@ (20025104 <HAL_RCC_HCPU_EnableDLL+0x90>)
20025076:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
2002507a:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
2002507e:	4299      	cmp	r1, r3
20025080:	b510      	push	{r4, lr}
20025082:	d83c      	bhi.n	200250fe <HAL_RCC_HCPU_EnableDLL+0x8a>
20025084:	2801      	cmp	r0, #1
20025086:	d002      	beq.n	2002508e <HAL_RCC_HCPU_EnableDLL+0x1a>
20025088:	2802      	cmp	r0, #2
2002508a:	d036      	beq.n	200250fa <HAL_RCC_HCPU_EnableDLL+0x86>
2002508c:	e7fe      	b.n	2002508c <HAL_RCC_HCPU_EnableDLL+0x18>
2002508e:	4c1e      	ldr	r4, [pc, #120]	@ (20025108 <HAL_RCC_HCPU_EnableDLL+0x94>)
20025090:	4b1e      	ldr	r3, [pc, #120]	@ (2002510c <HAL_RCC_HCPU_EnableDLL+0x98>)
20025092:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
20025096:	0790      	lsls	r0, r2, #30
20025098:	bf58      	it	pl
2002509a:	f8d3 2094 	ldrpl.w	r2, [r3, #148]	@ 0x94
2002509e:	f04f 0000 	mov.w	r0, #0
200250a2:	bf5c      	itt	pl
200250a4:	f042 0202 	orrpl.w	r2, r2, #2
200250a8:	f8c3 2094 	strpl.w	r2, [r3, #148]	@ 0x94
200250ac:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
200250b0:	07d2      	lsls	r2, r2, #31
200250b2:	bf5e      	ittt	pl
200250b4:	f8d3 2094 	ldrpl.w	r2, [r3, #148]	@ 0x94
200250b8:	f042 0201 	orrpl.w	r2, r2, #1
200250bc:	f8c3 2094 	strpl.w	r2, [r3, #148]	@ 0x94
200250c0:	4a13      	ldr	r2, [pc, #76]	@ (20025110 <HAL_RCC_HCPU_EnableDLL+0x9c>)
200250c2:	6823      	ldr	r3, [r4, #0]
200250c4:	fbb1 f1f2 	udiv	r1, r1, r2
200250c8:	f023 0301 	bic.w	r3, r3, #1
200250cc:	6023      	str	r3, [r4, #0]
200250ce:	6823      	ldr	r3, [r4, #0]
200250d0:	f423 5300 	bic.w	r3, r3, #8192	@ 0x2000
200250d4:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
200250d8:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
200250dc:	f443 5380 	orr.w	r3, r3, #4096	@ 0x1000
200250e0:	f043 0301 	orr.w	r3, r3, #1
200250e4:	6023      	str	r3, [r4, #0]
200250e6:	f7fd f838 	bl	2002215a <HAL_Delay_us>
200250ea:	200a      	movs	r0, #10
200250ec:	f7fd f835 	bl	2002215a <HAL_Delay_us>
200250f0:	6823      	ldr	r3, [r4, #0]
200250f2:	2b00      	cmp	r3, #0
200250f4:	dafc      	bge.n	200250f0 <HAL_RCC_HCPU_EnableDLL+0x7c>
200250f6:	2000      	movs	r0, #0
200250f8:	bd10      	pop	{r4, pc}
200250fa:	4c06      	ldr	r4, [pc, #24]	@ (20025114 <HAL_RCC_HCPU_EnableDLL+0xa0>)
200250fc:	e7c8      	b.n	20025090 <HAL_RCC_HCPU_EnableDLL+0x1c>
200250fe:	2001      	movs	r0, #1
20025100:	e7fa      	b.n	200250f8 <HAL_RCC_HCPU_EnableDLL+0x84>
20025102:	bf00      	nop
20025104:	15752a00 	.word	0x15752a00
20025108:	5000002c 	.word	0x5000002c
2002510c:	5000b000 	.word	0x5000b000
20025110:	016e3600 	.word	0x016e3600
20025114:	50000030 	.word	0x50000030

20025118 <HAL_RCC_HCPU_EnableDLL1>:
20025118:	4601      	mov	r1, r0
2002511a:	2001      	movs	r0, #1
2002511c:	f7ff bfaa 	b.w	20025074 <HAL_RCC_HCPU_EnableDLL>

20025120 <HAL_RCC_HCPU_EnableDLL2>:
20025120:	4601      	mov	r1, r0
20025122:	2002      	movs	r0, #2
20025124:	f7ff bfa6 	b.w	20025074 <HAL_RCC_HCPU_EnableDLL>

20025128 <HAL_RCC_HCPU_DisableDLL1>:
20025128:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
2002512c:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
2002512e:	2000      	movs	r0, #0
20025130:	f023 0301 	bic.w	r3, r3, #1
20025134:	62d3      	str	r3, [r2, #44]	@ 0x2c
20025136:	4770      	bx	lr

20025138 <HAL_RCC_GetSysCLKFreq>:
20025138:	2801      	cmp	r0, #1
2002513a:	d101      	bne.n	20025140 <HAL_RCC_GetSysCLKFreq+0x8>
2002513c:	f7ff bf86 	b.w	2002504c <HAL_RCC_GetSysCLKFreq.part.0>
20025140:	4800      	ldr	r0, [pc, #0]	@ (20025144 <HAL_RCC_GetSysCLKFreq+0xc>)
20025142:	4770      	bx	lr
20025144:	02dc6c00 	.word	0x02dc6c00

20025148 <HAL_RCC_GetHCLKFreq>:
20025148:	1e02      	subs	r2, r0, #0
2002514a:	bf08      	it	eq
2002514c:	2201      	moveq	r2, #1
2002514e:	b508      	push	{r3, lr}
20025150:	4610      	mov	r0, r2
20025152:	f7ff fff1 	bl	20025138 <HAL_RCC_GetSysCLKFreq>
20025156:	2a01      	cmp	r2, #1
20025158:	d002      	beq.n	20025160 <HAL_RCC_GetHCLKFreq+0x18>
2002515a:	2a02      	cmp	r2, #2
2002515c:	d00a      	beq.n	20025174 <HAL_RCC_GetHCLKFreq+0x2c>
2002515e:	e7fe      	b.n	2002515e <HAL_RCC_GetHCLKFreq+0x16>
20025160:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20025164:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
20025166:	b2db      	uxtb	r3, r3
20025168:	2b01      	cmp	r3, #1
2002516a:	bfb8      	it	lt
2002516c:	2301      	movlt	r3, #1
2002516e:	fbb0 f0f3 	udiv	r0, r0, r3
20025172:	bd08      	pop	{r3, pc}
20025174:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
20025178:	695b      	ldr	r3, [r3, #20]
2002517a:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
2002517e:	e7f3      	b.n	20025168 <HAL_RCC_GetHCLKFreq+0x20>

20025180 <HAL_RCC_HCPU_ClockSelect>:
20025180:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20025184:	b510      	push	{r4, lr}
20025186:	280d      	cmp	r0, #13
20025188:	6a1b      	ldr	r3, [r3, #32]
2002518a:	d818      	bhi.n	200251be <HAL_RCC_HCPU_ClockSelect+0x3e>
2002518c:	f642 72f1 	movw	r2, #12273	@ 0x2ff1
20025190:	40c2      	lsrs	r2, r0
20025192:	f012 0f01 	tst.w	r2, #1
20025196:	bf0c      	ite	eq
20025198:	2201      	moveq	r2, #1
2002519a:	2203      	movne	r2, #3
2002519c:	fa02 f400 	lsl.w	r4, r2, r0
200251a0:	4011      	ands	r1, r2
200251a2:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
200251a6:	ea23 0304 	bic.w	r3, r3, r4
200251aa:	4081      	lsls	r1, r0
200251ac:	430b      	orrs	r3, r1
200251ae:	6213      	str	r3, [r2, #32]
200251b0:	b920      	cbnz	r0, 200251bc <HAL_RCC_HCPU_ClockSelect+0x3c>
200251b2:	2001      	movs	r0, #1
200251b4:	f7ff ffc8 	bl	20025148 <HAL_RCC_GetHCLKFreq>
200251b8:	4b02      	ldr	r3, [pc, #8]	@ (200251c4 <HAL_RCC_HCPU_ClockSelect+0x44>)
200251ba:	6018      	str	r0, [r3, #0]
200251bc:	bd10      	pop	{r4, pc}
200251be:	2201      	movs	r2, #1
200251c0:	e7ec      	b.n	2002519c <HAL_RCC_HCPU_ClockSelect+0x1c>
200251c2:	bf00      	nop
200251c4:	20042c10 	.word	0x20042c10

200251c8 <HAL_RCC_HCPU_SetDiv>:
200251c8:	2800      	cmp	r0, #0
200251ca:	bfd8      	it	le
200251cc:	2000      	movle	r0, #0
200251ce:	b508      	push	{r3, lr}
200251d0:	bfcc      	ite	gt
200251d2:	23ff      	movgt	r3, #255	@ 0xff
200251d4:	4603      	movle	r3, r0
200251d6:	2900      	cmp	r1, #0
200251d8:	db12      	blt.n	20025200 <HAL_RCC_HCPU_SetDiv+0x38>
200251da:	2a00      	cmp	r2, #0
200251dc:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
200251e0:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
200251e4:	da0e      	bge.n	20025204 <HAL_RCC_HCPU_SetDiv+0x3c>
200251e6:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
200251ea:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
200251ec:	ea22 0303 	bic.w	r3, r2, r3
200251f0:	4303      	orrs	r3, r0
200251f2:	624b      	str	r3, [r1, #36]	@ 0x24
200251f4:	2001      	movs	r0, #1
200251f6:	f7ff ffa7 	bl	20025148 <HAL_RCC_GetHCLKFreq>
200251fa:	4b07      	ldr	r3, [pc, #28]	@ (20025218 <HAL_RCC_HCPU_SetDiv+0x50>)
200251fc:	6018      	str	r0, [r3, #0]
200251fe:	bd08      	pop	{r3, pc}
20025200:	2a00      	cmp	r2, #0
20025202:	db04      	blt.n	2002520e <HAL_RCC_HCPU_SetDiv+0x46>
20025204:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
20025208:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
2002520c:	e7eb      	b.n	200251e6 <HAL_RCC_HCPU_SetDiv+0x1e>
2002520e:	2b00      	cmp	r3, #0
20025210:	d0f0      	beq.n	200251f4 <HAL_RCC_HCPU_SetDiv+0x2c>
20025212:	23ff      	movs	r3, #255	@ 0xff
20025214:	e7e7      	b.n	200251e6 <HAL_RCC_HCPU_SetDiv+0x1e>
20025216:	bf00      	nop
20025218:	20042c10 	.word	0x20042c10

2002521c <HAL_RCC_HCPU_SwitchDvfsD2S>:
2002521c:	b570      	push	{r4, r5, r6, lr}
2002521e:	460c      	mov	r4, r1
20025220:	4d19      	ldr	r5, [pc, #100]	@ (20025288 <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
20025222:	4606      	mov	r6, r0
20025224:	f7ff feb0 	bl	20024f88 <HAL_RCC_HCPU_ConfigSxModeVolt>
20025228:	692b      	ldr	r3, [r5, #16]
2002522a:	20fa      	movs	r0, #250	@ 0xfa
2002522c:	f023 0304 	bic.w	r3, r3, #4
20025230:	612b      	str	r3, [r5, #16]
20025232:	f7fc ff92 	bl	2002215a <HAL_Delay_us>
20025236:	2c30      	cmp	r4, #48	@ 0x30
20025238:	d80d      	bhi.n	20025256 <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
2002523a:	2100      	movs	r1, #0
2002523c:	4608      	mov	r0, r1
2002523e:	f7ff ff9f 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20025242:	2030      	movs	r0, #48	@ 0x30
20025244:	2204      	movs	r2, #4
20025246:	2100      	movs	r1, #0
20025248:	fbb0 f0f4 	udiv	r0, r0, r4
2002524c:	f7ff ffbc 	bl	200251c8 <HAL_RCC_HCPU_SetDiv>
20025250:	2400      	movs	r4, #0
20025252:	4620      	mov	r0, r4
20025254:	bd70      	pop	{r4, r5, r6, pc}
20025256:	f7fd fcf1 	bl	20022c3c <HAL_HPAON_EnableXT48>
2002525a:	480c      	ldr	r0, [pc, #48]	@ (2002528c <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
2002525c:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
20025260:	6843      	ldr	r3, [r0, #4]
20025262:	480b      	ldr	r0, [pc, #44]	@ (20025290 <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
20025264:	61eb      	str	r3, [r5, #28]
20025266:	4360      	muls	r0, r4
20025268:	f7ff ff56 	bl	20025118 <HAL_RCC_HCPU_EnableDLL1>
2002526c:	4604      	mov	r4, r0
2002526e:	2800      	cmp	r0, #0
20025270:	d1ef      	bne.n	20025252 <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
20025272:	2101      	movs	r1, #1
20025274:	2206      	movs	r2, #6
20025276:	4608      	mov	r0, r1
20025278:	f7ff ffa6 	bl	200251c8 <HAL_RCC_HCPU_SetDiv>
2002527c:	2103      	movs	r1, #3
2002527e:	4620      	mov	r0, r4
20025280:	f7ff ff7e 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
20025284:	e7e4      	b.n	20025250 <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
20025286:	bf00      	nop
20025288:	5000b000 	.word	0x5000b000
2002528c:	2002ba54 	.word	0x2002ba54
20025290:	000f4240 	.word	0x000f4240

20025294 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
20025294:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20025298:	4c1d      	ldr	r4, [pc, #116]	@ (20025310 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
2002529a:	4f1e      	ldr	r7, [pc, #120]	@ (20025314 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
2002529c:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
200252a0:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
200252a2:	7892      	ldrb	r2, [r2, #2]
200252a4:	4605      	mov	r5, r0
200252a6:	f362 5317 	bfi	r3, r2, #20, #4
200252aa:	ea4f 08c0 	mov.w	r8, r0, lsl #3
200252ae:	633b      	str	r3, [r7, #48]	@ 0x30
200252b0:	f10d 0007 	add.w	r0, sp, #7
200252b4:	460e      	mov	r6, r1
200252b6:	f007 f965 	bl	2002c584 <HAL_PMU_GetHpsysVoutRef>
200252ba:	b110      	cbz	r0, 200252c2 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
200252bc:	230b      	movs	r3, #11
200252be:	f88d 3007 	strb.w	r3, [sp, #7]
200252c2:	f89d 1007 	ldrb.w	r1, [sp, #7]
200252c6:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
200252ca:	6cfb      	ldr	r3, [r7, #76]	@ 0x4c
200252cc:	440a      	add	r2, r1
200252ce:	2100      	movs	r1, #0
200252d0:	f362 0385 	bfi	r3, r2, #2, #4
200252d4:	4608      	mov	r0, r1
200252d6:	64fb      	str	r3, [r7, #76]	@ 0x4c
200252d8:	f7ff ff52 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
200252dc:	2e30      	cmp	r6, #48	@ 0x30
200252de:	d900      	bls.n	200252e2 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
200252e0:	e7fe      	b.n	200252e0 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
200252e2:	2030      	movs	r0, #48	@ 0x30
200252e4:	2204      	movs	r2, #4
200252e6:	2100      	movs	r1, #0
200252e8:	fbb0 f0f6 	udiv	r0, r0, r6
200252ec:	f7ff ff6c 	bl	200251c8 <HAL_RCC_HCPU_SetDiv>
200252f0:	f7ff ff1a 	bl	20025128 <HAL_RCC_HCPU_DisableDLL1>
200252f4:	f7fd fcae 	bl	20022c54 <HAL_HPAON_DisableXT48>
200252f8:	4444      	add	r4, r8
200252fa:	4b07      	ldr	r3, [pc, #28]	@ (20025318 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
200252fc:	6862      	ldr	r2, [r4, #4]
200252fe:	61da      	str	r2, [r3, #28]
20025300:	691a      	ldr	r2, [r3, #16]
20025302:	f042 0204 	orr.w	r2, r2, #4
20025306:	611a      	str	r2, [r3, #16]
20025308:	b002      	add	sp, #8
2002530a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002530e:	bf00      	nop
20025310:	2002ba54 	.word	0x2002ba54
20025314:	500ca000 	.word	0x500ca000
20025318:	5000b000 	.word	0x5000b000

2002531c <HAL_RCC_HCPU_ConfigDvfs>:
2002531c:	b570      	push	{r4, r5, r6, lr}
2002531e:	4e31      	ldr	r6, [pc, #196]	@ (200253e4 <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
20025320:	4605      	mov	r5, r0
20025322:	7833      	ldrb	r3, [r6, #0]
20025324:	460c      	mov	r4, r1
20025326:	2b01      	cmp	r3, #1
20025328:	d943      	bls.n	200253b2 <HAL_RCC_HCPU_ConfigDvfs+0x96>
2002532a:	3b02      	subs	r3, #2
2002532c:	2b01      	cmp	r3, #1
2002532e:	d902      	bls.n	20025336 <HAL_RCC_HCPU_ConfigDvfs+0x1a>
20025330:	2501      	movs	r5, #1
20025332:	4628      	mov	r0, r5
20025334:	bd70      	pop	{r4, r5, r6, pc}
20025336:	4b2c      	ldr	r3, [pc, #176]	@ (200253e8 <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
20025338:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
2002533c:	f7ff fe94 	bl	20025068 <HAL_RCC_HCPU_GetDLL2Freq>
20025340:	4290      	cmp	r0, r2
20025342:	d8f5      	bhi.n	20025330 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20025344:	2901      	cmp	r1, #1
20025346:	d805      	bhi.n	20025354 <HAL_RCC_HCPU_ConfigDvfs+0x38>
20025348:	4629      	mov	r1, r5
2002534a:	4620      	mov	r0, r4
2002534c:	f7ff ffa2 	bl	20025294 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
20025350:	2500      	movs	r5, #0
20025352:	e035      	b.n	200253c0 <HAL_RCC_HCPU_ConfigDvfs+0xa4>
20025354:	2100      	movs	r1, #0
20025356:	4608      	mov	r0, r1
20025358:	f7ff ff12 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
2002535c:	4620      	mov	r0, r4
2002535e:	f7ff fe13 	bl	20024f88 <HAL_RCC_HCPU_ConfigSxModeVolt>
20025362:	20fa      	movs	r0, #250	@ 0xfa
20025364:	f7fc fef9 	bl	2002215a <HAL_Delay_us>
20025368:	f7ff fede 	bl	20025128 <HAL_RCC_HCPU_DisableDLL1>
2002536c:	2d30      	cmp	r5, #48	@ 0x30
2002536e:	d80d      	bhi.n	2002538c <HAL_RCC_HCPU_ConfigDvfs+0x70>
20025370:	f7fd fc70 	bl	20022c54 <HAL_HPAON_DisableXT48>
20025374:	2100      	movs	r1, #0
20025376:	4608      	mov	r0, r1
20025378:	f7ff ff02 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
2002537c:	2204      	movs	r2, #4
2002537e:	2100      	movs	r1, #0
20025380:	2030      	movs	r0, #48	@ 0x30
20025382:	fbb0 f0f5 	udiv	r0, r0, r5
20025386:	f7ff ff1f 	bl	200251c8 <HAL_RCC_HCPU_SetDiv>
2002538a:	e7e1      	b.n	20025350 <HAL_RCC_HCPU_ConfigDvfs+0x34>
2002538c:	f7fd fc56 	bl	20022c3c <HAL_HPAON_EnableXT48>
20025390:	4816      	ldr	r0, [pc, #88]	@ (200253ec <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
20025392:	4368      	muls	r0, r5
20025394:	f7ff fec0 	bl	20025118 <HAL_RCC_HCPU_EnableDLL1>
20025398:	4605      	mov	r5, r0
2002539a:	2800      	cmp	r0, #0
2002539c:	d1c8      	bne.n	20025330 <HAL_RCC_HCPU_ConfigDvfs+0x14>
2002539e:	2101      	movs	r1, #1
200253a0:	2206      	movs	r2, #6
200253a2:	4608      	mov	r0, r1
200253a4:	f7ff ff10 	bl	200251c8 <HAL_RCC_HCPU_SetDiv>
200253a8:	2103      	movs	r1, #3
200253aa:	4628      	mov	r0, r5
200253ac:	f7ff fee8 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
200253b0:	e7ce      	b.n	20025350 <HAL_RCC_HCPU_ConfigDvfs+0x34>
200253b2:	2901      	cmp	r1, #1
200253b4:	d909      	bls.n	200253ca <HAL_RCC_HCPU_ConfigDvfs+0xae>
200253b6:	4601      	mov	r1, r0
200253b8:	4620      	mov	r0, r4
200253ba:	f7ff ff2f 	bl	2002521c <HAL_RCC_HCPU_SwitchDvfsD2S>
200253be:	4605      	mov	r5, r0
200253c0:	2000      	movs	r0, #0
200253c2:	7034      	strb	r4, [r6, #0]
200253c4:	f7fc fec9 	bl	2002215a <HAL_Delay_us>
200253c8:	e7b3      	b.n	20025332 <HAL_RCC_HCPU_ConfigDvfs+0x16>
200253ca:	428b      	cmp	r3, r1
200253cc:	d103      	bne.n	200253d6 <HAL_RCC_HCPU_ConfigDvfs+0xba>
200253ce:	f04f 32ff 	mov.w	r2, #4294967295
200253d2:	4611      	mov	r1, r2
200253d4:	e7d4      	b.n	20025380 <HAL_RCC_HCPU_ConfigDvfs+0x64>
200253d6:	2190      	movs	r1, #144	@ 0x90
200253d8:	2002      	movs	r0, #2
200253da:	f7ff ff1f 	bl	2002521c <HAL_RCC_HCPU_SwitchDvfsD2S>
200253de:	2800      	cmp	r0, #0
200253e0:	d1a6      	bne.n	20025330 <HAL_RCC_HCPU_ConfigDvfs+0x14>
200253e2:	e7b1      	b.n	20025348 <HAL_RCC_HCPU_ConfigDvfs+0x2c>
200253e4:	20042c14 	.word	0x20042c14
200253e8:	2002ba44 	.word	0x2002ba44
200253ec:	000f4240 	.word	0x000f4240

200253f0 <HAL_RCC_Reset_and_Halt_LCPU>:
200253f0:	4a13      	ldr	r2, [pc, #76]	@ (20025440 <HAL_RCC_Reset_and_Halt_LCPU+0x50>)
200253f2:	6813      	ldr	r3, [r2, #0]
200253f4:	0759      	lsls	r1, r3, #29
200253f6:	d421      	bmi.n	2002543c <HAL_RCC_Reset_and_Halt_LCPU+0x4c>
200253f8:	6811      	ldr	r1, [r2, #0]
200253fa:	2800      	cmp	r0, #0
200253fc:	bf0c      	ite	eq
200253fe:	2301      	moveq	r3, #1
20025400:	f04f 33ff 	movne.w	r3, #4294967295
20025404:	f041 0104 	orr.w	r1, r1, #4
20025408:	6011      	str	r1, [r2, #0]
2002540a:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
2002540e:	f443 1380 	orr.w	r3, r3, #1048576	@ 0x100000
20025412:	6013      	str	r3, [r2, #0]
20025414:	6811      	ldr	r1, [r2, #0]
20025416:	2900      	cmp	r1, #0
20025418:	d0fc      	beq.n	20025414 <HAL_RCC_Reset_and_Halt_LCPU+0x24>
2002541a:	4a09      	ldr	r2, [pc, #36]	@ (20025440 <HAL_RCC_Reset_and_Halt_LCPU+0x50>)
2002541c:	6c11      	ldr	r1, [r2, #64]	@ 0x40
2002541e:	06c8      	lsls	r0, r1, #27
20025420:	d506      	bpl.n	20025430 <HAL_RCC_Reset_and_Halt_LCPU+0x40>
20025422:	6c11      	ldr	r1, [r2, #64]	@ 0x40
20025424:	f041 0102 	orr.w	r1, r1, #2
20025428:	6411      	str	r1, [r2, #64]	@ 0x40
2002542a:	6c11      	ldr	r1, [r2, #64]	@ 0x40
2002542c:	06c9      	lsls	r1, r1, #27
2002542e:	d4fc      	bmi.n	2002542a <HAL_RCC_Reset_and_Halt_LCPU+0x3a>
20025430:	f04f 4180 	mov.w	r1, #1073741824	@ 0x40000000
20025434:	680a      	ldr	r2, [r1, #0]
20025436:	ea22 0303 	bic.w	r3, r2, r3
2002543a:	600b      	str	r3, [r1, #0]
2002543c:	4770      	bx	lr
2002543e:	bf00      	nop
20025440:	40040000 	.word	0x40040000

20025444 <HAL_RCC_EnableModule>:
20025444:	1c43      	adds	r3, r0, #1
20025446:	d013      	beq.n	20025470 <HAL_RCC_EnableModule+0x2c>
20025448:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
2002544c:	b281      	uxth	r1, r0
2002544e:	d000      	beq.n	20025452 <HAL_RCC_EnableModule+0xe>
20025450:	e7fe      	b.n	20025450 <HAL_RCC_EnableModule+0xc>
20025452:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
20025456:	f3c0 2281 	ubfx	r2, r0, #10, #2
2002545a:	f3c0 2301 	ubfx	r3, r0, #8, #2
2002545e:	d108      	bne.n	20025472 <HAL_RCC_EnableModule+0x2e>
20025460:	009b      	lsls	r3, r3, #2
20025462:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20025466:	3310      	adds	r3, #16
20025468:	2201      	movs	r2, #1
2002546a:	b2c9      	uxtb	r1, r1
2002546c:	408a      	lsls	r2, r1
2002546e:	601a      	str	r2, [r3, #0]
20025470:	4770      	bx	lr
20025472:	2a01      	cmp	r2, #1
20025474:	d104      	bne.n	20025480 <HAL_RCC_EnableModule+0x3c>
20025476:	009b      	lsls	r3, r3, #2
20025478:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
2002547c:	3308      	adds	r3, #8
2002547e:	e7f3      	b.n	20025468 <HAL_RCC_EnableModule+0x24>
20025480:	e7fe      	b.n	20025480 <HAL_RCC_EnableModule+0x3c>

20025482 <HAL_RCC_HCPU_ConfigHCLK>:
20025482:	28f0      	cmp	r0, #240	@ 0xf0
20025484:	d80d      	bhi.n	200254a2 <HAL_RCC_HCPU_ConfigHCLK+0x20>
20025486:	2890      	cmp	r0, #144	@ 0x90
20025488:	d807      	bhi.n	2002549a <HAL_RCC_HCPU_ConfigHCLK+0x18>
2002548a:	2830      	cmp	r0, #48	@ 0x30
2002548c:	d807      	bhi.n	2002549e <HAL_RCC_HCPU_ConfigHCLK+0x1c>
2002548e:	2818      	cmp	r0, #24
20025490:	bf94      	ite	ls
20025492:	2100      	movls	r1, #0
20025494:	2101      	movhi	r1, #1
20025496:	f7ff bf41 	b.w	2002531c <HAL_RCC_HCPU_ConfigDvfs>
2002549a:	2103      	movs	r1, #3
2002549c:	e7fb      	b.n	20025496 <HAL_RCC_HCPU_ConfigHCLK+0x14>
2002549e:	2102      	movs	r1, #2
200254a0:	e7f9      	b.n	20025496 <HAL_RCC_HCPU_ConfigHCLK+0x14>
200254a2:	2001      	movs	r0, #1
200254a4:	4770      	bx	lr

200254a6 <spi_nor_get_ext_cfg_by_id>:
200254a6:	2000      	movs	r0, #0
200254a8:	4770      	bx	lr

200254aa <spi_nor_get_user_flash_cfg>:
200254aa:	2000      	movs	r0, #0
200254ac:	4770      	bx	lr
	...

200254b0 <spi_flash_get_rdid>:
200254b0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200254b2:	4604      	mov	r4, r0
200254b4:	3801      	subs	r0, #1
200254b6:	b2c0      	uxtb	r0, r0
200254b8:	28fd      	cmp	r0, #253	@ 0xfd
200254ba:	d816      	bhi.n	200254ea <spi_flash_get_rdid+0x3a>
200254bc:	2500      	movs	r5, #0
200254be:	4e0d      	ldr	r6, [pc, #52]	@ (200254f4 <spi_flash_get_rdid+0x44>)
200254c0:	f856 0b04 	ldr.w	r0, [r6], #4
200254c4:	7807      	ldrb	r7, [r0, #0]
200254c6:	b937      	cbnz	r7, 200254d6 <spi_flash_get_rdid+0x26>
200254c8:	3501      	adds	r5, #1
200254ca:	2d06      	cmp	r5, #6
200254cc:	d1f8      	bne.n	200254c0 <spi_flash_get_rdid+0x10>
200254ce:	4620      	mov	r0, r4
200254d0:	f7ff ffeb 	bl	200254aa <spi_nor_get_user_flash_cfg>
200254d4:	e00d      	b.n	200254f2 <spi_flash_get_rdid+0x42>
200254d6:	42a7      	cmp	r7, r4
200254d8:	d105      	bne.n	200254e6 <spi_flash_get_rdid+0x36>
200254da:	7847      	ldrb	r7, [r0, #1]
200254dc:	4297      	cmp	r7, r2
200254de:	d102      	bne.n	200254e6 <spi_flash_get_rdid+0x36>
200254e0:	7887      	ldrb	r7, [r0, #2]
200254e2:	428f      	cmp	r7, r1
200254e4:	d003      	beq.n	200254ee <spi_flash_get_rdid+0x3e>
200254e6:	3008      	adds	r0, #8
200254e8:	e7ec      	b.n	200254c4 <spi_flash_get_rdid+0x14>
200254ea:	2000      	movs	r0, #0
200254ec:	e001      	b.n	200254f2 <spi_flash_get_rdid+0x42>
200254ee:	b103      	cbz	r3, 200254f2 <spi_flash_get_rdid+0x42>
200254f0:	701d      	strb	r5, [r3, #0]
200254f2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200254f4:	20042c18 	.word	0x20042c18

200254f8 <spi_flash_get_cmd_by_id>:
200254f8:	b507      	push	{r0, r1, r2, lr}
200254fa:	f10d 0307 	add.w	r3, sp, #7
200254fe:	f7ff ffd7 	bl	200254b0 <spi_flash_get_rdid>
20025502:	4b06      	ldr	r3, [pc, #24]	@ (2002551c <spi_flash_get_cmd_by_id+0x24>)
20025504:	b140      	cbz	r0, 20025518 <spi_flash_get_cmd_by_id+0x20>
20025506:	f44f 7105 	mov.w	r1, #532	@ 0x214
2002550a:	f89d 2007 	ldrb.w	r2, [sp, #7]
2002550e:	fb01 3002 	mla	r0, r1, r2, r3
20025512:	b003      	add	sp, #12
20025514:	f85d fb04 	ldr.w	pc, [sp], #4
20025518:	4618      	mov	r0, r3
2002551a:	e7fa      	b.n	20025512 <spi_flash_get_cmd_by_id+0x1a>
2002551c:	20042e60 	.word	0x20042e60

20025520 <spi_flash_get_size_by_id>:
20025520:	b508      	push	{r3, lr}
20025522:	2300      	movs	r3, #0
20025524:	f7ff ffc4 	bl	200254b0 <spi_flash_get_rdid>
20025528:	b108      	cbz	r0, 2002552e <spi_flash_get_size_by_id+0xe>
2002552a:	6840      	ldr	r0, [r0, #4]
2002552c:	bd08      	pop	{r3, pc}
2002552e:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
20025532:	e7fb      	b.n	2002552c <spi_flash_get_size_by_id+0xc>

20025534 <spi_flash_is_support_dtr>:
20025534:	b508      	push	{r3, lr}
20025536:	2300      	movs	r3, #0
20025538:	f7ff ffba 	bl	200254b0 <spi_flash_get_rdid>
2002553c:	b110      	cbz	r0, 20025544 <spi_flash_is_support_dtr+0x10>
2002553e:	78c0      	ldrb	r0, [r0, #3]
20025540:	f000 0001 	and.w	r0, r0, #1
20025544:	bd08      	pop	{r3, pc}
	...

20025548 <spi_flash_get_otp_base>:
20025548:	b508      	push	{r3, lr}
2002554a:	2300      	movs	r3, #0
2002554c:	f7ff ffb0 	bl	200254b0 <spi_flash_get_rdid>
20025550:	b130      	cbz	r0, 20025560 <spi_flash_get_otp_base+0x18>
20025552:	78c3      	ldrb	r3, [r0, #3]
20025554:	4803      	ldr	r0, [pc, #12]	@ (20025564 <spi_flash_get_otp_base+0x1c>)
20025556:	f003 0306 	and.w	r3, r3, #6
2002555a:	2b02      	cmp	r3, #2
2002555c:	bf18      	it	ne
2002555e:	2000      	movne	r0, #0
20025560:	bd08      	pop	{r3, pc}
20025562:	bf00      	nop
20025564:	00ffc000 	.word	0x00ffc000

20025568 <spi_nand_get_user_flash_cfg>:
20025568:	2000      	movs	r0, #0
2002556a:	4770      	bx	lr

2002556c <spi_nand_get_rdid>:
2002556c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002556e:	4604      	mov	r4, r0
20025570:	3801      	subs	r0, #1
20025572:	b2c0      	uxtb	r0, r0
20025574:	28fd      	cmp	r0, #253	@ 0xfd
20025576:	d816      	bhi.n	200255a6 <spi_nand_get_rdid+0x3a>
20025578:	2500      	movs	r5, #0
2002557a:	4e0d      	ldr	r6, [pc, #52]	@ (200255b0 <spi_nand_get_rdid+0x44>)
2002557c:	f856 0b04 	ldr.w	r0, [r6], #4
20025580:	7807      	ldrb	r7, [r0, #0]
20025582:	b937      	cbnz	r7, 20025592 <spi_nand_get_rdid+0x26>
20025584:	3501      	adds	r5, #1
20025586:	2d06      	cmp	r5, #6
20025588:	d1f8      	bne.n	2002557c <spi_nand_get_rdid+0x10>
2002558a:	4620      	mov	r0, r4
2002558c:	f7ff ffec 	bl	20025568 <spi_nand_get_user_flash_cfg>
20025590:	e00d      	b.n	200255ae <spi_nand_get_rdid+0x42>
20025592:	42a7      	cmp	r7, r4
20025594:	d105      	bne.n	200255a2 <spi_nand_get_rdid+0x36>
20025596:	7847      	ldrb	r7, [r0, #1]
20025598:	4297      	cmp	r7, r2
2002559a:	d102      	bne.n	200255a2 <spi_nand_get_rdid+0x36>
2002559c:	7887      	ldrb	r7, [r0, #2]
2002559e:	428f      	cmp	r7, r1
200255a0:	d003      	beq.n	200255aa <spi_nand_get_rdid+0x3e>
200255a2:	3008      	adds	r0, #8
200255a4:	e7ec      	b.n	20025580 <spi_nand_get_rdid+0x14>
200255a6:	2000      	movs	r0, #0
200255a8:	e001      	b.n	200255ae <spi_nand_get_rdid+0x42>
200255aa:	b103      	cbz	r3, 200255ae <spi_nand_get_rdid+0x42>
200255ac:	701d      	strb	r5, [r3, #0]
200255ae:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200255b0:	20043ad8 	.word	0x20043ad8

200255b4 <spi_nand_get_cmd_by_id>:
200255b4:	b507      	push	{r0, r1, r2, lr}
200255b6:	f10d 0307 	add.w	r3, sp, #7
200255ba:	f7ff ffd7 	bl	2002556c <spi_nand_get_rdid>
200255be:	b130      	cbz	r0, 200255ce <spi_nand_get_cmd_by_id+0x1a>
200255c0:	f44f 7205 	mov.w	r2, #532	@ 0x214
200255c4:	f89d 3007 	ldrb.w	r3, [sp, #7]
200255c8:	4802      	ldr	r0, [pc, #8]	@ (200255d4 <spi_nand_get_cmd_by_id+0x20>)
200255ca:	fb02 0003 	mla	r0, r2, r3, r0
200255ce:	b003      	add	sp, #12
200255d0:	f85d fb04 	ldr.w	pc, [sp], #4
200255d4:	20043d20 	.word	0x20043d20

200255d8 <spi_nand_get_ext_cfg_by_id>:
200255d8:	2000      	movs	r0, #0
200255da:	4770      	bx	lr

200255dc <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
200255dc:	f04f 30ff 	mov.w	r0, #4294967295
200255e0:	4770      	bx	lr
	...

200255e4 <spi_nand_get_default_ctable>:
200255e4:	b508      	push	{r3, lr}
200255e6:	f7ff fff9 	bl	200255dc <HAL_GET_NAND_FLASH_DEFAUT_IDX>
200255ea:	1e03      	subs	r3, r0, #0
200255ec:	bfa5      	ittet	ge
200255ee:	f44f 7205 	movge.w	r2, #532	@ 0x214
200255f2:	4802      	ldrge	r0, [pc, #8]	@ (200255fc <spi_nand_get_default_ctable+0x18>)
200255f4:	2000      	movlt	r0, #0
200255f6:	fb02 0003 	mlage	r0, r2, r3, r0
200255fa:	bd08      	pop	{r3, pc}
200255fc:	20043d20 	.word	0x20043d20

20025600 <spi_nand_get_size_by_id>:
20025600:	b508      	push	{r3, lr}
20025602:	2300      	movs	r3, #0
20025604:	f7ff ffb2 	bl	2002556c <spi_nand_get_rdid>
20025608:	b108      	cbz	r0, 2002560e <spi_nand_get_size_by_id+0xe>
2002560a:	6840      	ldr	r0, [r0, #4]
2002560c:	bd08      	pop	{r3, pc}
2002560e:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20025612:	e7fb      	b.n	2002560c <spi_nand_get_size_by_id+0xc>

20025614 <spi_nand_get_plane_select_flag>:
20025614:	b508      	push	{r3, lr}
20025616:	2300      	movs	r3, #0
20025618:	f7ff ffa8 	bl	2002556c <spi_nand_get_rdid>
2002561c:	b110      	cbz	r0, 20025624 <spi_nand_get_plane_select_flag+0x10>
2002561e:	78c0      	ldrb	r0, [r0, #3]
20025620:	f3c0 0040 	ubfx	r0, r0, #1, #1
20025624:	bd08      	pop	{r3, pc}

20025626 <spi_nand_get_big_page_flag>:
20025626:	b508      	push	{r3, lr}
20025628:	2300      	movs	r3, #0
2002562a:	f7ff ff9f 	bl	2002556c <spi_nand_get_rdid>
2002562e:	b110      	cbz	r0, 20025636 <spi_nand_get_big_page_flag+0x10>
20025630:	78c0      	ldrb	r0, [r0, #3]
20025632:	f3c0 0081 	ubfx	r0, r0, #2, #2
20025636:	bd08      	pop	{r3, pc}

20025638 <spi_nand_get_ecc_mode>:
20025638:	b508      	push	{r3, lr}
2002563a:	2300      	movs	r3, #0
2002563c:	f7ff ff96 	bl	2002556c <spi_nand_get_rdid>
20025640:	b108      	cbz	r0, 20025646 <spi_nand_get_ecc_mode+0xe>
20025642:	78c0      	ldrb	r0, [r0, #3]
20025644:	0900      	lsrs	r0, r0, #4
20025646:	bd08      	pop	{r3, pc}

20025648 <bbm_map_check.part.0>:
20025648:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
2002564a:	4b21      	ldr	r3, [pc, #132]	@ (200256d0 <bbm_map_check.part.0+0x88>)
2002564c:	4606      	mov	r6, r0
2002564e:	681d      	ldr	r5, [r3, #0]
20025650:	4b20      	ldr	r3, [pc, #128]	@ (200256d4 <bbm_map_check.part.0+0x8c>)
20025652:	3d04      	subs	r5, #4
20025654:	681f      	ldr	r7, [r3, #0]
20025656:	2300      	movs	r3, #0
20025658:	f100 0e1a 	add.w	lr, r0, #26
2002565c:	42ab      	cmp	r3, r5
2002565e:	db02      	blt.n	20025666 <bbm_map_check.part.0+0x1e>
20025660:	2000      	movs	r0, #0
20025662:	b003      	add	sp, #12
20025664:	bdf0      	pop	{r4, r5, r6, r7, pc}
20025666:	8b31      	ldrh	r1, [r6, #24]
20025668:	b321      	cbz	r1, 200256b4 <bbm_map_check.part.0+0x6c>
2002566a:	8b72      	ldrh	r2, [r6, #26]
2002566c:	b33a      	cbz	r2, 200256be <bbm_map_check.part.0+0x76>
2002566e:	42b9      	cmp	r1, r7
20025670:	d201      	bcs.n	20025676 <bbm_map_check.part.0+0x2e>
20025672:	4297      	cmp	r7, r2
20025674:	d905      	bls.n	20025682 <bbm_map_check.part.0+0x3a>
20025676:	4b18      	ldr	r3, [pc, #96]	@ (200256d8 <bbm_map_check.part.0+0x90>)
20025678:	681b      	ldr	r3, [r3, #0]
2002567a:	b10b      	cbz	r3, 20025680 <bbm_map_check.part.0+0x38>
2002567c:	4817      	ldr	r0, [pc, #92]	@ (200256dc <bbm_map_check.part.0+0x94>)
2002567e:	4798      	blx	r3
20025680:	e7fe      	b.n	20025680 <bbm_map_check.part.0+0x38>
20025682:	3301      	adds	r3, #1
20025684:	461c      	mov	r4, r3
20025686:	42ac      	cmp	r4, r5
20025688:	db01      	blt.n	2002568e <bbm_map_check.part.0+0x46>
2002568a:	3604      	adds	r6, #4
2002568c:	e7e6      	b.n	2002565c <bbm_map_check.part.0+0x14>
2002568e:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
20025692:	f1bc 0f00 	cmp.w	ip, #0
20025696:	d0f8      	beq.n	2002568a <bbm_map_check.part.0+0x42>
20025698:	4562      	cmp	r2, ip
2002569a:	d109      	bne.n	200256b0 <bbm_map_check.part.0+0x68>
2002569c:	4b0e      	ldr	r3, [pc, #56]	@ (200256d8 <bbm_map_check.part.0+0x90>)
2002569e:	681d      	ldr	r5, [r3, #0]
200256a0:	b12d      	cbz	r5, 200256ae <bbm_map_check.part.0+0x66>
200256a2:	3406      	adds	r4, #6
200256a4:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
200256a8:	480d      	ldr	r0, [pc, #52]	@ (200256e0 <bbm_map_check.part.0+0x98>)
200256aa:	9200      	str	r2, [sp, #0]
200256ac:	47a8      	blx	r5
200256ae:	e7fe      	b.n	200256ae <bbm_map_check.part.0+0x66>
200256b0:	3401      	adds	r4, #1
200256b2:	e7e8      	b.n	20025686 <bbm_map_check.part.0+0x3e>
200256b4:	eb00 0283 	add.w	r2, r0, r3, lsl #2
200256b8:	8b52      	ldrh	r2, [r2, #26]
200256ba:	2a00      	cmp	r2, #0
200256bc:	d0d0      	beq.n	20025660 <bbm_map_check.part.0+0x18>
200256be:	4a06      	ldr	r2, [pc, #24]	@ (200256d8 <bbm_map_check.part.0+0x90>)
200256c0:	6814      	ldr	r4, [r2, #0]
200256c2:	b124      	cbz	r4, 200256ce <bbm_map_check.part.0+0x86>
200256c4:	eb00 0383 	add.w	r3, r0, r3, lsl #2
200256c8:	8b5a      	ldrh	r2, [r3, #26]
200256ca:	4806      	ldr	r0, [pc, #24]	@ (200256e4 <bbm_map_check.part.0+0x9c>)
200256cc:	47a0      	blx	r4
200256ce:	e7fe      	b.n	200256ce <bbm_map_check.part.0+0x86>
200256d0:	2004cc64 	.word	0x2004cc64
200256d4:	2004cc68 	.word	0x2004cc68
200256d8:	2004cc54 	.word	0x2004cc54
200256dc:	2002abe4 	.word	0x2002abe4
200256e0:	2002ac01 	.word	0x2002ac01
200256e4:	2002ac4e 	.word	0x2002ac4e

200256e8 <bbm_crc_check>:
200256e8:	f04f 32ff 	mov.w	r2, #4294967295
200256ec:	b510      	push	{r4, lr}
200256ee:	4c07      	ldr	r4, [pc, #28]	@ (2002570c <bbm_crc_check+0x24>)
200256f0:	4401      	add	r1, r0
200256f2:	4288      	cmp	r0, r1
200256f4:	d101      	bne.n	200256fa <bbm_crc_check+0x12>
200256f6:	43d0      	mvns	r0, r2
200256f8:	bd10      	pop	{r4, pc}
200256fa:	f810 3b01 	ldrb.w	r3, [r0], #1
200256fe:	4053      	eors	r3, r2
20025700:	b2db      	uxtb	r3, r3
20025702:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
20025706:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
2002570a:	e7f2      	b.n	200256f2 <bbm_crc_check+0xa>
2002570c:	2002ba74 	.word	0x2002ba74

20025710 <bbm_get_phy_blk>:
20025710:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025712:	4b14      	ldr	r3, [pc, #80]	@ (20025764 <bbm_get_phy_blk+0x54>)
20025714:	4601      	mov	r1, r0
20025716:	681e      	ldr	r6, [r3, #0]
20025718:	42b0      	cmp	r0, r6
2002571a:	d21e      	bcs.n	2002575a <bbm_get_phy_blk+0x4a>
2002571c:	b138      	cbz	r0, 2002572e <bbm_get_phy_blk+0x1e>
2002571e:	4b12      	ldr	r3, [pc, #72]	@ (20025768 <bbm_get_phy_blk+0x58>)
20025720:	2200      	movs	r2, #0
20025722:	681c      	ldr	r4, [r3, #0]
20025724:	4b11      	ldr	r3, [pc, #68]	@ (2002576c <bbm_get_phy_blk+0x5c>)
20025726:	3c04      	subs	r4, #4
20025728:	461d      	mov	r5, r3
2002572a:	4294      	cmp	r4, r2
2002572c:	dc00      	bgt.n	20025730 <bbm_get_phy_blk+0x20>
2002572e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20025730:	8b1f      	ldrh	r7, [r3, #24]
20025732:	428f      	cmp	r7, r1
20025734:	d10a      	bne.n	2002574c <bbm_get_phy_blk+0x3c>
20025736:	eb05 0582 	add.w	r5, r5, r2, lsl #2
2002573a:	8b6a      	ldrh	r2, [r5, #26]
2002573c:	4296      	cmp	r6, r2
2002573e:	dd0f      	ble.n	20025760 <bbm_get_phy_blk+0x50>
20025740:	4b0b      	ldr	r3, [pc, #44]	@ (20025770 <bbm_get_phy_blk+0x60>)
20025742:	681b      	ldr	r3, [r3, #0]
20025744:	b10b      	cbz	r3, 2002574a <bbm_get_phy_blk+0x3a>
20025746:	480b      	ldr	r0, [pc, #44]	@ (20025774 <bbm_get_phy_blk+0x64>)
20025748:	4798      	blx	r3
2002574a:	e7fe      	b.n	2002574a <bbm_get_phy_blk+0x3a>
2002574c:	b917      	cbnz	r7, 20025754 <bbm_get_phy_blk+0x44>
2002574e:	8b5f      	ldrh	r7, [r3, #26]
20025750:	2f00      	cmp	r7, #0
20025752:	d0ec      	beq.n	2002572e <bbm_get_phy_blk+0x1e>
20025754:	3201      	adds	r2, #1
20025756:	3304      	adds	r3, #4
20025758:	e7e7      	b.n	2002572a <bbm_get_phy_blk+0x1a>
2002575a:	f04f 30ff 	mov.w	r0, #4294967295
2002575e:	e7e6      	b.n	2002572e <bbm_get_phy_blk+0x1e>
20025760:	4610      	mov	r0, r2
20025762:	e7e4      	b.n	2002572e <bbm_get_phy_blk+0x1e>
20025764:	2004cc68 	.word	0x2004cc68
20025768:	2004cc64 	.word	0x2004cc64
2002576c:	2004cc6c 	.word	0x2004cc6c
20025770:	2004cc54 	.word	0x2004cc54
20025774:	2002ac6c 	.word	0x2002ac6c

20025778 <bbm_get_version_inblk>:
20025778:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002577c:	4607      	mov	r7, r0
2002577e:	4688      	mov	r8, r1
20025780:	b087      	sub	sp, #28
20025782:	2900      	cmp	r1, #0
20025784:	d14b      	bne.n	2002581e <bbm_get_version_inblk+0xa6>
20025786:	2500      	movs	r5, #0
20025788:	4628      	mov	r0, r5
2002578a:	b007      	add	sp, #28
2002578c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025790:	2200      	movs	r2, #0
20025792:	e9cd 2201 	strd	r2, r2, [sp, #4]
20025796:	4e26      	ldr	r6, [pc, #152]	@ (20025830 <bbm_get_version_inblk+0xb8>)
20025798:	9100      	str	r1, [sp, #0]
2002579a:	4638      	mov	r0, r7
2002579c:	4621      	mov	r1, r4
2002579e:	6833      	ldr	r3, [r6, #0]
200257a0:	f7fb f9be 	bl	20020b20 <port_read_page>
200257a4:	2800      	cmp	r0, #0
200257a6:	dd32      	ble.n	2002580e <bbm_get_version_inblk+0x96>
200257a8:	6832      	ldr	r2, [r6, #0]
200257aa:	6813      	ldr	r3, [r2, #0]
200257ac:	455b      	cmp	r3, fp
200257ae:	d123      	bne.n	200257f8 <bbm_get_version_inblk+0x80>
200257b0:	6856      	ldr	r6, [r2, #4]
200257b2:	f3c6 061e 	ubfx	r6, r6, #0, #31
200257b6:	42ae      	cmp	r6, r5
200257b8:	dd15      	ble.n	200257e6 <bbm_get_version_inblk+0x6e>
200257ba:	4610      	mov	r0, r2
200257bc:	2110      	movs	r1, #16
200257be:	9205      	str	r2, [sp, #20]
200257c0:	f7ff ff92 	bl	200256e8 <bbm_crc_check>
200257c4:	9a05      	ldr	r2, [sp, #20]
200257c6:	6913      	ldr	r3, [r2, #16]
200257c8:	4283      	cmp	r3, r0
200257ca:	d113      	bne.n	200257f4 <bbm_get_version_inblk+0x7c>
200257cc:	f8c8 4000 	str.w	r4, [r8]
200257d0:	4635      	mov	r5, r6
200257d2:	3401      	adds	r4, #1
200257d4:	f8da 1000 	ldr.w	r1, [sl]
200257d8:	f8d9 3000 	ldr.w	r3, [r9]
200257dc:	fbb3 f3f1 	udiv	r3, r3, r1
200257e0:	42a3      	cmp	r3, r4
200257e2:	d8d5      	bhi.n	20025790 <bbm_get_version_inblk+0x18>
200257e4:	e7d0      	b.n	20025788 <bbm_get_version_inblk+0x10>
200257e6:	4b13      	ldr	r3, [pc, #76]	@ (20025834 <bbm_get_version_inblk+0xbc>)
200257e8:	681b      	ldr	r3, [r3, #0]
200257ea:	b11b      	cbz	r3, 200257f4 <bbm_get_version_inblk+0x7c>
200257ec:	4632      	mov	r2, r6
200257ee:	4629      	mov	r1, r5
200257f0:	4811      	ldr	r0, [pc, #68]	@ (20025838 <bbm_get_version_inblk+0xc0>)
200257f2:	4798      	blx	r3
200257f4:	462e      	mov	r6, r5
200257f6:	e7eb      	b.n	200257d0 <bbm_get_version_inblk+0x58>
200257f8:	1c5a      	adds	r2, r3, #1
200257fa:	d0c5      	beq.n	20025788 <bbm_get_version_inblk+0x10>
200257fc:	4a0d      	ldr	r2, [pc, #52]	@ (20025834 <bbm_get_version_inblk+0xbc>)
200257fe:	6815      	ldr	r5, [r2, #0]
20025800:	2d00      	cmp	r5, #0
20025802:	d0c0      	beq.n	20025786 <bbm_get_version_inblk+0xe>
20025804:	4622      	mov	r2, r4
20025806:	4639      	mov	r1, r7
20025808:	480c      	ldr	r0, [pc, #48]	@ (2002583c <bbm_get_version_inblk+0xc4>)
2002580a:	47a8      	blx	r5
2002580c:	e7bb      	b.n	20025786 <bbm_get_version_inblk+0xe>
2002580e:	4b09      	ldr	r3, [pc, #36]	@ (20025834 <bbm_get_version_inblk+0xbc>)
20025810:	681b      	ldr	r3, [r3, #0]
20025812:	2b00      	cmp	r3, #0
20025814:	d0ee      	beq.n	200257f4 <bbm_get_version_inblk+0x7c>
20025816:	4622      	mov	r2, r4
20025818:	4639      	mov	r1, r7
2002581a:	4809      	ldr	r0, [pc, #36]	@ (20025840 <bbm_get_version_inblk+0xc8>)
2002581c:	e7e9      	b.n	200257f2 <bbm_get_version_inblk+0x7a>
2002581e:	2400      	movs	r4, #0
20025820:	f8df a020 	ldr.w	sl, [pc, #32]	@ 20025844 <bbm_get_version_inblk+0xcc>
20025824:	4625      	mov	r5, r4
20025826:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 20025848 <bbm_get_version_inblk+0xd0>
2002582a:	f8df b020 	ldr.w	fp, [pc, #32]	@ 2002584c <bbm_get_version_inblk+0xd4>
2002582e:	e7d1      	b.n	200257d4 <bbm_get_version_inblk+0x5c>
20025830:	2004cc58 	.word	0x2004cc58
20025834:	2004cc54 	.word	0x2004cc54
20025838:	2002ac8b 	.word	0x2002ac8b
2002583c:	2002acb8 	.word	0x2002acb8
20025840:	2002ace9 	.word	0x2002ace9
20025844:	20044998 	.word	0x20044998
20025848:	2004499c 	.word	0x2004499c
2002584c:	5366424d 	.word	0x5366424d

20025850 <bbm_get_map_table>:
20025850:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025854:	2801      	cmp	r0, #1
20025856:	4607      	mov	r7, r0
20025858:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 200259b8 <bbm_get_map_table+0x168>
2002585c:	b087      	sub	sp, #28
2002585e:	dd0a      	ble.n	20025876 <bbm_get_map_table+0x26>
20025860:	f8db 3000 	ldr.w	r3, [fp]
20025864:	b91b      	cbnz	r3, 2002586e <bbm_get_map_table+0x1e>
20025866:	2000      	movs	r0, #0
20025868:	b007      	add	sp, #28
2002586a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002586e:	4601      	mov	r1, r0
20025870:	4847      	ldr	r0, [pc, #284]	@ (20025990 <bbm_get_map_table+0x140>)
20025872:	4798      	blx	r3
20025874:	e7f7      	b.n	20025866 <bbm_get_map_table+0x16>
20025876:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 200259bc <bbm_get_map_table+0x16c>
2002587a:	2800      	cmp	r0, #0
2002587c:	d163      	bne.n	20025946 <bbm_get_map_table+0xf6>
2002587e:	f8b8 6000 	ldrh.w	r6, [r8]
20025882:	f8b8 5002 	ldrh.w	r5, [r8, #2]
20025886:	2e00      	cmp	r6, #0
20025888:	d062      	beq.n	20025950 <bbm_get_map_table+0x100>
2002588a:	4630      	mov	r0, r6
2002588c:	a904      	add	r1, sp, #16
2002588e:	f7ff ff73 	bl	20025778 <bbm_get_version_inblk>
20025892:	4681      	mov	r9, r0
20025894:	2d00      	cmp	r5, #0
20025896:	d05d      	beq.n	20025954 <bbm_get_map_table+0x104>
20025898:	4628      	mov	r0, r5
2002589a:	a905      	add	r1, sp, #20
2002589c:	f7ff ff6c 	bl	20025778 <bbm_get_version_inblk>
200258a0:	4604      	mov	r4, r0
200258a2:	f8db a000 	ldr.w	sl, [fp]
200258a6:	f1ba 0f00 	cmp.w	sl, #0
200258aa:	d005      	beq.n	200258b8 <bbm_get_map_table+0x68>
200258ac:	4623      	mov	r3, r4
200258ae:	4632      	mov	r2, r6
200258b0:	4649      	mov	r1, r9
200258b2:	4838      	ldr	r0, [pc, #224]	@ (20025994 <bbm_get_map_table+0x144>)
200258b4:	9500      	str	r5, [sp, #0]
200258b6:	47d0      	blx	sl
200258b8:	45a1      	cmp	r9, r4
200258ba:	d0d4      	beq.n	20025866 <bbm_get_map_table+0x16>
200258bc:	f04f 0200 	mov.w	r2, #0
200258c0:	bf98      	it	ls
200258c2:	462e      	movls	r6, r5
200258c4:	f107 0308 	add.w	r3, r7, #8
200258c8:	bf94      	ite	ls
200258ca:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
200258ce:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
200258d2:	e9cd 2201 	strd	r2, r2, [sp, #4]
200258d6:	4b30      	ldr	r3, [pc, #192]	@ (20025998 <bbm_get_map_table+0x148>)
200258d8:	bf88      	it	hi
200258da:	f8dd a010 	ldrhi.w	sl, [sp, #16]
200258de:	681b      	ldr	r3, [r3, #0]
200258e0:	bf98      	it	ls
200258e2:	f8dd a014 	ldrls.w	sl, [sp, #20]
200258e6:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 200259c0 <bbm_get_map_table+0x170>
200258ea:	9300      	str	r3, [sp, #0]
200258ec:	4651      	mov	r1, sl
200258ee:	4630      	mov	r0, r6
200258f0:	f8d8 3000 	ldr.w	r3, [r8]
200258f4:	bf88      	it	hi
200258f6:	464c      	movhi	r4, r9
200258f8:	f7fb f912 	bl	20020b20 <port_read_page>
200258fc:	2800      	cmp	r0, #0
200258fe:	f8db 5000 	ldr.w	r5, [fp]
20025902:	dd38      	ble.n	20025976 <bbm_get_map_table+0x126>
20025904:	f8d8 8000 	ldr.w	r8, [r8]
20025908:	4b24      	ldr	r3, [pc, #144]	@ (2002599c <bbm_get_map_table+0x14c>)
2002590a:	f8d8 2000 	ldr.w	r2, [r8]
2002590e:	429a      	cmp	r2, r3
20025910:	d12b      	bne.n	2002596a <bbm_get_map_table+0x11a>
20025912:	2110      	movs	r1, #16
20025914:	4640      	mov	r0, r8
20025916:	f7ff fee7 	bl	200256e8 <bbm_crc_check>
2002591a:	f8d8 2010 	ldr.w	r2, [r8, #16]
2002591e:	4601      	mov	r1, r0
20025920:	4282      	cmp	r2, r0
20025922:	d11e      	bne.n	20025962 <bbm_get_map_table+0x112>
20025924:	f8d8 1004 	ldr.w	r1, [r8, #4]
20025928:	f3c1 011e 	ubfx	r1, r1, #0, #31
2002592c:	42a1      	cmp	r1, r4
2002592e:	d113      	bne.n	20025958 <bbm_get_map_table+0x108>
20025930:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025934:	481a      	ldr	r0, [pc, #104]	@ (200259a0 <bbm_get_map_table+0x150>)
20025936:	4641      	mov	r1, r8
20025938:	fb02 0007 	mla	r0, r2, r7, r0
2002593c:	f005 f888 	bl	2002aa50 <memcpy>
20025940:	bb0d      	cbnz	r5, 20025986 <bbm_get_map_table+0x136>
20025942:	4620      	mov	r0, r4
20025944:	e790      	b.n	20025868 <bbm_get_map_table+0x18>
20025946:	f8b8 6004 	ldrh.w	r6, [r8, #4]
2002594a:	f8b8 5006 	ldrh.w	r5, [r8, #6]
2002594e:	e79a      	b.n	20025886 <bbm_get_map_table+0x36>
20025950:	46b1      	mov	r9, r6
20025952:	e79f      	b.n	20025894 <bbm_get_map_table+0x44>
20025954:	462c      	mov	r4, r5
20025956:	e7a4      	b.n	200258a2 <bbm_get_map_table+0x52>
20025958:	b115      	cbz	r5, 20025960 <bbm_get_map_table+0x110>
2002595a:	4622      	mov	r2, r4
2002595c:	4811      	ldr	r0, [pc, #68]	@ (200259a4 <bbm_get_map_table+0x154>)
2002595e:	47a8      	blx	r5
20025960:	e7fe      	b.n	20025960 <bbm_get_map_table+0x110>
20025962:	b10d      	cbz	r5, 20025968 <bbm_get_map_table+0x118>
20025964:	4810      	ldr	r0, [pc, #64]	@ (200259a8 <bbm_get_map_table+0x158>)
20025966:	47a8      	blx	r5
20025968:	e7fe      	b.n	20025968 <bbm_get_map_table+0x118>
2002596a:	b11d      	cbz	r5, 20025974 <bbm_get_map_table+0x124>
2002596c:	4652      	mov	r2, sl
2002596e:	4631      	mov	r1, r6
20025970:	480e      	ldr	r0, [pc, #56]	@ (200259ac <bbm_get_map_table+0x15c>)
20025972:	47a8      	blx	r5
20025974:	e7fe      	b.n	20025974 <bbm_get_map_table+0x124>
20025976:	2d00      	cmp	r5, #0
20025978:	f43f af75 	beq.w	20025866 <bbm_get_map_table+0x16>
2002597c:	4652      	mov	r2, sl
2002597e:	4631      	mov	r1, r6
20025980:	480b      	ldr	r0, [pc, #44]	@ (200259b0 <bbm_get_map_table+0x160>)
20025982:	47a8      	blx	r5
20025984:	e76f      	b.n	20025866 <bbm_get_map_table+0x16>
20025986:	4621      	mov	r1, r4
20025988:	480a      	ldr	r0, [pc, #40]	@ (200259b4 <bbm_get_map_table+0x164>)
2002598a:	47a8      	blx	r5
2002598c:	e7d9      	b.n	20025942 <bbm_get_map_table+0xf2>
2002598e:	bf00      	nop
20025990:	2002ad07 	.word	0x2002ad07
20025994:	2002ad1b 	.word	0x2002ad1b
20025998:	20044998 	.word	0x20044998
2002599c:	5366424d 	.word	0x5366424d
200259a0:	2004cc6c 	.word	0x2004cc6c
200259a4:	2002ad41 	.word	0x2002ad41
200259a8:	2002ad8b 	.word	0x2002ad8b
200259ac:	2002ad9d 	.word	0x2002ad9d
200259b0:	2002add2 	.word	0x2002add2
200259b4:	2002adfe 	.word	0x2002adfe
200259b8:	2004cc54 	.word	0x2004cc54
200259bc:	2004d07c 	.word	0x2004d07c
200259c0:	2004cc58 	.word	0x2004cc58

200259c4 <bbm_get_page_num>:
200259c4:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200259c8:	4605      	mov	r5, r0
200259ca:	2400      	movs	r4, #0
200259cc:	4f13      	ldr	r7, [pc, #76]	@ (20025a1c <bbm_get_page_num+0x58>)
200259ce:	4e14      	ldr	r6, [pc, #80]	@ (20025a20 <bbm_get_page_num+0x5c>)
200259d0:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 20025a24 <bbm_get_page_num+0x60>
200259d4:	b085      	sub	sp, #20
200259d6:	6839      	ldr	r1, [r7, #0]
200259d8:	6833      	ldr	r3, [r6, #0]
200259da:	fbb3 f3f1 	udiv	r3, r3, r1
200259de:	42a3      	cmp	r3, r4
200259e0:	d802      	bhi.n	200259e8 <bbm_get_page_num+0x24>
200259e2:	f04f 34ff 	mov.w	r4, #4294967295
200259e6:	e015      	b.n	20025a14 <bbm_get_page_num+0x50>
200259e8:	2200      	movs	r2, #0
200259ea:	e9cd 2201 	strd	r2, r2, [sp, #4]
200259ee:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 20025a28 <bbm_get_page_num+0x64>
200259f2:	9100      	str	r1, [sp, #0]
200259f4:	4628      	mov	r0, r5
200259f6:	4621      	mov	r1, r4
200259f8:	f8d9 3000 	ldr.w	r3, [r9]
200259fc:	f7fb f890 	bl	20020b20 <port_read_page>
20025a00:	b120      	cbz	r0, 20025a0c <bbm_get_page_num+0x48>
20025a02:	f8d9 3000 	ldr.w	r3, [r9]
20025a06:	681b      	ldr	r3, [r3, #0]
20025a08:	4543      	cmp	r3, r8
20025a0a:	d101      	bne.n	20025a10 <bbm_get_page_num+0x4c>
20025a0c:	3401      	adds	r4, #1
20025a0e:	e7e2      	b.n	200259d6 <bbm_get_page_num+0x12>
20025a10:	3301      	adds	r3, #1
20025a12:	d1fb      	bne.n	20025a0c <bbm_get_page_num+0x48>
20025a14:	4620      	mov	r0, r4
20025a16:	b005      	add	sp, #20
20025a18:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20025a1c:	20044998 	.word	0x20044998
20025a20:	2004499c 	.word	0x2004499c
20025a24:	5366424d 	.word	0x5366424d
20025a28:	2004cc58 	.word	0x2004cc58

20025a2c <bbm_read_page>:
20025a2c:	b5f0      	push	{r4, r5, r6, r7, lr}
20025a2e:	4604      	mov	r4, r0
20025a30:	b085      	sub	sp, #20
20025a32:	b280      	uxth	r0, r0
20025a34:	461f      	mov	r7, r3
20025a36:	460d      	mov	r5, r1
20025a38:	4616      	mov	r6, r2
20025a3a:	f7ff fe69 	bl	20025710 <bbm_get_phy_blk>
20025a3e:	1c43      	adds	r3, r0, #1
20025a40:	d108      	bne.n	20025a54 <bbm_read_page+0x28>
20025a42:	4b0a      	ldr	r3, [pc, #40]	@ (20025a6c <bbm_read_page+0x40>)
20025a44:	681b      	ldr	r3, [r3, #0]
20025a46:	b113      	cbz	r3, 20025a4e <bbm_read_page+0x22>
20025a48:	4621      	mov	r1, r4
20025a4a:	4809      	ldr	r0, [pc, #36]	@ (20025a70 <bbm_read_page+0x44>)
20025a4c:	4798      	blx	r3
20025a4e:	2000      	movs	r0, #0
20025a50:	b005      	add	sp, #20
20025a52:	bdf0      	pop	{r4, r5, r6, r7, pc}
20025a54:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
20025a56:	4632      	mov	r2, r6
20025a58:	9302      	str	r3, [sp, #8]
20025a5a:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
20025a5c:	4629      	mov	r1, r5
20025a5e:	9301      	str	r3, [sp, #4]
20025a60:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20025a62:	9300      	str	r3, [sp, #0]
20025a64:	463b      	mov	r3, r7
20025a66:	f7fb f85b 	bl	20020b20 <port_read_page>
20025a6a:	e7f1      	b.n	20025a50 <bbm_read_page+0x24>
20025a6c:	2004cc54 	.word	0x2004cc54
20025a70:	2002ae11 	.word	0x2002ae11

20025a74 <port_write_page>:
20025a74:	4b01      	ldr	r3, [pc, #4]	@ (20025a7c <port_write_page+0x8>)
20025a76:	6818      	ldr	r0, [r3, #0]
20025a78:	4770      	bx	lr
20025a7a:	bf00      	nop
20025a7c:	20044998 	.word	0x20044998

20025a80 <bbm_write_talbe.isra.0>:
20025a80:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20025a82:	4604      	mov	r4, r0
20025a84:	4608      	mov	r0, r1
20025a86:	460e      	mov	r6, r1
20025a88:	f7ff ff9c 	bl	200259c4 <bbm_get_page_num>
20025a8c:	1e05      	subs	r5, r0, #0
20025a8e:	db25      	blt.n	20025adc <bbm_write_talbe.isra.0+0x5c>
20025a90:	4b13      	ldr	r3, [pc, #76]	@ (20025ae0 <bbm_write_talbe.isra.0+0x60>)
20025a92:	681a      	ldr	r2, [r3, #0]
20025a94:	4b13      	ldr	r3, [pc, #76]	@ (20025ae4 <bbm_write_talbe.isra.0+0x64>)
20025a96:	681b      	ldr	r3, [r3, #0]
20025a98:	fbb3 f3f2 	udiv	r3, r3, r2
20025a9c:	429d      	cmp	r5, r3
20025a9e:	da1d      	bge.n	20025adc <bbm_write_talbe.isra.0+0x5c>
20025aa0:	4f11      	ldr	r7, [pc, #68]	@ (20025ae8 <bbm_write_talbe.isra.0+0x68>)
20025aa2:	21ff      	movs	r1, #255	@ 0xff
20025aa4:	6838      	ldr	r0, [r7, #0]
20025aa6:	f004 ffb9 	bl	2002aa1c <memset>
20025aaa:	4264      	negs	r4, r4
20025aac:	490f      	ldr	r1, [pc, #60]	@ (20025aec <bbm_write_talbe.isra.0+0x6c>)
20025aae:	f404 7402 	and.w	r4, r4, #520	@ 0x208
20025ab2:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025ab6:	6838      	ldr	r0, [r7, #0]
20025ab8:	4421      	add	r1, r4
20025aba:	f004 ffc9 	bl	2002aa50 <memcpy>
20025abe:	6838      	ldr	r0, [r7, #0]
20025ac0:	b160      	cbz	r0, 20025adc <bbm_write_talbe.isra.0+0x5c>
20025ac2:	6802      	ldr	r2, [r0, #0]
20025ac4:	4b0a      	ldr	r3, [pc, #40]	@ (20025af0 <bbm_write_talbe.isra.0+0x70>)
20025ac6:	429a      	cmp	r2, r3
20025ac8:	d108      	bne.n	20025adc <bbm_write_talbe.isra.0+0x5c>
20025aca:	f7ff fdbd 	bl	20025648 <bbm_map_check.part.0>
20025ace:	2300      	movs	r3, #0
20025ad0:	9300      	str	r3, [sp, #0]
20025ad2:	4629      	mov	r1, r5
20025ad4:	4630      	mov	r0, r6
20025ad6:	683a      	ldr	r2, [r7, #0]
20025ad8:	f7ff ffcc 	bl	20025a74 <port_write_page>
20025adc:	b003      	add	sp, #12
20025ade:	bdf0      	pop	{r4, r5, r6, r7, pc}
20025ae0:	20044998 	.word	0x20044998
20025ae4:	2004499c 	.word	0x2004499c
20025ae8:	2004cc58 	.word	0x2004cc58
20025aec:	2004cc6c 	.word	0x2004cc6c
20025af0:	5366424d 	.word	0x5366424d

20025af4 <port_erase_block>:
20025af4:	2000      	movs	r0, #0
20025af6:	4770      	bx	lr

20025af8 <bbm_init_table>:
20025af8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025afc:	4c7c      	ldr	r4, [pc, #496]	@ (20025cf0 <bbm_init_table+0x1f8>)
20025afe:	4b7d      	ldr	r3, [pc, #500]	@ (20025cf4 <bbm_init_table+0x1fc>)
20025b00:	6822      	ldr	r2, [r4, #0]
20025b02:	b085      	sub	sp, #20
20025b04:	429a      	cmp	r2, r3
20025b06:	f000 80ed 	beq.w	20025ce4 <bbm_init_table+0x1ec>
20025b0a:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
20025b0e:	429a      	cmp	r2, r3
20025b10:	f000 80e8 	beq.w	20025ce4 <bbm_init_table+0x1ec>
20025b14:	6023      	str	r3, [r4, #0]
20025b16:	2301      	movs	r3, #1
20025b18:	6063      	str	r3, [r4, #4]
20025b1a:	2300      	movs	r3, #0
20025b1c:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 20025d28 <bbm_init_table+0x230>
20025b20:	8123      	strh	r3, [r4, #8]
20025b22:	f8d9 3000 	ldr.w	r3, [r9]
20025b26:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 20025d2c <bbm_init_table+0x234>
20025b2a:	3b04      	subs	r3, #4
20025b2c:	f8df a200 	ldr.w	sl, [pc, #512]	@ 20025d30 <bbm_init_table+0x238>
20025b30:	8163      	strh	r3, [r4, #10]
20025b32:	f8d8 3000 	ldr.w	r3, [r8]
20025b36:	f8da 5000 	ldr.w	r5, [sl]
20025b3a:	3b01      	subs	r3, #1
20025b3c:	4e6e      	ldr	r6, [pc, #440]	@ (20025cf8 <bbm_init_table+0x200>)
20025b3e:	81a3      	strh	r3, [r4, #12]
20025b40:	81e5      	strh	r5, [r4, #14]
20025b42:	f8d8 3000 	ldr.w	r3, [r8]
20025b46:	429d      	cmp	r5, r3
20025b48:	db10      	blt.n	20025b6c <bbm_init_table+0x74>
20025b4a:	2500      	movs	r5, #0
20025b4c:	462f      	mov	r7, r5
20025b4e:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 20025cf8 <bbm_init_table+0x200>
20025b52:	f8da 6000 	ldr.w	r6, [sl]
20025b56:	42b5      	cmp	r5, r6
20025b58:	db1d      	blt.n	20025b96 <bbm_init_table+0x9e>
20025b5a:	8963      	ldrh	r3, [r4, #10]
20025b5c:	2b00      	cmp	r3, #0
20025b5e:	d148      	bne.n	20025bf2 <bbm_init_table+0xfa>
20025b60:	4b65      	ldr	r3, [pc, #404]	@ (20025cf8 <bbm_init_table+0x200>)
20025b62:	681b      	ldr	r3, [r3, #0]
20025b64:	b10b      	cbz	r3, 20025b6a <bbm_init_table+0x72>
20025b66:	4865      	ldr	r0, [pc, #404]	@ (20025cfc <bbm_init_table+0x204>)
20025b68:	4798      	blx	r3
20025b6a:	e7fe      	b.n	20025b6a <bbm_init_table+0x72>
20025b6c:	4628      	mov	r0, r5
20025b6e:	f7fb f83b 	bl	20020be8 <bbm_get_bb>
20025b72:	b950      	cbnz	r0, 20025b8a <bbm_init_table+0x92>
20025b74:	4628      	mov	r0, r5
20025b76:	f7ff ffbd 	bl	20025af4 <port_erase_block>
20025b7a:	b120      	cbz	r0, 20025b86 <bbm_init_table+0x8e>
20025b7c:	6833      	ldr	r3, [r6, #0]
20025b7e:	b113      	cbz	r3, 20025b86 <bbm_init_table+0x8e>
20025b80:	4629      	mov	r1, r5
20025b82:	485f      	ldr	r0, [pc, #380]	@ (20025d00 <bbm_init_table+0x208>)
20025b84:	4798      	blx	r3
20025b86:	3501      	adds	r5, #1
20025b88:	e7db      	b.n	20025b42 <bbm_init_table+0x4a>
20025b8a:	6833      	ldr	r3, [r6, #0]
20025b8c:	2b00      	cmp	r3, #0
20025b8e:	d0fa      	beq.n	20025b86 <bbm_init_table+0x8e>
20025b90:	4629      	mov	r1, r5
20025b92:	485c      	ldr	r0, [pc, #368]	@ (20025d04 <bbm_init_table+0x20c>)
20025b94:	e7f6      	b.n	20025b84 <bbm_init_table+0x8c>
20025b96:	4628      	mov	r0, r5
20025b98:	f7fb f826 	bl	20020be8 <bbm_get_bb>
20025b9c:	b338      	cbz	r0, 20025bee <bbm_init_table+0xf6>
20025b9e:	f8db 3000 	ldr.w	r3, [fp]
20025ba2:	b113      	cbz	r3, 20025baa <bbm_init_table+0xb2>
20025ba4:	4629      	mov	r1, r5
20025ba6:	4858      	ldr	r0, [pc, #352]	@ (20025d08 <bbm_init_table+0x210>)
20025ba8:	4798      	blx	r3
20025baa:	89a0      	ldrh	r0, [r4, #12]
20025bac:	f7fb f81c 	bl	20020be8 <bbm_get_bb>
20025bb0:	89a3      	ldrh	r3, [r4, #12]
20025bb2:	4606      	mov	r6, r0
20025bb4:	3b01      	subs	r3, #1
20025bb6:	81a3      	strh	r3, [r4, #12]
20025bb8:	8963      	ldrh	r3, [r4, #10]
20025bba:	3b01      	subs	r3, #1
20025bbc:	b29b      	uxth	r3, r3
20025bbe:	8163      	strh	r3, [r4, #10]
20025bc0:	b108      	cbz	r0, 20025bc6 <bbm_init_table+0xce>
20025bc2:	2b00      	cmp	r3, #0
20025bc4:	d1f1      	bne.n	20025baa <bbm_init_table+0xb2>
20025bc6:	f8db 3000 	ldr.w	r3, [fp]
20025bca:	b11b      	cbz	r3, 20025bd4 <bbm_init_table+0xdc>
20025bcc:	463a      	mov	r2, r7
20025bce:	4629      	mov	r1, r5
20025bd0:	484e      	ldr	r0, [pc, #312]	@ (20025d0c <bbm_init_table+0x214>)
20025bd2:	4798      	blx	r3
20025bd4:	b93e      	cbnz	r6, 20025be6 <bbm_init_table+0xee>
20025bd6:	89a2      	ldrh	r2, [r4, #12]
20025bd8:	1dbb      	adds	r3, r7, #6
20025bda:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
20025bde:	3201      	adds	r2, #1
20025be0:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20025be4:	805a      	strh	r2, [r3, #2]
20025be6:	8923      	ldrh	r3, [r4, #8]
20025be8:	3701      	adds	r7, #1
20025bea:	3301      	adds	r3, #1
20025bec:	8123      	strh	r3, [r4, #8]
20025bee:	3501      	adds	r5, #1
20025bf0:	e7af      	b.n	20025b52 <bbm_init_table+0x5a>
20025bf2:	2110      	movs	r1, #16
20025bf4:	483e      	ldr	r0, [pc, #248]	@ (20025cf0 <bbm_init_table+0x1f8>)
20025bf6:	f7ff fd77 	bl	200256e8 <bbm_crc_check>
20025bfa:	f8d9 1000 	ldr.w	r1, [r9]
20025bfe:	6120      	str	r0, [r4, #16]
20025c00:	3904      	subs	r1, #4
20025c02:	0089      	lsls	r1, r1, #2
20025c04:	4842      	ldr	r0, [pc, #264]	@ (20025d10 <bbm_init_table+0x218>)
20025c06:	f7ff fd6f 	bl	200256e8 <bbm_crc_check>
20025c0a:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025c0e:	4938      	ldr	r1, [pc, #224]	@ (20025cf0 <bbm_init_table+0x1f8>)
20025c10:	6160      	str	r0, [r4, #20]
20025c12:	1888      	adds	r0, r1, r2
20025c14:	f004 ff1c 	bl	2002aa50 <memcpy>
20025c18:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025c1c:	2110      	movs	r1, #16
20025c1e:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025c22:	483c      	ldr	r0, [pc, #240]	@ (20025d14 <bbm_init_table+0x21c>)
20025c24:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20025c28:	f7ff fd5e 	bl	200256e8 <bbm_crc_check>
20025c2c:	2700      	movs	r7, #0
20025c2e:	f8df a104 	ldr.w	sl, [pc, #260]	@ 20025d34 <bbm_init_table+0x23c>
20025c32:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 20025d38 <bbm_init_table+0x240>
20025c36:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20025c3a:	f8d8 3000 	ldr.w	r3, [r8]
20025c3e:	429e      	cmp	r6, r3
20025c40:	db08      	blt.n	20025c54 <bbm_init_table+0x15c>
20025c42:	2f03      	cmp	r7, #3
20025c44:	dc2f      	bgt.n	20025ca6 <bbm_init_table+0x1ae>
20025c46:	4b2c      	ldr	r3, [pc, #176]	@ (20025cf8 <bbm_init_table+0x200>)
20025c48:	681b      	ldr	r3, [r3, #0]
20025c4a:	b113      	cbz	r3, 20025c52 <bbm_init_table+0x15a>
20025c4c:	4639      	mov	r1, r7
20025c4e:	4832      	ldr	r0, [pc, #200]	@ (20025d18 <bbm_init_table+0x220>)
20025c50:	4798      	blx	r3
20025c52:	e7fe      	b.n	20025c52 <bbm_init_table+0x15a>
20025c54:	4630      	mov	r0, r6
20025c56:	f7fa ffc7 	bl	20020be8 <bbm_get_bb>
20025c5a:	4604      	mov	r4, r0
20025c5c:	bb08      	cbnz	r0, 20025ca2 <bbm_init_table+0x1aa>
20025c5e:	f8da 5000 	ldr.w	r5, [sl]
20025c62:	21ff      	movs	r1, #255	@ 0xff
20025c64:	462a      	mov	r2, r5
20025c66:	f8d9 0000 	ldr.w	r0, [r9]
20025c6a:	f004 fed7 	bl	2002aa1c <memset>
20025c6e:	e9cd 4401 	strd	r4, r4, [sp, #4]
20025c72:	9500      	str	r5, [sp, #0]
20025c74:	f8d9 3000 	ldr.w	r3, [r9]
20025c78:	4622      	mov	r2, r4
20025c7a:	4621      	mov	r1, r4
20025c7c:	4630      	mov	r0, r6
20025c7e:	f7fa ff4f 	bl	20020b20 <port_read_page>
20025c82:	f8da 3000 	ldr.w	r3, [sl]
20025c86:	4298      	cmp	r0, r3
20025c88:	d109      	bne.n	20025c9e <bbm_init_table+0x1a6>
20025c8a:	f8d9 3000 	ldr.w	r3, [r9]
20025c8e:	681b      	ldr	r3, [r3, #0]
20025c90:	3301      	adds	r3, #1
20025c92:	bf01      	itttt	eq
20025c94:	4b21      	ldreq	r3, [pc, #132]	@ (20025d1c <bbm_init_table+0x224>)
20025c96:	1d3a      	addeq	r2, r7, #4
20025c98:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
20025c9c:	3701      	addeq	r7, #1
20025c9e:	2f03      	cmp	r7, #3
20025ca0:	dc01      	bgt.n	20025ca6 <bbm_init_table+0x1ae>
20025ca2:	3601      	adds	r6, #1
20025ca4:	e7c9      	b.n	20025c3a <bbm_init_table+0x142>
20025ca6:	2500      	movs	r5, #0
20025ca8:	4c1c      	ldr	r4, [pc, #112]	@ (20025d1c <bbm_init_table+0x224>)
20025caa:	2000      	movs	r0, #0
20025cac:	8921      	ldrh	r1, [r4, #8]
20025cae:	f7ff fee7 	bl	20025a80 <bbm_write_talbe.isra.0>
20025cb2:	8923      	ldrh	r3, [r4, #8]
20025cb4:	2001      	movs	r0, #1
20025cb6:	8961      	ldrh	r1, [r4, #10]
20025cb8:	8023      	strh	r3, [r4, #0]
20025cba:	8223      	strh	r3, [r4, #16]
20025cbc:	8125      	strh	r5, [r4, #8]
20025cbe:	f7ff fedf 	bl	20025a80 <bbm_write_talbe.isra.0>
20025cc2:	8963      	ldrh	r3, [r4, #10]
20025cc4:	8165      	strh	r5, [r4, #10]
20025cc6:	80a3      	strh	r3, [r4, #4]
20025cc8:	8263      	strh	r3, [r4, #18]
20025cca:	89a3      	ldrh	r3, [r4, #12]
20025ccc:	8063      	strh	r3, [r4, #2]
20025cce:	89e3      	ldrh	r3, [r4, #14]
20025cd0:	80e3      	strh	r3, [r4, #6]
20025cd2:	4b09      	ldr	r3, [pc, #36]	@ (20025cf8 <bbm_init_table+0x200>)
20025cd4:	681b      	ldr	r3, [r3, #0]
20025cd6:	b10b      	cbz	r3, 20025cdc <bbm_init_table+0x1e4>
20025cd8:	4811      	ldr	r0, [pc, #68]	@ (20025d20 <bbm_init_table+0x228>)
20025cda:	4798      	blx	r3
20025cdc:	2000      	movs	r0, #0
20025cde:	b005      	add	sp, #20
20025ce0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025ce4:	4b04      	ldr	r3, [pc, #16]	@ (20025cf8 <bbm_init_table+0x200>)
20025ce6:	681b      	ldr	r3, [r3, #0]
20025ce8:	b10b      	cbz	r3, 20025cee <bbm_init_table+0x1f6>
20025cea:	480e      	ldr	r0, [pc, #56]	@ (20025d24 <bbm_init_table+0x22c>)
20025cec:	4798      	blx	r3
20025cee:	e7fe      	b.n	20025cee <bbm_init_table+0x1f6>
20025cf0:	2004cc6c 	.word	0x2004cc6c
20025cf4:	5366424d 	.word	0x5366424d
20025cf8:	2004cc54 	.word	0x2004cc54
20025cfc:	2002aea6 	.word	0x2002aea6
20025d00:	2002ae34 	.word	0x2002ae34
20025d04:	2002ae56 	.word	0x2002ae56
20025d08:	2002ae73 	.word	0x2002ae73
20025d0c:	2002ae92 	.word	0x2002ae92
20025d10:	2004cc84 	.word	0x2004cc84
20025d14:	2004ce74 	.word	0x2004ce74
20025d18:	2002aec0 	.word	0x2002aec0
20025d1c:	2004d07c 	.word	0x2004d07c
20025d20:	2002aee7 	.word	0x2002aee7
20025d24:	2002af03 	.word	0x2002af03
20025d28:	2004cc64 	.word	0x2004cc64
20025d2c:	2004cc60 	.word	0x2004cc60
20025d30:	2004cc68 	.word	0x2004cc68
20025d34:	20044998 	.word	0x20044998
20025d38:	2004cc58 	.word	0x2004cc58

20025d3c <sif_bbm_init>:
20025d3c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025d40:	b087      	sub	sp, #28
20025d42:	2900      	cmp	r1, #0
20025d44:	f000 8129 	beq.w	20025f9a <sif_bbm_init+0x25e>
20025d48:	4b95      	ldr	r3, [pc, #596]	@ (20025fa0 <sif_bbm_init+0x264>)
20025d4a:	681a      	ldr	r2, [r3, #0]
20025d4c:	2a01      	cmp	r2, #1
20025d4e:	d108      	bne.n	20025d62 <sif_bbm_init+0x26>
20025d50:	4b94      	ldr	r3, [pc, #592]	@ (20025fa4 <sif_bbm_init+0x268>)
20025d52:	681b      	ldr	r3, [r3, #0]
20025d54:	b10b      	cbz	r3, 20025d5a <sif_bbm_init+0x1e>
20025d56:	4894      	ldr	r0, [pc, #592]	@ (20025fa8 <sif_bbm_init+0x26c>)
20025d58:	4798      	blx	r3
20025d5a:	2000      	movs	r0, #0
20025d5c:	b007      	add	sp, #28
20025d5e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025d62:	2201      	movs	r2, #1
20025d64:	601a      	str	r2, [r3, #0]
20025d66:	4b91      	ldr	r3, [pc, #580]	@ (20025fac <sif_bbm_init+0x270>)
20025d68:	681c      	ldr	r4, [r3, #0]
20025d6a:	b904      	cbnz	r4, 20025d6e <sif_bbm_init+0x32>
20025d6c:	e7fe      	b.n	20025d6c <sif_bbm_init+0x30>
20025d6e:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 20025fec <sif_bbm_init+0x2b0>
20025d72:	f8da 2000 	ldr.w	r2, [sl]
20025d76:	b902      	cbnz	r2, 20025d7a <sif_bbm_init+0x3e>
20025d78:	e7fe      	b.n	20025d78 <sif_bbm_init+0x3c>
20025d7a:	fbb0 f4f4 	udiv	r4, r0, r4
20025d7e:	f04f 0800 	mov.w	r8, #0
20025d82:	4a8b      	ldr	r2, [pc, #556]	@ (20025fb0 <sif_bbm_init+0x274>)
20025d84:	f8df b268 	ldr.w	fp, [pc, #616]	@ 20025ff0 <sif_bbm_init+0x2b4>
20025d88:	0963      	lsrs	r3, r4, #5
20025d8a:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20025ff4 <sif_bbm_init+0x2b8>
20025d8e:	6013      	str	r3, [r2, #0]
20025d90:	f8cb 4000 	str.w	r4, [fp]
20025d94:	1ae4      	subs	r4, r4, r3
20025d96:	4b87      	ldr	r3, [pc, #540]	@ (20025fb4 <sif_bbm_init+0x278>)
20025d98:	2218      	movs	r2, #24
20025d9a:	f8c9 1000 	str.w	r1, [r9]
20025d9e:	4886      	ldr	r0, [pc, #536]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025da0:	2100      	movs	r1, #0
20025da2:	601c      	str	r4, [r3, #0]
20025da4:	f004 fe3a 	bl	2002aa1c <memset>
20025da8:	f44f 6282 	mov.w	r2, #1040	@ 0x410
20025dac:	2100      	movs	r1, #0
20025dae:	4883      	ldr	r0, [pc, #524]	@ (20025fbc <sif_bbm_init+0x280>)
20025db0:	f004 fe34 	bl	2002aa1c <memset>
20025db4:	4647      	mov	r7, r8
20025db6:	4646      	mov	r6, r8
20025db8:	f8db 3000 	ldr.w	r3, [fp]
20025dbc:	429c      	cmp	r4, r3
20025dbe:	db02      	blt.n	20025dc6 <sif_bbm_init+0x8a>
20025dc0:	f04f 35ff 	mov.w	r5, #4294967295
20025dc4:	e064      	b.n	20025e90 <sif_bbm_init+0x154>
20025dc6:	4620      	mov	r0, r4
20025dc8:	f7fa ff0e 	bl	20020be8 <bbm_get_bb>
20025dcc:	4605      	mov	r5, r0
20025dce:	b138      	cbz	r0, 20025de0 <sif_bbm_init+0xa4>
20025dd0:	4b74      	ldr	r3, [pc, #464]	@ (20025fa4 <sif_bbm_init+0x268>)
20025dd2:	681b      	ldr	r3, [r3, #0]
20025dd4:	b113      	cbz	r3, 20025ddc <sif_bbm_init+0xa0>
20025dd6:	4621      	mov	r1, r4
20025dd8:	4879      	ldr	r0, [pc, #484]	@ (20025fc0 <sif_bbm_init+0x284>)
20025dda:	4798      	blx	r3
20025ddc:	3401      	adds	r4, #1
20025dde:	e7eb      	b.n	20025db8 <sif_bbm_init+0x7c>
20025de0:	f8da 2000 	ldr.w	r2, [sl]
20025de4:	21ff      	movs	r1, #255	@ 0xff
20025de6:	f8d9 0000 	ldr.w	r0, [r9]
20025dea:	9205      	str	r2, [sp, #20]
20025dec:	f004 fe16 	bl	2002aa1c <memset>
20025df0:	9a05      	ldr	r2, [sp, #20]
20025df2:	e9cd 5501 	strd	r5, r5, [sp, #4]
20025df6:	9200      	str	r2, [sp, #0]
20025df8:	f8d9 3000 	ldr.w	r3, [r9]
20025dfc:	462a      	mov	r2, r5
20025dfe:	4629      	mov	r1, r5
20025e00:	4620      	mov	r0, r4
20025e02:	f7fa fe8d 	bl	20020b20 <port_read_page>
20025e06:	f8da 3000 	ldr.w	r3, [sl]
20025e0a:	4298      	cmp	r0, r3
20025e0c:	d12e      	bne.n	20025e6c <sif_bbm_init+0x130>
20025e0e:	f8d9 1000 	ldr.w	r1, [r9]
20025e12:	486c      	ldr	r0, [pc, #432]	@ (20025fc4 <sif_bbm_init+0x288>)
20025e14:	680b      	ldr	r3, [r1, #0]
20025e16:	b2a2      	uxth	r2, r4
20025e18:	4283      	cmp	r3, r0
20025e1a:	4b67      	ldr	r3, [pc, #412]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025e1c:	d11f      	bne.n	20025e5e <sif_bbm_init+0x122>
20025e1e:	f991 1007 	ldrsb.w	r1, [r1, #7]
20025e22:	2900      	cmp	r1, #0
20025e24:	bfb5      	itete	lt
20025e26:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
20025e2a:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
20025e2e:	808a      	strhlt	r2, [r1, #4]
20025e30:	3601      	addge	r6, #1
20025e32:	bfb8      	it	lt
20025e34:	3701      	addlt	r7, #1
20025e36:	eb06 0208 	add.w	r2, r6, r8
20025e3a:	443a      	add	r2, r7
20025e3c:	2a03      	cmp	r2, #3
20025e3e:	ddcd      	ble.n	20025ddc <sif_bbm_init+0xa0>
20025e40:	2e00      	cmp	r6, #0
20025e42:	f000 8081 	beq.w	20025f48 <sif_bbm_init+0x20c>
20025e46:	2f00      	cmp	r7, #0
20025e48:	d07e      	beq.n	20025f48 <sif_bbm_init+0x20c>
20025e4a:	2e01      	cmp	r6, #1
20025e4c:	d001      	beq.n	20025e52 <sif_bbm_init+0x116>
20025e4e:	2f01      	cmp	r7, #1
20025e50:	d11e      	bne.n	20025e90 <sif_bbm_init+0x154>
20025e52:	8819      	ldrh	r1, [r3, #0]
20025e54:	891a      	ldrh	r2, [r3, #8]
20025e56:	b981      	cbnz	r1, 20025e7a <sif_bbm_init+0x13e>
20025e58:	801a      	strh	r2, [r3, #0]
20025e5a:	895a      	ldrh	r2, [r3, #10]
20025e5c:	e013      	b.n	20025e86 <sif_bbm_init+0x14a>
20025e5e:	f108 0104 	add.w	r1, r8, #4
20025e62:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
20025e66:	f108 0801 	add.w	r8, r8, #1
20025e6a:	e7e4      	b.n	20025e36 <sif_bbm_init+0xfa>
20025e6c:	4b4d      	ldr	r3, [pc, #308]	@ (20025fa4 <sif_bbm_init+0x268>)
20025e6e:	681b      	ldr	r3, [r3, #0]
20025e70:	2b00      	cmp	r3, #0
20025e72:	d0b3      	beq.n	20025ddc <sif_bbm_init+0xa0>
20025e74:	4854      	ldr	r0, [pc, #336]	@ (20025fc8 <sif_bbm_init+0x28c>)
20025e76:	1c61      	adds	r1, r4, #1
20025e78:	e7af      	b.n	20025dda <sif_bbm_init+0x9e>
20025e7a:	8859      	ldrh	r1, [r3, #2]
20025e7c:	b909      	cbnz	r1, 20025e82 <sif_bbm_init+0x146>
20025e7e:	805a      	strh	r2, [r3, #2]
20025e80:	e7eb      	b.n	20025e5a <sif_bbm_init+0x11e>
20025e82:	2a00      	cmp	r2, #0
20025e84:	d0e9      	beq.n	20025e5a <sif_bbm_init+0x11e>
20025e86:	8899      	ldrh	r1, [r3, #4]
20025e88:	2900      	cmp	r1, #0
20025e8a:	d158      	bne.n	20025f3e <sif_bbm_init+0x202>
20025e8c:	809a      	strh	r2, [r3, #4]
20025e8e:	2502      	movs	r5, #2
20025e90:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 20025fa4 <sif_bbm_init+0x268>
20025e94:	f8d9 4000 	ldr.w	r4, [r9]
20025e98:	b124      	cbz	r4, 20025ea4 <sif_bbm_init+0x168>
20025e9a:	4643      	mov	r3, r8
20025e9c:	463a      	mov	r2, r7
20025e9e:	4631      	mov	r1, r6
20025ea0:	484a      	ldr	r0, [pc, #296]	@ (20025fcc <sif_bbm_init+0x290>)
20025ea2:	47a0      	blx	r4
20025ea4:	f8d9 3000 	ldr.w	r3, [r9]
20025ea8:	b113      	cbz	r3, 20025eb0 <sif_bbm_init+0x174>
20025eaa:	4629      	mov	r1, r5
20025eac:	4848      	ldr	r0, [pc, #288]	@ (20025fd0 <sif_bbm_init+0x294>)
20025eae:	4798      	blx	r3
20025eb0:	f035 0002 	bics.w	r0, r5, #2
20025eb4:	d164      	bne.n	20025f80 <sif_bbm_init+0x244>
20025eb6:	f7ff fccb 	bl	20025850 <bbm_get_map_table>
20025eba:	4605      	mov	r5, r0
20025ebc:	2001      	movs	r0, #1
20025ebe:	f7ff fcc7 	bl	20025850 <bbm_get_map_table>
20025ec2:	f8d9 6000 	ldr.w	r6, [r9]
20025ec6:	4604      	mov	r4, r0
20025ec8:	b13e      	cbz	r6, 20025eda <sif_bbm_init+0x19e>
20025eca:	4a3b      	ldr	r2, [pc, #236]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025ecc:	4629      	mov	r1, r5
20025ece:	8a53      	ldrh	r3, [r2, #18]
20025ed0:	9300      	str	r3, [sp, #0]
20025ed2:	8a12      	ldrh	r2, [r2, #16]
20025ed4:	4603      	mov	r3, r0
20025ed6:	483f      	ldr	r0, [pc, #252]	@ (20025fd4 <sif_bbm_init+0x298>)
20025ed8:	47b0      	blx	r6
20025eda:	42a5      	cmp	r5, r4
20025edc:	4c37      	ldr	r4, [pc, #220]	@ (20025fbc <sif_bbm_init+0x280>)
20025ede:	dd35      	ble.n	20025f4c <sif_bbm_init+0x210>
20025ee0:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025ee4:	4621      	mov	r1, r4
20025ee6:	18a0      	adds	r0, r4, r2
20025ee8:	f004 fdb2 	bl	2002aa50 <memcpy>
20025eec:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025ef0:	2110      	movs	r1, #16
20025ef2:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025ef6:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20025efa:	f504 7002 	add.w	r0, r4, #520	@ 0x208
20025efe:	f7ff fbf3 	bl	200256e8 <bbm_crc_check>
20025f02:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20025f06:	2001      	movs	r0, #1
20025f08:	4b2b      	ldr	r3, [pc, #172]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025f0a:	8a59      	ldrh	r1, [r3, #18]
20025f0c:	f7ff fdb8 	bl	20025a80 <bbm_write_talbe.isra.0>
20025f10:	6822      	ldr	r2, [r4, #0]
20025f12:	4b2c      	ldr	r3, [pc, #176]	@ (20025fc4 <sif_bbm_init+0x288>)
20025f14:	429a      	cmp	r2, r3
20025f16:	d12d      	bne.n	20025f74 <sif_bbm_init+0x238>
20025f18:	4828      	ldr	r0, [pc, #160]	@ (20025fbc <sif_bbm_init+0x280>)
20025f1a:	f7ff fb95 	bl	20025648 <bbm_map_check.part.0>
20025f1e:	f8d9 4000 	ldr.w	r4, [r9]
20025f22:	b12c      	cbz	r4, 20025f30 <sif_bbm_init+0x1f4>
20025f24:	4b2c      	ldr	r3, [pc, #176]	@ (20025fd8 <sif_bbm_init+0x29c>)
20025f26:	4924      	ldr	r1, [pc, #144]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025f28:	482c      	ldr	r0, [pc, #176]	@ (20025fdc <sif_bbm_init+0x2a0>)
20025f2a:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
20025f2e:	47a0      	blx	r4
20025f30:	f8d9 3000 	ldr.w	r3, [r9]
20025f34:	2b00      	cmp	r3, #0
20025f36:	f43f af10 	beq.w	20025d5a <sif_bbm_init+0x1e>
20025f3a:	4829      	ldr	r0, [pc, #164]	@ (20025fe0 <sif_bbm_init+0x2a4>)
20025f3c:	e70c      	b.n	20025d58 <sif_bbm_init+0x1c>
20025f3e:	88d9      	ldrh	r1, [r3, #6]
20025f40:	2900      	cmp	r1, #0
20025f42:	d1a4      	bne.n	20025e8e <sif_bbm_init+0x152>
20025f44:	80da      	strh	r2, [r3, #6]
20025f46:	e7a2      	b.n	20025e8e <sif_bbm_init+0x152>
20025f48:	2501      	movs	r5, #1
20025f4a:	e7a1      	b.n	20025e90 <sif_bbm_init+0x154>
20025f4c:	dae0      	bge.n	20025f10 <sif_bbm_init+0x1d4>
20025f4e:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025f52:	4620      	mov	r0, r4
20025f54:	18a1      	adds	r1, r4, r2
20025f56:	f004 fd7b 	bl	2002aa50 <memcpy>
20025f5a:	79e3      	ldrb	r3, [r4, #7]
20025f5c:	2110      	movs	r1, #16
20025f5e:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
20025f62:	71e3      	strb	r3, [r4, #7]
20025f64:	4620      	mov	r0, r4
20025f66:	f7ff fbbf 	bl	200256e8 <bbm_crc_check>
20025f6a:	4b13      	ldr	r3, [pc, #76]	@ (20025fb8 <sif_bbm_init+0x27c>)
20025f6c:	6120      	str	r0, [r4, #16]
20025f6e:	8a19      	ldrh	r1, [r3, #16]
20025f70:	2000      	movs	r0, #0
20025f72:	e7cb      	b.n	20025f0c <sif_bbm_init+0x1d0>
20025f74:	f8d9 3000 	ldr.w	r3, [r9]
20025f78:	b10b      	cbz	r3, 20025f7e <sif_bbm_init+0x242>
20025f7a:	481a      	ldr	r0, [pc, #104]	@ (20025fe4 <sif_bbm_init+0x2a8>)
20025f7c:	4798      	blx	r3
20025f7e:	e7fe      	b.n	20025f7e <sif_bbm_init+0x242>
20025f80:	2d01      	cmp	r5, #1
20025f82:	d102      	bne.n	20025f8a <sif_bbm_init+0x24e>
20025f84:	f7ff fdb8 	bl	20025af8 <bbm_init_table>
20025f88:	e7c9      	b.n	20025f1e <sif_bbm_init+0x1e2>
20025f8a:	f8d9 3000 	ldr.w	r3, [r9]
20025f8e:	b11b      	cbz	r3, 20025f98 <sif_bbm_init+0x25c>
20025f90:	f04f 31ff 	mov.w	r1, #4294967295
20025f94:	4814      	ldr	r0, [pc, #80]	@ (20025fe8 <sif_bbm_init+0x2ac>)
20025f96:	4798      	blx	r3
20025f98:	e7fe      	b.n	20025f98 <sif_bbm_init+0x25c>
20025f9a:	f04f 30ff 	mov.w	r0, #4294967295
20025f9e:	e6dd      	b.n	20025d5c <sif_bbm_init+0x20>
20025fa0:	2004cc5c 	.word	0x2004cc5c
20025fa4:	2004cc54 	.word	0x2004cc54
20025fa8:	2002af17 	.word	0x2002af17
20025fac:	2004499c 	.word	0x2004499c
20025fb0:	2004cc64 	.word	0x2004cc64
20025fb4:	2004cc68 	.word	0x2004cc68
20025fb8:	2004d07c 	.word	0x2004d07c
20025fbc:	2004cc6c 	.word	0x2004cc6c
20025fc0:	2002af45 	.word	0x2002af45
20025fc4:	5366424d 	.word	0x5366424d
20025fc8:	2002af51 	.word	0x2002af51
20025fcc:	2002af70 	.word	0x2002af70
20025fd0:	2002af8f 	.word	0x2002af8f
20025fd4:	2002afa1 	.word	0x2002afa1
20025fd8:	2004ce74 	.word	0x2004ce74
20025fdc:	2002affc 	.word	0x2002affc
20025fe0:	2002b020 	.word	0x2002b020
20025fe4:	2002afc5 	.word	0x2002afc5
20025fe8:	2002afdb 	.word	0x2002afdb
20025fec:	20044998 	.word	0x20044998
20025ff0:	2004cc60 	.word	0x2004cc60
20025ff4:	2004cc58 	.word	0x2004cc58

20025ff8 <bbm_set_page_size>:
20025ff8:	4b01      	ldr	r3, [pc, #4]	@ (20026000 <bbm_set_page_size+0x8>)
20025ffa:	6018      	str	r0, [r3, #0]
20025ffc:	4770      	bx	lr
20025ffe:	bf00      	nop
20026000:	20044998 	.word	0x20044998

20026004 <bbm_set_blk_size>:
20026004:	4b01      	ldr	r3, [pc, #4]	@ (2002600c <bbm_set_blk_size+0x8>)
20026006:	6018      	str	r0, [r3, #0]
20026008:	4770      	bx	lr
2002600a:	bf00      	nop
2002600c:	2004499c 	.word	0x2004499c

20026010 <mbedtls_md_info_from_type>:
20026010:	3805      	subs	r0, #5
20026012:	b2c0      	uxtb	r0, r0
20026014:	2803      	cmp	r0, #3
20026016:	bf9a      	itte	ls
20026018:	4b02      	ldrls	r3, [pc, #8]	@ (20026024 <mbedtls_md_info_from_type+0x14>)
2002601a:	f853 0020 	ldrls.w	r0, [r3, r0, lsl #2]
2002601e:	2000      	movhi	r0, #0
20026020:	4770      	bx	lr
20026022:	bf00      	nop
20026024:	2002be74 	.word	0x2002be74

20026028 <mbedtls_md_get_size>:
20026028:	b100      	cbz	r0, 2002602c <mbedtls_md_get_size+0x4>
2002602a:	7a00      	ldrb	r0, [r0, #8]
2002602c:	4770      	bx	lr

2002602e <sha224_process_wrap>:
2002602e:	f000 b8a9 	b.w	20026184 <mbedtls_sha256_process>

20026032 <sha224_clone_wrap>:
20026032:	f000 b85a 	b.w	200260ea <mbedtls_sha256_clone>

20026036 <sha224_ctx_free>:
20026036:	b510      	push	{r4, lr}
20026038:	4604      	mov	r4, r0
2002603a:	f000 f84c 	bl	200260d6 <mbedtls_sha256_free>
2002603e:	4620      	mov	r0, r4
20026040:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20026044:	f004 bc24 	b.w	2002a890 <free>

20026048 <sha224_ctx_alloc>:
20026048:	b510      	push	{r4, lr}
2002604a:	216c      	movs	r1, #108	@ 0x6c
2002604c:	2001      	movs	r0, #1
2002604e:	f004 fc03 	bl	2002a858 <calloc>
20026052:	4604      	mov	r4, r0
20026054:	b108      	cbz	r0, 2002605a <sha224_ctx_alloc+0x12>
20026056:	f000 f83a 	bl	200260ce <mbedtls_sha256_init>
2002605a:	4620      	mov	r0, r4
2002605c:	bd10      	pop	{r4, pc}

2002605e <sha224_wrap>:
2002605e:	2301      	movs	r3, #1
20026060:	f000 bc94 	b.w	2002698c <mbedtls_sha256>

20026064 <sha256_wrap>:
20026064:	2300      	movs	r3, #0
20026066:	f000 bc91 	b.w	2002698c <mbedtls_sha256>

2002606a <sha224_finish_wrap>:
2002606a:	f000 bc21 	b.w	200268b0 <mbedtls_sha256_finish>

2002606e <sha224_update_wrap>:
2002606e:	f000 bc1b 	b.w	200268a8 <mbedtls_sha256_update>

20026072 <sha224_starts_wrap>:
20026072:	2101      	movs	r1, #1
20026074:	f000 b83e 	b.w	200260f4 <mbedtls_sha256_starts>

20026078 <sha256_starts_wrap>:
20026078:	2100      	movs	r1, #0
2002607a:	f000 b83b 	b.w	200260f4 <mbedtls_sha256_starts>

2002607e <sha384_process_wrap>:
2002607e:	f000 bd8f 	b.w	20026ba0 <mbedtls_sha512_process>

20026082 <sha384_clone_wrap>:
20026082:	f000 bcf5 	b.w	20026a70 <mbedtls_sha512_clone>

20026086 <sha384_ctx_free>:
20026086:	b510      	push	{r4, lr}
20026088:	4604      	mov	r4, r0
2002608a:	f000 fce7 	bl	20026a5c <mbedtls_sha512_free>
2002608e:	4620      	mov	r0, r4
20026090:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20026094:	f004 bbfc 	b.w	2002a890 <free>

20026098 <sha384_ctx_alloc>:
20026098:	b510      	push	{r4, lr}
2002609a:	21d8      	movs	r1, #216	@ 0xd8
2002609c:	2001      	movs	r0, #1
2002609e:	f004 fbdb 	bl	2002a858 <calloc>
200260a2:	4604      	mov	r4, r0
200260a4:	b108      	cbz	r0, 200260aa <sha384_ctx_alloc+0x12>
200260a6:	f000 fcd5 	bl	20026a54 <mbedtls_sha512_init>
200260aa:	4620      	mov	r0, r4
200260ac:	bd10      	pop	{r4, pc}

200260ae <sha384_wrap>:
200260ae:	2301      	movs	r3, #1
200260b0:	f001 bbfa 	b.w	200278a8 <mbedtls_sha512>

200260b4 <sha512_wrap>:
200260b4:	2300      	movs	r3, #0
200260b6:	f001 bbf7 	b.w	200278a8 <mbedtls_sha512>

200260ba <sha384_finish_wrap>:
200260ba:	f001 baef 	b.w	2002769c <mbedtls_sha512_finish>

200260be <sha384_update_wrap>:
200260be:	f001 bae8 	b.w	20027692 <mbedtls_sha512_update>

200260c2 <sha384_starts_wrap>:
200260c2:	2101      	movs	r1, #1
200260c4:	f000 bcdc 	b.w	20026a80 <mbedtls_sha512_starts>

200260c8 <sha512_starts_wrap>:
200260c8:	2100      	movs	r1, #0
200260ca:	f000 bcd9 	b.w	20026a80 <mbedtls_sha512_starts>

200260ce <mbedtls_sha256_init>:
200260ce:	226c      	movs	r2, #108	@ 0x6c
200260d0:	2100      	movs	r1, #0
200260d2:	f004 bca3 	b.w	2002aa1c <memset>

200260d6 <mbedtls_sha256_free>:
200260d6:	b138      	cbz	r0, 200260e8 <mbedtls_sha256_free+0x12>
200260d8:	2100      	movs	r1, #0
200260da:	f100 036c 	add.w	r3, r0, #108	@ 0x6c
200260de:	4602      	mov	r2, r0
200260e0:	3001      	adds	r0, #1
200260e2:	4298      	cmp	r0, r3
200260e4:	7011      	strb	r1, [r2, #0]
200260e6:	d1fa      	bne.n	200260de <mbedtls_sha256_free+0x8>
200260e8:	4770      	bx	lr

200260ea <mbedtls_sha256_clone>:
200260ea:	b508      	push	{r3, lr}
200260ec:	226c      	movs	r2, #108	@ 0x6c
200260ee:	f004 fcaf 	bl	2002aa50 <memcpy>
200260f2:	bd08      	pop	{r3, pc}

200260f4 <mbedtls_sha256_starts>:
200260f4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200260f8:	b1c1      	cbz	r1, 2002612c <mbedtls_sha256_starts+0x38>
200260fa:	f8df e078 	ldr.w	lr, [pc, #120]	@ 20026174 <mbedtls_sha256_starts+0x80>
200260fe:	f8df c078 	ldr.w	ip, [pc, #120]	@ 20026178 <mbedtls_sha256_starts+0x84>
20026102:	4f10      	ldr	r7, [pc, #64]	@ (20026144 <mbedtls_sha256_starts+0x50>)
20026104:	4e10      	ldr	r6, [pc, #64]	@ (20026148 <mbedtls_sha256_starts+0x54>)
20026106:	4d11      	ldr	r5, [pc, #68]	@ (2002614c <mbedtls_sha256_starts+0x58>)
20026108:	4c11      	ldr	r4, [pc, #68]	@ (20026150 <mbedtls_sha256_starts+0x5c>)
2002610a:	4a12      	ldr	r2, [pc, #72]	@ (20026154 <mbedtls_sha256_starts+0x60>)
2002610c:	4b12      	ldr	r3, [pc, #72]	@ (20026158 <mbedtls_sha256_starts+0x64>)
2002610e:	f04f 0800 	mov.w	r8, #0
20026112:	e9c0 ec02 	strd	lr, ip, [r0, #8]
20026116:	e9c0 8800 	strd	r8, r8, [r0]
2002611a:	e9c0 7604 	strd	r7, r6, [r0, #16]
2002611e:	e9c0 5406 	strd	r5, r4, [r0, #24]
20026122:	e9c0 2308 	strd	r2, r3, [r0, #32]
20026126:	6681      	str	r1, [r0, #104]	@ 0x68
20026128:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002612c:	f8df e04c 	ldr.w	lr, [pc, #76]	@ 2002617c <mbedtls_sha256_starts+0x88>
20026130:	f8df c04c 	ldr.w	ip, [pc, #76]	@ 20026180 <mbedtls_sha256_starts+0x8c>
20026134:	4f09      	ldr	r7, [pc, #36]	@ (2002615c <mbedtls_sha256_starts+0x68>)
20026136:	4e0a      	ldr	r6, [pc, #40]	@ (20026160 <mbedtls_sha256_starts+0x6c>)
20026138:	4d0a      	ldr	r5, [pc, #40]	@ (20026164 <mbedtls_sha256_starts+0x70>)
2002613a:	4c0b      	ldr	r4, [pc, #44]	@ (20026168 <mbedtls_sha256_starts+0x74>)
2002613c:	4a0b      	ldr	r2, [pc, #44]	@ (2002616c <mbedtls_sha256_starts+0x78>)
2002613e:	4b0c      	ldr	r3, [pc, #48]	@ (20026170 <mbedtls_sha256_starts+0x7c>)
20026140:	e7e5      	b.n	2002610e <mbedtls_sha256_starts+0x1a>
20026142:	bf00      	nop
20026144:	3070dd17 	.word	0x3070dd17
20026148:	f70e5939 	.word	0xf70e5939
2002614c:	ffc00b31 	.word	0xffc00b31
20026150:	68581511 	.word	0x68581511
20026154:	64f98fa7 	.word	0x64f98fa7
20026158:	befa4fa4 	.word	0xbefa4fa4
2002615c:	3c6ef372 	.word	0x3c6ef372
20026160:	a54ff53a 	.word	0xa54ff53a
20026164:	510e527f 	.word	0x510e527f
20026168:	9b05688c 	.word	0x9b05688c
2002616c:	1f83d9ab 	.word	0x1f83d9ab
20026170:	5be0cd19 	.word	0x5be0cd19
20026174:	c1059ed8 	.word	0xc1059ed8
20026178:	367cd507 	.word	0x367cd507
2002617c:	6a09e667 	.word	0x6a09e667
20026180:	bb67ae85 	.word	0xbb67ae85

20026184 <mbedtls_sha256_process>:
20026184:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20026188:	b0cf      	sub	sp, #316	@ 0x13c
2002618a:	aa06      	add	r2, sp, #24
2002618c:	460b      	mov	r3, r1
2002618e:	4616      	mov	r6, r2
20026190:	9004      	str	r0, [sp, #16]
20026192:	f100 0408 	add.w	r4, r0, #8
20026196:	f100 0728 	add.w	r7, r0, #40	@ 0x28
2002619a:	4635      	mov	r5, r6
2002619c:	6820      	ldr	r0, [r4, #0]
2002619e:	6861      	ldr	r1, [r4, #4]
200261a0:	3408      	adds	r4, #8
200261a2:	c503      	stmia	r5!, {r0, r1}
200261a4:	42bc      	cmp	r4, r7
200261a6:	462e      	mov	r6, r5
200261a8:	d1f7      	bne.n	2002619a <mbedtls_sha256_process+0x16>
200261aa:	f10d 0a38 	add.w	sl, sp, #56	@ 0x38
200261ae:	4619      	mov	r1, r3
200261b0:	4650      	mov	r0, sl
200261b2:	f103 0440 	add.w	r4, r3, #64	@ 0x40
200261b6:	784b      	ldrb	r3, [r1, #1]
200261b8:	780d      	ldrb	r5, [r1, #0]
200261ba:	041b      	lsls	r3, r3, #16
200261bc:	ea43 6305 	orr.w	r3, r3, r5, lsl #24
200261c0:	78cd      	ldrb	r5, [r1, #3]
200261c2:	3104      	adds	r1, #4
200261c4:	432b      	orrs	r3, r5
200261c6:	f811 5c02 	ldrb.w	r5, [r1, #-2]
200261ca:	428c      	cmp	r4, r1
200261cc:	ea43 2305 	orr.w	r3, r3, r5, lsl #8
200261d0:	f840 3b04 	str.w	r3, [r0], #4
200261d4:	d1ef      	bne.n	200261b6 <mbedtls_sha256_process+0x32>
200261d6:	4996      	ldr	r1, [pc, #600]	@ (20026430 <mbedtls_sha256_process+0x2ac>)
200261d8:	46d4      	mov	ip, sl
200261da:	e9d2 e705 	ldrd	lr, r7, [r2, #20]
200261de:	e9d2 9600 	ldrd	r9, r6, [r2]
200261e2:	460d      	mov	r5, r1
200261e4:	9100      	str	r1, [sp, #0]
200261e6:	f8d2 801c 	ldr.w	r8, [r2, #28]
200261ea:	f8d2 b010 	ldr.w	fp, [r2, #16]
200261ee:	e9d2 3202 	ldrd	r3, r2, [r2, #8]
200261f2:	6829      	ldr	r1, [r5, #0]
200261f4:	f8dc 0000 	ldr.w	r0, [ip]
200261f8:	ea4f 24fb 	mov.w	r4, fp, ror #11
200261fc:	ea84 14bb 	eor.w	r4, r4, fp, ror #6
20026200:	4401      	add	r1, r0
20026202:	ea87 000e 	eor.w	r0, r7, lr
20026206:	ea84 647b 	eor.w	r4, r4, fp, ror #25
2002620a:	ea00 000b 	and.w	r0, r0, fp
2002620e:	4078      	eors	r0, r7
20026210:	4421      	add	r1, r4
20026212:	4401      	add	r1, r0
20026214:	4441      	add	r1, r8
20026216:	ea4f 3879 	mov.w	r8, r9, ror #13
2002621a:	ea88 08b9 	eor.w	r8, r8, r9, ror #2
2002621e:	ea88 58b9 	eor.w	r8, r8, r9, ror #22
20026222:	440a      	add	r2, r1
20026224:	4488      	add	r8, r1
20026226:	ea49 0106 	orr.w	r1, r9, r6
2002622a:	ea09 0006 	and.w	r0, r9, r6
2002622e:	4019      	ands	r1, r3
20026230:	4301      	orrs	r1, r0
20026232:	4488      	add	r8, r1
20026234:	f8dc 0004 	ldr.w	r0, [ip, #4]
20026238:	6869      	ldr	r1, [r5, #4]
2002623a:	ea4f 3478 	mov.w	r4, r8, ror #13
2002623e:	4401      	add	r1, r0
20026240:	ea8b 000e 	eor.w	r0, fp, lr
20026244:	4010      	ands	r0, r2
20026246:	ea80 000e 	eor.w	r0, r0, lr
2002624a:	4439      	add	r1, r7
2002624c:	4401      	add	r1, r0
2002624e:	ea4f 20f2 	mov.w	r0, r2, ror #11
20026252:	ea80 10b2 	eor.w	r0, r0, r2, ror #6
20026256:	ea80 6072 	eor.w	r0, r0, r2, ror #25
2002625a:	ea84 04b8 	eor.w	r4, r4, r8, ror #2
2002625e:	4401      	add	r1, r0
20026260:	ea84 54b8 	eor.w	r4, r4, r8, ror #22
20026264:	440b      	add	r3, r1
20026266:	440c      	add	r4, r1
20026268:	ea48 0109 	orr.w	r1, r8, r9
2002626c:	ea08 0009 	and.w	r0, r8, r9
20026270:	4031      	ands	r1, r6
20026272:	4301      	orrs	r1, r0
20026274:	440c      	add	r4, r1
20026276:	f8dc 0008 	ldr.w	r0, [ip, #8]
2002627a:	68a9      	ldr	r1, [r5, #8]
2002627c:	ea82 0703 	eor.w	r7, r2, r3
20026280:	4401      	add	r1, r0
20026282:	ea82 000b 	eor.w	r0, r2, fp
20026286:	4018      	ands	r0, r3
20026288:	ea80 000b 	eor.w	r0, r0, fp
2002628c:	4471      	add	r1, lr
2002628e:	4401      	add	r1, r0
20026290:	ea4f 20f3 	mov.w	r0, r3, ror #11
20026294:	ea80 10b3 	eor.w	r0, r0, r3, ror #6
20026298:	ea80 6073 	eor.w	r0, r0, r3, ror #25
2002629c:	4401      	add	r1, r0
2002629e:	ea4f 3074 	mov.w	r0, r4, ror #13
200262a2:	ea80 00b4 	eor.w	r0, r0, r4, ror #2
200262a6:	ea80 50b4 	eor.w	r0, r0, r4, ror #22
200262aa:	eb06 0e01 	add.w	lr, r6, r1
200262ae:	4408      	add	r0, r1
200262b0:	ea48 0104 	orr.w	r1, r8, r4
200262b4:	ea08 0604 	and.w	r6, r8, r4
200262b8:	ea01 0109 	and.w	r1, r1, r9
200262bc:	4331      	orrs	r1, r6
200262be:	4408      	add	r0, r1
200262c0:	f8dc 600c 	ldr.w	r6, [ip, #12]
200262c4:	68e9      	ldr	r1, [r5, #12]
200262c6:	ea07 070e 	and.w	r7, r7, lr
200262ca:	440e      	add	r6, r1
200262cc:	ea4f 21fe 	mov.w	r1, lr, ror #11
200262d0:	4057      	eors	r7, r2
200262d2:	445e      	add	r6, fp
200262d4:	ea81 11be 	eor.w	r1, r1, lr, ror #6
200262d8:	ea81 617e 	eor.w	r1, r1, lr, ror #25
200262dc:	443e      	add	r6, r7
200262de:	440e      	add	r6, r1
200262e0:	ea4f 3170 	mov.w	r1, r0, ror #13
200262e4:	ea81 01b0 	eor.w	r1, r1, r0, ror #2
200262e8:	ea81 51b0 	eor.w	r1, r1, r0, ror #22
200262ec:	44b1      	add	r9, r6
200262ee:	4431      	add	r1, r6
200262f0:	ea44 0600 	orr.w	r6, r4, r0
200262f4:	ea04 0700 	and.w	r7, r4, r0
200262f8:	ea06 0608 	and.w	r6, r6, r8
200262fc:	433e      	orrs	r6, r7
200262fe:	4431      	add	r1, r6
20026300:	f8dc 7010 	ldr.w	r7, [ip, #16]
20026304:	692e      	ldr	r6, [r5, #16]
20026306:	3520      	adds	r5, #32
20026308:	443e      	add	r6, r7
2002630a:	4416      	add	r6, r2
2002630c:	ea83 020e 	eor.w	r2, r3, lr
20026310:	ea02 0209 	and.w	r2, r2, r9
20026314:	405a      	eors	r2, r3
20026316:	4416      	add	r6, r2
20026318:	ea4f 22f9 	mov.w	r2, r9, ror #11
2002631c:	ea82 12b9 	eor.w	r2, r2, r9, ror #6
20026320:	ea82 6279 	eor.w	r2, r2, r9, ror #25
20026324:	4416      	add	r6, r2
20026326:	ea4f 3271 	mov.w	r2, r1, ror #13
2002632a:	ea82 02b1 	eor.w	r2, r2, r1, ror #2
2002632e:	ea82 52b1 	eor.w	r2, r2, r1, ror #22
20026332:	44b0      	add	r8, r6
20026334:	4432      	add	r2, r6
20026336:	ea40 0601 	orr.w	r6, r0, r1
2002633a:	ea00 0701 	and.w	r7, r0, r1
2002633e:	4026      	ands	r6, r4
20026340:	433e      	orrs	r6, r7
20026342:	4432      	add	r2, r6
20026344:	f8dc 7014 	ldr.w	r7, [ip, #20]
20026348:	f855 6c0c 	ldr.w	r6, [r5, #-12]
2002634c:	f10c 0c20 	add.w	ip, ip, #32
20026350:	443e      	add	r6, r7
20026352:	441e      	add	r6, r3
20026354:	ea8e 0309 	eor.w	r3, lr, r9
20026358:	ea03 0308 	and.w	r3, r3, r8
2002635c:	ea83 030e 	eor.w	r3, r3, lr
20026360:	441e      	add	r6, r3
20026362:	ea4f 23f8 	mov.w	r3, r8, ror #11
20026366:	ea83 13b8 	eor.w	r3, r3, r8, ror #6
2002636a:	ea83 6378 	eor.w	r3, r3, r8, ror #25
2002636e:	441e      	add	r6, r3
20026370:	ea4f 3372 	mov.w	r3, r2, ror #13
20026374:	ea83 03b2 	eor.w	r3, r3, r2, ror #2
20026378:	19a7      	adds	r7, r4, r6
2002637a:	ea83 53b2 	eor.w	r3, r3, r2, ror #22
2002637e:	ea41 0402 	orr.w	r4, r1, r2
20026382:	4433      	add	r3, r6
20026384:	4004      	ands	r4, r0
20026386:	ea01 0602 	and.w	r6, r1, r2
2002638a:	4334      	orrs	r4, r6
2002638c:	4423      	add	r3, r4
2002638e:	f85c 6c08 	ldr.w	r6, [ip, #-8]
20026392:	f855 4c08 	ldr.w	r4, [r5, #-8]
20026396:	4434      	add	r4, r6
20026398:	ea89 0608 	eor.w	r6, r9, r8
2002639c:	403e      	ands	r6, r7
2002639e:	ea86 0609 	eor.w	r6, r6, r9
200263a2:	4474      	add	r4, lr
200263a4:	4434      	add	r4, r6
200263a6:	ea4f 26f7 	mov.w	r6, r7, ror #11
200263aa:	ea86 16b7 	eor.w	r6, r6, r7, ror #6
200263ae:	ea86 6677 	eor.w	r6, r6, r7, ror #25
200263b2:	4434      	add	r4, r6
200263b4:	eb00 0e04 	add.w	lr, r0, r4
200263b8:	ea4f 3073 	mov.w	r0, r3, ror #13
200263bc:	ea80 00b3 	eor.w	r0, r0, r3, ror #2
200263c0:	ea80 50b3 	eor.w	r0, r0, r3, ror #22
200263c4:	4420      	add	r0, r4
200263c6:	ea42 0403 	orr.w	r4, r2, r3
200263ca:	400c      	ands	r4, r1
200263cc:	ea02 0603 	and.w	r6, r2, r3
200263d0:	4334      	orrs	r4, r6
200263d2:	1906      	adds	r6, r0, r4
200263d4:	f855 0c04 	ldr.w	r0, [r5, #-4]
200263d8:	f85c 4c04 	ldr.w	r4, [ip, #-4]
200263dc:	4420      	add	r0, r4
200263de:	ea88 0407 	eor.w	r4, r8, r7
200263e2:	ea04 040e 	and.w	r4, r4, lr
200263e6:	4448      	add	r0, r9
200263e8:	ea84 0408 	eor.w	r4, r4, r8
200263ec:	4420      	add	r0, r4
200263ee:	ea4f 24fe 	mov.w	r4, lr, ror #11
200263f2:	ea84 14be 	eor.w	r4, r4, lr, ror #6
200263f6:	ea84 647e 	eor.w	r4, r4, lr, ror #25
200263fa:	4420      	add	r0, r4
200263fc:	eb01 0b00 	add.w	fp, r1, r0
20026400:	ea4f 3176 	mov.w	r1, r6, ror #13
20026404:	ea81 01b6 	eor.w	r1, r1, r6, ror #2
20026408:	ea81 51b6 	eor.w	r1, r1, r6, ror #22
2002640c:	4401      	add	r1, r0
2002640e:	ea43 0006 	orr.w	r0, r3, r6
20026412:	4010      	ands	r0, r2
20026414:	ea03 0406 	and.w	r4, r3, r6
20026418:	4320      	orrs	r0, r4
2002641a:	eb01 0900 	add.w	r9, r1, r0
2002641e:	4905      	ldr	r1, [pc, #20]	@ (20026434 <mbedtls_sha256_process+0x2b0>)
20026420:	42a9      	cmp	r1, r5
20026422:	f47f aee6 	bne.w	200261f2 <mbedtls_sha256_process+0x6e>
20026426:	f10a 01c0 	add.w	r1, sl, #192	@ 0xc0
2002642a:	9105      	str	r1, [sp, #20]
2002642c:	e004      	b.n	20026438 <mbedtls_sha256_process+0x2b4>
2002642e:	bf00      	nop
20026430:	2002bf84 	.word	0x2002bf84
20026434:	2002bfc4 	.word	0x2002bfc4
20026438:	f8da 1038 	ldr.w	r1, [sl, #56]	@ 0x38
2002643c:	f8da 5004 	ldr.w	r5, [sl, #4]
20026440:	ea4f 44f1 	mov.w	r4, r1, ror #19
20026444:	ea84 4471 	eor.w	r4, r4, r1, ror #17
20026448:	f8da 0000 	ldr.w	r0, [sl]
2002644c:	ea84 2491 	eor.w	r4, r4, r1, lsr #10
20026450:	f8da 1024 	ldr.w	r1, [sl, #36]	@ 0x24
20026454:	f10a 0a20 	add.w	sl, sl, #32
20026458:	4401      	add	r1, r0
2002645a:	ea4f 40b5 	mov.w	r0, r5, ror #18
2002645e:	ea80 10f5 	eor.w	r0, r0, r5, ror #7
20026462:	ea80 00d5 	eor.w	r0, r0, r5, lsr #3
20026466:	4421      	add	r1, r4
20026468:	4401      	add	r1, r0
2002646a:	9103      	str	r1, [sp, #12]
2002646c:	ea87 000e 	eor.w	r0, r7, lr
20026470:	9900      	ldr	r1, [sp, #0]
20026472:	ea4f 24fb 	mov.w	r4, fp, ror #11
20026476:	ea84 14bb 	eor.w	r4, r4, fp, ror #6
2002647a:	ea00 000b 	and.w	r0, r0, fp
2002647e:	ea84 647b 	eor.w	r4, r4, fp, ror #25
20026482:	6c09      	ldr	r1, [r1, #64]	@ 0x40
20026484:	4078      	eors	r0, r7
20026486:	4420      	add	r0, r4
20026488:	4401      	add	r1, r0
2002648a:	9803      	ldr	r0, [sp, #12]
2002648c:	ea4f 3479 	mov.w	r4, r9, ror #13
20026490:	4401      	add	r1, r0
20026492:	4441      	add	r1, r8
20026494:	eb02 0801 	add.w	r8, r2, r1
20026498:	ea49 0206 	orr.w	r2, r9, r6
2002649c:	f8ca 0020 	str.w	r0, [sl, #32]
200264a0:	ea84 04b9 	eor.w	r4, r4, r9, ror #2
200264a4:	ea09 0006 	and.w	r0, r9, r6
200264a8:	401a      	ands	r2, r3
200264aa:	4302      	orrs	r2, r0
200264ac:	ea84 54b9 	eor.w	r4, r4, r9, ror #22
200264b0:	4414      	add	r4, r2
200264b2:	f8da 201c 	ldr.w	r2, [sl, #28]
200264b6:	440c      	add	r4, r1
200264b8:	ea4f 4cf2 	mov.w	ip, r2, ror #19
200264bc:	ea8c 4c72 	eor.w	ip, ip, r2, ror #17
200264c0:	f85a 1c18 	ldr.w	r1, [sl, #-24]
200264c4:	ea8c 2c92 	eor.w	ip, ip, r2, lsr #10
200264c8:	f8da 2008 	ldr.w	r2, [sl, #8]
200264cc:	18a8      	adds	r0, r5, r2
200264ce:	ea4f 42b1 	mov.w	r2, r1, ror #18
200264d2:	ea82 12f1 	eor.w	r2, r2, r1, ror #7
200264d6:	ea82 02d1 	eor.w	r2, r2, r1, lsr #3
200264da:	4460      	add	r0, ip
200264dc:	4410      	add	r0, r2
200264de:	9a00      	ldr	r2, [sp, #0]
200264e0:	ea8b 050e 	eor.w	r5, fp, lr
200264e4:	6c52      	ldr	r2, [r2, #68]	@ 0x44
200264e6:	ea05 0508 	and.w	r5, r5, r8
200264ea:	443a      	add	r2, r7
200264ec:	4402      	add	r2, r0
200264ee:	ea85 050e 	eor.w	r5, r5, lr
200264f2:	4415      	add	r5, r2
200264f4:	ea4f 22f8 	mov.w	r2, r8, ror #11
200264f8:	ea82 12b8 	eor.w	r2, r2, r8, ror #6
200264fc:	ea82 6278 	eor.w	r2, r2, r8, ror #25
20026500:	442a      	add	r2, r5
20026502:	4413      	add	r3, r2
20026504:	9301      	str	r3, [sp, #4]
20026506:	ea49 0504 	orr.w	r5, r9, r4
2002650a:	ea4f 3374 	mov.w	r3, r4, ror #13
2002650e:	ea09 0704 	and.w	r7, r9, r4
20026512:	ea83 03b4 	eor.w	r3, r3, r4, ror #2
20026516:	4035      	ands	r5, r6
20026518:	433d      	orrs	r5, r7
2002651a:	ea83 53b4 	eor.w	r3, r3, r4, ror #22
2002651e:	442b      	add	r3, r5
20026520:	4413      	add	r3, r2
20026522:	9a03      	ldr	r2, [sp, #12]
20026524:	f85a 5c14 	ldr.w	r5, [sl, #-20]
20026528:	ea4f 4cf2 	mov.w	ip, r2, ror #19
2002652c:	ea8c 4c72 	eor.w	ip, ip, r2, ror #17
20026530:	ea8c 2c92 	eor.w	ip, ip, r2, lsr #10
20026534:	f8da 200c 	ldr.w	r2, [sl, #12]
20026538:	f8ca 0024 	str.w	r0, [sl, #36]	@ 0x24
2002653c:	188f      	adds	r7, r1, r2
2002653e:	ea4f 42b5 	mov.w	r2, r5, ror #18
20026542:	ea82 12f5 	eor.w	r2, r2, r5, ror #7
20026546:	ea82 02d5 	eor.w	r2, r2, r5, lsr #3
2002654a:	4467      	add	r7, ip
2002654c:	4417      	add	r7, r2
2002654e:	9a01      	ldr	r2, [sp, #4]
20026550:	ea8b 0108 	eor.w	r1, fp, r8
20026554:	4011      	ands	r1, r2
20026556:	9a00      	ldr	r2, [sp, #0]
20026558:	ea81 010b 	eor.w	r1, r1, fp
2002655c:	6c92      	ldr	r2, [r2, #72]	@ 0x48
2002655e:	f8ca 7028 	str.w	r7, [sl, #40]	@ 0x28
20026562:	4472      	add	r2, lr
20026564:	443a      	add	r2, r7
20026566:	eb01 0c02 	add.w	ip, r1, r2
2002656a:	9a01      	ldr	r2, [sp, #4]
2002656c:	9901      	ldr	r1, [sp, #4]
2002656e:	ea4f 22f2 	mov.w	r2, r2, ror #11
20026572:	ea82 12b1 	eor.w	r2, r2, r1, ror #6
20026576:	ea82 6271 	eor.w	r2, r2, r1, ror #25
2002657a:	4462      	add	r2, ip
2002657c:	18b1      	adds	r1, r6, r2
2002657e:	9102      	str	r1, [sp, #8]
20026580:	ea44 0603 	orr.w	r6, r4, r3
20026584:	ea4f 3173 	mov.w	r1, r3, ror #13
20026588:	ea04 0c03 	and.w	ip, r4, r3
2002658c:	ea81 01b3 	eor.w	r1, r1, r3, ror #2
20026590:	ea06 0609 	and.w	r6, r6, r9
20026594:	ea46 060c 	orr.w	r6, r6, ip
20026598:	ea81 51b3 	eor.w	r1, r1, r3, ror #22
2002659c:	4431      	add	r1, r6
2002659e:	4411      	add	r1, r2
200265a0:	ea4f 42f0 	mov.w	r2, r0, ror #19
200265a4:	ea82 4270 	eor.w	r2, r2, r0, ror #17
200265a8:	f85a 6c10 	ldr.w	r6, [sl, #-16]
200265ac:	ea82 2090 	eor.w	r0, r2, r0, lsr #10
200265b0:	f8da 2010 	ldr.w	r2, [sl, #16]
200265b4:	ea03 0e01 	and.w	lr, r3, r1
200265b8:	4415      	add	r5, r2
200265ba:	ea4f 42b6 	mov.w	r2, r6, ror #18
200265be:	ea82 12f6 	eor.w	r2, r2, r6, ror #7
200265c2:	ea82 02d6 	eor.w	r2, r2, r6, lsr #3
200265c6:	4405      	add	r5, r0
200265c8:	4415      	add	r5, r2
200265ca:	9a01      	ldr	r2, [sp, #4]
200265cc:	ea88 0002 	eor.w	r0, r8, r2
200265d0:	9a02      	ldr	r2, [sp, #8]
200265d2:	4010      	ands	r0, r2
200265d4:	9a00      	ldr	r2, [sp, #0]
200265d6:	ea80 0008 	eor.w	r0, r0, r8
200265da:	6cd2      	ldr	r2, [r2, #76]	@ 0x4c
200265dc:	f8ca 502c 	str.w	r5, [sl, #44]	@ 0x2c
200265e0:	445a      	add	r2, fp
200265e2:	442a      	add	r2, r5
200265e4:	eb00 0c02 	add.w	ip, r0, r2
200265e8:	9a02      	ldr	r2, [sp, #8]
200265ea:	9802      	ldr	r0, [sp, #8]
200265ec:	ea4f 22f2 	mov.w	r2, r2, ror #11
200265f0:	ea82 12b0 	eor.w	r2, r2, r0, ror #6
200265f4:	ea82 6270 	eor.w	r2, r2, r0, ror #25
200265f8:	4462      	add	r2, ip
200265fa:	ea4f 3071 	mov.w	r0, r1, ror #13
200265fe:	ea43 0c01 	orr.w	ip, r3, r1
20026602:	ea80 00b1 	eor.w	r0, r0, r1, ror #2
20026606:	ea0c 0c04 	and.w	ip, ip, r4
2002660a:	ea4c 0c0e 	orr.w	ip, ip, lr
2002660e:	ea80 50b1 	eor.w	r0, r0, r1, ror #22
20026612:	4460      	add	r0, ip
20026614:	4410      	add	r0, r2
20026616:	4491      	add	r9, r2
20026618:	ea4f 42f7 	mov.w	r2, r7, ror #19
2002661c:	ea82 4277 	eor.w	r2, r2, r7, ror #17
20026620:	f85a cc0c 	ldr.w	ip, [sl, #-12]
20026624:	ea82 2797 	eor.w	r7, r2, r7, lsr #10
20026628:	f8da 2014 	ldr.w	r2, [sl, #20]
2002662c:	ea01 0e00 	and.w	lr, r1, r0
20026630:	4416      	add	r6, r2
20026632:	ea4f 42bc 	mov.w	r2, ip, ror #18
20026636:	ea82 12fc 	eor.w	r2, r2, ip, ror #7
2002663a:	ea82 02dc 	eor.w	r2, r2, ip, lsr #3
2002663e:	443e      	add	r6, r7
20026640:	4416      	add	r6, r2
20026642:	e9dd 2701 	ldrd	r2, r7, [sp, #4]
20026646:	4057      	eors	r7, r2
20026648:	ea07 0709 	and.w	r7, r7, r9
2002664c:	4057      	eors	r7, r2
2002664e:	9a00      	ldr	r2, [sp, #0]
20026650:	f8ca 6030 	str.w	r6, [sl, #48]	@ 0x30
20026654:	6d12      	ldr	r2, [r2, #80]	@ 0x50
20026656:	4432      	add	r2, r6
20026658:	4442      	add	r2, r8
2002665a:	443a      	add	r2, r7
2002665c:	ea4f 27f9 	mov.w	r7, r9, ror #11
20026660:	ea87 17b9 	eor.w	r7, r7, r9, ror #6
20026664:	ea87 6779 	eor.w	r7, r7, r9, ror #25
20026668:	4417      	add	r7, r2
2002666a:	eb04 0807 	add.w	r8, r4, r7
2002666e:	ea4f 3270 	mov.w	r2, r0, ror #13
20026672:	ea41 0400 	orr.w	r4, r1, r0
20026676:	ea82 02b0 	eor.w	r2, r2, r0, ror #2
2002667a:	401c      	ands	r4, r3
2002667c:	ea44 040e 	orr.w	r4, r4, lr
20026680:	ea82 52b0 	eor.w	r2, r2, r0, ror #22
20026684:	4422      	add	r2, r4
20026686:	ea4f 44f5 	mov.w	r4, r5, ror #19
2002668a:	ea84 4475 	eor.w	r4, r4, r5, ror #17
2002668e:	ea84 2495 	eor.w	r4, r4, r5, lsr #10
20026692:	f8da 5018 	ldr.w	r5, [sl, #24]
20026696:	f85a ec08 	ldr.w	lr, [sl, #-8]
2002669a:	4465      	add	r5, ip
2002669c:	4425      	add	r5, r4
2002669e:	ea4f 44be 	mov.w	r4, lr, ror #18
200266a2:	ea84 14fe 	eor.w	r4, r4, lr, ror #7
200266a6:	ea84 04de 	eor.w	r4, r4, lr, lsr #3
200266aa:	4425      	add	r5, r4
200266ac:	9c02      	ldr	r4, [sp, #8]
200266ae:	443a      	add	r2, r7
200266b0:	ea84 0709 	eor.w	r7, r4, r9
200266b4:	ea07 0708 	and.w	r7, r7, r8
200266b8:	ea87 0c04 	eor.w	ip, r7, r4
200266bc:	9c00      	ldr	r4, [sp, #0]
200266be:	9f01      	ldr	r7, [sp, #4]
200266c0:	6d64      	ldr	r4, [r4, #84]	@ 0x54
200266c2:	ea00 0b02 	and.w	fp, r0, r2
200266c6:	442c      	add	r4, r5
200266c8:	443c      	add	r4, r7
200266ca:	eb0c 0704 	add.w	r7, ip, r4
200266ce:	ea4f 24f8 	mov.w	r4, r8, ror #11
200266d2:	ea84 14b8 	eor.w	r4, r4, r8, ror #6
200266d6:	ea84 6478 	eor.w	r4, r4, r8, ror #25
200266da:	443c      	add	r4, r7
200266dc:	191f      	adds	r7, r3, r4
200266de:	ea40 0c02 	orr.w	ip, r0, r2
200266e2:	ea4f 3372 	mov.w	r3, r2, ror #13
200266e6:	ea0c 0c01 	and.w	ip, ip, r1
200266ea:	ea83 03b2 	eor.w	r3, r3, r2, ror #2
200266ee:	ea4c 0c0b 	orr.w	ip, ip, fp
200266f2:	ea83 53b2 	eor.w	r3, r3, r2, ror #22
200266f6:	4463      	add	r3, ip
200266f8:	4423      	add	r3, r4
200266fa:	ea4f 44f6 	mov.w	r4, r6, ror #19
200266fe:	ea84 4476 	eor.w	r4, r4, r6, ror #17
20026702:	ea84 2496 	eor.w	r4, r4, r6, lsr #10
20026706:	f8da 601c 	ldr.w	r6, [sl, #28]
2002670a:	f85a cc04 	ldr.w	ip, [sl, #-4]
2002670e:	4476      	add	r6, lr
20026710:	4426      	add	r6, r4
20026712:	ea4f 44bc 	mov.w	r4, ip, ror #18
20026716:	ea84 14fc 	eor.w	r4, r4, ip, ror #7
2002671a:	ea84 04dc 	eor.w	r4, r4, ip, lsr #3
2002671e:	eb06 0b04 	add.w	fp, r6, r4
20026722:	9c00      	ldr	r4, [sp, #0]
20026724:	9e02      	ldr	r6, [sp, #8]
20026726:	6da4      	ldr	r4, [r4, #88]	@ 0x58
20026728:	ea89 0e08 	eor.w	lr, r9, r8
2002672c:	445c      	add	r4, fp
2002672e:	4434      	add	r4, r6
20026730:	ea0e 0e07 	and.w	lr, lr, r7
20026734:	ea4f 26f7 	mov.w	r6, r7, ror #11
20026738:	ea8e 0e09 	eor.w	lr, lr, r9
2002673c:	ea86 16b7 	eor.w	r6, r6, r7, ror #6
20026740:	4474      	add	r4, lr
20026742:	ea86 6677 	eor.w	r6, r6, r7, ror #25
20026746:	4434      	add	r4, r6
20026748:	eb01 0e04 	add.w	lr, r1, r4
2002674c:	ea42 0603 	orr.w	r6, r2, r3
20026750:	ea4f 3173 	mov.w	r1, r3, ror #13
20026754:	f8ca b038 	str.w	fp, [sl, #56]	@ 0x38
20026758:	4006      	ands	r6, r0
2002675a:	ea02 0b03 	and.w	fp, r2, r3
2002675e:	ea81 01b3 	eor.w	r1, r1, r3, ror #2
20026762:	ea46 060b 	orr.w	r6, r6, fp
20026766:	ea81 51b3 	eor.w	r1, r1, r3, ror #22
2002676a:	4431      	add	r1, r6
2002676c:	190e      	adds	r6, r1, r4
2002676e:	ea4f 41f5 	mov.w	r1, r5, ror #19
20026772:	ea81 4175 	eor.w	r1, r1, r5, ror #17
20026776:	f8ca 5034 	str.w	r5, [sl, #52]	@ 0x34
2002677a:	ea81 2195 	eor.w	r1, r1, r5, lsr #10
2002677e:	9d03      	ldr	r5, [sp, #12]
20026780:	f8da 4000 	ldr.w	r4, [sl]
20026784:	4465      	add	r5, ip
20026786:	4429      	add	r1, r5
20026788:	ea4f 45b4 	mov.w	r5, r4, ror #18
2002678c:	ea85 15f4 	eor.w	r5, r5, r4, ror #7
20026790:	ea85 05d4 	eor.w	r5, r5, r4, lsr #3
20026794:	194c      	adds	r4, r1, r5
20026796:	9900      	ldr	r1, [sp, #0]
20026798:	ea88 0507 	eor.w	r5, r8, r7
2002679c:	6dc9      	ldr	r1, [r1, #92]	@ 0x5c
2002679e:	ea05 050e 	and.w	r5, r5, lr
200267a2:	4421      	add	r1, r4
200267a4:	4449      	add	r1, r9
200267a6:	ea85 0508 	eor.w	r5, r5, r8
200267aa:	440d      	add	r5, r1
200267ac:	ea4f 21fe 	mov.w	r1, lr, ror #11
200267b0:	ea81 11be 	eor.w	r1, r1, lr, ror #6
200267b4:	ea81 617e 	eor.w	r1, r1, lr, ror #25
200267b8:	4429      	add	r1, r5
200267ba:	f8ca 403c 	str.w	r4, [sl, #60]	@ 0x3c
200267be:	eb00 0b01 	add.w	fp, r0, r1
200267c2:	ea43 0406 	orr.w	r4, r3, r6
200267c6:	ea4f 3076 	mov.w	r0, r6, ror #13
200267ca:	ea80 00b6 	eor.w	r0, r0, r6, ror #2
200267ce:	4014      	ands	r4, r2
200267d0:	ea03 0506 	and.w	r5, r3, r6
200267d4:	ea80 50b6 	eor.w	r0, r0, r6, ror #22
200267d8:	432c      	orrs	r4, r5
200267da:	4420      	add	r0, r4
200267dc:	eb00 0901 	add.w	r9, r0, r1
200267e0:	9900      	ldr	r1, [sp, #0]
200267e2:	3120      	adds	r1, #32
200267e4:	9100      	str	r1, [sp, #0]
200267e6:	9905      	ldr	r1, [sp, #20]
200267e8:	4551      	cmp	r1, sl
200267ea:	f47f ae25 	bne.w	20026438 <mbedtls_sha256_process+0x2b4>
200267ee:	9308      	str	r3, [sp, #32]
200267f0:	9b04      	ldr	r3, [sp, #16]
200267f2:	a906      	add	r1, sp, #24
200267f4:	60ca      	str	r2, [r1, #12]
200267f6:	f8c1 801c 	str.w	r8, [r1, #28]
200267fa:	1d1a      	adds	r2, r3, #4
200267fc:	618f      	str	r7, [r1, #24]
200267fe:	3324      	adds	r3, #36	@ 0x24
20026800:	f8c1 e014 	str.w	lr, [r1, #20]
20026804:	604e      	str	r6, [r1, #4]
20026806:	f8c1 b010 	str.w	fp, [r1, #16]
2002680a:	f8c1 9000 	str.w	r9, [r1]
2002680e:	f852 0f04 	ldr.w	r0, [r2, #4]!
20026812:	f851 4b04 	ldr.w	r4, [r1], #4
20026816:	4293      	cmp	r3, r2
20026818:	4420      	add	r0, r4
2002681a:	6010      	str	r0, [r2, #0]
2002681c:	d1f7      	bne.n	2002680e <mbedtls_sha256_process+0x68a>
2002681e:	b04f      	add	sp, #316	@ 0x13c
20026820:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}

20026824 <mbedtls_sha256_update.part.0>:
20026824:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20026828:	6803      	ldr	r3, [r0, #0]
2002682a:	4605      	mov	r5, r0
2002682c:	f003 073f 	and.w	r7, r3, #63	@ 0x3f
20026830:	189b      	adds	r3, r3, r2
20026832:	6003      	str	r3, [r0, #0]
20026834:	bf28      	it	cs
20026836:	6843      	ldrcs	r3, [r0, #4]
20026838:	460e      	mov	r6, r1
2002683a:	bf28      	it	cs
2002683c:	3301      	addcs	r3, #1
2002683e:	4614      	mov	r4, r2
20026840:	bf28      	it	cs
20026842:	6043      	strcs	r3, [r0, #4]
20026844:	b197      	cbz	r7, 2002686c <mbedtls_sha256_update.part.0+0x48>
20026846:	f1c7 0940 	rsb	r9, r7, #64	@ 0x40
2002684a:	4591      	cmp	r9, r2
2002684c:	d80e      	bhi.n	2002686c <mbedtls_sha256_update.part.0+0x48>
2002684e:	f100 0828 	add.w	r8, r0, #40	@ 0x28
20026852:	464a      	mov	r2, r9
20026854:	eb08 0007 	add.w	r0, r8, r7
20026858:	f004 f8fa 	bl	2002aa50 <memcpy>
2002685c:	3c40      	subs	r4, #64	@ 0x40
2002685e:	4641      	mov	r1, r8
20026860:	4628      	mov	r0, r5
20026862:	443c      	add	r4, r7
20026864:	f7ff fc8e 	bl	20026184 <mbedtls_sha256_process>
20026868:	2700      	movs	r7, #0
2002686a:	444e      	add	r6, r9
2002686c:	46a0      	mov	r8, r4
2002686e:	eb04 0906 	add.w	r9, r4, r6
20026872:	e004      	b.n	2002687e <mbedtls_sha256_update.part.0+0x5a>
20026874:	4628      	mov	r0, r5
20026876:	f7ff fc85 	bl	20026184 <mbedtls_sha256_process>
2002687a:	f1a8 0840 	sub.w	r8, r8, #64	@ 0x40
2002687e:	f1b8 0f3f 	cmp.w	r8, #63	@ 0x3f
20026882:	eba9 0108 	sub.w	r1, r9, r8
20026886:	d8f5      	bhi.n	20026874 <mbedtls_sha256_update.part.0+0x50>
20026888:	f06f 033f 	mvn.w	r3, #63	@ 0x3f
2002688c:	09a1      	lsrs	r1, r4, #6
2002688e:	4359      	muls	r1, r3
20026890:	1862      	adds	r2, r4, r1
20026892:	d007      	beq.n	200268a4 <mbedtls_sha256_update.part.0+0x80>
20026894:	f105 0028 	add.w	r0, r5, #40	@ 0x28
20026898:	1a71      	subs	r1, r6, r1
2002689a:	4438      	add	r0, r7
2002689c:	e8bd 43f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200268a0:	f004 b8d6 	b.w	2002aa50 <memcpy>
200268a4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}

200268a8 <mbedtls_sha256_update>:
200268a8:	b10a      	cbz	r2, 200268ae <mbedtls_sha256_update+0x6>
200268aa:	f7ff bfbb 	b.w	20026824 <mbedtls_sha256_update.part.0>
200268ae:	4770      	bx	lr

200268b0 <mbedtls_sha256_finish>:
200268b0:	b537      	push	{r0, r1, r2, r4, r5, lr}
200268b2:	4604      	mov	r4, r0
200268b4:	460d      	mov	r5, r1
200268b6:	e9d0 2100 	ldrd	r2, r1, [r0]
200268ba:	0f53      	lsrs	r3, r2, #29
200268bc:	ea43 03c1 	orr.w	r3, r3, r1, lsl #3
200268c0:	ba1b      	rev	r3, r3
200268c2:	9300      	str	r3, [sp, #0]
200268c4:	00d3      	lsls	r3, r2, #3
200268c6:	f002 023f 	and.w	r2, r2, #63	@ 0x3f
200268ca:	2a37      	cmp	r2, #55	@ 0x37
200268cc:	ba1b      	rev	r3, r3
200268ce:	bf94      	ite	ls
200268d0:	f1c2 0238 	rsbls	r2, r2, #56	@ 0x38
200268d4:	f1c2 0278 	rsbhi	r2, r2, #120	@ 0x78
200268d8:	492b      	ldr	r1, [pc, #172]	@ (20026988 <mbedtls_sha256_finish+0xd8>)
200268da:	9301      	str	r3, [sp, #4]
200268dc:	f7ff ffe4 	bl	200268a8 <mbedtls_sha256_update>
200268e0:	2208      	movs	r2, #8
200268e2:	4669      	mov	r1, sp
200268e4:	4620      	mov	r0, r4
200268e6:	f7ff ff9d 	bl	20026824 <mbedtls_sha256_update.part.0>
200268ea:	7ae3      	ldrb	r3, [r4, #11]
200268ec:	702b      	strb	r3, [r5, #0]
200268ee:	8963      	ldrh	r3, [r4, #10]
200268f0:	706b      	strb	r3, [r5, #1]
200268f2:	68a3      	ldr	r3, [r4, #8]
200268f4:	0a1b      	lsrs	r3, r3, #8
200268f6:	70ab      	strb	r3, [r5, #2]
200268f8:	68a3      	ldr	r3, [r4, #8]
200268fa:	70eb      	strb	r3, [r5, #3]
200268fc:	7be3      	ldrb	r3, [r4, #15]
200268fe:	712b      	strb	r3, [r5, #4]
20026900:	89e3      	ldrh	r3, [r4, #14]
20026902:	716b      	strb	r3, [r5, #5]
20026904:	68e3      	ldr	r3, [r4, #12]
20026906:	0a1b      	lsrs	r3, r3, #8
20026908:	71ab      	strb	r3, [r5, #6]
2002690a:	68e3      	ldr	r3, [r4, #12]
2002690c:	71eb      	strb	r3, [r5, #7]
2002690e:	7ce3      	ldrb	r3, [r4, #19]
20026910:	722b      	strb	r3, [r5, #8]
20026912:	8a63      	ldrh	r3, [r4, #18]
20026914:	726b      	strb	r3, [r5, #9]
20026916:	6923      	ldr	r3, [r4, #16]
20026918:	0a1b      	lsrs	r3, r3, #8
2002691a:	72ab      	strb	r3, [r5, #10]
2002691c:	6923      	ldr	r3, [r4, #16]
2002691e:	72eb      	strb	r3, [r5, #11]
20026920:	7de3      	ldrb	r3, [r4, #23]
20026922:	732b      	strb	r3, [r5, #12]
20026924:	8ae3      	ldrh	r3, [r4, #22]
20026926:	736b      	strb	r3, [r5, #13]
20026928:	6963      	ldr	r3, [r4, #20]
2002692a:	0a1b      	lsrs	r3, r3, #8
2002692c:	73ab      	strb	r3, [r5, #14]
2002692e:	6963      	ldr	r3, [r4, #20]
20026930:	73eb      	strb	r3, [r5, #15]
20026932:	7ee3      	ldrb	r3, [r4, #27]
20026934:	742b      	strb	r3, [r5, #16]
20026936:	8b63      	ldrh	r3, [r4, #26]
20026938:	746b      	strb	r3, [r5, #17]
2002693a:	69a3      	ldr	r3, [r4, #24]
2002693c:	0a1b      	lsrs	r3, r3, #8
2002693e:	74ab      	strb	r3, [r5, #18]
20026940:	69a3      	ldr	r3, [r4, #24]
20026942:	74eb      	strb	r3, [r5, #19]
20026944:	7fe3      	ldrb	r3, [r4, #31]
20026946:	752b      	strb	r3, [r5, #20]
20026948:	8be3      	ldrh	r3, [r4, #30]
2002694a:	756b      	strb	r3, [r5, #21]
2002694c:	69e3      	ldr	r3, [r4, #28]
2002694e:	0a1b      	lsrs	r3, r3, #8
20026950:	75ab      	strb	r3, [r5, #22]
20026952:	69e3      	ldr	r3, [r4, #28]
20026954:	75eb      	strb	r3, [r5, #23]
20026956:	f894 3023 	ldrb.w	r3, [r4, #35]	@ 0x23
2002695a:	762b      	strb	r3, [r5, #24]
2002695c:	8c63      	ldrh	r3, [r4, #34]	@ 0x22
2002695e:	766b      	strb	r3, [r5, #25]
20026960:	6a23      	ldr	r3, [r4, #32]
20026962:	0a1b      	lsrs	r3, r3, #8
20026964:	76ab      	strb	r3, [r5, #26]
20026966:	6a23      	ldr	r3, [r4, #32]
20026968:	76eb      	strb	r3, [r5, #27]
2002696a:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
2002696c:	b94b      	cbnz	r3, 20026982 <mbedtls_sha256_finish+0xd2>
2002696e:	f894 3027 	ldrb.w	r3, [r4, #39]	@ 0x27
20026972:	772b      	strb	r3, [r5, #28]
20026974:	8ce3      	ldrh	r3, [r4, #38]	@ 0x26
20026976:	776b      	strb	r3, [r5, #29]
20026978:	6a63      	ldr	r3, [r4, #36]	@ 0x24
2002697a:	0a1b      	lsrs	r3, r3, #8
2002697c:	77ab      	strb	r3, [r5, #30]
2002697e:	6a63      	ldr	r3, [r4, #36]	@ 0x24
20026980:	77eb      	strb	r3, [r5, #31]
20026982:	b003      	add	sp, #12
20026984:	bd30      	pop	{r4, r5, pc}
20026986:	bf00      	nop
20026988:	2002bf44 	.word	0x2002bf44

2002698c <mbedtls_sha256>:
2002698c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20026990:	461d      	mov	r5, r3
20026992:	b09c      	sub	sp, #112	@ 0x70
20026994:	4607      	mov	r7, r0
20026996:	a801      	add	r0, sp, #4
20026998:	4688      	mov	r8, r1
2002699a:	4616      	mov	r6, r2
2002699c:	f7ff fb97 	bl	200260ce <mbedtls_sha256_init>
200269a0:	b355      	cbz	r5, 200269f8 <mbedtls_sha256+0x6c>
200269a2:	f8df a090 	ldr.w	sl, [pc, #144]	@ 20026a34 <mbedtls_sha256+0xa8>
200269a6:	f8df 9090 	ldr.w	r9, [pc, #144]	@ 20026a38 <mbedtls_sha256+0xac>
200269aa:	f8df e090 	ldr.w	lr, [pc, #144]	@ 20026a3c <mbedtls_sha256+0xb0>
200269ae:	f8df c090 	ldr.w	ip, [pc, #144]	@ 20026a40 <mbedtls_sha256+0xb4>
200269b2:	4818      	ldr	r0, [pc, #96]	@ (20026a14 <mbedtls_sha256+0x88>)
200269b4:	4918      	ldr	r1, [pc, #96]	@ (20026a18 <mbedtls_sha256+0x8c>)
200269b6:	4a19      	ldr	r2, [pc, #100]	@ (20026a1c <mbedtls_sha256+0x90>)
200269b8:	4b19      	ldr	r3, [pc, #100]	@ (20026a20 <mbedtls_sha256+0x94>)
200269ba:	2400      	movs	r4, #0
200269bc:	e9cd 2309 	strd	r2, r3, [sp, #36]	@ 0x24
200269c0:	e9cd 0107 	strd	r0, r1, [sp, #28]
200269c4:	4642      	mov	r2, r8
200269c6:	4639      	mov	r1, r7
200269c8:	a801      	add	r0, sp, #4
200269ca:	e9cd ec05 	strd	lr, ip, [sp, #20]
200269ce:	e9cd 4401 	strd	r4, r4, [sp, #4]
200269d2:	e9cd a903 	strd	sl, r9, [sp, #12]
200269d6:	951b      	str	r5, [sp, #108]	@ 0x6c
200269d8:	f7ff ff66 	bl	200268a8 <mbedtls_sha256_update>
200269dc:	4631      	mov	r1, r6
200269de:	a801      	add	r0, sp, #4
200269e0:	f7ff ff66 	bl	200268b0 <mbedtls_sha256_finish>
200269e4:	4623      	mov	r3, r4
200269e6:	4622      	mov	r2, r4
200269e8:	a901      	add	r1, sp, #4
200269ea:	54ca      	strb	r2, [r1, r3]
200269ec:	3301      	adds	r3, #1
200269ee:	2b6c      	cmp	r3, #108	@ 0x6c
200269f0:	d1fa      	bne.n	200269e8 <mbedtls_sha256+0x5c>
200269f2:	b01c      	add	sp, #112	@ 0x70
200269f4:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200269f8:	f8df a048 	ldr.w	sl, [pc, #72]	@ 20026a44 <mbedtls_sha256+0xb8>
200269fc:	f8df 9048 	ldr.w	r9, [pc, #72]	@ 20026a48 <mbedtls_sha256+0xbc>
20026a00:	f8df e048 	ldr.w	lr, [pc, #72]	@ 20026a4c <mbedtls_sha256+0xc0>
20026a04:	f8df c048 	ldr.w	ip, [pc, #72]	@ 20026a50 <mbedtls_sha256+0xc4>
20026a08:	4806      	ldr	r0, [pc, #24]	@ (20026a24 <mbedtls_sha256+0x98>)
20026a0a:	4907      	ldr	r1, [pc, #28]	@ (20026a28 <mbedtls_sha256+0x9c>)
20026a0c:	4a07      	ldr	r2, [pc, #28]	@ (20026a2c <mbedtls_sha256+0xa0>)
20026a0e:	4b08      	ldr	r3, [pc, #32]	@ (20026a30 <mbedtls_sha256+0xa4>)
20026a10:	e7d3      	b.n	200269ba <mbedtls_sha256+0x2e>
20026a12:	bf00      	nop
20026a14:	ffc00b31 	.word	0xffc00b31
20026a18:	68581511 	.word	0x68581511
20026a1c:	64f98fa7 	.word	0x64f98fa7
20026a20:	befa4fa4 	.word	0xbefa4fa4
20026a24:	510e527f 	.word	0x510e527f
20026a28:	9b05688c 	.word	0x9b05688c
20026a2c:	1f83d9ab 	.word	0x1f83d9ab
20026a30:	5be0cd19 	.word	0x5be0cd19
20026a34:	c1059ed8 	.word	0xc1059ed8
20026a38:	367cd507 	.word	0x367cd507
20026a3c:	3070dd17 	.word	0x3070dd17
20026a40:	f70e5939 	.word	0xf70e5939
20026a44:	6a09e667 	.word	0x6a09e667
20026a48:	bb67ae85 	.word	0xbb67ae85
20026a4c:	3c6ef372 	.word	0x3c6ef372
20026a50:	a54ff53a 	.word	0xa54ff53a

20026a54 <mbedtls_sha512_init>:
20026a54:	22d8      	movs	r2, #216	@ 0xd8
20026a56:	2100      	movs	r1, #0
20026a58:	f003 bfe0 	b.w	2002aa1c <memset>

20026a5c <mbedtls_sha512_free>:
20026a5c:	b138      	cbz	r0, 20026a6e <mbedtls_sha512_free+0x12>
20026a5e:	2100      	movs	r1, #0
20026a60:	f100 03d8 	add.w	r3, r0, #216	@ 0xd8
20026a64:	4602      	mov	r2, r0
20026a66:	3001      	adds	r0, #1
20026a68:	4298      	cmp	r0, r3
20026a6a:	7011      	strb	r1, [r2, #0]
20026a6c:	d1fa      	bne.n	20026a64 <mbedtls_sha512_free+0x8>
20026a6e:	4770      	bx	lr

20026a70 <mbedtls_sha512_clone>:
20026a70:	b508      	push	{r3, lr}
20026a72:	22d8      	movs	r2, #216	@ 0xd8
20026a74:	f003 ffec 	bl	2002aa50 <memcpy>
20026a78:	bd08      	pop	{r3, pc}
20026a7a:	0000      	movs	r0, r0
20026a7c:	0000      	movs	r0, r0
	...

20026a80 <mbedtls_sha512_starts>:
20026a80:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20026a84:	b381      	cbz	r1, 20026ae8 <mbedtls_sha512_starts+0x68>
20026a86:	f20f 0bc8 	addw	fp, pc, #200	@ 0xc8
20026a8a:	e9db ab00 	ldrd	sl, fp, [fp]
20026a8e:	f20f 09c8 	addw	r9, pc, #200	@ 0xc8
20026a92:	e9d9 8900 	ldrd	r8, r9, [r9]
20026a96:	a732      	add	r7, pc, #200	@ (adr r7, 20026b60 <mbedtls_sha512_starts+0xe0>)
20026a98:	e9d7 6700 	ldrd	r6, r7, [r7]
20026a9c:	a532      	add	r5, pc, #200	@ (adr r5, 20026b68 <mbedtls_sha512_starts+0xe8>)
20026a9e:	e9d5 4500 	ldrd	r4, r5, [r5]
20026aa2:	a333      	add	r3, pc, #204	@ (adr r3, 20026b70 <mbedtls_sha512_starts+0xf0>)
20026aa4:	e9d3 2300 	ldrd	r2, r3, [r3]
20026aa8:	ed9f 5b1b 	vldr	d5, [pc, #108]	@ 20026b18 <mbedtls_sha512_starts+0x98>
20026aac:	ed9f 6b1c 	vldr	d6, [pc, #112]	@ 20026b20 <mbedtls_sha512_starts+0xa0>
20026ab0:	ed9f 7b1d 	vldr	d7, [pc, #116]	@ 20026b28 <mbedtls_sha512_starts+0xa8>
20026ab4:	ed9f 4b1e 	vldr	d4, [pc, #120]	@ 20026b30 <mbedtls_sha512_starts+0xb0>
20026ab8:	ed80 5b04 	vstr	d5, [r0, #16]
20026abc:	ed80 4b00 	vstr	d4, [r0]
20026ac0:	ed80 4b02 	vstr	d4, [r0, #8]
20026ac4:	ed80 6b06 	vstr	d6, [r0, #24]
20026ac8:	ed80 7b08 	vstr	d7, [r0, #32]
20026acc:	e9c0 ab0a 	strd	sl, fp, [r0, #40]	@ 0x28
20026ad0:	e9c0 890c 	strd	r8, r9, [r0, #48]	@ 0x30
20026ad4:	e9c0 670e 	strd	r6, r7, [r0, #56]	@ 0x38
20026ad8:	e9c0 4510 	strd	r4, r5, [r0, #64]	@ 0x40
20026adc:	e9c0 2312 	strd	r2, r3, [r0, #72]	@ 0x48
20026ae0:	f8c0 10d0 	str.w	r1, [r0, #208]	@ 0xd0
20026ae4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20026ae8:	ed9f 5b13 	vldr	d5, [pc, #76]	@ 20026b38 <mbedtls_sha512_starts+0xb8>
20026aec:	f20f 0b88 	addw	fp, pc, #136	@ 0x88
20026af0:	e9db ab00 	ldrd	sl, fp, [fp]
20026af4:	f20f 0988 	addw	r9, pc, #136	@ 0x88
20026af8:	e9d9 8900 	ldrd	r8, r9, [r9]
20026afc:	a722      	add	r7, pc, #136	@ (adr r7, 20026b88 <mbedtls_sha512_starts+0x108>)
20026afe:	e9d7 6700 	ldrd	r6, r7, [r7]
20026b02:	a523      	add	r5, pc, #140	@ (adr r5, 20026b90 <mbedtls_sha512_starts+0x110>)
20026b04:	e9d5 4500 	ldrd	r4, r5, [r5]
20026b08:	a323      	add	r3, pc, #140	@ (adr r3, 20026b98 <mbedtls_sha512_starts+0x118>)
20026b0a:	e9d3 2300 	ldrd	r2, r3, [r3]
20026b0e:	ed9f 6b0c 	vldr	d6, [pc, #48]	@ 20026b40 <mbedtls_sha512_starts+0xc0>
20026b12:	ed9f 7b0d 	vldr	d7, [pc, #52]	@ 20026b48 <mbedtls_sha512_starts+0xc8>
20026b16:	e7cd      	b.n	20026ab4 <mbedtls_sha512_starts+0x34>
20026b18:	c1059ed8 	.word	0xc1059ed8
20026b1c:	cbbb9d5d 	.word	0xcbbb9d5d
20026b20:	367cd507 	.word	0x367cd507
20026b24:	629a292a 	.word	0x629a292a
20026b28:	3070dd17 	.word	0x3070dd17
20026b2c:	9159015a 	.word	0x9159015a
	...
20026b38:	f3bcc908 	.word	0xf3bcc908
20026b3c:	6a09e667 	.word	0x6a09e667
20026b40:	84caa73b 	.word	0x84caa73b
20026b44:	bb67ae85 	.word	0xbb67ae85
20026b48:	fe94f82b 	.word	0xfe94f82b
20026b4c:	3c6ef372 	.word	0x3c6ef372
20026b50:	f70e5939 	.word	0xf70e5939
20026b54:	152fecd8 	.word	0x152fecd8
20026b58:	ffc00b31 	.word	0xffc00b31
20026b5c:	67332667 	.word	0x67332667
20026b60:	68581511 	.word	0x68581511
20026b64:	8eb44a87 	.word	0x8eb44a87
20026b68:	64f98fa7 	.word	0x64f98fa7
20026b6c:	db0c2e0d 	.word	0xdb0c2e0d
20026b70:	befa4fa4 	.word	0xbefa4fa4
20026b74:	47b5481d 	.word	0x47b5481d
20026b78:	5f1d36f1 	.word	0x5f1d36f1
20026b7c:	a54ff53a 	.word	0xa54ff53a
20026b80:	ade682d1 	.word	0xade682d1
20026b84:	510e527f 	.word	0x510e527f
20026b88:	2b3e6c1f 	.word	0x2b3e6c1f
20026b8c:	9b05688c 	.word	0x9b05688c
20026b90:	fb41bd6b 	.word	0xfb41bd6b
20026b94:	1f83d9ab 	.word	0x1f83d9ab
20026b98:	137e2179 	.word	0x137e2179
20026b9c:	5be0cd19 	.word	0x5be0cd19

20026ba0 <mbedtls_sha512_process>:
20026ba0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20026ba4:	f5ad 7d3f 	sub.w	sp, sp, #764	@ 0x2fc
20026ba8:	4682      	mov	sl, r0
20026baa:	a81e      	add	r0, sp, #120	@ 0x78
20026bac:	4604      	mov	r4, r0
20026bae:	f101 0580 	add.w	r5, r1, #128	@ 0x80
20026bb2:	784b      	ldrb	r3, [r1, #1]
20026bb4:	780a      	ldrb	r2, [r1, #0]
20026bb6:	041b      	lsls	r3, r3, #16
20026bb8:	790f      	ldrb	r7, [r1, #4]
20026bba:	ea43 6302 	orr.w	r3, r3, r2, lsl #24
20026bbe:	79ca      	ldrb	r2, [r1, #7]
20026bc0:	788e      	ldrb	r6, [r1, #2]
20026bc2:	ea42 6207 	orr.w	r2, r2, r7, lsl #24
20026bc6:	794f      	ldrb	r7, [r1, #5]
20026bc8:	ea43 2306 	orr.w	r3, r3, r6, lsl #8
20026bcc:	ea42 4207 	orr.w	r2, r2, r7, lsl #16
20026bd0:	78ce      	ldrb	r6, [r1, #3]
20026bd2:	798f      	ldrb	r7, [r1, #6]
20026bd4:	3108      	adds	r1, #8
20026bd6:	ea42 2207 	orr.w	r2, r2, r7, lsl #8
20026bda:	4333      	orrs	r3, r6
20026bdc:	428d      	cmp	r5, r1
20026bde:	e9c4 2300 	strd	r2, r3, [r4]
20026be2:	f104 0408 	add.w	r4, r4, #8
20026be6:	d1e4      	bne.n	20026bb2 <mbedtls_sha512_process+0x12>
20026be8:	4601      	mov	r1, r0
20026bea:	2610      	movs	r6, #16
20026bec:	e9d1 4c1c 	ldrd	r4, ip, [r1, #112]	@ 0x70
20026bf0:	e9d1 2502 	ldrd	r2, r5, [r1, #8]
20026bf4:	468e      	mov	lr, r1
20026bf6:	0ce3      	lsrs	r3, r4, #19
20026bf8:	ea4f 47dc 	mov.w	r7, ip, lsr #19
20026bfc:	ea4f 09c4 	mov.w	r9, r4, lsl #3
20026c00:	ea4f 08cc 	mov.w	r8, ip, lsl #3
20026c04:	ea48 7854 	orr.w	r8, r8, r4, lsr #29
20026c08:	ea43 334c 	orr.w	r3, r3, ip, lsl #13
20026c0c:	ea47 3744 	orr.w	r7, r7, r4, lsl #13
20026c10:	ea49 795c 	orr.w	r9, r9, ip, lsr #29
20026c14:	09a4      	lsrs	r4, r4, #6
20026c16:	ea87 0708 	eor.w	r7, r7, r8
20026c1a:	ea44 648c 	orr.w	r4, r4, ip, lsl #26
20026c1e:	ea83 0309 	eor.w	r3, r3, r9
20026c22:	4063      	eors	r3, r4
20026c24:	ea87 179c 	eor.w	r7, r7, ip, lsr #6
20026c28:	e9de 4c12 	ldrd	r4, ip, [lr, #72]	@ 0x48
20026c2c:	e9de 8e00 	ldrd	r8, lr, [lr]
20026c30:	eb14 0408 	adds.w	r4, r4, r8
20026c34:	eb4c 0c0e 	adc.w	ip, ip, lr
20026c38:	191b      	adds	r3, r3, r4
20026c3a:	eb47 070c 	adc.w	r7, r7, ip
20026c3e:	0854      	lsrs	r4, r2, #1
20026c40:	ea4f 2812 	mov.w	r8, r2, lsr #8
20026c44:	ea4f 0c55 	mov.w	ip, r5, lsr #1
20026c48:	ea4f 2e15 	mov.w	lr, r5, lsr #8
20026c4c:	ea4c 7cc2 	orr.w	ip, ip, r2, lsl #31
20026c50:	ea4e 6e02 	orr.w	lr, lr, r2, lsl #24
20026c54:	ea44 74c5 	orr.w	r4, r4, r5, lsl #31
20026c58:	ea48 6805 	orr.w	r8, r8, r5, lsl #24
20026c5c:	09d2      	lsrs	r2, r2, #7
20026c5e:	ea84 0408 	eor.w	r4, r4, r8
20026c62:	ea42 6245 	orr.w	r2, r2, r5, lsl #25
20026c66:	4062      	eors	r2, r4
20026c68:	ea8c 0c0e 	eor.w	ip, ip, lr
20026c6c:	189b      	adds	r3, r3, r2
20026c6e:	ea8c 14d5 	eor.w	r4, ip, r5, lsr #7
20026c72:	f106 0601 	add.w	r6, r6, #1
20026c76:	eb47 0704 	adc.w	r7, r7, r4
20026c7a:	3108      	adds	r1, #8
20026c7c:	2e50      	cmp	r6, #80	@ 0x50
20026c7e:	e9c1 371e 	strd	r3, r7, [r1, #120]	@ 0x78
20026c82:	d1b3      	bne.n	20026bec <mbedtls_sha512_process+0x4c>
20026c84:	f8da 3010 	ldr.w	r3, [sl, #16]
20026c88:	930e      	str	r3, [sp, #56]	@ 0x38
20026c8a:	f8da 3014 	ldr.w	r3, [sl, #20]
20026c8e:	930f      	str	r3, [sp, #60]	@ 0x3c
20026c90:	f8da 3018 	ldr.w	r3, [sl, #24]
20026c94:	9310      	str	r3, [sp, #64]	@ 0x40
20026c96:	f8da 301c 	ldr.w	r3, [sl, #28]
20026c9a:	9311      	str	r3, [sp, #68]	@ 0x44
20026c9c:	f8da 3020 	ldr.w	r3, [sl, #32]
20026ca0:	9312      	str	r3, [sp, #72]	@ 0x48
20026ca2:	f8da 3024 	ldr.w	r3, [sl, #36]	@ 0x24
20026ca6:	9313      	str	r3, [sp, #76]	@ 0x4c
20026ca8:	f8da 3028 	ldr.w	r3, [sl, #40]	@ 0x28
20026cac:	9314      	str	r3, [sp, #80]	@ 0x50
20026cae:	f8da 302c 	ldr.w	r3, [sl, #44]	@ 0x2c
20026cb2:	9315      	str	r3, [sp, #84]	@ 0x54
20026cb4:	f8da 3030 	ldr.w	r3, [sl, #48]	@ 0x30
20026cb8:	9316      	str	r3, [sp, #88]	@ 0x58
20026cba:	f8da 3034 	ldr.w	r3, [sl, #52]	@ 0x34
20026cbe:	9317      	str	r3, [sp, #92]	@ 0x5c
20026cc0:	f8da 3038 	ldr.w	r3, [sl, #56]	@ 0x38
20026cc4:	9318      	str	r3, [sp, #96]	@ 0x60
20026cc6:	f8da 303c 	ldr.w	r3, [sl, #60]	@ 0x3c
20026cca:	9319      	str	r3, [sp, #100]	@ 0x64
20026ccc:	f8da 3040 	ldr.w	r3, [sl, #64]	@ 0x40
20026cd0:	931a      	str	r3, [sp, #104]	@ 0x68
20026cd2:	f8da 3044 	ldr.w	r3, [sl, #68]	@ 0x44
20026cd6:	931b      	str	r3, [sp, #108]	@ 0x6c
20026cd8:	f8da 3048 	ldr.w	r3, [sl, #72]	@ 0x48
20026cdc:	931c      	str	r3, [sp, #112]	@ 0x70
20026cde:	f8da 304c 	ldr.w	r3, [sl, #76]	@ 0x4c
20026ce2:	931d      	str	r3, [sp, #116]	@ 0x74
20026ce4:	4b0f      	ldr	r3, [pc, #60]	@ (20026d24 <mbedtls_sha512_process+0x184>)
20026ce6:	9300      	str	r3, [sp, #0]
20026ce8:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
20026cea:	f8dd b054 	ldr.w	fp, [sp, #84]	@ 0x54
20026cee:	930a      	str	r3, [sp, #40]	@ 0x28
20026cf0:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
20026cf2:	e9dd ce10 	ldrd	ip, lr, [sp, #64]	@ 0x40
20026cf6:	930b      	str	r3, [sp, #44]	@ 0x2c
20026cf8:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
20026cfa:	9308      	str	r3, [sp, #32]
20026cfc:	9b1b      	ldr	r3, [sp, #108]	@ 0x6c
20026cfe:	9309      	str	r3, [sp, #36]	@ 0x24
20026d00:	9b18      	ldr	r3, [sp, #96]	@ 0x60
20026d02:	9306      	str	r3, [sp, #24]
20026d04:	9b19      	ldr	r3, [sp, #100]	@ 0x64
20026d06:	9307      	str	r3, [sp, #28]
20026d08:	9b16      	ldr	r3, [sp, #88]	@ 0x58
20026d0a:	9304      	str	r3, [sp, #16]
20026d0c:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
20026d0e:	9305      	str	r3, [sp, #20]
20026d10:	9b14      	ldr	r3, [sp, #80]	@ 0x50
20026d12:	9303      	str	r3, [sp, #12]
20026d14:	9b12      	ldr	r3, [sp, #72]	@ 0x48
20026d16:	9301      	str	r3, [sp, #4]
20026d18:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
20026d1a:	9302      	str	r3, [sp, #8]
20026d1c:	e9dd 320e 	ldrd	r3, r2, [sp, #56]	@ 0x38
20026d20:	e002      	b.n	20026d28 <mbedtls_sha512_process+0x188>
20026d22:	bf00      	nop
20026d24:	2002c108 	.word	0x2002c108
20026d28:	9c04      	ldr	r4, [sp, #16]
20026d2a:	9e04      	ldr	r6, [sp, #16]
20026d2c:	ea4f 3894 	mov.w	r8, r4, lsr #14
20026d30:	9c05      	ldr	r4, [sp, #20]
20026d32:	9900      	ldr	r1, [sp, #0]
20026d34:	ea48 4884 	orr.w	r8, r8, r4, lsl #18
20026d38:	ea4f 3994 	mov.w	r9, r4, lsr #14
20026d3c:	9c04      	ldr	r4, [sp, #16]
20026d3e:	ea49 4984 	orr.w	r9, r9, r4, lsl #18
20026d42:	0ca5      	lsrs	r5, r4, #18
20026d44:	9c05      	ldr	r4, [sp, #20]
20026d46:	ea45 3584 	orr.w	r5, r5, r4, lsl #14
20026d4a:	0ca4      	lsrs	r4, r4, #18
20026d4c:	ea44 3486 	orr.w	r4, r4, r6, lsl #14
20026d50:	ea89 0904 	eor.w	r9, r9, r4
20026d54:	9c05      	ldr	r4, [sp, #20]
20026d56:	ea88 0805 	eor.w	r8, r8, r5
20026d5a:	05f5      	lsls	r5, r6, #23
20026d5c:	ea45 2554 	orr.w	r5, r5, r4, lsr #9
20026d60:	05e4      	lsls	r4, r4, #23
20026d62:	ea44 2456 	orr.w	r4, r4, r6, lsr #9
20026d66:	ea88 0805 	eor.w	r8, r8, r5
20026d6a:	ea89 0904 	eor.w	r9, r9, r4
20026d6e:	e9d1 5700 	ldrd	r5, r7, [r1]
20026d72:	e9d0 6400 	ldrd	r6, r4, [r0]
20026d76:	19ad      	adds	r5, r5, r6
20026d78:	eb47 0404 	adc.w	r4, r7, r4
20026d7c:	9e06      	ldr	r6, [sp, #24]
20026d7e:	9f08      	ldr	r7, [sp, #32]
20026d80:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026d82:	407e      	eors	r6, r7
20026d84:	9f07      	ldr	r7, [sp, #28]
20026d86:	eb18 0505 	adds.w	r5, r8, r5
20026d8a:	ea87 0701 	eor.w	r7, r7, r1
20026d8e:	9904      	ldr	r1, [sp, #16]
20026d90:	eb49 0404 	adc.w	r4, r9, r4
20026d94:	400e      	ands	r6, r1
20026d96:	9905      	ldr	r1, [sp, #20]
20026d98:	ea4f 7813 	mov.w	r8, r3, lsr #28
20026d9c:	400f      	ands	r7, r1
20026d9e:	9908      	ldr	r1, [sp, #32]
20026da0:	ea4f 7983 	mov.w	r9, r3, lsl #30
20026da4:	404e      	eors	r6, r1
20026da6:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026da8:	19ad      	adds	r5, r5, r6
20026daa:	ea87 0701 	eor.w	r7, r7, r1
20026dae:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026db0:	eb44 0407 	adc.w	r4, r4, r7
20026db4:	186d      	adds	r5, r5, r1
20026db6:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20026db8:	ea4f 7712 	mov.w	r7, r2, lsr #28
20026dbc:	eb41 0404 	adc.w	r4, r1, r4
20026dc0:	9903      	ldr	r1, [sp, #12]
20026dc2:	0796      	lsls	r6, r2, #30
20026dc4:	1949      	adds	r1, r1, r5
20026dc6:	ea46 0693 	orr.w	r6, r6, r3, lsr #2
20026dca:	ea47 1703 	orr.w	r7, r7, r3, lsl #4
20026dce:	910a      	str	r1, [sp, #40]	@ 0x28
20026dd0:	ea87 0706 	eor.w	r7, r7, r6
20026dd4:	eb4b 0104 	adc.w	r1, fp, r4
20026dd8:	0656      	lsls	r6, r2, #25
20026dda:	ea49 0992 	orr.w	r9, r9, r2, lsr #2
20026dde:	ea46 16d3 	orr.w	r6, r6, r3, lsr #7
20026de2:	910b      	str	r1, [sp, #44]	@ 0x2c
20026de4:	ea48 1802 	orr.w	r8, r8, r2, lsl #4
20026de8:	9901      	ldr	r1, [sp, #4]
20026dea:	ea88 0809 	eor.w	r8, r8, r9
20026dee:	4077      	eors	r7, r6
20026df0:	ea4f 6943 	mov.w	r9, r3, lsl #25
20026df4:	ea43 060c 	orr.w	r6, r3, ip
20026df8:	ea49 19d2 	orr.w	r9, r9, r2, lsr #7
20026dfc:	400e      	ands	r6, r1
20026dfe:	9902      	ldr	r1, [sp, #8]
20026e00:	ea03 0b0c 	and.w	fp, r3, ip
20026e04:	ea88 0809 	eor.w	r8, r8, r9
20026e08:	ea42 090e 	orr.w	r9, r2, lr
20026e0c:	ea09 0901 	and.w	r9, r9, r1
20026e10:	ea46 060b 	orr.w	r6, r6, fp
20026e14:	ea02 010e 	and.w	r1, r2, lr
20026e18:	eb18 0606 	adds.w	r6, r8, r6
20026e1c:	ea49 0901 	orr.w	r9, r9, r1
20026e20:	eb47 0709 	adc.w	r7, r7, r9
20026e24:	1971      	adds	r1, r6, r5
20026e26:	9103      	str	r1, [sp, #12]
20026e28:	9900      	ldr	r1, [sp, #0]
20026e2a:	eb44 0b07 	adc.w	fp, r4, r7
20026e2e:	e9d0 6702 	ldrd	r6, r7, [r0, #8]
20026e32:	e9d1 4502 	ldrd	r4, r5, [r1, #8]
20026e36:	9908      	ldr	r1, [sp, #32]
20026e38:	19a4      	adds	r4, r4, r6
20026e3a:	eb45 0507 	adc.w	r5, r5, r7
20026e3e:	1864      	adds	r4, r4, r1
20026e40:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026e42:	9e06      	ldr	r6, [sp, #24]
20026e44:	eb41 0505 	adc.w	r5, r1, r5
20026e48:	9904      	ldr	r1, [sp, #16]
20026e4a:	ea81 0706 	eor.w	r7, r1, r6
20026e4e:	9905      	ldr	r1, [sp, #20]
20026e50:	9e07      	ldr	r6, [sp, #28]
20026e52:	404e      	eors	r6, r1
20026e54:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026e56:	400f      	ands	r7, r1
20026e58:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20026e5a:	400e      	ands	r6, r1
20026e5c:	9906      	ldr	r1, [sp, #24]
20026e5e:	404f      	eors	r7, r1
20026e60:	9907      	ldr	r1, [sp, #28]
20026e62:	19e4      	adds	r4, r4, r7
20026e64:	ea86 0601 	eor.w	r6, r6, r1
20026e68:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026e6a:	eb45 0506 	adc.w	r5, r5, r6
20026e6e:	0b8f      	lsrs	r7, r1, #14
20026e70:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20026e72:	ea47 4781 	orr.w	r7, r7, r1, lsl #18
20026e76:	ea4f 3891 	mov.w	r8, r1, lsr #14
20026e7a:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026e7c:	ea48 4881 	orr.w	r8, r8, r1, lsl #18
20026e80:	ea4f 4991 	mov.w	r9, r1, lsr #18
20026e84:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20026e86:	ea49 3981 	orr.w	r9, r9, r1, lsl #14
20026e8a:	0c8e      	lsrs	r6, r1, #18
20026e8c:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026e8e:	ea87 0709 	eor.w	r7, r7, r9
20026e92:	ea46 3681 	orr.w	r6, r6, r1, lsl #14
20026e96:	ea88 0806 	eor.w	r8, r8, r6
20026e9a:	05ce      	lsls	r6, r1, #23
20026e9c:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20026e9e:	ea46 2651 	orr.w	r6, r6, r1, lsr #9
20026ea2:	ea4f 59c1 	mov.w	r9, r1, lsl #23
20026ea6:	990a      	ldr	r1, [sp, #40]	@ 0x28
20026ea8:	407e      	eors	r6, r7
20026eaa:	ea49 2951 	orr.w	r9, r9, r1, lsr #9
20026eae:	9901      	ldr	r1, [sp, #4]
20026eb0:	19a4      	adds	r4, r4, r6
20026eb2:	ea88 0809 	eor.w	r8, r8, r9
20026eb6:	eb45 0808 	adc.w	r8, r5, r8
20026eba:	1909      	adds	r1, r1, r4
20026ebc:	9108      	str	r1, [sp, #32]
20026ebe:	9902      	ldr	r1, [sp, #8]
20026ec0:	ea4f 761b 	mov.w	r6, fp, lsr #28
20026ec4:	eb41 0108 	adc.w	r1, r1, r8
20026ec8:	9109      	str	r1, [sp, #36]	@ 0x24
20026eca:	9903      	ldr	r1, [sp, #12]
20026ecc:	ea4f 758b 	mov.w	r5, fp, lsl #30
20026ed0:	ea45 0591 	orr.w	r5, r5, r1, lsr #2
20026ed4:	0f0f      	lsrs	r7, r1, #28
20026ed6:	ea46 1601 	orr.w	r6, r6, r1, lsl #4
20026eda:	ea4f 7981 	mov.w	r9, r1, lsl #30
20026ede:	ea49 099b 	orr.w	r9, r9, fp, lsr #2
20026ee2:	ea47 170b 	orr.w	r7, r7, fp, lsl #4
20026ee6:	406e      	eors	r6, r5
20026ee8:	ea4f 654b 	mov.w	r5, fp, lsl #25
20026eec:	ea45 15d1 	orr.w	r5, r5, r1, lsr #7
20026ef0:	ea87 0709 	eor.w	r7, r7, r9
20026ef4:	ea4f 6941 	mov.w	r9, r1, lsl #25
20026ef8:	ea49 19db 	orr.w	r9, r9, fp, lsr #7
20026efc:	406e      	eors	r6, r5
20026efe:	ea43 0501 	orr.w	r5, r3, r1
20026f02:	ea87 0709 	eor.w	r7, r7, r9
20026f06:	4019      	ands	r1, r3
20026f08:	ea42 090b 	orr.w	r9, r2, fp
20026f0c:	ea05 050c 	and.w	r5, r5, ip
20026f10:	ea09 090e 	and.w	r9, r9, lr
20026f14:	430d      	orrs	r5, r1
20026f16:	ea02 010b 	and.w	r1, r2, fp
20026f1a:	197d      	adds	r5, r7, r5
20026f1c:	ea49 0901 	orr.w	r9, r9, r1
20026f20:	eb46 0609 	adc.w	r6, r6, r9
20026f24:	1929      	adds	r1, r5, r4
20026f26:	9101      	str	r1, [sp, #4]
20026f28:	eb48 0106 	adc.w	r1, r8, r6
20026f2c:	9102      	str	r1, [sp, #8]
20026f2e:	9900      	ldr	r1, [sp, #0]
20026f30:	e9d0 6704 	ldrd	r6, r7, [r0, #16]
20026f34:	e9d1 4504 	ldrd	r4, r5, [r1, #16]
20026f38:	9906      	ldr	r1, [sp, #24]
20026f3a:	19a4      	adds	r4, r4, r6
20026f3c:	eb45 0507 	adc.w	r5, r5, r7
20026f40:	1864      	adds	r4, r4, r1
20026f42:	9907      	ldr	r1, [sp, #28]
20026f44:	eb41 0505 	adc.w	r5, r1, r5
20026f48:	9904      	ldr	r1, [sp, #16]
20026f4a:	9e0a      	ldr	r6, [sp, #40]	@ 0x28
20026f4c:	ea81 0706 	eor.w	r7, r1, r6
20026f50:	9905      	ldr	r1, [sp, #20]
20026f52:	9e0b      	ldr	r6, [sp, #44]	@ 0x2c
20026f54:	404e      	eors	r6, r1
20026f56:	9908      	ldr	r1, [sp, #32]
20026f58:	400f      	ands	r7, r1
20026f5a:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026f5c:	400e      	ands	r6, r1
20026f5e:	9904      	ldr	r1, [sp, #16]
20026f60:	404f      	eors	r7, r1
20026f62:	9905      	ldr	r1, [sp, #20]
20026f64:	19e4      	adds	r4, r4, r7
20026f66:	ea86 0601 	eor.w	r6, r6, r1
20026f6a:	9908      	ldr	r1, [sp, #32]
20026f6c:	eb45 0506 	adc.w	r5, r5, r6
20026f70:	0b8f      	lsrs	r7, r1, #14
20026f72:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026f74:	ea47 4781 	orr.w	r7, r7, r1, lsl #18
20026f78:	ea4f 3891 	mov.w	r8, r1, lsr #14
20026f7c:	9908      	ldr	r1, [sp, #32]
20026f7e:	ea48 4881 	orr.w	r8, r8, r1, lsl #18
20026f82:	ea4f 4991 	mov.w	r9, r1, lsr #18
20026f86:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026f88:	ea49 3981 	orr.w	r9, r9, r1, lsl #14
20026f8c:	0c8e      	lsrs	r6, r1, #18
20026f8e:	9908      	ldr	r1, [sp, #32]
20026f90:	ea87 0709 	eor.w	r7, r7, r9
20026f94:	ea46 3681 	orr.w	r6, r6, r1, lsl #14
20026f98:	ea88 0806 	eor.w	r8, r8, r6
20026f9c:	05ce      	lsls	r6, r1, #23
20026f9e:	9909      	ldr	r1, [sp, #36]	@ 0x24
20026fa0:	ea46 2651 	orr.w	r6, r6, r1, lsr #9
20026fa4:	ea4f 59c1 	mov.w	r9, r1, lsl #23
20026fa8:	9908      	ldr	r1, [sp, #32]
20026faa:	407e      	eors	r6, r7
20026fac:	ea49 2951 	orr.w	r9, r9, r1, lsr #9
20026fb0:	19a4      	adds	r4, r4, r6
20026fb2:	ea88 0809 	eor.w	r8, r8, r9
20026fb6:	eb45 0808 	adc.w	r8, r5, r8
20026fba:	eb1c 0104 	adds.w	r1, ip, r4
20026fbe:	9106      	str	r1, [sp, #24]
20026fc0:	eb4e 0108 	adc.w	r1, lr, r8
20026fc4:	9107      	str	r1, [sp, #28]
20026fc6:	9901      	ldr	r1, [sp, #4]
20026fc8:	0f0f      	lsrs	r7, r1, #28
20026fca:	9902      	ldr	r1, [sp, #8]
20026fcc:	ea47 1701 	orr.w	r7, r7, r1, lsl #4
20026fd0:	0f0e      	lsrs	r6, r1, #28
20026fd2:	9901      	ldr	r1, [sp, #4]
20026fd4:	ea46 1601 	orr.w	r6, r6, r1, lsl #4
20026fd8:	ea4f 7c81 	mov.w	ip, r1, lsl #30
20026fdc:	9902      	ldr	r1, [sp, #8]
20026fde:	ea4c 0c91 	orr.w	ip, ip, r1, lsr #2
20026fe2:	078d      	lsls	r5, r1, #30
20026fe4:	9901      	ldr	r1, [sp, #4]
20026fe6:	ea87 070c 	eor.w	r7, r7, ip
20026fea:	ea45 0591 	orr.w	r5, r5, r1, lsr #2
20026fee:	ea4f 6c41 	mov.w	ip, r1, lsl #25
20026ff2:	9902      	ldr	r1, [sp, #8]
20026ff4:	406e      	eors	r6, r5
20026ff6:	ea4c 1cd1 	orr.w	ip, ip, r1, lsr #7
20026ffa:	064d      	lsls	r5, r1, #25
20026ffc:	9901      	ldr	r1, [sp, #4]
20026ffe:	ea87 070c 	eor.w	r7, r7, ip
20027002:	ea45 15d1 	orr.w	r5, r5, r1, lsr #7
20027006:	406e      	eors	r6, r5
20027008:	9903      	ldr	r1, [sp, #12]
2002700a:	9d01      	ldr	r5, [sp, #4]
2002700c:	430d      	orrs	r5, r1
2002700e:	9902      	ldr	r1, [sp, #8]
20027010:	ea4b 0c01 	orr.w	ip, fp, r1
20027014:	ea05 0103 	and.w	r1, r5, r3
20027018:	910c      	str	r1, [sp, #48]	@ 0x30
2002701a:	9d01      	ldr	r5, [sp, #4]
2002701c:	9903      	ldr	r1, [sp, #12]
2002701e:	ea0c 0c02 	and.w	ip, ip, r2
20027022:	ea01 0905 	and.w	r9, r1, r5
20027026:	9902      	ldr	r1, [sp, #8]
20027028:	ea0b 0e01 	and.w	lr, fp, r1
2002702c:	990c      	ldr	r1, [sp, #48]	@ 0x30
2002702e:	ea4c 0c0e 	orr.w	ip, ip, lr
20027032:	ea41 0509 	orr.w	r5, r1, r9
20027036:	9900      	ldr	r1, [sp, #0]
20027038:	197d      	adds	r5, r7, r5
2002703a:	eb46 060c 	adc.w	r6, r6, ip
2002703e:	eb15 0904 	adds.w	r9, r5, r4
20027042:	e9d1 4506 	ldrd	r4, r5, [r1, #24]
20027046:	9904      	ldr	r1, [sp, #16]
20027048:	eb48 0806 	adc.w	r8, r8, r6
2002704c:	e9d0 6706 	ldrd	r6, r7, [r0, #24]
20027050:	19a4      	adds	r4, r4, r6
20027052:	eb45 0507 	adc.w	r5, r5, r7
20027056:	1864      	adds	r4, r4, r1
20027058:	9905      	ldr	r1, [sp, #20]
2002705a:	9e08      	ldr	r6, [sp, #32]
2002705c:	eb41 0505 	adc.w	r5, r1, r5
20027060:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027062:	ea81 0706 	eor.w	r7, r1, r6
20027066:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20027068:	9e09      	ldr	r6, [sp, #36]	@ 0x24
2002706a:	404e      	eors	r6, r1
2002706c:	9906      	ldr	r1, [sp, #24]
2002706e:	400f      	ands	r7, r1
20027070:	9907      	ldr	r1, [sp, #28]
20027072:	400e      	ands	r6, r1
20027074:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027076:	404f      	eors	r7, r1
20027078:	990b      	ldr	r1, [sp, #44]	@ 0x2c
2002707a:	19e4      	adds	r4, r4, r7
2002707c:	ea86 0601 	eor.w	r6, r6, r1
20027080:	9906      	ldr	r1, [sp, #24]
20027082:	eb45 0506 	adc.w	r5, r5, r6
20027086:	ea4f 3c91 	mov.w	ip, r1, lsr #14
2002708a:	9907      	ldr	r1, [sp, #28]
2002708c:	ea4c 4c81 	orr.w	ip, ip, r1, lsl #18
20027090:	0b8e      	lsrs	r6, r1, #14
20027092:	9906      	ldr	r1, [sp, #24]
20027094:	ea46 4681 	orr.w	r6, r6, r1, lsl #18
20027098:	ea4f 4e91 	mov.w	lr, r1, lsr #18
2002709c:	9907      	ldr	r1, [sp, #28]
2002709e:	ea4e 3e81 	orr.w	lr, lr, r1, lsl #14
200270a2:	0c8f      	lsrs	r7, r1, #18
200270a4:	9906      	ldr	r1, [sp, #24]
200270a6:	ea8c 0c0e 	eor.w	ip, ip, lr
200270aa:	ea47 3781 	orr.w	r7, r7, r1, lsl #14
200270ae:	407e      	eors	r6, r7
200270b0:	05cf      	lsls	r7, r1, #23
200270b2:	9907      	ldr	r1, [sp, #28]
200270b4:	ea47 2751 	orr.w	r7, r7, r1, lsr #9
200270b8:	ea4f 5ec1 	mov.w	lr, r1, lsl #23
200270bc:	9906      	ldr	r1, [sp, #24]
200270be:	ea8c 0707 	eor.w	r7, ip, r7
200270c2:	ea4e 2e51 	orr.w	lr, lr, r1, lsr #9
200270c6:	19e4      	adds	r4, r4, r7
200270c8:	ea86 060e 	eor.w	r6, r6, lr
200270cc:	eb45 0606 	adc.w	r6, r5, r6
200270d0:	191b      	adds	r3, r3, r4
200270d2:	930c      	str	r3, [sp, #48]	@ 0x30
200270d4:	eb42 0306 	adc.w	r3, r2, r6
200270d8:	930d      	str	r3, [sp, #52]	@ 0x34
200270da:	ea4f 7218 	mov.w	r2, r8, lsr #28
200270de:	ea4f 7388 	mov.w	r3, r8, lsl #30
200270e2:	ea43 0399 	orr.w	r3, r3, r9, lsr #2
200270e6:	ea4f 7519 	mov.w	r5, r9, lsr #28
200270ea:	ea42 1209 	orr.w	r2, r2, r9, lsl #4
200270ee:	ea4f 7789 	mov.w	r7, r9, lsl #30
200270f2:	ea47 0798 	orr.w	r7, r7, r8, lsr #2
200270f6:	ea45 1508 	orr.w	r5, r5, r8, lsl #4
200270fa:	405a      	eors	r2, r3
200270fc:	ea4f 6348 	mov.w	r3, r8, lsl #25
20027100:	9902      	ldr	r1, [sp, #8]
20027102:	ea43 13d9 	orr.w	r3, r3, r9, lsr #7
20027106:	407d      	eors	r5, r7
20027108:	ea4f 6749 	mov.w	r7, r9, lsl #25
2002710c:	ea47 17d8 	orr.w	r7, r7, r8, lsr #7
20027110:	405a      	eors	r2, r3
20027112:	9b01      	ldr	r3, [sp, #4]
20027114:	407d      	eors	r5, r7
20027116:	ea41 0708 	orr.w	r7, r1, r8
2002711a:	9903      	ldr	r1, [sp, #12]
2002711c:	ea43 0309 	orr.w	r3, r3, r9
20027120:	400b      	ands	r3, r1
20027122:	9901      	ldr	r1, [sp, #4]
20027124:	ea07 070b 	and.w	r7, r7, fp
20027128:	ea01 0e09 	and.w	lr, r1, r9
2002712c:	9902      	ldr	r1, [sp, #8]
2002712e:	ea43 030e 	orr.w	r3, r3, lr
20027132:	ea01 0c08 	and.w	ip, r1, r8
20027136:	ea47 070c 	orr.w	r7, r7, ip
2002713a:	18eb      	adds	r3, r5, r3
2002713c:	eb42 0207 	adc.w	r2, r2, r7
20027140:	191b      	adds	r3, r3, r4
20027142:	9304      	str	r3, [sp, #16]
20027144:	eb46 0302 	adc.w	r3, r6, r2
20027148:	9305      	str	r3, [sp, #20]
2002714a:	9b00      	ldr	r3, [sp, #0]
2002714c:	6a1b      	ldr	r3, [r3, #32]
2002714e:	9a00      	ldr	r2, [sp, #0]
20027150:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027152:	6a52      	ldr	r2, [r2, #36]	@ 0x24
20027154:	e9d0 4508 	ldrd	r4, r5, [r0, #32]
20027158:	191b      	adds	r3, r3, r4
2002715a:	eb42 0205 	adc.w	r2, r2, r5
2002715e:	185b      	adds	r3, r3, r1
20027160:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20027162:	9c06      	ldr	r4, [sp, #24]
20027164:	eb41 0202 	adc.w	r2, r1, r2
20027168:	9908      	ldr	r1, [sp, #32]
2002716a:	ea81 0504 	eor.w	r5, r1, r4
2002716e:	9909      	ldr	r1, [sp, #36]	@ 0x24
20027170:	9c07      	ldr	r4, [sp, #28]
20027172:	404c      	eors	r4, r1
20027174:	990c      	ldr	r1, [sp, #48]	@ 0x30
20027176:	400d      	ands	r5, r1
20027178:	990d      	ldr	r1, [sp, #52]	@ 0x34
2002717a:	400c      	ands	r4, r1
2002717c:	9908      	ldr	r1, [sp, #32]
2002717e:	404d      	eors	r5, r1
20027180:	9909      	ldr	r1, [sp, #36]	@ 0x24
20027182:	195b      	adds	r3, r3, r5
20027184:	ea84 0401 	eor.w	r4, r4, r1
20027188:	990c      	ldr	r1, [sp, #48]	@ 0x30
2002718a:	eb42 0204 	adc.w	r2, r2, r4
2002718e:	0b8e      	lsrs	r6, r1, #14
20027190:	990d      	ldr	r1, [sp, #52]	@ 0x34
20027192:	ea46 4681 	orr.w	r6, r6, r1, lsl #18
20027196:	0b8c      	lsrs	r4, r1, #14
20027198:	990c      	ldr	r1, [sp, #48]	@ 0x30
2002719a:	ea44 4481 	orr.w	r4, r4, r1, lsl #18
2002719e:	0c8f      	lsrs	r7, r1, #18
200271a0:	990d      	ldr	r1, [sp, #52]	@ 0x34
200271a2:	ea47 3781 	orr.w	r7, r7, r1, lsl #14
200271a6:	0c8d      	lsrs	r5, r1, #18
200271a8:	990c      	ldr	r1, [sp, #48]	@ 0x30
200271aa:	407e      	eors	r6, r7
200271ac:	ea45 3581 	orr.w	r5, r5, r1, lsl #14
200271b0:	406c      	eors	r4, r5
200271b2:	05cd      	lsls	r5, r1, #23
200271b4:	990d      	ldr	r1, [sp, #52]	@ 0x34
200271b6:	ea45 2551 	orr.w	r5, r5, r1, lsr #9
200271ba:	05cf      	lsls	r7, r1, #23
200271bc:	990c      	ldr	r1, [sp, #48]	@ 0x30
200271be:	4075      	eors	r5, r6
200271c0:	ea47 2751 	orr.w	r7, r7, r1, lsr #9
200271c4:	9903      	ldr	r1, [sp, #12]
200271c6:	195b      	adds	r3, r3, r5
200271c8:	ea84 0407 	eor.w	r4, r4, r7
200271cc:	eb42 0204 	adc.w	r2, r2, r4
200271d0:	18c9      	adds	r1, r1, r3
200271d2:	910a      	str	r1, [sp, #40]	@ 0x28
200271d4:	eb4b 0102 	adc.w	r1, fp, r2
200271d8:	910b      	str	r1, [sp, #44]	@ 0x2c
200271da:	9904      	ldr	r1, [sp, #16]
200271dc:	0f0e      	lsrs	r6, r1, #28
200271de:	9905      	ldr	r1, [sp, #20]
200271e0:	ea46 1601 	orr.w	r6, r6, r1, lsl #4
200271e4:	0f0d      	lsrs	r5, r1, #28
200271e6:	9904      	ldr	r1, [sp, #16]
200271e8:	ea45 1501 	orr.w	r5, r5, r1, lsl #4
200271ec:	078f      	lsls	r7, r1, #30
200271ee:	9905      	ldr	r1, [sp, #20]
200271f0:	ea47 0791 	orr.w	r7, r7, r1, lsr #2
200271f4:	078c      	lsls	r4, r1, #30
200271f6:	9904      	ldr	r1, [sp, #16]
200271f8:	407e      	eors	r6, r7
200271fa:	ea44 0491 	orr.w	r4, r4, r1, lsr #2
200271fe:	064f      	lsls	r7, r1, #25
20027200:	9905      	ldr	r1, [sp, #20]
20027202:	4065      	eors	r5, r4
20027204:	ea47 17d1 	orr.w	r7, r7, r1, lsr #7
20027208:	064c      	lsls	r4, r1, #25
2002720a:	9904      	ldr	r1, [sp, #16]
2002720c:	407e      	eors	r6, r7
2002720e:	ea44 14d1 	orr.w	r4, r4, r1, lsr #7
20027212:	4065      	eors	r5, r4
20027214:	ea49 0401 	orr.w	r4, r9, r1
20027218:	9905      	ldr	r1, [sp, #20]
2002721a:	ea48 0701 	orr.w	r7, r8, r1
2002721e:	9901      	ldr	r1, [sp, #4]
20027220:	400c      	ands	r4, r1
20027222:	9902      	ldr	r1, [sp, #8]
20027224:	400f      	ands	r7, r1
20027226:	9904      	ldr	r1, [sp, #16]
20027228:	ea09 0e01 	and.w	lr, r9, r1
2002722c:	9905      	ldr	r1, [sp, #20]
2002722e:	ea44 040e 	orr.w	r4, r4, lr
20027232:	ea08 0c01 	and.w	ip, r8, r1
20027236:	1934      	adds	r4, r6, r4
20027238:	ea47 070c 	orr.w	r7, r7, ip
2002723c:	eb45 0507 	adc.w	r5, r5, r7
20027240:	18e3      	adds	r3, r4, r3
20027242:	9303      	str	r3, [sp, #12]
20027244:	9b00      	ldr	r3, [sp, #0]
20027246:	eb42 0b05 	adc.w	fp, r2, r5
2002724a:	9a00      	ldr	r2, [sp, #0]
2002724c:	6a9b      	ldr	r3, [r3, #40]	@ 0x28
2002724e:	9908      	ldr	r1, [sp, #32]
20027250:	6ad2      	ldr	r2, [r2, #44]	@ 0x2c
20027252:	e9d0 450a 	ldrd	r4, r5, [r0, #40]	@ 0x28
20027256:	191b      	adds	r3, r3, r4
20027258:	eb42 0205 	adc.w	r2, r2, r5
2002725c:	185b      	adds	r3, r3, r1
2002725e:	9909      	ldr	r1, [sp, #36]	@ 0x24
20027260:	9c0c      	ldr	r4, [sp, #48]	@ 0x30
20027262:	eb41 0202 	adc.w	r2, r1, r2
20027266:	9906      	ldr	r1, [sp, #24]
20027268:	ea81 0504 	eor.w	r5, r1, r4
2002726c:	9907      	ldr	r1, [sp, #28]
2002726e:	9c0d      	ldr	r4, [sp, #52]	@ 0x34
20027270:	404c      	eors	r4, r1
20027272:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027274:	400d      	ands	r5, r1
20027276:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20027278:	400c      	ands	r4, r1
2002727a:	9906      	ldr	r1, [sp, #24]
2002727c:	404d      	eors	r5, r1
2002727e:	9907      	ldr	r1, [sp, #28]
20027280:	195b      	adds	r3, r3, r5
20027282:	ea84 0401 	eor.w	r4, r4, r1
20027286:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027288:	eb42 0204 	adc.w	r2, r2, r4
2002728c:	0b8e      	lsrs	r6, r1, #14
2002728e:	990b      	ldr	r1, [sp, #44]	@ 0x2c
20027290:	ea46 4681 	orr.w	r6, r6, r1, lsl #18
20027294:	0b8c      	lsrs	r4, r1, #14
20027296:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027298:	ea44 4481 	orr.w	r4, r4, r1, lsl #18
2002729c:	0c8f      	lsrs	r7, r1, #18
2002729e:	990b      	ldr	r1, [sp, #44]	@ 0x2c
200272a0:	ea47 3781 	orr.w	r7, r7, r1, lsl #14
200272a4:	0c8d      	lsrs	r5, r1, #18
200272a6:	990a      	ldr	r1, [sp, #40]	@ 0x28
200272a8:	407e      	eors	r6, r7
200272aa:	ea45 3581 	orr.w	r5, r5, r1, lsl #14
200272ae:	406c      	eors	r4, r5
200272b0:	05cd      	lsls	r5, r1, #23
200272b2:	990b      	ldr	r1, [sp, #44]	@ 0x2c
200272b4:	ea45 2551 	orr.w	r5, r5, r1, lsr #9
200272b8:	05cf      	lsls	r7, r1, #23
200272ba:	990a      	ldr	r1, [sp, #40]	@ 0x28
200272bc:	4075      	eors	r5, r6
200272be:	ea47 2751 	orr.w	r7, r7, r1, lsr #9
200272c2:	9901      	ldr	r1, [sp, #4]
200272c4:	195b      	adds	r3, r3, r5
200272c6:	ea84 0407 	eor.w	r4, r4, r7
200272ca:	eb42 0204 	adc.w	r2, r2, r4
200272ce:	18c9      	adds	r1, r1, r3
200272d0:	9108      	str	r1, [sp, #32]
200272d2:	9902      	ldr	r1, [sp, #8]
200272d4:	ea4f 751b 	mov.w	r5, fp, lsr #28
200272d8:	eb41 0102 	adc.w	r1, r1, r2
200272dc:	9109      	str	r1, [sp, #36]	@ 0x24
200272de:	9903      	ldr	r1, [sp, #12]
200272e0:	ea4f 748b 	mov.w	r4, fp, lsl #30
200272e4:	ea44 0491 	orr.w	r4, r4, r1, lsr #2
200272e8:	ea45 1501 	orr.w	r5, r5, r1, lsl #4
200272ec:	0f0e      	lsrs	r6, r1, #28
200272ee:	078f      	lsls	r7, r1, #30
200272f0:	4065      	eors	r5, r4
200272f2:	ea4f 644b 	mov.w	r4, fp, lsl #25
200272f6:	ea47 079b 	orr.w	r7, r7, fp, lsr #2
200272fa:	ea44 14d1 	orr.w	r4, r4, r1, lsr #7
200272fe:	ea46 160b 	orr.w	r6, r6, fp, lsl #4
20027302:	407e      	eors	r6, r7
20027304:	4065      	eors	r5, r4
20027306:	064f      	lsls	r7, r1, #25
20027308:	e9dd 4103 	ldrd	r4, r1, [sp, #12]
2002730c:	430c      	orrs	r4, r1
2002730e:	9905      	ldr	r1, [sp, #20]
20027310:	ea47 17db 	orr.w	r7, r7, fp, lsr #7
20027314:	407e      	eors	r6, r7
20027316:	ea41 070b 	orr.w	r7, r1, fp
2002731a:	ea04 0109 	and.w	r1, r4, r9
2002731e:	9101      	str	r1, [sp, #4]
20027320:	e9dd 4103 	ldrd	r4, r1, [sp, #12]
20027324:	ea01 0e04 	and.w	lr, r1, r4
20027328:	9905      	ldr	r1, [sp, #20]
2002732a:	ea07 0708 	and.w	r7, r7, r8
2002732e:	ea01 0c0b 	and.w	ip, r1, fp
20027332:	9901      	ldr	r1, [sp, #4]
20027334:	ea47 070c 	orr.w	r7, r7, ip
20027338:	ea41 040e 	orr.w	r4, r1, lr
2002733c:	1934      	adds	r4, r6, r4
2002733e:	eb45 0507 	adc.w	r5, r5, r7
20027342:	18e3      	adds	r3, r4, r3
20027344:	9301      	str	r3, [sp, #4]
20027346:	eb42 0305 	adc.w	r3, r2, r5
2002734a:	9302      	str	r3, [sp, #8]
2002734c:	9b00      	ldr	r3, [sp, #0]
2002734e:	9a00      	ldr	r2, [sp, #0]
20027350:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
20027352:	9906      	ldr	r1, [sp, #24]
20027354:	6b52      	ldr	r2, [r2, #52]	@ 0x34
20027356:	e9d0 450c 	ldrd	r4, r5, [r0, #48]	@ 0x30
2002735a:	191b      	adds	r3, r3, r4
2002735c:	eb42 0205 	adc.w	r2, r2, r5
20027360:	185b      	adds	r3, r3, r1
20027362:	9907      	ldr	r1, [sp, #28]
20027364:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
20027366:	eb41 0202 	adc.w	r2, r1, r2
2002736a:	990c      	ldr	r1, [sp, #48]	@ 0x30
2002736c:	ea81 0504 	eor.w	r5, r1, r4
20027370:	990d      	ldr	r1, [sp, #52]	@ 0x34
20027372:	9c0b      	ldr	r4, [sp, #44]	@ 0x2c
20027374:	404c      	eors	r4, r1
20027376:	9908      	ldr	r1, [sp, #32]
20027378:	400d      	ands	r5, r1
2002737a:	9909      	ldr	r1, [sp, #36]	@ 0x24
2002737c:	400c      	ands	r4, r1
2002737e:	990c      	ldr	r1, [sp, #48]	@ 0x30
20027380:	404d      	eors	r5, r1
20027382:	990d      	ldr	r1, [sp, #52]	@ 0x34
20027384:	195b      	adds	r3, r3, r5
20027386:	ea84 0401 	eor.w	r4, r4, r1
2002738a:	9908      	ldr	r1, [sp, #32]
2002738c:	eb42 0204 	adc.w	r2, r2, r4
20027390:	0b8e      	lsrs	r6, r1, #14
20027392:	9909      	ldr	r1, [sp, #36]	@ 0x24
20027394:	ea46 4681 	orr.w	r6, r6, r1, lsl #18
20027398:	0b8c      	lsrs	r4, r1, #14
2002739a:	9908      	ldr	r1, [sp, #32]
2002739c:	ea44 4481 	orr.w	r4, r4, r1, lsl #18
200273a0:	0c8f      	lsrs	r7, r1, #18
200273a2:	9909      	ldr	r1, [sp, #36]	@ 0x24
200273a4:	ea47 3781 	orr.w	r7, r7, r1, lsl #14
200273a8:	0c8d      	lsrs	r5, r1, #18
200273aa:	9908      	ldr	r1, [sp, #32]
200273ac:	407e      	eors	r6, r7
200273ae:	ea45 3581 	orr.w	r5, r5, r1, lsl #14
200273b2:	406c      	eors	r4, r5
200273b4:	05cd      	lsls	r5, r1, #23
200273b6:	9909      	ldr	r1, [sp, #36]	@ 0x24
200273b8:	ea45 2551 	orr.w	r5, r5, r1, lsr #9
200273bc:	05cf      	lsls	r7, r1, #23
200273be:	9908      	ldr	r1, [sp, #32]
200273c0:	4075      	eors	r5, r6
200273c2:	ea47 2751 	orr.w	r7, r7, r1, lsr #9
200273c6:	195b      	adds	r3, r3, r5
200273c8:	ea84 0407 	eor.w	r4, r4, r7
200273cc:	eb42 0204 	adc.w	r2, r2, r4
200273d0:	eb19 0103 	adds.w	r1, r9, r3
200273d4:	9106      	str	r1, [sp, #24]
200273d6:	eb48 0102 	adc.w	r1, r8, r2
200273da:	9107      	str	r1, [sp, #28]
200273dc:	9901      	ldr	r1, [sp, #4]
200273de:	0f0e      	lsrs	r6, r1, #28
200273e0:	9902      	ldr	r1, [sp, #8]
200273e2:	ea46 1601 	orr.w	r6, r6, r1, lsl #4
200273e6:	0f0d      	lsrs	r5, r1, #28
200273e8:	9901      	ldr	r1, [sp, #4]
200273ea:	ea45 1501 	orr.w	r5, r5, r1, lsl #4
200273ee:	078f      	lsls	r7, r1, #30
200273f0:	9902      	ldr	r1, [sp, #8]
200273f2:	ea47 0791 	orr.w	r7, r7, r1, lsr #2
200273f6:	078c      	lsls	r4, r1, #30
200273f8:	9901      	ldr	r1, [sp, #4]
200273fa:	407e      	eors	r6, r7
200273fc:	ea44 0491 	orr.w	r4, r4, r1, lsr #2
20027400:	064f      	lsls	r7, r1, #25
20027402:	9902      	ldr	r1, [sp, #8]
20027404:	4065      	eors	r5, r4
20027406:	ea47 17d1 	orr.w	r7, r7, r1, lsr #7
2002740a:	064c      	lsls	r4, r1, #25
2002740c:	9901      	ldr	r1, [sp, #4]
2002740e:	407e      	eors	r6, r7
20027410:	ea44 14d1 	orr.w	r4, r4, r1, lsr #7
20027414:	4065      	eors	r5, r4
20027416:	9903      	ldr	r1, [sp, #12]
20027418:	9c01      	ldr	r4, [sp, #4]
2002741a:	430c      	orrs	r4, r1
2002741c:	9902      	ldr	r1, [sp, #8]
2002741e:	ea4b 0701 	orr.w	r7, fp, r1
20027422:	9904      	ldr	r1, [sp, #16]
20027424:	ea04 0801 	and.w	r8, r4, r1
20027428:	9905      	ldr	r1, [sp, #20]
2002742a:	9c01      	ldr	r4, [sp, #4]
2002742c:	400f      	ands	r7, r1
2002742e:	9903      	ldr	r1, [sp, #12]
20027430:	ea01 0e04 	and.w	lr, r1, r4
20027434:	9902      	ldr	r1, [sp, #8]
20027436:	ea48 040e 	orr.w	r4, r8, lr
2002743a:	ea0b 0c01 	and.w	ip, fp, r1
2002743e:	1934      	adds	r4, r6, r4
20027440:	ea47 070c 	orr.w	r7, r7, ip
20027444:	eb45 0507 	adc.w	r5, r5, r7
20027448:	eb14 0c03 	adds.w	ip, r4, r3
2002744c:	9b00      	ldr	r3, [sp, #0]
2002744e:	eb42 0e05 	adc.w	lr, r2, r5
20027452:	6b9b      	ldr	r3, [r3, #56]	@ 0x38
20027454:	9a00      	ldr	r2, [sp, #0]
20027456:	e9d0 450e 	ldrd	r4, r5, [r0, #56]	@ 0x38
2002745a:	6bd2      	ldr	r2, [r2, #60]	@ 0x3c
2002745c:	191c      	adds	r4, r3, r4
2002745e:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
20027460:	eb42 0205 	adc.w	r2, r2, r5
20027464:	18e4      	adds	r4, r4, r3
20027466:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
20027468:	9908      	ldr	r1, [sp, #32]
2002746a:	eb43 0202 	adc.w	r2, r3, r2
2002746e:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20027470:	3040      	adds	r0, #64	@ 0x40
20027472:	ea83 0501 	eor.w	r5, r3, r1
20027476:	9909      	ldr	r1, [sp, #36]	@ 0x24
20027478:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
2002747a:	404b      	eors	r3, r1
2002747c:	9906      	ldr	r1, [sp, #24]
2002747e:	400d      	ands	r5, r1
20027480:	9907      	ldr	r1, [sp, #28]
20027482:	400b      	ands	r3, r1
20027484:	990a      	ldr	r1, [sp, #40]	@ 0x28
20027486:	404d      	eors	r5, r1
20027488:	990b      	ldr	r1, [sp, #44]	@ 0x2c
2002748a:	1964      	adds	r4, r4, r5
2002748c:	ea83 0301 	eor.w	r3, r3, r1
20027490:	eb42 0203 	adc.w	r2, r2, r3
20027494:	9b06      	ldr	r3, [sp, #24]
20027496:	9906      	ldr	r1, [sp, #24]
20027498:	0b9e      	lsrs	r6, r3, #14
2002749a:	9b07      	ldr	r3, [sp, #28]
2002749c:	0c8f      	lsrs	r7, r1, #18
2002749e:	ea46 4683 	orr.w	r6, r6, r3, lsl #18
200274a2:	0b9b      	lsrs	r3, r3, #14
200274a4:	ea43 4381 	orr.w	r3, r3, r1, lsl #18
200274a8:	9907      	ldr	r1, [sp, #28]
200274aa:	ea47 3781 	orr.w	r7, r7, r1, lsl #14
200274ae:	0c8d      	lsrs	r5, r1, #18
200274b0:	9906      	ldr	r1, [sp, #24]
200274b2:	407e      	eors	r6, r7
200274b4:	ea45 3581 	orr.w	r5, r5, r1, lsl #14
200274b8:	406b      	eors	r3, r5
200274ba:	05cd      	lsls	r5, r1, #23
200274bc:	9907      	ldr	r1, [sp, #28]
200274be:	ea45 2551 	orr.w	r5, r5, r1, lsr #9
200274c2:	05cf      	lsls	r7, r1, #23
200274c4:	9906      	ldr	r1, [sp, #24]
200274c6:	4075      	eors	r5, r6
200274c8:	ea47 2751 	orr.w	r7, r7, r1, lsr #9
200274cc:	1964      	adds	r4, r4, r5
200274ce:	ea83 0307 	eor.w	r3, r3, r7
200274d2:	eb42 0203 	adc.w	r2, r2, r3
200274d6:	9b04      	ldr	r3, [sp, #16]
200274d8:	ea4f 751e 	mov.w	r5, lr, lsr #28
200274dc:	191b      	adds	r3, r3, r4
200274de:	9304      	str	r3, [sp, #16]
200274e0:	9b05      	ldr	r3, [sp, #20]
200274e2:	ea4f 761c 	mov.w	r6, ip, lsr #28
200274e6:	eb43 0302 	adc.w	r3, r3, r2
200274ea:	9305      	str	r3, [sp, #20]
200274ec:	ea4f 738e 	mov.w	r3, lr, lsl #30
200274f0:	ea43 039c 	orr.w	r3, r3, ip, lsr #2
200274f4:	ea45 150c 	orr.w	r5, r5, ip, lsl #4
200274f8:	ea4f 778c 	mov.w	r7, ip, lsl #30
200274fc:	ea47 079e 	orr.w	r7, r7, lr, lsr #2
20027500:	405d      	eors	r5, r3
20027502:	ea46 160e 	orr.w	r6, r6, lr, lsl #4
20027506:	ea4f 634e 	mov.w	r3, lr, lsl #25
2002750a:	9902      	ldr	r1, [sp, #8]
2002750c:	407e      	eors	r6, r7
2002750e:	ea43 13dc 	orr.w	r3, r3, ip, lsr #7
20027512:	ea4f 674c 	mov.w	r7, ip, lsl #25
20027516:	ea47 17de 	orr.w	r7, r7, lr, lsr #7
2002751a:	405d      	eors	r5, r3
2002751c:	9b01      	ldr	r3, [sp, #4]
2002751e:	407e      	eors	r6, r7
20027520:	ea41 070e 	orr.w	r7, r1, lr
20027524:	9903      	ldr	r1, [sp, #12]
20027526:	ea43 030c 	orr.w	r3, r3, ip
2002752a:	400b      	ands	r3, r1
2002752c:	9901      	ldr	r1, [sp, #4]
2002752e:	ea07 070b 	and.w	r7, r7, fp
20027532:	ea01 090c 	and.w	r9, r1, ip
20027536:	9902      	ldr	r1, [sp, #8]
20027538:	ea43 0309 	orr.w	r3, r3, r9
2002753c:	ea01 080e 	and.w	r8, r1, lr
20027540:	9900      	ldr	r1, [sp, #0]
20027542:	18f3      	adds	r3, r6, r3
20027544:	f101 0140 	add.w	r1, r1, #64	@ 0x40
20027548:	9100      	str	r1, [sp, #0]
2002754a:	ea47 0708 	orr.w	r7, r7, r8
2002754e:	eb45 0507 	adc.w	r5, r5, r7
20027552:	4928      	ldr	r1, [pc, #160]	@ (200275f4 <mbedtls_sha512_process+0xa54>)
20027554:	191b      	adds	r3, r3, r4
20027556:	9c00      	ldr	r4, [sp, #0]
20027558:	eb42 0205 	adc.w	r2, r2, r5
2002755c:	42a1      	cmp	r1, r4
2002755e:	f47f abe3 	bne.w	20026d28 <mbedtls_sha512_process+0x188>
20027562:	990e      	ldr	r1, [sp, #56]	@ 0x38
20027564:	18cb      	adds	r3, r1, r3
20027566:	990f      	ldr	r1, [sp, #60]	@ 0x3c
20027568:	eb42 0201 	adc.w	r2, r2, r1
2002756c:	e9ca 3204 	strd	r3, r2, [sl, #16]
20027570:	9b10      	ldr	r3, [sp, #64]	@ 0x40
20027572:	9a11      	ldr	r2, [sp, #68]	@ 0x44
20027574:	eb13 030c 	adds.w	r3, r3, ip
20027578:	eb4e 0202 	adc.w	r2, lr, r2
2002757c:	e9ca 3206 	strd	r3, r2, [sl, #24]
20027580:	9a01      	ldr	r2, [sp, #4]
20027582:	9b12      	ldr	r3, [sp, #72]	@ 0x48
20027584:	9913      	ldr	r1, [sp, #76]	@ 0x4c
20027586:	189b      	adds	r3, r3, r2
20027588:	9a02      	ldr	r2, [sp, #8]
2002758a:	eb42 0201 	adc.w	r2, r2, r1
2002758e:	e9ca 3208 	strd	r3, r2, [sl, #32]
20027592:	9a03      	ldr	r2, [sp, #12]
20027594:	9b14      	ldr	r3, [sp, #80]	@ 0x50
20027596:	9917      	ldr	r1, [sp, #92]	@ 0x5c
20027598:	189b      	adds	r3, r3, r2
2002759a:	9a15      	ldr	r2, [sp, #84]	@ 0x54
2002759c:	eb4b 0202 	adc.w	r2, fp, r2
200275a0:	e9ca 320a 	strd	r3, r2, [sl, #40]	@ 0x28
200275a4:	9a04      	ldr	r2, [sp, #16]
200275a6:	9b16      	ldr	r3, [sp, #88]	@ 0x58
200275a8:	189b      	adds	r3, r3, r2
200275aa:	9a05      	ldr	r2, [sp, #20]
200275ac:	eb42 0201 	adc.w	r2, r2, r1
200275b0:	e9ca 320c 	strd	r3, r2, [sl, #48]	@ 0x30
200275b4:	9b18      	ldr	r3, [sp, #96]	@ 0x60
200275b6:	9a06      	ldr	r2, [sp, #24]
200275b8:	9919      	ldr	r1, [sp, #100]	@ 0x64
200275ba:	189a      	adds	r2, r3, r2
200275bc:	9b07      	ldr	r3, [sp, #28]
200275be:	eb43 0301 	adc.w	r3, r3, r1
200275c2:	e9ca 230e 	strd	r2, r3, [sl, #56]	@ 0x38
200275c6:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
200275c8:	9a08      	ldr	r2, [sp, #32]
200275ca:	991b      	ldr	r1, [sp, #108]	@ 0x6c
200275cc:	189a      	adds	r2, r3, r2
200275ce:	9b09      	ldr	r3, [sp, #36]	@ 0x24
200275d0:	eb43 0301 	adc.w	r3, r3, r1
200275d4:	e9ca 2310 	strd	r2, r3, [sl, #64]	@ 0x40
200275d8:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
200275da:	9a0a      	ldr	r2, [sp, #40]	@ 0x28
200275dc:	991d      	ldr	r1, [sp, #116]	@ 0x74
200275de:	189a      	adds	r2, r3, r2
200275e0:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
200275e2:	eb43 0301 	adc.w	r3, r3, r1
200275e6:	e9ca 2312 	strd	r2, r3, [sl, #72]	@ 0x48
200275ea:	f50d 7d3f 	add.w	sp, sp, #764	@ 0x2fc
200275ee:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200275f2:	bf00      	nop
200275f4:	2002c388 	.word	0x2002c388

200275f8 <mbedtls_sha512_update.part.0>:
200275f8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200275fc:	4615      	mov	r5, r2
200275fe:	e9d0 3200 	ldrd	r3, r2, [r0]
20027602:	f003 077f 	and.w	r7, r3, #127	@ 0x7f
20027606:	195b      	adds	r3, r3, r5
20027608:	f152 0200 	adcs.w	r2, r2, #0
2002760c:	460e      	mov	r6, r1
2002760e:	f04f 0100 	mov.w	r1, #0
20027612:	bf28      	it	cs
20027614:	2101      	movcs	r1, #1
20027616:	4604      	mov	r4, r0
20027618:	e9c0 3200 	strd	r3, r2, [r0]
2002761c:	b131      	cbz	r1, 2002762c <mbedtls_sha512_update.part.0+0x34>
2002761e:	e9d0 3202 	ldrd	r3, r2, [r0, #8]
20027622:	3301      	adds	r3, #1
20027624:	f142 0200 	adc.w	r2, r2, #0
20027628:	e9c0 3202 	strd	r3, r2, [r0, #8]
2002762c:	b19f      	cbz	r7, 20027656 <mbedtls_sha512_update.part.0+0x5e>
2002762e:	f1c7 0980 	rsb	r9, r7, #128	@ 0x80
20027632:	45a9      	cmp	r9, r5
20027634:	d80f      	bhi.n	20027656 <mbedtls_sha512_update.part.0+0x5e>
20027636:	f104 0850 	add.w	r8, r4, #80	@ 0x50
2002763a:	4631      	mov	r1, r6
2002763c:	464a      	mov	r2, r9
2002763e:	eb08 0007 	add.w	r0, r8, r7
20027642:	f003 fa05 	bl	2002aa50 <memcpy>
20027646:	3d80      	subs	r5, #128	@ 0x80
20027648:	4641      	mov	r1, r8
2002764a:	4620      	mov	r0, r4
2002764c:	443d      	add	r5, r7
2002764e:	f7ff faa7 	bl	20026ba0 <mbedtls_sha512_process>
20027652:	2700      	movs	r7, #0
20027654:	444e      	add	r6, r9
20027656:	46a8      	mov	r8, r5
20027658:	eb05 0906 	add.w	r9, r5, r6
2002765c:	e004      	b.n	20027668 <mbedtls_sha512_update.part.0+0x70>
2002765e:	4620      	mov	r0, r4
20027660:	f7ff fa9e 	bl	20026ba0 <mbedtls_sha512_process>
20027664:	f1a8 0880 	sub.w	r8, r8, #128	@ 0x80
20027668:	f1b8 0f7f 	cmp.w	r8, #127	@ 0x7f
2002766c:	eba9 0108 	sub.w	r1, r9, r8
20027670:	d8f5      	bhi.n	2002765e <mbedtls_sha512_update.part.0+0x66>
20027672:	f06f 037f 	mvn.w	r3, #127	@ 0x7f
20027676:	09e9      	lsrs	r1, r5, #7
20027678:	4359      	muls	r1, r3
2002767a:	186a      	adds	r2, r5, r1
2002767c:	d007      	beq.n	2002768e <mbedtls_sha512_update.part.0+0x96>
2002767e:	f104 0050 	add.w	r0, r4, #80	@ 0x50
20027682:	1a71      	subs	r1, r6, r1
20027684:	4438      	add	r0, r7
20027686:	e8bd 43f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
2002768a:	f003 b9e1 	b.w	2002aa50 <memcpy>
2002768e:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}

20027692 <mbedtls_sha512_update>:
20027692:	b10a      	cbz	r2, 20027698 <mbedtls_sha512_update+0x6>
20027694:	f7ff bfb0 	b.w	200275f8 <mbedtls_sha512_update.part.0>
20027698:	4770      	bx	lr
	...

2002769c <mbedtls_sha512_finish>:
2002769c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002769e:	4604      	mov	r4, r0
200276a0:	e9d0 2300 	ldrd	r2, r3, [r0]
200276a4:	460d      	mov	r5, r1
200276a6:	e9d0 6102 	ldrd	r6, r1, [r0, #8]
200276aa:	00c9      	lsls	r1, r1, #3
200276ac:	ea41 7156 	orr.w	r1, r1, r6, lsr #29
200276b0:	b085      	sub	sp, #20
200276b2:	0e0f      	lsrs	r7, r1, #24
200276b4:	0f58      	lsrs	r0, r3, #29
200276b6:	00db      	lsls	r3, r3, #3
200276b8:	ea43 7352 	orr.w	r3, r3, r2, lsr #29
200276bc:	f88d 7000 	strb.w	r7, [sp]
200276c0:	0c0f      	lsrs	r7, r1, #16
200276c2:	f88d 7001 	strb.w	r7, [sp, #1]
200276c6:	f88d 1003 	strb.w	r1, [sp, #3]
200276ca:	0a0f      	lsrs	r7, r1, #8
200276cc:	0e19      	lsrs	r1, r3, #24
200276ce:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200276d2:	f88d 1008 	strb.w	r1, [sp, #8]
200276d6:	00d6      	lsls	r6, r2, #3
200276d8:	0c19      	lsrs	r1, r3, #16
200276da:	f002 027f 	and.w	r2, r2, #127	@ 0x7f
200276de:	2a6f      	cmp	r2, #111	@ 0x6f
200276e0:	ba00      	rev	r0, r0
200276e2:	f88d 1009 	strb.w	r1, [sp, #9]
200276e6:	ea4f 2113 	mov.w	r1, r3, lsr #8
200276ea:	bf94      	ite	ls
200276ec:	f1c2 0270 	rsbls	r2, r2, #112	@ 0x70
200276f0:	f1c2 02f0 	rsbhi	r2, r2, #240	@ 0xf0
200276f4:	9001      	str	r0, [sp, #4]
200276f6:	f88d 100a 	strb.w	r1, [sp, #10]
200276fa:	4620      	mov	r0, r4
200276fc:	4969      	ldr	r1, [pc, #420]	@ (200278a4 <mbedtls_sha512_finish+0x208>)
200276fe:	ba36      	rev	r6, r6
20027700:	f88d 300b 	strb.w	r3, [sp, #11]
20027704:	f88d 7002 	strb.w	r7, [sp, #2]
20027708:	9603      	str	r6, [sp, #12]
2002770a:	f7ff ffc2 	bl	20027692 <mbedtls_sha512_update>
2002770e:	2210      	movs	r2, #16
20027710:	4669      	mov	r1, sp
20027712:	4620      	mov	r0, r4
20027714:	f7ff ff70 	bl	200275f8 <mbedtls_sha512_update.part.0>
20027718:	7de3      	ldrb	r3, [r4, #23]
2002771a:	702b      	strb	r3, [r5, #0]
2002771c:	8ae3      	ldrh	r3, [r4, #22]
2002771e:	706b      	strb	r3, [r5, #1]
20027720:	6963      	ldr	r3, [r4, #20]
20027722:	0a1b      	lsrs	r3, r3, #8
20027724:	70ab      	strb	r3, [r5, #2]
20027726:	6963      	ldr	r3, [r4, #20]
20027728:	70eb      	strb	r3, [r5, #3]
2002772a:	7ce3      	ldrb	r3, [r4, #19]
2002772c:	712b      	strb	r3, [r5, #4]
2002772e:	8a63      	ldrh	r3, [r4, #18]
20027730:	716b      	strb	r3, [r5, #5]
20027732:	6923      	ldr	r3, [r4, #16]
20027734:	0a1b      	lsrs	r3, r3, #8
20027736:	71ab      	strb	r3, [r5, #6]
20027738:	6923      	ldr	r3, [r4, #16]
2002773a:	71eb      	strb	r3, [r5, #7]
2002773c:	7fe3      	ldrb	r3, [r4, #31]
2002773e:	722b      	strb	r3, [r5, #8]
20027740:	8be3      	ldrh	r3, [r4, #30]
20027742:	726b      	strb	r3, [r5, #9]
20027744:	69e3      	ldr	r3, [r4, #28]
20027746:	0a1b      	lsrs	r3, r3, #8
20027748:	72ab      	strb	r3, [r5, #10]
2002774a:	69e3      	ldr	r3, [r4, #28]
2002774c:	72eb      	strb	r3, [r5, #11]
2002774e:	7ee3      	ldrb	r3, [r4, #27]
20027750:	732b      	strb	r3, [r5, #12]
20027752:	8b63      	ldrh	r3, [r4, #26]
20027754:	736b      	strb	r3, [r5, #13]
20027756:	69a3      	ldr	r3, [r4, #24]
20027758:	0a1b      	lsrs	r3, r3, #8
2002775a:	73ab      	strb	r3, [r5, #14]
2002775c:	69a3      	ldr	r3, [r4, #24]
2002775e:	73eb      	strb	r3, [r5, #15]
20027760:	f894 3027 	ldrb.w	r3, [r4, #39]	@ 0x27
20027764:	742b      	strb	r3, [r5, #16]
20027766:	8ce3      	ldrh	r3, [r4, #38]	@ 0x26
20027768:	746b      	strb	r3, [r5, #17]
2002776a:	6a63      	ldr	r3, [r4, #36]	@ 0x24
2002776c:	0a1b      	lsrs	r3, r3, #8
2002776e:	74ab      	strb	r3, [r5, #18]
20027770:	6a63      	ldr	r3, [r4, #36]	@ 0x24
20027772:	74eb      	strb	r3, [r5, #19]
20027774:	f894 3023 	ldrb.w	r3, [r4, #35]	@ 0x23
20027778:	752b      	strb	r3, [r5, #20]
2002777a:	8c63      	ldrh	r3, [r4, #34]	@ 0x22
2002777c:	756b      	strb	r3, [r5, #21]
2002777e:	6a23      	ldr	r3, [r4, #32]
20027780:	0a1b      	lsrs	r3, r3, #8
20027782:	75ab      	strb	r3, [r5, #22]
20027784:	6a23      	ldr	r3, [r4, #32]
20027786:	75eb      	strb	r3, [r5, #23]
20027788:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
2002778c:	762b      	strb	r3, [r5, #24]
2002778e:	8de3      	ldrh	r3, [r4, #46]	@ 0x2e
20027790:	766b      	strb	r3, [r5, #25]
20027792:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
20027794:	0a1b      	lsrs	r3, r3, #8
20027796:	76ab      	strb	r3, [r5, #26]
20027798:	6ae3      	ldr	r3, [r4, #44]	@ 0x2c
2002779a:	76eb      	strb	r3, [r5, #27]
2002779c:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200277a0:	772b      	strb	r3, [r5, #28]
200277a2:	8d63      	ldrh	r3, [r4, #42]	@ 0x2a
200277a4:	776b      	strb	r3, [r5, #29]
200277a6:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
200277a8:	0a1b      	lsrs	r3, r3, #8
200277aa:	77ab      	strb	r3, [r5, #30]
200277ac:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
200277ae:	77eb      	strb	r3, [r5, #31]
200277b0:	f894 3037 	ldrb.w	r3, [r4, #55]	@ 0x37
200277b4:	f885 3020 	strb.w	r3, [r5, #32]
200277b8:	8ee3      	ldrh	r3, [r4, #54]	@ 0x36
200277ba:	f885 3021 	strb.w	r3, [r5, #33]	@ 0x21
200277be:	6b63      	ldr	r3, [r4, #52]	@ 0x34
200277c0:	0a1b      	lsrs	r3, r3, #8
200277c2:	f885 3022 	strb.w	r3, [r5, #34]	@ 0x22
200277c6:	6b63      	ldr	r3, [r4, #52]	@ 0x34
200277c8:	f885 3023 	strb.w	r3, [r5, #35]	@ 0x23
200277cc:	f894 3033 	ldrb.w	r3, [r4, #51]	@ 0x33
200277d0:	f885 3024 	strb.w	r3, [r5, #36]	@ 0x24
200277d4:	8e63      	ldrh	r3, [r4, #50]	@ 0x32
200277d6:	f885 3025 	strb.w	r3, [r5, #37]	@ 0x25
200277da:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200277dc:	0a1b      	lsrs	r3, r3, #8
200277de:	f885 3026 	strb.w	r3, [r5, #38]	@ 0x26
200277e2:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200277e4:	f885 3027 	strb.w	r3, [r5, #39]	@ 0x27
200277e8:	f894 303f 	ldrb.w	r3, [r4, #63]	@ 0x3f
200277ec:	f885 3028 	strb.w	r3, [r5, #40]	@ 0x28
200277f0:	8fe3      	ldrh	r3, [r4, #62]	@ 0x3e
200277f2:	f885 3029 	strb.w	r3, [r5, #41]	@ 0x29
200277f6:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
200277f8:	0a1b      	lsrs	r3, r3, #8
200277fa:	f885 302a 	strb.w	r3, [r5, #42]	@ 0x2a
200277fe:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20027800:	f885 302b 	strb.w	r3, [r5, #43]	@ 0x2b
20027804:	f894 303b 	ldrb.w	r3, [r4, #59]	@ 0x3b
20027808:	f885 302c 	strb.w	r3, [r5, #44]	@ 0x2c
2002780c:	8f63      	ldrh	r3, [r4, #58]	@ 0x3a
2002780e:	f885 302d 	strb.w	r3, [r5, #45]	@ 0x2d
20027812:	6ba3      	ldr	r3, [r4, #56]	@ 0x38
20027814:	0a1b      	lsrs	r3, r3, #8
20027816:	f885 302e 	strb.w	r3, [r5, #46]	@ 0x2e
2002781a:	6ba3      	ldr	r3, [r4, #56]	@ 0x38
2002781c:	f885 302f 	strb.w	r3, [r5, #47]	@ 0x2f
20027820:	f8d4 30d0 	ldr.w	r3, [r4, #208]	@ 0xd0
20027824:	2b00      	cmp	r3, #0
20027826:	d13b      	bne.n	200278a0 <mbedtls_sha512_finish+0x204>
20027828:	f894 3047 	ldrb.w	r3, [r4, #71]	@ 0x47
2002782c:	f885 3030 	strb.w	r3, [r5, #48]	@ 0x30
20027830:	f8b4 3046 	ldrh.w	r3, [r4, #70]	@ 0x46
20027834:	f885 3031 	strb.w	r3, [r5, #49]	@ 0x31
20027838:	6c63      	ldr	r3, [r4, #68]	@ 0x44
2002783a:	0a1b      	lsrs	r3, r3, #8
2002783c:	f885 3032 	strb.w	r3, [r5, #50]	@ 0x32
20027840:	6c63      	ldr	r3, [r4, #68]	@ 0x44
20027842:	f885 3033 	strb.w	r3, [r5, #51]	@ 0x33
20027846:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
2002784a:	f885 3034 	strb.w	r3, [r5, #52]	@ 0x34
2002784e:	f8b4 3042 	ldrh.w	r3, [r4, #66]	@ 0x42
20027852:	f885 3035 	strb.w	r3, [r5, #53]	@ 0x35
20027856:	6c23      	ldr	r3, [r4, #64]	@ 0x40
20027858:	0a1b      	lsrs	r3, r3, #8
2002785a:	f885 3036 	strb.w	r3, [r5, #54]	@ 0x36
2002785e:	6c23      	ldr	r3, [r4, #64]	@ 0x40
20027860:	f885 3037 	strb.w	r3, [r5, #55]	@ 0x37
20027864:	f894 304f 	ldrb.w	r3, [r4, #79]	@ 0x4f
20027868:	f885 3038 	strb.w	r3, [r5, #56]	@ 0x38
2002786c:	f8b4 304e 	ldrh.w	r3, [r4, #78]	@ 0x4e
20027870:	f885 3039 	strb.w	r3, [r5, #57]	@ 0x39
20027874:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
20027876:	0a1b      	lsrs	r3, r3, #8
20027878:	f885 303a 	strb.w	r3, [r5, #58]	@ 0x3a
2002787c:	6ce3      	ldr	r3, [r4, #76]	@ 0x4c
2002787e:	f885 303b 	strb.w	r3, [r5, #59]	@ 0x3b
20027882:	f894 304b 	ldrb.w	r3, [r4, #75]	@ 0x4b
20027886:	f885 303c 	strb.w	r3, [r5, #60]	@ 0x3c
2002788a:	f8b4 304a 	ldrh.w	r3, [r4, #74]	@ 0x4a
2002788e:	f885 303d 	strb.w	r3, [r5, #61]	@ 0x3d
20027892:	6ca3      	ldr	r3, [r4, #72]	@ 0x48
20027894:	0a1b      	lsrs	r3, r3, #8
20027896:	f885 303e 	strb.w	r3, [r5, #62]	@ 0x3e
2002789a:	6ca3      	ldr	r3, [r4, #72]	@ 0x48
2002789c:	f885 303f 	strb.w	r3, [r5, #63]	@ 0x3f
200278a0:	b005      	add	sp, #20
200278a2:	bdf0      	pop	{r4, r5, r6, r7, pc}
200278a4:	2002c084 	.word	0x2002c084

200278a8 <mbedtls_sha512>:
200278a8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200278ac:	461c      	mov	r4, r3
200278ae:	b0b7      	sub	sp, #220	@ 0xdc
200278b0:	4606      	mov	r6, r0
200278b2:	4668      	mov	r0, sp
200278b4:	460f      	mov	r7, r1
200278b6:	4615      	mov	r5, r2
200278b8:	f7ff f8cc 	bl	20026a54 <mbedtls_sha512_init>
200278bc:	2c00      	cmp	r4, #0
200278be:	d03f      	beq.n	20027940 <mbedtls_sha512+0x98>
200278c0:	f20f 0bf4 	addw	fp, pc, #244	@ 0xf4
200278c4:	e9db ab00 	ldrd	sl, fp, [fp]
200278c8:	f20f 09f4 	addw	r9, pc, #244	@ 0xf4
200278cc:	e9d9 8900 	ldrd	r8, r9, [r9]
200278d0:	a13d      	add	r1, pc, #244	@ (adr r1, 200279c8 <mbedtls_sha512+0x120>)
200278d2:	e9d1 0100 	ldrd	r0, r1, [r1]
200278d6:	a33e      	add	r3, pc, #248	@ (adr r3, 200279d0 <mbedtls_sha512+0x128>)
200278d8:	e9d3 2300 	ldrd	r2, r3, [r3]
200278dc:	ed9f 4b24 	vldr	d4, [pc, #144]	@ 20027970 <mbedtls_sha512+0xc8>
200278e0:	ed9f 5b25 	vldr	d5, [pc, #148]	@ 20027978 <mbedtls_sha512+0xd0>
200278e4:	ed9f 6b26 	vldr	d6, [pc, #152]	@ 20027980 <mbedtls_sha512+0xd8>
200278e8:	ed9f 7b27 	vldr	d7, [pc, #156]	@ 20027988 <mbedtls_sha512+0xe0>
200278ec:	ed9f 3b28 	vldr	d3, [pc, #160]	@ 20027990 <mbedtls_sha512+0xe8>
200278f0:	e9cd 2312 	strd	r2, r3, [sp, #72]	@ 0x48
200278f4:	e9cd 0110 	strd	r0, r1, [sp, #64]	@ 0x40
200278f8:	463a      	mov	r2, r7
200278fa:	4631      	mov	r1, r6
200278fc:	4668      	mov	r0, sp
200278fe:	ed8d 3b00 	vstr	d3, [sp]
20027902:	ed8d 3b02 	vstr	d3, [sp, #8]
20027906:	ed8d 4b04 	vstr	d4, [sp, #16]
2002790a:	ed8d 5b06 	vstr	d5, [sp, #24]
2002790e:	ed8d 6b08 	vstr	d6, [sp, #32]
20027912:	ed8d 7b0a 	vstr	d7, [sp, #40]	@ 0x28
20027916:	e9cd ab0c 	strd	sl, fp, [sp, #48]	@ 0x30
2002791a:	e9cd 890e 	strd	r8, r9, [sp, #56]	@ 0x38
2002791e:	9434      	str	r4, [sp, #208]	@ 0xd0
20027920:	f7ff feb7 	bl	20027692 <mbedtls_sha512_update>
20027924:	4629      	mov	r1, r5
20027926:	4668      	mov	r0, sp
20027928:	f7ff feb8 	bl	2002769c <mbedtls_sha512_finish>
2002792c:	2300      	movs	r3, #0
2002792e:	461a      	mov	r2, r3
20027930:	f80d 2003 	strb.w	r2, [sp, r3]
20027934:	3301      	adds	r3, #1
20027936:	2bd8      	cmp	r3, #216	@ 0xd8
20027938:	d1fa      	bne.n	20027930 <mbedtls_sha512+0x88>
2002793a:	b037      	add	sp, #220	@ 0xdc
2002793c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20027940:	ed9f 4b15 	vldr	d4, [pc, #84]	@ 20027998 <mbedtls_sha512+0xf0>
20027944:	f20f 0b90 	addw	fp, pc, #144	@ 0x90
20027948:	e9db ab00 	ldrd	sl, fp, [fp]
2002794c:	f20f 0990 	addw	r9, pc, #144	@ 0x90
20027950:	e9d9 8900 	ldrd	r8, r9, [r9]
20027954:	a124      	add	r1, pc, #144	@ (adr r1, 200279e8 <mbedtls_sha512+0x140>)
20027956:	e9d1 0100 	ldrd	r0, r1, [r1]
2002795a:	a325      	add	r3, pc, #148	@ (adr r3, 200279f0 <mbedtls_sha512+0x148>)
2002795c:	e9d3 2300 	ldrd	r2, r3, [r3]
20027960:	ed9f 5b0f 	vldr	d5, [pc, #60]	@ 200279a0 <mbedtls_sha512+0xf8>
20027964:	ed9f 6b10 	vldr	d6, [pc, #64]	@ 200279a8 <mbedtls_sha512+0x100>
20027968:	ed9f 7b11 	vldr	d7, [pc, #68]	@ 200279b0 <mbedtls_sha512+0x108>
2002796c:	e7be      	b.n	200278ec <mbedtls_sha512+0x44>
2002796e:	bf00      	nop
20027970:	c1059ed8 	.word	0xc1059ed8
20027974:	cbbb9d5d 	.word	0xcbbb9d5d
20027978:	367cd507 	.word	0x367cd507
2002797c:	629a292a 	.word	0x629a292a
20027980:	3070dd17 	.word	0x3070dd17
20027984:	9159015a 	.word	0x9159015a
20027988:	f70e5939 	.word	0xf70e5939
2002798c:	152fecd8 	.word	0x152fecd8
	...
20027998:	f3bcc908 	.word	0xf3bcc908
2002799c:	6a09e667 	.word	0x6a09e667
200279a0:	84caa73b 	.word	0x84caa73b
200279a4:	bb67ae85 	.word	0xbb67ae85
200279a8:	fe94f82b 	.word	0xfe94f82b
200279ac:	3c6ef372 	.word	0x3c6ef372
200279b0:	5f1d36f1 	.word	0x5f1d36f1
200279b4:	a54ff53a 	.word	0xa54ff53a
200279b8:	ffc00b31 	.word	0xffc00b31
200279bc:	67332667 	.word	0x67332667
200279c0:	68581511 	.word	0x68581511
200279c4:	8eb44a87 	.word	0x8eb44a87
200279c8:	64f98fa7 	.word	0x64f98fa7
200279cc:	db0c2e0d 	.word	0xdb0c2e0d
200279d0:	befa4fa4 	.word	0xbefa4fa4
200279d4:	47b5481d 	.word	0x47b5481d
200279d8:	ade682d1 	.word	0xade682d1
200279dc:	510e527f 	.word	0x510e527f
200279e0:	2b3e6c1f 	.word	0x2b3e6c1f
200279e4:	9b05688c 	.word	0x9b05688c
200279e8:	fb41bd6b 	.word	0xfb41bd6b
200279ec:	1f83d9ab 	.word	0x1f83d9ab
200279f0:	137e2179 	.word	0x137e2179
200279f4:	5be0cd19 	.word	0x5be0cd19

200279f8 <mbedtls_asn1_get_len>:
200279f8:	b570      	push	{r4, r5, r6, lr}
200279fa:	6803      	ldr	r3, [r0, #0]
200279fc:	1acd      	subs	r5, r1, r3
200279fe:	2d00      	cmp	r5, #0
20027a00:	dc02      	bgt.n	20027a08 <mbedtls_asn1_get_len+0x10>
20027a02:	f06f 005f 	mvn.w	r0, #95	@ 0x5f
20027a06:	bd70      	pop	{r4, r5, r6, pc}
20027a08:	f993 6000 	ldrsb.w	r6, [r3]
20027a0c:	781c      	ldrb	r4, [r3, #0]
20027a0e:	2e00      	cmp	r6, #0
20027a10:	db0a      	blt.n	20027a28 <mbedtls_asn1_get_len+0x30>
20027a12:	1c5c      	adds	r4, r3, #1
20027a14:	6004      	str	r4, [r0, #0]
20027a16:	781b      	ldrb	r3, [r3, #0]
20027a18:	6013      	str	r3, [r2, #0]
20027a1a:	6803      	ldr	r3, [r0, #0]
20027a1c:	1ac9      	subs	r1, r1, r3
20027a1e:	6813      	ldr	r3, [r2, #0]
20027a20:	428b      	cmp	r3, r1
20027a22:	d8ee      	bhi.n	20027a02 <mbedtls_asn1_get_len+0xa>
20027a24:	2000      	movs	r0, #0
20027a26:	e7ee      	b.n	20027a06 <mbedtls_asn1_get_len+0xe>
20027a28:	f004 047f 	and.w	r4, r4, #127	@ 0x7f
20027a2c:	3c01      	subs	r4, #1
20027a2e:	2c03      	cmp	r4, #3
20027a30:	d82b      	bhi.n	20027a8a <mbedtls_asn1_get_len+0x92>
20027a32:	e8df f004 	tbb	[pc, r4]
20027a36:	0a02      	.short	0x0a02
20027a38:	2114      	.short	0x2114
20027a3a:	2d01      	cmp	r5, #1
20027a3c:	d0e1      	beq.n	20027a02 <mbedtls_asn1_get_len+0xa>
20027a3e:	785b      	ldrb	r3, [r3, #1]
20027a40:	6013      	str	r3, [r2, #0]
20027a42:	6803      	ldr	r3, [r0, #0]
20027a44:	3302      	adds	r3, #2
20027a46:	6003      	str	r3, [r0, #0]
20027a48:	e7e7      	b.n	20027a1a <mbedtls_asn1_get_len+0x22>
20027a4a:	2d02      	cmp	r5, #2
20027a4c:	ddd9      	ble.n	20027a02 <mbedtls_asn1_get_len+0xa>
20027a4e:	f8b3 3001 	ldrh.w	r3, [r3, #1]
20027a52:	ba5b      	rev16	r3, r3
20027a54:	b29b      	uxth	r3, r3
20027a56:	6013      	str	r3, [r2, #0]
20027a58:	6803      	ldr	r3, [r0, #0]
20027a5a:	3303      	adds	r3, #3
20027a5c:	e7f3      	b.n	20027a46 <mbedtls_asn1_get_len+0x4e>
20027a5e:	2d03      	cmp	r5, #3
20027a60:	ddcf      	ble.n	20027a02 <mbedtls_asn1_get_len+0xa>
20027a62:	789c      	ldrb	r4, [r3, #2]
20027a64:	785d      	ldrb	r5, [r3, #1]
20027a66:	0224      	lsls	r4, r4, #8
20027a68:	78db      	ldrb	r3, [r3, #3]
20027a6a:	ea44 4405 	orr.w	r4, r4, r5, lsl #16
20027a6e:	4323      	orrs	r3, r4
20027a70:	6013      	str	r3, [r2, #0]
20027a72:	6803      	ldr	r3, [r0, #0]
20027a74:	3304      	adds	r3, #4
20027a76:	e7e6      	b.n	20027a46 <mbedtls_asn1_get_len+0x4e>
20027a78:	2d04      	cmp	r5, #4
20027a7a:	ddc2      	ble.n	20027a02 <mbedtls_asn1_get_len+0xa>
20027a7c:	f8d3 3001 	ldr.w	r3, [r3, #1]
20027a80:	ba1b      	rev	r3, r3
20027a82:	6013      	str	r3, [r2, #0]
20027a84:	6803      	ldr	r3, [r0, #0]
20027a86:	3305      	adds	r3, #5
20027a88:	e7dd      	b.n	20027a46 <mbedtls_asn1_get_len+0x4e>
20027a8a:	f06f 0063 	mvn.w	r0, #99	@ 0x63
20027a8e:	e7ba      	b.n	20027a06 <mbedtls_asn1_get_len+0xe>

20027a90 <mbedtls_asn1_get_tag>:
20027a90:	b470      	push	{r4, r5, r6}
20027a92:	6804      	ldr	r4, [r0, #0]
20027a94:	1b0e      	subs	r6, r1, r4
20027a96:	2e00      	cmp	r6, #0
20027a98:	dd07      	ble.n	20027aaa <mbedtls_asn1_get_tag+0x1a>
20027a9a:	7826      	ldrb	r6, [r4, #0]
20027a9c:	429e      	cmp	r6, r3
20027a9e:	d108      	bne.n	20027ab2 <mbedtls_asn1_get_tag+0x22>
20027aa0:	3401      	adds	r4, #1
20027aa2:	6004      	str	r4, [r0, #0]
20027aa4:	bc70      	pop	{r4, r5, r6}
20027aa6:	f7ff bfa7 	b.w	200279f8 <mbedtls_asn1_get_len>
20027aaa:	f06f 005f 	mvn.w	r0, #95	@ 0x5f
20027aae:	bc70      	pop	{r4, r5, r6}
20027ab0:	4770      	bx	lr
20027ab2:	f06f 0061 	mvn.w	r0, #97	@ 0x61
20027ab6:	e7fa      	b.n	20027aae <mbedtls_asn1_get_tag+0x1e>

20027ab8 <mbedtls_asn1_get_mpi>:
20027ab8:	b573      	push	{r0, r1, r4, r5, r6, lr}
20027aba:	2302      	movs	r3, #2
20027abc:	4615      	mov	r5, r2
20027abe:	aa01      	add	r2, sp, #4
20027ac0:	4604      	mov	r4, r0
20027ac2:	f7ff ffe5 	bl	20027a90 <mbedtls_asn1_get_tag>
20027ac6:	b940      	cbnz	r0, 20027ada <mbedtls_asn1_get_mpi+0x22>
20027ac8:	9e01      	ldr	r6, [sp, #4]
20027aca:	4628      	mov	r0, r5
20027acc:	4632      	mov	r2, r6
20027ace:	6821      	ldr	r1, [r4, #0]
20027ad0:	f000 fad4 	bl	2002807c <mbedtls_mpi_read_binary>
20027ad4:	6823      	ldr	r3, [r4, #0]
20027ad6:	4433      	add	r3, r6
20027ad8:	6023      	str	r3, [r4, #0]
20027ada:	b002      	add	sp, #8
20027adc:	bd70      	pop	{r4, r5, r6, pc}

20027ade <mbedtls_asn1_get_bitstring_null>:
20027ade:	b538      	push	{r3, r4, r5, lr}
20027ae0:	2303      	movs	r3, #3
20027ae2:	4604      	mov	r4, r0
20027ae4:	4615      	mov	r5, r2
20027ae6:	f7ff ffd3 	bl	20027a90 <mbedtls_asn1_get_tag>
20027aea:	b958      	cbnz	r0, 20027b04 <mbedtls_asn1_get_bitstring_null+0x26>
20027aec:	6813      	ldr	r3, [r2, #0]
20027aee:	1e5a      	subs	r2, r3, #1
20027af0:	2b01      	cmp	r3, #1
20027af2:	602a      	str	r2, [r5, #0]
20027af4:	d904      	bls.n	20027b00 <mbedtls_asn1_get_bitstring_null+0x22>
20027af6:	6823      	ldr	r3, [r4, #0]
20027af8:	1c5a      	adds	r2, r3, #1
20027afa:	6022      	str	r2, [r4, #0]
20027afc:	781b      	ldrb	r3, [r3, #0]
20027afe:	b10b      	cbz	r3, 20027b04 <mbedtls_asn1_get_bitstring_null+0x26>
20027b00:	f06f 0067 	mvn.w	r0, #103	@ 0x67
20027b04:	bd38      	pop	{r3, r4, r5, pc}

20027b06 <mbedtls_asn1_get_alg>:
20027b06:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20027b0a:	4690      	mov	r8, r2
20027b0c:	461e      	mov	r6, r3
20027b0e:	aa01      	add	r2, sp, #4
20027b10:	2330      	movs	r3, #48	@ 0x30
20027b12:	4605      	mov	r5, r0
20027b14:	460f      	mov	r7, r1
20027b16:	f7ff ffbb 	bl	20027a90 <mbedtls_asn1_get_tag>
20027b1a:	4604      	mov	r4, r0
20027b1c:	bb10      	cbnz	r0, 20027b64 <mbedtls_asn1_get_alg+0x5e>
20027b1e:	682b      	ldr	r3, [r5, #0]
20027b20:	1aff      	subs	r7, r7, r3
20027b22:	2f00      	cmp	r7, #0
20027b24:	dd38      	ble.n	20027b98 <mbedtls_asn1_get_alg+0x92>
20027b26:	4642      	mov	r2, r8
20027b28:	781b      	ldrb	r3, [r3, #0]
20027b2a:	4628      	mov	r0, r5
20027b2c:	f842 3b04 	str.w	r3, [r2], #4
20027b30:	682f      	ldr	r7, [r5, #0]
20027b32:	9b01      	ldr	r3, [sp, #4]
20027b34:	441f      	add	r7, r3
20027b36:	4639      	mov	r1, r7
20027b38:	2306      	movs	r3, #6
20027b3a:	f7ff ffa9 	bl	20027a90 <mbedtls_asn1_get_tag>
20027b3e:	4604      	mov	r4, r0
20027b40:	b980      	cbnz	r0, 20027b64 <mbedtls_asn1_get_alg+0x5e>
20027b42:	682b      	ldr	r3, [r5, #0]
20027b44:	f8d8 2004 	ldr.w	r2, [r8, #4]
20027b48:	f8c8 3008 	str.w	r3, [r8, #8]
20027b4c:	1899      	adds	r1, r3, r2
20027b4e:	42b9      	cmp	r1, r7
20027b50:	6029      	str	r1, [r5, #0]
20027b52:	d10b      	bne.n	20027b6c <mbedtls_asn1_get_alg+0x66>
20027b54:	4601      	mov	r1, r0
20027b56:	f106 030c 	add.w	r3, r6, #12
20027b5a:	4632      	mov	r2, r6
20027b5c:	3601      	adds	r6, #1
20027b5e:	42b3      	cmp	r3, r6
20027b60:	7011      	strb	r1, [r2, #0]
20027b62:	d1fa      	bne.n	20027b5a <mbedtls_asn1_get_alg+0x54>
20027b64:	4620      	mov	r0, r4
20027b66:	b002      	add	sp, #8
20027b68:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027b6c:	5c9b      	ldrb	r3, [r3, r2]
20027b6e:	4632      	mov	r2, r6
20027b70:	f842 3b04 	str.w	r3, [r2], #4
20027b74:	682b      	ldr	r3, [r5, #0]
20027b76:	4639      	mov	r1, r7
20027b78:	3301      	adds	r3, #1
20027b7a:	4628      	mov	r0, r5
20027b7c:	602b      	str	r3, [r5, #0]
20027b7e:	f7ff ff3b 	bl	200279f8 <mbedtls_asn1_get_len>
20027b82:	b960      	cbnz	r0, 20027b9e <mbedtls_asn1_get_alg+0x98>
20027b84:	682b      	ldr	r3, [r5, #0]
20027b86:	6872      	ldr	r2, [r6, #4]
20027b88:	60b3      	str	r3, [r6, #8]
20027b8a:	4413      	add	r3, r2
20027b8c:	42bb      	cmp	r3, r7
20027b8e:	bf18      	it	ne
20027b90:	f06f 0465 	mvnne.w	r4, #101	@ 0x65
20027b94:	602b      	str	r3, [r5, #0]
20027b96:	e7e5      	b.n	20027b64 <mbedtls_asn1_get_alg+0x5e>
20027b98:	f06f 045f 	mvn.w	r4, #95	@ 0x5f
20027b9c:	e7e2      	b.n	20027b64 <mbedtls_asn1_get_alg+0x5e>
20027b9e:	4604      	mov	r4, r0
20027ba0:	e7e0      	b.n	20027b64 <mbedtls_asn1_get_alg+0x5e>

20027ba2 <mpi_sub_hlp>:
20027ba2:	2300      	movs	r3, #0
20027ba4:	b5f0      	push	{r4, r5, r6, r7, lr}
20027ba6:	461c      	mov	r4, r3
20027ba8:	1f16      	subs	r6, r2, #4
20027baa:	4284      	cmp	r4, r0
20027bac:	d103      	bne.n	20027bb6 <mpi_sub_hlp+0x14>
20027bae:	eb02 0284 	add.w	r2, r2, r4, lsl #2
20027bb2:	b9b3      	cbnz	r3, 20027be2 <mpi_sub_hlp+0x40>
20027bb4:	bdf0      	pop	{r4, r5, r6, r7, pc}
20027bb6:	f856 cf04 	ldr.w	ip, [r6, #4]!
20027bba:	ebac 0503 	sub.w	r5, ip, r3
20027bbe:	6035      	str	r5, [r6, #0]
20027bc0:	f851 7024 	ldr.w	r7, [r1, r4, lsl #2]
20027bc4:	3401      	adds	r4, #1
20027bc6:	42bd      	cmp	r5, r7
20027bc8:	bf2c      	ite	cs
20027bca:	f04f 0e00 	movcs.w	lr, #0
20027bce:	f04f 0e01 	movcc.w	lr, #1
20027bd2:	1bed      	subs	r5, r5, r7
20027bd4:	459c      	cmp	ip, r3
20027bd6:	bf2c      	ite	cs
20027bd8:	4673      	movcs	r3, lr
20027bda:	f10e 0301 	addcc.w	r3, lr, #1
20027bde:	6035      	str	r5, [r6, #0]
20027be0:	e7e3      	b.n	20027baa <mpi_sub_hlp+0x8>
20027be2:	6811      	ldr	r1, [r2, #0]
20027be4:	1ac8      	subs	r0, r1, r3
20027be6:	4299      	cmp	r1, r3
20027be8:	bf2c      	ite	cs
20027bea:	2300      	movcs	r3, #0
20027bec:	2301      	movcc	r3, #1
20027bee:	f842 0b04 	str.w	r0, [r2], #4
20027bf2:	e7de      	b.n	20027bb2 <mpi_sub_hlp+0x10>

20027bf4 <mpi_mul_hlp>:
20027bf4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20027bf8:	4694      	mov	ip, r2
20027bfa:	460e      	mov	r6, r1
20027bfc:	4686      	mov	lr, r0
20027bfe:	2500      	movs	r5, #0
20027c00:	f102 0440 	add.w	r4, r2, #64	@ 0x40
20027c04:	f1be 0f0f 	cmp.w	lr, #15
20027c08:	f854 7c40 	ldr.w	r7, [r4, #-64]
20027c0c:	f106 0640 	add.w	r6, r6, #64	@ 0x40
20027c10:	f104 0440 	add.w	r4, r4, #64	@ 0x40
20027c14:	d87c      	bhi.n	20027d10 <mpi_mul_hlp+0x11c>
20027c16:	f06f 080f 	mvn.w	r8, #15
20027c1a:	0902      	lsrs	r2, r0, #4
20027c1c:	fb08 0002 	mla	r0, r8, r2, r0
20027c20:	2807      	cmp	r0, #7
20027c22:	ea4f 1e82 	mov.w	lr, r2, lsl #6
20027c26:	eb0c 1482 	add.w	r4, ip, r2, lsl #6
20027c2a:	eb01 1682 	add.w	r6, r1, r2, lsl #6
20027c2e:	d95b      	bls.n	20027ce8 <mpi_mul_hlp+0xf4>
20027c30:	f851 100e 	ldr.w	r1, [r1, lr]
20027c34:	3808      	subs	r0, #8
20027c36:	fba1 1203 	umull	r1, r2, r1, r3
20027c3a:	1869      	adds	r1, r5, r1
20027c3c:	f142 0200 	adc.w	r2, r2, #0
20027c40:	187f      	adds	r7, r7, r1
20027c42:	f84c 700e 	str.w	r7, [ip, lr]
20027c46:	6871      	ldr	r1, [r6, #4]
20027c48:	f142 0200 	adc.w	r2, r2, #0
20027c4c:	fba1 5103 	umull	r5, r1, r1, r3
20027c50:	1952      	adds	r2, r2, r5
20027c52:	6865      	ldr	r5, [r4, #4]
20027c54:	f141 0100 	adc.w	r1, r1, #0
20027c58:	1952      	adds	r2, r2, r5
20027c5a:	6062      	str	r2, [r4, #4]
20027c5c:	68b2      	ldr	r2, [r6, #8]
20027c5e:	f141 0100 	adc.w	r1, r1, #0
20027c62:	fba2 5203 	umull	r5, r2, r2, r3
20027c66:	1949      	adds	r1, r1, r5
20027c68:	68a5      	ldr	r5, [r4, #8]
20027c6a:	f142 0200 	adc.w	r2, r2, #0
20027c6e:	1949      	adds	r1, r1, r5
20027c70:	60a1      	str	r1, [r4, #8]
20027c72:	68f1      	ldr	r1, [r6, #12]
20027c74:	f142 0200 	adc.w	r2, r2, #0
20027c78:	fba1 5103 	umull	r5, r1, r1, r3
20027c7c:	1952      	adds	r2, r2, r5
20027c7e:	68e5      	ldr	r5, [r4, #12]
20027c80:	f141 0100 	adc.w	r1, r1, #0
20027c84:	1952      	adds	r2, r2, r5
20027c86:	60e2      	str	r2, [r4, #12]
20027c88:	6932      	ldr	r2, [r6, #16]
20027c8a:	f141 0100 	adc.w	r1, r1, #0
20027c8e:	fba2 5203 	umull	r5, r2, r2, r3
20027c92:	1949      	adds	r1, r1, r5
20027c94:	6925      	ldr	r5, [r4, #16]
20027c96:	f142 0200 	adc.w	r2, r2, #0
20027c9a:	1949      	adds	r1, r1, r5
20027c9c:	6121      	str	r1, [r4, #16]
20027c9e:	6971      	ldr	r1, [r6, #20]
20027ca0:	f142 0200 	adc.w	r2, r2, #0
20027ca4:	fba1 5103 	umull	r5, r1, r1, r3
20027ca8:	1952      	adds	r2, r2, r5
20027caa:	6965      	ldr	r5, [r4, #20]
20027cac:	f141 0100 	adc.w	r1, r1, #0
20027cb0:	1952      	adds	r2, r2, r5
20027cb2:	6162      	str	r2, [r4, #20]
20027cb4:	69b2      	ldr	r2, [r6, #24]
20027cb6:	f141 0100 	adc.w	r1, r1, #0
20027cba:	fba2 5203 	umull	r5, r2, r2, r3
20027cbe:	1949      	adds	r1, r1, r5
20027cc0:	69a5      	ldr	r5, [r4, #24]
20027cc2:	f142 0200 	adc.w	r2, r2, #0
20027cc6:	1949      	adds	r1, r1, r5
20027cc8:	61a1      	str	r1, [r4, #24]
20027cca:	69f1      	ldr	r1, [r6, #28]
20027ccc:	f142 0200 	adc.w	r2, r2, #0
20027cd0:	fba1 1503 	umull	r1, r5, r1, r3
20027cd4:	1852      	adds	r2, r2, r1
20027cd6:	69e1      	ldr	r1, [r4, #28]
20027cd8:	f145 0500 	adc.w	r5, r5, #0
20027cdc:	1852      	adds	r2, r2, r1
20027cde:	61e2      	str	r2, [r4, #28]
20027ce0:	f145 0500 	adc.w	r5, r5, #0
20027ce4:	3420      	adds	r4, #32
20027ce6:	3620      	adds	r6, #32
20027ce8:	4627      	mov	r7, r4
20027cea:	ea4f 0c80 	mov.w	ip, r0, lsl #2
20027cee:	eb06 0080 	add.w	r0, r6, r0, lsl #2
20027cf2:	42b0      	cmp	r0, r6
20027cf4:	f857 1b04 	ldr.w	r1, [r7], #4
20027cf8:	f040 80eb 	bne.w	20027ed2 <mpi_mul_hlp+0x2de>
20027cfc:	4464      	add	r4, ip
20027cfe:	6823      	ldr	r3, [r4, #0]
20027d00:	195b      	adds	r3, r3, r5
20027d02:	f844 3b04 	str.w	r3, [r4], #4
20027d06:	f04f 0501 	mov.w	r5, #1
20027d0a:	d2f8      	bcs.n	20027cfe <mpi_mul_hlp+0x10a>
20027d0c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027d10:	f856 2c40 	ldr.w	r2, [r6, #-64]
20027d14:	f1ae 0e10 	sub.w	lr, lr, #16
20027d18:	fba2 2803 	umull	r2, r8, r2, r3
20027d1c:	18aa      	adds	r2, r5, r2
20027d1e:	f148 0500 	adc.w	r5, r8, #0
20027d22:	18ba      	adds	r2, r7, r2
20027d24:	f844 2c80 	str.w	r2, [r4, #-128]
20027d28:	f856 2c3c 	ldr.w	r2, [r6, #-60]
20027d2c:	f145 0500 	adc.w	r5, r5, #0
20027d30:	fba2 7203 	umull	r7, r2, r2, r3
20027d34:	19ef      	adds	r7, r5, r7
20027d36:	f854 5c7c 	ldr.w	r5, [r4, #-124]
20027d3a:	f142 0200 	adc.w	r2, r2, #0
20027d3e:	19ed      	adds	r5, r5, r7
20027d40:	f844 5c7c 	str.w	r5, [r4, #-124]
20027d44:	f856 5c38 	ldr.w	r5, [r6, #-56]
20027d48:	f142 0200 	adc.w	r2, r2, #0
20027d4c:	fba5 7503 	umull	r7, r5, r5, r3
20027d50:	19d7      	adds	r7, r2, r7
20027d52:	f854 2c78 	ldr.w	r2, [r4, #-120]
20027d56:	f145 0500 	adc.w	r5, r5, #0
20027d5a:	19d2      	adds	r2, r2, r7
20027d5c:	f844 2c78 	str.w	r2, [r4, #-120]
20027d60:	f856 2c34 	ldr.w	r2, [r6, #-52]
20027d64:	f145 0500 	adc.w	r5, r5, #0
20027d68:	fba2 7203 	umull	r7, r2, r2, r3
20027d6c:	19ef      	adds	r7, r5, r7
20027d6e:	f854 5c74 	ldr.w	r5, [r4, #-116]
20027d72:	f142 0200 	adc.w	r2, r2, #0
20027d76:	19ed      	adds	r5, r5, r7
20027d78:	f844 5c74 	str.w	r5, [r4, #-116]
20027d7c:	f856 5c30 	ldr.w	r5, [r6, #-48]
20027d80:	f142 0200 	adc.w	r2, r2, #0
20027d84:	fba5 7503 	umull	r7, r5, r5, r3
20027d88:	19d7      	adds	r7, r2, r7
20027d8a:	f854 2c70 	ldr.w	r2, [r4, #-112]
20027d8e:	f145 0500 	adc.w	r5, r5, #0
20027d92:	19d2      	adds	r2, r2, r7
20027d94:	f844 2c70 	str.w	r2, [r4, #-112]
20027d98:	f856 2c2c 	ldr.w	r2, [r6, #-44]
20027d9c:	f145 0500 	adc.w	r5, r5, #0
20027da0:	fba2 7203 	umull	r7, r2, r2, r3
20027da4:	19ef      	adds	r7, r5, r7
20027da6:	f854 5c6c 	ldr.w	r5, [r4, #-108]
20027daa:	f142 0200 	adc.w	r2, r2, #0
20027dae:	19ed      	adds	r5, r5, r7
20027db0:	f844 5c6c 	str.w	r5, [r4, #-108]
20027db4:	f856 5c28 	ldr.w	r5, [r6, #-40]
20027db8:	f142 0200 	adc.w	r2, r2, #0
20027dbc:	fba5 7503 	umull	r7, r5, r5, r3
20027dc0:	19d7      	adds	r7, r2, r7
20027dc2:	f854 2c68 	ldr.w	r2, [r4, #-104]
20027dc6:	f145 0500 	adc.w	r5, r5, #0
20027dca:	19d2      	adds	r2, r2, r7
20027dcc:	f844 2c68 	str.w	r2, [r4, #-104]
20027dd0:	f856 2c24 	ldr.w	r2, [r6, #-36]
20027dd4:	f145 0500 	adc.w	r5, r5, #0
20027dd8:	fba2 7203 	umull	r7, r2, r2, r3
20027ddc:	19ef      	adds	r7, r5, r7
20027dde:	f854 5c64 	ldr.w	r5, [r4, #-100]
20027de2:	f142 0200 	adc.w	r2, r2, #0
20027de6:	19ed      	adds	r5, r5, r7
20027de8:	f844 5c64 	str.w	r5, [r4, #-100]
20027dec:	f856 5c20 	ldr.w	r5, [r6, #-32]
20027df0:	f142 0200 	adc.w	r2, r2, #0
20027df4:	fba5 7503 	umull	r7, r5, r5, r3
20027df8:	19d7      	adds	r7, r2, r7
20027dfa:	f854 2c60 	ldr.w	r2, [r4, #-96]
20027dfe:	f145 0500 	adc.w	r5, r5, #0
20027e02:	19d2      	adds	r2, r2, r7
20027e04:	f844 2c60 	str.w	r2, [r4, #-96]
20027e08:	f856 2c1c 	ldr.w	r2, [r6, #-28]
20027e0c:	f145 0500 	adc.w	r5, r5, #0
20027e10:	fba2 7203 	umull	r7, r2, r2, r3
20027e14:	19ef      	adds	r7, r5, r7
20027e16:	f854 5c5c 	ldr.w	r5, [r4, #-92]
20027e1a:	f142 0200 	adc.w	r2, r2, #0
20027e1e:	19ed      	adds	r5, r5, r7
20027e20:	f844 5c5c 	str.w	r5, [r4, #-92]
20027e24:	f856 5c18 	ldr.w	r5, [r6, #-24]
20027e28:	f142 0200 	adc.w	r2, r2, #0
20027e2c:	fba5 7503 	umull	r7, r5, r5, r3
20027e30:	19d7      	adds	r7, r2, r7
20027e32:	f854 2c58 	ldr.w	r2, [r4, #-88]
20027e36:	f145 0500 	adc.w	r5, r5, #0
20027e3a:	19d2      	adds	r2, r2, r7
20027e3c:	f844 2c58 	str.w	r2, [r4, #-88]
20027e40:	f856 2c14 	ldr.w	r2, [r6, #-20]
20027e44:	f145 0500 	adc.w	r5, r5, #0
20027e48:	fba2 7203 	umull	r7, r2, r2, r3
20027e4c:	19ef      	adds	r7, r5, r7
20027e4e:	f854 5c54 	ldr.w	r5, [r4, #-84]
20027e52:	f142 0200 	adc.w	r2, r2, #0
20027e56:	19ed      	adds	r5, r5, r7
20027e58:	f844 5c54 	str.w	r5, [r4, #-84]
20027e5c:	f856 5c10 	ldr.w	r5, [r6, #-16]
20027e60:	f142 0200 	adc.w	r2, r2, #0
20027e64:	fba5 7503 	umull	r7, r5, r5, r3
20027e68:	19d7      	adds	r7, r2, r7
20027e6a:	f854 2c50 	ldr.w	r2, [r4, #-80]
20027e6e:	f145 0500 	adc.w	r5, r5, #0
20027e72:	19d2      	adds	r2, r2, r7
20027e74:	f844 2c50 	str.w	r2, [r4, #-80]
20027e78:	f856 2c0c 	ldr.w	r2, [r6, #-12]
20027e7c:	f145 0500 	adc.w	r5, r5, #0
20027e80:	fba2 7203 	umull	r7, r2, r2, r3
20027e84:	19ef      	adds	r7, r5, r7
20027e86:	f854 5c4c 	ldr.w	r5, [r4, #-76]
20027e8a:	f142 0200 	adc.w	r2, r2, #0
20027e8e:	19ed      	adds	r5, r5, r7
20027e90:	f844 5c4c 	str.w	r5, [r4, #-76]
20027e94:	f856 5c08 	ldr.w	r5, [r6, #-8]
20027e98:	f142 0200 	adc.w	r2, r2, #0
20027e9c:	fba5 5703 	umull	r5, r7, r5, r3
20027ea0:	1955      	adds	r5, r2, r5
20027ea2:	f854 2c48 	ldr.w	r2, [r4, #-72]
20027ea6:	f147 0700 	adc.w	r7, r7, #0
20027eaa:	1952      	adds	r2, r2, r5
20027eac:	f844 2c48 	str.w	r2, [r4, #-72]
20027eb0:	f856 2c04 	ldr.w	r2, [r6, #-4]
20027eb4:	f147 0700 	adc.w	r7, r7, #0
20027eb8:	fba2 2503 	umull	r2, r5, r2, r3
20027ebc:	18bf      	adds	r7, r7, r2
20027ebe:	f854 2c44 	ldr.w	r2, [r4, #-68]
20027ec2:	f145 0500 	adc.w	r5, r5, #0
20027ec6:	19d2      	adds	r2, r2, r7
20027ec8:	f145 0500 	adc.w	r5, r5, #0
20027ecc:	f844 2c44 	str.w	r2, [r4, #-68]
20027ed0:	e698      	b.n	20027c04 <mpi_mul_hlp+0x10>
20027ed2:	f856 2b04 	ldr.w	r2, [r6], #4
20027ed6:	fba2 2e03 	umull	r2, lr, r2, r3
20027eda:	18aa      	adds	r2, r5, r2
20027edc:	f14e 0500 	adc.w	r5, lr, #0
20027ee0:	1889      	adds	r1, r1, r2
20027ee2:	f145 0500 	adc.w	r5, r5, #0
20027ee6:	f847 1c04 	str.w	r1, [r7, #-4]
20027eea:	e702      	b.n	20027cf2 <mpi_mul_hlp+0xfe>

20027eec <mbedtls_mpi_init>:
20027eec:	b120      	cbz	r0, 20027ef8 <mbedtls_mpi_init+0xc>
20027eee:	2300      	movs	r3, #0
20027ef0:	2201      	movs	r2, #1
20027ef2:	e9c0 2300 	strd	r2, r3, [r0]
20027ef6:	6083      	str	r3, [r0, #8]
20027ef8:	4770      	bx	lr

20027efa <mbedtls_mpi_free>:
20027efa:	b510      	push	{r4, lr}
20027efc:	4604      	mov	r4, r0
20027efe:	b168      	cbz	r0, 20027f1c <mbedtls_mpi_free+0x22>
20027f00:	6883      	ldr	r3, [r0, #8]
20027f02:	b133      	cbz	r3, 20027f12 <mbedtls_mpi_free+0x18>
20027f04:	2100      	movs	r1, #0
20027f06:	6842      	ldr	r2, [r0, #4]
20027f08:	3a01      	subs	r2, #1
20027f0a:	d208      	bcs.n	20027f1e <mbedtls_mpi_free+0x24>
20027f0c:	68a0      	ldr	r0, [r4, #8]
20027f0e:	f002 fcbf 	bl	2002a890 <free>
20027f12:	2300      	movs	r3, #0
20027f14:	2201      	movs	r2, #1
20027f16:	e9c4 2300 	strd	r2, r3, [r4]
20027f1a:	60a3      	str	r3, [r4, #8]
20027f1c:	bd10      	pop	{r4, pc}
20027f1e:	f843 1b04 	str.w	r1, [r3], #4
20027f22:	e7f1      	b.n	20027f08 <mbedtls_mpi_free+0xe>

20027f24 <mbedtls_mpi_grow>:
20027f24:	f242 7310 	movw	r3, #10000	@ 0x2710
20027f28:	4299      	cmp	r1, r3
20027f2a:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20027f2e:	4605      	mov	r5, r0
20027f30:	460f      	mov	r7, r1
20027f32:	d903      	bls.n	20027f3c <mbedtls_mpi_grow+0x18>
20027f34:	f06f 000f 	mvn.w	r0, #15
20027f38:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027f3c:	6846      	ldr	r6, [r0, #4]
20027f3e:	428e      	cmp	r6, r1
20027f40:	d301      	bcc.n	20027f46 <mbedtls_mpi_grow+0x22>
20027f42:	2000      	movs	r0, #0
20027f44:	e7f8      	b.n	20027f38 <mbedtls_mpi_grow+0x14>
20027f46:	2104      	movs	r1, #4
20027f48:	4638      	mov	r0, r7
20027f4a:	f002 fc85 	bl	2002a858 <calloc>
20027f4e:	4680      	mov	r8, r0
20027f50:	2800      	cmp	r0, #0
20027f52:	d0ef      	beq.n	20027f34 <mbedtls_mpi_grow+0x10>
20027f54:	68ac      	ldr	r4, [r5, #8]
20027f56:	b15c      	cbz	r4, 20027f70 <mbedtls_mpi_grow+0x4c>
20027f58:	00b6      	lsls	r6, r6, #2
20027f5a:	4632      	mov	r2, r6
20027f5c:	4621      	mov	r1, r4
20027f5e:	f002 fd77 	bl	2002aa50 <memcpy>
20027f62:	2300      	movs	r3, #0
20027f64:	4426      	add	r6, r4
20027f66:	42b4      	cmp	r4, r6
20027f68:	d105      	bne.n	20027f76 <mbedtls_mpi_grow+0x52>
20027f6a:	68a8      	ldr	r0, [r5, #8]
20027f6c:	f002 fc90 	bl	2002a890 <free>
20027f70:	e9c5 7801 	strd	r7, r8, [r5, #4]
20027f74:	e7e5      	b.n	20027f42 <mbedtls_mpi_grow+0x1e>
20027f76:	f844 3b04 	str.w	r3, [r4], #4
20027f7a:	e7f4      	b.n	20027f66 <mbedtls_mpi_grow+0x42>

20027f7c <mbedtls_mpi_copy>:
20027f7c:	4288      	cmp	r0, r1
20027f7e:	b570      	push	{r4, r5, r6, lr}
20027f80:	4605      	mov	r5, r0
20027f82:	460e      	mov	r6, r1
20027f84:	d003      	beq.n	20027f8e <mbedtls_mpi_copy+0x12>
20027f86:	688b      	ldr	r3, [r1, #8]
20027f88:	b91b      	cbnz	r3, 20027f92 <mbedtls_mpi_copy+0x16>
20027f8a:	f7ff ffb6 	bl	20027efa <mbedtls_mpi_free>
20027f8e:	2000      	movs	r0, #0
20027f90:	bd70      	pop	{r4, r5, r6, pc}
20027f92:	684a      	ldr	r2, [r1, #4]
20027f94:	3a01      	subs	r2, #1
20027f96:	b11a      	cbz	r2, 20027fa0 <mbedtls_mpi_copy+0x24>
20027f98:	f853 1022 	ldr.w	r1, [r3, r2, lsl #2]
20027f9c:	2900      	cmp	r1, #0
20027f9e:	d0f9      	beq.n	20027f94 <mbedtls_mpi_copy+0x18>
20027fa0:	6833      	ldr	r3, [r6, #0]
20027fa2:	1c54      	adds	r4, r2, #1
20027fa4:	4621      	mov	r1, r4
20027fa6:	4628      	mov	r0, r5
20027fa8:	602b      	str	r3, [r5, #0]
20027faa:	f7ff ffbb 	bl	20027f24 <mbedtls_mpi_grow>
20027fae:	4601      	mov	r1, r0
20027fb0:	b950      	cbnz	r0, 20027fc8 <mbedtls_mpi_copy+0x4c>
20027fb2:	686a      	ldr	r2, [r5, #4]
20027fb4:	68a8      	ldr	r0, [r5, #8]
20027fb6:	0092      	lsls	r2, r2, #2
20027fb8:	f002 fd30 	bl	2002aa1c <memset>
20027fbc:	68b1      	ldr	r1, [r6, #8]
20027fbe:	68a8      	ldr	r0, [r5, #8]
20027fc0:	00a2      	lsls	r2, r4, #2
20027fc2:	f002 fd45 	bl	2002aa50 <memcpy>
20027fc6:	e7e2      	b.n	20027f8e <mbedtls_mpi_copy+0x12>
20027fc8:	f06f 000f 	mvn.w	r0, #15
20027fcc:	e7e0      	b.n	20027f90 <mbedtls_mpi_copy+0x14>

20027fce <mbedtls_mpi_lset>:
20027fce:	b570      	push	{r4, r5, r6, lr}
20027fd0:	460e      	mov	r6, r1
20027fd2:	2101      	movs	r1, #1
20027fd4:	4604      	mov	r4, r0
20027fd6:	f7ff ffa5 	bl	20027f24 <mbedtls_mpi_grow>
20027fda:	4605      	mov	r5, r0
20027fdc:	b988      	cbnz	r0, 20028002 <mbedtls_mpi_lset+0x34>
20027fde:	6862      	ldr	r2, [r4, #4]
20027fe0:	4601      	mov	r1, r0
20027fe2:	0092      	lsls	r2, r2, #2
20027fe4:	68a0      	ldr	r0, [r4, #8]
20027fe6:	f002 fd19 	bl	2002aa1c <memset>
20027fea:	68a3      	ldr	r3, [r4, #8]
20027fec:	ea86 72e6 	eor.w	r2, r6, r6, asr #31
20027ff0:	2e00      	cmp	r6, #0
20027ff2:	eba2 72e6 	sub.w	r2, r2, r6, asr #31
20027ff6:	601a      	str	r2, [r3, #0]
20027ff8:	bfac      	ite	ge
20027ffa:	2301      	movge	r3, #1
20027ffc:	f04f 33ff 	movlt.w	r3, #4294967295
20028000:	6023      	str	r3, [r4, #0]
20028002:	4628      	mov	r0, r5
20028004:	bd70      	pop	{r4, r5, r6, pc}

20028006 <mbedtls_mpi_lsb>:
20028006:	2300      	movs	r3, #0
20028008:	4619      	mov	r1, r3
2002800a:	b570      	push	{r4, r5, r6, lr}
2002800c:	6844      	ldr	r4, [r0, #4]
2002800e:	428c      	cmp	r4, r1
20028010:	d101      	bne.n	20028016 <mbedtls_mpi_lsb+0x10>
20028012:	2000      	movs	r0, #0
20028014:	e008      	b.n	20028028 <mbedtls_mpi_lsb+0x22>
20028016:	6882      	ldr	r2, [r0, #8]
20028018:	f852 5021 	ldr.w	r5, [r2, r1, lsl #2]
2002801c:	2200      	movs	r2, #0
2002801e:	fa25 f602 	lsr.w	r6, r5, r2
20028022:	07f6      	lsls	r6, r6, #31
20028024:	d501      	bpl.n	2002802a <mbedtls_mpi_lsb+0x24>
20028026:	1898      	adds	r0, r3, r2
20028028:	bd70      	pop	{r4, r5, r6, pc}
2002802a:	3201      	adds	r2, #1
2002802c:	2a20      	cmp	r2, #32
2002802e:	d1f6      	bne.n	2002801e <mbedtls_mpi_lsb+0x18>
20028030:	3320      	adds	r3, #32
20028032:	3101      	adds	r1, #1
20028034:	e7eb      	b.n	2002800e <mbedtls_mpi_lsb+0x8>

20028036 <mbedtls_mpi_bitlen>:
20028036:	4602      	mov	r2, r0
20028038:	6840      	ldr	r0, [r0, #4]
2002803a:	b188      	cbz	r0, 20028060 <mbedtls_mpi_bitlen+0x2a>
2002803c:	6891      	ldr	r1, [r2, #8]
2002803e:	1e43      	subs	r3, r0, #1
20028040:	b97b      	cbnz	r3, 20028062 <mbedtls_mpi_bitlen+0x2c>
20028042:	461a      	mov	r2, r3
20028044:	5889      	ldr	r1, [r1, r2]
20028046:	2000      	movs	r0, #0
20028048:	f04f 4200 	mov.w	r2, #2147483648	@ 0x80000000
2002804c:	4211      	tst	r1, r2
2002804e:	d104      	bne.n	2002805a <mbedtls_mpi_bitlen+0x24>
20028050:	3001      	adds	r0, #1
20028052:	2820      	cmp	r0, #32
20028054:	ea4f 0252 	mov.w	r2, r2, lsr #1
20028058:	d1f8      	bne.n	2002804c <mbedtls_mpi_bitlen+0x16>
2002805a:	3301      	adds	r3, #1
2002805c:	ebc0 1043 	rsb	r0, r0, r3, lsl #5
20028060:	4770      	bx	lr
20028062:	f851 0023 	ldr.w	r0, [r1, r3, lsl #2]
20028066:	009a      	lsls	r2, r3, #2
20028068:	2800      	cmp	r0, #0
2002806a:	d1eb      	bne.n	20028044 <mbedtls_mpi_bitlen+0xe>
2002806c:	3b01      	subs	r3, #1
2002806e:	e7e7      	b.n	20028040 <mbedtls_mpi_bitlen+0xa>

20028070 <mbedtls_mpi_size>:
20028070:	b508      	push	{r3, lr}
20028072:	f7ff ffe0 	bl	20028036 <mbedtls_mpi_bitlen>
20028076:	3007      	adds	r0, #7
20028078:	08c0      	lsrs	r0, r0, #3
2002807a:	bd08      	pop	{r3, pc}

2002807c <mbedtls_mpi_read_binary>:
2002807c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002807e:	4607      	mov	r7, r0
20028080:	460c      	mov	r4, r1
20028082:	4616      	mov	r6, r2
20028084:	2500      	movs	r5, #0
20028086:	42b5      	cmp	r5, r6
20028088:	d001      	beq.n	2002808e <mbedtls_mpi_read_binary+0x12>
2002808a:	5d63      	ldrb	r3, [r4, r5]
2002808c:	b173      	cbz	r3, 200280ac <mbedtls_mpi_read_binary+0x30>
2002808e:	1b71      	subs	r1, r6, r5
20028090:	f011 0303 	ands.w	r3, r1, #3
20028094:	bf18      	it	ne
20028096:	2301      	movne	r3, #1
20028098:	4638      	mov	r0, r7
2002809a:	eb03 0191 	add.w	r1, r3, r1, lsr #2
2002809e:	f7ff ff41 	bl	20027f24 <mbedtls_mpi_grow>
200280a2:	4601      	mov	r1, r0
200280a4:	b120      	cbz	r0, 200280b0 <mbedtls_mpi_read_binary+0x34>
200280a6:	f06f 000f 	mvn.w	r0, #15
200280aa:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200280ac:	3501      	adds	r5, #1
200280ae:	e7ea      	b.n	20028086 <mbedtls_mpi_read_binary+0xa>
200280b0:	4638      	mov	r0, r7
200280b2:	f7ff ff8c 	bl	20027fce <mbedtls_mpi_lset>
200280b6:	2800      	cmp	r0, #0
200280b8:	d1f5      	bne.n	200280a6 <mbedtls_mpi_read_binary+0x2a>
200280ba:	4603      	mov	r3, r0
200280bc:	4434      	add	r4, r6
200280be:	1af2      	subs	r2, r6, r3
200280c0:	4295      	cmp	r5, r2
200280c2:	d2f2      	bcs.n	200280aa <mbedtls_mpi_read_binary+0x2e>
200280c4:	f8d7 e008 	ldr.w	lr, [r7, #8]
200280c8:	f814 1d01 	ldrb.w	r1, [r4, #-1]!
200280cc:	00da      	lsls	r2, r3, #3
200280ce:	f023 0c03 	bic.w	ip, r3, #3
200280d2:	f002 0218 	and.w	r2, r2, #24
200280d6:	4091      	lsls	r1, r2
200280d8:	f85e 200c 	ldr.w	r2, [lr, ip]
200280dc:	3301      	adds	r3, #1
200280de:	430a      	orrs	r2, r1
200280e0:	f84e 200c 	str.w	r2, [lr, ip]
200280e4:	e7eb      	b.n	200280be <mbedtls_mpi_read_binary+0x42>

200280e6 <mbedtls_mpi_write_binary>:
200280e6:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200280e8:	4615      	mov	r5, r2
200280ea:	4607      	mov	r7, r0
200280ec:	460c      	mov	r4, r1
200280ee:	f7ff ffbf 	bl	20028070 <mbedtls_mpi_size>
200280f2:	42a8      	cmp	r0, r5
200280f4:	4606      	mov	r6, r0
200280f6:	d816      	bhi.n	20028126 <mbedtls_mpi_write_binary+0x40>
200280f8:	4620      	mov	r0, r4
200280fa:	462a      	mov	r2, r5
200280fc:	2100      	movs	r1, #0
200280fe:	f002 fc8d 	bl	2002aa1c <memset>
20028102:	2300      	movs	r3, #0
20028104:	442c      	add	r4, r5
20028106:	42b3      	cmp	r3, r6
20028108:	d101      	bne.n	2002810e <mbedtls_mpi_write_binary+0x28>
2002810a:	2000      	movs	r0, #0
2002810c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002810e:	68b8      	ldr	r0, [r7, #8]
20028110:	f023 0203 	bic.w	r2, r3, #3
20028114:	5882      	ldr	r2, [r0, r2]
20028116:	00d9      	lsls	r1, r3, #3
20028118:	f001 0118 	and.w	r1, r1, #24
2002811c:	40ca      	lsrs	r2, r1
2002811e:	f804 2d01 	strb.w	r2, [r4, #-1]!
20028122:	3301      	adds	r3, #1
20028124:	e7ef      	b.n	20028106 <mbedtls_mpi_write_binary+0x20>
20028126:	f06f 0007 	mvn.w	r0, #7
2002812a:	e7ef      	b.n	2002810c <mbedtls_mpi_write_binary+0x26>

2002812c <mbedtls_mpi_shift_l>:
2002812c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002812e:	4605      	mov	r5, r0
20028130:	460e      	mov	r6, r1
20028132:	094c      	lsrs	r4, r1, #5
20028134:	f001 071f 	and.w	r7, r1, #31
20028138:	f7ff ff7d 	bl	20028036 <mbedtls_mpi_bitlen>
2002813c:	686b      	ldr	r3, [r5, #4]
2002813e:	4430      	add	r0, r6
20028140:	ebb0 1f43 	cmp.w	r0, r3, lsl #5
20028144:	d805      	bhi.n	20028152 <mbedtls_mpi_shift_l+0x26>
20028146:	2e1f      	cmp	r6, #31
20028148:	d811      	bhi.n	2002816e <mbedtls_mpi_shift_l+0x42>
2002814a:	2f00      	cmp	r7, #0
2002814c:	d143      	bne.n	200281d6 <mbedtls_mpi_shift_l+0xaa>
2002814e:	2000      	movs	r0, #0
20028150:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20028152:	f010 011f 	ands.w	r1, r0, #31
20028156:	bf18      	it	ne
20028158:	2101      	movne	r1, #1
2002815a:	eb01 1150 	add.w	r1, r1, r0, lsr #5
2002815e:	4628      	mov	r0, r5
20028160:	f7ff fee0 	bl	20027f24 <mbedtls_mpi_grow>
20028164:	2800      	cmp	r0, #0
20028166:	d0ee      	beq.n	20028146 <mbedtls_mpi_shift_l+0x1a>
20028168:	f06f 000f 	mvn.w	r0, #15
2002816c:	e7f0      	b.n	20028150 <mbedtls_mpi_shift_l+0x24>
2002816e:	f06f 0003 	mvn.w	r0, #3
20028172:	686a      	ldr	r2, [r5, #4]
20028174:	4360      	muls	r0, r4
20028176:	4611      	mov	r1, r2
20028178:	0093      	lsls	r3, r2, #2
2002817a:	42a1      	cmp	r1, r4
2002817c:	f1a3 0304 	sub.w	r3, r3, #4
20028180:	d80c      	bhi.n	2002819c <mbedtls_mpi_shift_l+0x70>
20028182:	1aa3      	subs	r3, r4, r2
20028184:	4294      	cmp	r4, r2
20028186:	bf88      	it	hi
20028188:	2300      	movhi	r3, #0
2002818a:	4413      	add	r3, r2
2002818c:	2200      	movs	r2, #0
2002818e:	009b      	lsls	r3, r3, #2
20028190:	3b04      	subs	r3, #4
20028192:	1d19      	adds	r1, r3, #4
20028194:	d0d9      	beq.n	2002814a <mbedtls_mpi_shift_l+0x1e>
20028196:	68a9      	ldr	r1, [r5, #8]
20028198:	50ca      	str	r2, [r1, r3]
2002819a:	e7f9      	b.n	20028190 <mbedtls_mpi_shift_l+0x64>
2002819c:	68ae      	ldr	r6, [r5, #8]
2002819e:	3901      	subs	r1, #1
200281a0:	eb06 0c03 	add.w	ip, r6, r3
200281a4:	f85c c000 	ldr.w	ip, [ip, r0]
200281a8:	f846 c003 	str.w	ip, [r6, r3]
200281ac:	e7e5      	b.n	2002817a <mbedtls_mpi_shift_l+0x4e>
200281ae:	68ab      	ldr	r3, [r5, #8]
200281b0:	f853 1024 	ldr.w	r1, [r3, r4, lsl #2]
200281b4:	fa01 f007 	lsl.w	r0, r1, r7
200281b8:	f843 0024 	str.w	r0, [r3, r4, lsl #2]
200281bc:	68a8      	ldr	r0, [r5, #8]
200281be:	f850 3024 	ldr.w	r3, [r0, r4, lsl #2]
200281c2:	4313      	orrs	r3, r2
200281c4:	f840 3024 	str.w	r3, [r0, r4, lsl #2]
200281c8:	fa21 f206 	lsr.w	r2, r1, r6
200281cc:	3401      	adds	r4, #1
200281ce:	686b      	ldr	r3, [r5, #4]
200281d0:	42a3      	cmp	r3, r4
200281d2:	d8ec      	bhi.n	200281ae <mbedtls_mpi_shift_l+0x82>
200281d4:	e7bb      	b.n	2002814e <mbedtls_mpi_shift_l+0x22>
200281d6:	2200      	movs	r2, #0
200281d8:	f1c7 0620 	rsb	r6, r7, #32
200281dc:	e7f7      	b.n	200281ce <mbedtls_mpi_shift_l+0xa2>

200281de <mbedtls_mpi_shift_r>:
200281de:	b4f0      	push	{r4, r5, r6, r7}
200281e0:	6843      	ldr	r3, [r0, #4]
200281e2:	094c      	lsrs	r4, r1, #5
200281e4:	42a3      	cmp	r3, r4
200281e6:	f001 021f 	and.w	r2, r1, #31
200281ea:	d301      	bcc.n	200281f0 <mbedtls_mpi_shift_r+0x12>
200281ec:	d104      	bne.n	200281f8 <mbedtls_mpi_shift_r+0x1a>
200281ee:	b392      	cbz	r2, 20028256 <mbedtls_mpi_shift_r+0x78>
200281f0:	bcf0      	pop	{r4, r5, r6, r7}
200281f2:	2100      	movs	r1, #0
200281f4:	f7ff beeb 	b.w	20027fce <mbedtls_mpi_lset>
200281f8:	291f      	cmp	r1, #31
200281fa:	d82e      	bhi.n	2002825a <mbedtls_mpi_shift_r+0x7c>
200281fc:	b9aa      	cbnz	r2, 2002822a <mbedtls_mpi_shift_r+0x4c>
200281fe:	bcf0      	pop	{r4, r5, r6, r7}
20028200:	2000      	movs	r0, #0
20028202:	4770      	bx	lr
20028204:	6885      	ldr	r5, [r0, #8]
20028206:	586e      	ldr	r6, [r5, r1]
20028208:	3104      	adds	r1, #4
2002820a:	f845 6023 	str.w	r6, [r5, r3, lsl #2]
2002820e:	3301      	adds	r3, #1
20028210:	6845      	ldr	r5, [r0, #4]
20028212:	1b2d      	subs	r5, r5, r4
20028214:	429d      	cmp	r5, r3
20028216:	d8f5      	bhi.n	20028204 <mbedtls_mpi_shift_r+0x26>
20028218:	2400      	movs	r4, #0
2002821a:	6841      	ldr	r1, [r0, #4]
2002821c:	4299      	cmp	r1, r3
2002821e:	d9ed      	bls.n	200281fc <mbedtls_mpi_shift_r+0x1e>
20028220:	6881      	ldr	r1, [r0, #8]
20028222:	f841 4023 	str.w	r4, [r1, r3, lsl #2]
20028226:	3301      	adds	r3, #1
20028228:	e7f7      	b.n	2002821a <mbedtls_mpi_shift_r+0x3c>
2002822a:	2400      	movs	r4, #0
2002822c:	6843      	ldr	r3, [r0, #4]
2002822e:	f1c2 0720 	rsb	r7, r2, #32
20028232:	3b01      	subs	r3, #1
20028234:	d3e3      	bcc.n	200281fe <mbedtls_mpi_shift_r+0x20>
20028236:	6881      	ldr	r1, [r0, #8]
20028238:	f851 5023 	ldr.w	r5, [r1, r3, lsl #2]
2002823c:	fa25 f602 	lsr.w	r6, r5, r2
20028240:	f841 6023 	str.w	r6, [r1, r3, lsl #2]
20028244:	6886      	ldr	r6, [r0, #8]
20028246:	f856 1023 	ldr.w	r1, [r6, r3, lsl #2]
2002824a:	4321      	orrs	r1, r4
2002824c:	f846 1023 	str.w	r1, [r6, r3, lsl #2]
20028250:	fa05 f407 	lsl.w	r4, r5, r7
20028254:	e7ed      	b.n	20028232 <mbedtls_mpi_shift_r+0x54>
20028256:	291f      	cmp	r1, #31
20028258:	d9d1      	bls.n	200281fe <mbedtls_mpi_shift_r+0x20>
2002825a:	2300      	movs	r3, #0
2002825c:	00a1      	lsls	r1, r4, #2
2002825e:	e7d7      	b.n	20028210 <mbedtls_mpi_shift_r+0x32>

20028260 <mbedtls_mpi_cmp_abs>:
20028260:	b530      	push	{r4, r5, lr}
20028262:	6842      	ldr	r2, [r0, #4]
20028264:	b922      	cbnz	r2, 20028270 <mbedtls_mpi_cmp_abs+0x10>
20028266:	684b      	ldr	r3, [r1, #4]
20028268:	b95b      	cbnz	r3, 20028282 <mbedtls_mpi_cmp_abs+0x22>
2002826a:	b19a      	cbz	r2, 20028294 <mbedtls_mpi_cmp_abs+0x34>
2002826c:	2001      	movs	r0, #1
2002826e:	e015      	b.n	2002829c <mbedtls_mpi_cmp_abs+0x3c>
20028270:	6883      	ldr	r3, [r0, #8]
20028272:	eb03 0382 	add.w	r3, r3, r2, lsl #2
20028276:	f853 3c04 	ldr.w	r3, [r3, #-4]
2002827a:	2b00      	cmp	r3, #0
2002827c:	d1f3      	bne.n	20028266 <mbedtls_mpi_cmp_abs+0x6>
2002827e:	3a01      	subs	r2, #1
20028280:	e7f0      	b.n	20028264 <mbedtls_mpi_cmp_abs+0x4>
20028282:	688c      	ldr	r4, [r1, #8]
20028284:	eb04 0583 	add.w	r5, r4, r3, lsl #2
20028288:	f855 5c04 	ldr.w	r5, [r5, #-4]
2002828c:	b90d      	cbnz	r5, 20028292 <mbedtls_mpi_cmp_abs+0x32>
2002828e:	3b01      	subs	r3, #1
20028290:	e7ea      	b.n	20028268 <mbedtls_mpi_cmp_abs+0x8>
20028292:	b922      	cbnz	r2, 2002829e <mbedtls_mpi_cmp_abs+0x3e>
20028294:	1e18      	subs	r0, r3, #0
20028296:	bf18      	it	ne
20028298:	2001      	movne	r0, #1
2002829a:	4240      	negs	r0, r0
2002829c:	bd30      	pop	{r4, r5, pc}
2002829e:	4293      	cmp	r3, r2
200282a0:	d3e4      	bcc.n	2002826c <mbedtls_mpi_cmp_abs+0xc>
200282a2:	d80e      	bhi.n	200282c2 <mbedtls_mpi_cmp_abs+0x62>
200282a4:	3a01      	subs	r2, #1
200282a6:	6883      	ldr	r3, [r0, #8]
200282a8:	f853 1022 	ldr.w	r1, [r3, r2, lsl #2]
200282ac:	f854 3022 	ldr.w	r3, [r4, r2, lsl #2]
200282b0:	4299      	cmp	r1, r3
200282b2:	d8db      	bhi.n	2002826c <mbedtls_mpi_cmp_abs+0xc>
200282b4:	f102 32ff 	add.w	r2, r2, #4294967295
200282b8:	d303      	bcc.n	200282c2 <mbedtls_mpi_cmp_abs+0x62>
200282ba:	1c53      	adds	r3, r2, #1
200282bc:	d1f3      	bne.n	200282a6 <mbedtls_mpi_cmp_abs+0x46>
200282be:	2000      	movs	r0, #0
200282c0:	e7ec      	b.n	2002829c <mbedtls_mpi_cmp_abs+0x3c>
200282c2:	f04f 30ff 	mov.w	r0, #4294967295
200282c6:	e7e9      	b.n	2002829c <mbedtls_mpi_cmp_abs+0x3c>

200282c8 <mpi_montmul>:
200282c8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200282cc:	4615      	mov	r5, r2
200282ce:	b087      	sub	sp, #28
200282d0:	9305      	str	r3, [sp, #20]
200282d2:	9b10      	ldr	r3, [sp, #64]	@ 0x40
200282d4:	4606      	mov	r6, r0
200282d6:	685a      	ldr	r2, [r3, #4]
200282d8:	686b      	ldr	r3, [r5, #4]
200282da:	4689      	mov	r9, r1
200282dc:	3301      	adds	r3, #1
200282de:	429a      	cmp	r2, r3
200282e0:	d359      	bcc.n	20028396 <mpi_montmul+0xce>
200282e2:	9b10      	ldr	r3, [sp, #64]	@ 0x40
200282e4:	6898      	ldr	r0, [r3, #8]
200282e6:	2800      	cmp	r0, #0
200282e8:	d055      	beq.n	20028396 <mpi_montmul+0xce>
200282ea:	0092      	lsls	r2, r2, #2
200282ec:	2100      	movs	r1, #0
200282ee:	f002 fb95 	bl	2002aa1c <memset>
200282f2:	9b10      	ldr	r3, [sp, #64]	@ 0x40
200282f4:	f8d5 8004 	ldr.w	r8, [r5, #4]
200282f8:	f8d3 a008 	ldr.w	sl, [r3, #8]
200282fc:	f8d9 3004 	ldr.w	r3, [r9, #4]
20028300:	46d3      	mov	fp, sl
20028302:	4543      	cmp	r3, r8
20028304:	bf28      	it	cs
20028306:	4643      	movcs	r3, r8
20028308:	2400      	movs	r4, #0
2002830a:	9304      	str	r3, [sp, #16]
2002830c:	f108 0301 	add.w	r3, r8, #1
20028310:	009a      	lsls	r2, r3, #2
20028312:	eb0a 0383 	add.w	r3, sl, r3, lsl #2
20028316:	9202      	str	r2, [sp, #8]
20028318:	9303      	str	r3, [sp, #12]
2002831a:	4544      	cmp	r4, r8
2002831c:	68b0      	ldr	r0, [r6, #8]
2002831e:	d118      	bne.n	20028352 <mpi_montmul+0x8a>
20028320:	9b02      	ldr	r3, [sp, #8]
20028322:	1f19      	subs	r1, r3, #4
20028324:	461a      	mov	r2, r3
20028326:	4451      	add	r1, sl
20028328:	f002 fb92 	bl	2002aa50 <memcpy>
2002832c:	4629      	mov	r1, r5
2002832e:	4630      	mov	r0, r6
20028330:	f7ff ff96 	bl	20028260 <mbedtls_mpi_cmp_abs>
20028334:	3001      	adds	r0, #1
20028336:	68b1      	ldr	r1, [r6, #8]
20028338:	bf0c      	ite	eq
2002833a:	9b10      	ldreq	r3, [sp, #64]	@ 0x40
2002833c:	460a      	movne	r2, r1
2002833e:	4620      	mov	r0, r4
20028340:	bf14      	ite	ne
20028342:	68a9      	ldrne	r1, [r5, #8]
20028344:	689a      	ldreq	r2, [r3, #8]
20028346:	f7ff fc2c 	bl	20027ba2 <mpi_sub_hlp>
2002834a:	2000      	movs	r0, #0
2002834c:	b007      	add	sp, #28
2002834e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20028352:	f850 3024 	ldr.w	r3, [r0, r4, lsl #2]
20028356:	f8d9 1008 	ldr.w	r1, [r9, #8]
2002835a:	9301      	str	r3, [sp, #4]
2002835c:	9a01      	ldr	r2, [sp, #4]
2002835e:	680b      	ldr	r3, [r1, #0]
20028360:	f8db 7000 	ldr.w	r7, [fp]
20028364:	9804      	ldr	r0, [sp, #16]
20028366:	fb03 7702 	mla	r7, r3, r2, r7
2002836a:	9b05      	ldr	r3, [sp, #20]
2002836c:	3401      	adds	r4, #1
2002836e:	435f      	muls	r7, r3
20028370:	4613      	mov	r3, r2
20028372:	465a      	mov	r2, fp
20028374:	f7ff fc3e 	bl	20027bf4 <mpi_mul_hlp>
20028378:	465a      	mov	r2, fp
2002837a:	463b      	mov	r3, r7
2002837c:	4640      	mov	r0, r8
2002837e:	68a9      	ldr	r1, [r5, #8]
20028380:	f7ff fc38 	bl	20027bf4 <mpi_mul_hlp>
20028384:	2200      	movs	r2, #0
20028386:	9b01      	ldr	r3, [sp, #4]
20028388:	f84b 3b04 	str.w	r3, [fp], #4
2002838c:	9b03      	ldr	r3, [sp, #12]
2002838e:	f843 2f04 	str.w	r2, [r3, #4]!
20028392:	9303      	str	r3, [sp, #12]
20028394:	e7c1      	b.n	2002831a <mpi_montmul+0x52>
20028396:	f06f 0003 	mvn.w	r0, #3
2002839a:	e7d7      	b.n	2002834c <mpi_montmul+0x84>

2002839c <mbedtls_mpi_cmp_mpi>:
2002839c:	4602      	mov	r2, r0
2002839e:	b530      	push	{r4, r5, lr}
200283a0:	6843      	ldr	r3, [r0, #4]
200283a2:	b923      	cbnz	r3, 200283ae <mbedtls_mpi_cmp_mpi+0x12>
200283a4:	6848      	ldr	r0, [r1, #4]
200283a6:	b958      	cbnz	r0, 200283c0 <mbedtls_mpi_cmp_mpi+0x24>
200283a8:	2b00      	cmp	r3, #0
200283aa:	d136      	bne.n	2002841a <mbedtls_mpi_cmp_mpi+0x7e>
200283ac:	e02f      	b.n	2002840e <mbedtls_mpi_cmp_mpi+0x72>
200283ae:	6890      	ldr	r0, [r2, #8]
200283b0:	eb00 0083 	add.w	r0, r0, r3, lsl #2
200283b4:	f850 0c04 	ldr.w	r0, [r0, #-4]
200283b8:	2800      	cmp	r0, #0
200283ba:	d1f3      	bne.n	200283a4 <mbedtls_mpi_cmp_mpi+0x8>
200283bc:	3b01      	subs	r3, #1
200283be:	e7f0      	b.n	200283a2 <mbedtls_mpi_cmp_mpi+0x6>
200283c0:	688c      	ldr	r4, [r1, #8]
200283c2:	eb04 0580 	add.w	r5, r4, r0, lsl #2
200283c6:	f855 5c04 	ldr.w	r5, [r5, #-4]
200283ca:	bb15      	cbnz	r5, 20028412 <mbedtls_mpi_cmp_mpi+0x76>
200283cc:	3801      	subs	r0, #1
200283ce:	e7ea      	b.n	200283a6 <mbedtls_mpi_cmp_mpi+0xa>
200283d0:	680d      	ldr	r5, [r1, #0]
200283d2:	d202      	bcs.n	200283da <mbedtls_mpi_cmp_mpi+0x3e>
200283d4:	6808      	ldr	r0, [r1, #0]
200283d6:	4240      	negs	r0, r0
200283d8:	e020      	b.n	2002841c <mbedtls_mpi_cmp_mpi+0x80>
200283da:	6810      	ldr	r0, [r2, #0]
200283dc:	2800      	cmp	r0, #0
200283de:	dd03      	ble.n	200283e8 <mbedtls_mpi_cmp_mpi+0x4c>
200283e0:	2d00      	cmp	r5, #0
200283e2:	da07      	bge.n	200283f4 <mbedtls_mpi_cmp_mpi+0x58>
200283e4:	2001      	movs	r0, #1
200283e6:	e019      	b.n	2002841c <mbedtls_mpi_cmp_mpi+0x80>
200283e8:	2d00      	cmp	r5, #0
200283ea:	dd03      	ble.n	200283f4 <mbedtls_mpi_cmp_mpi+0x58>
200283ec:	b110      	cbz	r0, 200283f4 <mbedtls_mpi_cmp_mpi+0x58>
200283ee:	f04f 30ff 	mov.w	r0, #4294967295
200283f2:	e013      	b.n	2002841c <mbedtls_mpi_cmp_mpi+0x80>
200283f4:	3b01      	subs	r3, #1
200283f6:	6891      	ldr	r1, [r2, #8]
200283f8:	f851 5023 	ldr.w	r5, [r1, r3, lsl #2]
200283fc:	f854 1023 	ldr.w	r1, [r4, r3, lsl #2]
20028400:	428d      	cmp	r5, r1
20028402:	d80b      	bhi.n	2002841c <mbedtls_mpi_cmp_mpi+0x80>
20028404:	f103 33ff 	add.w	r3, r3, #4294967295
20028408:	d3e5      	bcc.n	200283d6 <mbedtls_mpi_cmp_mpi+0x3a>
2002840a:	1c59      	adds	r1, r3, #1
2002840c:	d1f3      	bne.n	200283f6 <mbedtls_mpi_cmp_mpi+0x5a>
2002840e:	2000      	movs	r0, #0
20028410:	e004      	b.n	2002841c <mbedtls_mpi_cmp_mpi+0x80>
20028412:	2b00      	cmp	r3, #0
20028414:	d0de      	beq.n	200283d4 <mbedtls_mpi_cmp_mpi+0x38>
20028416:	4283      	cmp	r3, r0
20028418:	d9da      	bls.n	200283d0 <mbedtls_mpi_cmp_mpi+0x34>
2002841a:	6810      	ldr	r0, [r2, #0]
2002841c:	bd30      	pop	{r4, r5, pc}

2002841e <mbedtls_mpi_cmp_int>:
2002841e:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20028420:	ea81 73e1 	eor.w	r3, r1, r1, asr #31
20028424:	eba3 73e1 	sub.w	r3, r3, r1, asr #31
20028428:	2900      	cmp	r1, #0
2002842a:	9300      	str	r3, [sp, #0]
2002842c:	bfac      	ite	ge
2002842e:	2301      	movge	r3, #1
20028430:	f04f 33ff 	movlt.w	r3, #4294967295
20028434:	9301      	str	r3, [sp, #4]
20028436:	2301      	movs	r3, #1
20028438:	a901      	add	r1, sp, #4
2002843a:	9302      	str	r3, [sp, #8]
2002843c:	f8cd d00c 	str.w	sp, [sp, #12]
20028440:	f7ff ffac 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20028444:	b005      	add	sp, #20
20028446:	f85d fb04 	ldr.w	pc, [sp], #4

2002844a <mbedtls_mpi_add_abs>:
2002844a:	4290      	cmp	r0, r2
2002844c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20028450:	4606      	mov	r6, r0
20028452:	460c      	mov	r4, r1
20028454:	4615      	mov	r5, r2
20028456:	d002      	beq.n	2002845e <mbedtls_mpi_add_abs+0x14>
20028458:	4288      	cmp	r0, r1
2002845a:	d12c      	bne.n	200284b6 <mbedtls_mpi_add_abs+0x6c>
2002845c:	462c      	mov	r4, r5
2002845e:	2301      	movs	r3, #1
20028460:	6033      	str	r3, [r6, #0]
20028462:	6865      	ldr	r5, [r4, #4]
20028464:	bb85      	cbnz	r5, 200284c8 <mbedtls_mpi_add_abs+0x7e>
20028466:	4629      	mov	r1, r5
20028468:	4630      	mov	r0, r6
2002846a:	f7ff fd5b 	bl	20027f24 <mbedtls_mpi_grow>
2002846e:	4607      	mov	r7, r0
20028470:	bb28      	cbnz	r0, 200284be <mbedtls_mpi_add_abs+0x74>
20028472:	68b3      	ldr	r3, [r6, #8]
20028474:	68a1      	ldr	r1, [r4, #8]
20028476:	469c      	mov	ip, r3
20028478:	4604      	mov	r4, r0
2002847a:	42a8      	cmp	r0, r5
2002847c:	d12d      	bne.n	200284da <mbedtls_mpi_add_abs+0x90>
2002847e:	eb03 0385 	add.w	r3, r3, r5, lsl #2
20028482:	b1f4      	cbz	r4, 200284c2 <mbedtls_mpi_add_abs+0x78>
20028484:	6872      	ldr	r2, [r6, #4]
20028486:	f105 0801 	add.w	r8, r5, #1
2002848a:	42aa      	cmp	r2, r5
2002848c:	d807      	bhi.n	2002849e <mbedtls_mpi_add_abs+0x54>
2002848e:	4641      	mov	r1, r8
20028490:	4630      	mov	r0, r6
20028492:	f7ff fd47 	bl	20027f24 <mbedtls_mpi_grow>
20028496:	b990      	cbnz	r0, 200284be <mbedtls_mpi_add_abs+0x74>
20028498:	68b3      	ldr	r3, [r6, #8]
2002849a:	eb03 0385 	add.w	r3, r3, r5, lsl #2
2002849e:	681a      	ldr	r2, [r3, #0]
200284a0:	4645      	mov	r5, r8
200284a2:	1912      	adds	r2, r2, r4
200284a4:	bf2c      	ite	cs
200284a6:	2401      	movcs	r4, #1
200284a8:	2400      	movcc	r4, #0
200284aa:	3c00      	subs	r4, #0
200284ac:	bf18      	it	ne
200284ae:	2401      	movne	r4, #1
200284b0:	f843 2b04 	str.w	r2, [r3], #4
200284b4:	e7e5      	b.n	20028482 <mbedtls_mpi_add_abs+0x38>
200284b6:	f7ff fd61 	bl	20027f7c <mbedtls_mpi_copy>
200284ba:	2800      	cmp	r0, #0
200284bc:	d0ce      	beq.n	2002845c <mbedtls_mpi_add_abs+0x12>
200284be:	f06f 070f 	mvn.w	r7, #15
200284c2:	4638      	mov	r0, r7
200284c4:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200284c8:	68a3      	ldr	r3, [r4, #8]
200284ca:	eb03 0385 	add.w	r3, r3, r5, lsl #2
200284ce:	f853 3c04 	ldr.w	r3, [r3, #-4]
200284d2:	2b00      	cmp	r3, #0
200284d4:	d1c7      	bne.n	20028466 <mbedtls_mpi_add_abs+0x1c>
200284d6:	3d01      	subs	r5, #1
200284d8:	e7c4      	b.n	20028464 <mbedtls_mpi_add_abs+0x1a>
200284da:	f8dc 2000 	ldr.w	r2, [ip]
200284de:	1912      	adds	r2, r2, r4
200284e0:	bf2c      	ite	cs
200284e2:	f04f 0e01 	movcs.w	lr, #1
200284e6:	f04f 0e00 	movcc.w	lr, #0
200284ea:	f851 4020 	ldr.w	r4, [r1, r0, lsl #2]
200284ee:	3001      	adds	r0, #1
200284f0:	1912      	adds	r2, r2, r4
200284f2:	f84c 2b04 	str.w	r2, [ip], #4
200284f6:	f14e 0400 	adc.w	r4, lr, #0
200284fa:	e7be      	b.n	2002847a <mbedtls_mpi_add_abs+0x30>

200284fc <mbedtls_mpi_sub_abs>:
200284fc:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200284fe:	460e      	mov	r6, r1
20028500:	4605      	mov	r5, r0
20028502:	4611      	mov	r1, r2
20028504:	4630      	mov	r0, r6
20028506:	4614      	mov	r4, r2
20028508:	f7ff feaa 	bl	20028260 <mbedtls_mpi_cmp_abs>
2002850c:	3001      	adds	r0, #1
2002850e:	d02f      	beq.n	20028570 <mbedtls_mpi_sub_abs+0x74>
20028510:	2300      	movs	r3, #0
20028512:	2201      	movs	r2, #1
20028514:	42ac      	cmp	r4, r5
20028516:	e9cd 2301 	strd	r2, r3, [sp, #4]
2002851a:	9303      	str	r3, [sp, #12]
2002851c:	d10d      	bne.n	2002853a <mbedtls_mpi_sub_abs+0x3e>
2002851e:	4621      	mov	r1, r4
20028520:	a801      	add	r0, sp, #4
20028522:	f7ff fd2b 	bl	20027f7c <mbedtls_mpi_copy>
20028526:	b138      	cbz	r0, 20028538 <mbedtls_mpi_sub_abs+0x3c>
20028528:	f06f 040f 	mvn.w	r4, #15
2002852c:	a801      	add	r0, sp, #4
2002852e:	f7ff fce4 	bl	20027efa <mbedtls_mpi_free>
20028532:	4620      	mov	r0, r4
20028534:	b004      	add	sp, #16
20028536:	bd70      	pop	{r4, r5, r6, pc}
20028538:	ac01      	add	r4, sp, #4
2002853a:	42ae      	cmp	r6, r5
2002853c:	d109      	bne.n	20028552 <mbedtls_mpi_sub_abs+0x56>
2002853e:	2301      	movs	r3, #1
20028540:	602b      	str	r3, [r5, #0]
20028542:	e9d4 0101 	ldrd	r0, r1, [r4, #4]
20028546:	b958      	cbnz	r0, 20028560 <mbedtls_mpi_sub_abs+0x64>
20028548:	68aa      	ldr	r2, [r5, #8]
2002854a:	f7ff fb2a 	bl	20027ba2 <mpi_sub_hlp>
2002854e:	2400      	movs	r4, #0
20028550:	e7ec      	b.n	2002852c <mbedtls_mpi_sub_abs+0x30>
20028552:	4631      	mov	r1, r6
20028554:	4628      	mov	r0, r5
20028556:	f7ff fd11 	bl	20027f7c <mbedtls_mpi_copy>
2002855a:	2800      	cmp	r0, #0
2002855c:	d0ef      	beq.n	2002853e <mbedtls_mpi_sub_abs+0x42>
2002855e:	e7e3      	b.n	20028528 <mbedtls_mpi_sub_abs+0x2c>
20028560:	eb01 0380 	add.w	r3, r1, r0, lsl #2
20028564:	f853 3c04 	ldr.w	r3, [r3, #-4]
20028568:	2b00      	cmp	r3, #0
2002856a:	d1ed      	bne.n	20028548 <mbedtls_mpi_sub_abs+0x4c>
2002856c:	3801      	subs	r0, #1
2002856e:	e7ea      	b.n	20028546 <mbedtls_mpi_sub_abs+0x4a>
20028570:	f06f 0409 	mvn.w	r4, #9
20028574:	e7dd      	b.n	20028532 <mbedtls_mpi_sub_abs+0x36>

20028576 <mbedtls_mpi_add_mpi>:
20028576:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20028578:	680d      	ldr	r5, [r1, #0]
2002857a:	6813      	ldr	r3, [r2, #0]
2002857c:	4604      	mov	r4, r0
2002857e:	436b      	muls	r3, r5
20028580:	460f      	mov	r7, r1
20028582:	4616      	mov	r6, r2
20028584:	d516      	bpl.n	200285b4 <mbedtls_mpi_add_mpi+0x3e>
20028586:	4611      	mov	r1, r2
20028588:	4638      	mov	r0, r7
2002858a:	f7ff fe69 	bl	20028260 <mbedtls_mpi_cmp_abs>
2002858e:	3001      	adds	r0, #1
20028590:	d007      	beq.n	200285a2 <mbedtls_mpi_add_mpi+0x2c>
20028592:	4632      	mov	r2, r6
20028594:	4639      	mov	r1, r7
20028596:	4620      	mov	r0, r4
20028598:	f7ff ffb0 	bl	200284fc <mbedtls_mpi_sub_abs>
2002859c:	b900      	cbnz	r0, 200285a0 <mbedtls_mpi_add_mpi+0x2a>
2002859e:	6025      	str	r5, [r4, #0]
200285a0:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200285a2:	463a      	mov	r2, r7
200285a4:	4631      	mov	r1, r6
200285a6:	4620      	mov	r0, r4
200285a8:	f7ff ffa8 	bl	200284fc <mbedtls_mpi_sub_abs>
200285ac:	2800      	cmp	r0, #0
200285ae:	d1f7      	bne.n	200285a0 <mbedtls_mpi_add_mpi+0x2a>
200285b0:	426d      	negs	r5, r5
200285b2:	e7f4      	b.n	2002859e <mbedtls_mpi_add_mpi+0x28>
200285b4:	f7ff ff49 	bl	2002844a <mbedtls_mpi_add_abs>
200285b8:	2800      	cmp	r0, #0
200285ba:	d0f0      	beq.n	2002859e <mbedtls_mpi_add_mpi+0x28>
200285bc:	f06f 000f 	mvn.w	r0, #15
200285c0:	e7ee      	b.n	200285a0 <mbedtls_mpi_add_mpi+0x2a>

200285c2 <mbedtls_mpi_sub_mpi>:
200285c2:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200285c4:	680d      	ldr	r5, [r1, #0]
200285c6:	6813      	ldr	r3, [r2, #0]
200285c8:	4604      	mov	r4, r0
200285ca:	436b      	muls	r3, r5
200285cc:	2b00      	cmp	r3, #0
200285ce:	460f      	mov	r7, r1
200285d0:	4616      	mov	r6, r2
200285d2:	dd16      	ble.n	20028602 <mbedtls_mpi_sub_mpi+0x40>
200285d4:	4611      	mov	r1, r2
200285d6:	4638      	mov	r0, r7
200285d8:	f7ff fe42 	bl	20028260 <mbedtls_mpi_cmp_abs>
200285dc:	3001      	adds	r0, #1
200285de:	d007      	beq.n	200285f0 <mbedtls_mpi_sub_mpi+0x2e>
200285e0:	4632      	mov	r2, r6
200285e2:	4639      	mov	r1, r7
200285e4:	4620      	mov	r0, r4
200285e6:	f7ff ff89 	bl	200284fc <mbedtls_mpi_sub_abs>
200285ea:	b900      	cbnz	r0, 200285ee <mbedtls_mpi_sub_mpi+0x2c>
200285ec:	6025      	str	r5, [r4, #0]
200285ee:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200285f0:	463a      	mov	r2, r7
200285f2:	4631      	mov	r1, r6
200285f4:	4620      	mov	r0, r4
200285f6:	f7ff ff81 	bl	200284fc <mbedtls_mpi_sub_abs>
200285fa:	2800      	cmp	r0, #0
200285fc:	d1f7      	bne.n	200285ee <mbedtls_mpi_sub_mpi+0x2c>
200285fe:	426d      	negs	r5, r5
20028600:	e7f4      	b.n	200285ec <mbedtls_mpi_sub_mpi+0x2a>
20028602:	f7ff ff22 	bl	2002844a <mbedtls_mpi_add_abs>
20028606:	2800      	cmp	r0, #0
20028608:	d0f0      	beq.n	200285ec <mbedtls_mpi_sub_mpi+0x2a>
2002860a:	f06f 000f 	mvn.w	r0, #15
2002860e:	e7ee      	b.n	200285ee <mbedtls_mpi_sub_mpi+0x2c>

20028610 <mbedtls_mpi_sub_int>:
20028610:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20028612:	ea82 73e2 	eor.w	r3, r2, r2, asr #31
20028616:	eba3 73e2 	sub.w	r3, r3, r2, asr #31
2002861a:	2a00      	cmp	r2, #0
2002861c:	9300      	str	r3, [sp, #0]
2002861e:	bfac      	ite	ge
20028620:	2301      	movge	r3, #1
20028622:	f04f 33ff 	movlt.w	r3, #4294967295
20028626:	9301      	str	r3, [sp, #4]
20028628:	2301      	movs	r3, #1
2002862a:	aa01      	add	r2, sp, #4
2002862c:	9302      	str	r3, [sp, #8]
2002862e:	f8cd d00c 	str.w	sp, [sp, #12]
20028632:	f7ff ffc6 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20028636:	b005      	add	sp, #20
20028638:	f85d fb04 	ldr.w	pc, [sp], #4

2002863c <mbedtls_mpi_mul_mpi>:
2002863c:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20028640:	2300      	movs	r3, #0
20028642:	4615      	mov	r5, r2
20028644:	2201      	movs	r2, #1
20028646:	b087      	sub	sp, #28
20028648:	4288      	cmp	r0, r1
2002864a:	4607      	mov	r7, r0
2002864c:	460e      	mov	r6, r1
2002864e:	e9cd 2300 	strd	r2, r3, [sp]
20028652:	e9cd 3202 	strd	r3, r2, [sp, #8]
20028656:	e9cd 3304 	strd	r3, r3, [sp, #16]
2002865a:	d110      	bne.n	2002867e <mbedtls_mpi_mul_mpi+0x42>
2002865c:	4668      	mov	r0, sp
2002865e:	f7ff fc8d 	bl	20027f7c <mbedtls_mpi_copy>
20028662:	b158      	cbz	r0, 2002867c <mbedtls_mpi_mul_mpi+0x40>
20028664:	f06f 090f 	mvn.w	r9, #15
20028668:	a803      	add	r0, sp, #12
2002866a:	f7ff fc46 	bl	20027efa <mbedtls_mpi_free>
2002866e:	4668      	mov	r0, sp
20028670:	f7ff fc43 	bl	20027efa <mbedtls_mpi_free>
20028674:	4648      	mov	r0, r9
20028676:	b007      	add	sp, #28
20028678:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
2002867c:	466e      	mov	r6, sp
2002867e:	42af      	cmp	r7, r5
20028680:	d106      	bne.n	20028690 <mbedtls_mpi_mul_mpi+0x54>
20028682:	4639      	mov	r1, r7
20028684:	a803      	add	r0, sp, #12
20028686:	f7ff fc79 	bl	20027f7c <mbedtls_mpi_copy>
2002868a:	2800      	cmp	r0, #0
2002868c:	d1ea      	bne.n	20028664 <mbedtls_mpi_mul_mpi+0x28>
2002868e:	ad03      	add	r5, sp, #12
20028690:	f8d6 8004 	ldr.w	r8, [r6, #4]
20028694:	f1b8 0f00 	cmp.w	r8, #0
20028698:	d116      	bne.n	200286c8 <mbedtls_mpi_mul_mpi+0x8c>
2002869a:	686c      	ldr	r4, [r5, #4]
2002869c:	b9f4      	cbnz	r4, 200286dc <mbedtls_mpi_mul_mpi+0xa0>
2002869e:	eb08 0104 	add.w	r1, r8, r4
200286a2:	4638      	mov	r0, r7
200286a4:	f7ff fc3e 	bl	20027f24 <mbedtls_mpi_grow>
200286a8:	4601      	mov	r1, r0
200286aa:	2800      	cmp	r0, #0
200286ac:	d1da      	bne.n	20028664 <mbedtls_mpi_mul_mpi+0x28>
200286ae:	4638      	mov	r0, r7
200286b0:	f7ff fc8d 	bl	20027fce <mbedtls_mpi_lset>
200286b4:	4681      	mov	r9, r0
200286b6:	2800      	cmp	r0, #0
200286b8:	d1d4      	bne.n	20028664 <mbedtls_mpi_mul_mpi+0x28>
200286ba:	3c01      	subs	r4, #1
200286bc:	d217      	bcs.n	200286ee <mbedtls_mpi_mul_mpi+0xb2>
200286be:	6833      	ldr	r3, [r6, #0]
200286c0:	682a      	ldr	r2, [r5, #0]
200286c2:	4353      	muls	r3, r2
200286c4:	603b      	str	r3, [r7, #0]
200286c6:	e7cf      	b.n	20028668 <mbedtls_mpi_mul_mpi+0x2c>
200286c8:	68b3      	ldr	r3, [r6, #8]
200286ca:	eb03 0388 	add.w	r3, r3, r8, lsl #2
200286ce:	f853 3c04 	ldr.w	r3, [r3, #-4]
200286d2:	2b00      	cmp	r3, #0
200286d4:	d1e1      	bne.n	2002869a <mbedtls_mpi_mul_mpi+0x5e>
200286d6:	f108 38ff 	add.w	r8, r8, #4294967295
200286da:	e7db      	b.n	20028694 <mbedtls_mpi_mul_mpi+0x58>
200286dc:	68ab      	ldr	r3, [r5, #8]
200286de:	eb03 0384 	add.w	r3, r3, r4, lsl #2
200286e2:	f853 3c04 	ldr.w	r3, [r3, #-4]
200286e6:	2b00      	cmp	r3, #0
200286e8:	d1d9      	bne.n	2002869e <mbedtls_mpi_mul_mpi+0x62>
200286ea:	3c01      	subs	r4, #1
200286ec:	e7d6      	b.n	2002869c <mbedtls_mpi_mul_mpi+0x60>
200286ee:	68ab      	ldr	r3, [r5, #8]
200286f0:	68ba      	ldr	r2, [r7, #8]
200286f2:	4640      	mov	r0, r8
200286f4:	f853 3024 	ldr.w	r3, [r3, r4, lsl #2]
200286f8:	68b1      	ldr	r1, [r6, #8]
200286fa:	eb02 0284 	add.w	r2, r2, r4, lsl #2
200286fe:	f7ff fa79 	bl	20027bf4 <mpi_mul_hlp>
20028702:	e7da      	b.n	200286ba <mbedtls_mpi_mul_mpi+0x7e>

20028704 <mbedtls_mpi_mul_int>:
20028704:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20028706:	2301      	movs	r3, #1
20028708:	9200      	str	r2, [sp, #0]
2002870a:	aa01      	add	r2, sp, #4
2002870c:	e9cd 3301 	strd	r3, r3, [sp, #4]
20028710:	f8cd d00c 	str.w	sp, [sp, #12]
20028714:	f7ff ff92 	bl	2002863c <mbedtls_mpi_mul_mpi>
20028718:	b005      	add	sp, #20
2002871a:	f85d fb04 	ldr.w	pc, [sp], #4

2002871e <mbedtls_mpi_div_mpi>:
2002871e:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20028722:	b09f      	sub	sp, #124	@ 0x7c
20028724:	e9cd 1203 	strd	r1, r2, [sp, #12]
20028728:	9005      	str	r0, [sp, #20]
2002872a:	2100      	movs	r1, #0
2002872c:	4618      	mov	r0, r3
2002872e:	9309      	str	r3, [sp, #36]	@ 0x24
20028730:	f7ff fe75 	bl	2002841e <mbedtls_mpi_cmp_int>
20028734:	2800      	cmp	r0, #0
20028736:	f000 81f3 	beq.w	20028b20 <mbedtls_mpi_div_mpi+0x402>
2002873a:	2501      	movs	r5, #1
2002873c:	2400      	movs	r4, #0
2002873e:	9909      	ldr	r1, [sp, #36]	@ 0x24
20028740:	9804      	ldr	r0, [sp, #16]
20028742:	e9cd 5418 	strd	r5, r4, [sp, #96]	@ 0x60
20028746:	e9cd 541b 	strd	r5, r4, [sp, #108]	@ 0x6c
2002874a:	950f      	str	r5, [sp, #60]	@ 0x3c
2002874c:	9512      	str	r5, [sp, #72]	@ 0x48
2002874e:	9515      	str	r5, [sp, #84]	@ 0x54
20028750:	9416      	str	r4, [sp, #88]	@ 0x58
20028752:	f7ff fd85 	bl	20028260 <mbedtls_mpi_cmp_abs>
20028756:	3001      	adds	r0, #1
20028758:	d11f      	bne.n	2002879a <mbedtls_mpi_div_mpi+0x7c>
2002875a:	9b05      	ldr	r3, [sp, #20]
2002875c:	b933      	cbnz	r3, 2002876c <mbedtls_mpi_div_mpi+0x4e>
2002875e:	9b03      	ldr	r3, [sp, #12]
20028760:	b9a3      	cbnz	r3, 2002878c <mbedtls_mpi_div_mpi+0x6e>
20028762:	2100      	movs	r1, #0
20028764:	4608      	mov	r0, r1
20028766:	b01f      	add	sp, #124	@ 0x7c
20028768:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002876c:	4621      	mov	r1, r4
2002876e:	9805      	ldr	r0, [sp, #20]
20028770:	f7ff fc2d 	bl	20027fce <mbedtls_mpi_lset>
20028774:	2800      	cmp	r0, #0
20028776:	d0f2      	beq.n	2002875e <mbedtls_mpi_div_mpi+0x40>
20028778:	2400      	movs	r4, #0
2002877a:	4625      	mov	r5, r4
2002877c:	46a1      	mov	r9, r4
2002877e:	46a0      	mov	r8, r4
20028780:	4626      	mov	r6, r4
20028782:	4627      	mov	r7, r4
20028784:	9402      	str	r4, [sp, #8]
20028786:	f06f 010f 	mvn.w	r1, #15
2002878a:	e0ef      	b.n	2002896c <mbedtls_mpi_div_mpi+0x24e>
2002878c:	e9dd 0103 	ldrd	r0, r1, [sp, #12]
20028790:	f7ff fbf4 	bl	20027f7c <mbedtls_mpi_copy>
20028794:	2800      	cmp	r0, #0
20028796:	d1ef      	bne.n	20028778 <mbedtls_mpi_div_mpi+0x5a>
20028798:	e7e3      	b.n	20028762 <mbedtls_mpi_div_mpi+0x44>
2002879a:	9904      	ldr	r1, [sp, #16]
2002879c:	a80f      	add	r0, sp, #60	@ 0x3c
2002879e:	e9cd 4410 	strd	r4, r4, [sp, #64]	@ 0x40
200287a2:	f7ff fbeb 	bl	20027f7c <mbedtls_mpi_copy>
200287a6:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
200287aa:	4682      	mov	sl, r0
200287ac:	2800      	cmp	r0, #0
200287ae:	f040 81a9 	bne.w	20028b04 <mbedtls_mpi_div_mpi+0x3e6>
200287b2:	e9cd 0013 	strd	r0, r0, [sp, #76]	@ 0x4c
200287b6:	9909      	ldr	r1, [sp, #36]	@ 0x24
200287b8:	a812      	add	r0, sp, #72	@ 0x48
200287ba:	f7ff fbdf 	bl	20027f7c <mbedtls_mpi_copy>
200287be:	e9dd 8913 	ldrd	r8, r9, [sp, #76]	@ 0x4c
200287c2:	4604      	mov	r4, r0
200287c4:	2800      	cmp	r0, #0
200287c6:	f040 81a2 	bne.w	20028b0e <mbedtls_mpi_div_mpi+0x3f0>
200287ca:	9b04      	ldr	r3, [sp, #16]
200287cc:	9017      	str	r0, [sp, #92]	@ 0x5c
200287ce:	6859      	ldr	r1, [r3, #4]
200287d0:	a815      	add	r0, sp, #84	@ 0x54
200287d2:	3102      	adds	r1, #2
200287d4:	9512      	str	r5, [sp, #72]	@ 0x48
200287d6:	950f      	str	r5, [sp, #60]	@ 0x3c
200287d8:	f7ff fba4 	bl	20027f24 <mbedtls_mpi_grow>
200287dc:	4605      	mov	r5, r0
200287de:	b118      	cbz	r0, 200287e8 <mbedtls_mpi_div_mpi+0xca>
200287e0:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
200287e2:	9302      	str	r3, [sp, #8]
200287e4:	4625      	mov	r5, r4
200287e6:	e7ce      	b.n	20028786 <mbedtls_mpi_div_mpi+0x68>
200287e8:	4601      	mov	r1, r0
200287ea:	a815      	add	r0, sp, #84	@ 0x54
200287ec:	f7ff fbef 	bl	20027fce <mbedtls_mpi_lset>
200287f0:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
200287f2:	4604      	mov	r4, r0
200287f4:	9302      	str	r3, [sp, #8]
200287f6:	2800      	cmp	r0, #0
200287f8:	f040 818e 	bne.w	20028b18 <mbedtls_mpi_div_mpi+0x3fa>
200287fc:	901a      	str	r0, [sp, #104]	@ 0x68
200287fe:	2102      	movs	r1, #2
20028800:	a818      	add	r0, sp, #96	@ 0x60
20028802:	f7ff fb8f 	bl	20027f24 <mbedtls_mpi_grow>
20028806:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20028808:	2800      	cmp	r0, #0
2002880a:	d1bc      	bne.n	20028786 <mbedtls_mpi_div_mpi+0x68>
2002880c:	901d      	str	r0, [sp, #116]	@ 0x74
2002880e:	2103      	movs	r1, #3
20028810:	a81b      	add	r0, sp, #108	@ 0x6c
20028812:	f7ff fb87 	bl	20027f24 <mbedtls_mpi_grow>
20028816:	9c1d      	ldr	r4, [sp, #116]	@ 0x74
20028818:	4683      	mov	fp, r0
2002881a:	2800      	cmp	r0, #0
2002881c:	d1b3      	bne.n	20028786 <mbedtls_mpi_div_mpi+0x68>
2002881e:	a812      	add	r0, sp, #72	@ 0x48
20028820:	f7ff fc09 	bl	20028036 <mbedtls_mpi_bitlen>
20028824:	f000 001f 	and.w	r0, r0, #31
20028828:	281f      	cmp	r0, #31
2002882a:	f000 808a 	beq.w	20028942 <mbedtls_mpi_div_mpi+0x224>
2002882e:	f1c0 031f 	rsb	r3, r0, #31
20028832:	4619      	mov	r1, r3
20028834:	a80f      	add	r0, sp, #60	@ 0x3c
20028836:	9306      	str	r3, [sp, #24]
20028838:	f7ff fc78 	bl	2002812c <mbedtls_mpi_shift_l>
2002883c:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
20028840:	2800      	cmp	r0, #0
20028842:	d1a0      	bne.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028844:	9906      	ldr	r1, [sp, #24]
20028846:	a812      	add	r0, sp, #72	@ 0x48
20028848:	f7ff fc70 	bl	2002812c <mbedtls_mpi_shift_l>
2002884c:	e9dd 8913 	ldrd	r8, r9, [sp, #76]	@ 0x4c
20028850:	2800      	cmp	r0, #0
20028852:	d198      	bne.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028854:	46ba      	mov	sl, r7
20028856:	f8cd 8020 	str.w	r8, [sp, #32]
2002885a:	eba7 0b08 	sub.w	fp, r7, r8
2002885e:	ea4f 134b 	mov.w	r3, fp, lsl #5
20028862:	4619      	mov	r1, r3
20028864:	a812      	add	r0, sp, #72	@ 0x48
20028866:	e9cd 8913 	strd	r8, r9, [sp, #76]	@ 0x4c
2002886a:	9301      	str	r3, [sp, #4]
2002886c:	f7ff fc5e 	bl	2002812c <mbedtls_mpi_shift_l>
20028870:	e9dd 8913 	ldrd	r8, r9, [sp, #76]	@ 0x4c
20028874:	2800      	cmp	r0, #0
20028876:	d186      	bne.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028878:	ea4f 038b 	mov.w	r3, fp, lsl #2
2002887c:	930b      	str	r3, [sp, #44]	@ 0x2c
2002887e:	9b02      	ldr	r3, [sp, #8]
20028880:	eb03 0b8b 	add.w	fp, r3, fp, lsl #2
20028884:	a912      	add	r1, sp, #72	@ 0x48
20028886:	a80f      	add	r0, sp, #60	@ 0x3c
20028888:	e9cd 7610 	strd	r7, r6, [sp, #64]	@ 0x40
2002888c:	e9cd 8913 	strd	r8, r9, [sp, #76]	@ 0x4c
20028890:	f7ff fd84 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20028894:	2800      	cmp	r0, #0
20028896:	da5a      	bge.n	2002894e <mbedtls_mpi_div_mpi+0x230>
20028898:	9901      	ldr	r1, [sp, #4]
2002889a:	a812      	add	r0, sp, #72	@ 0x48
2002889c:	f7ff fc9f 	bl	200281de <mbedtls_mpi_shift_r>
200288a0:	e9dd 8913 	ldrd	r8, r9, [sp, #76]	@ 0x4c
200288a4:	2800      	cmp	r0, #0
200288a6:	f47f af6e 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
200288aa:	f10a 33ff 	add.w	r3, sl, #4294967295
200288ae:	9301      	str	r3, [sp, #4]
200288b0:	9b08      	ldr	r3, [sp, #32]
200288b2:	9a02      	ldr	r2, [sp, #8]
200288b4:	3b01      	subs	r3, #1
200288b6:	9307      	str	r3, [sp, #28]
200288b8:	eb09 0383 	add.w	r3, r9, r3, lsl #2
200288bc:	930a      	str	r3, [sp, #40]	@ 0x28
200288be:	9b08      	ldr	r3, [sp, #32]
200288c0:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
200288c4:	3b02      	subs	r3, #2
200288c6:	eb09 0383 	add.w	r3, r9, r3, lsl #2
200288ca:	930c      	str	r3, [sp, #48]	@ 0x30
200288cc:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
200288ce:	4413      	add	r3, r2
200288d0:	469a      	mov	sl, r3
200288d2:	9b01      	ldr	r3, [sp, #4]
200288d4:	9a07      	ldr	r2, [sp, #28]
200288d6:	4293      	cmp	r3, r2
200288d8:	d862      	bhi.n	200289a0 <mbedtls_mpi_div_mpi+0x282>
200288da:	9b05      	ldr	r3, [sp, #20]
200288dc:	b16b      	cbz	r3, 200288fa <mbedtls_mpi_div_mpi+0x1dc>
200288de:	4618      	mov	r0, r3
200288e0:	a915      	add	r1, sp, #84	@ 0x54
200288e2:	f7ff fb4b 	bl	20027f7c <mbedtls_mpi_copy>
200288e6:	2800      	cmp	r0, #0
200288e8:	f47f af4d 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
200288ec:	9b04      	ldr	r3, [sp, #16]
200288ee:	9a09      	ldr	r2, [sp, #36]	@ 0x24
200288f0:	681b      	ldr	r3, [r3, #0]
200288f2:	6812      	ldr	r2, [r2, #0]
200288f4:	4353      	muls	r3, r2
200288f6:	9a05      	ldr	r2, [sp, #20]
200288f8:	6013      	str	r3, [r2, #0]
200288fa:	9b03      	ldr	r3, [sp, #12]
200288fc:	2b00      	cmp	r3, #0
200288fe:	f000 810d 	beq.w	20028b1c <mbedtls_mpi_div_mpi+0x3fe>
20028902:	9906      	ldr	r1, [sp, #24]
20028904:	a80f      	add	r0, sp, #60	@ 0x3c
20028906:	e9cd 7610 	strd	r7, r6, [sp, #64]	@ 0x40
2002890a:	f7ff fc68 	bl	200281de <mbedtls_mpi_shift_r>
2002890e:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
20028912:	2800      	cmp	r0, #0
20028914:	f47f af37 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
20028918:	9b04      	ldr	r3, [sp, #16]
2002891a:	a90f      	add	r1, sp, #60	@ 0x3c
2002891c:	681b      	ldr	r3, [r3, #0]
2002891e:	9803      	ldr	r0, [sp, #12]
20028920:	930f      	str	r3, [sp, #60]	@ 0x3c
20028922:	f7ff fb2b 	bl	20027f7c <mbedtls_mpi_copy>
20028926:	4601      	mov	r1, r0
20028928:	2800      	cmp	r0, #0
2002892a:	f47f af2c 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
2002892e:	9001      	str	r0, [sp, #4]
20028930:	9803      	ldr	r0, [sp, #12]
20028932:	f7ff fd74 	bl	2002841e <mbedtls_mpi_cmp_int>
20028936:	9901      	ldr	r1, [sp, #4]
20028938:	b9c0      	cbnz	r0, 2002896c <mbedtls_mpi_div_mpi+0x24e>
2002893a:	2301      	movs	r3, #1
2002893c:	9a03      	ldr	r2, [sp, #12]
2002893e:	6013      	str	r3, [r2, #0]
20028940:	e014      	b.n	2002896c <mbedtls_mpi_div_mpi+0x24e>
20028942:	46ba      	mov	sl, r7
20028944:	f8cd 8020 	str.w	r8, [sp, #32]
20028948:	f8cd b018 	str.w	fp, [sp, #24]
2002894c:	e785      	b.n	2002885a <mbedtls_mpi_div_mpi+0x13c>
2002894e:	f8db 2000 	ldr.w	r2, [fp]
20028952:	a90f      	add	r1, sp, #60	@ 0x3c
20028954:	3201      	adds	r2, #1
20028956:	4608      	mov	r0, r1
20028958:	f8cb 2000 	str.w	r2, [fp]
2002895c:	aa12      	add	r2, sp, #72	@ 0x48
2002895e:	f7ff fe30 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20028962:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
20028966:	4601      	mov	r1, r0
20028968:	2800      	cmp	r0, #0
2002896a:	d08b      	beq.n	20028884 <mbedtls_mpi_div_mpi+0x166>
2002896c:	a80f      	add	r0, sp, #60	@ 0x3c
2002896e:	9101      	str	r1, [sp, #4]
20028970:	e9cd 7610 	strd	r7, r6, [sp, #64]	@ 0x40
20028974:	f7ff fac1 	bl	20027efa <mbedtls_mpi_free>
20028978:	a812      	add	r0, sp, #72	@ 0x48
2002897a:	e9cd 8913 	strd	r8, r9, [sp, #76]	@ 0x4c
2002897e:	f7ff fabc 	bl	20027efa <mbedtls_mpi_free>
20028982:	9b02      	ldr	r3, [sp, #8]
20028984:	a815      	add	r0, sp, #84	@ 0x54
20028986:	9317      	str	r3, [sp, #92]	@ 0x5c
20028988:	f7ff fab7 	bl	20027efa <mbedtls_mpi_free>
2002898c:	a818      	add	r0, sp, #96	@ 0x60
2002898e:	951a      	str	r5, [sp, #104]	@ 0x68
20028990:	f7ff fab3 	bl	20027efa <mbedtls_mpi_free>
20028994:	a81b      	add	r0, sp, #108	@ 0x6c
20028996:	941d      	str	r4, [sp, #116]	@ 0x74
20028998:	f7ff faaf 	bl	20027efa <mbedtls_mpi_free>
2002899c:	9901      	ldr	r1, [sp, #4]
2002899e:	e6e1      	b.n	20028764 <mbedtls_mpi_div_mpi+0x46>
200289a0:	9b01      	ldr	r3, [sp, #4]
200289a2:	ea4f 0b83 	mov.w	fp, r3, lsl #2
200289a6:	eb06 0383 	add.w	r3, r6, r3, lsl #2
200289aa:	930b      	str	r3, [sp, #44]	@ 0x2c
200289ac:	9b01      	ldr	r3, [sp, #4]
200289ae:	f1ab 0004 	sub.w	r0, fp, #4
200289b2:	f856 1023 	ldr.w	r1, [r6, r3, lsl #2]
200289b6:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
200289b8:	681a      	ldr	r2, [r3, #0]
200289ba:	1833      	adds	r3, r6, r0
200289bc:	4291      	cmp	r1, r2
200289be:	930d      	str	r3, [sp, #52]	@ 0x34
200289c0:	d255      	bcs.n	20028a6e <mbedtls_mpi_div_mpi+0x350>
200289c2:	2300      	movs	r3, #0
200289c4:	5830      	ldr	r0, [r6, r0]
200289c6:	f001 fd87 	bl	2002a4d8 <__aeabi_uldivmod>
200289ca:	2900      	cmp	r1, #0
200289cc:	bf14      	ite	ne
200289ce:	f04f 33ff 	movne.w	r3, #4294967295
200289d2:	4603      	moveq	r3, r0
200289d4:	3301      	adds	r3, #1
200289d6:	f1ab 0b08 	sub.w	fp, fp, #8
200289da:	f84a 3c04 	str.w	r3, [sl, #-4]
200289de:	44b3      	add	fp, r6
200289e0:	f85a 3c04 	ldr.w	r3, [sl, #-4]
200289e4:	2100      	movs	r1, #0
200289e6:	3b01      	subs	r3, #1
200289e8:	f84a 3c04 	str.w	r3, [sl, #-4]
200289ec:	a818      	add	r0, sp, #96	@ 0x60
200289ee:	951a      	str	r5, [sp, #104]	@ 0x68
200289f0:	f7ff faed 	bl	20027fce <mbedtls_mpi_lset>
200289f4:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
200289f6:	2800      	cmp	r0, #0
200289f8:	f47f aec5 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
200289fc:	9b07      	ldr	r3, [sp, #28]
200289fe:	2b00      	cmp	r3, #0
20028a00:	d038      	beq.n	20028a74 <mbedtls_mpi_div_mpi+0x356>
20028a02:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
20028a04:	681b      	ldr	r3, [r3, #0]
20028a06:	602b      	str	r3, [r5, #0]
20028a08:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20028a0a:	a918      	add	r1, sp, #96	@ 0x60
20028a0c:	681b      	ldr	r3, [r3, #0]
20028a0e:	4608      	mov	r0, r1
20028a10:	606b      	str	r3, [r5, #4]
20028a12:	f85a 2c04 	ldr.w	r2, [sl, #-4]
20028a16:	f7ff fe75 	bl	20028704 <mbedtls_mpi_mul_int>
20028a1a:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20028a1c:	4601      	mov	r1, r0
20028a1e:	2800      	cmp	r0, #0
20028a20:	f47f aeb1 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
20028a24:	a81b      	add	r0, sp, #108	@ 0x6c
20028a26:	941d      	str	r4, [sp, #116]	@ 0x74
20028a28:	f7ff fad1 	bl	20027fce <mbedtls_mpi_lset>
20028a2c:	9c1d      	ldr	r4, [sp, #116]	@ 0x74
20028a2e:	2800      	cmp	r0, #0
20028a30:	f47f aea9 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
20028a34:	9b01      	ldr	r3, [sp, #4]
20028a36:	a91b      	add	r1, sp, #108	@ 0x6c
20028a38:	2b01      	cmp	r3, #1
20028a3a:	bf18      	it	ne
20028a3c:	f8db 0000 	ldrne.w	r0, [fp]
20028a40:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
20028a42:	6020      	str	r0, [r4, #0]
20028a44:	681b      	ldr	r3, [r3, #0]
20028a46:	a818      	add	r0, sp, #96	@ 0x60
20028a48:	6063      	str	r3, [r4, #4]
20028a4a:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
20028a4c:	681b      	ldr	r3, [r3, #0]
20028a4e:	60a3      	str	r3, [r4, #8]
20028a50:	f7ff fca4 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20028a54:	2800      	cmp	r0, #0
20028a56:	dcc3      	bgt.n	200289e0 <mbedtls_mpi_div_mpi+0x2c2>
20028a58:	f85a 2c04 	ldr.w	r2, [sl, #-4]
20028a5c:	a912      	add	r1, sp, #72	@ 0x48
20028a5e:	a818      	add	r0, sp, #96	@ 0x60
20028a60:	e9cd 8913 	strd	r8, r9, [sp, #76]	@ 0x4c
20028a64:	f7ff fe4e 	bl	20028704 <mbedtls_mpi_mul_int>
20028a68:	b130      	cbz	r0, 20028a78 <mbedtls_mpi_div_mpi+0x35a>
20028a6a:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20028a6c:	e68b      	b.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028a6e:	f04f 33ff 	mov.w	r3, #4294967295
20028a72:	e7af      	b.n	200289d4 <mbedtls_mpi_div_mpi+0x2b6>
20028a74:	9b07      	ldr	r3, [sp, #28]
20028a76:	e7c6      	b.n	20028a06 <mbedtls_mpi_div_mpi+0x2e8>
20028a78:	f06f 0b1f 	mvn.w	fp, #31
20028a7c:	9b08      	ldr	r3, [sp, #32]
20028a7e:	a818      	add	r0, sp, #96	@ 0x60
20028a80:	fb0b fb03 	mul.w	fp, fp, r3
20028a84:	9b01      	ldr	r3, [sp, #4]
20028a86:	eb0b 1b43 	add.w	fp, fp, r3, lsl #5
20028a8a:	4659      	mov	r1, fp
20028a8c:	f7ff fb4e 	bl	2002812c <mbedtls_mpi_shift_l>
20028a90:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20028a92:	2800      	cmp	r0, #0
20028a94:	f47f ae77 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
20028a98:	a90f      	add	r1, sp, #60	@ 0x3c
20028a9a:	4608      	mov	r0, r1
20028a9c:	aa18      	add	r2, sp, #96	@ 0x60
20028a9e:	e9cd 7610 	strd	r7, r6, [sp, #64]	@ 0x40
20028aa2:	f7ff fd8e 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20028aa6:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
20028aaa:	4601      	mov	r1, r0
20028aac:	2800      	cmp	r0, #0
20028aae:	f47f af5d 	bne.w	2002896c <mbedtls_mpi_div_mpi+0x24e>
20028ab2:	a80f      	add	r0, sp, #60	@ 0x3c
20028ab4:	f7ff fcb3 	bl	2002841e <mbedtls_mpi_cmp_int>
20028ab8:	2800      	cmp	r0, #0
20028aba:	da1d      	bge.n	20028af8 <mbedtls_mpi_div_mpi+0x3da>
20028abc:	a912      	add	r1, sp, #72	@ 0x48
20028abe:	a818      	add	r0, sp, #96	@ 0x60
20028ac0:	f7ff fa5c 	bl	20027f7c <mbedtls_mpi_copy>
20028ac4:	2800      	cmp	r0, #0
20028ac6:	d1d0      	bne.n	20028a6a <mbedtls_mpi_div_mpi+0x34c>
20028ac8:	4659      	mov	r1, fp
20028aca:	a818      	add	r0, sp, #96	@ 0x60
20028acc:	f7ff fb2e 	bl	2002812c <mbedtls_mpi_shift_l>
20028ad0:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20028ad2:	2800      	cmp	r0, #0
20028ad4:	f47f ae57 	bne.w	20028786 <mbedtls_mpi_div_mpi+0x68>
20028ad8:	a90f      	add	r1, sp, #60	@ 0x3c
20028ada:	4608      	mov	r0, r1
20028adc:	aa18      	add	r2, sp, #96	@ 0x60
20028ade:	f7ff fd4a 	bl	20028576 <mbedtls_mpi_add_mpi>
20028ae2:	e9dd 7610 	ldrd	r7, r6, [sp, #64]	@ 0x40
20028ae6:	4601      	mov	r1, r0
20028ae8:	2800      	cmp	r0, #0
20028aea:	f47f af3f 	bne.w	2002896c <mbedtls_mpi_div_mpi+0x24e>
20028aee:	f85a 3c04 	ldr.w	r3, [sl, #-4]
20028af2:	3b01      	subs	r3, #1
20028af4:	f84a 3c04 	str.w	r3, [sl, #-4]
20028af8:	9b01      	ldr	r3, [sp, #4]
20028afa:	f1aa 0a04 	sub.w	sl, sl, #4
20028afe:	3b01      	subs	r3, #1
20028b00:	9301      	str	r3, [sp, #4]
20028b02:	e6e6      	b.n	200288d2 <mbedtls_mpi_div_mpi+0x1b4>
20028b04:	4625      	mov	r5, r4
20028b06:	46a1      	mov	r9, r4
20028b08:	46a0      	mov	r8, r4
20028b0a:	9402      	str	r4, [sp, #8]
20028b0c:	e63b      	b.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028b0e:	4654      	mov	r4, sl
20028b10:	4655      	mov	r5, sl
20028b12:	f8cd a008 	str.w	sl, [sp, #8]
20028b16:	e636      	b.n	20028786 <mbedtls_mpi_div_mpi+0x68>
20028b18:	462c      	mov	r4, r5
20028b1a:	e663      	b.n	200287e4 <mbedtls_mpi_div_mpi+0xc6>
20028b1c:	9903      	ldr	r1, [sp, #12]
20028b1e:	e725      	b.n	2002896c <mbedtls_mpi_div_mpi+0x24e>
20028b20:	f06f 010b 	mvn.w	r1, #11
20028b24:	e61e      	b.n	20028764 <mbedtls_mpi_div_mpi+0x46>

20028b26 <mbedtls_mpi_mod_mpi>:
20028b26:	b570      	push	{r4, r5, r6, lr}
20028b28:	4604      	mov	r4, r0
20028b2a:	460d      	mov	r5, r1
20028b2c:	4610      	mov	r0, r2
20028b2e:	2100      	movs	r1, #0
20028b30:	4616      	mov	r6, r2
20028b32:	f7ff fc74 	bl	2002841e <mbedtls_mpi_cmp_int>
20028b36:	2800      	cmp	r0, #0
20028b38:	db24      	blt.n	20028b84 <mbedtls_mpi_mod_mpi+0x5e>
20028b3a:	462a      	mov	r2, r5
20028b3c:	4633      	mov	r3, r6
20028b3e:	4621      	mov	r1, r4
20028b40:	2000      	movs	r0, #0
20028b42:	f7ff fdec 	bl	2002871e <mbedtls_mpi_div_mpi>
20028b46:	4605      	mov	r5, r0
20028b48:	b138      	cbz	r0, 20028b5a <mbedtls_mpi_mod_mpi+0x34>
20028b4a:	4628      	mov	r0, r5
20028b4c:	bd70      	pop	{r4, r5, r6, pc}
20028b4e:	4632      	mov	r2, r6
20028b50:	4621      	mov	r1, r4
20028b52:	4620      	mov	r0, r4
20028b54:	f7ff fd0f 	bl	20028576 <mbedtls_mpi_add_mpi>
20028b58:	b990      	cbnz	r0, 20028b80 <mbedtls_mpi_mod_mpi+0x5a>
20028b5a:	2100      	movs	r1, #0
20028b5c:	4620      	mov	r0, r4
20028b5e:	f7ff fc5e 	bl	2002841e <mbedtls_mpi_cmp_int>
20028b62:	2800      	cmp	r0, #0
20028b64:	dbf3      	blt.n	20028b4e <mbedtls_mpi_mod_mpi+0x28>
20028b66:	4631      	mov	r1, r6
20028b68:	4620      	mov	r0, r4
20028b6a:	f7ff fc17 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20028b6e:	2800      	cmp	r0, #0
20028b70:	dbeb      	blt.n	20028b4a <mbedtls_mpi_mod_mpi+0x24>
20028b72:	4632      	mov	r2, r6
20028b74:	4621      	mov	r1, r4
20028b76:	4620      	mov	r0, r4
20028b78:	f7ff fd23 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20028b7c:	2800      	cmp	r0, #0
20028b7e:	d0f2      	beq.n	20028b66 <mbedtls_mpi_mod_mpi+0x40>
20028b80:	4605      	mov	r5, r0
20028b82:	e7e2      	b.n	20028b4a <mbedtls_mpi_mod_mpi+0x24>
20028b84:	f06f 0509 	mvn.w	r5, #9
20028b88:	e7df      	b.n	20028b4a <mbedtls_mpi_mod_mpi+0x24>

20028b8a <mbedtls_mpi_exp_mod>:
20028b8a:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20028b8e:	4605      	mov	r5, r0
20028b90:	f2ad 6d54 	subw	sp, sp, #1620	@ 0x654
20028b94:	4688      	mov	r8, r1
20028b96:	4618      	mov	r0, r3
20028b98:	2100      	movs	r1, #0
20028b9a:	461c      	mov	r4, r3
20028b9c:	9203      	str	r2, [sp, #12]
20028b9e:	f7ff fc3e 	bl	2002841e <mbedtls_mpi_cmp_int>
20028ba2:	2800      	cmp	r0, #0
20028ba4:	f2c0 8202 	blt.w	20028fac <mbedtls_mpi_exp_mod+0x422>
20028ba8:	68a3      	ldr	r3, [r4, #8]
20028baa:	681f      	ldr	r7, [r3, #0]
20028bac:	f017 0301 	ands.w	r3, r7, #1
20028bb0:	9305      	str	r3, [sp, #20]
20028bb2:	f000 81fb 	beq.w	20028fac <mbedtls_mpi_exp_mod+0x422>
20028bb6:	2100      	movs	r1, #0
20028bb8:	9803      	ldr	r0, [sp, #12]
20028bba:	f7ff fc30 	bl	2002841e <mbedtls_mpi_cmp_int>
20028bbe:	2800      	cmp	r0, #0
20028bc0:	f2c0 81f4 	blt.w	20028fac <mbedtls_mpi_exp_mod+0x422>
20028bc4:	2100      	movs	r1, #0
20028bc6:	2301      	movs	r3, #1
20028bc8:	f44f 62c0 	mov.w	r2, #1536	@ 0x600
20028bcc:	a814      	add	r0, sp, #80	@ 0x50
20028bce:	e9cd 3108 	strd	r3, r1, [sp, #32]
20028bd2:	e9cd 130a 	strd	r1, r3, [sp, #40]	@ 0x28
20028bd6:	e9cd 110c 	strd	r1, r1, [sp, #48]	@ 0x30
20028bda:	e9cd 310e 	strd	r3, r1, [sp, #56]	@ 0x38
20028bde:	9110      	str	r1, [sp, #64]	@ 0x40
20028be0:	f001 ff1c 	bl	2002aa1c <memset>
20028be4:	9803      	ldr	r0, [sp, #12]
20028be6:	f7ff fa26 	bl	20028036 <mbedtls_mpi_bitlen>
20028bea:	f5b0 7f28 	cmp.w	r0, #672	@ 0x2a0
20028bee:	d233      	bcs.n	20028c58 <mbedtls_mpi_exp_mod+0xce>
20028bf0:	28ef      	cmp	r0, #239	@ 0xef
20028bf2:	d833      	bhi.n	20028c5c <mbedtls_mpi_exp_mod+0xd2>
20028bf4:	284f      	cmp	r0, #79	@ 0x4f
20028bf6:	d833      	bhi.n	20028c60 <mbedtls_mpi_exp_mod+0xd6>
20028bf8:	9b05      	ldr	r3, [sp, #20]
20028bfa:	2818      	cmp	r0, #24
20028bfc:	bf34      	ite	cc
20028bfe:	461e      	movcc	r6, r3
20028c00:	2603      	movcs	r6, #3
20028c02:	6863      	ldr	r3, [r4, #4]
20028c04:	4628      	mov	r0, r5
20028c06:	f103 0901 	add.w	r9, r3, #1
20028c0a:	4649      	mov	r1, r9
20028c0c:	f7ff f98a 	bl	20027f24 <mbedtls_mpi_grow>
20028c10:	b340      	cbz	r0, 20028c64 <mbedtls_mpi_exp_mod+0xda>
20028c12:	f06f 090f 	mvn.w	r9, #15
20028c16:	2301      	movs	r3, #1
20028c18:	1e74      	subs	r4, r6, #1
20028c1a:	fa03 f506 	lsl.w	r5, r3, r6
20028c1e:	260c      	movs	r6, #12
20028c20:	fa03 f404 	lsl.w	r4, r3, r4
20028c24:	af14      	add	r7, sp, #80	@ 0x50
20028c26:	42a5      	cmp	r5, r4
20028c28:	f200 81ba 	bhi.w	20028fa0 <mbedtls_mpi_exp_mod+0x416>
20028c2c:	a817      	add	r0, sp, #92	@ 0x5c
20028c2e:	f7ff f964 	bl	20027efa <mbedtls_mpi_free>
20028c32:	a80b      	add	r0, sp, #44	@ 0x2c
20028c34:	f7ff f961 	bl	20027efa <mbedtls_mpi_free>
20028c38:	a80e      	add	r0, sp, #56	@ 0x38
20028c3a:	f7ff f95e 	bl	20027efa <mbedtls_mpi_free>
20028c3e:	f8dd 3678 	ldr.w	r3, [sp, #1656]	@ 0x678
20028c42:	b10b      	cbz	r3, 20028c48 <mbedtls_mpi_exp_mod+0xbe>
20028c44:	689b      	ldr	r3, [r3, #8]
20028c46:	b913      	cbnz	r3, 20028c4e <mbedtls_mpi_exp_mod+0xc4>
20028c48:	a808      	add	r0, sp, #32
20028c4a:	f7ff f956 	bl	20027efa <mbedtls_mpi_free>
20028c4e:	4648      	mov	r0, r9
20028c50:	f20d 6d54 	addw	sp, sp, #1620	@ 0x654
20028c54:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20028c58:	2606      	movs	r6, #6
20028c5a:	e7d2      	b.n	20028c02 <mbedtls_mpi_exp_mod+0x78>
20028c5c:	2605      	movs	r6, #5
20028c5e:	e7d0      	b.n	20028c02 <mbedtls_mpi_exp_mod+0x78>
20028c60:	2604      	movs	r6, #4
20028c62:	e7ce      	b.n	20028c02 <mbedtls_mpi_exp_mod+0x78>
20028c64:	4649      	mov	r1, r9
20028c66:	a817      	add	r0, sp, #92	@ 0x5c
20028c68:	f7ff f95c 	bl	20027f24 <mbedtls_mpi_grow>
20028c6c:	2800      	cmp	r0, #0
20028c6e:	d1d0      	bne.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028c70:	ea4f 0149 	mov.w	r1, r9, lsl #1
20028c74:	a80b      	add	r0, sp, #44	@ 0x2c
20028c76:	f7ff f955 	bl	20027f24 <mbedtls_mpi_grow>
20028c7a:	2800      	cmp	r0, #0
20028c7c:	d1c9      	bne.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028c7e:	f8d8 3000 	ldr.w	r3, [r8]
20028c82:	9304      	str	r3, [sp, #16]
20028c84:	3301      	adds	r3, #1
20028c86:	d109      	bne.n	20028c9c <mbedtls_mpi_exp_mod+0x112>
20028c88:	4641      	mov	r1, r8
20028c8a:	a80e      	add	r0, sp, #56	@ 0x38
20028c8c:	f7ff f976 	bl	20027f7c <mbedtls_mpi_copy>
20028c90:	2800      	cmp	r0, #0
20028c92:	d1be      	bne.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028c94:	2301      	movs	r3, #1
20028c96:	f10d 0838 	add.w	r8, sp, #56	@ 0x38
20028c9a:	930e      	str	r3, [sp, #56]	@ 0x38
20028c9c:	f8dd 3678 	ldr.w	r3, [sp, #1656]	@ 0x678
20028ca0:	b11b      	cbz	r3, 20028caa <mbedtls_mpi_exp_mod+0x120>
20028ca2:	689b      	ldr	r3, [r3, #8]
20028ca4:	2b00      	cmp	r3, #0
20028ca6:	f040 80ab 	bne.w	20028e00 <mbedtls_mpi_exp_mod+0x276>
20028caa:	2101      	movs	r1, #1
20028cac:	a808      	add	r0, sp, #32
20028cae:	f7ff f98e 	bl	20027fce <mbedtls_mpi_lset>
20028cb2:	2800      	cmp	r0, #0
20028cb4:	d1ad      	bne.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028cb6:	6861      	ldr	r1, [r4, #4]
20028cb8:	a808      	add	r0, sp, #32
20028cba:	0189      	lsls	r1, r1, #6
20028cbc:	f7ff fa36 	bl	2002812c <mbedtls_mpi_shift_l>
20028cc0:	2800      	cmp	r0, #0
20028cc2:	d1a6      	bne.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028cc4:	a908      	add	r1, sp, #32
20028cc6:	4622      	mov	r2, r4
20028cc8:	4608      	mov	r0, r1
20028cca:	f7ff ff2c 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20028cce:	4681      	mov	r9, r0
20028cd0:	2800      	cmp	r0, #0
20028cd2:	d1a0      	bne.n	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028cd4:	f8dd 3678 	ldr.w	r3, [sp, #1656]	@ 0x678
20028cd8:	b13b      	cbz	r3, 20028cea <mbedtls_mpi_exp_mod+0x160>
20028cda:	f8dd 2678 	ldr.w	r2, [sp, #1656]	@ 0x678
20028cde:	ab08      	add	r3, sp, #32
20028ce0:	cb03      	ldmia	r3!, {r0, r1}
20028ce2:	6010      	str	r0, [r2, #0]
20028ce4:	6818      	ldr	r0, [r3, #0]
20028ce6:	6051      	str	r1, [r2, #4]
20028ce8:	6090      	str	r0, [r2, #8]
20028cea:	4621      	mov	r1, r4
20028cec:	4640      	mov	r0, r8
20028cee:	f7ff fb55 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20028cf2:	2800      	cmp	r0, #0
20028cf4:	f2c0 808d 	blt.w	20028e12 <mbedtls_mpi_exp_mod+0x288>
20028cf8:	4622      	mov	r2, r4
20028cfa:	4641      	mov	r1, r8
20028cfc:	a817      	add	r0, sp, #92	@ 0x5c
20028cfe:	f7ff ff12 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20028d02:	4681      	mov	r9, r0
20028d04:	2800      	cmp	r0, #0
20028d06:	d186      	bne.n	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028d08:	1cba      	adds	r2, r7, #2
20028d0a:	0052      	lsls	r2, r2, #1
20028d0c:	f002 0208 	and.w	r2, r2, #8
20028d10:	443a      	add	r2, r7
20028d12:	fb02 f307 	mul.w	r3, r2, r7
20028d16:	f1c3 0302 	rsb	r3, r3, #2
20028d1a:	4353      	muls	r3, r2
20028d1c:	fb03 f207 	mul.w	r2, r3, r7
20028d20:	f1c2 0202 	rsb	r2, r2, #2
20028d24:	4353      	muls	r3, r2
20028d26:	435f      	muls	r7, r3
20028d28:	3f02      	subs	r7, #2
20028d2a:	437b      	muls	r3, r7
20028d2c:	f10d 0b2c 	add.w	fp, sp, #44	@ 0x2c
20028d30:	4622      	mov	r2, r4
20028d32:	f8cd b000 	str.w	fp, [sp]
20028d36:	a908      	add	r1, sp, #32
20028d38:	a817      	add	r0, sp, #92	@ 0x5c
20028d3a:	9302      	str	r3, [sp, #8]
20028d3c:	f7ff fac4 	bl	200282c8 <mpi_montmul>
20028d40:	2800      	cmp	r0, #0
20028d42:	f040 80e4 	bne.w	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028d46:	4628      	mov	r0, r5
20028d48:	a908      	add	r1, sp, #32
20028d4a:	f7ff f917 	bl	20027f7c <mbedtls_mpi_copy>
20028d4e:	2800      	cmp	r0, #0
20028d50:	f47f af5f 	bne.w	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028d54:	2301      	movs	r3, #1
20028d56:	aa07      	add	r2, sp, #28
20028d58:	e9cd 3311 	strd	r3, r3, [sp, #68]	@ 0x44
20028d5c:	9307      	str	r3, [sp, #28]
20028d5e:	9213      	str	r2, [sp, #76]	@ 0x4c
20028d60:	4628      	mov	r0, r5
20028d62:	4622      	mov	r2, r4
20028d64:	9b02      	ldr	r3, [sp, #8]
20028d66:	f8cd b000 	str.w	fp, [sp]
20028d6a:	a911      	add	r1, sp, #68	@ 0x44
20028d6c:	f7ff faac 	bl	200282c8 <mpi_montmul>
20028d70:	2800      	cmp	r0, #0
20028d72:	f040 80cc 	bne.w	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028d76:	2e01      	cmp	r6, #1
20028d78:	d153      	bne.n	20028e22 <mbedtls_mpi_exp_mod+0x298>
20028d7a:	f04f 0900 	mov.w	r9, #0
20028d7e:	464f      	mov	r7, r9
20028d80:	46ca      	mov	sl, r9
20028d82:	46c8      	mov	r8, r9
20028d84:	9b03      	ldr	r3, [sp, #12]
20028d86:	f8d3 b004 	ldr.w	fp, [r3, #4]
20028d8a:	f1ba 0f00 	cmp.w	sl, #0
20028d8e:	f040 80a1 	bne.w	20028ed4 <mbedtls_mpi_exp_mod+0x34a>
20028d92:	f1bb 0f00 	cmp.w	fp, #0
20028d96:	f040 8099 	bne.w	20028ecc <mbedtls_mpi_exp_mod+0x342>
20028d9a:	f04f 0a01 	mov.w	sl, #1
20028d9e:	f10d 092c 	add.w	r9, sp, #44	@ 0x2c
20028da2:	fa0a fa06 	lsl.w	sl, sl, r6
20028da6:	45bb      	cmp	fp, r7
20028da8:	f040 80dd 	bne.w	20028f66 <mbedtls_mpi_exp_mod+0x3dc>
20028dac:	2301      	movs	r3, #1
20028dae:	aa07      	add	r2, sp, #28
20028db0:	e9cd 3311 	strd	r3, r3, [sp, #68]	@ 0x44
20028db4:	9307      	str	r3, [sp, #28]
20028db6:	9213      	str	r2, [sp, #76]	@ 0x4c
20028db8:	f8cd 9000 	str.w	r9, [sp]
20028dbc:	4622      	mov	r2, r4
20028dbe:	4628      	mov	r0, r5
20028dc0:	9b02      	ldr	r3, [sp, #8]
20028dc2:	a911      	add	r1, sp, #68	@ 0x44
20028dc4:	f7ff fa80 	bl	200282c8 <mpi_montmul>
20028dc8:	4681      	mov	r9, r0
20028dca:	2800      	cmp	r0, #0
20028dcc:	f040 809f 	bne.w	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028dd0:	9b04      	ldr	r3, [sp, #16]
20028dd2:	3301      	adds	r3, #1
20028dd4:	f47f af1f 	bne.w	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028dd8:	9b03      	ldr	r3, [sp, #12]
20028dda:	685b      	ldr	r3, [r3, #4]
20028ddc:	2b00      	cmp	r3, #0
20028dde:	f43f af1a 	beq.w	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028de2:	9b03      	ldr	r3, [sp, #12]
20028de4:	689b      	ldr	r3, [r3, #8]
20028de6:	681b      	ldr	r3, [r3, #0]
20028de8:	07db      	lsls	r3, r3, #31
20028dea:	f57f af14 	bpl.w	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028dee:	9b04      	ldr	r3, [sp, #16]
20028df0:	462a      	mov	r2, r5
20028df2:	4621      	mov	r1, r4
20028df4:	4628      	mov	r0, r5
20028df6:	602b      	str	r3, [r5, #0]
20028df8:	f7ff fbbd 	bl	20028576 <mbedtls_mpi_add_mpi>
20028dfc:	4681      	mov	r9, r0
20028dfe:	e70a      	b.n	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028e00:	f8dd 2678 	ldr.w	r2, [sp, #1656]	@ 0x678
20028e04:	ab08      	add	r3, sp, #32
20028e06:	6810      	ldr	r0, [r2, #0]
20028e08:	6851      	ldr	r1, [r2, #4]
20028e0a:	c303      	stmia	r3!, {r0, r1}
20028e0c:	6890      	ldr	r0, [r2, #8]
20028e0e:	6018      	str	r0, [r3, #0]
20028e10:	e76b      	b.n	20028cea <mbedtls_mpi_exp_mod+0x160>
20028e12:	4641      	mov	r1, r8
20028e14:	a817      	add	r0, sp, #92	@ 0x5c
20028e16:	f7ff f8b1 	bl	20027f7c <mbedtls_mpi_copy>
20028e1a:	2800      	cmp	r0, #0
20028e1c:	f43f af74 	beq.w	20028d08 <mbedtls_mpi_exp_mod+0x17e>
20028e20:	e6f7      	b.n	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028e22:	f04f 0a0c 	mov.w	sl, #12
20028e26:	1e77      	subs	r7, r6, #1
20028e28:	6861      	ldr	r1, [r4, #4]
20028e2a:	fa0a fa07 	lsl.w	sl, sl, r7
20028e2e:	f10d 0950 	add.w	r9, sp, #80	@ 0x50
20028e32:	44d1      	add	r9, sl
20028e34:	4648      	mov	r0, r9
20028e36:	3101      	adds	r1, #1
20028e38:	f7ff f874 	bl	20027f24 <mbedtls_mpi_grow>
20028e3c:	2800      	cmp	r0, #0
20028e3e:	f47f aee8 	bne.w	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028e42:	4648      	mov	r0, r9
20028e44:	a917      	add	r1, sp, #92	@ 0x5c
20028e46:	f7ff f899 	bl	20027f7c <mbedtls_mpi_copy>
20028e4a:	2800      	cmp	r0, #0
20028e4c:	f47f aee1 	bne.w	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028e50:	4680      	mov	r8, r0
20028e52:	4622      	mov	r2, r4
20028e54:	4649      	mov	r1, r9
20028e56:	4648      	mov	r0, r9
20028e58:	9b02      	ldr	r3, [sp, #8]
20028e5a:	f8cd b000 	str.w	fp, [sp]
20028e5e:	f7ff fa33 	bl	200282c8 <mpi_montmul>
20028e62:	2800      	cmp	r0, #0
20028e64:	d153      	bne.n	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028e66:	f108 0801 	add.w	r8, r8, #1
20028e6a:	45b8      	cmp	r8, r7
20028e6c:	d3f1      	bcc.n	20028e52 <mbedtls_mpi_exp_mod+0x2c8>
20028e6e:	f04f 0801 	mov.w	r8, #1
20028e72:	f10d 0b50 	add.w	fp, sp, #80	@ 0x50
20028e76:	fa08 f707 	lsl.w	r7, r8, r7
20028e7a:	4447      	add	r7, r8
20028e7c:	44d3      	add	fp, sl
20028e7e:	fa08 f806 	lsl.w	r8, r8, r6
20028e82:	f10d 0a2c 	add.w	sl, sp, #44	@ 0x2c
20028e86:	45b8      	cmp	r8, r7
20028e88:	f67f af77 	bls.w	20028d7a <mbedtls_mpi_exp_mod+0x1f0>
20028e8c:	6861      	ldr	r1, [r4, #4]
20028e8e:	f10b 090c 	add.w	r9, fp, #12
20028e92:	4648      	mov	r0, r9
20028e94:	3101      	adds	r1, #1
20028e96:	f7ff f845 	bl	20027f24 <mbedtls_mpi_grow>
20028e9a:	2800      	cmp	r0, #0
20028e9c:	f47f aeb9 	bne.w	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028ea0:	4659      	mov	r1, fp
20028ea2:	4648      	mov	r0, r9
20028ea4:	f7ff f86a 	bl	20027f7c <mbedtls_mpi_copy>
20028ea8:	2800      	cmp	r0, #0
20028eaa:	f47f aeb2 	bne.w	20028c12 <mbedtls_mpi_exp_mod+0x88>
20028eae:	4622      	mov	r2, r4
20028eb0:	4648      	mov	r0, r9
20028eb2:	9b02      	ldr	r3, [sp, #8]
20028eb4:	f8cd a000 	str.w	sl, [sp]
20028eb8:	a917      	add	r1, sp, #92	@ 0x5c
20028eba:	f7ff fa05 	bl	200282c8 <mpi_montmul>
20028ebe:	bb30      	cbnz	r0, 20028f0e <mbedtls_mpi_exp_mod+0x384>
20028ec0:	46cb      	mov	fp, r9
20028ec2:	3701      	adds	r7, #1
20028ec4:	e7df      	b.n	20028e86 <mbedtls_mpi_exp_mod+0x2fc>
20028ec6:	f04f 0902 	mov.w	r9, #2
20028eca:	e75e      	b.n	20028d8a <mbedtls_mpi_exp_mod+0x200>
20028ecc:	f04f 0a20 	mov.w	sl, #32
20028ed0:	f10b 3bff 	add.w	fp, fp, #4294967295
20028ed4:	9b03      	ldr	r3, [sp, #12]
20028ed6:	f10a 3aff 	add.w	sl, sl, #4294967295
20028eda:	689b      	ldr	r3, [r3, #8]
20028edc:	f853 302b 	ldr.w	r3, [r3, fp, lsl #2]
20028ee0:	fa23 f30a 	lsr.w	r3, r3, sl
20028ee4:	f013 0301 	ands.w	r3, r3, #1
20028ee8:	d114      	bne.n	20028f14 <mbedtls_mpi_exp_mod+0x38a>
20028eea:	f1b9 0f00 	cmp.w	r9, #0
20028eee:	f43f af4c 	beq.w	20028d8a <mbedtls_mpi_exp_mod+0x200>
20028ef2:	f1b9 0f01 	cmp.w	r9, #1
20028ef6:	d10d      	bne.n	20028f14 <mbedtls_mpi_exp_mod+0x38a>
20028ef8:	ab0b      	add	r3, sp, #44	@ 0x2c
20028efa:	9300      	str	r3, [sp, #0]
20028efc:	4622      	mov	r2, r4
20028efe:	4629      	mov	r1, r5
20028f00:	4628      	mov	r0, r5
20028f02:	9b02      	ldr	r3, [sp, #8]
20028f04:	f7ff f9e0 	bl	200282c8 <mpi_montmul>
20028f08:	2800      	cmp	r0, #0
20028f0a:	f43f af3e 	beq.w	20028d8a <mbedtls_mpi_exp_mod+0x200>
20028f0e:	f06f 0903 	mvn.w	r9, #3
20028f12:	e680      	b.n	20028c16 <mbedtls_mpi_exp_mod+0x8c>
20028f14:	3701      	adds	r7, #1
20028f16:	1bf2      	subs	r2, r6, r7
20028f18:	4093      	lsls	r3, r2
20028f1a:	42be      	cmp	r6, r7
20028f1c:	ea48 0803 	orr.w	r8, r8, r3
20028f20:	d1d1      	bne.n	20028ec6 <mbedtls_mpi_exp_mod+0x33c>
20028f22:	f04f 0900 	mov.w	r9, #0
20028f26:	ab0b      	add	r3, sp, #44	@ 0x2c
20028f28:	9300      	str	r3, [sp, #0]
20028f2a:	4622      	mov	r2, r4
20028f2c:	4629      	mov	r1, r5
20028f2e:	4628      	mov	r0, r5
20028f30:	9b02      	ldr	r3, [sp, #8]
20028f32:	f7ff f9c9 	bl	200282c8 <mpi_montmul>
20028f36:	2800      	cmp	r0, #0
20028f38:	d1e9      	bne.n	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028f3a:	f109 0901 	add.w	r9, r9, #1
20028f3e:	454f      	cmp	r7, r9
20028f40:	d8f1      	bhi.n	20028f26 <mbedtls_mpi_exp_mod+0x39c>
20028f42:	200c      	movs	r0, #12
20028f44:	ab0b      	add	r3, sp, #44	@ 0x2c
20028f46:	a914      	add	r1, sp, #80	@ 0x50
20028f48:	fb00 1108 	mla	r1, r0, r8, r1
20028f4c:	9300      	str	r3, [sp, #0]
20028f4e:	4622      	mov	r2, r4
20028f50:	4628      	mov	r0, r5
20028f52:	9b02      	ldr	r3, [sp, #8]
20028f54:	f7ff f9b8 	bl	200282c8 <mpi_montmul>
20028f58:	4607      	mov	r7, r0
20028f5a:	2800      	cmp	r0, #0
20028f5c:	d1d7      	bne.n	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028f5e:	4680      	mov	r8, r0
20028f60:	f8dd 9014 	ldr.w	r9, [sp, #20]
20028f64:	e711      	b.n	20028d8a <mbedtls_mpi_exp_mod+0x200>
20028f66:	4622      	mov	r2, r4
20028f68:	4629      	mov	r1, r5
20028f6a:	4628      	mov	r0, r5
20028f6c:	9b02      	ldr	r3, [sp, #8]
20028f6e:	f8cd 9000 	str.w	r9, [sp]
20028f72:	f7ff f9a9 	bl	200282c8 <mpi_montmul>
20028f76:	2800      	cmp	r0, #0
20028f78:	d1c9      	bne.n	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028f7a:	ea4f 0848 	mov.w	r8, r8, lsl #1
20028f7e:	ea18 0f0a 	tst.w	r8, sl
20028f82:	d102      	bne.n	20028f8a <mbedtls_mpi_exp_mod+0x400>
20028f84:	f10b 0b01 	add.w	fp, fp, #1
20028f88:	e70d      	b.n	20028da6 <mbedtls_mpi_exp_mod+0x21c>
20028f8a:	4622      	mov	r2, r4
20028f8c:	4628      	mov	r0, r5
20028f8e:	9b02      	ldr	r3, [sp, #8]
20028f90:	f8cd 9000 	str.w	r9, [sp]
20028f94:	a917      	add	r1, sp, #92	@ 0x5c
20028f96:	f7ff f997 	bl	200282c8 <mpi_montmul>
20028f9a:	2800      	cmp	r0, #0
20028f9c:	d0f2      	beq.n	20028f84 <mbedtls_mpi_exp_mod+0x3fa>
20028f9e:	e7b6      	b.n	20028f0e <mbedtls_mpi_exp_mod+0x384>
20028fa0:	fb06 7004 	mla	r0, r6, r4, r7
20028fa4:	f7fe ffa9 	bl	20027efa <mbedtls_mpi_free>
20028fa8:	3401      	adds	r4, #1
20028faa:	e63c      	b.n	20028c26 <mbedtls_mpi_exp_mod+0x9c>
20028fac:	f06f 0903 	mvn.w	r9, #3
20028fb0:	e64d      	b.n	20028c4e <mbedtls_mpi_exp_mod+0xc4>

20028fb2 <mbedtls_mpi_gcd>:
20028fb2:	b570      	push	{r4, r5, r6, lr}
20028fb4:	2300      	movs	r3, #0
20028fb6:	2401      	movs	r4, #1
20028fb8:	b086      	sub	sp, #24
20028fba:	4606      	mov	r6, r0
20028fbc:	4668      	mov	r0, sp
20028fbe:	4615      	mov	r5, r2
20028fc0:	e9cd 4300 	strd	r4, r3, [sp]
20028fc4:	e9cd 3402 	strd	r3, r4, [sp, #8]
20028fc8:	e9cd 3304 	strd	r3, r3, [sp, #16]
20028fcc:	f7fe ffd6 	bl	20027f7c <mbedtls_mpi_copy>
20028fd0:	b150      	cbz	r0, 20028fe8 <mbedtls_mpi_gcd+0x36>
20028fd2:	f06f 040f 	mvn.w	r4, #15
20028fd6:	4668      	mov	r0, sp
20028fd8:	f7fe ff8f 	bl	20027efa <mbedtls_mpi_free>
20028fdc:	a803      	add	r0, sp, #12
20028fde:	f7fe ff8c 	bl	20027efa <mbedtls_mpi_free>
20028fe2:	4620      	mov	r0, r4
20028fe4:	b006      	add	sp, #24
20028fe6:	bd70      	pop	{r4, r5, r6, pc}
20028fe8:	4629      	mov	r1, r5
20028fea:	a803      	add	r0, sp, #12
20028fec:	f7fe ffc6 	bl	20027f7c <mbedtls_mpi_copy>
20028ff0:	2800      	cmp	r0, #0
20028ff2:	d1ee      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
20028ff4:	4668      	mov	r0, sp
20028ff6:	f7ff f806 	bl	20028006 <mbedtls_mpi_lsb>
20028ffa:	4605      	mov	r5, r0
20028ffc:	a803      	add	r0, sp, #12
20028ffe:	f7ff f802 	bl	20028006 <mbedtls_mpi_lsb>
20029002:	4285      	cmp	r5, r0
20029004:	bf28      	it	cs
20029006:	4605      	movcs	r5, r0
20029008:	4668      	mov	r0, sp
2002900a:	4629      	mov	r1, r5
2002900c:	f7ff f8e7 	bl	200281de <mbedtls_mpi_shift_r>
20029010:	2800      	cmp	r0, #0
20029012:	d1de      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
20029014:	4629      	mov	r1, r5
20029016:	a803      	add	r0, sp, #12
20029018:	f7ff f8e1 	bl	200281de <mbedtls_mpi_shift_r>
2002901c:	2800      	cmp	r0, #0
2002901e:	d1d8      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
20029020:	9403      	str	r4, [sp, #12]
20029022:	9400      	str	r4, [sp, #0]
20029024:	2100      	movs	r1, #0
20029026:	4668      	mov	r0, sp
20029028:	f7ff f9f9 	bl	2002841e <mbedtls_mpi_cmp_int>
2002902c:	b968      	cbnz	r0, 2002904a <mbedtls_mpi_gcd+0x98>
2002902e:	4629      	mov	r1, r5
20029030:	a803      	add	r0, sp, #12
20029032:	f7ff f87b 	bl	2002812c <mbedtls_mpi_shift_l>
20029036:	2800      	cmp	r0, #0
20029038:	d1cb      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
2002903a:	4630      	mov	r0, r6
2002903c:	a903      	add	r1, sp, #12
2002903e:	f7fe ff9d 	bl	20027f7c <mbedtls_mpi_copy>
20029042:	4604      	mov	r4, r0
20029044:	2800      	cmp	r0, #0
20029046:	d0c6      	beq.n	20028fd6 <mbedtls_mpi_gcd+0x24>
20029048:	e7c3      	b.n	20028fd2 <mbedtls_mpi_gcd+0x20>
2002904a:	4668      	mov	r0, sp
2002904c:	f7fe ffdb 	bl	20028006 <mbedtls_mpi_lsb>
20029050:	4601      	mov	r1, r0
20029052:	4668      	mov	r0, sp
20029054:	f7ff f8c3 	bl	200281de <mbedtls_mpi_shift_r>
20029058:	2800      	cmp	r0, #0
2002905a:	d1ba      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
2002905c:	a803      	add	r0, sp, #12
2002905e:	f7fe ffd2 	bl	20028006 <mbedtls_mpi_lsb>
20029062:	4601      	mov	r1, r0
20029064:	a803      	add	r0, sp, #12
20029066:	f7ff f8ba 	bl	200281de <mbedtls_mpi_shift_r>
2002906a:	2800      	cmp	r0, #0
2002906c:	d1b1      	bne.n	20028fd2 <mbedtls_mpi_gcd+0x20>
2002906e:	4668      	mov	r0, sp
20029070:	a903      	add	r1, sp, #12
20029072:	f7ff f993 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029076:	2800      	cmp	r0, #0
20029078:	db0e      	blt.n	20029098 <mbedtls_mpi_gcd+0xe6>
2002907a:	4669      	mov	r1, sp
2002907c:	4668      	mov	r0, sp
2002907e:	aa03      	add	r2, sp, #12
20029080:	f7ff fa3c 	bl	200284fc <mbedtls_mpi_sub_abs>
20029084:	4604      	mov	r4, r0
20029086:	2800      	cmp	r0, #0
20029088:	d1a5      	bne.n	20028fd6 <mbedtls_mpi_gcd+0x24>
2002908a:	2101      	movs	r1, #1
2002908c:	4668      	mov	r0, sp
2002908e:	f7ff f8a6 	bl	200281de <mbedtls_mpi_shift_r>
20029092:	2800      	cmp	r0, #0
20029094:	d0c6      	beq.n	20029024 <mbedtls_mpi_gcd+0x72>
20029096:	e79c      	b.n	20028fd2 <mbedtls_mpi_gcd+0x20>
20029098:	a903      	add	r1, sp, #12
2002909a:	466a      	mov	r2, sp
2002909c:	4608      	mov	r0, r1
2002909e:	f7ff fa2d 	bl	200284fc <mbedtls_mpi_sub_abs>
200290a2:	4604      	mov	r4, r0
200290a4:	2800      	cmp	r0, #0
200290a6:	d196      	bne.n	20028fd6 <mbedtls_mpi_gcd+0x24>
200290a8:	2101      	movs	r1, #1
200290aa:	a803      	add	r0, sp, #12
200290ac:	e7ef      	b.n	2002908e <mbedtls_mpi_gcd+0xdc>

200290ae <mbedtls_mpi_fill_random>:
200290ae:	b570      	push	{r4, r5, r6, lr}
200290b0:	f5b1 6f80 	cmp.w	r1, #1024	@ 0x400
200290b4:	4605      	mov	r5, r0
200290b6:	460c      	mov	r4, r1
200290b8:	4616      	mov	r6, r2
200290ba:	4618      	mov	r0, r3
200290bc:	f5ad 6d80 	sub.w	sp, sp, #1024	@ 0x400
200290c0:	d80f      	bhi.n	200290e2 <mbedtls_mpi_fill_random+0x34>
200290c2:	460a      	mov	r2, r1
200290c4:	4669      	mov	r1, sp
200290c6:	47b0      	blx	r6
200290c8:	b940      	cbnz	r0, 200290dc <mbedtls_mpi_fill_random+0x2e>
200290ca:	4622      	mov	r2, r4
200290cc:	4669      	mov	r1, sp
200290ce:	4628      	mov	r0, r5
200290d0:	f7fe ffd4 	bl	2002807c <mbedtls_mpi_read_binary>
200290d4:	2800      	cmp	r0, #0
200290d6:	bf18      	it	ne
200290d8:	f06f 000f 	mvnne.w	r0, #15
200290dc:	f50d 6d80 	add.w	sp, sp, #1024	@ 0x400
200290e0:	bd70      	pop	{r4, r5, r6, pc}
200290e2:	f06f 0003 	mvn.w	r0, #3
200290e6:	e7f9      	b.n	200290dc <mbedtls_mpi_fill_random+0x2e>

200290e8 <mbedtls_mpi_inv_mod>:
200290e8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200290ec:	b09f      	sub	sp, #124	@ 0x7c
200290ee:	9001      	str	r0, [sp, #4]
200290f0:	460f      	mov	r7, r1
200290f2:	4610      	mov	r0, r2
200290f4:	2101      	movs	r1, #1
200290f6:	4692      	mov	sl, r2
200290f8:	f7ff f991 	bl	2002841e <mbedtls_mpi_cmp_int>
200290fc:	2800      	cmp	r0, #0
200290fe:	f340 81b5 	ble.w	2002946c <mbedtls_mpi_inv_mod+0x384>
20029102:	2500      	movs	r5, #0
20029104:	2601      	movs	r6, #1
20029106:	4652      	mov	r2, sl
20029108:	4639      	mov	r1, r7
2002910a:	a803      	add	r0, sp, #12
2002910c:	e9cd 6506 	strd	r6, r5, [sp, #24]
20029110:	e9cd 5608 	strd	r5, r6, [sp, #32]
20029114:	e9cd 650c 	strd	r6, r5, [sp, #48]	@ 0x30
20029118:	e9cd 650f 	strd	r6, r5, [sp, #60]	@ 0x3c
2002911c:	e9cd 6503 	strd	r6, r5, [sp, #12]
20029120:	e9cd 6512 	strd	r6, r5, [sp, #72]	@ 0x48
20029124:	e9cd 5614 	strd	r5, r6, [sp, #80]	@ 0x50
20029128:	e9cd 6518 	strd	r6, r5, [sp, #96]	@ 0x60
2002912c:	e9cd 651b 	strd	r6, r5, [sp, #108]	@ 0x6c
20029130:	950a      	str	r5, [sp, #40]	@ 0x28
20029132:	9505      	str	r5, [sp, #20]
20029134:	9516      	str	r5, [sp, #88]	@ 0x58
20029136:	f7ff ff3c 	bl	20028fb2 <mbedtls_mpi_gcd>
2002913a:	4604      	mov	r4, r0
2002913c:	2800      	cmp	r0, #0
2002913e:	f040 8182 	bne.w	20029446 <mbedtls_mpi_inv_mod+0x35e>
20029142:	4631      	mov	r1, r6
20029144:	a803      	add	r0, sp, #12
20029146:	f7ff f96a 	bl	2002841e <mbedtls_mpi_cmp_int>
2002914a:	4605      	mov	r5, r0
2002914c:	2800      	cmp	r0, #0
2002914e:	f040 8171 	bne.w	20029434 <mbedtls_mpi_inv_mod+0x34c>
20029152:	4652      	mov	r2, sl
20029154:	4639      	mov	r1, r7
20029156:	a806      	add	r0, sp, #24
20029158:	f7ff fce5 	bl	20028b26 <mbedtls_mpi_mod_mpi>
2002915c:	4604      	mov	r4, r0
2002915e:	2800      	cmp	r0, #0
20029160:	f040 8171 	bne.w	20029446 <mbedtls_mpi_inv_mod+0x35e>
20029164:	900b      	str	r0, [sp, #44]	@ 0x2c
20029166:	a906      	add	r1, sp, #24
20029168:	a809      	add	r0, sp, #36	@ 0x24
2002916a:	f7fe ff07 	bl	20027f7c <mbedtls_mpi_copy>
2002916e:	f8dd 902c 	ldr.w	r9, [sp, #44]	@ 0x2c
20029172:	b920      	cbnz	r0, 2002917e <mbedtls_mpi_inv_mod+0x96>
20029174:	4651      	mov	r1, sl
20029176:	a812      	add	r0, sp, #72	@ 0x48
20029178:	f7fe ff00 	bl	20027f7c <mbedtls_mpi_copy>
2002917c:	b130      	cbz	r0, 2002918c <mbedtls_mpi_inv_mod+0xa4>
2002917e:	f04f 0b00 	mov.w	fp, #0
20029182:	465d      	mov	r5, fp
20029184:	46d8      	mov	r8, fp
20029186:	465e      	mov	r6, fp
20029188:	465f      	mov	r7, fp
2002918a:	e0f5      	b.n	20029378 <mbedtls_mpi_inv_mod+0x290>
2002918c:	9017      	str	r0, [sp, #92]	@ 0x5c
2002918e:	4651      	mov	r1, sl
20029190:	a815      	add	r0, sp, #84	@ 0x54
20029192:	f7fe fef3 	bl	20027f7c <mbedtls_mpi_copy>
20029196:	f8dd 805c 	ldr.w	r8, [sp, #92]	@ 0x5c
2002919a:	2800      	cmp	r0, #0
2002919c:	f040 8159 	bne.w	20029452 <mbedtls_mpi_inv_mod+0x36a>
200291a0:	4631      	mov	r1, r6
200291a2:	900e      	str	r0, [sp, #56]	@ 0x38
200291a4:	a80c      	add	r0, sp, #48	@ 0x30
200291a6:	f7fe ff12 	bl	20027fce <mbedtls_mpi_lset>
200291aa:	9f0e      	ldr	r7, [sp, #56]	@ 0x38
200291ac:	4601      	mov	r1, r0
200291ae:	2800      	cmp	r0, #0
200291b0:	f040 8152 	bne.w	20029458 <mbedtls_mpi_inv_mod+0x370>
200291b4:	9011      	str	r0, [sp, #68]	@ 0x44
200291b6:	a80f      	add	r0, sp, #60	@ 0x3c
200291b8:	f7fe ff09 	bl	20027fce <mbedtls_mpi_lset>
200291bc:	9e11      	ldr	r6, [sp, #68]	@ 0x44
200291be:	4683      	mov	fp, r0
200291c0:	2800      	cmp	r0, #0
200291c2:	f040 814d 	bne.w	20029460 <mbedtls_mpi_inv_mod+0x378>
200291c6:	4601      	mov	r1, r0
200291c8:	901a      	str	r0, [sp, #104]	@ 0x68
200291ca:	a818      	add	r0, sp, #96	@ 0x60
200291cc:	f7fe feff 	bl	20027fce <mbedtls_mpi_lset>
200291d0:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
200291d2:	2800      	cmp	r0, #0
200291d4:	f040 8147 	bne.w	20029466 <mbedtls_mpi_inv_mod+0x37e>
200291d8:	2101      	movs	r1, #1
200291da:	a81b      	add	r0, sp, #108	@ 0x6c
200291dc:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
200291e0:	f7fe fef5 	bl	20027fce <mbedtls_mpi_lset>
200291e4:	f8dd b074 	ldr.w	fp, [sp, #116]	@ 0x74
200291e8:	2800      	cmp	r0, #0
200291ea:	f040 80c5 	bne.w	20029378 <mbedtls_mpi_inv_mod+0x290>
200291ee:	f8d9 2000 	ldr.w	r2, [r9]
200291f2:	07d0      	lsls	r0, r2, #31
200291f4:	d554      	bpl.n	200292a0 <mbedtls_mpi_inv_mod+0x1b8>
200291f6:	f8d8 2000 	ldr.w	r2, [r8]
200291fa:	07d3      	lsls	r3, r2, #31
200291fc:	f140 8083 	bpl.w	20029306 <mbedtls_mpi_inv_mod+0x21e>
20029200:	a915      	add	r1, sp, #84	@ 0x54
20029202:	a809      	add	r0, sp, #36	@ 0x24
20029204:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
20029208:	f8cd 805c 	str.w	r8, [sp, #92]	@ 0x5c
2002920c:	f7ff f8c6 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029210:	2800      	cmp	r0, #0
20029212:	f2c0 80b4 	blt.w	2002937e <mbedtls_mpi_inv_mod+0x296>
20029216:	a909      	add	r1, sp, #36	@ 0x24
20029218:	4608      	mov	r0, r1
2002921a:	aa15      	add	r2, sp, #84	@ 0x54
2002921c:	f7ff f9d1 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20029220:	f8dd 902c 	ldr.w	r9, [sp, #44]	@ 0x2c
20029224:	4604      	mov	r4, r0
20029226:	2800      	cmp	r0, #0
20029228:	f040 80d1 	bne.w	200293ce <mbedtls_mpi_inv_mod+0x2e6>
2002922c:	a90c      	add	r1, sp, #48	@ 0x30
2002922e:	4608      	mov	r0, r1
20029230:	aa18      	add	r2, sp, #96	@ 0x60
20029232:	970e      	str	r7, [sp, #56]	@ 0x38
20029234:	951a      	str	r5, [sp, #104]	@ 0x68
20029236:	f7ff f9c4 	bl	200285c2 <mbedtls_mpi_sub_mpi>
2002923a:	9f0e      	ldr	r7, [sp, #56]	@ 0x38
2002923c:	4604      	mov	r4, r0
2002923e:	2800      	cmp	r0, #0
20029240:	f040 80c5 	bne.w	200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029244:	a90f      	add	r1, sp, #60	@ 0x3c
20029246:	4608      	mov	r0, r1
20029248:	aa1b      	add	r2, sp, #108	@ 0x6c
2002924a:	9611      	str	r6, [sp, #68]	@ 0x44
2002924c:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
20029250:	f7ff f9b7 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20029254:	9e11      	ldr	r6, [sp, #68]	@ 0x44
20029256:	4604      	mov	r4, r0
20029258:	2800      	cmp	r0, #0
2002925a:	f040 80b8 	bne.w	200293ce <mbedtls_mpi_inv_mod+0x2e6>
2002925e:	2100      	movs	r1, #0
20029260:	a809      	add	r0, sp, #36	@ 0x24
20029262:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
20029266:	f7ff f8da 	bl	2002841e <mbedtls_mpi_cmp_int>
2002926a:	2800      	cmp	r0, #0
2002926c:	d1bf      	bne.n	200291ee <mbedtls_mpi_inv_mod+0x106>
2002926e:	2100      	movs	r1, #0
20029270:	a818      	add	r0, sp, #96	@ 0x60
20029272:	951a      	str	r5, [sp, #104]	@ 0x68
20029274:	f7ff f8d3 	bl	2002841e <mbedtls_mpi_cmp_int>
20029278:	2800      	cmp	r0, #0
2002927a:	f2c0 809e 	blt.w	200293ba <mbedtls_mpi_inv_mod+0x2d2>
2002927e:	4651      	mov	r1, sl
20029280:	a818      	add	r0, sp, #96	@ 0x60
20029282:	951a      	str	r5, [sp, #104]	@ 0x68
20029284:	f7ff f88a 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029288:	2800      	cmp	r0, #0
2002928a:	f280 80c8 	bge.w	2002941e <mbedtls_mpi_inv_mod+0x336>
2002928e:	9801      	ldr	r0, [sp, #4]
20029290:	a918      	add	r1, sp, #96	@ 0x60
20029292:	f7fe fe73 	bl	20027f7c <mbedtls_mpi_copy>
20029296:	1e04      	subs	r4, r0, #0
20029298:	bf18      	it	ne
2002929a:	f06f 040f 	mvnne.w	r4, #15
2002929e:	e096      	b.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
200292a0:	2101      	movs	r1, #1
200292a2:	a809      	add	r0, sp, #36	@ 0x24
200292a4:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
200292a8:	f7fe ff99 	bl	200281de <mbedtls_mpi_shift_r>
200292ac:	f8dd 902c 	ldr.w	r9, [sp, #44]	@ 0x2c
200292b0:	2800      	cmp	r0, #0
200292b2:	d161      	bne.n	20029378 <mbedtls_mpi_inv_mod+0x290>
200292b4:	683a      	ldr	r2, [r7, #0]
200292b6:	07d3      	lsls	r3, r2, #31
200292b8:	d402      	bmi.n	200292c0 <mbedtls_mpi_inv_mod+0x1d8>
200292ba:	6832      	ldr	r2, [r6, #0]
200292bc:	07d4      	lsls	r4, r2, #31
200292be:	d513      	bpl.n	200292e8 <mbedtls_mpi_inv_mod+0x200>
200292c0:	a90c      	add	r1, sp, #48	@ 0x30
200292c2:	4608      	mov	r0, r1
200292c4:	aa12      	add	r2, sp, #72	@ 0x48
200292c6:	970e      	str	r7, [sp, #56]	@ 0x38
200292c8:	f7ff f955 	bl	20028576 <mbedtls_mpi_add_mpi>
200292cc:	9f0e      	ldr	r7, [sp, #56]	@ 0x38
200292ce:	4604      	mov	r4, r0
200292d0:	2800      	cmp	r0, #0
200292d2:	d17c      	bne.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
200292d4:	a90f      	add	r1, sp, #60	@ 0x3c
200292d6:	4608      	mov	r0, r1
200292d8:	aa06      	add	r2, sp, #24
200292da:	9611      	str	r6, [sp, #68]	@ 0x44
200292dc:	f7ff f971 	bl	200285c2 <mbedtls_mpi_sub_mpi>
200292e0:	9e11      	ldr	r6, [sp, #68]	@ 0x44
200292e2:	4604      	mov	r4, r0
200292e4:	2800      	cmp	r0, #0
200292e6:	d172      	bne.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
200292e8:	2101      	movs	r1, #1
200292ea:	a80c      	add	r0, sp, #48	@ 0x30
200292ec:	970e      	str	r7, [sp, #56]	@ 0x38
200292ee:	f7fe ff76 	bl	200281de <mbedtls_mpi_shift_r>
200292f2:	9f0e      	ldr	r7, [sp, #56]	@ 0x38
200292f4:	2800      	cmp	r0, #0
200292f6:	d13f      	bne.n	20029378 <mbedtls_mpi_inv_mod+0x290>
200292f8:	2101      	movs	r1, #1
200292fa:	a80f      	add	r0, sp, #60	@ 0x3c
200292fc:	9611      	str	r6, [sp, #68]	@ 0x44
200292fe:	f7fe ff6e 	bl	200281de <mbedtls_mpi_shift_r>
20029302:	9e11      	ldr	r6, [sp, #68]	@ 0x44
20029304:	e770      	b.n	200291e8 <mbedtls_mpi_inv_mod+0x100>
20029306:	2101      	movs	r1, #1
20029308:	a815      	add	r0, sp, #84	@ 0x54
2002930a:	f8cd 805c 	str.w	r8, [sp, #92]	@ 0x5c
2002930e:	f7fe ff66 	bl	200281de <mbedtls_mpi_shift_r>
20029312:	f8dd 805c 	ldr.w	r8, [sp, #92]	@ 0x5c
20029316:	2800      	cmp	r0, #0
20029318:	d12e      	bne.n	20029378 <mbedtls_mpi_inv_mod+0x290>
2002931a:	682a      	ldr	r2, [r5, #0]
2002931c:	07d1      	lsls	r1, r2, #31
2002931e:	d403      	bmi.n	20029328 <mbedtls_mpi_inv_mod+0x240>
20029320:	f8db 2000 	ldr.w	r2, [fp]
20029324:	07d2      	lsls	r2, r2, #31
20029326:	d515      	bpl.n	20029354 <mbedtls_mpi_inv_mod+0x26c>
20029328:	a918      	add	r1, sp, #96	@ 0x60
2002932a:	4608      	mov	r0, r1
2002932c:	aa12      	add	r2, sp, #72	@ 0x48
2002932e:	951a      	str	r5, [sp, #104]	@ 0x68
20029330:	f7ff f921 	bl	20028576 <mbedtls_mpi_add_mpi>
20029334:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20029336:	4604      	mov	r4, r0
20029338:	2800      	cmp	r0, #0
2002933a:	d148      	bne.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
2002933c:	a91b      	add	r1, sp, #108	@ 0x6c
2002933e:	4608      	mov	r0, r1
20029340:	aa06      	add	r2, sp, #24
20029342:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
20029346:	f7ff f93c 	bl	200285c2 <mbedtls_mpi_sub_mpi>
2002934a:	f8dd b074 	ldr.w	fp, [sp, #116]	@ 0x74
2002934e:	4604      	mov	r4, r0
20029350:	2800      	cmp	r0, #0
20029352:	d13c      	bne.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029354:	2101      	movs	r1, #1
20029356:	a818      	add	r0, sp, #96	@ 0x60
20029358:	951a      	str	r5, [sp, #104]	@ 0x68
2002935a:	f7fe ff40 	bl	200281de <mbedtls_mpi_shift_r>
2002935e:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
20029360:	b950      	cbnz	r0, 20029378 <mbedtls_mpi_inv_mod+0x290>
20029362:	2101      	movs	r1, #1
20029364:	a81b      	add	r0, sp, #108	@ 0x6c
20029366:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
2002936a:	f7fe ff38 	bl	200281de <mbedtls_mpi_shift_r>
2002936e:	f8dd b074 	ldr.w	fp, [sp, #116]	@ 0x74
20029372:	2800      	cmp	r0, #0
20029374:	f43f af3f 	beq.w	200291f6 <mbedtls_mpi_inv_mod+0x10e>
20029378:	f06f 040f 	mvn.w	r4, #15
2002937c:	e027      	b.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
2002937e:	a915      	add	r1, sp, #84	@ 0x54
20029380:	4608      	mov	r0, r1
20029382:	aa09      	add	r2, sp, #36	@ 0x24
20029384:	f7ff f91d 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20029388:	f8dd 805c 	ldr.w	r8, [sp, #92]	@ 0x5c
2002938c:	4604      	mov	r4, r0
2002938e:	b9f0      	cbnz	r0, 200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029390:	a918      	add	r1, sp, #96	@ 0x60
20029392:	4608      	mov	r0, r1
20029394:	aa0c      	add	r2, sp, #48	@ 0x30
20029396:	951a      	str	r5, [sp, #104]	@ 0x68
20029398:	970e      	str	r7, [sp, #56]	@ 0x38
2002939a:	f7ff f912 	bl	200285c2 <mbedtls_mpi_sub_mpi>
2002939e:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
200293a0:	4604      	mov	r4, r0
200293a2:	b9a0      	cbnz	r0, 200293ce <mbedtls_mpi_inv_mod+0x2e6>
200293a4:	a91b      	add	r1, sp, #108	@ 0x6c
200293a6:	4608      	mov	r0, r1
200293a8:	aa0f      	add	r2, sp, #60	@ 0x3c
200293aa:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
200293ae:	9611      	str	r6, [sp, #68]	@ 0x44
200293b0:	f7ff f907 	bl	200285c2 <mbedtls_mpi_sub_mpi>
200293b4:	f8dd b074 	ldr.w	fp, [sp, #116]	@ 0x74
200293b8:	e74d      	b.n	20029256 <mbedtls_mpi_inv_mod+0x16e>
200293ba:	a918      	add	r1, sp, #96	@ 0x60
200293bc:	4652      	mov	r2, sl
200293be:	4608      	mov	r0, r1
200293c0:	f7ff f8d9 	bl	20028576 <mbedtls_mpi_add_mpi>
200293c4:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
200293c6:	4604      	mov	r4, r0
200293c8:	2800      	cmp	r0, #0
200293ca:	f43f af50 	beq.w	2002926e <mbedtls_mpi_inv_mod+0x186>
200293ce:	a806      	add	r0, sp, #24
200293d0:	f7fe fd93 	bl	20027efa <mbedtls_mpi_free>
200293d4:	a809      	add	r0, sp, #36	@ 0x24
200293d6:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
200293da:	f7fe fd8e 	bl	20027efa <mbedtls_mpi_free>
200293de:	a80c      	add	r0, sp, #48	@ 0x30
200293e0:	970e      	str	r7, [sp, #56]	@ 0x38
200293e2:	f7fe fd8a 	bl	20027efa <mbedtls_mpi_free>
200293e6:	a80f      	add	r0, sp, #60	@ 0x3c
200293e8:	9611      	str	r6, [sp, #68]	@ 0x44
200293ea:	f7fe fd86 	bl	20027efa <mbedtls_mpi_free>
200293ee:	a803      	add	r0, sp, #12
200293f0:	f7fe fd83 	bl	20027efa <mbedtls_mpi_free>
200293f4:	a812      	add	r0, sp, #72	@ 0x48
200293f6:	f7fe fd80 	bl	20027efa <mbedtls_mpi_free>
200293fa:	a815      	add	r0, sp, #84	@ 0x54
200293fc:	f8cd 805c 	str.w	r8, [sp, #92]	@ 0x5c
20029400:	f7fe fd7b 	bl	20027efa <mbedtls_mpi_free>
20029404:	a818      	add	r0, sp, #96	@ 0x60
20029406:	951a      	str	r5, [sp, #104]	@ 0x68
20029408:	f7fe fd77 	bl	20027efa <mbedtls_mpi_free>
2002940c:	a81b      	add	r0, sp, #108	@ 0x6c
2002940e:	f8cd b074 	str.w	fp, [sp, #116]	@ 0x74
20029412:	f7fe fd72 	bl	20027efa <mbedtls_mpi_free>
20029416:	4620      	mov	r0, r4
20029418:	b01f      	add	sp, #124	@ 0x7c
2002941a:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002941e:	a918      	add	r1, sp, #96	@ 0x60
20029420:	4652      	mov	r2, sl
20029422:	4608      	mov	r0, r1
20029424:	f7ff f8cd 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20029428:	9d1a      	ldr	r5, [sp, #104]	@ 0x68
2002942a:	4604      	mov	r4, r0
2002942c:	2800      	cmp	r0, #0
2002942e:	f43f af26 	beq.w	2002927e <mbedtls_mpi_inv_mod+0x196>
20029432:	e7cc      	b.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029434:	46a3      	mov	fp, r4
20029436:	4625      	mov	r5, r4
20029438:	46a0      	mov	r8, r4
2002943a:	4626      	mov	r6, r4
2002943c:	4627      	mov	r7, r4
2002943e:	46a1      	mov	r9, r4
20029440:	f06f 040d 	mvn.w	r4, #13
20029444:	e7c3      	b.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029446:	46ab      	mov	fp, r5
20029448:	46a8      	mov	r8, r5
2002944a:	462e      	mov	r6, r5
2002944c:	462f      	mov	r7, r5
2002944e:	46a9      	mov	r9, r5
20029450:	e7bd      	b.n	200293ce <mbedtls_mpi_inv_mod+0x2e6>
20029452:	46a3      	mov	fp, r4
20029454:	4625      	mov	r5, r4
20029456:	e696      	b.n	20029186 <mbedtls_mpi_inv_mod+0x9e>
20029458:	46a3      	mov	fp, r4
2002945a:	4625      	mov	r5, r4
2002945c:	4626      	mov	r6, r4
2002945e:	e78b      	b.n	20029378 <mbedtls_mpi_inv_mod+0x290>
20029460:	46a3      	mov	fp, r4
20029462:	4625      	mov	r5, r4
20029464:	e788      	b.n	20029378 <mbedtls_mpi_inv_mod+0x290>
20029466:	f04f 0b00 	mov.w	fp, #0
2002946a:	e785      	b.n	20029378 <mbedtls_mpi_inv_mod+0x290>
2002946c:	f06f 0403 	mvn.w	r4, #3
20029470:	e7d1      	b.n	20029416 <mbedtls_mpi_inv_mod+0x32e>
	...

20029474 <mbedtls_oid_get_pk_alg>:
20029474:	b570      	push	{r4, r5, r6, lr}
20029476:	460e      	mov	r6, r1
20029478:	4605      	mov	r5, r0
2002947a:	b110      	cbz	r0, 20029482 <mbedtls_oid_get_pk_alg+0xe>
2002947c:	4c09      	ldr	r4, [pc, #36]	@ (200294a4 <mbedtls_oid_get_pk_alg+0x30>)
2002947e:	6820      	ldr	r0, [r4, #0]
20029480:	b910      	cbnz	r0, 20029488 <mbedtls_oid_get_pk_alg+0x14>
20029482:	f06f 002d 	mvn.w	r0, #45	@ 0x2d
20029486:	bd70      	pop	{r4, r5, r6, pc}
20029488:	686b      	ldr	r3, [r5, #4]
2002948a:	6862      	ldr	r2, [r4, #4]
2002948c:	429a      	cmp	r2, r3
2002948e:	d103      	bne.n	20029498 <mbedtls_oid_get_pk_alg+0x24>
20029490:	68a9      	ldr	r1, [r5, #8]
20029492:	f001 fab3 	bl	2002a9fc <memcmp>
20029496:	b108      	cbz	r0, 2002949c <mbedtls_oid_get_pk_alg+0x28>
20029498:	3414      	adds	r4, #20
2002949a:	e7f0      	b.n	2002947e <mbedtls_oid_get_pk_alg+0xa>
2002949c:	7c23      	ldrb	r3, [r4, #16]
2002949e:	7033      	strb	r3, [r6, #0]
200294a0:	e7f1      	b.n	20029486 <mbedtls_oid_get_pk_alg+0x12>
200294a2:	bf00      	nop
200294a4:	2002c3ec 	.word	0x2002c3ec

200294a8 <mbedtls_oid_get_md_alg>:
200294a8:	b570      	push	{r4, r5, r6, lr}
200294aa:	460e      	mov	r6, r1
200294ac:	4605      	mov	r5, r0
200294ae:	b110      	cbz	r0, 200294b6 <mbedtls_oid_get_md_alg+0xe>
200294b0:	4c09      	ldr	r4, [pc, #36]	@ (200294d8 <mbedtls_oid_get_md_alg+0x30>)
200294b2:	6820      	ldr	r0, [r4, #0]
200294b4:	b910      	cbnz	r0, 200294bc <mbedtls_oid_get_md_alg+0x14>
200294b6:	f06f 002d 	mvn.w	r0, #45	@ 0x2d
200294ba:	bd70      	pop	{r4, r5, r6, pc}
200294bc:	686b      	ldr	r3, [r5, #4]
200294be:	6862      	ldr	r2, [r4, #4]
200294c0:	429a      	cmp	r2, r3
200294c2:	d103      	bne.n	200294cc <mbedtls_oid_get_md_alg+0x24>
200294c4:	68a9      	ldr	r1, [r5, #8]
200294c6:	f001 fa99 	bl	2002a9fc <memcmp>
200294ca:	b108      	cbz	r0, 200294d0 <mbedtls_oid_get_md_alg+0x28>
200294cc:	3414      	adds	r4, #20
200294ce:	e7f0      	b.n	200294b2 <mbedtls_oid_get_md_alg+0xa>
200294d0:	7c23      	ldrb	r3, [r4, #16]
200294d2:	7033      	strb	r3, [r6, #0]
200294d4:	e7f1      	b.n	200294ba <mbedtls_oid_get_md_alg+0x12>
200294d6:	bf00      	nop
200294d8:	2002c388 	.word	0x2002c388

200294dc <mbedtls_oid_get_oid_by_md>:
200294dc:	b530      	push	{r4, r5, lr}
200294de:	4b08      	ldr	r3, [pc, #32]	@ (20029500 <mbedtls_oid_get_oid_by_md+0x24>)
200294e0:	681c      	ldr	r4, [r3, #0]
200294e2:	b914      	cbnz	r4, 200294ea <mbedtls_oid_get_oid_by_md+0xe>
200294e4:	f06f 002d 	mvn.w	r0, #45	@ 0x2d
200294e8:	e006      	b.n	200294f8 <mbedtls_oid_get_oid_by_md+0x1c>
200294ea:	7c1d      	ldrb	r5, [r3, #16]
200294ec:	4285      	cmp	r5, r0
200294ee:	d104      	bne.n	200294fa <mbedtls_oid_get_oid_by_md+0x1e>
200294f0:	2000      	movs	r0, #0
200294f2:	600c      	str	r4, [r1, #0]
200294f4:	685b      	ldr	r3, [r3, #4]
200294f6:	6013      	str	r3, [r2, #0]
200294f8:	bd30      	pop	{r4, r5, pc}
200294fa:	3314      	adds	r3, #20
200294fc:	e7f0      	b.n	200294e0 <mbedtls_oid_get_oid_by_md+0x4>
200294fe:	bf00      	nop
20029500:	2002c388 	.word	0x2002c388

20029504 <mbedtls_pk_init>:
20029504:	b110      	cbz	r0, 2002950c <mbedtls_pk_init+0x8>
20029506:	2300      	movs	r3, #0
20029508:	e9c0 3300 	strd	r3, r3, [r0]
2002950c:	4770      	bx	lr

2002950e <mbedtls_pk_free>:
2002950e:	b510      	push	{r4, lr}
20029510:	4604      	mov	r4, r0
20029512:	b160      	cbz	r0, 2002952e <mbedtls_pk_free+0x20>
20029514:	6803      	ldr	r3, [r0, #0]
20029516:	b153      	cbz	r3, 2002952e <mbedtls_pk_free+0x20>
20029518:	6a9b      	ldr	r3, [r3, #40]	@ 0x28
2002951a:	6840      	ldr	r0, [r0, #4]
2002951c:	4798      	blx	r3
2002951e:	2100      	movs	r1, #0
20029520:	f104 0308 	add.w	r3, r4, #8
20029524:	4622      	mov	r2, r4
20029526:	3401      	adds	r4, #1
20029528:	429c      	cmp	r4, r3
2002952a:	7011      	strb	r1, [r2, #0]
2002952c:	d1fa      	bne.n	20029524 <mbedtls_pk_free+0x16>
2002952e:	bd10      	pop	{r4, pc}

20029530 <mbedtls_pk_info_from_type>:
20029530:	2801      	cmp	r0, #1
20029532:	4802      	ldr	r0, [pc, #8]	@ (2002953c <mbedtls_pk_info_from_type+0xc>)
20029534:	bf18      	it	ne
20029536:	2000      	movne	r0, #0
20029538:	4770      	bx	lr
2002953a:	bf00      	nop
2002953c:	2002c43c 	.word	0x2002c43c

20029540 <mbedtls_pk_setup>:
20029540:	b570      	push	{r4, r5, r6, lr}
20029542:	460e      	mov	r6, r1
20029544:	4605      	mov	r5, r0
20029546:	b148      	cbz	r0, 2002955c <mbedtls_pk_setup+0x1c>
20029548:	b141      	cbz	r1, 2002955c <mbedtls_pk_setup+0x1c>
2002954a:	6804      	ldr	r4, [r0, #0]
2002954c:	b934      	cbnz	r4, 2002955c <mbedtls_pk_setup+0x1c>
2002954e:	6a4b      	ldr	r3, [r1, #36]	@ 0x24
20029550:	4798      	blx	r3
20029552:	6068      	str	r0, [r5, #4]
20029554:	b120      	cbz	r0, 20029560 <mbedtls_pk_setup+0x20>
20029556:	4620      	mov	r0, r4
20029558:	602e      	str	r6, [r5, #0]
2002955a:	bd70      	pop	{r4, r5, r6, pc}
2002955c:	4801      	ldr	r0, [pc, #4]	@ (20029564 <mbedtls_pk_setup+0x24>)
2002955e:	e7fc      	b.n	2002955a <mbedtls_pk_setup+0x1a>
20029560:	4801      	ldr	r0, [pc, #4]	@ (20029568 <mbedtls_pk_setup+0x28>)
20029562:	e7fa      	b.n	2002955a <mbedtls_pk_setup+0x1a>
20029564:	ffffc180 	.word	0xffffc180
20029568:	ffffc080 	.word	0xffffc080

2002956c <mbedtls_pk_verify>:
2002956c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20029570:	460d      	mov	r5, r1
20029572:	e9dd 8908 	ldrd	r8, r9, [sp, #32]
20029576:	4616      	mov	r6, r2
20029578:	4604      	mov	r4, r0
2002957a:	b910      	cbnz	r0, 20029582 <mbedtls_pk_verify+0x16>
2002957c:	480e      	ldr	r0, [pc, #56]	@ (200295b8 <mbedtls_pk_verify+0x4c>)
2002957e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20029582:	6802      	ldr	r2, [r0, #0]
20029584:	2a00      	cmp	r2, #0
20029586:	d0f9      	beq.n	2002957c <mbedtls_pk_verify+0x10>
20029588:	b93b      	cbnz	r3, 2002959a <mbedtls_pk_verify+0x2e>
2002958a:	4608      	mov	r0, r1
2002958c:	f7fc fd40 	bl	20026010 <mbedtls_md_info_from_type>
20029590:	2800      	cmp	r0, #0
20029592:	d0f3      	beq.n	2002957c <mbedtls_pk_verify+0x10>
20029594:	f7fc fd48 	bl	20026028 <mbedtls_md_get_size>
20029598:	4603      	mov	r3, r0
2002959a:	6822      	ldr	r2, [r4, #0]
2002959c:	6917      	ldr	r7, [r2, #16]
2002959e:	b147      	cbz	r7, 200295b2 <mbedtls_pk_verify+0x46>
200295a0:	e9cd 8908 	strd	r8, r9, [sp, #32]
200295a4:	4632      	mov	r2, r6
200295a6:	4629      	mov	r1, r5
200295a8:	46bc      	mov	ip, r7
200295aa:	6860      	ldr	r0, [r4, #4]
200295ac:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200295b0:	4760      	bx	ip
200295b2:	4802      	ldr	r0, [pc, #8]	@ (200295bc <mbedtls_pk_verify+0x50>)
200295b4:	e7e3      	b.n	2002957e <mbedtls_pk_verify+0x12>
200295b6:	bf00      	nop
200295b8:	ffffc180 	.word	0xffffc180
200295bc:	ffffc100 	.word	0xffffc100

200295c0 <pk_get_pk_alg>:
200295c0:	b530      	push	{r4, r5, lr}
200295c2:	4615      	mov	r5, r2
200295c4:	2200      	movs	r2, #0
200295c6:	b085      	sub	sp, #20
200295c8:	e9c3 2200 	strd	r2, r2, [r3]
200295cc:	609a      	str	r2, [r3, #8]
200295ce:	aa01      	add	r2, sp, #4
200295d0:	461c      	mov	r4, r3
200295d2:	f7fe fa98 	bl	20027b06 <mbedtls_asn1_get_alg>
200295d6:	b118      	cbz	r0, 200295e0 <pk_get_pk_alg+0x20>
200295d8:	f5a0 506a 	sub.w	r0, r0, #14976	@ 0x3a80
200295dc:	b005      	add	sp, #20
200295de:	bd30      	pop	{r4, r5, pc}
200295e0:	4629      	mov	r1, r5
200295e2:	a801      	add	r0, sp, #4
200295e4:	f7ff ff46 	bl	20029474 <mbedtls_oid_get_pk_alg>
200295e8:	b960      	cbnz	r0, 20029604 <pk_get_pk_alg+0x44>
200295ea:	782b      	ldrb	r3, [r5, #0]
200295ec:	2b01      	cmp	r3, #1
200295ee:	d1f5      	bne.n	200295dc <pk_get_pk_alg+0x1c>
200295f0:	6823      	ldr	r3, [r4, #0]
200295f2:	2b05      	cmp	r3, #5
200295f4:	d000      	beq.n	200295f8 <pk_get_pk_alg+0x38>
200295f6:	b93b      	cbnz	r3, 20029608 <pk_get_pk_alg+0x48>
200295f8:	6862      	ldr	r2, [r4, #4]
200295fa:	4b04      	ldr	r3, [pc, #16]	@ (2002960c <pk_get_pk_alg+0x4c>)
200295fc:	2a00      	cmp	r2, #0
200295fe:	bf18      	it	ne
20029600:	4618      	movne	r0, r3
20029602:	e7eb      	b.n	200295dc <pk_get_pk_alg+0x1c>
20029604:	4802      	ldr	r0, [pc, #8]	@ (20029610 <pk_get_pk_alg+0x50>)
20029606:	e7e9      	b.n	200295dc <pk_get_pk_alg+0x1c>
20029608:	4800      	ldr	r0, [pc, #0]	@ (2002960c <pk_get_pk_alg+0x4c>)
2002960a:	e7e7      	b.n	200295dc <pk_get_pk_alg+0x1c>
2002960c:	ffffc580 	.word	0xffffc580
20029610:	ffffc380 	.word	0xffffc380

20029614 <mbedtls_pk_parse_subpubkey>:
20029614:	2300      	movs	r3, #0
20029616:	e92d 45f0 	stmdb	sp!, {r4, r5, r6, r7, r8, sl, lr}
2002961a:	b087      	sub	sp, #28
2002961c:	4690      	mov	r8, r2
2002961e:	f88d 3003 	strb.w	r3, [sp, #3]
20029622:	aa01      	add	r2, sp, #4
20029624:	2330      	movs	r3, #48	@ 0x30
20029626:	4606      	mov	r6, r0
20029628:	f7fe fa32 	bl	20027a90 <mbedtls_asn1_get_tag>
2002962c:	b128      	cbz	r0, 2002963a <mbedtls_pk_parse_subpubkey+0x26>
2002962e:	f5a0 5474 	sub.w	r4, r0, #15616	@ 0x3d00
20029632:	4620      	mov	r0, r4
20029634:	b007      	add	sp, #28
20029636:	e8bd 85f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, sl, pc}
2002963a:	9b01      	ldr	r3, [sp, #4]
2002963c:	6837      	ldr	r7, [r6, #0]
2002963e:	4630      	mov	r0, r6
20029640:	441f      	add	r7, r3
20029642:	4639      	mov	r1, r7
20029644:	ab03      	add	r3, sp, #12
20029646:	f10d 0203 	add.w	r2, sp, #3
2002964a:	f7ff ffb9 	bl	200295c0 <pk_get_pk_alg>
2002964e:	4604      	mov	r4, r0
20029650:	2800      	cmp	r0, #0
20029652:	d1ee      	bne.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
20029654:	4639      	mov	r1, r7
20029656:	4630      	mov	r0, r6
20029658:	aa01      	add	r2, sp, #4
2002965a:	f7fe fa40 	bl	20027ade <mbedtls_asn1_get_bitstring_null>
2002965e:	b110      	cbz	r0, 20029666 <mbedtls_pk_parse_subpubkey+0x52>
20029660:	f5a0 546c 	sub.w	r4, r0, #15104	@ 0x3b00
20029664:	e7e5      	b.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
20029666:	6833      	ldr	r3, [r6, #0]
20029668:	9a01      	ldr	r2, [sp, #4]
2002966a:	4413      	add	r3, r2
2002966c:	429f      	cmp	r7, r3
2002966e:	d14b      	bne.n	20029708 <mbedtls_pk_parse_subpubkey+0xf4>
20029670:	f89d 0003 	ldrb.w	r0, [sp, #3]
20029674:	f7ff ff5c 	bl	20029530 <mbedtls_pk_info_from_type>
20029678:	4601      	mov	r1, r0
2002967a:	2800      	cmp	r0, #0
2002967c:	d046      	beq.n	2002970c <mbedtls_pk_parse_subpubkey+0xf8>
2002967e:	4640      	mov	r0, r8
20029680:	f7ff ff5e 	bl	20029540 <mbedtls_pk_setup>
20029684:	4604      	mov	r4, r0
20029686:	2800      	cmp	r0, #0
20029688:	d1d3      	bne.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
2002968a:	f89d 3003 	ldrb.w	r3, [sp, #3]
2002968e:	2b01      	cmp	r3, #1
20029690:	d138      	bne.n	20029704 <mbedtls_pk_parse_subpubkey+0xf0>
20029692:	2330      	movs	r3, #48	@ 0x30
20029694:	4639      	mov	r1, r7
20029696:	4630      	mov	r0, r6
20029698:	aa02      	add	r2, sp, #8
2002969a:	f8d8 5004 	ldr.w	r5, [r8, #4]
2002969e:	f7fe f9f7 	bl	20027a90 <mbedtls_asn1_get_tag>
200296a2:	b138      	cbz	r0, 200296b4 <mbedtls_pk_parse_subpubkey+0xa0>
200296a4:	f5a0 556c 	sub.w	r5, r0, #15104	@ 0x3b00
200296a8:	bb3d      	cbnz	r5, 200296fa <mbedtls_pk_parse_subpubkey+0xe6>
200296aa:	6833      	ldr	r3, [r6, #0]
200296ac:	42bb      	cmp	r3, r7
200296ae:	d0c0      	beq.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
200296b0:	4d17      	ldr	r5, [pc, #92]	@ (20029710 <mbedtls_pk_parse_subpubkey+0xfc>)
200296b2:	e022      	b.n	200296fa <mbedtls_pk_parse_subpubkey+0xe6>
200296b4:	6833      	ldr	r3, [r6, #0]
200296b6:	9a02      	ldr	r2, [sp, #8]
200296b8:	4413      	add	r3, r2
200296ba:	429f      	cmp	r7, r3
200296bc:	d1f8      	bne.n	200296b0 <mbedtls_pk_parse_subpubkey+0x9c>
200296be:	f105 0a08 	add.w	sl, r5, #8
200296c2:	4652      	mov	r2, sl
200296c4:	4639      	mov	r1, r7
200296c6:	4630      	mov	r0, r6
200296c8:	f7fe f9f6 	bl	20027ab8 <mbedtls_asn1_get_mpi>
200296cc:	2800      	cmp	r0, #0
200296ce:	d1e9      	bne.n	200296a4 <mbedtls_pk_parse_subpubkey+0x90>
200296d0:	4639      	mov	r1, r7
200296d2:	4630      	mov	r0, r6
200296d4:	f105 0214 	add.w	r2, r5, #20
200296d8:	f7fe f9ee 	bl	20027ab8 <mbedtls_asn1_get_mpi>
200296dc:	2800      	cmp	r0, #0
200296de:	d1e1      	bne.n	200296a4 <mbedtls_pk_parse_subpubkey+0x90>
200296e0:	6833      	ldr	r3, [r6, #0]
200296e2:	429f      	cmp	r7, r3
200296e4:	d1e4      	bne.n	200296b0 <mbedtls_pk_parse_subpubkey+0x9c>
200296e6:	4628      	mov	r0, r5
200296e8:	f000 f8c2 	bl	20029870 <mbedtls_rsa_check_pubkey>
200296ec:	b920      	cbnz	r0, 200296f8 <mbedtls_pk_parse_subpubkey+0xe4>
200296ee:	4650      	mov	r0, sl
200296f0:	f7fe fcbe 	bl	20028070 <mbedtls_mpi_size>
200296f4:	6068      	str	r0, [r5, #4]
200296f6:	e7d8      	b.n	200296aa <mbedtls_pk_parse_subpubkey+0x96>
200296f8:	4d06      	ldr	r5, [pc, #24]	@ (20029714 <mbedtls_pk_parse_subpubkey+0x100>)
200296fa:	4640      	mov	r0, r8
200296fc:	f7ff ff07 	bl	2002950e <mbedtls_pk_free>
20029700:	462c      	mov	r4, r5
20029702:	e796      	b.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
20029704:	4d04      	ldr	r5, [pc, #16]	@ (20029718 <mbedtls_pk_parse_subpubkey+0x104>)
20029706:	e7f8      	b.n	200296fa <mbedtls_pk_parse_subpubkey+0xe6>
20029708:	4c01      	ldr	r4, [pc, #4]	@ (20029710 <mbedtls_pk_parse_subpubkey+0xfc>)
2002970a:	e792      	b.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
2002970c:	4c02      	ldr	r4, [pc, #8]	@ (20029718 <mbedtls_pk_parse_subpubkey+0x104>)
2002970e:	e790      	b.n	20029632 <mbedtls_pk_parse_subpubkey+0x1e>
20029710:	ffffc49a 	.word	0xffffc49a
20029714:	ffffc500 	.word	0xffffc500
20029718:	ffffc380 	.word	0xffffc380

2002971c <mbedtls_pk_parse_public_key>:
2002971c:	4613      	mov	r3, r2
2002971e:	b507      	push	{r0, r1, r2, lr}
20029720:	4602      	mov	r2, r0
20029722:	9101      	str	r1, [sp, #4]
20029724:	a801      	add	r0, sp, #4
20029726:	4419      	add	r1, r3
20029728:	f7ff ff74 	bl	20029614 <mbedtls_pk_parse_subpubkey>
2002972c:	b003      	add	sp, #12
2002972e:	f85d fb04 	ldr.w	pc, [sp], #4

20029732 <rsa_can_do>:
20029732:	2801      	cmp	r0, #1
20029734:	d002      	beq.n	2002973c <rsa_can_do+0xa>
20029736:	1f83      	subs	r3, r0, #6
20029738:	4258      	negs	r0, r3
2002973a:	4158      	adcs	r0, r3
2002973c:	4770      	bx	lr

2002973e <rsa_get_bitlen>:
2002973e:	6840      	ldr	r0, [r0, #4]
20029740:	00c0      	lsls	r0, r0, #3
20029742:	4770      	bx	lr

20029744 <rsa_debug>:
20029744:	2301      	movs	r3, #1
20029746:	4a06      	ldr	r2, [pc, #24]	@ (20029760 <rsa_debug+0x1c>)
20029748:	700b      	strb	r3, [r1, #0]
2002974a:	730b      	strb	r3, [r1, #12]
2002974c:	4b05      	ldr	r3, [pc, #20]	@ (20029764 <rsa_debug+0x20>)
2002974e:	604a      	str	r2, [r1, #4]
20029750:	f100 0208 	add.w	r2, r0, #8
20029754:	3014      	adds	r0, #20
20029756:	608a      	str	r2, [r1, #8]
20029758:	610b      	str	r3, [r1, #16]
2002975a:	6148      	str	r0, [r1, #20]
2002975c:	4770      	bx	lr
2002975e:	bf00      	nop
20029760:	2002b218 	.word	0x2002b218
20029764:	2002b21e 	.word	0x2002b21e

20029768 <rsa_free_wrap>:
20029768:	b510      	push	{r4, lr}
2002976a:	4604      	mov	r4, r0
2002976c:	f000 fe7c 	bl	2002a468 <mbedtls_rsa_free>
20029770:	4620      	mov	r0, r4
20029772:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20029776:	f001 b88b 	b.w	2002a890 <free>

2002977a <rsa_alloc_wrap>:
2002977a:	b510      	push	{r4, lr}
2002977c:	21ac      	movs	r1, #172	@ 0xac
2002977e:	2001      	movs	r0, #1
20029780:	f001 f86a 	bl	2002a858 <calloc>
20029784:	4604      	mov	r4, r0
20029786:	b118      	cbz	r0, 20029790 <rsa_alloc_wrap+0x16>
20029788:	2200      	movs	r2, #0
2002978a:	4611      	mov	r1, r2
2002978c:	f000 f862 	bl	20029854 <mbedtls_rsa_init>
20029790:	4620      	mov	r0, r4
20029792:	bd10      	pop	{r4, pc}

20029794 <rsa_check_pair_wrap>:
20029794:	f000 b99c 	b.w	20029ad0 <mbedtls_rsa_check_pub_priv>

20029798 <rsa_encrypt_wrap>:
20029798:	b4f0      	push	{r4, r5, r6, r7}
2002979a:	9f04      	ldr	r7, [sp, #16]
2002979c:	6846      	ldr	r6, [r0, #4]
2002979e:	460d      	mov	r5, r1
200297a0:	603e      	str	r6, [r7, #0]
200297a2:	9f05      	ldr	r7, [sp, #20]
200297a4:	4614      	mov	r4, r2
200297a6:	e9dd 1206 	ldrd	r1, r2, [sp, #24]
200297aa:	42be      	cmp	r6, r7
200297ac:	d806      	bhi.n	200297bc <rsa_encrypt_wrap+0x24>
200297ae:	e9cd 5305 	strd	r5, r3, [sp, #20]
200297b2:	9404      	str	r4, [sp, #16]
200297b4:	2300      	movs	r3, #0
200297b6:	bcf0      	pop	{r4, r5, r6, r7}
200297b8:	f000 bbe2 	b.w	20029f80 <mbedtls_rsa_pkcs1_encrypt>
200297bc:	4801      	ldr	r0, [pc, #4]	@ (200297c4 <rsa_encrypt_wrap+0x2c>)
200297be:	bcf0      	pop	{r4, r5, r6, r7}
200297c0:	4770      	bx	lr
200297c2:	bf00      	nop
200297c4:	ffffbc00 	.word	0xffffbc00

200297c8 <rsa_decrypt_wrap>:
200297c8:	b4f0      	push	{r4, r5, r6, r7}
200297ca:	4616      	mov	r6, r2
200297cc:	6847      	ldr	r7, [r0, #4]
200297ce:	460c      	mov	r4, r1
200297d0:	e9dd 5105 	ldrd	r5, r1, [sp, #20]
200297d4:	42b7      	cmp	r7, r6
200297d6:	9a07      	ldr	r2, [sp, #28]
200297d8:	d106      	bne.n	200297e8 <rsa_decrypt_wrap+0x20>
200297da:	e9cd 3506 	strd	r3, r5, [sp, #24]
200297de:	9405      	str	r4, [sp, #20]
200297e0:	2301      	movs	r3, #1
200297e2:	bcf0      	pop	{r4, r5, r6, r7}
200297e4:	f000 bc6e 	b.w	2002a0c4 <mbedtls_rsa_pkcs1_decrypt>
200297e8:	4801      	ldr	r0, [pc, #4]	@ (200297f0 <rsa_decrypt_wrap+0x28>)
200297ea:	bcf0      	pop	{r4, r5, r6, r7}
200297ec:	4770      	bx	lr
200297ee:	bf00      	nop
200297f0:	ffffbf80 	.word	0xffffbf80

200297f4 <rsa_sign_wrap>:
200297f4:	b4f0      	push	{r4, r5, r6, r7}
200297f6:	460c      	mov	r4, r1
200297f8:	4615      	mov	r5, r2
200297fa:	e9dd 1206 	ldrd	r1, r2, [sp, #24]
200297fe:	6847      	ldr	r7, [r0, #4]
20029800:	9e05      	ldr	r6, [sp, #20]
20029802:	6037      	str	r7, [r6, #0]
20029804:	9e04      	ldr	r6, [sp, #16]
20029806:	e9cd 4304 	strd	r4, r3, [sp, #16]
2002980a:	e9cd 5606 	strd	r5, r6, [sp, #24]
2002980e:	bcf0      	pop	{r4, r5, r6, r7}
20029810:	2301      	movs	r3, #1
20029812:	f000 bd31 	b.w	2002a278 <mbedtls_rsa_pkcs1_sign>
	...

20029818 <rsa_verify_wrap>:
20029818:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
2002981a:	9d09      	ldr	r5, [sp, #36]	@ 0x24
2002981c:	6846      	ldr	r6, [r0, #4]
2002981e:	4604      	mov	r4, r0
20029820:	42ae      	cmp	r6, r5
20029822:	d811      	bhi.n	20029848 <rsa_verify_wrap+0x30>
20029824:	e9cd 1300 	strd	r1, r3, [sp]
20029828:	2300      	movs	r3, #0
2002982a:	9e08      	ldr	r6, [sp, #32]
2002982c:	4619      	mov	r1, r3
2002982e:	e9cd 2602 	strd	r2, r6, [sp, #8]
20029832:	461a      	mov	r2, r3
20029834:	f000 fe08 	bl	2002a448 <mbedtls_rsa_pkcs1_verify>
20029838:	b920      	cbnz	r0, 20029844 <rsa_verify_wrap+0x2c>
2002983a:	6862      	ldr	r2, [r4, #4]
2002983c:	4b03      	ldr	r3, [pc, #12]	@ (2002984c <rsa_verify_wrap+0x34>)
2002983e:	42aa      	cmp	r2, r5
20029840:	bf38      	it	cc
20029842:	4618      	movcc	r0, r3
20029844:	b004      	add	sp, #16
20029846:	bd70      	pop	{r4, r5, r6, pc}
20029848:	4801      	ldr	r0, [pc, #4]	@ (20029850 <rsa_verify_wrap+0x38>)
2002984a:	e7fb      	b.n	20029844 <rsa_verify_wrap+0x2c>
2002984c:	ffffc700 	.word	0xffffc700
20029850:	ffffbc80 	.word	0xffffbc80

20029854 <mbedtls_rsa_init>:
20029854:	b570      	push	{r4, r5, r6, lr}
20029856:	4604      	mov	r4, r0
20029858:	460e      	mov	r6, r1
2002985a:	4615      	mov	r5, r2
2002985c:	2100      	movs	r1, #0
2002985e:	22ac      	movs	r2, #172	@ 0xac
20029860:	f001 f8dc 	bl	2002aa1c <memset>
20029864:	e9c4 6529 	strd	r6, r5, [r4, #164]	@ 0xa4
20029868:	bd70      	pop	{r4, r5, r6, pc}

2002986a <mbedtls_rsa_set_padding>:
2002986a:	e9c0 1229 	strd	r1, r2, [r0, #164]	@ 0xa4
2002986e:	4770      	bx	lr

20029870 <mbedtls_rsa_check_pubkey>:
20029870:	b538      	push	{r3, r4, r5, lr}
20029872:	6902      	ldr	r2, [r0, #16]
20029874:	4604      	mov	r4, r0
20029876:	b10a      	cbz	r2, 2002987c <mbedtls_rsa_check_pubkey+0xc>
20029878:	69c3      	ldr	r3, [r0, #28]
2002987a:	b90b      	cbnz	r3, 20029880 <mbedtls_rsa_check_pubkey+0x10>
2002987c:	4811      	ldr	r0, [pc, #68]	@ (200298c4 <mbedtls_rsa_check_pubkey+0x54>)
2002987e:	bd38      	pop	{r3, r4, r5, pc}
20029880:	6812      	ldr	r2, [r2, #0]
20029882:	07d2      	lsls	r2, r2, #31
20029884:	d5fa      	bpl.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
20029886:	681b      	ldr	r3, [r3, #0]
20029888:	07db      	lsls	r3, r3, #31
2002988a:	d5f7      	bpl.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
2002988c:	f100 0508 	add.w	r5, r0, #8
20029890:	4628      	mov	r0, r5
20029892:	f7fe fbd0 	bl	20028036 <mbedtls_mpi_bitlen>
20029896:	287f      	cmp	r0, #127	@ 0x7f
20029898:	d9f0      	bls.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
2002989a:	4628      	mov	r0, r5
2002989c:	f7fe fbcb 	bl	20028036 <mbedtls_mpi_bitlen>
200298a0:	f5b0 5f00 	cmp.w	r0, #8192	@ 0x2000
200298a4:	d8ea      	bhi.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
200298a6:	3414      	adds	r4, #20
200298a8:	4620      	mov	r0, r4
200298aa:	f7fe fbc4 	bl	20028036 <mbedtls_mpi_bitlen>
200298ae:	2801      	cmp	r0, #1
200298b0:	d9e4      	bls.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
200298b2:	4629      	mov	r1, r5
200298b4:	4620      	mov	r0, r4
200298b6:	f7fe fd71 	bl	2002839c <mbedtls_mpi_cmp_mpi>
200298ba:	2800      	cmp	r0, #0
200298bc:	dade      	bge.n	2002987c <mbedtls_rsa_check_pubkey+0xc>
200298be:	2000      	movs	r0, #0
200298c0:	e7dd      	b.n	2002987e <mbedtls_rsa_check_pubkey+0xe>
200298c2:	bf00      	nop
200298c4:	ffffbe00 	.word	0xffffbe00

200298c8 <mbedtls_rsa_check_privkey>:
200298c8:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200298cc:	b0a9      	sub	sp, #164	@ 0xa4
200298ce:	4605      	mov	r5, r0
200298d0:	f7ff ffce 	bl	20029870 <mbedtls_rsa_check_pubkey>
200298d4:	b120      	cbz	r0, 200298e0 <mbedtls_rsa_check_privkey+0x18>
200298d6:	4c7d      	ldr	r4, [pc, #500]	@ (20029acc <mbedtls_rsa_check_privkey+0x204>)
200298d8:	4620      	mov	r0, r4
200298da:	b029      	add	sp, #164	@ 0xa4
200298dc:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200298e0:	6b6b      	ldr	r3, [r5, #52]	@ 0x34
200298e2:	2b00      	cmp	r3, #0
200298e4:	d0f7      	beq.n	200298d6 <mbedtls_rsa_check_privkey+0xe>
200298e6:	6c2b      	ldr	r3, [r5, #64]	@ 0x40
200298e8:	2b00      	cmp	r3, #0
200298ea:	d0f4      	beq.n	200298d6 <mbedtls_rsa_check_privkey+0xe>
200298ec:	6aab      	ldr	r3, [r5, #40]	@ 0x28
200298ee:	2b00      	cmp	r3, #0
200298f0:	d0f1      	beq.n	200298d6 <mbedtls_rsa_check_privkey+0xe>
200298f2:	a801      	add	r0, sp, #4
200298f4:	f7fe fafa 	bl	20027eec <mbedtls_mpi_init>
200298f8:	a804      	add	r0, sp, #16
200298fa:	f7fe faf7 	bl	20027eec <mbedtls_mpi_init>
200298fe:	a807      	add	r0, sp, #28
20029900:	f7fe faf4 	bl	20027eec <mbedtls_mpi_init>
20029904:	a80a      	add	r0, sp, #40	@ 0x28
20029906:	f7fe faf1 	bl	20027eec <mbedtls_mpi_init>
2002990a:	a80d      	add	r0, sp, #52	@ 0x34
2002990c:	f7fe faee 	bl	20027eec <mbedtls_mpi_init>
20029910:	a810      	add	r0, sp, #64	@ 0x40
20029912:	f7fe faeb 	bl	20027eec <mbedtls_mpi_init>
20029916:	a813      	add	r0, sp, #76	@ 0x4c
20029918:	f7fe fae8 	bl	20027eec <mbedtls_mpi_init>
2002991c:	a816      	add	r0, sp, #88	@ 0x58
2002991e:	f7fe fae5 	bl	20027eec <mbedtls_mpi_init>
20029922:	a819      	add	r0, sp, #100	@ 0x64
20029924:	f7fe fae2 	bl	20027eec <mbedtls_mpi_init>
20029928:	a81c      	add	r0, sp, #112	@ 0x70
2002992a:	f7fe fadf 	bl	20027eec <mbedtls_mpi_init>
2002992e:	a81f      	add	r0, sp, #124	@ 0x7c
20029930:	f7fe fadc 	bl	20027eec <mbedtls_mpi_init>
20029934:	a822      	add	r0, sp, #136	@ 0x88
20029936:	f7fe fad9 	bl	20027eec <mbedtls_mpi_init>
2002993a:	f105 072c 	add.w	r7, r5, #44	@ 0x2c
2002993e:	a825      	add	r0, sp, #148	@ 0x94
20029940:	f105 0638 	add.w	r6, r5, #56	@ 0x38
20029944:	f7fe fad2 	bl	20027eec <mbedtls_mpi_init>
20029948:	4632      	mov	r2, r6
2002994a:	4639      	mov	r1, r7
2002994c:	a801      	add	r0, sp, #4
2002994e:	f7fe fe75 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029952:	4604      	mov	r4, r0
20029954:	2800      	cmp	r0, #0
20029956:	d15e      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029958:	f105 0820 	add.w	r8, r5, #32
2002995c:	f105 0914 	add.w	r9, r5, #20
20029960:	464a      	mov	r2, r9
20029962:	4641      	mov	r1, r8
20029964:	a804      	add	r0, sp, #16
20029966:	f7fe fe69 	bl	2002863c <mbedtls_mpi_mul_mpi>
2002996a:	4604      	mov	r4, r0
2002996c:	2800      	cmp	r0, #0
2002996e:	d152      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029970:	2201      	movs	r2, #1
20029972:	4639      	mov	r1, r7
20029974:	a807      	add	r0, sp, #28
20029976:	f7fe fe4b 	bl	20028610 <mbedtls_mpi_sub_int>
2002997a:	4604      	mov	r4, r0
2002997c:	2800      	cmp	r0, #0
2002997e:	d14a      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029980:	2201      	movs	r2, #1
20029982:	4631      	mov	r1, r6
20029984:	a80a      	add	r0, sp, #40	@ 0x28
20029986:	f7fe fe43 	bl	20028610 <mbedtls_mpi_sub_int>
2002998a:	4604      	mov	r4, r0
2002998c:	2800      	cmp	r0, #0
2002998e:	d142      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029990:	aa0a      	add	r2, sp, #40	@ 0x28
20029992:	a907      	add	r1, sp, #28
20029994:	a80d      	add	r0, sp, #52	@ 0x34
20029996:	f7fe fe51 	bl	2002863c <mbedtls_mpi_mul_mpi>
2002999a:	4604      	mov	r4, r0
2002999c:	2800      	cmp	r0, #0
2002999e:	d13a      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299a0:	4649      	mov	r1, r9
200299a2:	aa0d      	add	r2, sp, #52	@ 0x34
200299a4:	a813      	add	r0, sp, #76	@ 0x4c
200299a6:	f7ff fb04 	bl	20028fb2 <mbedtls_mpi_gcd>
200299aa:	4604      	mov	r4, r0
200299ac:	2800      	cmp	r0, #0
200299ae:	d132      	bne.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299b0:	aa0a      	add	r2, sp, #40	@ 0x28
200299b2:	a907      	add	r1, sp, #28
200299b4:	a816      	add	r0, sp, #88	@ 0x58
200299b6:	f7ff fafc 	bl	20028fb2 <mbedtls_mpi_gcd>
200299ba:	4604      	mov	r4, r0
200299bc:	bb58      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299be:	ab16      	add	r3, sp, #88	@ 0x58
200299c0:	aa0d      	add	r2, sp, #52	@ 0x34
200299c2:	a91c      	add	r1, sp, #112	@ 0x70
200299c4:	a819      	add	r0, sp, #100	@ 0x64
200299c6:	f7fe feaa 	bl	2002871e <mbedtls_mpi_div_mpi>
200299ca:	4604      	mov	r4, r0
200299cc:	bb18      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299ce:	aa19      	add	r2, sp, #100	@ 0x64
200299d0:	a904      	add	r1, sp, #16
200299d2:	a810      	add	r0, sp, #64	@ 0x40
200299d4:	f7ff f8a7 	bl	20028b26 <mbedtls_mpi_mod_mpi>
200299d8:	4604      	mov	r4, r0
200299da:	b9e0      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299dc:	4641      	mov	r1, r8
200299de:	aa07      	add	r2, sp, #28
200299e0:	a81f      	add	r0, sp, #124	@ 0x7c
200299e2:	f7ff f8a0 	bl	20028b26 <mbedtls_mpi_mod_mpi>
200299e6:	4604      	mov	r4, r0
200299e8:	b9a8      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299ea:	4641      	mov	r1, r8
200299ec:	aa0a      	add	r2, sp, #40	@ 0x28
200299ee:	a822      	add	r0, sp, #136	@ 0x88
200299f0:	f7ff f899 	bl	20028b26 <mbedtls_mpi_mod_mpi>
200299f4:	4604      	mov	r4, r0
200299f6:	b970      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
200299f8:	463a      	mov	r2, r7
200299fa:	4631      	mov	r1, r6
200299fc:	a825      	add	r0, sp, #148	@ 0x94
200299fe:	f7ff fb73 	bl	200290e8 <mbedtls_mpi_inv_mod>
20029a02:	4604      	mov	r4, r0
20029a04:	b938      	cbnz	r0, 20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029a06:	f105 0108 	add.w	r1, r5, #8
20029a0a:	a801      	add	r0, sp, #4
20029a0c:	f7fe fcc6 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029a10:	2800      	cmp	r0, #0
20029a12:	d031      	beq.n	20029a78 <mbedtls_rsa_check_privkey+0x1b0>
20029a14:	4c2d      	ldr	r4, [pc, #180]	@ (20029acc <mbedtls_rsa_check_privkey+0x204>)
20029a16:	a801      	add	r0, sp, #4
20029a18:	f7fe fa6f 	bl	20027efa <mbedtls_mpi_free>
20029a1c:	a804      	add	r0, sp, #16
20029a1e:	f7fe fa6c 	bl	20027efa <mbedtls_mpi_free>
20029a22:	a807      	add	r0, sp, #28
20029a24:	f7fe fa69 	bl	20027efa <mbedtls_mpi_free>
20029a28:	a80a      	add	r0, sp, #40	@ 0x28
20029a2a:	f7fe fa66 	bl	20027efa <mbedtls_mpi_free>
20029a2e:	a80d      	add	r0, sp, #52	@ 0x34
20029a30:	f7fe fa63 	bl	20027efa <mbedtls_mpi_free>
20029a34:	a810      	add	r0, sp, #64	@ 0x40
20029a36:	f7fe fa60 	bl	20027efa <mbedtls_mpi_free>
20029a3a:	a813      	add	r0, sp, #76	@ 0x4c
20029a3c:	f7fe fa5d 	bl	20027efa <mbedtls_mpi_free>
20029a40:	a816      	add	r0, sp, #88	@ 0x58
20029a42:	f7fe fa5a 	bl	20027efa <mbedtls_mpi_free>
20029a46:	a819      	add	r0, sp, #100	@ 0x64
20029a48:	f7fe fa57 	bl	20027efa <mbedtls_mpi_free>
20029a4c:	a81c      	add	r0, sp, #112	@ 0x70
20029a4e:	f7fe fa54 	bl	20027efa <mbedtls_mpi_free>
20029a52:	a81f      	add	r0, sp, #124	@ 0x7c
20029a54:	f7fe fa51 	bl	20027efa <mbedtls_mpi_free>
20029a58:	a822      	add	r0, sp, #136	@ 0x88
20029a5a:	f7fe fa4e 	bl	20027efa <mbedtls_mpi_free>
20029a5e:	a825      	add	r0, sp, #148	@ 0x94
20029a60:	f7fe fa4b 	bl	20027efa <mbedtls_mpi_free>
20029a64:	f514 4f84 	cmn.w	r4, #16896	@ 0x4200
20029a68:	f43f af35 	beq.w	200298d6 <mbedtls_rsa_check_privkey+0xe>
20029a6c:	2c00      	cmp	r4, #0
20029a6e:	f43f af33 	beq.w	200298d8 <mbedtls_rsa_check_privkey+0x10>
20029a72:	f5a4 4484 	sub.w	r4, r4, #16896	@ 0x4200
20029a76:	e72f      	b.n	200298d8 <mbedtls_rsa_check_privkey+0x10>
20029a78:	f105 0144 	add.w	r1, r5, #68	@ 0x44
20029a7c:	a81f      	add	r0, sp, #124	@ 0x7c
20029a7e:	f7fe fc8d 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029a82:	2800      	cmp	r0, #0
20029a84:	d1c6      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029a86:	f105 0150 	add.w	r1, r5, #80	@ 0x50
20029a8a:	a822      	add	r0, sp, #136	@ 0x88
20029a8c:	f7fe fc86 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029a90:	2800      	cmp	r0, #0
20029a92:	d1bf      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029a94:	f105 015c 	add.w	r1, r5, #92	@ 0x5c
20029a98:	a825      	add	r0, sp, #148	@ 0x94
20029a9a:	f7fe fc7f 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029a9e:	2800      	cmp	r0, #0
20029aa0:	d1b8      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029aa2:	2100      	movs	r1, #0
20029aa4:	a81c      	add	r0, sp, #112	@ 0x70
20029aa6:	f7fe fcba 	bl	2002841e <mbedtls_mpi_cmp_int>
20029aaa:	2800      	cmp	r0, #0
20029aac:	d1b2      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029aae:	2101      	movs	r1, #1
20029ab0:	a810      	add	r0, sp, #64	@ 0x40
20029ab2:	f7fe fcb4 	bl	2002841e <mbedtls_mpi_cmp_int>
20029ab6:	2800      	cmp	r0, #0
20029ab8:	d1ac      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029aba:	2101      	movs	r1, #1
20029abc:	a813      	add	r0, sp, #76	@ 0x4c
20029abe:	f7fe fcae 	bl	2002841e <mbedtls_mpi_cmp_int>
20029ac2:	4604      	mov	r4, r0
20029ac4:	2800      	cmp	r0, #0
20029ac6:	d1a5      	bne.n	20029a14 <mbedtls_rsa_check_privkey+0x14c>
20029ac8:	e7a5      	b.n	20029a16 <mbedtls_rsa_check_privkey+0x14e>
20029aca:	bf00      	nop
20029acc:	ffffbe00 	.word	0xffffbe00

20029ad0 <mbedtls_rsa_check_pub_priv>:
20029ad0:	b538      	push	{r3, r4, r5, lr}
20029ad2:	4605      	mov	r5, r0
20029ad4:	460c      	mov	r4, r1
20029ad6:	f7ff fecb 	bl	20029870 <mbedtls_rsa_check_pubkey>
20029ada:	b918      	cbnz	r0, 20029ae4 <mbedtls_rsa_check_pub_priv+0x14>
20029adc:	4620      	mov	r0, r4
20029ade:	f7ff fef3 	bl	200298c8 <mbedtls_rsa_check_privkey>
20029ae2:	b108      	cbz	r0, 20029ae8 <mbedtls_rsa_check_pub_priv+0x18>
20029ae4:	4809      	ldr	r0, [pc, #36]	@ (20029b0c <mbedtls_rsa_check_pub_priv+0x3c>)
20029ae6:	bd38      	pop	{r3, r4, r5, pc}
20029ae8:	f104 0108 	add.w	r1, r4, #8
20029aec:	f105 0008 	add.w	r0, r5, #8
20029af0:	f7fe fc54 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029af4:	2800      	cmp	r0, #0
20029af6:	d1f5      	bne.n	20029ae4 <mbedtls_rsa_check_pub_priv+0x14>
20029af8:	f104 0114 	add.w	r1, r4, #20
20029afc:	f105 0014 	add.w	r0, r5, #20
20029b00:	f7fe fc4c 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029b04:	2800      	cmp	r0, #0
20029b06:	d0ee      	beq.n	20029ae6 <mbedtls_rsa_check_pub_priv+0x16>
20029b08:	e7ec      	b.n	20029ae4 <mbedtls_rsa_check_pub_priv+0x14>
20029b0a:	bf00      	nop
20029b0c:	ffffbe00 	.word	0xffffbe00

20029b10 <mbedtls_rsa_public>:
20029b10:	b5f0      	push	{r4, r5, r6, r7, lr}
20029b12:	460c      	mov	r4, r1
20029b14:	4605      	mov	r5, r0
20029b16:	b087      	sub	sp, #28
20029b18:	a803      	add	r0, sp, #12
20029b1a:	4616      	mov	r6, r2
20029b1c:	f7fe f9e6 	bl	20027eec <mbedtls_mpi_init>
20029b20:	4621      	mov	r1, r4
20029b22:	686a      	ldr	r2, [r5, #4]
20029b24:	a803      	add	r0, sp, #12
20029b26:	f7fe faa9 	bl	2002807c <mbedtls_mpi_read_binary>
20029b2a:	4604      	mov	r4, r0
20029b2c:	b9d0      	cbnz	r0, 20029b64 <mbedtls_rsa_public+0x54>
20029b2e:	f105 0408 	add.w	r4, r5, #8
20029b32:	4621      	mov	r1, r4
20029b34:	a803      	add	r0, sp, #12
20029b36:	f7fe fc31 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029b3a:	2800      	cmp	r0, #0
20029b3c:	da1b      	bge.n	20029b76 <mbedtls_rsa_public+0x66>
20029b3e:	f105 0368 	add.w	r3, r5, #104	@ 0x68
20029b42:	a903      	add	r1, sp, #12
20029b44:	686f      	ldr	r7, [r5, #4]
20029b46:	4608      	mov	r0, r1
20029b48:	9300      	str	r3, [sp, #0]
20029b4a:	f105 0214 	add.w	r2, r5, #20
20029b4e:	4623      	mov	r3, r4
20029b50:	f7ff f81b 	bl	20028b8a <mbedtls_mpi_exp_mod>
20029b54:	4604      	mov	r4, r0
20029b56:	b928      	cbnz	r0, 20029b64 <mbedtls_rsa_public+0x54>
20029b58:	463a      	mov	r2, r7
20029b5a:	4631      	mov	r1, r6
20029b5c:	a803      	add	r0, sp, #12
20029b5e:	f7fe fac2 	bl	200280e6 <mbedtls_mpi_write_binary>
20029b62:	4604      	mov	r4, r0
20029b64:	a803      	add	r0, sp, #12
20029b66:	f7fe f9c8 	bl	20027efa <mbedtls_mpi_free>
20029b6a:	b10c      	cbz	r4, 20029b70 <mbedtls_rsa_public+0x60>
20029b6c:	f5a4 4485 	sub.w	r4, r4, #17024	@ 0x4280
20029b70:	4620      	mov	r0, r4
20029b72:	b007      	add	sp, #28
20029b74:	bdf0      	pop	{r4, r5, r6, r7, pc}
20029b76:	f06f 0403 	mvn.w	r4, #3
20029b7a:	e7f3      	b.n	20029b64 <mbedtls_rsa_public+0x54>

20029b7c <mbedtls_rsa_private>:
20029b7c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20029b80:	461e      	mov	r6, r3
20029b82:	6b43      	ldr	r3, [r0, #52]	@ 0x34
20029b84:	4604      	mov	r4, r0
20029b86:	460d      	mov	r5, r1
20029b88:	4617      	mov	r7, r2
20029b8a:	b09d      	sub	sp, #116	@ 0x74
20029b8c:	2b00      	cmp	r3, #0
20029b8e:	f000 8179 	beq.w	20029e84 <mbedtls_rsa_private+0x308>
20029b92:	6c03      	ldr	r3, [r0, #64]	@ 0x40
20029b94:	2b00      	cmp	r3, #0
20029b96:	f000 8175 	beq.w	20029e84 <mbedtls_rsa_private+0x308>
20029b9a:	6a83      	ldr	r3, [r0, #40]	@ 0x28
20029b9c:	2b00      	cmp	r3, #0
20029b9e:	f000 8171 	beq.w	20029e84 <mbedtls_rsa_private+0x308>
20029ba2:	a804      	add	r0, sp, #16
20029ba4:	f7fe f9a2 	bl	20027eec <mbedtls_mpi_init>
20029ba8:	a807      	add	r0, sp, #28
20029baa:	f7fe f99f 	bl	20027eec <mbedtls_mpi_init>
20029bae:	a80a      	add	r0, sp, #40	@ 0x28
20029bb0:	f7fe f99c 	bl	20027eec <mbedtls_mpi_init>
20029bb4:	a80d      	add	r0, sp, #52	@ 0x34
20029bb6:	f7fe f999 	bl	20027eec <mbedtls_mpi_init>
20029bba:	a810      	add	r0, sp, #64	@ 0x40
20029bbc:	f7fe f996 	bl	20027eec <mbedtls_mpi_init>
20029bc0:	a813      	add	r0, sp, #76	@ 0x4c
20029bc2:	f7fe f993 	bl	20027eec <mbedtls_mpi_init>
20029bc6:	b12d      	cbz	r5, 20029bd4 <mbedtls_rsa_private+0x58>
20029bc8:	a816      	add	r0, sp, #88	@ 0x58
20029bca:	f7fe f98f 	bl	20027eec <mbedtls_mpi_init>
20029bce:	a819      	add	r0, sp, #100	@ 0x64
20029bd0:	f7fe f98c 	bl	20027eec <mbedtls_mpi_init>
20029bd4:	4631      	mov	r1, r6
20029bd6:	6862      	ldr	r2, [r4, #4]
20029bd8:	a804      	add	r0, sp, #16
20029bda:	f7fe fa4f 	bl	2002807c <mbedtls_mpi_read_binary>
20029bde:	4603      	mov	r3, r0
20029be0:	2800      	cmp	r0, #0
20029be2:	f040 80e0 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029be6:	f104 0608 	add.w	r6, r4, #8
20029bea:	4631      	mov	r1, r6
20029bec:	a804      	add	r0, sp, #16
20029bee:	f7fe fbd5 	bl	2002839c <mbedtls_mpi_cmp_mpi>
20029bf2:	2800      	cmp	r0, #0
20029bf4:	f280 8143 	bge.w	20029e7e <mbedtls_rsa_private+0x302>
20029bf8:	f104 0a44 	add.w	sl, r4, #68	@ 0x44
20029bfc:	f104 0950 	add.w	r9, r4, #80	@ 0x50
20029c00:	2d00      	cmp	r5, #0
20029c02:	f000 8089 	beq.w	20029d18 <mbedtls_rsa_private+0x19c>
20029c06:	f8d4 30a0 	ldr.w	r3, [r4, #160]	@ 0xa0
20029c0a:	2b00      	cmp	r3, #0
20029c0c:	f000 80f4 	beq.w	20029df8 <mbedtls_rsa_private+0x27c>
20029c10:	f104 088c 	add.w	r8, r4, #140	@ 0x8c
20029c14:	4642      	mov	r2, r8
20029c16:	4641      	mov	r1, r8
20029c18:	4640      	mov	r0, r8
20029c1a:	f7fe fd0f 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029c1e:	4603      	mov	r3, r0
20029c20:	2800      	cmp	r0, #0
20029c22:	f040 80c0 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c26:	4632      	mov	r2, r6
20029c28:	4641      	mov	r1, r8
20029c2a:	4640      	mov	r0, r8
20029c2c:	f7fe ff7b 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20029c30:	4603      	mov	r3, r0
20029c32:	2800      	cmp	r0, #0
20029c34:	f040 80b7 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c38:	f104 0898 	add.w	r8, r4, #152	@ 0x98
20029c3c:	4642      	mov	r2, r8
20029c3e:	4641      	mov	r1, r8
20029c40:	4640      	mov	r0, r8
20029c42:	f7fe fcfb 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029c46:	4603      	mov	r3, r0
20029c48:	2800      	cmp	r0, #0
20029c4a:	f040 80ac 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c4e:	4632      	mov	r2, r6
20029c50:	4641      	mov	r1, r8
20029c52:	4640      	mov	r0, r8
20029c54:	f7fe ff67 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20029c58:	4603      	mov	r3, r0
20029c5a:	2800      	cmp	r0, #0
20029c5c:	f040 80a3 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c60:	a904      	add	r1, sp, #16
20029c62:	4608      	mov	r0, r1
20029c64:	f104 028c 	add.w	r2, r4, #140	@ 0x8c
20029c68:	f7fe fce8 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029c6c:	4603      	mov	r3, r0
20029c6e:	2800      	cmp	r0, #0
20029c70:	f040 8099 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c74:	a904      	add	r1, sp, #16
20029c76:	4632      	mov	r2, r6
20029c78:	4608      	mov	r0, r1
20029c7a:	f7fe ff54 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20029c7e:	4603      	mov	r3, r0
20029c80:	2800      	cmp	r0, #0
20029c82:	f040 8090 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c86:	2201      	movs	r2, #1
20029c88:	f104 012c 	add.w	r1, r4, #44	@ 0x2c
20029c8c:	a80d      	add	r0, sp, #52	@ 0x34
20029c8e:	f7fe fcbf 	bl	20028610 <mbedtls_mpi_sub_int>
20029c92:	4603      	mov	r3, r0
20029c94:	2800      	cmp	r0, #0
20029c96:	f040 8086 	bne.w	20029da6 <mbedtls_rsa_private+0x22a>
20029c9a:	2201      	movs	r2, #1
20029c9c:	f104 0138 	add.w	r1, r4, #56	@ 0x38
20029ca0:	a810      	add	r0, sp, #64	@ 0x40
20029ca2:	f7fe fcb5 	bl	20028610 <mbedtls_mpi_sub_int>
20029ca6:	4603      	mov	r3, r0
20029ca8:	2800      	cmp	r0, #0
20029caa:	d17c      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029cac:	463b      	mov	r3, r7
20029cae:	462a      	mov	r2, r5
20029cb0:	211c      	movs	r1, #28
20029cb2:	a813      	add	r0, sp, #76	@ 0x4c
20029cb4:	f7ff f9fb 	bl	200290ae <mbedtls_mpi_fill_random>
20029cb8:	4603      	mov	r3, r0
20029cba:	2800      	cmp	r0, #0
20029cbc:	d173      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029cbe:	aa13      	add	r2, sp, #76	@ 0x4c
20029cc0:	a90d      	add	r1, sp, #52	@ 0x34
20029cc2:	a816      	add	r0, sp, #88	@ 0x58
20029cc4:	f7fe fcba 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029cc8:	4603      	mov	r3, r0
20029cca:	2800      	cmp	r0, #0
20029ccc:	d16b      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029cce:	a916      	add	r1, sp, #88	@ 0x58
20029cd0:	4652      	mov	r2, sl
20029cd2:	4608      	mov	r0, r1
20029cd4:	f7fe fc4f 	bl	20028576 <mbedtls_mpi_add_mpi>
20029cd8:	4603      	mov	r3, r0
20029cda:	2800      	cmp	r0, #0
20029cdc:	d163      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029cde:	463b      	mov	r3, r7
20029ce0:	462a      	mov	r2, r5
20029ce2:	211c      	movs	r1, #28
20029ce4:	a813      	add	r0, sp, #76	@ 0x4c
20029ce6:	f7ff f9e2 	bl	200290ae <mbedtls_mpi_fill_random>
20029cea:	4603      	mov	r3, r0
20029cec:	2800      	cmp	r0, #0
20029cee:	d15a      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029cf0:	aa13      	add	r2, sp, #76	@ 0x4c
20029cf2:	a910      	add	r1, sp, #64	@ 0x40
20029cf4:	a819      	add	r0, sp, #100	@ 0x64
20029cf6:	f7fe fca1 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029cfa:	4603      	mov	r3, r0
20029cfc:	2800      	cmp	r0, #0
20029cfe:	d152      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029d00:	a919      	add	r1, sp, #100	@ 0x64
20029d02:	464a      	mov	r2, r9
20029d04:	4608      	mov	r0, r1
20029d06:	f7fe fc36 	bl	20028576 <mbedtls_mpi_add_mpi>
20029d0a:	4603      	mov	r3, r0
20029d0c:	2800      	cmp	r0, #0
20029d0e:	d14a      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029d10:	f10d 0964 	add.w	r9, sp, #100	@ 0x64
20029d14:	f10d 0a58 	add.w	sl, sp, #88	@ 0x58
20029d18:	f104 0374 	add.w	r3, r4, #116	@ 0x74
20029d1c:	f104 082c 	add.w	r8, r4, #44	@ 0x2c
20029d20:	9300      	str	r3, [sp, #0]
20029d22:	4652      	mov	r2, sl
20029d24:	4643      	mov	r3, r8
20029d26:	a904      	add	r1, sp, #16
20029d28:	a807      	add	r0, sp, #28
20029d2a:	f7fe ff2e 	bl	20028b8a <mbedtls_mpi_exp_mod>
20029d2e:	4603      	mov	r3, r0
20029d30:	2800      	cmp	r0, #0
20029d32:	d138      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029d34:	f104 0380 	add.w	r3, r4, #128	@ 0x80
20029d38:	f104 0738 	add.w	r7, r4, #56	@ 0x38
20029d3c:	9300      	str	r3, [sp, #0]
20029d3e:	464a      	mov	r2, r9
20029d40:	463b      	mov	r3, r7
20029d42:	a904      	add	r1, sp, #16
20029d44:	a80a      	add	r0, sp, #40	@ 0x28
20029d46:	f7fe ff20 	bl	20028b8a <mbedtls_mpi_exp_mod>
20029d4a:	4603      	mov	r3, r0
20029d4c:	bb58      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d4e:	aa0a      	add	r2, sp, #40	@ 0x28
20029d50:	a907      	add	r1, sp, #28
20029d52:	a804      	add	r0, sp, #16
20029d54:	f7fe fc35 	bl	200285c2 <mbedtls_mpi_sub_mpi>
20029d58:	4603      	mov	r3, r0
20029d5a:	bb20      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d5c:	f104 025c 	add.w	r2, r4, #92	@ 0x5c
20029d60:	a904      	add	r1, sp, #16
20029d62:	a807      	add	r0, sp, #28
20029d64:	f7fe fc6a 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029d68:	4603      	mov	r3, r0
20029d6a:	b9e0      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d6c:	4642      	mov	r2, r8
20029d6e:	a907      	add	r1, sp, #28
20029d70:	a804      	add	r0, sp, #16
20029d72:	f7fe fed8 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20029d76:	4603      	mov	r3, r0
20029d78:	b9a8      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d7a:	463a      	mov	r2, r7
20029d7c:	a904      	add	r1, sp, #16
20029d7e:	a807      	add	r0, sp, #28
20029d80:	f7fe fc5c 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029d84:	4603      	mov	r3, r0
20029d86:	b970      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d88:	aa07      	add	r2, sp, #28
20029d8a:	a90a      	add	r1, sp, #40	@ 0x28
20029d8c:	a804      	add	r0, sp, #16
20029d8e:	f7fe fbf2 	bl	20028576 <mbedtls_mpi_add_mpi>
20029d92:	4603      	mov	r3, r0
20029d94:	b938      	cbnz	r0, 20029da6 <mbedtls_rsa_private+0x22a>
20029d96:	2d00      	cmp	r5, #0
20029d98:	d15f      	bne.n	20029e5a <mbedtls_rsa_private+0x2de>
20029d9a:	6862      	ldr	r2, [r4, #4]
20029d9c:	9926      	ldr	r1, [sp, #152]	@ 0x98
20029d9e:	a804      	add	r0, sp, #16
20029da0:	f7fe f9a1 	bl	200280e6 <mbedtls_mpi_write_binary>
20029da4:	4603      	mov	r3, r0
20029da6:	a804      	add	r0, sp, #16
20029da8:	9303      	str	r3, [sp, #12]
20029daa:	f7fe f8a6 	bl	20027efa <mbedtls_mpi_free>
20029dae:	a807      	add	r0, sp, #28
20029db0:	f7fe f8a3 	bl	20027efa <mbedtls_mpi_free>
20029db4:	a80a      	add	r0, sp, #40	@ 0x28
20029db6:	f7fe f8a0 	bl	20027efa <mbedtls_mpi_free>
20029dba:	a80d      	add	r0, sp, #52	@ 0x34
20029dbc:	f7fe f89d 	bl	20027efa <mbedtls_mpi_free>
20029dc0:	a810      	add	r0, sp, #64	@ 0x40
20029dc2:	f7fe f89a 	bl	20027efa <mbedtls_mpi_free>
20029dc6:	a813      	add	r0, sp, #76	@ 0x4c
20029dc8:	f7fe f897 	bl	20027efa <mbedtls_mpi_free>
20029dcc:	9b03      	ldr	r3, [sp, #12]
20029dce:	b135      	cbz	r5, 20029dde <mbedtls_rsa_private+0x262>
20029dd0:	a816      	add	r0, sp, #88	@ 0x58
20029dd2:	f7fe f892 	bl	20027efa <mbedtls_mpi_free>
20029dd6:	a819      	add	r0, sp, #100	@ 0x64
20029dd8:	f7fe f88f 	bl	20027efa <mbedtls_mpi_free>
20029ddc:	9b03      	ldr	r3, [sp, #12]
20029dde:	b10b      	cbz	r3, 20029de4 <mbedtls_rsa_private+0x268>
20029de0:	f5a3 4386 	sub.w	r3, r3, #17152	@ 0x4300
20029de4:	4618      	mov	r0, r3
20029de6:	b01d      	add	sp, #116	@ 0x74
20029de8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20029dec:	9b03      	ldr	r3, [sp, #12]
20029dee:	3b01      	subs	r3, #1
20029df0:	9303      	str	r3, [sp, #12]
20029df2:	d107      	bne.n	20029e04 <mbedtls_rsa_private+0x288>
20029df4:	4b24      	ldr	r3, [pc, #144]	@ (20029e88 <mbedtls_rsa_private+0x30c>)
20029df6:	e7d6      	b.n	20029da6 <mbedtls_rsa_private+0x22a>
20029df8:	230b      	movs	r3, #11
20029dfa:	f104 0b98 	add.w	fp, r4, #152	@ 0x98
20029dfe:	9303      	str	r3, [sp, #12]
20029e00:	f104 088c 	add.w	r8, r4, #140	@ 0x8c
20029e04:	6861      	ldr	r1, [r4, #4]
20029e06:	463b      	mov	r3, r7
20029e08:	462a      	mov	r2, r5
20029e0a:	4658      	mov	r0, fp
20029e0c:	3901      	subs	r1, #1
20029e0e:	f7ff f94e 	bl	200290ae <mbedtls_mpi_fill_random>
20029e12:	4603      	mov	r3, r0
20029e14:	2800      	cmp	r0, #0
20029e16:	d1c6      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e18:	4632      	mov	r2, r6
20029e1a:	4659      	mov	r1, fp
20029e1c:	4640      	mov	r0, r8
20029e1e:	f7ff f8c8 	bl	20028fb2 <mbedtls_mpi_gcd>
20029e22:	4603      	mov	r3, r0
20029e24:	2800      	cmp	r0, #0
20029e26:	d1be      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e28:	2101      	movs	r1, #1
20029e2a:	4640      	mov	r0, r8
20029e2c:	f7fe faf7 	bl	2002841e <mbedtls_mpi_cmp_int>
20029e30:	2800      	cmp	r0, #0
20029e32:	d1db      	bne.n	20029dec <mbedtls_rsa_private+0x270>
20029e34:	4632      	mov	r2, r6
20029e36:	4659      	mov	r1, fp
20029e38:	4640      	mov	r0, r8
20029e3a:	f7ff f955 	bl	200290e8 <mbedtls_mpi_inv_mod>
20029e3e:	4603      	mov	r3, r0
20029e40:	2800      	cmp	r0, #0
20029e42:	d1b0      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e44:	f104 0368 	add.w	r3, r4, #104	@ 0x68
20029e48:	9300      	str	r3, [sp, #0]
20029e4a:	4641      	mov	r1, r8
20029e4c:	4633      	mov	r3, r6
20029e4e:	4640      	mov	r0, r8
20029e50:	f104 0214 	add.w	r2, r4, #20
20029e54:	f7fe fe99 	bl	20028b8a <mbedtls_mpi_exp_mod>
20029e58:	e6fe      	b.n	20029c58 <mbedtls_rsa_private+0xdc>
20029e5a:	a904      	add	r1, sp, #16
20029e5c:	4608      	mov	r0, r1
20029e5e:	f104 0298 	add.w	r2, r4, #152	@ 0x98
20029e62:	f7fe fbeb 	bl	2002863c <mbedtls_mpi_mul_mpi>
20029e66:	4603      	mov	r3, r0
20029e68:	2800      	cmp	r0, #0
20029e6a:	d19c      	bne.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e6c:	a904      	add	r1, sp, #16
20029e6e:	4632      	mov	r2, r6
20029e70:	4608      	mov	r0, r1
20029e72:	f7fe fe58 	bl	20028b26 <mbedtls_mpi_mod_mpi>
20029e76:	4603      	mov	r3, r0
20029e78:	2800      	cmp	r0, #0
20029e7a:	d08e      	beq.n	20029d9a <mbedtls_rsa_private+0x21e>
20029e7c:	e793      	b.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e7e:	f06f 0303 	mvn.w	r3, #3
20029e82:	e790      	b.n	20029da6 <mbedtls_rsa_private+0x22a>
20029e84:	4b01      	ldr	r3, [pc, #4]	@ (20029e8c <mbedtls_rsa_private+0x310>)
20029e86:	e7ad      	b.n	20029de4 <mbedtls_rsa_private+0x268>
20029e88:	ffffbb80 	.word	0xffffbb80
20029e8c:	ffffbf80 	.word	0xffffbf80

20029e90 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt>:
20029e90:	e92d 4ff7 	stmdb	sp!, {r0, r1, r2, r4, r5, r6, r7, r8, r9, sl, fp, lr}
20029e94:	4698      	mov	r8, r3
20029e96:	e9dd a30c 	ldrd	sl, r3, [sp, #48]	@ 0x30
20029e9a:	f1b8 0f01 	cmp.w	r8, #1
20029e9e:	4606      	mov	r6, r0
20029ea0:	460f      	mov	r7, r1
20029ea2:	4691      	mov	r9, r2
20029ea4:	9d0e      	ldr	r5, [sp, #56]	@ 0x38
20029ea6:	d103      	bne.n	20029eb0 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0x20>
20029ea8:	f8d0 20a4 	ldr.w	r2, [r0, #164]	@ 0xa4
20029eac:	2a00      	cmp	r2, #0
20029eae:	d162      	bne.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029eb0:	2f00      	cmp	r7, #0
20029eb2:	d060      	beq.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029eb4:	2b00      	cmp	r3, #0
20029eb6:	d05e      	beq.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029eb8:	2d00      	cmp	r5, #0
20029eba:	d05c      	beq.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029ebc:	f11a 0f0c 	cmn.w	sl, #12
20029ec0:	6874      	ldr	r4, [r6, #4]
20029ec2:	d858      	bhi.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029ec4:	f10a 020b 	add.w	r2, sl, #11
20029ec8:	42a2      	cmp	r2, r4
20029eca:	d854      	bhi.n	20029f76 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xe6>
20029ecc:	4629      	mov	r1, r5
20029ece:	2200      	movs	r2, #0
20029ed0:	eba4 040a 	sub.w	r4, r4, sl
20029ed4:	3c03      	subs	r4, #3
20029ed6:	f801 2b02 	strb.w	r2, [r1], #2
20029eda:	f1b8 0f00 	cmp.w	r8, #0
20029ede:	d131      	bne.n	20029f44 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xb4>
20029ee0:	2202      	movs	r2, #2
20029ee2:	4414      	add	r4, r2
20029ee4:	706a      	strb	r2, [r5, #1]
20029ee6:	442c      	add	r4, r5
20029ee8:	42a1      	cmp	r1, r4
20029eea:	d112      	bne.n	20029f12 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0x82>
20029eec:	2200      	movs	r2, #0
20029eee:	4620      	mov	r0, r4
20029ef0:	4619      	mov	r1, r3
20029ef2:	f800 2b01 	strb.w	r2, [r0], #1
20029ef6:	4652      	mov	r2, sl
20029ef8:	f000 fdaa 	bl	2002aa50 <memcpy>
20029efc:	f1b8 0f00 	cmp.w	r8, #0
20029f00:	d12f      	bne.n	20029f62 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xd2>
20029f02:	462a      	mov	r2, r5
20029f04:	4629      	mov	r1, r5
20029f06:	4630      	mov	r0, r6
20029f08:	b003      	add	sp, #12
20029f0a:	e8bd 4ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20029f0e:	f7ff bdff 	b.w	20029b10 <mbedtls_rsa_public>
20029f12:	f04f 0b64 	mov.w	fp, #100	@ 0x64
20029f16:	2201      	movs	r2, #1
20029f18:	4648      	mov	r0, r9
20029f1a:	9301      	str	r3, [sp, #4]
20029f1c:	9100      	str	r1, [sp, #0]
20029f1e:	47b8      	blx	r7
20029f20:	9900      	ldr	r1, [sp, #0]
20029f22:	9b01      	ldr	r3, [sp, #4]
20029f24:	780a      	ldrb	r2, [r1, #0]
20029f26:	b94a      	cbnz	r2, 20029f3c <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xac>
20029f28:	f1bb 0b01 	subs.w	fp, fp, #1
20029f2c:	d001      	beq.n	20029f32 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xa2>
20029f2e:	2800      	cmp	r0, #0
20029f30:	d0f1      	beq.n	20029f16 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0x86>
20029f32:	f5a0 4089 	sub.w	r0, r0, #17536	@ 0x4480
20029f36:	b003      	add	sp, #12
20029f38:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20029f3c:	2800      	cmp	r0, #0
20029f3e:	d1f8      	bne.n	20029f32 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xa2>
20029f40:	3101      	adds	r1, #1
20029f42:	e7d1      	b.n	20029ee8 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0x58>
20029f44:	2001      	movs	r0, #1
20029f46:	462a      	mov	r2, r5
20029f48:	f04f 0cff 	mov.w	ip, #255	@ 0xff
20029f4c:	f802 0f01 	strb.w	r0, [r2, #1]!
20029f50:	1820      	adds	r0, r4, r0
20029f52:	4428      	add	r0, r5
20029f54:	4282      	cmp	r2, r0
20029f56:	d101      	bne.n	20029f5c <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xcc>
20029f58:	440c      	add	r4, r1
20029f5a:	e7c7      	b.n	20029eec <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0x5c>
20029f5c:	f802 cf01 	strb.w	ip, [r2, #1]!
20029f60:	e7f8      	b.n	20029f54 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xc4>
20029f62:	462b      	mov	r3, r5
20029f64:	464a      	mov	r2, r9
20029f66:	4639      	mov	r1, r7
20029f68:	4630      	mov	r0, r6
20029f6a:	950c      	str	r5, [sp, #48]	@ 0x30
20029f6c:	b003      	add	sp, #12
20029f6e:	e8bd 4ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20029f72:	f7ff be03 	b.w	20029b7c <mbedtls_rsa_private>
20029f76:	4801      	ldr	r0, [pc, #4]	@ (20029f7c <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xec>)
20029f78:	e7dd      	b.n	20029f36 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt+0xa6>
20029f7a:	bf00      	nop
20029f7c:	ffffbf80 	.word	0xffffbf80

20029f80 <mbedtls_rsa_pkcs1_encrypt>:
20029f80:	b410      	push	{r4}
20029f82:	f8d0 40a4 	ldr.w	r4, [r0, #164]	@ 0xa4
20029f86:	b91c      	cbnz	r4, 20029f90 <mbedtls_rsa_pkcs1_encrypt+0x10>
20029f88:	f85d 4b04 	ldr.w	r4, [sp], #4
20029f8c:	f7ff bf80 	b.w	20029e90 <mbedtls_rsa_rsaes_pkcs1_v15_encrypt>
20029f90:	4801      	ldr	r0, [pc, #4]	@ (20029f98 <mbedtls_rsa_pkcs1_encrypt+0x18>)
20029f92:	f85d 4b04 	ldr.w	r4, [sp], #4
20029f96:	4770      	bx	lr
20029f98:	ffffbf00 	.word	0xffffbf00

20029f9c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt>:
20029f9c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20029fa0:	4698      	mov	r8, r3
20029fa2:	f5ad 6d81 	sub.w	sp, sp, #1032	@ 0x408
20029fa6:	f1b8 0f01 	cmp.w	r8, #1
20029faa:	f8dd 3424 	ldr.w	r3, [sp, #1060]	@ 0x424
20029fae:	d103      	bne.n	20029fb8 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x1c>
20029fb0:	f8d0 40a4 	ldr.w	r4, [r0, #164]	@ 0xa4
20029fb4:	2c00      	cmp	r4, #0
20029fb6:	d17c      	bne.n	2002a0b2 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x116>
20029fb8:	6845      	ldr	r5, [r0, #4]
20029fba:	f1a5 0410 	sub.w	r4, r5, #16
20029fbe:	f5b4 7f7c 	cmp.w	r4, #1008	@ 0x3f0
20029fc2:	d876      	bhi.n	2002a0b2 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x116>
20029fc4:	ae02      	add	r6, sp, #8
20029fc6:	f1b8 0f00 	cmp.w	r8, #0
20029fca:	d153      	bne.n	2002a074 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xd8>
20029fcc:	4632      	mov	r2, r6
20029fce:	4619      	mov	r1, r3
20029fd0:	f7ff fd9e 	bl	20029b10 <mbedtls_rsa_public>
20029fd4:	4604      	mov	r4, r0
20029fd6:	2800      	cmp	r0, #0
20029fd8:	d140      	bne.n	2002a05c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xc0>
20029fda:	f1b8 0f01 	cmp.w	r8, #1
20029fde:	7831      	ldrb	r1, [r6, #0]
20029fe0:	7872      	ldrb	r2, [r6, #1]
20029fe2:	f1a5 0703 	sub.w	r7, r5, #3
20029fe6:	d149      	bne.n	2002a07c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xe0>
20029fe8:	f082 0202 	eor.w	r2, r2, #2
20029fec:	ea41 0302 	orr.w	r3, r1, r2
20029ff0:	4684      	mov	ip, r0
20029ff2:	4686      	mov	lr, r0
20029ff4:	4602      	mov	r2, r0
20029ff6:	f10d 0109 	add.w	r1, sp, #9
20029ffa:	f811 0f01 	ldrb.w	r0, [r1, #1]!
20029ffe:	f10e 0e01 	add.w	lr, lr, #1
2002a002:	f1c0 0800 	rsb	r8, r0, #0
2002a006:	ea40 0008 	orr.w	r0, r0, r8
2002a00a:	f3c0 10c0 	ubfx	r0, r0, #7, #1
2002a00e:	f080 0001 	eor.w	r0, r0, #1
2002a012:	ea4c 0c00 	orr.w	ip, ip, r0
2002a016:	f1cc 0000 	rsb	r0, ip, #0
2002a01a:	ea4c 0000 	orr.w	r0, ip, r0
2002a01e:	f3c0 10c0 	ubfx	r0, r0, #7, #1
2002a022:	f080 0001 	eor.w	r0, r0, #1
2002a026:	45be      	cmp	lr, r7
2002a028:	4402      	add	r2, r0
2002a02a:	d3e6      	bcc.n	20029ffa <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x5e>
2002a02c:	f10d 000a 	add.w	r0, sp, #10
2002a030:	1881      	adds	r1, r0, r2
2002a032:	5c80      	ldrb	r0, [r0, r2]
2002a034:	3101      	adds	r1, #1
2002a036:	4303      	orrs	r3, r0
2002a038:	2a07      	cmp	r2, #7
2002a03a:	bf98      	it	ls
2002a03c:	f043 0301 	orrls.w	r3, r3, #1
2002a040:	bb9b      	cbnz	r3, 2002a0aa <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x10e>
2002a042:	1b8b      	subs	r3, r1, r6
2002a044:	1aea      	subs	r2, r5, r3
2002a046:	f8dd 342c 	ldr.w	r3, [sp, #1068]	@ 0x42c
2002a04a:	429a      	cmp	r2, r3
2002a04c:	d82f      	bhi.n	2002a0ae <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x112>
2002a04e:	f8dd 3420 	ldr.w	r3, [sp, #1056]	@ 0x420
2002a052:	f8dd 0428 	ldr.w	r0, [sp, #1064]	@ 0x428
2002a056:	601a      	str	r2, [r3, #0]
2002a058:	f000 fcfa 	bl	2002aa50 <memcpy>
2002a05c:	2300      	movs	r3, #0
2002a05e:	461a      	mov	r2, r3
2002a060:	54f2      	strb	r2, [r6, r3]
2002a062:	3301      	adds	r3, #1
2002a064:	f5b3 6f80 	cmp.w	r3, #1024	@ 0x400
2002a068:	d1fa      	bne.n	2002a060 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xc4>
2002a06a:	4620      	mov	r0, r4
2002a06c:	f50d 6d81 	add.w	sp, sp, #1032	@ 0x408
2002a070:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002a074:	9600      	str	r6, [sp, #0]
2002a076:	f7ff fd81 	bl	20029b7c <mbedtls_rsa_private>
2002a07a:	e7ab      	b.n	20029fd4 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x38>
2002a07c:	f082 0201 	eor.w	r2, r2, #1
2002a080:	ea41 0302 	orr.w	r3, r1, r2
2002a084:	4684      	mov	ip, r0
2002a086:	4602      	mov	r2, r0
2002a088:	f10d 0109 	add.w	r1, sp, #9
2002a08c:	f811 ef01 	ldrb.w	lr, [r1, #1]!
2002a090:	3001      	adds	r0, #1
2002a092:	f1be 0fff 	cmp.w	lr, #255	@ 0xff
2002a096:	bf18      	it	ne
2002a098:	f04c 0c01 	orrne.w	ip, ip, #1
2002a09c:	42b8      	cmp	r0, r7
2002a09e:	f08c 0e01 	eor.w	lr, ip, #1
2002a0a2:	fa52 f28e 	uxtab	r2, r2, lr
2002a0a6:	d3f1      	bcc.n	2002a08c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xf0>
2002a0a8:	e7c0      	b.n	2002a02c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x90>
2002a0aa:	4c03      	ldr	r4, [pc, #12]	@ (2002a0b8 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x11c>)
2002a0ac:	e7d6      	b.n	2002a05c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xc0>
2002a0ae:	4c03      	ldr	r4, [pc, #12]	@ (2002a0bc <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x120>)
2002a0b0:	e7d4      	b.n	2002a05c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xc0>
2002a0b2:	4c03      	ldr	r4, [pc, #12]	@ (2002a0c0 <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0x124>)
2002a0b4:	e7d9      	b.n	2002a06a <mbedtls_rsa_rsaes_pkcs1_v15_decrypt+0xce>
2002a0b6:	bf00      	nop
2002a0b8:	ffffbf00 	.word	0xffffbf00
2002a0bc:	ffffbc00 	.word	0xffffbc00
2002a0c0:	ffffbf80 	.word	0xffffbf80

2002a0c4 <mbedtls_rsa_pkcs1_decrypt>:
2002a0c4:	b410      	push	{r4}
2002a0c6:	f8d0 40a4 	ldr.w	r4, [r0, #164]	@ 0xa4
2002a0ca:	b91c      	cbnz	r4, 2002a0d4 <mbedtls_rsa_pkcs1_decrypt+0x10>
2002a0cc:	f85d 4b04 	ldr.w	r4, [sp], #4
2002a0d0:	f7ff bf64 	b.w	20029f9c <mbedtls_rsa_rsaes_pkcs1_v15_decrypt>
2002a0d4:	4801      	ldr	r0, [pc, #4]	@ (2002a0dc <mbedtls_rsa_pkcs1_decrypt+0x18>)
2002a0d6:	f85d 4b04 	ldr.w	r4, [sp], #4
2002a0da:	4770      	bx	lr
2002a0dc:	ffffbf00 	.word	0xffffbf00

2002a0e0 <mbedtls_rsa_rsassa_pkcs1_v15_sign>:
2002a0e0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002a0e4:	4692      	mov	sl, r2
2002a0e6:	2200      	movs	r2, #0
2002a0e8:	b089      	sub	sp, #36	@ 0x24
2002a0ea:	2b01      	cmp	r3, #1
2002a0ec:	4604      	mov	r4, r0
2002a0ee:	461f      	mov	r7, r3
2002a0f0:	e9cd 2206 	strd	r2, r2, [sp, #24]
2002a0f4:	f89d 8048 	ldrb.w	r8, [sp, #72]	@ 0x48
2002a0f8:	f8dd 904c 	ldr.w	r9, [sp, #76]	@ 0x4c
2002a0fc:	9e15      	ldr	r6, [sp, #84]	@ 0x54
2002a0fe:	9102      	str	r1, [sp, #8]
2002a100:	d107      	bne.n	2002a112 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x32>
2002a102:	f8d0 20a4 	ldr.w	r2, [r0, #164]	@ 0xa4
2002a106:	b122      	cbz	r2, 2002a112 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x32>
2002a108:	4d59      	ldr	r5, [pc, #356]	@ (2002a270 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x190>)
2002a10a:	4628      	mov	r0, r5
2002a10c:	b009      	add	sp, #36	@ 0x24
2002a10e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002a112:	f8d4 b004 	ldr.w	fp, [r4, #4]
2002a116:	f1ab 0503 	sub.w	r5, fp, #3
2002a11a:	f1b8 0f00 	cmp.w	r8, #0
2002a11e:	d014      	beq.n	2002a14a <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x6a>
2002a120:	4640      	mov	r0, r8
2002a122:	f7fb ff75 	bl	20026010 <mbedtls_md_info_from_type>
2002a126:	4681      	mov	r9, r0
2002a128:	2800      	cmp	r0, #0
2002a12a:	d0ed      	beq.n	2002a108 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x28>
2002a12c:	4640      	mov	r0, r8
2002a12e:	aa06      	add	r2, sp, #24
2002a130:	a907      	add	r1, sp, #28
2002a132:	f7ff f9d3 	bl	200294dc <mbedtls_oid_get_oid_by_md>
2002a136:	2800      	cmp	r0, #0
2002a138:	d1e6      	bne.n	2002a108 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x28>
2002a13a:	9a06      	ldr	r2, [sp, #24]
2002a13c:	4648      	mov	r0, r9
2002a13e:	1aaa      	subs	r2, r5, r2
2002a140:	f1a2 050a 	sub.w	r5, r2, #10
2002a144:	f7fb ff70 	bl	20026028 <mbedtls_md_get_size>
2002a148:	4681      	mov	r9, r0
2002a14a:	eba5 0209 	sub.w	r2, r5, r9
2002a14e:	2a07      	cmp	r2, #7
2002a150:	d9da      	bls.n	2002a108 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x28>
2002a152:	4593      	cmp	fp, r2
2002a154:	d3d8      	bcc.n	2002a108 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x28>
2002a156:	46b3      	mov	fp, r6
2002a158:	2500      	movs	r5, #0
2002a15a:	2101      	movs	r1, #1
2002a15c:	f80b 5b02 	strb.w	r5, [fp], #2
2002a160:	4658      	mov	r0, fp
2002a162:	7071      	strb	r1, [r6, #1]
2002a164:	21ff      	movs	r1, #255	@ 0xff
2002a166:	9203      	str	r2, [sp, #12]
2002a168:	f000 fc58 	bl	2002aa1c <memset>
2002a16c:	9a03      	ldr	r2, [sp, #12]
2002a16e:	eb0b 0002 	add.w	r0, fp, r2
2002a172:	f80b 5002 	strb.w	r5, [fp, r2]
2002a176:	f1b8 0f00 	cmp.w	r8, #0
2002a17a:	d10c      	bne.n	2002a196 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0xb6>
2002a17c:	464a      	mov	r2, r9
2002a17e:	9914      	ldr	r1, [sp, #80]	@ 0x50
2002a180:	3001      	adds	r0, #1
2002a182:	f000 fc65 	bl	2002aa50 <memcpy>
2002a186:	bb8f      	cbnz	r7, 2002a1ec <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x10c>
2002a188:	4632      	mov	r2, r6
2002a18a:	4631      	mov	r1, r6
2002a18c:	4620      	mov	r0, r4
2002a18e:	f7ff fcbf 	bl	20029b10 <mbedtls_rsa_public>
2002a192:	4605      	mov	r5, r0
2002a194:	e7b9      	b.n	2002a10a <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x2a>
2002a196:	2130      	movs	r1, #48	@ 0x30
2002a198:	7041      	strb	r1, [r0, #1]
2002a19a:	9a06      	ldr	r2, [sp, #24]
2002a19c:	70c1      	strb	r1, [r0, #3]
2002a19e:	3208      	adds	r2, #8
2002a1a0:	fa52 f289 	uxtab	r2, r2, r9
2002a1a4:	7082      	strb	r2, [r0, #2]
2002a1a6:	9a06      	ldr	r2, [sp, #24]
2002a1a8:	f100 0807 	add.w	r8, r0, #7
2002a1ac:	b2d1      	uxtb	r1, r2
2002a1ae:	f101 0c04 	add.w	ip, r1, #4
2002a1b2:	f880 c004 	strb.w	ip, [r0, #4]
2002a1b6:	f04f 0c06 	mov.w	ip, #6
2002a1ba:	7181      	strb	r1, [r0, #6]
2002a1bc:	f880 c005 	strb.w	ip, [r0, #5]
2002a1c0:	9907      	ldr	r1, [sp, #28]
2002a1c2:	4640      	mov	r0, r8
2002a1c4:	9203      	str	r2, [sp, #12]
2002a1c6:	f000 fc43 	bl	2002aa50 <memcpy>
2002a1ca:	2105      	movs	r1, #5
2002a1cc:	9a03      	ldr	r2, [sp, #12]
2002a1ce:	fa5f fb89 	uxtb.w	fp, r9
2002a1d2:	eb08 0002 	add.w	r0, r8, r2
2002a1d6:	f808 1002 	strb.w	r1, [r8, r2]
2002a1da:	2204      	movs	r2, #4
2002a1dc:	7045      	strb	r5, [r0, #1]
2002a1de:	7082      	strb	r2, [r0, #2]
2002a1e0:	f880 b003 	strb.w	fp, [r0, #3]
2002a1e4:	464a      	mov	r2, r9
2002a1e6:	9914      	ldr	r1, [sp, #80]	@ 0x50
2002a1e8:	3004      	adds	r0, #4
2002a1ea:	e7ca      	b.n	2002a182 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0xa2>
2002a1ec:	6865      	ldr	r5, [r4, #4]
2002a1ee:	2001      	movs	r0, #1
2002a1f0:	4629      	mov	r1, r5
2002a1f2:	f000 fb31 	bl	2002a858 <calloc>
2002a1f6:	4607      	mov	r7, r0
2002a1f8:	b140      	cbz	r0, 2002a20c <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x12c>
2002a1fa:	4629      	mov	r1, r5
2002a1fc:	2001      	movs	r0, #1
2002a1fe:	f000 fb2b 	bl	2002a858 <calloc>
2002a202:	4680      	mov	r8, r0
2002a204:	b928      	cbnz	r0, 2002a212 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x132>
2002a206:	4638      	mov	r0, r7
2002a208:	f000 fb42 	bl	2002a890 <free>
2002a20c:	f06f 050f 	mvn.w	r5, #15
2002a210:	e77b      	b.n	2002a10a <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x2a>
2002a212:	4633      	mov	r3, r6
2002a214:	4652      	mov	r2, sl
2002a216:	4620      	mov	r0, r4
2002a218:	9902      	ldr	r1, [sp, #8]
2002a21a:	9700      	str	r7, [sp, #0]
2002a21c:	f7ff fcae 	bl	20029b7c <mbedtls_rsa_private>
2002a220:	4605      	mov	r5, r0
2002a222:	b9a0      	cbnz	r0, 2002a24e <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x16e>
2002a224:	4642      	mov	r2, r8
2002a226:	4639      	mov	r1, r7
2002a228:	4620      	mov	r0, r4
2002a22a:	f7ff fc71 	bl	20029b10 <mbedtls_rsa_public>
2002a22e:	4605      	mov	r5, r0
2002a230:	b968      	cbnz	r0, 2002a24e <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x16e>
2002a232:	4601      	mov	r1, r0
2002a234:	4603      	mov	r3, r0
2002a236:	6862      	ldr	r2, [r4, #4]
2002a238:	429a      	cmp	r2, r3
2002a23a:	d10f      	bne.n	2002a25c <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x17c>
2002a23c:	f88d 1017 	strb.w	r1, [sp, #23]
2002a240:	f89d 3017 	ldrb.w	r3, [sp, #23]
2002a244:	b98b      	cbnz	r3, 2002a26a <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x18a>
2002a246:	4639      	mov	r1, r7
2002a248:	4630      	mov	r0, r6
2002a24a:	f000 fc01 	bl	2002aa50 <memcpy>
2002a24e:	4638      	mov	r0, r7
2002a250:	f000 fb1e 	bl	2002a890 <free>
2002a254:	4640      	mov	r0, r8
2002a256:	f000 fb1b 	bl	2002a890 <free>
2002a25a:	e756      	b.n	2002a10a <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x2a>
2002a25c:	f818 0003 	ldrb.w	r0, [r8, r3]
2002a260:	5cf4      	ldrb	r4, [r6, r3]
2002a262:	3301      	adds	r3, #1
2002a264:	4060      	eors	r0, r4
2002a266:	4301      	orrs	r1, r0
2002a268:	e7e6      	b.n	2002a238 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x158>
2002a26a:	4d02      	ldr	r5, [pc, #8]	@ (2002a274 <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x194>)
2002a26c:	e7ef      	b.n	2002a24e <mbedtls_rsa_rsassa_pkcs1_v15_sign+0x16e>
2002a26e:	bf00      	nop
2002a270:	ffffbf80 	.word	0xffffbf80
2002a274:	ffffbd00 	.word	0xffffbd00

2002a278 <mbedtls_rsa_pkcs1_sign>:
2002a278:	b430      	push	{r4, r5}
2002a27a:	f8d0 50a4 	ldr.w	r5, [r0, #164]	@ 0xa4
2002a27e:	f89d 4008 	ldrb.w	r4, [sp, #8]
2002a282:	b91d      	cbnz	r5, 2002a28c <mbedtls_rsa_pkcs1_sign+0x14>
2002a284:	9402      	str	r4, [sp, #8]
2002a286:	bc30      	pop	{r4, r5}
2002a288:	f7ff bf2a 	b.w	2002a0e0 <mbedtls_rsa_rsassa_pkcs1_v15_sign>
2002a28c:	4801      	ldr	r0, [pc, #4]	@ (2002a294 <mbedtls_rsa_pkcs1_sign+0x1c>)
2002a28e:	bc30      	pop	{r4, r5}
2002a290:	4770      	bx	lr
2002a292:	bf00      	nop
2002a294:	ffffbf00 	.word	0xffffbf00

2002a298 <mbedtls_rsa_rsassa_pkcs1_v15_verify>:
2002a298:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002a29c:	461c      	mov	r4, r3
2002a29e:	f2ad 4d2c 	subw	sp, sp, #1068	@ 0x42c
2002a2a2:	f89d 3450 	ldrb.w	r3, [sp, #1104]	@ 0x450
2002a2a6:	2c01      	cmp	r4, #1
2002a2a8:	9303      	str	r3, [sp, #12]
2002a2aa:	f8dd 8454 	ldr.w	r8, [sp, #1108]	@ 0x454
2002a2ae:	f8dd 345c 	ldr.w	r3, [sp, #1116]	@ 0x45c
2002a2b2:	d108      	bne.n	2002a2c6 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x2e>
2002a2b4:	f8d0 50a4 	ldr.w	r5, [r0, #164]	@ 0xa4
2002a2b8:	b12d      	cbz	r5, 2002a2c6 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x2e>
2002a2ba:	4d60      	ldr	r5, [pc, #384]	@ (2002a43c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x1a4>)
2002a2bc:	4628      	mov	r0, r5
2002a2be:	f20d 4d2c 	addw	sp, sp, #1068	@ 0x42c
2002a2c2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002a2c6:	6846      	ldr	r6, [r0, #4]
2002a2c8:	f1a6 0510 	sub.w	r5, r6, #16
2002a2cc:	f5b5 7f7c 	cmp.w	r5, #1008	@ 0x3f0
2002a2d0:	d8f3      	bhi.n	2002a2ba <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x22>
2002a2d2:	af0a      	add	r7, sp, #40	@ 0x28
2002a2d4:	b954      	cbnz	r4, 2002a2ec <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x54>
2002a2d6:	463a      	mov	r2, r7
2002a2d8:	4619      	mov	r1, r3
2002a2da:	f7ff fc19 	bl	20029b10 <mbedtls_rsa_public>
2002a2de:	4605      	mov	r5, r0
2002a2e0:	2800      	cmp	r0, #0
2002a2e2:	d1eb      	bne.n	2002a2bc <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x24>
2002a2e4:	783b      	ldrb	r3, [r7, #0]
2002a2e6:	b12b      	cbz	r3, 2002a2f4 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x5c>
2002a2e8:	4d55      	ldr	r5, [pc, #340]	@ (2002a440 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x1a8>)
2002a2ea:	e7e7      	b.n	2002a2bc <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x24>
2002a2ec:	9700      	str	r7, [sp, #0]
2002a2ee:	f7ff fc45 	bl	20029b7c <mbedtls_rsa_private>
2002a2f2:	e7f4      	b.n	2002a2de <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x46>
2002a2f4:	787b      	ldrb	r3, [r7, #1]
2002a2f6:	ac06      	add	r4, sp, #24
2002a2f8:	f10d 002a 	add.w	r0, sp, #42	@ 0x2a
2002a2fc:	2b01      	cmp	r3, #1
2002a2fe:	6020      	str	r0, [r4, #0]
2002a300:	d1f2      	bne.n	2002a2e8 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x50>
2002a302:	1e73      	subs	r3, r6, #1
2002a304:	443b      	add	r3, r7
2002a306:	7802      	ldrb	r2, [r0, #0]
2002a308:	b992      	cbnz	r2, 2002a330 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x98>
2002a30a:	3001      	adds	r0, #1
2002a30c:	1bc7      	subs	r7, r0, r7
2002a30e:	2f0a      	cmp	r7, #10
2002a310:	6020      	str	r0, [r4, #0]
2002a312:	dde9      	ble.n	2002a2e8 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x50>
2002a314:	1bf6      	subs	r6, r6, r7
2002a316:	4546      	cmp	r6, r8
2002a318:	d112      	bne.n	2002a340 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0xa8>
2002a31a:	9b03      	ldr	r3, [sp, #12]
2002a31c:	b983      	cbnz	r3, 2002a340 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0xa8>
2002a31e:	4642      	mov	r2, r8
2002a320:	f8dd 1458 	ldr.w	r1, [sp, #1112]	@ 0x458
2002a324:	f000 fb6a 	bl	2002a9fc <memcmp>
2002a328:	2800      	cmp	r0, #0
2002a32a:	d0c7      	beq.n	2002a2bc <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x24>
2002a32c:	4d45      	ldr	r5, [pc, #276]	@ (2002a444 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x1ac>)
2002a32e:	e7c5      	b.n	2002a2bc <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x24>
2002a330:	4298      	cmp	r0, r3
2002a332:	d2d9      	bcs.n	2002a2e8 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x50>
2002a334:	2aff      	cmp	r2, #255	@ 0xff
2002a336:	f100 0001 	add.w	r0, r0, #1
2002a33a:	d1d5      	bne.n	2002a2e8 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x50>
2002a33c:	6020      	str	r0, [r4, #0]
2002a33e:	e7e2      	b.n	2002a306 <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x6e>
2002a340:	9803      	ldr	r0, [sp, #12]
2002a342:	f7fb fe65 	bl	20026010 <mbedtls_md_info_from_type>
2002a346:	2800      	cmp	r0, #0
2002a348:	d0b7      	beq.n	2002a2ba <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x22>
2002a34a:	f7fb fe6d 	bl	20026028 <mbedtls_md_get_size>
2002a34e:	f8d4 a000 	ldr.w	sl, [r4]
2002a352:	af05      	add	r7, sp, #20
2002a354:	eb0a 0806 	add.w	r8, sl, r6
2002a358:	4681      	mov	r9, r0
2002a35a:	2330      	movs	r3, #48	@ 0x30
2002a35c:	463a      	mov	r2, r7
2002a35e:	4641      	mov	r1, r8
2002a360:	4620      	mov	r0, r4
2002a362:	f7fd fb95 	bl	20027a90 <mbedtls_asn1_get_tag>
2002a366:	2800      	cmp	r0, #0
2002a368:	d1e0      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a36a:	f8d4 b000 	ldr.w	fp, [r4]
2002a36e:	f10a 0a02 	add.w	sl, sl, #2
2002a372:	45d3      	cmp	fp, sl
2002a374:	d1da      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a376:	683b      	ldr	r3, [r7, #0]
2002a378:	3302      	adds	r3, #2
2002a37a:	42b3      	cmp	r3, r6
2002a37c:	d1d6      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a37e:	2330      	movs	r3, #48	@ 0x30
2002a380:	463a      	mov	r2, r7
2002a382:	4641      	mov	r1, r8
2002a384:	4620      	mov	r0, r4
2002a386:	f7fd fb83 	bl	20027a90 <mbedtls_asn1_get_tag>
2002a38a:	2800      	cmp	r0, #0
2002a38c:	d1ce      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a38e:	f8d4 a000 	ldr.w	sl, [r4]
2002a392:	f10b 0b02 	add.w	fp, fp, #2
2002a396:	45da      	cmp	sl, fp
2002a398:	d1c8      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a39a:	683b      	ldr	r3, [r7, #0]
2002a39c:	3306      	adds	r3, #6
2002a39e:	444b      	add	r3, r9
2002a3a0:	42b3      	cmp	r3, r6
2002a3a2:	d1c3      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3a4:	2306      	movs	r3, #6
2002a3a6:	4641      	mov	r1, r8
2002a3a8:	4620      	mov	r0, r4
2002a3aa:	aa08      	add	r2, sp, #32
2002a3ac:	ae07      	add	r6, sp, #28
2002a3ae:	f7fd fb6f 	bl	20027a90 <mbedtls_asn1_get_tag>
2002a3b2:	2800      	cmp	r0, #0
2002a3b4:	d1ba      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3b6:	6823      	ldr	r3, [r4, #0]
2002a3b8:	f10a 0a02 	add.w	sl, sl, #2
2002a3bc:	4553      	cmp	r3, sl
2002a3be:	d1b5      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3c0:	9a08      	ldr	r2, [sp, #32]
2002a3c2:	f10d 0a13 	add.w	sl, sp, #19
2002a3c6:	9309      	str	r3, [sp, #36]	@ 0x24
2002a3c8:	4651      	mov	r1, sl
2002a3ca:	4413      	add	r3, r2
2002a3cc:	4630      	mov	r0, r6
2002a3ce:	6023      	str	r3, [r4, #0]
2002a3d0:	f7ff f86a 	bl	200294a8 <mbedtls_oid_get_md_alg>
2002a3d4:	2800      	cmp	r0, #0
2002a3d6:	d1a9      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3d8:	f89d 3013 	ldrb.w	r3, [sp, #19]
2002a3dc:	9a03      	ldr	r2, [sp, #12]
2002a3de:	4293      	cmp	r3, r2
2002a3e0:	d1a4      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3e2:	2305      	movs	r3, #5
2002a3e4:	463a      	mov	r2, r7
2002a3e6:	4641      	mov	r1, r8
2002a3e8:	4620      	mov	r0, r4
2002a3ea:	f8d4 a000 	ldr.w	sl, [r4]
2002a3ee:	f7fd fb4f 	bl	20027a90 <mbedtls_asn1_get_tag>
2002a3f2:	2800      	cmp	r0, #0
2002a3f4:	d19a      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a3f6:	6826      	ldr	r6, [r4, #0]
2002a3f8:	f10a 0a02 	add.w	sl, sl, #2
2002a3fc:	4556      	cmp	r6, sl
2002a3fe:	d195      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a400:	2304      	movs	r3, #4
2002a402:	463a      	mov	r2, r7
2002a404:	4641      	mov	r1, r8
2002a406:	4620      	mov	r0, r4
2002a408:	f7fd fb42 	bl	20027a90 <mbedtls_asn1_get_tag>
2002a40c:	2800      	cmp	r0, #0
2002a40e:	d18d      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a410:	6824      	ldr	r4, [r4, #0]
2002a412:	3602      	adds	r6, #2
2002a414:	42b4      	cmp	r4, r6
2002a416:	d189      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a418:	683b      	ldr	r3, [r7, #0]
2002a41a:	454b      	cmp	r3, r9
2002a41c:	d186      	bne.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a41e:	464a      	mov	r2, r9
2002a420:	4620      	mov	r0, r4
2002a422:	f8dd 1458 	ldr.w	r1, [sp, #1112]	@ 0x458
2002a426:	f000 fae9 	bl	2002a9fc <memcmp>
2002a42a:	2800      	cmp	r0, #0
2002a42c:	f47f af7e 	bne.w	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a430:	444c      	add	r4, r9
2002a432:	45a0      	cmp	r8, r4
2002a434:	f43f af42 	beq.w	2002a2bc <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x24>
2002a438:	e778      	b.n	2002a32c <mbedtls_rsa_rsassa_pkcs1_v15_verify+0x94>
2002a43a:	bf00      	nop
2002a43c:	ffffbf80 	.word	0xffffbf80
2002a440:	ffffbf00 	.word	0xffffbf00
2002a444:	ffffbc80 	.word	0xffffbc80

2002a448 <mbedtls_rsa_pkcs1_verify>:
2002a448:	b430      	push	{r4, r5}
2002a44a:	f8d0 50a4 	ldr.w	r5, [r0, #164]	@ 0xa4
2002a44e:	f89d 4008 	ldrb.w	r4, [sp, #8]
2002a452:	b91d      	cbnz	r5, 2002a45c <mbedtls_rsa_pkcs1_verify+0x14>
2002a454:	9402      	str	r4, [sp, #8]
2002a456:	bc30      	pop	{r4, r5}
2002a458:	f7ff bf1e 	b.w	2002a298 <mbedtls_rsa_rsassa_pkcs1_v15_verify>
2002a45c:	4801      	ldr	r0, [pc, #4]	@ (2002a464 <mbedtls_rsa_pkcs1_verify+0x1c>)
2002a45e:	bc30      	pop	{r4, r5}
2002a460:	4770      	bx	lr
2002a462:	bf00      	nop
2002a464:	ffffbf00 	.word	0xffffbf00

2002a468 <mbedtls_rsa_free>:
2002a468:	b510      	push	{r4, lr}
2002a46a:	4604      	mov	r4, r0
2002a46c:	308c      	adds	r0, #140	@ 0x8c
2002a46e:	f7fd fd44 	bl	20027efa <mbedtls_mpi_free>
2002a472:	f104 0098 	add.w	r0, r4, #152	@ 0x98
2002a476:	f7fd fd40 	bl	20027efa <mbedtls_mpi_free>
2002a47a:	f104 0080 	add.w	r0, r4, #128	@ 0x80
2002a47e:	f7fd fd3c 	bl	20027efa <mbedtls_mpi_free>
2002a482:	f104 0074 	add.w	r0, r4, #116	@ 0x74
2002a486:	f7fd fd38 	bl	20027efa <mbedtls_mpi_free>
2002a48a:	f104 0068 	add.w	r0, r4, #104	@ 0x68
2002a48e:	f7fd fd34 	bl	20027efa <mbedtls_mpi_free>
2002a492:	f104 005c 	add.w	r0, r4, #92	@ 0x5c
2002a496:	f7fd fd30 	bl	20027efa <mbedtls_mpi_free>
2002a49a:	f104 0050 	add.w	r0, r4, #80	@ 0x50
2002a49e:	f7fd fd2c 	bl	20027efa <mbedtls_mpi_free>
2002a4a2:	f104 0044 	add.w	r0, r4, #68	@ 0x44
2002a4a6:	f7fd fd28 	bl	20027efa <mbedtls_mpi_free>
2002a4aa:	f104 0038 	add.w	r0, r4, #56	@ 0x38
2002a4ae:	f7fd fd24 	bl	20027efa <mbedtls_mpi_free>
2002a4b2:	f104 002c 	add.w	r0, r4, #44	@ 0x2c
2002a4b6:	f7fd fd20 	bl	20027efa <mbedtls_mpi_free>
2002a4ba:	f104 0020 	add.w	r0, r4, #32
2002a4be:	f7fd fd1c 	bl	20027efa <mbedtls_mpi_free>
2002a4c2:	f104 0014 	add.w	r0, r4, #20
2002a4c6:	f7fd fd18 	bl	20027efa <mbedtls_mpi_free>
2002a4ca:	f104 0008 	add.w	r0, r4, #8
2002a4ce:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002a4d2:	f7fd bd12 	b.w	20027efa <mbedtls_mpi_free>
	...

2002a4d8 <__aeabi_uldivmod>:
2002a4d8:	b953      	cbnz	r3, 2002a4f0 <__aeabi_uldivmod+0x18>
2002a4da:	b94a      	cbnz	r2, 2002a4f0 <__aeabi_uldivmod+0x18>
2002a4dc:	2900      	cmp	r1, #0
2002a4de:	bf08      	it	eq
2002a4e0:	2800      	cmpeq	r0, #0
2002a4e2:	bf1c      	itt	ne
2002a4e4:	f04f 31ff 	movne.w	r1, #4294967295
2002a4e8:	f04f 30ff 	movne.w	r0, #4294967295
2002a4ec:	f000 b9b2 	b.w	2002a854 <__aeabi_idiv0>
2002a4f0:	f1ad 0c08 	sub.w	ip, sp, #8
2002a4f4:	e96d ce04 	strd	ip, lr, [sp, #-16]!
2002a4f8:	f000 f806 	bl	2002a508 <__udivmoddi4>
2002a4fc:	f8dd e004 	ldr.w	lr, [sp, #4]
2002a500:	e9dd 2302 	ldrd	r2, r3, [sp, #8]
2002a504:	b004      	add	sp, #16
2002a506:	4770      	bx	lr

2002a508 <__udivmoddi4>:
2002a508:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002a50c:	468c      	mov	ip, r1
2002a50e:	9e09      	ldr	r6, [sp, #36]	@ 0x24
2002a510:	4604      	mov	r4, r0
2002a512:	460f      	mov	r7, r1
2002a514:	2b00      	cmp	r3, #0
2002a516:	d148      	bne.n	2002a5aa <__udivmoddi4+0xa2>
2002a518:	428a      	cmp	r2, r1
2002a51a:	4615      	mov	r5, r2
2002a51c:	d95e      	bls.n	2002a5dc <__udivmoddi4+0xd4>
2002a51e:	fab2 f382 	clz	r3, r2
2002a522:	b13b      	cbz	r3, 2002a534 <__udivmoddi4+0x2c>
2002a524:	f1c3 0220 	rsb	r2, r3, #32
2002a528:	409f      	lsls	r7, r3
2002a52a:	409d      	lsls	r5, r3
2002a52c:	409c      	lsls	r4, r3
2002a52e:	fa20 f202 	lsr.w	r2, r0, r2
2002a532:	4317      	orrs	r7, r2
2002a534:	ea4f 4e15 	mov.w	lr, r5, lsr #16
2002a538:	fa1f fc85 	uxth.w	ip, r5
2002a53c:	0c22      	lsrs	r2, r4, #16
2002a53e:	fbb7 f1fe 	udiv	r1, r7, lr
2002a542:	fb0e 7711 	mls	r7, lr, r1, r7
2002a546:	fb01 f00c 	mul.w	r0, r1, ip
2002a54a:	ea42 4207 	orr.w	r2, r2, r7, lsl #16
2002a54e:	4290      	cmp	r0, r2
2002a550:	d907      	bls.n	2002a562 <__udivmoddi4+0x5a>
2002a552:	18aa      	adds	r2, r5, r2
2002a554:	f101 37ff 	add.w	r7, r1, #4294967295
2002a558:	d202      	bcs.n	2002a560 <__udivmoddi4+0x58>
2002a55a:	4290      	cmp	r0, r2
2002a55c:	f200 8158 	bhi.w	2002a810 <__udivmoddi4+0x308>
2002a560:	4639      	mov	r1, r7
2002a562:	1a12      	subs	r2, r2, r0
2002a564:	b2a4      	uxth	r4, r4
2002a566:	fbb2 f0fe 	udiv	r0, r2, lr
2002a56a:	fb0e 2210 	mls	r2, lr, r0, r2
2002a56e:	fb00 fc0c 	mul.w	ip, r0, ip
2002a572:	ea44 4402 	orr.w	r4, r4, r2, lsl #16
2002a576:	45a4      	cmp	ip, r4
2002a578:	d90b      	bls.n	2002a592 <__udivmoddi4+0x8a>
2002a57a:	192c      	adds	r4, r5, r4
2002a57c:	f100 32ff 	add.w	r2, r0, #4294967295
2002a580:	bf2c      	ite	cs
2002a582:	2701      	movcs	r7, #1
2002a584:	2700      	movcc	r7, #0
2002a586:	45a4      	cmp	ip, r4
2002a588:	d902      	bls.n	2002a590 <__udivmoddi4+0x88>
2002a58a:	2f00      	cmp	r7, #0
2002a58c:	f000 8143 	beq.w	2002a816 <__udivmoddi4+0x30e>
2002a590:	4610      	mov	r0, r2
2002a592:	ea40 4001 	orr.w	r0, r0, r1, lsl #16
2002a596:	eba4 040c 	sub.w	r4, r4, ip
2002a59a:	2100      	movs	r1, #0
2002a59c:	b11e      	cbz	r6, 2002a5a6 <__udivmoddi4+0x9e>
2002a59e:	40dc      	lsrs	r4, r3
2002a5a0:	2300      	movs	r3, #0
2002a5a2:	e9c6 4300 	strd	r4, r3, [r6]
2002a5a6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002a5aa:	428b      	cmp	r3, r1
2002a5ac:	d906      	bls.n	2002a5bc <__udivmoddi4+0xb4>
2002a5ae:	b10e      	cbz	r6, 2002a5b4 <__udivmoddi4+0xac>
2002a5b0:	e9c6 0100 	strd	r0, r1, [r6]
2002a5b4:	2100      	movs	r1, #0
2002a5b6:	4608      	mov	r0, r1
2002a5b8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002a5bc:	fab3 f183 	clz	r1, r3
2002a5c0:	2900      	cmp	r1, #0
2002a5c2:	d151      	bne.n	2002a668 <__udivmoddi4+0x160>
2002a5c4:	4563      	cmp	r3, ip
2002a5c6:	f0c0 8116 	bcc.w	2002a7f6 <__udivmoddi4+0x2ee>
2002a5ca:	4282      	cmp	r2, r0
2002a5cc:	f240 8113 	bls.w	2002a7f6 <__udivmoddi4+0x2ee>
2002a5d0:	4608      	mov	r0, r1
2002a5d2:	2e00      	cmp	r6, #0
2002a5d4:	d0e7      	beq.n	2002a5a6 <__udivmoddi4+0x9e>
2002a5d6:	e9c6 4700 	strd	r4, r7, [r6]
2002a5da:	e7e4      	b.n	2002a5a6 <__udivmoddi4+0x9e>
2002a5dc:	2a00      	cmp	r2, #0
2002a5de:	f000 80af 	beq.w	2002a740 <__udivmoddi4+0x238>
2002a5e2:	fab2 f382 	clz	r3, r2
2002a5e6:	2b00      	cmp	r3, #0
2002a5e8:	f040 80c2 	bne.w	2002a770 <__udivmoddi4+0x268>
2002a5ec:	1a8a      	subs	r2, r1, r2
2002a5ee:	ea4f 4e15 	mov.w	lr, r5, lsr #16
2002a5f2:	b2af      	uxth	r7, r5
2002a5f4:	2101      	movs	r1, #1
2002a5f6:	0c20      	lsrs	r0, r4, #16
2002a5f8:	fbb2 fcfe 	udiv	ip, r2, lr
2002a5fc:	fb0e 221c 	mls	r2, lr, ip, r2
2002a600:	ea40 4202 	orr.w	r2, r0, r2, lsl #16
2002a604:	fb07 f00c 	mul.w	r0, r7, ip
2002a608:	4290      	cmp	r0, r2
2002a60a:	d90e      	bls.n	2002a62a <__udivmoddi4+0x122>
2002a60c:	18aa      	adds	r2, r5, r2
2002a60e:	f10c 38ff 	add.w	r8, ip, #4294967295
2002a612:	bf2c      	ite	cs
2002a614:	f04f 0901 	movcs.w	r9, #1
2002a618:	f04f 0900 	movcc.w	r9, #0
2002a61c:	4290      	cmp	r0, r2
2002a61e:	d903      	bls.n	2002a628 <__udivmoddi4+0x120>
2002a620:	f1b9 0f00 	cmp.w	r9, #0
2002a624:	f000 80f0 	beq.w	2002a808 <__udivmoddi4+0x300>
2002a628:	46c4      	mov	ip, r8
2002a62a:	1a12      	subs	r2, r2, r0
2002a62c:	b2a4      	uxth	r4, r4
2002a62e:	fbb2 f0fe 	udiv	r0, r2, lr
2002a632:	fb0e 2210 	mls	r2, lr, r0, r2
2002a636:	fb00 f707 	mul.w	r7, r0, r7
2002a63a:	ea44 4402 	orr.w	r4, r4, r2, lsl #16
2002a63e:	42a7      	cmp	r7, r4
2002a640:	d90e      	bls.n	2002a660 <__udivmoddi4+0x158>
2002a642:	192c      	adds	r4, r5, r4
2002a644:	f100 32ff 	add.w	r2, r0, #4294967295
2002a648:	bf2c      	ite	cs
2002a64a:	f04f 0e01 	movcs.w	lr, #1
2002a64e:	f04f 0e00 	movcc.w	lr, #0
2002a652:	42a7      	cmp	r7, r4
2002a654:	d903      	bls.n	2002a65e <__udivmoddi4+0x156>
2002a656:	f1be 0f00 	cmp.w	lr, #0
2002a65a:	f000 80d2 	beq.w	2002a802 <__udivmoddi4+0x2fa>
2002a65e:	4610      	mov	r0, r2
2002a660:	1be4      	subs	r4, r4, r7
2002a662:	ea40 400c 	orr.w	r0, r0, ip, lsl #16
2002a666:	e799      	b.n	2002a59c <__udivmoddi4+0x94>
2002a668:	f1c1 0520 	rsb	r5, r1, #32
2002a66c:	408b      	lsls	r3, r1
2002a66e:	fa0c f401 	lsl.w	r4, ip, r1
2002a672:	fa00 f901 	lsl.w	r9, r0, r1
2002a676:	fa22 f705 	lsr.w	r7, r2, r5
2002a67a:	fa2c fc05 	lsr.w	ip, ip, r5
2002a67e:	408a      	lsls	r2, r1
2002a680:	431f      	orrs	r7, r3
2002a682:	fa20 f305 	lsr.w	r3, r0, r5
2002a686:	0c38      	lsrs	r0, r7, #16
2002a688:	4323      	orrs	r3, r4
2002a68a:	fa1f fe87 	uxth.w	lr, r7
2002a68e:	0c1c      	lsrs	r4, r3, #16
2002a690:	fbbc f8f0 	udiv	r8, ip, r0
2002a694:	fb00 cc18 	mls	ip, r0, r8, ip
2002a698:	ea44 440c 	orr.w	r4, r4, ip, lsl #16
2002a69c:	fb08 fc0e 	mul.w	ip, r8, lr
2002a6a0:	45a4      	cmp	ip, r4
2002a6a2:	d90e      	bls.n	2002a6c2 <__udivmoddi4+0x1ba>
2002a6a4:	193c      	adds	r4, r7, r4
2002a6a6:	f108 3aff 	add.w	sl, r8, #4294967295
2002a6aa:	bf2c      	ite	cs
2002a6ac:	f04f 0b01 	movcs.w	fp, #1
2002a6b0:	f04f 0b00 	movcc.w	fp, #0
2002a6b4:	45a4      	cmp	ip, r4
2002a6b6:	d903      	bls.n	2002a6c0 <__udivmoddi4+0x1b8>
2002a6b8:	f1bb 0f00 	cmp.w	fp, #0
2002a6bc:	f000 80b8 	beq.w	2002a830 <__udivmoddi4+0x328>
2002a6c0:	46d0      	mov	r8, sl
2002a6c2:	eba4 040c 	sub.w	r4, r4, ip
2002a6c6:	fa1f fc83 	uxth.w	ip, r3
2002a6ca:	fbb4 f3f0 	udiv	r3, r4, r0
2002a6ce:	fb00 4413 	mls	r4, r0, r3, r4
2002a6d2:	fb03 fe0e 	mul.w	lr, r3, lr
2002a6d6:	ea4c 4404 	orr.w	r4, ip, r4, lsl #16
2002a6da:	45a6      	cmp	lr, r4
2002a6dc:	d90e      	bls.n	2002a6fc <__udivmoddi4+0x1f4>
2002a6de:	193c      	adds	r4, r7, r4
2002a6e0:	f103 30ff 	add.w	r0, r3, #4294967295
2002a6e4:	bf2c      	ite	cs
2002a6e6:	f04f 0c01 	movcs.w	ip, #1
2002a6ea:	f04f 0c00 	movcc.w	ip, #0
2002a6ee:	45a6      	cmp	lr, r4
2002a6f0:	d903      	bls.n	2002a6fa <__udivmoddi4+0x1f2>
2002a6f2:	f1bc 0f00 	cmp.w	ip, #0
2002a6f6:	f000 809f 	beq.w	2002a838 <__udivmoddi4+0x330>
2002a6fa:	4603      	mov	r3, r0
2002a6fc:	ea43 4008 	orr.w	r0, r3, r8, lsl #16
2002a700:	eba4 040e 	sub.w	r4, r4, lr
2002a704:	fba0 ec02 	umull	lr, ip, r0, r2
2002a708:	4564      	cmp	r4, ip
2002a70a:	4673      	mov	r3, lr
2002a70c:	46e0      	mov	r8, ip
2002a70e:	d302      	bcc.n	2002a716 <__udivmoddi4+0x20e>
2002a710:	d107      	bne.n	2002a722 <__udivmoddi4+0x21a>
2002a712:	45f1      	cmp	r9, lr
2002a714:	d205      	bcs.n	2002a722 <__udivmoddi4+0x21a>
2002a716:	ebbe 0302 	subs.w	r3, lr, r2
2002a71a:	eb6c 0c07 	sbc.w	ip, ip, r7
2002a71e:	3801      	subs	r0, #1
2002a720:	46e0      	mov	r8, ip
2002a722:	b15e      	cbz	r6, 2002a73c <__udivmoddi4+0x234>
2002a724:	ebb9 0203 	subs.w	r2, r9, r3
2002a728:	eb64 0408 	sbc.w	r4, r4, r8
2002a72c:	fa04 f505 	lsl.w	r5, r4, r5
2002a730:	fa22 f301 	lsr.w	r3, r2, r1
2002a734:	40cc      	lsrs	r4, r1
2002a736:	431d      	orrs	r5, r3
2002a738:	e9c6 5400 	strd	r5, r4, [r6]
2002a73c:	2100      	movs	r1, #0
2002a73e:	e732      	b.n	2002a5a6 <__udivmoddi4+0x9e>
2002a740:	0842      	lsrs	r2, r0, #1
2002a742:	462f      	mov	r7, r5
2002a744:	084b      	lsrs	r3, r1, #1
2002a746:	46ac      	mov	ip, r5
2002a748:	ea42 72c1 	orr.w	r2, r2, r1, lsl #31
2002a74c:	46ae      	mov	lr, r5
2002a74e:	07c4      	lsls	r4, r0, #31
2002a750:	0c11      	lsrs	r1, r2, #16
2002a752:	b292      	uxth	r2, r2
2002a754:	ea41 4103 	orr.w	r1, r1, r3, lsl #16
2002a758:	ea42 4201 	orr.w	r2, r2, r1, lsl #16
2002a75c:	fbb1 f1f5 	udiv	r1, r1, r5
2002a760:	fbb3 f0f5 	udiv	r0, r3, r5
2002a764:	231f      	movs	r3, #31
2002a766:	eba2 020c 	sub.w	r2, r2, ip
2002a76a:	ea41 4100 	orr.w	r1, r1, r0, lsl #16
2002a76e:	e742      	b.n	2002a5f6 <__udivmoddi4+0xee>
2002a770:	409d      	lsls	r5, r3
2002a772:	f1c3 0220 	rsb	r2, r3, #32
2002a776:	4099      	lsls	r1, r3
2002a778:	409c      	lsls	r4, r3
2002a77a:	fa2c fc02 	lsr.w	ip, ip, r2
2002a77e:	ea4f 4e15 	mov.w	lr, r5, lsr #16
2002a782:	fa20 f202 	lsr.w	r2, r0, r2
2002a786:	b2af      	uxth	r7, r5
2002a788:	fbbc f8fe 	udiv	r8, ip, lr
2002a78c:	430a      	orrs	r2, r1
2002a78e:	fb0e cc18 	mls	ip, lr, r8, ip
2002a792:	0c11      	lsrs	r1, r2, #16
2002a794:	ea41 410c 	orr.w	r1, r1, ip, lsl #16
2002a798:	fb08 fc07 	mul.w	ip, r8, r7
2002a79c:	458c      	cmp	ip, r1
2002a79e:	d950      	bls.n	2002a842 <__udivmoddi4+0x33a>
2002a7a0:	1869      	adds	r1, r5, r1
2002a7a2:	f108 30ff 	add.w	r0, r8, #4294967295
2002a7a6:	bf2c      	ite	cs
2002a7a8:	f04f 0901 	movcs.w	r9, #1
2002a7ac:	f04f 0900 	movcc.w	r9, #0
2002a7b0:	458c      	cmp	ip, r1
2002a7b2:	d902      	bls.n	2002a7ba <__udivmoddi4+0x2b2>
2002a7b4:	f1b9 0f00 	cmp.w	r9, #0
2002a7b8:	d030      	beq.n	2002a81c <__udivmoddi4+0x314>
2002a7ba:	eba1 010c 	sub.w	r1, r1, ip
2002a7be:	fbb1 f8fe 	udiv	r8, r1, lr
2002a7c2:	fb08 fc07 	mul.w	ip, r8, r7
2002a7c6:	fb0e 1118 	mls	r1, lr, r8, r1
2002a7ca:	b292      	uxth	r2, r2
2002a7cc:	ea42 4201 	orr.w	r2, r2, r1, lsl #16
2002a7d0:	4562      	cmp	r2, ip
2002a7d2:	d234      	bcs.n	2002a83e <__udivmoddi4+0x336>
2002a7d4:	18aa      	adds	r2, r5, r2
2002a7d6:	f108 31ff 	add.w	r1, r8, #4294967295
2002a7da:	bf2c      	ite	cs
2002a7dc:	f04f 0901 	movcs.w	r9, #1
2002a7e0:	f04f 0900 	movcc.w	r9, #0
2002a7e4:	4562      	cmp	r2, ip
2002a7e6:	d2be      	bcs.n	2002a766 <__udivmoddi4+0x25e>
2002a7e8:	f1b9 0f00 	cmp.w	r9, #0
2002a7ec:	d1bb      	bne.n	2002a766 <__udivmoddi4+0x25e>
2002a7ee:	f1a8 0102 	sub.w	r1, r8, #2
2002a7f2:	442a      	add	r2, r5
2002a7f4:	e7b7      	b.n	2002a766 <__udivmoddi4+0x25e>
2002a7f6:	1a84      	subs	r4, r0, r2
2002a7f8:	eb6c 0203 	sbc.w	r2, ip, r3
2002a7fc:	2001      	movs	r0, #1
2002a7fe:	4617      	mov	r7, r2
2002a800:	e6e7      	b.n	2002a5d2 <__udivmoddi4+0xca>
2002a802:	442c      	add	r4, r5
2002a804:	3802      	subs	r0, #2
2002a806:	e72b      	b.n	2002a660 <__udivmoddi4+0x158>
2002a808:	f1ac 0c02 	sub.w	ip, ip, #2
2002a80c:	442a      	add	r2, r5
2002a80e:	e70c      	b.n	2002a62a <__udivmoddi4+0x122>
2002a810:	3902      	subs	r1, #2
2002a812:	442a      	add	r2, r5
2002a814:	e6a5      	b.n	2002a562 <__udivmoddi4+0x5a>
2002a816:	442c      	add	r4, r5
2002a818:	3802      	subs	r0, #2
2002a81a:	e6ba      	b.n	2002a592 <__udivmoddi4+0x8a>
2002a81c:	eba5 0c0c 	sub.w	ip, r5, ip
2002a820:	f1a8 0002 	sub.w	r0, r8, #2
2002a824:	4461      	add	r1, ip
2002a826:	fbb1 f8fe 	udiv	r8, r1, lr
2002a82a:	fb08 fc07 	mul.w	ip, r8, r7
2002a82e:	e7ca      	b.n	2002a7c6 <__udivmoddi4+0x2be>
2002a830:	f1a8 0802 	sub.w	r8, r8, #2
2002a834:	443c      	add	r4, r7
2002a836:	e744      	b.n	2002a6c2 <__udivmoddi4+0x1ba>
2002a838:	3b02      	subs	r3, #2
2002a83a:	443c      	add	r4, r7
2002a83c:	e75e      	b.n	2002a6fc <__udivmoddi4+0x1f4>
2002a83e:	4641      	mov	r1, r8
2002a840:	e791      	b.n	2002a766 <__udivmoddi4+0x25e>
2002a842:	eba1 010c 	sub.w	r1, r1, ip
2002a846:	4640      	mov	r0, r8
2002a848:	fbb1 f8fe 	udiv	r8, r1, lr
2002a84c:	fb08 fc07 	mul.w	ip, r8, r7
2002a850:	e7b9      	b.n	2002a7c6 <__udivmoddi4+0x2be>
2002a852:	bf00      	nop

2002a854 <__aeabi_idiv0>:
2002a854:	4770      	bx	lr
2002a856:	bf00      	nop

2002a858 <calloc>:
2002a858:	4b02      	ldr	r3, [pc, #8]	@ (2002a864 <calloc+0xc>)
2002a85a:	460a      	mov	r2, r1
2002a85c:	4601      	mov	r1, r0
2002a85e:	6818      	ldr	r0, [r3, #0]
2002a860:	f000 b802 	b.w	2002a868 <_calloc_r>
2002a864:	200449a0 	.word	0x200449a0

2002a868 <_calloc_r>:
2002a868:	b570      	push	{r4, r5, r6, lr}
2002a86a:	fba1 5402 	umull	r5, r4, r1, r2
2002a86e:	b934      	cbnz	r4, 2002a87e <_calloc_r+0x16>
2002a870:	4629      	mov	r1, r5
2002a872:	f000 f837 	bl	2002a8e4 <_malloc_r>
2002a876:	4606      	mov	r6, r0
2002a878:	b928      	cbnz	r0, 2002a886 <_calloc_r+0x1e>
2002a87a:	4630      	mov	r0, r6
2002a87c:	bd70      	pop	{r4, r5, r6, pc}
2002a87e:	220c      	movs	r2, #12
2002a880:	2600      	movs	r6, #0
2002a882:	6002      	str	r2, [r0, #0]
2002a884:	e7f9      	b.n	2002a87a <_calloc_r+0x12>
2002a886:	462a      	mov	r2, r5
2002a888:	4621      	mov	r1, r4
2002a88a:	f000 f8c7 	bl	2002aa1c <memset>
2002a88e:	e7f4      	b.n	2002a87a <_calloc_r+0x12>

2002a890 <free>:
2002a890:	4b02      	ldr	r3, [pc, #8]	@ (2002a89c <free+0xc>)
2002a892:	4601      	mov	r1, r0
2002a894:	6818      	ldr	r0, [r3, #0]
2002a896:	f000 b8e9 	b.w	2002aa6c <_free_r>
2002a89a:	bf00      	nop
2002a89c:	200449a0 	.word	0x200449a0

2002a8a0 <sbrk_aligned>:
2002a8a0:	b570      	push	{r4, r5, r6, lr}
2002a8a2:	4e0f      	ldr	r6, [pc, #60]	@ (2002a8e0 <sbrk_aligned+0x40>)
2002a8a4:	460c      	mov	r4, r1
2002a8a6:	4605      	mov	r5, r0
2002a8a8:	6831      	ldr	r1, [r6, #0]
2002a8aa:	b911      	cbnz	r1, 2002a8b2 <sbrk_aligned+0x12>
2002a8ac:	f000 f8be 	bl	2002aa2c <_sbrk_r>
2002a8b0:	6030      	str	r0, [r6, #0]
2002a8b2:	4621      	mov	r1, r4
2002a8b4:	4628      	mov	r0, r5
2002a8b6:	f000 f8b9 	bl	2002aa2c <_sbrk_r>
2002a8ba:	1c43      	adds	r3, r0, #1
2002a8bc:	d103      	bne.n	2002a8c6 <sbrk_aligned+0x26>
2002a8be:	f04f 34ff 	mov.w	r4, #4294967295
2002a8c2:	4620      	mov	r0, r4
2002a8c4:	bd70      	pop	{r4, r5, r6, pc}
2002a8c6:	1cc4      	adds	r4, r0, #3
2002a8c8:	f024 0403 	bic.w	r4, r4, #3
2002a8cc:	42a0      	cmp	r0, r4
2002a8ce:	d0f8      	beq.n	2002a8c2 <sbrk_aligned+0x22>
2002a8d0:	1a21      	subs	r1, r4, r0
2002a8d2:	4628      	mov	r0, r5
2002a8d4:	f000 f8aa 	bl	2002aa2c <_sbrk_r>
2002a8d8:	3001      	adds	r0, #1
2002a8da:	d1f2      	bne.n	2002a8c2 <sbrk_aligned+0x22>
2002a8dc:	e7ef      	b.n	2002a8be <sbrk_aligned+0x1e>
2002a8de:	bf00      	nop
2002a8e0:	2004d094 	.word	0x2004d094

2002a8e4 <_malloc_r>:
2002a8e4:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
2002a8e8:	1ccd      	adds	r5, r1, #3
2002a8ea:	4606      	mov	r6, r0
2002a8ec:	f025 0503 	bic.w	r5, r5, #3
2002a8f0:	3508      	adds	r5, #8
2002a8f2:	2d0c      	cmp	r5, #12
2002a8f4:	bf38      	it	cc
2002a8f6:	250c      	movcc	r5, #12
2002a8f8:	2d00      	cmp	r5, #0
2002a8fa:	db01      	blt.n	2002a900 <_malloc_r+0x1c>
2002a8fc:	42a9      	cmp	r1, r5
2002a8fe:	d904      	bls.n	2002a90a <_malloc_r+0x26>
2002a900:	230c      	movs	r3, #12
2002a902:	6033      	str	r3, [r6, #0]
2002a904:	2000      	movs	r0, #0
2002a906:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002a90a:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 2002a9e0 <_malloc_r+0xfc>
2002a90e:	f000 f869 	bl	2002a9e4 <__malloc_lock>
2002a912:	f8d8 3000 	ldr.w	r3, [r8]
2002a916:	461c      	mov	r4, r3
2002a918:	bb44      	cbnz	r4, 2002a96c <_malloc_r+0x88>
2002a91a:	4629      	mov	r1, r5
2002a91c:	4630      	mov	r0, r6
2002a91e:	f7ff ffbf 	bl	2002a8a0 <sbrk_aligned>
2002a922:	1c43      	adds	r3, r0, #1
2002a924:	4604      	mov	r4, r0
2002a926:	d158      	bne.n	2002a9da <_malloc_r+0xf6>
2002a928:	f8d8 4000 	ldr.w	r4, [r8]
2002a92c:	4627      	mov	r7, r4
2002a92e:	2f00      	cmp	r7, #0
2002a930:	d143      	bne.n	2002a9ba <_malloc_r+0xd6>
2002a932:	2c00      	cmp	r4, #0
2002a934:	d04b      	beq.n	2002a9ce <_malloc_r+0xea>
2002a936:	6823      	ldr	r3, [r4, #0]
2002a938:	4639      	mov	r1, r7
2002a93a:	4630      	mov	r0, r6
2002a93c:	eb04 0903 	add.w	r9, r4, r3
2002a940:	f000 f874 	bl	2002aa2c <_sbrk_r>
2002a944:	4581      	cmp	r9, r0
2002a946:	d142      	bne.n	2002a9ce <_malloc_r+0xea>
2002a948:	6821      	ldr	r1, [r4, #0]
2002a94a:	4630      	mov	r0, r6
2002a94c:	1a6d      	subs	r5, r5, r1
2002a94e:	4629      	mov	r1, r5
2002a950:	f7ff ffa6 	bl	2002a8a0 <sbrk_aligned>
2002a954:	3001      	adds	r0, #1
2002a956:	d03a      	beq.n	2002a9ce <_malloc_r+0xea>
2002a958:	6823      	ldr	r3, [r4, #0]
2002a95a:	442b      	add	r3, r5
2002a95c:	6023      	str	r3, [r4, #0]
2002a95e:	f8d8 3000 	ldr.w	r3, [r8]
2002a962:	685a      	ldr	r2, [r3, #4]
2002a964:	bb62      	cbnz	r2, 2002a9c0 <_malloc_r+0xdc>
2002a966:	f8c8 7000 	str.w	r7, [r8]
2002a96a:	e00f      	b.n	2002a98c <_malloc_r+0xa8>
2002a96c:	6822      	ldr	r2, [r4, #0]
2002a96e:	1b52      	subs	r2, r2, r5
2002a970:	d420      	bmi.n	2002a9b4 <_malloc_r+0xd0>
2002a972:	2a0b      	cmp	r2, #11
2002a974:	d917      	bls.n	2002a9a6 <_malloc_r+0xc2>
2002a976:	1961      	adds	r1, r4, r5
2002a978:	42a3      	cmp	r3, r4
2002a97a:	6025      	str	r5, [r4, #0]
2002a97c:	bf18      	it	ne
2002a97e:	6059      	strne	r1, [r3, #4]
2002a980:	6863      	ldr	r3, [r4, #4]
2002a982:	bf08      	it	eq
2002a984:	f8c8 1000 	streq.w	r1, [r8]
2002a988:	5162      	str	r2, [r4, r5]
2002a98a:	604b      	str	r3, [r1, #4]
2002a98c:	4630      	mov	r0, r6
2002a98e:	f000 f82f 	bl	2002a9f0 <__malloc_unlock>
2002a992:	f104 000b 	add.w	r0, r4, #11
2002a996:	1d23      	adds	r3, r4, #4
2002a998:	f020 0007 	bic.w	r0, r0, #7
2002a99c:	1ac2      	subs	r2, r0, r3
2002a99e:	bf1c      	itt	ne
2002a9a0:	1a1b      	subne	r3, r3, r0
2002a9a2:	50a3      	strne	r3, [r4, r2]
2002a9a4:	e7af      	b.n	2002a906 <_malloc_r+0x22>
2002a9a6:	6862      	ldr	r2, [r4, #4]
2002a9a8:	42a3      	cmp	r3, r4
2002a9aa:	bf0c      	ite	eq
2002a9ac:	f8c8 2000 	streq.w	r2, [r8]
2002a9b0:	605a      	strne	r2, [r3, #4]
2002a9b2:	e7eb      	b.n	2002a98c <_malloc_r+0xa8>
2002a9b4:	4623      	mov	r3, r4
2002a9b6:	6864      	ldr	r4, [r4, #4]
2002a9b8:	e7ae      	b.n	2002a918 <_malloc_r+0x34>
2002a9ba:	463c      	mov	r4, r7
2002a9bc:	687f      	ldr	r7, [r7, #4]
2002a9be:	e7b6      	b.n	2002a92e <_malloc_r+0x4a>
2002a9c0:	461a      	mov	r2, r3
2002a9c2:	685b      	ldr	r3, [r3, #4]
2002a9c4:	42a3      	cmp	r3, r4
2002a9c6:	d1fb      	bne.n	2002a9c0 <_malloc_r+0xdc>
2002a9c8:	2300      	movs	r3, #0
2002a9ca:	6053      	str	r3, [r2, #4]
2002a9cc:	e7de      	b.n	2002a98c <_malloc_r+0xa8>
2002a9ce:	230c      	movs	r3, #12
2002a9d0:	4630      	mov	r0, r6
2002a9d2:	6033      	str	r3, [r6, #0]
2002a9d4:	f000 f80c 	bl	2002a9f0 <__malloc_unlock>
2002a9d8:	e794      	b.n	2002a904 <_malloc_r+0x20>
2002a9da:	6005      	str	r5, [r0, #0]
2002a9dc:	e7d6      	b.n	2002a98c <_malloc_r+0xa8>
2002a9de:	bf00      	nop
2002a9e0:	2004d098 	.word	0x2004d098

2002a9e4 <__malloc_lock>:
2002a9e4:	4801      	ldr	r0, [pc, #4]	@ (2002a9ec <__malloc_lock+0x8>)
2002a9e6:	f000 b831 	b.w	2002aa4c <__retarget_lock_acquire_recursive>
2002a9ea:	bf00      	nop
2002a9ec:	2004d1d8 	.word	0x2004d1d8

2002a9f0 <__malloc_unlock>:
2002a9f0:	4801      	ldr	r0, [pc, #4]	@ (2002a9f8 <__malloc_unlock+0x8>)
2002a9f2:	f000 b82c 	b.w	2002aa4e <__retarget_lock_release_recursive>
2002a9f6:	bf00      	nop
2002a9f8:	2004d1d8 	.word	0x2004d1d8

2002a9fc <memcmp>:
2002a9fc:	3901      	subs	r1, #1
2002a9fe:	4402      	add	r2, r0
2002aa00:	b510      	push	{r4, lr}
2002aa02:	4290      	cmp	r0, r2
2002aa04:	d101      	bne.n	2002aa0a <memcmp+0xe>
2002aa06:	2000      	movs	r0, #0
2002aa08:	e005      	b.n	2002aa16 <memcmp+0x1a>
2002aa0a:	7803      	ldrb	r3, [r0, #0]
2002aa0c:	f811 4f01 	ldrb.w	r4, [r1, #1]!
2002aa10:	42a3      	cmp	r3, r4
2002aa12:	d001      	beq.n	2002aa18 <memcmp+0x1c>
2002aa14:	1b18      	subs	r0, r3, r4
2002aa16:	bd10      	pop	{r4, pc}
2002aa18:	3001      	adds	r0, #1
2002aa1a:	e7f2      	b.n	2002aa02 <memcmp+0x6>

2002aa1c <memset>:
2002aa1c:	4402      	add	r2, r0
2002aa1e:	4603      	mov	r3, r0
2002aa20:	4293      	cmp	r3, r2
2002aa22:	d100      	bne.n	2002aa26 <memset+0xa>
2002aa24:	4770      	bx	lr
2002aa26:	f803 1b01 	strb.w	r1, [r3], #1
2002aa2a:	e7f9      	b.n	2002aa20 <memset+0x4>

2002aa2c <_sbrk_r>:
2002aa2c:	b538      	push	{r3, r4, r5, lr}
2002aa2e:	2300      	movs	r3, #0
2002aa30:	4d05      	ldr	r5, [pc, #20]	@ (2002aa48 <_sbrk_r+0x1c>)
2002aa32:	4604      	mov	r4, r0
2002aa34:	4608      	mov	r0, r1
2002aa36:	602b      	str	r3, [r5, #0]
2002aa38:	f000 f862 	bl	2002ab00 <_sbrk>
2002aa3c:	1c43      	adds	r3, r0, #1
2002aa3e:	d102      	bne.n	2002aa46 <_sbrk_r+0x1a>
2002aa40:	682b      	ldr	r3, [r5, #0]
2002aa42:	b103      	cbz	r3, 2002aa46 <_sbrk_r+0x1a>
2002aa44:	6023      	str	r3, [r4, #0]
2002aa46:	bd38      	pop	{r3, r4, r5, pc}
2002aa48:	2004d1d4 	.word	0x2004d1d4

2002aa4c <__retarget_lock_acquire_recursive>:
2002aa4c:	4770      	bx	lr

2002aa4e <__retarget_lock_release_recursive>:
2002aa4e:	4770      	bx	lr

2002aa50 <memcpy>:
2002aa50:	440a      	add	r2, r1
2002aa52:	1e43      	subs	r3, r0, #1
2002aa54:	4291      	cmp	r1, r2
2002aa56:	d100      	bne.n	2002aa5a <memcpy+0xa>
2002aa58:	4770      	bx	lr
2002aa5a:	b510      	push	{r4, lr}
2002aa5c:	f811 4b01 	ldrb.w	r4, [r1], #1
2002aa60:	4291      	cmp	r1, r2
2002aa62:	f803 4f01 	strb.w	r4, [r3, #1]!
2002aa66:	d1f9      	bne.n	2002aa5c <memcpy+0xc>
2002aa68:	bd10      	pop	{r4, pc}
	...

2002aa6c <_free_r>:
2002aa6c:	b538      	push	{r3, r4, r5, lr}
2002aa6e:	4605      	mov	r5, r0
2002aa70:	2900      	cmp	r1, #0
2002aa72:	d041      	beq.n	2002aaf8 <_free_r+0x8c>
2002aa74:	f851 3c04 	ldr.w	r3, [r1, #-4]
2002aa78:	1f0c      	subs	r4, r1, #4
2002aa7a:	2b00      	cmp	r3, #0
2002aa7c:	bfb8      	it	lt
2002aa7e:	18e4      	addlt	r4, r4, r3
2002aa80:	f7ff ffb0 	bl	2002a9e4 <__malloc_lock>
2002aa84:	4a1d      	ldr	r2, [pc, #116]	@ (2002aafc <_free_r+0x90>)
2002aa86:	6813      	ldr	r3, [r2, #0]
2002aa88:	b933      	cbnz	r3, 2002aa98 <_free_r+0x2c>
2002aa8a:	6063      	str	r3, [r4, #4]
2002aa8c:	6014      	str	r4, [r2, #0]
2002aa8e:	4628      	mov	r0, r5
2002aa90:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
2002aa94:	f7ff bfac 	b.w	2002a9f0 <__malloc_unlock>
2002aa98:	42a3      	cmp	r3, r4
2002aa9a:	d908      	bls.n	2002aaae <_free_r+0x42>
2002aa9c:	6820      	ldr	r0, [r4, #0]
2002aa9e:	1821      	adds	r1, r4, r0
2002aaa0:	428b      	cmp	r3, r1
2002aaa2:	bf01      	itttt	eq
2002aaa4:	6819      	ldreq	r1, [r3, #0]
2002aaa6:	685b      	ldreq	r3, [r3, #4]
2002aaa8:	1809      	addeq	r1, r1, r0
2002aaaa:	6021      	streq	r1, [r4, #0]
2002aaac:	e7ed      	b.n	2002aa8a <_free_r+0x1e>
2002aaae:	461a      	mov	r2, r3
2002aab0:	685b      	ldr	r3, [r3, #4]
2002aab2:	b10b      	cbz	r3, 2002aab8 <_free_r+0x4c>
2002aab4:	42a3      	cmp	r3, r4
2002aab6:	d9fa      	bls.n	2002aaae <_free_r+0x42>
2002aab8:	6811      	ldr	r1, [r2, #0]
2002aaba:	1850      	adds	r0, r2, r1
2002aabc:	42a0      	cmp	r0, r4
2002aabe:	d10b      	bne.n	2002aad8 <_free_r+0x6c>
2002aac0:	6820      	ldr	r0, [r4, #0]
2002aac2:	4401      	add	r1, r0
2002aac4:	1850      	adds	r0, r2, r1
2002aac6:	6011      	str	r1, [r2, #0]
2002aac8:	4283      	cmp	r3, r0
2002aaca:	d1e0      	bne.n	2002aa8e <_free_r+0x22>
2002aacc:	6818      	ldr	r0, [r3, #0]
2002aace:	685b      	ldr	r3, [r3, #4]
2002aad0:	4408      	add	r0, r1
2002aad2:	6053      	str	r3, [r2, #4]
2002aad4:	6010      	str	r0, [r2, #0]
2002aad6:	e7da      	b.n	2002aa8e <_free_r+0x22>
2002aad8:	d902      	bls.n	2002aae0 <_free_r+0x74>
2002aada:	230c      	movs	r3, #12
2002aadc:	602b      	str	r3, [r5, #0]
2002aade:	e7d6      	b.n	2002aa8e <_free_r+0x22>
2002aae0:	6820      	ldr	r0, [r4, #0]
2002aae2:	1821      	adds	r1, r4, r0
2002aae4:	428b      	cmp	r3, r1
2002aae6:	bf02      	ittt	eq
2002aae8:	6819      	ldreq	r1, [r3, #0]
2002aaea:	685b      	ldreq	r3, [r3, #4]
2002aaec:	1809      	addeq	r1, r1, r0
2002aaee:	6063      	str	r3, [r4, #4]
2002aaf0:	bf08      	it	eq
2002aaf2:	6021      	streq	r1, [r4, #0]
2002aaf4:	6054      	str	r4, [r2, #4]
2002aaf6:	e7ca      	b.n	2002aa8e <_free_r+0x22>
2002aaf8:	bd38      	pop	{r3, r4, r5, pc}
2002aafa:	bf00      	nop
2002aafc:	2004d098 	.word	0x2004d098

2002ab00 <_sbrk>:
2002ab00:	4a05      	ldr	r2, [pc, #20]	@ (2002ab18 <_sbrk+0x18>)
2002ab02:	4603      	mov	r3, r0
2002ab04:	6810      	ldr	r0, [r2, #0]
2002ab06:	b110      	cbz	r0, 2002ab0e <_sbrk+0xe>
2002ab08:	4403      	add	r3, r0
2002ab0a:	6013      	str	r3, [r2, #0]
2002ab0c:	4770      	bx	lr
2002ab0e:	4803      	ldr	r0, [pc, #12]	@ (2002ab1c <_sbrk+0x1c>)
2002ab10:	4403      	add	r3, r0
2002ab12:	6013      	str	r3, [r2, #0]
2002ab14:	4770      	bx	lr
2002ab16:	bf00      	nop
2002ab18:	2004d1dc 	.word	0x2004d1dc
2002ab1c:	20042000 	.word	0x20042000
2002ab20:	50041000 	.word	0x50041000
2002ab24:	00000002 	.word	0x00000002
2002ab28:	10000000 	.word	0x10000000
2002ab2c:	00000004 	.word	0x00000004
2002ab30:	00000000 	.word	0x00000000
2002ab34:	50042000 	.word	0x50042000
2002ab38:	00000002 	.word	0x00000002
2002ab3c:	12000000 	.word	0x12000000
2002ab40:	00000004 	.word	0x00000004
2002ab44:	00000000 	.word	0x00000000
2002ab48:	62636573 	.word	0x62636573
2002ab4c:	20746f6f 	.word	0x20746f6f
2002ab50:	6b676973 	.word	0x6b676973
2002ab54:	70207965 	.word	0x70207965
2002ab58:	65206275 	.word	0x65206275
2002ab5c:	00217272 	.word	0x00217272
2002ab60:	62636573 	.word	0x62636573
2002ab64:	20746f6f 	.word	0x20746f6f
2002ab68:	20676d69 	.word	0x20676d69
2002ab6c:	68736168 	.word	0x68736168
2002ab70:	67697320 	.word	0x67697320
2002ab74:	72726520 	.word	0x72726520
2002ab78:	65730021 	.word	0x65730021
2002ab7c:	6f6f6263 	.word	0x6f6f6263
2002ab80:	78652074 	.word	0x78652074
2002ab84:	20747063 	.word	0x20747063
2002ab88:	6c6c756e 	.word	0x6c6c756e
2002ab8c:	41480021 	.word	0x41480021
2002ab90:	535f4853 	.word	0x535f4853
2002ab94:	49545445 	.word	0x49545445
2002ab98:	253d474e 	.word	0x253d474e
2002ab9c:	0a583830 	.word	0x0a583830
2002aba0:	616f4c00 	.word	0x616f4c00
2002aba4:	56492064 	.word	0x56492064
2002aba8:	646e6120 	.word	0x646e6120
2002abac:	6e656c20 	.word	0x6e656c20
2002abb0:	20687467 	.word	0x20687467
2002abb4:	48534148 	.word	0x48534148
2002abb8:	5445535f 	.word	0x5445535f
2002abbc:	474e4954 	.word	0x474e4954
2002abc0:	3830253d 	.word	0x3830253d
2002abc4:	69202c58 	.word	0x69202c58
2002abc8:	656c2076 	.word	0x656c2076
2002abcc:	6874676e 	.word	0x6874676e
2002abd0:	0a64253d 	.word	0x0a64253d
2002abd4:	73655200 	.word	0x73655200
2002abd8:	20746c75 	.word	0x20746c75
2002abdc:	3d6e656c 	.word	0x3d6e656c
2002abe0:	000a6425 	.word	0x000a6425
2002abe4:	2070614d 	.word	0x2070614d
2002abe8:	6f727265 	.word	0x6f727265
2002abec:	6c203a72 	.word	0x6c203a72
2002abf0:	6369676f 	.word	0x6369676f
2002abf4:	2c642520 	.word	0x2c642520
2002abf8:	79687020 	.word	0x79687020
2002abfc:	0a642520 	.word	0x0a642520
2002ac00:	52524500 	.word	0x52524500
2002ac04:	2032203a 	.word	0x2032203a
2002ac08:	69676f6c 	.word	0x69676f6c
2002ac0c:	6c622063 	.word	0x6c622063
2002ac10:	736b636f 	.word	0x736b636f
2002ac14:	70616d20 	.word	0x70616d20
2002ac18:	206f7420 	.word	0x206f7420
2002ac1c:	656d6173 	.word	0x656d6173
2002ac20:	6b6c6220 	.word	0x6b6c6220
2002ac24:	6f6c203a 	.word	0x6f6c203a
2002ac28:	30636967 	.word	0x30636967
2002ac2c:	2c642520 	.word	0x2c642520
2002ac30:	79687020 	.word	0x79687020
2002ac34:	64252030 	.word	0x64252030
2002ac38:	6f6c202c 	.word	0x6f6c202c
2002ac3c:	31636967 	.word	0x31636967
2002ac40:	2c642520 	.word	0x2c642520
2002ac44:	79687020 	.word	0x79687020
2002ac48:	64252031 	.word	0x64252031
2002ac4c:	614d000a 	.word	0x614d000a
2002ac50:	72652070 	.word	0x72652070
2002ac54:	30726f72 	.word	0x30726f72
2002ac58:	6f6c203a 	.word	0x6f6c203a
2002ac5c:	20636967 	.word	0x20636967
2002ac60:	202c6425 	.word	0x202c6425
2002ac64:	20796870 	.word	0x20796870
2002ac68:	000a6425 	.word	0x000a6425
2002ac6c:	20746547 	.word	0x20746547
2002ac70:	2070616d 	.word	0x2070616d
2002ac74:	636f6c62 	.word	0x636f6c62
2002ac78:	7265206b 	.word	0x7265206b
2002ac7c:	20726f72 	.word	0x20726f72
2002ac80:	2d206425 	.word	0x2d206425
2002ac84:	25203e2d 	.word	0x25203e2d
2002ac88:	42000a64 	.word	0x42000a64
2002ac8c:	76204d42 	.word	0x76204d42
2002ac90:	69737265 	.word	0x69737265
2002ac94:	6e206e6f 	.word	0x6e206e6f
2002ac98:	6920746f 	.word	0x6920746f
2002ac9c:	6572636e 	.word	0x6572636e
2002aca0:	64657361 	.word	0x64657361
2002aca4:	7270203a 	.word	0x7270203a
2002aca8:	25207665 	.word	0x25207665
2002acac:	63202c64 	.word	0x63202c64
2002acb0:	20727275 	.word	0x20727275
2002acb4:	000a6425 	.word	0x000a6425
2002acb8:	41544144 	.word	0x41544144
2002acbc:	746f6e20 	.word	0x746f6e20
2002acc0:	61657220 	.word	0x61657220
2002acc4:	616e6f73 	.word	0x616e6f73
2002acc8:	20656c62 	.word	0x20656c62
2002accc:	42206e69 	.word	0x42206e69
2002acd0:	62204d42 	.word	0x62204d42
2002acd4:	25206b6c 	.word	0x25206b6c
2002acd8:	61702064 	.word	0x61702064
2002acdc:	25206567 	.word	0x25206567
2002ace0:	30203a64 	.word	0x30203a64
2002ace4:	0a782578 	.word	0x0a782578
2002ace8:	61655200 	.word	0x61655200
2002acec:	62622064 	.word	0x62622064
2002acf0:	6c62206d 	.word	0x6c62206d
2002acf4:	6425206b 	.word	0x6425206b
2002acf8:	67617020 	.word	0x67617020
2002acfc:	64252065 	.word	0x64252065
2002ad00:	69616620 	.word	0x69616620
2002ad04:	49000a6c 	.word	0x49000a6c
2002ad08:	6c61766e 	.word	0x6c61766e
2002ad0c:	42206469 	.word	0x42206469
2002ad10:	49204d42 	.word	0x49204d42
2002ad14:	25205844 	.word	0x25205844
2002ad18:	56000a64 	.word	0x56000a64
2002ad1c:	64252031 	.word	0x64252031
2002ad20:	206e6920 	.word	0x206e6920
2002ad24:	636f6c62 	.word	0x636f6c62
2002ad28:	6425206b 	.word	0x6425206b
2002ad2c:	3256202c 	.word	0x3256202c
2002ad30:	20642520 	.word	0x20642520
2002ad34:	62206e69 	.word	0x62206e69
2002ad38:	6b636f6c 	.word	0x6b636f6c
2002ad3c:	0a642520 	.word	0x0a642520
2002ad40:	6d615300 	.word	0x6d615300
2002ad44:	69687465 	.word	0x69687465
2002ad48:	6d20676e 	.word	0x6d20676e
2002ad4c:	20747375 	.word	0x20747375
2002ad50:	77206562 	.word	0x77206562
2002ad54:	676e6f72 	.word	0x676e6f72
2002ad58:	6567202c 	.word	0x6567202c
2002ad5c:	656e2074 	.word	0x656e2074
2002ad60:	65762077 	.word	0x65762077
2002ad64:	6f697372 	.word	0x6f697372
2002ad68:	6425206e 	.word	0x6425206e
2002ad6c:	206f6420 	.word	0x206f6420
2002ad70:	20746f6e 	.word	0x20746f6e
2002ad74:	656d6173 	.word	0x656d6173
2002ad78:	206f7420 	.word	0x206f7420
2002ad7c:	76657270 	.word	0x76657270
2002ad80:	65686320 	.word	0x65686320
2002ad84:	25206b63 	.word	0x25206b63
2002ad88:	43000a64 	.word	0x43000a64
2002ad8c:	63204352 	.word	0x63204352
2002ad90:	6b636568 	.word	0x6b636568
2002ad94:	72726520 	.word	0x72726520
2002ad98:	0a20726f 	.word	0x0a20726f
2002ad9c:	61655200 	.word	0x61655200
2002ada0:	62622064 	.word	0x62622064
2002ada4:	6c62206d 	.word	0x6c62206d
2002ada8:	6425206b 	.word	0x6425206b
2002adac:	67617020 	.word	0x67617020
2002adb0:	64252065 	.word	0x64252065
2002adb4:	74616420 	.word	0x74616420
2002adb8:	6f6e2061 	.word	0x6f6e2061
2002adbc:	72772074 	.word	0x72772074
2002adc0:	20657469 	.word	0x20657469
2002adc4:	20726f66 	.word	0x20726f66
2002adc8:	20646e32 	.word	0x20646e32
2002adcc:	656d6974 	.word	0x656d6974
2002add0:	6552000a 	.word	0x6552000a
2002add4:	62206461 	.word	0x62206461
2002add8:	62206d62 	.word	0x62206d62
2002addc:	25206b6c 	.word	0x25206b6c
2002ade0:	61702064 	.word	0x61702064
2002ade4:	25206567 	.word	0x25206567
2002ade8:	61662064 	.word	0x61662064
2002adec:	66206c69 	.word	0x66206c69
2002adf0:	3220726f 	.word	0x3220726f
2002adf4:	7420646e 	.word	0x7420646e
2002adf8:	3f656d69 	.word	0x3f656d69
2002adfc:	614c000a 	.word	0x614c000a
2002ae00:	74736574 	.word	0x74736574
2002ae04:	72657620 	.word	0x72657620
2002ae08:	6e6f6973 	.word	0x6e6f6973
2002ae0c:	0a642520 	.word	0x0a642520
2002ae10:	74654700 	.word	0x74654700
2002ae14:	79687020 	.word	0x79687020
2002ae18:	6b6c6220 	.word	0x6b6c6220
2002ae1c:	726f6620 	.word	0x726f6620
2002ae20:	20642520 	.word	0x20642520
2002ae24:	6c696166 	.word	0x6c696166
2002ae28:	65687720 	.word	0x65687720
2002ae2c:	6572206e 	.word	0x6572206e
2002ae30:	000a6461 	.word	0x000a6461
2002ae34:	636f6c42 	.word	0x636f6c42
2002ae38:	6425206b 	.word	0x6425206b
2002ae3c:	61726520 	.word	0x61726520
2002ae40:	66206573 	.word	0x66206573
2002ae44:	2c6c6961 	.word	0x2c6c6961
2002ae48:	72616d20 	.word	0x72616d20
2002ae4c:	7361206b 	.word	0x7361206b
2002ae50:	64616220 	.word	0x64616220
2002ae54:	6c42000a 	.word	0x6c42000a
2002ae58:	206b636f 	.word	0x206b636f
2002ae5c:	63206425 	.word	0x63206425
2002ae60:	6b636568 	.word	0x6b636568
2002ae64:	20736120 	.word	0x20736120
2002ae68:	20646162 	.word	0x20646162
2002ae6c:	636f6c62 	.word	0x636f6c62
2002ae70:	42000a6b 	.word	0x42000a6b
2002ae74:	6b636f6c 	.word	0x6b636f6c
2002ae78:	20642520 	.word	0x20642520
2002ae7c:	62207369 	.word	0x62207369
2002ae80:	69206461 	.word	0x69206461
2002ae84:	7375206e 	.word	0x7375206e
2002ae88:	62207265 	.word	0x62207265
2002ae8c:	6b636f6c 	.word	0x6b636f6c
2002ae90:	6162000a 	.word	0x6162000a
2002ae94:	64252064 	.word	0x64252064
2002ae98:	6572202c 	.word	0x6572202c
2002ae9c:	63616c70 	.word	0x63616c70
2002aea0:	64252065 	.word	0x64252065
2002aea4:	6f4e000a 	.word	0x6f4e000a
2002aea8:	63616220 	.word	0x63616220
2002aeac:	2070756b 	.word	0x2070756b
2002aeb0:	636f6c62 	.word	0x636f6c62
2002aeb4:	6e61206b 	.word	0x6e61206b
2002aeb8:	6f6d2079 	.word	0x6f6d2079
2002aebc:	000a6572 	.word	0x000a6572
2002aec0:	74706d65 	.word	0x74706d65
2002aec4:	61742079 	.word	0x61742079
2002aec8:	20656c62 	.word	0x20656c62
2002aecc:	6e206425 	.word	0x6e206425
2002aed0:	6520746f 	.word	0x6520746f
2002aed4:	67756f6e 	.word	0x67756f6e
2002aed8:	6f662068 	.word	0x6f662068
2002aedc:	6e692072 	.word	0x6e692072
2002aee0:	61697469 	.word	0x61697469
2002aee4:	55000a6c 	.word	0x55000a6c
2002aee8:	74616470 	.word	0x74616470
2002aeec:	61742065 	.word	0x61742065
2002aef0:	20656c62 	.word	0x20656c62
2002aef4:	66206f74 	.word	0x66206f74
2002aef8:	6873616c 	.word	0x6873616c
2002aefc:	6e6f6420 	.word	0x6e6f6420
2002af00:	49000a65 	.word	0x49000a65
2002af04:	6974696e 	.word	0x6974696e
2002af08:	74206c61 	.word	0x74206c61
2002af0c:	656c6261 	.word	0x656c6261
2002af10:	69616620 	.word	0x69616620
2002af14:	42000a6c 	.word	0x42000a6c
2002af18:	69204d42 	.word	0x69204d42
2002af1c:	6974696e 	.word	0x6974696e
2002af20:	7a696c61 	.word	0x7a696c61
2002af24:	62206465 	.word	0x62206465
2002af28:	726f6665 	.word	0x726f6665
2002af2c:	64202c65 	.word	0x64202c65
2002af30:	6f6e206f 	.word	0x6f6e206f
2002af34:	6e692074 	.word	0x6e692074
2002af38:	61207469 	.word	0x61207469
2002af3c:	6d20796e 	.word	0x6d20796e
2002af40:	0a65726f 	.word	0x0a65726f
2002af44:	54454400 	.word	0x54454400
2002af48:	20642520 	.word	0x20642520
2002af4c:	0a646162 	.word	0x0a646162
2002af50:	4b4c4200 	.word	0x4b4c4200
2002af54:	20642520 	.word	0x20642520
2002af58:	64616572 	.word	0x64616572
2002af5c:	69616620 	.word	0x69616620
2002af60:	6d202c6c 	.word	0x6d202c6c
2002af64:	206b7261 	.word	0x206b7261
2002af68:	62207361 	.word	0x62207361
2002af6c:	000a6461 	.word	0x000a6461
2002af70:	20746564 	.word	0x20746564
2002af74:	206d6262 	.word	0x206d6262
2002af78:	6c626174 	.word	0x6c626174
2002af7c:	69772065 	.word	0x69772065
2002af80:	25206874 	.word	0x25206874
2002af84:	25202c64 	.word	0x25202c64
2002af88:	25202c64 	.word	0x25202c64
2002af8c:	64000a64 	.word	0x64000a64
2002af90:	63657465 	.word	0x63657465
2002af94:	65722074 	.word	0x65722074
2002af98:	746c7573 	.word	0x746c7573
2002af9c:	0a642520 	.word	0x0a642520
2002afa0:	20317600 	.word	0x20317600
2002afa4:	69206425 	.word	0x69206425
2002afa8:	6c62206e 	.word	0x6c62206e
2002afac:	6425206b 	.word	0x6425206b
2002afb0:	3276202c 	.word	0x3276202c
2002afb4:	20642520 	.word	0x20642520
2002afb8:	62206e69 	.word	0x62206e69
2002afbc:	6b636f6c 	.word	0x6b636f6c
2002afc0:	0a642520 	.word	0x0a642520
2002afc4:	65684300 	.word	0x65684300
2002afc8:	62206b63 	.word	0x62206b63
2002afcc:	74206d62 	.word	0x74206d62
2002afd0:	656c6261 	.word	0x656c6261
2002afd4:	69616620 	.word	0x69616620
2002afd8:	64000a6c 	.word	0x64000a6c
2002afdc:	63657465 	.word	0x63657465
2002afe0:	65722074 	.word	0x65722074
2002afe4:	746c7573 	.word	0x746c7573
2002afe8:	20642520 	.word	0x20642520
2002afec:	20746f6e 	.word	0x20746f6e
2002aff0:	73616572 	.word	0x73616572
2002aff4:	62616e6f 	.word	0x62616e6f
2002aff8:	000a656c 	.word	0x000a656c
2002affc:	204d4242 	.word	0x204d4242
2002b000:	3a4d454d 	.word	0x3a4d454d
2002b004:	78746320 	.word	0x78746320
2002b008:	2c702520 	.word	0x2c702520
2002b00c:	70616d20 	.word	0x70616d20
2002b010:	70252031 	.word	0x70252031
2002b014:	616d202c 	.word	0x616d202c
2002b018:	25203270 	.word	0x25203270
2002b01c:	000a2070 	.word	0x000a2070
2002b020:	5f666973 	.word	0x5f666973
2002b024:	5f6d6262 	.word	0x5f6d6262
2002b028:	74696e69 	.word	0x74696e69
2002b02c:	6e6f6420 	.word	0x6e6f6420
2002b030:	53000a65 	.word	0x53000a65
2002b034:	31354148 	.word	0x31354148
2002b038:	48530032 	.word	0x48530032
2002b03c:	34383341 	.word	0x34383341
2002b040:	41485300 	.word	0x41485300
2002b044:	00363532 	.word	0x00363532
2002b048:	32414853 	.word	0x32414853
2002b04c:	60003432 	.word	0x60003432
2002b050:	65014886 	.word	0x65014886
2002b054:	04020403 	.word	0x04020403
2002b058:	2d646900 	.word	0x2d646900
2002b05c:	32616873 	.word	0x32616873
2002b060:	60003432 	.word	0x60003432
2002b064:	65014886 	.word	0x65014886
2002b068:	01020403 	.word	0x01020403
2002b06c:	2d646900 	.word	0x2d646900
2002b070:	32616873 	.word	0x32616873
2002b074:	60003635 	.word	0x60003635
2002b078:	65014886 	.word	0x65014886
2002b07c:	02020403 	.word	0x02020403
2002b080:	2d646900 	.word	0x2d646900
2002b084:	33616873 	.word	0x33616873
2002b088:	60003438 	.word	0x60003438
2002b08c:	65014886 	.word	0x65014886
2002b090:	03020403 	.word	0x03020403
2002b094:	2d646900 	.word	0x2d646900
2002b098:	35616873 	.word	0x35616873
2002b09c:	2b003231 	.word	0x2b003231
2002b0a0:	0702030e 	.word	0x0702030e
2002b0a4:	73656400 	.word	0x73656400
2002b0a8:	00434243 	.word	0x00434243
2002b0ac:	2d534544 	.word	0x2d534544
2002b0b0:	00434243 	.word	0x00434243
2002b0b4:	8648862a 	.word	0x8648862a
2002b0b8:	07030df7 	.word	0x07030df7
2002b0bc:	73656400 	.word	0x73656400
2002b0c0:	6564652d 	.word	0x6564652d
2002b0c4:	62632d33 	.word	0x62632d33
2002b0c8:	45440063 	.word	0x45440063
2002b0cc:	44452d53 	.word	0x44452d53
2002b0d0:	432d3345 	.word	0x432d3345
2002b0d4:	2a004342 	.word	0x2a004342
2002b0d8:	f7864886 	.word	0xf7864886
2002b0dc:	0101010d 	.word	0x0101010d
2002b0e0:	61737200 	.word	0x61737200
2002b0e4:	72636e45 	.word	0x72636e45
2002b0e8:	69747079 	.word	0x69747079
2002b0ec:	52006e6f 	.word	0x52006e6f
2002b0f0:	2a004153 	.word	0x2a004153
2002b0f4:	3dce4886 	.word	0x3dce4886
2002b0f8:	69000102 	.word	0x69000102
2002b0fc:	63652d64 	.word	0x63652d64
2002b100:	6c627550 	.word	0x6c627550
2002b104:	654b6369 	.word	0x654b6369
2002b108:	65470079 	.word	0x65470079
2002b10c:	6972656e 	.word	0x6972656e
2002b110:	43452063 	.word	0x43452063
2002b114:	79656b20 	.word	0x79656b20
2002b118:	04812b00 	.word	0x04812b00
2002b11c:	69000c01 	.word	0x69000c01
2002b120:	63652d64 	.word	0x63652d64
2002b124:	45004844 	.word	0x45004844
2002b128:	656b2043 	.word	0x656b2043
2002b12c:	6f662079 	.word	0x6f662079
2002b130:	43452072 	.word	0x43452072
2002b134:	2a004844 	.word	0x2a004844
2002b138:	f7864886 	.word	0xf7864886
2002b13c:	0e01010d 	.word	0x0e01010d
2002b140:	61687300 	.word	0x61687300
2002b144:	57343232 	.word	0x57343232
2002b148:	52687469 	.word	0x52687469
2002b14c:	6e454153 	.word	0x6e454153
2002b150:	70797263 	.word	0x70797263
2002b154:	6e6f6974 	.word	0x6e6f6974
2002b158:	41535200 	.word	0x41535200
2002b15c:	74697720 	.word	0x74697720
2002b160:	48532068 	.word	0x48532068
2002b164:	32322d41 	.word	0x32322d41
2002b168:	862a0034 	.word	0x862a0034
2002b16c:	0df78648 	.word	0x0df78648
2002b170:	000b0101 	.word	0x000b0101
2002b174:	32616873 	.word	0x32616873
2002b178:	69573635 	.word	0x69573635
2002b17c:	53526874 	.word	0x53526874
2002b180:	636e4541 	.word	0x636e4541
2002b184:	74707972 	.word	0x74707972
2002b188:	006e6f69 	.word	0x006e6f69
2002b18c:	20415352 	.word	0x20415352
2002b190:	68746977 	.word	0x68746977
2002b194:	41485320 	.word	0x41485320
2002b198:	3635322d 	.word	0x3635322d
2002b19c:	48862a00 	.word	0x48862a00
2002b1a0:	010df786 	.word	0x010df786
2002b1a4:	73000c01 	.word	0x73000c01
2002b1a8:	38336168 	.word	0x38336168
2002b1ac:	74695734 	.word	0x74695734
2002b1b0:	41535268 	.word	0x41535268
2002b1b4:	72636e45 	.word	0x72636e45
2002b1b8:	69747079 	.word	0x69747079
2002b1bc:	52006e6f 	.word	0x52006e6f
2002b1c0:	77204153 	.word	0x77204153
2002b1c4:	20687469 	.word	0x20687469
2002b1c8:	2d414853 	.word	0x2d414853
2002b1cc:	00343833 	.word	0x00343833
2002b1d0:	8648862a 	.word	0x8648862a
2002b1d4:	01010df7 	.word	0x01010df7
2002b1d8:	6873000d 	.word	0x6873000d
2002b1dc:	32313561 	.word	0x32313561
2002b1e0:	68746957 	.word	0x68746957
2002b1e4:	45415352 	.word	0x45415352
2002b1e8:	7972636e 	.word	0x7972636e
2002b1ec:	6f697470 	.word	0x6f697470
2002b1f0:	5352006e 	.word	0x5352006e
2002b1f4:	69772041 	.word	0x69772041
2002b1f8:	53206874 	.word	0x53206874
2002b1fc:	352d4148 	.word	0x352d4148
2002b200:	2a003231 	.word	0x2a003231
2002b204:	f7864886 	.word	0xf7864886
2002b208:	0a01010d 	.word	0x0a01010d
2002b20c:	41535200 	.word	0x41535200
2002b210:	2d415353 	.word	0x2d415353
2002b214:	00535350 	.word	0x00535350
2002b218:	2e617372 	.word	0x2e617372
2002b21c:	7372004e 	.word	0x7372004e
2002b220:	00452e61 	.word	0x00452e61

2002b224 <pin_pad_func_lcpu>:
	...
2002b244:	032100b2 00000301 00000000 024b023b     ..!.........;.K.
2002b254:	00000237 00000000 00000000 00000000     7...............
2002b264:	032200b3 00000302 00000000 024b023c     ..".........<.K.
2002b274:	00000238 00000000 00000000 00000000     8...............
2002b284:	032300b4 00000303 00000000 024b023d     ..#.........=.K.
2002b294:	0000023a 00000000 00000000 00000000     :...............
2002b2a4:	032400b5 00000304 00000000 024b023e     ..$.........>.K.
2002b2b4:	00000239 00000000 00000000 00000000     9...............

2002b2c4 <pin_pad_func_hcpu>:
	...
2002b2e4:	000400f2 00000000 000b0000 00000000     ................
	...
2002b304:	000900f3 00000000 00030000 00000000     ................
	...
2002b324:	000a00f4 00000000 000a0000 00000000     ................
	...
2002b344:	000b00f5 00000000 000b0000 00000000     ................
	...
2002b364:	000c00f6 00000000 00030000 00000000     ................
	...
2002b384:	000300f7 000d0000 00000009 00000000     ................
	...
2002b3a4:	000200f8 000e0000 0000000b 00000000     ................
	...
2002b3c4:	000100f9 000f0000 0009000a 00000000     ................
	...
2002b3e4:	000d00fa 00100000 000c0003 00000000     ................
	...
2002b404:	000e00fb 00060000 00010001 00000000     ................
	...
2002b424:	000f00fc 00010000 000c000c 00000000     ................
	...
2002b444:	001000fd 00030000 00090000 00000000     ................
	...
2002b464:	000500fe 00000006 00000000 00000000     ................
	...
2002b484:	01540052 00000000 026302b2 016a0000     R.T.......c...j.
	...
2002b4a4:	00000053 00000000 026402b3 00000000     S.........d.....
	...
2002b4c4:	01550054 01c60000 026502b4 016b019a     T.U.......e...k.
2002b4d4:	023b0000 02270000 00000000 00000000     ..;...'.........
2002b4e4:	014e0055 01c80000 026602b5 015f0199     U.N.......f..._.
2002b4f4:	023c0000 02280000 00000000 00000000     ..<...(.........
2002b504:	014f0056 01c70000 026702b6 015e0197     V.O.......g...^.
2002b514:	023d0000 02290000 00000000 00000000     ..=...).........
2002b524:	01500057 01c40000 026802b7 01680195     W.P.......h...h.
2002b534:	023e0000 022a0000 00000000 00000000     ..>...*.........
2002b544:	01510058 01c50000 026902b8 01690194     X.Q.......i...i.
2002b554:	023f0000 022b0000 00000000 00000000     ..?...+.........
2002b564:	01520059 01d40000 026a02b9 01600192     Y.R.......j...`.
2002b574:	02400000 022c0000 00000000 00000000     ..@...,.........
2002b584:	0153005a 01d50000 026b02ba 01610191     Z.S.......k...a.
2002b594:	02410000 0000023a 00000000 00000000     ..A.:...........
2002b5a4:	0000005b 00000000 026c02bb 00000000     [.........l.....
2002b5b4:	02420000 00000239 00000000 00000000     ..B.9...........
2002b5c4:	0000005c 00000000 026d02bc 00000000     \.........m.....
	...
2002b5e4:	0000005d 00000000 026e02bd 00000000     ].........n.....
2002b5f4:	01d30000 02210237 00000000 00000000     ....7.!.........
2002b604:	001b005e 000001b7 026f02be 00000000     ^.........o.....
2002b614:	00000000 02220238 00000000 00000000     ....8.".........
2002b624:	0022005f 000001b8 027002bf 00000000     _.".......p.....
2002b634:	00000000 02230000 00000000 00000000     ......#.........
2002b644:	00230060 000001b2 027102c0 00000000     `.#.......q.....
2002b654:	00000000 02240000 00000000 00000000     ......$.........
2002b664:	00210061 000001b4 027202c1 00000000     a.!.......r.....
2002b674:	00000000 02250000 00000000 00000000     ......%.........
2002b684:	00190062 000001b5 027302c2 00000000     b.........s.....
2002b694:	00000000 02260000 00000000 00000000     ......&.........
2002b6a4:	00240063 000001b6 027402c3 00000000     c.$.......t.....
	...
2002b6c4:	00000064 0000021a 027502c4 00000000     d.........u.....
	...
2002b6e4:	00000065 00000219 027602c5 00000000     e.........v.....
	...
2002b704:	00000066 00000000 027702c6 00000000     f.........w.....
2002b714:	024b0000 00000000 00000000 00000000     ..K.............
2002b724:	00000067 00000000 027802c7 00000000     g.........x.....
	...
2002b744:	00000068 01d40000 027902c8 00000000     h.........y.....
	...
2002b764:	00000069 01d50000 027a02c9 00000000     i.........z.....
	...
2002b784:	0000006a 01c60149 027b02ca 03620361     j...I.....{.a.b.
2002b794:	03640363 03660365 00000000 00000000     c.d.e.f.........
2002b7a4:	0000006b 01c80148 027c02cb 03620361     k...H.....|.a.b.
2002b7b4:	03640363 03660365 00000000 00000000     c.d.e.f.........
2002b7c4:	0000006c 00000000 027d02cc 03620361     l.........}.a.b.
2002b7d4:	03640363 03660365 00000000 00000000     c.d.e.f.........
2002b7e4:	0000006d 00000000 027e02cd 03620361     m.........~.a.b.
2002b7f4:	03640363 03660365 00000000 00000000     c.d.e.f.........
2002b804:	0000006e 01c70146 027f02ce 00000000     n...F...........
	...
2002b824:	0000006f 01c40147 028002cf 00000000     o...G...........
	...
2002b844:	00000070 01c50000 028102d0 00000000     p...............
	...
2002b864:	00000071 00000000 028202d1 00000000     q...............
2002b874:	02430000 00000000 00000000 00000000     ..C.............
2002b884:	00000072 00000000 028302d2 00000000     r...............
	...
2002b8a4:	00000073 00000000 028402d3 00000000     s...............
	...
2002b8c4:	00000074 00000000 028502d4 00000000     t...............
	...
2002b8e4:	00000075 00000000 028602d5 00000000     u...............
	...
2002b904:	00000076 00000000 028702d6 00000000     v...............
	...
2002b924:	00000077 0000014d 028802d7 01620000     w...M.........b.
2002b934:	02440000 00000000 00000000 00000000     ..D.............
2002b944:	00000078 0000014c 028902d8 00000000     x...L...........
	...
2002b964:	00000079 0000014a 028a02d9 01630190     y...J.........c.
2002b974:	02450000 022f0000 00000000 00000000     ..E.../.........
2002b984:	0000007a 0000014b 028b02da 0164018f     z...K.........d.
2002b994:	02460000 02300000 00000000 00000000     ..F...0.........
2002b9a4:	0000007b 00000000 028c02db 01650193     {.............e.
2002b9b4:	02470000 02310000 00000000 00000000     ..G...1.........
2002b9c4:	0000007c 00000000 028d02dc 01660196     |.............f.
2002b9d4:	02480000 02320000 00000000 00000000     ..H...2.........
2002b9e4:	0000007d 00000000 028e02dd 01670198     }.............g.
2002b9f4:	02490000 02330000 00000000 00000000     ..I...3.........
2002ba04:	0000007e 00000000 028f02de 00000000     ~...............
2002ba14:	024a0000 02340000 00000000 00000000     ..J...4.........

2002ba24 <HASH_SIZE>:
2002ba24:	20202014 00000000 04030201 00000000     .   ............
2002ba34:	01060204                                ....

2002ba38 <CSWTCH.40>:
2002ba38:	0000003f 00003f00 003f0000              ?....?....?.

2002ba44 <hpsys_dll2_limit>:
	...
2002ba4c:	112a8800 112a8800                       ..*...*.

2002ba54 <hpsys_dvfs_config>:
2002ba54:	000906fb 00100330 000a08fd 00110331     ....0.......1...
2002ba64:	000d0b00 00130213 000f0d02 00130213     ................

2002ba74 <crc32tab>:
2002ba74:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
2002ba84:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
2002ba94:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
2002baa4:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
2002bab4:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
2002bac4:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
2002bad4:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
2002bae4:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
2002baf4:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
2002bb04:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
2002bb14:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
2002bb24:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
2002bb34:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
2002bb44:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
2002bb54:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
2002bb64:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
2002bb74:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
2002bb84:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
2002bb94:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
2002bba4:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
2002bbb4:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
2002bbc4:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
2002bbd4:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
2002bbe4:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
2002bbf4:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
2002bc04:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
2002bc14:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
2002bc24:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
2002bc34:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
2002bc44:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
2002bc54:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
2002bc64:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
2002bc74:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
2002bc84:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
2002bc94:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
2002bca4:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
2002bcb4:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
2002bcc4:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
2002bcd4:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
2002bce4:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
2002bcf4:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
2002bd04:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
2002bd14:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
2002bd24:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
2002bd34:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
2002bd44:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
2002bd54:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
2002bd64:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
2002bd74:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
2002bd84:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
2002bd94:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
2002bda4:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
2002bdb4:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
2002bdc4:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
2002bdd4:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
2002bde4:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
2002bdf4:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
2002be04:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
2002be14:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
2002be24:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
2002be34:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
2002be44:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
2002be54:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
2002be64:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

2002be74 <CSWTCH.5>:
2002be74:	2002bf14 2002bee4 2002beb4 2002be84     ... ... ... ... 

2002be84 <mbedtls_sha512_info>:
2002be84:	00000008 2002b033 00000040 00000080     ....3.. @.......
2002be94:	200260c9 200260bf 200260bb 200260b5     .`. .`. .`. .`. 
2002bea4:	20026099 20026087 20026083 2002607f     .`. .`. .`. .`. 

2002beb4 <mbedtls_sha384_info>:
2002beb4:	00000007 2002b03a 00000030 00000080     ....:.. 0.......
2002bec4:	200260c3 200260bf 200260bb 200260af     .`. .`. .`. .`. 
2002bed4:	20026099 20026087 20026083 2002607f     .`. .`. .`. .`. 

2002bee4 <mbedtls_sha256_info>:
2002bee4:	00000006 2002b041 00000020 00000040     ....A..  ...@...
2002bef4:	20026079 2002606f 2002606b 20026065     y`. o`. k`. e`. 
2002bf04:	20026049 20026037 20026033 2002602f     I`. 7`. 3`. /`. 

2002bf14 <mbedtls_sha224_info>:
2002bf14:	00000005 2002b048 0000001c 00000040     ....H.. ....@...
2002bf24:	20026073 2002606f 2002606b 2002605f     s`. o`. k`. _`. 
2002bf34:	20026049 20026037 20026033 2002602f     I`. 7`. 3`. /`. 

2002bf44 <sha256_padding>:
2002bf44:	00000080 00000000 00000000 00000000     ................
	...

2002bf84 <K>:
2002bf84:	428a2f98 71374491 b5c0fbcf e9b5dba5     ./.B.D7q........
2002bf94:	3956c25b 59f111f1 923f82a4 ab1c5ed5     [.V9...Y..?..^..
2002bfa4:	d807aa98 12835b01 243185be 550c7dc3     .....[....1$.}.U
2002bfb4:	72be5d74 80deb1fe 9bdc06a7 c19bf174     t].r........t...
2002bfc4:	e49b69c1 efbe4786 0fc19dc6 240ca1cc     .i...G.........$
2002bfd4:	2de92c6f 4a7484aa 5cb0a9dc 76f988da     o,.-..tJ...\...v
2002bfe4:	983e5152 a831c66d b00327c8 bf597fc7     RQ>.m.1..'....Y.
2002bff4:	c6e00bf3 d5a79147 06ca6351 14292967     ....G...Qc..g)).
2002c004:	27b70a85 2e1b2138 4d2c6dfc 53380d13     ...'8!...m,M..8S
2002c014:	650a7354 766a0abb 81c2c92e 92722c85     Ts.e..jv.....,r.
2002c024:	a2bfe8a1 a81a664b c24b8b70 c76c51a3     ....Kf..p.K..Ql.
2002c034:	d192e819 d6990624 f40e3585 106aa070     ....$....5..p.j.
2002c044:	19a4c116 1e376c08 2748774c 34b0bcb5     .....l7.LwH'...4
2002c054:	391c0cb3 4ed8aa4a 5b9cca4f 682e6ff3     ...9J..NO..[.o.h
2002c064:	748f82ee 78a5636f 84c87814 8cc70208     ...toc.x.x......
2002c074:	90befffa a4506ceb bef9a3f7 c67178f2     .....lP......xq.

2002c084 <sha512_padding>:
2002c084:	00000080 00000000 00000000 00000000     ................
	...

2002c108 <K>:
2002c108:	d728ae22 428a2f98 23ef65cd 71374491     ".(../.B.e.#.D7q
2002c118:	ec4d3b2f b5c0fbcf 8189dbbc e9b5dba5     /;M.............
2002c128:	f348b538 3956c25b b605d019 59f111f1     8.H.[.V9.......Y
2002c138:	af194f9b 923f82a4 da6d8118 ab1c5ed5     .O....?...m..^..
2002c148:	a3030242 d807aa98 45706fbe 12835b01     B........opE.[..
2002c158:	4ee4b28c 243185be d5ffb4e2 550c7dc3     ...N..1$.....}.U
2002c168:	f27b896f 72be5d74 3b1696b1 80deb1fe     o.{.t].r...;....
2002c178:	25c71235 9bdc06a7 cf692694 c19bf174     5..%.....&i.t...
2002c188:	9ef14ad2 e49b69c1 384f25e3 efbe4786     .J...i...%O8.G..
2002c198:	8b8cd5b5 0fc19dc6 77ac9c65 240ca1cc     ........e..w...$
2002c1a8:	592b0275 2de92c6f 6ea6e483 4a7484aa     u.+Yo,.-...n..tJ
2002c1b8:	bd41fbd4 5cb0a9dc 831153b5 76f988da     ..A....\.S.....v
2002c1c8:	ee66dfab 983e5152 2db43210 a831c66d     ..f.RQ>..2.-m.1.
2002c1d8:	98fb213f b00327c8 beef0ee4 bf597fc7     ?!...'........Y.
2002c1e8:	3da88fc2 c6e00bf3 930aa725 d5a79147     ...=....%...G...
2002c1f8:	e003826f 06ca6351 0a0e6e70 14292967     o...Qc..pn..g)).
2002c208:	46d22ffc 27b70a85 5c26c926 2e1b2138     ./.F...'&.&\8!..
2002c218:	5ac42aed 4d2c6dfc 9d95b3df 53380d13     .*.Z.m,M......8S
2002c228:	8baf63de 650a7354 3c77b2a8 766a0abb     .c..Ts.e..w<..jv
2002c238:	47edaee6 81c2c92e 1482353b 92722c85     ...G....;5...,r.
2002c248:	4cf10364 a2bfe8a1 bc423001 a81a664b     d..L.....0B.Kf..
2002c258:	d0f89791 c24b8b70 0654be30 c76c51a3     ....p.K.0.T..Ql.
2002c268:	d6ef5218 d192e819 5565a910 d6990624     .R........eU$...
2002c278:	5771202a f40e3585 32bbd1b8 106aa070     * qW.5.....2p.j.
2002c288:	b8d2d0c8 19a4c116 5141ab53 1e376c08     ........S.AQ.l7.
2002c298:	df8eeb99 2748774c e19b48a8 34b0bcb5     ....LwH'.H.....4
2002c2a8:	c5c95a63 391c0cb3 e3418acb 4ed8aa4a     cZ.....9..A.J..N
2002c2b8:	7763e373 5b9cca4f d6b2b8a3 682e6ff3     s.cwO..[.....o.h
2002c2c8:	5defb2fc 748f82ee 43172f60 78a5636f     ...]...t`/.Coc.x
2002c2d8:	a1f0ab72 84c87814 1a6439ec 8cc70208     r....x...9d.....
2002c2e8:	23631e28 90befffa de82bde9 a4506ceb     (.c#.........lP.
2002c2f8:	b2c67915 bef9a3f7 e372532b c67178f2     .y......+Sr..xq.
2002c308:	ea26619c ca273ece 21c0c207 d186b8c7     .a&..>'....!....
2002c318:	cde0eb1e eada7dd6 ee6ed178 f57d4f7f     .....}..x.n..O}.
2002c328:	72176fba 06f067aa a2c898a6 0a637dc5     .o.r.g.......}c.
2002c338:	bef90dae 113f9804 131c471b 1b710b35     ......?..G..5.q.
2002c348:	23047d84 28db77f5 40c72493 32caab7b     .}.#.w.(.$.@{..2
2002c358:	15c9bebc 3c9ebe0a 9c100d4c 431d67c4     .......<L....g.C
2002c368:	cb3e42b6 4cc5d4be fc657e2a 597f299c     .B>....L*~e..).Y
2002c378:	3ad6faec 5fcb6fab 4a475817 6c44198c     ...:.o._.XGJ..Dl

2002c388 <oid_md_alg>:
2002c388:	2002b04f 00000009 2002b059 2002b162     O.. ....Y.. b.. 
2002c398:	00000005 2002b063 00000009 2002b06d     ....c.. ....m.. 
2002c3a8:	2002b195 00000006 2002b077 00000009     ... ....w.. ....
2002c3b8:	2002b081 2002b1c8 00000007 2002b08b     ... ... ....... 
2002c3c8:	00000009 2002b095 2002b1fb 00000008     ....... ... ....
	...

2002c3ec <oid_pk_alg>:
2002c3ec:	2002b0d7 00000009 2002b0e1 2002b0ef     ... ....... ... 
2002c3fc:	00000001 2002b0f3 00000007 2002b0fb     ....... ....... 
2002c40c:	2002b10a 00000002 2002b119 00000005     ... ....... ....
2002c41c:	2002b11f 2002b127 00000003 00000000     ... '.. ........
	...

2002c43c <mbedtls_rsa_info>:
2002c43c:	00000001 2002b0ef 2002973f 20029733     ....... ?.. 3.. 
2002c44c:	20029819 200297f5 200297c9 20029799     ... ... ... ... 
2002c45c:	20029795 2002977b 20029769 20029745     ... {.. i.. E.. 

2002c46c <_init>:
2002c46c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002c46e:	bf00      	nop
2002c470:	bcf8      	pop	{r3, r4, r5, r6, r7}
2002c472:	bc08      	pop	{r3}
2002c474:	469e      	mov	lr, r3
2002c476:	4770      	bx	lr

2002c478 <_fini>:
2002c478:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002c47a:	bf00      	nop
2002c47c:	bcf8      	pop	{r3, r4, r5, r6, r7}
2002c47e:	bc08      	pop	{r3}
2002c480:	469e      	mov	lr, r3
2002c482:	4770      	bx	lr

2002c484 <__EH_FRAME_BEGIN__>:
2002c484:	0000 0000                                   ....

Disassembly of section .l1_ret_text_HAL_Set_backup:

2002c488 <HAL_Set_backup>:
2002c488:	4b01      	ldr	r3, [pc, #4]	@ (2002c490 <HAL_Set_backup+0x8>)
2002c48a:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
2002c48e:	4770      	bx	lr
2002c490:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

2002c494 <HAL_Get_backup>:
2002c494:	4b01      	ldr	r3, [pc, #4]	@ (2002c49c <HAL_Get_backup+0x8>)
2002c496:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
2002c49a:	4770      	bx	lr
2002c49c:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_ConfigPeriLdo:

2002c4a0 <HAL_PMU_ConfigPeriLdo>:
2002c4a0:	b538      	push	{r3, r4, r5, lr}
2002c4a2:	b160      	cbz	r0, 2002c4be <HAL_PMU_ConfigPeriLdo+0x1e>
2002c4a4:	4c11      	ldr	r4, [pc, #68]	@ (2002c4ec <HAL_PMU_ConfigPeriLdo+0x4c>)
2002c4a6:	6863      	ldr	r3, [r4, #4]
2002c4a8:	b2db      	uxtb	r3, r3
2002c4aa:	2b07      	cmp	r3, #7
2002c4ac:	d01a      	beq.n	2002c4e4 <HAL_PMU_ConfigPeriLdo+0x44>
2002c4ae:	6863      	ldr	r3, [r4, #4]
2002c4b0:	b2db      	uxtb	r3, r3
2002c4b2:	2b0f      	cmp	r3, #15
2002c4b4:	d016      	beq.n	2002c4e4 <HAL_PMU_ConfigPeriLdo+0x44>
2002c4b6:	2808      	cmp	r0, #8
2002c4b8:	d001      	beq.n	2002c4be <HAL_PMU_ConfigPeriLdo+0x1e>
2002c4ba:	2810      	cmp	r0, #16
2002c4bc:	d114      	bne.n	2002c4e8 <HAL_PMU_ConfigPeriLdo+0x48>
2002c4be:	2900      	cmp	r1, #0
2002c4c0:	f04f 0421 	mov.w	r4, #33	@ 0x21
2002c4c4:	bf0c      	ite	eq
2002c4c6:	2120      	moveq	r1, #32
2002c4c8:	2101      	movne	r1, #1
2002c4ca:	4d09      	ldr	r5, [pc, #36]	@ (2002c4f0 <HAL_PMU_ConfigPeriLdo+0x50>)
2002c4cc:	4084      	lsls	r4, r0
2002c4ce:	6deb      	ldr	r3, [r5, #92]	@ 0x5c
2002c4d0:	4081      	lsls	r1, r0
2002c4d2:	ea23 0304 	bic.w	r3, r3, r4
2002c4d6:	430b      	orrs	r3, r1
2002c4d8:	65eb      	str	r3, [r5, #92]	@ 0x5c
2002c4da:	b11a      	cbz	r2, 2002c4e4 <HAL_PMU_ConfigPeriLdo+0x44>
2002c4dc:	f241 3088 	movw	r0, #5000	@ 0x1388
2002c4e0:	f7f5 fe3b 	bl	2002215a <HAL_Delay_us>
2002c4e4:	2000      	movs	r0, #0
2002c4e6:	bd38      	pop	{r3, r4, r5, pc}
2002c4e8:	2001      	movs	r0, #1
2002c4ea:	e7fc      	b.n	2002c4e6 <HAL_PMU_ConfigPeriLdo+0x46>
2002c4ec:	5000b000 	.word	0x5000b000
2002c4f0:	500ca000 	.word	0x500ca000

Disassembly of section .l1_ret_text_HAL_PMU_Reboot:

2002c4f4 <HAL_PMU_Reboot>:
2002c4f4:	b538      	push	{r3, r4, r5, lr}
2002c4f6:	f3ef 8310 	mrs	r3, PRIMASK
2002c4fa:	2501      	movs	r5, #1
2002c4fc:	f385 8810 	msr	PRIMASK, r5
2002c500:	2002      	movs	r0, #2
2002c502:	f7f6 fb71 	bl	20022be8 <HAL_HPAON_WakeCore>
2002c506:	4628      	mov	r0, r5
2002c508:	f7f8 ff72 	bl	200253f0 <HAL_RCC_Reset_and_Halt_LCPU>
2002c50c:	462a      	mov	r2, r5
2002c50e:	2100      	movs	r1, #0
2002c510:	2008      	movs	r0, #8
2002c512:	f7ff ffc5 	bl	2002c4a0 <HAL_PMU_ConfigPeriLdo>
2002c516:	f44f 50fa 	mov.w	r0, #8000	@ 0x1f40
2002c51a:	f7f5 fdc7 	bl	200220ac <HAL_Delay_us_>
2002c51e:	2000      	movs	r0, #0
2002c520:	f7f8 fd5e 	bl	20024fe0 <HAL_RCC_HCPU_GetClockSrc>
2002c524:	4604      	mov	r4, r0
2002c526:	b928      	cbnz	r0, 2002c534 <HAL_PMU_Reboot+0x40>
2002c528:	f7f6 fb88 	bl	20022c3c <HAL_HPAON_EnableXT48>
2002c52c:	4629      	mov	r1, r5
2002c52e:	4620      	mov	r0, r4
2002c530:	f7f8 fe26 	bl	20025180 <HAL_RCC_HCPU_ClockSelect>
2002c534:	4b10      	ldr	r3, [pc, #64]	@ (2002c578 <HAL_PMU_Reboot+0x84>)
2002c536:	4c11      	ldr	r4, [pc, #68]	@ (2002c57c <HAL_PMU_Reboot+0x88>)
2002c538:	2000      	movs	r0, #0
2002c53a:	6763      	str	r3, [r4, #116]	@ 0x74
2002c53c:	f7ff ffaa 	bl	2002c494 <HAL_Get_backup>
2002c540:	4601      	mov	r1, r0
2002c542:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
2002c546:	f020 000f 	bic.w	r0, r0, #15
2002c54a:	b928      	cbnz	r0, 2002c558 <HAL_PMU_Reboot+0x64>
2002c54c:	f441 41a0 	orr.w	r1, r1, #20480	@ 0x5000
2002c550:	f041 0150 	orr.w	r1, r1, #80	@ 0x50
2002c554:	f7ff ff98 	bl	2002c488 <HAL_Set_backup>
2002c558:	6823      	ldr	r3, [r4, #0]
2002c55a:	075b      	lsls	r3, r3, #29
2002c55c:	d506      	bpl.n	2002c56c <HAL_PMU_Reboot+0x78>
2002c55e:	6823      	ldr	r3, [r4, #0]
2002c560:	4807      	ldr	r0, [pc, #28]	@ (2002c580 <HAL_PMU_Reboot+0x8c>)
2002c562:	f023 0304 	bic.w	r3, r3, #4
2002c566:	6023      	str	r3, [r4, #0]
2002c568:	f7f5 fdf7 	bl	2002215a <HAL_Delay_us>
2002c56c:	4a03      	ldr	r2, [pc, #12]	@ (2002c57c <HAL_PMU_Reboot+0x88>)
2002c56e:	6813      	ldr	r3, [r2, #0]
2002c570:	f043 0304 	orr.w	r3, r3, #4
2002c574:	6013      	str	r3, [r2, #0]
2002c576:	e7fe      	b.n	2002c576 <HAL_PMU_Reboot+0x82>
2002c578:	0a50c015 	.word	0x0a50c015
2002c57c:	500ca000 	.word	0x500ca000
2002c580:	000186a0 	.word	0x000186a0

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

2002c584 <HAL_PMU_GetHpsysVoutRef>:
2002c584:	4b04      	ldr	r3, [pc, #16]	@ (2002c598 <HAL_PMU_GetHpsysVoutRef+0x14>)
2002c586:	781a      	ldrb	r2, [r3, #0]
2002c588:	b122      	cbz	r2, 2002c594 <HAL_PMU_GetHpsysVoutRef+0x10>
2002c58a:	b118      	cbz	r0, 2002c594 <HAL_PMU_GetHpsysVoutRef+0x10>
2002c58c:	78db      	ldrb	r3, [r3, #3]
2002c58e:	7003      	strb	r3, [r0, #0]
2002c590:	2000      	movs	r0, #0
2002c592:	4770      	bx	lr
2002c594:	2001      	movs	r0, #1
2002c596:	4770      	bx	lr
2002c598:	2004cc45 	.word	0x2004cc45

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

2002c59c <HAL_PMU_GetHpsysVoutRef2>:
2002c59c:	4b04      	ldr	r3, [pc, #16]	@ (2002c5b0 <HAL_PMU_GetHpsysVoutRef2+0x14>)
2002c59e:	781a      	ldrb	r2, [r3, #0]
2002c5a0:	b122      	cbz	r2, 2002c5ac <HAL_PMU_GetHpsysVoutRef2+0x10>
2002c5a2:	b118      	cbz	r0, 2002c5ac <HAL_PMU_GetHpsysVoutRef2+0x10>
2002c5a4:	7b5b      	ldrb	r3, [r3, #13]
2002c5a6:	7003      	strb	r3, [r0, #0]
2002c5a8:	2000      	movs	r0, #0
2002c5aa:	4770      	bx	lr
2002c5ac:	2001      	movs	r0, #1
2002c5ae:	4770      	bx	lr
2002c5b0:	2004cc45 	.word	0x2004cc45
