
build_sf32lb57-lcd_n16r16_dpi_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020204 <deregister_tm_clones>:
20020204:	4803      	ldr	r0, [pc, #12]	@ (20020214 <deregister_tm_clones+0x10>)
20020206:	4b04      	ldr	r3, [pc, #16]	@ (20020218 <deregister_tm_clones+0x14>)
20020208:	4283      	cmp	r3, r0
2002020a:	d002      	beq.n	20020212 <deregister_tm_clones+0xe>
2002020c:	4b03      	ldr	r3, [pc, #12]	@ (2002021c <deregister_tm_clones+0x18>)
2002020e:	b103      	cbz	r3, 20020212 <deregister_tm_clones+0xe>
20020210:	4718      	bx	r3
20020212:	4770      	bx	lr
20020214:	20044a10 	.word	0x20044a10
20020218:	20044a10 	.word	0x20044a10
2002021c:	00000000 	.word	0x00000000

20020220 <register_tm_clones>:
20020220:	4b06      	ldr	r3, [pc, #24]	@ (2002023c <register_tm_clones+0x1c>)
20020222:	4907      	ldr	r1, [pc, #28]	@ (20020240 <register_tm_clones+0x20>)
20020224:	1ac9      	subs	r1, r1, r3
20020226:	1089      	asrs	r1, r1, #2
20020228:	bf48      	it	mi
2002022a:	3101      	addmi	r1, #1
2002022c:	1049      	asrs	r1, r1, #1
2002022e:	d003      	beq.n	20020238 <register_tm_clones+0x18>
20020230:	4b04      	ldr	r3, [pc, #16]	@ (20020244 <register_tm_clones+0x24>)
20020232:	b10b      	cbz	r3, 20020238 <register_tm_clones+0x18>
20020234:	4801      	ldr	r0, [pc, #4]	@ (2002023c <register_tm_clones+0x1c>)
20020236:	4718      	bx	r3
20020238:	4770      	bx	lr
2002023a:	bf00      	nop
2002023c:	20044a10 	.word	0x20044a10
20020240:	20044a10 	.word	0x20044a10
20020244:	00000000 	.word	0x00000000

20020248 <__do_global_dtors_aux>:
20020248:	b510      	push	{r4, lr}
2002024a:	4c06      	ldr	r4, [pc, #24]	@ (20020264 <__do_global_dtors_aux+0x1c>)
2002024c:	7823      	ldrb	r3, [r4, #0]
2002024e:	b943      	cbnz	r3, 20020262 <__do_global_dtors_aux+0x1a>
20020250:	f7ff ffd8 	bl	20020204 <deregister_tm_clones>
20020254:	4b04      	ldr	r3, [pc, #16]	@ (20020268 <__do_global_dtors_aux+0x20>)
20020256:	b113      	cbz	r3, 2002025e <__do_global_dtors_aux+0x16>
20020258:	4804      	ldr	r0, [pc, #16]	@ (2002026c <__do_global_dtors_aux+0x24>)
2002025a:	f3af 8000 	nop.w
2002025e:	2301      	movs	r3, #1
20020260:	7023      	strb	r3, [r4, #0]
20020262:	bd10      	pop	{r4, pc}
20020264:	20044a10 	.word	0x20044a10
20020268:	00000000 	.word	0x00000000
2002026c:	20027abc 	.word	0x20027abc

20020270 <frame_dummy>:
20020270:	b508      	push	{r3, lr}
20020272:	4b05      	ldr	r3, [pc, #20]	@ (20020288 <frame_dummy+0x18>)
20020274:	b11b      	cbz	r3, 2002027e <frame_dummy+0xe>
20020276:	4905      	ldr	r1, [pc, #20]	@ (2002028c <frame_dummy+0x1c>)
20020278:	4805      	ldr	r0, [pc, #20]	@ (20020290 <frame_dummy+0x20>)
2002027a:	f3af 8000 	nop.w
2002027e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020282:	f7ff bfcd 	b.w	20020220 <register_tm_clones>
20020286:	bf00      	nop
20020288:	00000000 	.word	0x00000000
2002028c:	20044a14 	.word	0x20044a14
20020290:	20027abc 	.word	0x20027abc

20020294 <boot_uart_tx>:
20020294:	2300      	movs	r3, #0
20020296:	b510      	push	{r4, lr}
20020298:	4293      	cmp	r3, r2
2002029a:	db00      	blt.n	2002029e <boot_uart_tx+0xa>
2002029c:	bd10      	pop	{r4, pc}
2002029e:	69c4      	ldr	r4, [r0, #28]
200202a0:	0624      	lsls	r4, r4, #24
200202a2:	d5fc      	bpl.n	2002029e <boot_uart_tx+0xa>
200202a4:	5ccc      	ldrb	r4, [r1, r3]
200202a6:	3301      	adds	r3, #1
200202a8:	6284      	str	r4, [r0, #40]	@ 0x28
200202aa:	e7f5      	b.n	20020298 <boot_uart_tx+0x4>

200202ac <mpu_config>:
200202ac:	4770      	bx	lr

200202ae <cache_enable>:
200202ae:	4770      	bx	lr

200202b0 <board_pinmux_mpi1_type1>:
200202b0:	b510      	push	{r4, lr}
200202b2:	2100      	movs	r1, #0
200202b4:	f640 3004 	movw	r0, #2820	@ 0xb04
200202b8:	f004 f8e2 	bl	20024480 <HAL_PIN_Set2>
200202bc:	2100      	movs	r1, #0
200202be:	f44f 7082 	mov.w	r0, #260	@ 0x104
200202c2:	f004 f8dd 	bl	20024480 <HAL_PIN_Set2>
200202c6:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202ca:	f640 5004 	movw	r0, #3332	@ 0xd04
200202ce:	f004 f8d7 	bl	20024480 <HAL_PIN_Set2>
200202d2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202d6:	f44f 7041 	mov.w	r0, #772	@ 0x304
200202da:	f004 f8d1 	bl	20024480 <HAL_PIN_Set2>
200202de:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202e2:	f240 5004 	movw	r0, #1284	@ 0x504
200202e6:	f004 f8cb 	bl	20024480 <HAL_PIN_Set2>
200202ea:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202ee:	f640 4004 	movw	r0, #3076	@ 0xc04
200202f2:	f004 f8c5 	bl	20024480 <HAL_PIN_Set2>
200202f6:	2400      	movs	r4, #0
200202f8:	2201      	movs	r2, #1
200202fa:	3401      	adds	r4, #1
200202fc:	4611      	mov	r1, r2
200202fe:	4620      	mov	r0, r4
20020300:	f004 f908 	bl	20024514 <HAL_PIN_Set_DS0>
20020304:	2200      	movs	r2, #0
20020306:	2101      	movs	r1, #1
20020308:	4620      	mov	r0, r4
2002030a:	f004 f919 	bl	20024540 <HAL_PIN_Set_DS1>
2002030e:	2c0d      	cmp	r4, #13
20020310:	d1f2      	bne.n	200202f8 <board_pinmux_mpi1_type1+0x48>
20020312:	bd10      	pop	{r4, pc}

20020314 <board_pinmux_mpi1_type2>:
20020314:	b510      	push	{r4, lr}
20020316:	2100      	movs	r1, #0
20020318:	f640 3004 	movw	r0, #2820	@ 0xb04
2002031c:	f004 f8b0 	bl	20024480 <HAL_PIN_Set2>
20020320:	2100      	movs	r1, #0
20020322:	f240 4004 	movw	r0, #1028	@ 0x404
20020326:	f004 f8ab 	bl	20024480 <HAL_PIN_Set2>
2002032a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002032e:	f640 5004 	movw	r0, #3332	@ 0xd04
20020332:	f004 f8a5 	bl	20024480 <HAL_PIN_Set2>
20020336:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002033a:	f44f 7041 	mov.w	r0, #772	@ 0x304
2002033e:	f004 f89f 	bl	20024480 <HAL_PIN_Set2>
20020342:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020346:	f44f 7001 	mov.w	r0, #516	@ 0x204
2002034a:	f004 f899 	bl	20024480 <HAL_PIN_Set2>
2002034e:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020352:	f640 2004 	movw	r0, #2564	@ 0xa04
20020356:	f004 f893 	bl	20024480 <HAL_PIN_Set2>
2002035a:	2400      	movs	r4, #0
2002035c:	2201      	movs	r2, #1
2002035e:	3401      	adds	r4, #1
20020360:	4611      	mov	r1, r2
20020362:	4620      	mov	r0, r4
20020364:	f004 f8d6 	bl	20024514 <HAL_PIN_Set_DS0>
20020368:	2200      	movs	r2, #0
2002036a:	2101      	movs	r1, #1
2002036c:	4620      	mov	r0, r4
2002036e:	f004 f8e7 	bl	20024540 <HAL_PIN_Set_DS1>
20020372:	2c0d      	cmp	r4, #13
20020374:	d1f2      	bne.n	2002035c <board_pinmux_mpi1_type2+0x48>
20020376:	bd10      	pop	{r4, pc}

20020378 <board_pinmux_mpi2>:
20020378:	b510      	push	{r4, lr}
2002037a:	2100      	movs	r1, #0
2002037c:	f641 2004 	movw	r0, #6660	@ 0x1a04
20020380:	f004 f87e 	bl	20024480 <HAL_PIN_Set2>
20020384:	2100      	movs	r1, #0
20020386:	f241 4004 	movw	r0, #5124	@ 0x1404
2002038a:	f004 f879 	bl	20024480 <HAL_PIN_Set2>
2002038e:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020392:	f641 0004 	movw	r0, #6148	@ 0x1804
20020396:	f004 f873 	bl	20024480 <HAL_PIN_Set2>
2002039a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002039e:	f241 3004 	movw	r0, #4868	@ 0x1304
200203a2:	f004 f86d 	bl	20024480 <HAL_PIN_Set2>
200203a6:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203aa:	f241 2004 	movw	r0, #4612	@ 0x1204
200203ae:	f004 f867 	bl	20024480 <HAL_PIN_Set2>
200203b2:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203b6:	f641 1004 	movw	r0, #6404	@ 0x1904
200203ba:	f004 f861 	bl	20024480 <HAL_PIN_Set2>
200203be:	240e      	movs	r4, #14
200203c0:	2201      	movs	r2, #1
200203c2:	4620      	mov	r0, r4
200203c4:	4611      	mov	r1, r2
200203c6:	f004 f8a5 	bl	20024514 <HAL_PIN_Set_DS0>
200203ca:	4620      	mov	r0, r4
200203cc:	2200      	movs	r2, #0
200203ce:	2101      	movs	r1, #1
200203d0:	3401      	adds	r4, #1
200203d2:	f004 f8b5 	bl	20024540 <HAL_PIN_Set_DS1>
200203d6:	2c1b      	cmp	r4, #27
200203d8:	d1f2      	bne.n	200203c0 <board_pinmux_mpi2+0x48>
200203da:	bd10      	pop	{r4, pc}

200203dc <board_pinmux_mpi3>:
200203dc:	b510      	push	{r4, lr}
200203de:	2100      	movs	r1, #0
200203e0:	f642 3001 	movw	r0, #11009	@ 0x2b01
200203e4:	f004 f84c 	bl	20024480 <HAL_PIN_Set2>
200203e8:	2100      	movs	r1, #0
200203ea:	f242 7001 	movw	r0, #9985	@ 0x2701
200203ee:	f004 f847 	bl	20024480 <HAL_PIN_Set2>
200203f2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200203f6:	f642 2001 	movw	r0, #10753	@ 0x2a01
200203fa:	f004 f841 	bl	20024480 <HAL_PIN_Set2>
200203fe:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020402:	f642 0001 	movw	r0, #10241	@ 0x2801
20020406:	f004 f83b 	bl	20024480 <HAL_PIN_Set2>
2002040a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002040e:	f642 1001 	movw	r0, #10497	@ 0x2901
20020412:	f004 f835 	bl	20024480 <HAL_PIN_Set2>
20020416:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002041a:	f642 4001 	movw	r0, #11265	@ 0x2c01
2002041e:	f004 f82f 	bl	20024480 <HAL_PIN_Set2>
20020422:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20020426:	4b13      	ldr	r3, [pc, #76]	@ (20020474 <board_pinmux_mpi3+0x98>)
20020428:	2427      	movs	r4, #39	@ 0x27
2002042a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002042e:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20020432:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020436:	f44f 4200 	mov.w	r2, #32768	@ 0x8000
2002043a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002043e:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020442:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020446:	f44f 4280 	mov.w	r2, #16384	@ 0x4000
2002044a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002044e:	f44f 3200 	mov.w	r2, #131072	@ 0x20000
20020452:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020456:	2201      	movs	r2, #1
20020458:	4620      	mov	r0, r4
2002045a:	4611      	mov	r1, r2
2002045c:	f004 f85a 	bl	20024514 <HAL_PIN_Set_DS0>
20020460:	4620      	mov	r0, r4
20020462:	2200      	movs	r2, #0
20020464:	2101      	movs	r1, #1
20020466:	3401      	adds	r4, #1
20020468:	f004 f86a 	bl	20024540 <HAL_PIN_Set_DS1>
2002046c:	2c2d      	cmp	r4, #45	@ 0x2d
2002046e:	d1f2      	bne.n	20020456 <board_pinmux_mpi3+0x7a>
20020470:	bd10      	pop	{r4, pc}
20020472:	bf00      	nop
20020474:	500ca000 	.word	0x500ca000

20020478 <board_pinmux_sd>:
20020478:	b510      	push	{r4, lr}
2002047a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002047e:	f642 2002 	movw	r0, #10754	@ 0x2a02
20020482:	f003 fffd 	bl	20024480 <HAL_PIN_Set2>
20020486:	f44f 4300 	mov.w	r3, #32768	@ 0x8000
2002048a:	4c1c      	ldr	r4, [pc, #112]	@ (200204fc <board_pinmux_sd+0x84>)
2002048c:	2014      	movs	r0, #20
2002048e:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
20020492:	f001 faae 	bl	200219f2 <HAL_Delay_us>
20020496:	2100      	movs	r1, #0
20020498:	f642 1002 	movw	r0, #10498	@ 0x2902
2002049c:	f003 fff0 	bl	20024480 <HAL_PIN_Set2>
200204a0:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204a4:	f642 3002 	movw	r0, #11010	@ 0x2b02
200204a8:	f003 ffea 	bl	20024480 <HAL_PIN_Set2>
200204ac:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204b0:	f642 4002 	movw	r0, #11266	@ 0x2c02
200204b4:	f003 ffe4 	bl	20024480 <HAL_PIN_Set2>
200204b8:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204bc:	f242 7002 	movw	r0, #9986	@ 0x2702
200204c0:	f003 ffde 	bl	20024480 <HAL_PIN_Set2>
200204c4:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204c8:	f642 0002 	movw	r0, #10242	@ 0x2802
200204cc:	f003 ffd8 	bl	20024480 <HAL_PIN_Set2>
200204d0:	f44f 4380 	mov.w	r3, #16384	@ 0x4000
200204d4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204d8:	f44f 3380 	mov.w	r3, #65536	@ 0x10000
200204dc:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e0:	f44f 3300 	mov.w	r3, #131072	@ 0x20000
200204e4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e8:	f44f 5380 	mov.w	r3, #4096	@ 0x1000
200204ec:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f0:	f44f 5300 	mov.w	r3, #8192	@ 0x2000
200204f4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f8:	bd10      	pop	{r4, pc}
200204fa:	bf00      	nop
200204fc:	500ca000 	.word	0x500ca000

20020500 <board_boot_from>:
20020500:	b508      	push	{r3, lr}
20020502:	2000      	movs	r0, #0
20020504:	f007 fc82 	bl	20027e0c <HAL_Get_backup>
20020508:	f000 000f 	and.w	r0, r0, #15
2002050c:	bd08      	pop	{r3, pc}

2002050e <board_init>:
2002050e:	f004 bb6b 	b.w	20024be8 <BSP_System_Config>

20020512 <bootloader_switch_clock>:
20020512:	2102      	movs	r1, #2
20020514:	2004      	movs	r0, #4
20020516:	f004 b97d 	b.w	20024814 <HAL_RCC_HCPU_ClockSelect>

2002051a <board_init_psram>:
2002051a:	2201      	movs	r2, #1
2002051c:	b508      	push	{r3, lr}
2002051e:	4611      	mov	r1, r2
20020520:	2000      	movs	r0, #0
20020522:	f007 fc99 	bl	20027e58 <HAL_PMU_ConfigPeriLdo>
20020526:	2001      	movs	r0, #1
20020528:	f7ff fff3 	bl	20020512 <bootloader_switch_clock>
2002052c:	2002      	movs	r0, #2
2002052e:	f001 f911 	bl	20021754 <BSP_SetFlash1DIV>
20020532:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020536:	f001 b8c5 	b.w	200216c4 <bsp_psramc_init>
	...

2002053c <erase_nor>:
2002053c:	b570      	push	{r4, r5, r6, lr}
2002053e:	4b13      	ldr	r3, [pc, #76]	@ (2002058c <erase_nor+0x50>)
20020540:	460c      	mov	r4, r1
20020542:	681e      	ldr	r6, [r3, #0]
20020544:	6933      	ldr	r3, [r6, #16]
20020546:	4283      	cmp	r3, r0
20020548:	d901      	bls.n	2002054e <erase_nor+0x12>
2002054a:	2001      	movs	r0, #1
2002054c:	bd70      	pop	{r4, r5, r6, pc}
2002054e:	6972      	ldr	r2, [r6, #20]
20020550:	441a      	add	r2, r3
20020552:	4282      	cmp	r2, r0
20020554:	d3f9      	bcc.n	2002054a <erase_nor+0xe>
20020556:	1ac0      	subs	r0, r0, r3
20020558:	f3c0 030b 	ubfx	r3, r0, #0, #12
2002055c:	b97b      	cbnz	r3, 2002057e <erase_nor+0x42>
2002055e:	f3c1 030b 	ubfx	r3, r1, #0, #12
20020562:	b97b      	cbnz	r3, 20020584 <erase_nor+0x48>
20020564:	1845      	adds	r5, r0, r1
20020566:	1b29      	subs	r1, r5, r4
20020568:	b90c      	cbnz	r4, 2002056e <erase_nor+0x32>
2002056a:	4620      	mov	r0, r4
2002056c:	e7ee      	b.n	2002054c <erase_nor+0x10>
2002056e:	4630      	mov	r0, r6
20020570:	f003 f8f1 	bl	20023756 <HAL_QSPIEX_SECT_ERASE>
20020574:	2800      	cmp	r0, #0
20020576:	d1e8      	bne.n	2002054a <erase_nor+0xe>
20020578:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
2002057c:	e7f3      	b.n	20020566 <erase_nor+0x2a>
2002057e:	f04f 30ff 	mov.w	r0, #4294967295
20020582:	e7e3      	b.n	2002054c <erase_nor+0x10>
20020584:	f06f 0001 	mvn.w	r0, #1
20020588:	e7e0      	b.n	2002054c <erase_nor+0x10>
2002058a:	bf00      	nop
2002058c:	20046d38 	.word	0x20046d38

20020590 <write_nor>:
20020590:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020594:	4b1e      	ldr	r3, [pc, #120]	@ (20020610 <write_nor+0x80>)
20020596:	460f      	mov	r7, r1
20020598:	f8d3 8000 	ldr.w	r8, [r3]
2002059c:	4616      	mov	r6, r2
2002059e:	f8d8 5010 	ldr.w	r5, [r8, #16]
200205a2:	4285      	cmp	r5, r0
200205a4:	d902      	bls.n	200205ac <write_nor+0x1c>
200205a6:	2000      	movs	r0, #0
200205a8:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200205ac:	f8d8 2014 	ldr.w	r2, [r8, #20]
200205b0:	442a      	add	r2, r5
200205b2:	4282      	cmp	r2, r0
200205b4:	d3f7      	bcc.n	200205a6 <write_nor+0x16>
200205b6:	1b45      	subs	r5, r0, r5
200205b8:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
200205bc:	d012      	beq.n	200205e4 <write_nor+0x54>
200205be:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
200205c2:	42b4      	cmp	r4, r6
200205c4:	bf28      	it	cs
200205c6:	4634      	movcs	r4, r6
200205c8:	460a      	mov	r2, r1
200205ca:	4623      	mov	r3, r4
200205cc:	4629      	mov	r1, r5
200205ce:	4640      	mov	r0, r8
200205d0:	f002 ffdc 	bl	2002358c <HAL_QSPIEX_WRITE_PAGE>
200205d4:	4284      	cmp	r4, r0
200205d6:	d1e6      	bne.n	200205a6 <write_nor+0x16>
200205d8:	4425      	add	r5, r4
200205da:	4427      	add	r7, r4
200205dc:	1b34      	subs	r4, r6, r4
200205de:	b91c      	cbnz	r4, 200205e8 <write_nor+0x58>
200205e0:	4630      	mov	r0, r6
200205e2:	e7e1      	b.n	200205a8 <write_nor+0x18>
200205e4:	4634      	mov	r4, r6
200205e6:	e7fa      	b.n	200205de <write_nor+0x4e>
200205e8:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
200205ec:	46a1      	mov	r9, r4
200205ee:	bf28      	it	cs
200205f0:	f44f 7980 	movcs.w	r9, #256	@ 0x100
200205f4:	463a      	mov	r2, r7
200205f6:	464b      	mov	r3, r9
200205f8:	4629      	mov	r1, r5
200205fa:	4640      	mov	r0, r8
200205fc:	f002 ffc6 	bl	2002358c <HAL_QSPIEX_WRITE_PAGE>
20020600:	4581      	cmp	r9, r0
20020602:	d1d0      	bne.n	200205a6 <write_nor+0x16>
20020604:	444d      	add	r5, r9
20020606:	444f      	add	r7, r9
20020608:	eba4 0409 	sub.w	r4, r4, r9
2002060c:	e7e7      	b.n	200205de <write_nor+0x4e>
2002060e:	bf00      	nop
20020610:	20046d38 	.word	0x20046d38

20020614 <read_nor>:
20020614:	460b      	mov	r3, r1
20020616:	b510      	push	{r4, lr}
20020618:	4614      	mov	r4, r2
2002061a:	4601      	mov	r1, r0
2002061c:	4618      	mov	r0, r3
2002061e:	f005 febc 	bl	2002639a <memcpy>
20020622:	4620      	mov	r0, r4
20020624:	bd10      	pop	{r4, pc}
	...

20020628 <read_nand>:
20020628:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002062c:	2600      	movs	r6, #0
2002062e:	460f      	mov	r7, r1
20020630:	4615      	mov	r5, r2
20020632:	46b0      	mov	r8, r6
20020634:	4b19      	ldr	r3, [pc, #100]	@ (2002069c <read_nand+0x74>)
20020636:	f8df a068 	ldr.w	sl, [pc, #104]	@ 200206a0 <read_nand+0x78>
2002063a:	681b      	ldr	r3, [r3, #0]
2002063c:	f8df b064 	ldr.w	fp, [pc, #100]	@ 200206a4 <read_nand+0x7c>
20020640:	691b      	ldr	r3, [r3, #16]
20020642:	4604      	mov	r4, r0
20020644:	4283      	cmp	r3, r0
20020646:	b085      	sub	sp, #20
20020648:	bf98      	it	ls
2002064a:	1ac4      	subls	r4, r0, r3
2002064c:	b91d      	cbnz	r5, 20020656 <read_nand+0x2e>
2002064e:	4630      	mov	r0, r6
20020650:	b005      	add	sp, #20
20020652:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020656:	f8da 1000 	ldr.w	r1, [sl]
2002065a:	f8db 0000 	ldr.w	r0, [fp]
2002065e:	42a9      	cmp	r1, r5
20020660:	fbb0 fcf1 	udiv	ip, r0, r1
20020664:	4689      	mov	r9, r1
20020666:	f101 32ff 	add.w	r2, r1, #4294967295
2002066a:	bf28      	it	cs
2002066c:	46a9      	movcs	r9, r5
2002066e:	fbb4 f1f1 	udiv	r1, r4, r1
20020672:	f10c 3cff 	add.w	ip, ip, #4294967295
20020676:	fbb4 f0f0 	udiv	r0, r4, r0
2002067a:	e9cd 8801 	strd	r8, r8, [sp, #4]
2002067e:	f8cd 9000 	str.w	r9, [sp]
20020682:	19bb      	adds	r3, r7, r6
20020684:	4022      	ands	r2, r4
20020686:	ea0c 0101 	and.w	r1, ip, r1
2002068a:	f004 fe95 	bl	200253b8 <bbm_read_page>
2002068e:	4548      	cmp	r0, r9
20020690:	d1dd      	bne.n	2002064e <read_nand+0x26>
20020692:	4406      	add	r6, r0
20020694:	1a2d      	subs	r5, r5, r0
20020696:	4404      	add	r4, r0
20020698:	e7d8      	b.n	2002064c <read_nand+0x24>
2002069a:	bf00      	nop
2002069c:	20046d38 	.word	0x20046d38
200206a0:	20042c04 	.word	0x20042c04
200206a4:	20042c00 	.word	0x20042c00

200206a8 <read_sdnand>:
200206a8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200206ac:	f3c0 0408 	ubfx	r4, r0, #0, #9
200206b0:	460e      	mov	r6, r1
200206b2:	4615      	mov	r5, r2
200206b4:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
200206b8:	b38c      	cbz	r4, 2002071e <read_sdnand+0x76>
200206ba:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 20020734 <read_sdnand+0x8c>
200206be:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
200206c2:	eba8 0004 	sub.w	r0, r8, r4
200206c6:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206ca:	4649      	mov	r1, r9
200206cc:	f000 fed2 	bl	20021474 <sd_read_data>
200206d0:	42af      	cmp	r7, r5
200206d2:	bf28      	it	cs
200206d4:	462f      	movcs	r7, r5
200206d6:	4630      	mov	r0, r6
200206d8:	eb09 0104 	add.w	r1, r9, r4
200206dc:	463a      	mov	r2, r7
200206de:	f005 fe5c 	bl	2002639a <memcpy>
200206e2:	1bec      	subs	r4, r5, r7
200206e4:	44b8      	add	r8, r7
200206e6:	443e      	add	r6, r7
200206e8:	2700      	movs	r7, #0
200206ea:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
200206ee:	f02a 0a01 	bic.w	sl, sl, #1
200206f2:	4557      	cmp	r7, sl
200206f4:	eb07 0906 	add.w	r9, r7, r6
200206f8:	eb08 0007 	add.w	r0, r8, r7
200206fc:	d111      	bne.n	20020722 <read_sdnand+0x7a>
200206fe:	f3c4 0408 	ubfx	r4, r4, #0, #9
20020702:	b14c      	cbz	r4, 20020718 <read_sdnand+0x70>
20020704:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020708:	490a      	ldr	r1, [pc, #40]	@ (20020734 <read_sdnand+0x8c>)
2002070a:	f000 feb3 	bl	20021474 <sd_read_data>
2002070e:	4622      	mov	r2, r4
20020710:	4648      	mov	r0, r9
20020712:	4908      	ldr	r1, [pc, #32]	@ (20020734 <read_sdnand+0x8c>)
20020714:	f005 fe41 	bl	2002639a <memcpy>
20020718:	4628      	mov	r0, r5
2002071a:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002071e:	4614      	mov	r4, r2
20020720:	e7e2      	b.n	200206e8 <read_sdnand+0x40>
20020722:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020726:	4649      	mov	r1, r9
20020728:	f000 fea4 	bl	20021474 <sd_read_data>
2002072c:	f507 7700 	add.w	r7, r7, #512	@ 0x200
20020730:	e7df      	b.n	200206f2 <read_sdnand+0x4a>
20020732:	bf00      	nop
20020734:	20046b34 	.word	0x20046b34

20020738 <read_sdemmc>:
20020738:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
2002073c:	f3c0 0408 	ubfx	r4, r0, #0, #9
20020740:	460e      	mov	r6, r1
20020742:	4615      	mov	r5, r2
20020744:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020748:	b38c      	cbz	r4, 200207ae <read_sdemmc+0x76>
2002074a:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 200207c4 <read_sdemmc+0x8c>
2002074e:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
20020752:	eba8 0004 	sub.w	r0, r8, r4
20020756:	f44f 7200 	mov.w	r2, #512	@ 0x200
2002075a:	4649      	mov	r1, r9
2002075c:	f000 fd2e 	bl	200211bc <emmc_read_data>
20020760:	42af      	cmp	r7, r5
20020762:	bf28      	it	cs
20020764:	462f      	movcs	r7, r5
20020766:	4630      	mov	r0, r6
20020768:	eb09 0104 	add.w	r1, r9, r4
2002076c:	463a      	mov	r2, r7
2002076e:	f005 fe14 	bl	2002639a <memcpy>
20020772:	1bec      	subs	r4, r5, r7
20020774:	44b8      	add	r8, r7
20020776:	443e      	add	r6, r7
20020778:	2700      	movs	r7, #0
2002077a:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
2002077e:	f02a 0a01 	bic.w	sl, sl, #1
20020782:	4557      	cmp	r7, sl
20020784:	eb07 0906 	add.w	r9, r7, r6
20020788:	eb08 0007 	add.w	r0, r8, r7
2002078c:	d111      	bne.n	200207b2 <read_sdemmc+0x7a>
2002078e:	f3c4 0408 	ubfx	r4, r4, #0, #9
20020792:	b14c      	cbz	r4, 200207a8 <read_sdemmc+0x70>
20020794:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020798:	490a      	ldr	r1, [pc, #40]	@ (200207c4 <read_sdemmc+0x8c>)
2002079a:	f000 fd0f 	bl	200211bc <emmc_read_data>
2002079e:	4622      	mov	r2, r4
200207a0:	4648      	mov	r0, r9
200207a2:	4908      	ldr	r1, [pc, #32]	@ (200207c4 <read_sdemmc+0x8c>)
200207a4:	f005 fdf9 	bl	2002639a <memcpy>
200207a8:	4628      	mov	r0, r5
200207aa:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200207ae:	4614      	mov	r4, r2
200207b0:	e7e2      	b.n	20020778 <read_sdemmc+0x40>
200207b2:	f44f 7200 	mov.w	r2, #512	@ 0x200
200207b6:	4649      	mov	r1, r9
200207b8:	f000 fd00 	bl	200211bc <emmc_read_data>
200207bc:	f507 7700 	add.w	r7, r7, #512	@ 0x200
200207c0:	e7df      	b.n	20020782 <read_sdemmc+0x4a>
200207c2:	bf00      	nop
200207c4:	20046b34 	.word	0x20046b34

200207c8 <port_read_page>:
200207c8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200207cc:	4615      	mov	r5, r2
200207ce:	460e      	mov	r6, r1
200207d0:	492b      	ldr	r1, [pc, #172]	@ (20020880 <port_read_page+0xb8>)
200207d2:	461a      	mov	r2, r3
200207d4:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
200207d8:	680f      	ldr	r7, [r1, #0]
200207da:	18e9      	adds	r1, r5, r3
200207dc:	428f      	cmp	r7, r1
200207de:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
200207e2:	d200      	bcs.n	200207e6 <port_read_page+0x1e>
200207e4:	e7fe      	b.n	200207e4 <port_read_page+0x1c>
200207e6:	4927      	ldr	r1, [pc, #156]	@ (20020884 <port_read_page+0xbc>)
200207e8:	f107 0980 	add.w	r9, r7, #128	@ 0x80
200207ec:	f1b9 0f00 	cmp.w	r9, #0
200207f0:	6809      	ldr	r1, [r1, #0]
200207f2:	dd18      	ble.n	20020826 <port_read_page+0x5e>
200207f4:	4c24      	ldr	r4, [pc, #144]	@ (20020888 <port_read_page+0xc0>)
200207f6:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
200207fa:	f004 081f 	and.w	r8, r4, #31
200207fe:	44c8      	add	r8, r9
20020800:	f024 041f 	bic.w	r4, r4, #31
20020804:	f3bf 8f4f 	dsb	sy
20020808:	f8df a084 	ldr.w	sl, [pc, #132]	@ 20020890 <port_read_page+0xc8>
2002080c:	44a0      	add	r8, r4
2002080e:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
20020812:	3420      	adds	r4, #32
20020814:	eba8 0904 	sub.w	r9, r8, r4
20020818:	f1b9 0f00 	cmp.w	r9, #0
2002081c:	dcf7      	bgt.n	2002080e <port_read_page+0x46>
2002081e:	f3bf 8f4f 	dsb	sy
20020822:	f3bf 8f6f 	isb	sy
20020826:	07c4      	lsls	r4, r0, #31
20020828:	d51e      	bpl.n	20020868 <port_read_page+0xa0>
2002082a:	4c17      	ldr	r4, [pc, #92]	@ (20020888 <port_read_page+0xc0>)
2002082c:	f894 80d7 	ldrb.w	r8, [r4, #215]	@ 0xd7
20020830:	f1b8 0f00 	cmp.w	r8, #0
20020834:	d018      	beq.n	20020868 <port_read_page+0xa0>
20020836:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
2002083a:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
2002083e:	f004 041f 	and.w	r4, r4, #31
20020842:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020846:	f028 081f 	bic.w	r8, r8, #31
2002084a:	f3bf 8f4f 	dsb	sy
2002084e:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 20020890 <port_read_page+0xc8>
20020852:	3c20      	subs	r4, #32
20020854:	2c00      	cmp	r4, #0
20020856:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
2002085a:	f108 0820 	add.w	r8, r8, #32
2002085e:	dcf8      	bgt.n	20020852 <port_read_page+0x8a>
20020860:	f3bf 8f4f 	dsb	sy
20020864:	f3bf 8f6f 	isb	sy
20020868:	fb07 5506 	mla	r5, r7, r6, r5
2002086c:	e9cd ce08 	strd	ip, lr, [sp, #32]
20020870:	fb01 5100 	mla	r1, r1, r0, r5
20020874:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020878:	4804      	ldr	r0, [pc, #16]	@ (2002088c <port_read_page+0xc4>)
2002087a:	f002 bda5 	b.w	200233c8 <HAL_NAND_READ_WITHOOB>
2002087e:	bf00      	nop
20020880:	20042c04 	.word	0x20042c04
20020884:	20042c00 	.word	0x20042c00
20020888:	20046f78 	.word	0x20046f78
2002088c:	20047020 	.word	0x20047020
20020890:	e000ed00 	.word	0xe000ed00

20020894 <bbm_get_bb>:
20020894:	b410      	push	{r4}
20020896:	4b1e      	ldr	r3, [pc, #120]	@ (20020910 <bbm_get_bb+0x7c>)
20020898:	4601      	mov	r1, r0
2002089a:	6818      	ldr	r0, [r3, #0]
2002089c:	3080      	adds	r0, #128	@ 0x80
2002089e:	2800      	cmp	r0, #0
200208a0:	dd14      	ble.n	200208cc <bbm_get_bb+0x38>
200208a2:	4b1c      	ldr	r3, [pc, #112]	@ (20020914 <bbm_get_bb+0x80>)
200208a4:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208a6:	f003 021f 	and.w	r2, r3, #31
200208aa:	4402      	add	r2, r0
200208ac:	f023 031f 	bic.w	r3, r3, #31
200208b0:	f3bf 8f4f 	dsb	sy
200208b4:	4c18      	ldr	r4, [pc, #96]	@ (20020918 <bbm_get_bb+0x84>)
200208b6:	441a      	add	r2, r3
200208b8:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
200208bc:	3320      	adds	r3, #32
200208be:	1ad0      	subs	r0, r2, r3
200208c0:	2800      	cmp	r0, #0
200208c2:	dcf9      	bgt.n	200208b8 <bbm_get_bb+0x24>
200208c4:	f3bf 8f4f 	dsb	sy
200208c8:	f3bf 8f6f 	isb	sy
200208cc:	07cb      	lsls	r3, r1, #31
200208ce:	d51a      	bpl.n	20020906 <bbm_get_bb+0x72>
200208d0:	4b10      	ldr	r3, [pc, #64]	@ (20020914 <bbm_get_bb+0x80>)
200208d2:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
200208d6:	b1b2      	cbz	r2, 20020906 <bbm_get_bb+0x72>
200208d8:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208da:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
200208de:	f003 031f 	and.w	r3, r3, #31
200208e2:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
200208e6:	f022 021f 	bic.w	r2, r2, #31
200208ea:	f3bf 8f4f 	dsb	sy
200208ee:	480a      	ldr	r0, [pc, #40]	@ (20020918 <bbm_get_bb+0x84>)
200208f0:	3b20      	subs	r3, #32
200208f2:	2b00      	cmp	r3, #0
200208f4:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
200208f8:	f102 0220 	add.w	r2, r2, #32
200208fc:	dcf8      	bgt.n	200208f0 <bbm_get_bb+0x5c>
200208fe:	f3bf 8f4f 	dsb	sy
20020902:	f3bf 8f6f 	isb	sy
20020906:	4805      	ldr	r0, [pc, #20]	@ (2002091c <bbm_get_bb+0x88>)
20020908:	f85d 4b04 	ldr.w	r4, [sp], #4
2002090c:	f002 be1d 	b.w	2002354a <HAL_NAND_GET_BADBLK>
20020910:	20042c04 	.word	0x20042c04
20020914:	20046f78 	.word	0x20046f78
20020918:	e000ed00 	.word	0xe000ed00
2002091c:	20046fcc 	.word	0x20046fcc

20020920 <boot_device_init>:
20020920:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020924:	b08c      	sub	sp, #48	@ 0x30
20020926:	f001 fda7 	bl	20022478 <HAL_HPAON_EnableXT48>
2002092a:	2101      	movs	r1, #1
2002092c:	2000      	movs	r0, #0
2002092e:	f003 ff71 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20020932:	2101      	movs	r1, #1
20020934:	200c      	movs	r0, #12
20020936:	f003 ff6d 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
2002093a:	2001      	movs	r0, #1
2002093c:	f003 fe16 	bl	2002456c <HAL_PMU_EnableDLL>
20020940:	4fa3      	ldr	r7, [pc, #652]	@ (20020bd0 <boot_device_init+0x2b0>)
20020942:	2090      	movs	r0, #144	@ 0x90
20020944:	f004 f8cc 	bl	20024ae0 <HAL_RCC_HCPU_ConfigHCLK>
20020948:	48a2      	ldr	r0, [pc, #648]	@ (20020bd4 <boot_device_init+0x2b4>)
2002094a:	f003 ff2b 	bl	200247a4 <HAL_RCC_HCPU_EnableDLL2>
2002094e:	783b      	ldrb	r3, [r7, #0]
20020950:	4ca1      	ldr	r4, [pc, #644]	@ (20020bd8 <boot_device_init+0x2b8>)
20020952:	2b06      	cmp	r3, #6
20020954:	f200 8137 	bhi.w	20020bc6 <boot_device_init+0x2a6>
20020958:	e8df f013 	tbh	[pc, r3, lsl #1]
2002095c:	00440007 	.word	0x00440007
20020960:	009f0044 	.word	0x009f0044
20020964:	011b009f 	.word	0x011b009f
20020968:	012a      	.short	0x012a
2002096a:	2006      	movs	r0, #6
2002096c:	4e9b      	ldr	r6, [pc, #620]	@ (20020bdc <boot_device_init+0x2bc>)
2002096e:	f000 fef7 	bl	20021760 <BSP_SetFlash2DIV>
20020972:	ad02      	add	r5, sp, #8
20020974:	2102      	movs	r1, #2
20020976:	2006      	movs	r0, #6
20020978:	f003 ff4c 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
2002097c:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002097e:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020980:	6833      	ldr	r3, [r6, #0]
20020982:	2210      	movs	r2, #16
20020984:	2100      	movs	r1, #0
20020986:	602b      	str	r3, [r5, #0]
20020988:	a808      	add	r0, sp, #32
2002098a:	f005 fc97 	bl	200262bc <memset>
2002098e:	4b94      	ldr	r3, [pc, #592]	@ (20020be0 <boot_device_init+0x2c0>)
20020990:	2601      	movs	r6, #1
20020992:	9307      	str	r3, [sp, #28]
20020994:	2333      	movs	r3, #51	@ 0x33
20020996:	960a      	str	r6, [sp, #40]	@ 0x28
20020998:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
2002099c:	f7ff fcec 	bl	20020378 <board_pinmux_mpi2>
200209a0:	2302      	movs	r3, #2
200209a2:	4d90      	ldr	r5, [pc, #576]	@ (20020be4 <boot_device_init+0x2c4>)
200209a4:	9303      	str	r3, [sp, #12]
200209a6:	4b90      	ldr	r3, [pc, #576]	@ (20020be8 <boot_device_init+0x2c8>)
200209a8:	2000      	movs	r0, #0
200209aa:	6023      	str	r3, [r4, #0]
200209ac:	f001 f821 	bl	200219f2 <HAL_Delay_us>
200209b0:	f885 6099 	strb.w	r6, [r5, #153]	@ 0x99
200209b4:	f000 fec2 	bl	2002173c <BSP_GetFlash2DIV>
200209b8:	f105 0654 	add.w	r6, r5, #84	@ 0x54
200209bc:	4a8b      	ldr	r2, [pc, #556]	@ (20020bec <boot_device_init+0x2cc>)
200209be:	9000      	str	r0, [sp, #0]
200209c0:	ab07      	add	r3, sp, #28
200209c2:	4630      	mov	r0, r6
200209c4:	a902      	add	r1, sp, #8
200209c6:	f002 ff79 	bl	200238bc <HAL_FLASH_Init>
200209ca:	4b89      	ldr	r3, [pc, #548]	@ (20020bf0 <boot_device_init+0x2d0>)
200209cc:	4a89      	ldr	r2, [pc, #548]	@ (20020bf4 <boot_device_init+0x2d4>)
200209ce:	601a      	str	r2, [r3, #0]
200209d0:	4a89      	ldr	r2, [pc, #548]	@ (20020bf8 <boot_device_init+0x2d8>)
200209d2:	4b8a      	ldr	r3, [pc, #552]	@ (20020bfc <boot_device_init+0x2dc>)
200209d4:	601a      	str	r2, [r3, #0]
200209d6:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
200209da:	4b89      	ldr	r3, [pc, #548]	@ (20020c00 <boot_device_init+0x2e0>)
200209dc:	601a      	str	r2, [r3, #0]
200209de:	4b89      	ldr	r3, [pc, #548]	@ (20020c04 <boot_device_init+0x2e4>)
200209e0:	601e      	str	r6, [r3, #0]
200209e2:	e037      	b.n	20020a54 <boot_device_init+0x134>
200209e4:	2006      	movs	r0, #6
200209e6:	4e88      	ldr	r6, [pc, #544]	@ (20020c08 <boot_device_init+0x2e8>)
200209e8:	f000 feb4 	bl	20021754 <BSP_SetFlash1DIV>
200209ec:	ad02      	add	r5, sp, #8
200209ee:	2102      	movs	r1, #2
200209f0:	2004      	movs	r0, #4
200209f2:	f003 ff0f 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
200209f6:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
200209f8:	c50f      	stmia	r5!, {r0, r1, r2, r3}
200209fa:	6833      	ldr	r3, [r6, #0]
200209fc:	2210      	movs	r2, #16
200209fe:	602b      	str	r3, [r5, #0]
20020a00:	2100      	movs	r1, #0
20020a02:	a808      	add	r0, sp, #32
20020a04:	f005 fc5a 	bl	200262bc <memset>
20020a08:	4b80      	ldr	r3, [pc, #512]	@ (20020c0c <boot_device_init+0x2ec>)
20020a0a:	4d76      	ldr	r5, [pc, #472]	@ (20020be4 <boot_device_init+0x2c4>)
20020a0c:	9307      	str	r3, [sp, #28]
20020a0e:	2332      	movs	r3, #50	@ 0x32
20020a10:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020a14:	2301      	movs	r3, #1
20020a16:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
20020a1a:	783b      	ldrb	r3, [r7, #0]
20020a1c:	2b01      	cmp	r3, #1
20020a1e:	d139      	bne.n	20020a94 <boot_device_init+0x174>
20020a20:	f7ff fc46 	bl	200202b0 <board_pinmux_mpi1_type1>
20020a24:	2302      	movs	r3, #2
20020a26:	9303      	str	r3, [sp, #12]
20020a28:	f000 fe82 	bl	20021730 <BSP_GetFlash1DIV>
20020a2c:	4a78      	ldr	r2, [pc, #480]	@ (20020c10 <boot_device_init+0x2f0>)
20020a2e:	9000      	str	r0, [sp, #0]
20020a30:	ab07      	add	r3, sp, #28
20020a32:	486c      	ldr	r0, [pc, #432]	@ (20020be4 <boot_device_init+0x2c4>)
20020a34:	a902      	add	r1, sp, #8
20020a36:	f002 ff41 	bl	200238bc <HAL_FLASH_Init>
20020a3a:	4b6b      	ldr	r3, [pc, #428]	@ (20020be8 <boot_device_init+0x2c8>)
20020a3c:	4a6d      	ldr	r2, [pc, #436]	@ (20020bf4 <boot_device_init+0x2d4>)
20020a3e:	6023      	str	r3, [r4, #0]
20020a40:	4b6b      	ldr	r3, [pc, #428]	@ (20020bf0 <boot_device_init+0x2d0>)
20020a42:	601a      	str	r2, [r3, #0]
20020a44:	4b6d      	ldr	r3, [pc, #436]	@ (20020bfc <boot_device_init+0x2dc>)
20020a46:	4a6c      	ldr	r2, [pc, #432]	@ (20020bf8 <boot_device_init+0x2d8>)
20020a48:	601a      	str	r2, [r3, #0]
20020a4a:	4b6d      	ldr	r3, [pc, #436]	@ (20020c00 <boot_device_init+0x2e0>)
20020a4c:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020a4e:	601a      	str	r2, [r3, #0]
20020a50:	4b6c      	ldr	r3, [pc, #432]	@ (20020c04 <boot_device_init+0x2e4>)
20020a52:	601d      	str	r5, [r3, #0]
20020a54:	6823      	ldr	r3, [r4, #0]
20020a56:	2b00      	cmp	r3, #0
20020a58:	f000 8110 	beq.w	20020c7c <boot_device_init+0x35c>
20020a5c:	4e68      	ldr	r6, [pc, #416]	@ (20020c00 <boot_device_init+0x2e0>)
20020a5e:	6830      	ldr	r0, [r6, #0]
20020a60:	2800      	cmp	r0, #0
20020a62:	f000 810b 	beq.w	20020c7c <boot_device_init+0x35c>
20020a66:	4d6b      	ldr	r5, [pc, #428]	@ (20020c14 <boot_device_init+0x2f4>)
20020a68:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020a6c:	4629      	mov	r1, r5
20020a6e:	4798      	blx	r3
20020a70:	682a      	ldr	r2, [r5, #0]
20020a72:	4b69      	ldr	r3, [pc, #420]	@ (20020c18 <boot_device_init+0x2f8>)
20020a74:	7839      	ldrb	r1, [r7, #0]
20020a76:	429a      	cmp	r2, r3
20020a78:	f040 80fb 	bne.w	20020c72 <boot_device_init+0x352>
20020a7c:	2904      	cmp	r1, #4
20020a7e:	d105      	bne.n	20020a8c <boot_device_init+0x16c>
20020a80:	f8d5 30a4 	ldr.w	r3, [r5, #164]	@ 0xa4
20020a84:	1e5a      	subs	r2, r3, #1
20020a86:	3203      	adds	r2, #3
20020a88:	f240 80e2 	bls.w	20020c50 <boot_device_init+0x330>
20020a8c:	2001      	movs	r0, #1
20020a8e:	b00c      	add	sp, #48	@ 0x30
20020a90:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020a94:	f7ff fc3e 	bl	20020314 <board_pinmux_mpi1_type2>
20020a98:	e7c4      	b.n	20020a24 <boot_device_init+0x104>
20020a9a:	2006      	movs	r0, #6
20020a9c:	4e5f      	ldr	r6, [pc, #380]	@ (20020c1c <boot_device_init+0x2fc>)
20020a9e:	f000 fe65 	bl	2002176c <BSP_SetFlash3DIV>
20020aa2:	ad02      	add	r5, sp, #8
20020aa4:	2102      	movs	r1, #2
20020aa6:	2008      	movs	r0, #8
20020aa8:	f003 feb4 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20020aac:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020aae:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020ab0:	f897 8000 	ldrb.w	r8, [r7]
20020ab4:	6833      	ldr	r3, [r6, #0]
20020ab6:	f1b8 0a03 	subs.w	sl, r8, #3
20020aba:	602b      	str	r3, [r5, #0]
20020abc:	f04f 0210 	mov.w	r2, #16
20020ac0:	f04f 0100 	mov.w	r1, #0
20020ac4:	a808      	add	r0, sp, #32
20020ac6:	bf18      	it	ne
20020ac8:	f04f 0a01 	movne.w	sl, #1
20020acc:	f005 fbf6 	bl	200262bc <memset>
20020ad0:	4b4e      	ldr	r3, [pc, #312]	@ (20020c0c <boot_device_init+0x2ec>)
20020ad2:	2502      	movs	r5, #2
20020ad4:	9307      	str	r3, [sp, #28]
20020ad6:	2332      	movs	r3, #50	@ 0x32
20020ad8:	950a      	str	r5, [sp, #40]	@ 0x28
20020ada:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020ade:	f7ff fc7d 	bl	200203dc <board_pinmux_mpi3>
20020ae2:	f1b8 0f03 	cmp.w	r8, #3
20020ae6:	9503      	str	r5, [sp, #12]
20020ae8:	4d3e      	ldr	r5, [pc, #248]	@ (20020be4 <boot_device_init+0x2c4>)
20020aea:	d045      	beq.n	20020b78 <boot_device_init+0x258>
20020aec:	4b4c      	ldr	r3, [pc, #304]	@ (20020c20 <boot_device_init+0x300>)
20020aee:	6023      	str	r3, [r4, #0]
20020af0:	9b04      	ldr	r3, [sp, #16]
20020af2:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020af6:	9304      	str	r3, [sp, #16]
20020af8:	2301      	movs	r3, #1
20020afa:	9306      	str	r3, [sp, #24]
20020afc:	4b49      	ldr	r3, [pc, #292]	@ (20020c24 <boot_device_init+0x304>)
20020afe:	f8c5 30c4 	str.w	r3, [r5, #196]	@ 0xc4
20020b02:	f04f 0901 	mov.w	r9, #1
20020b06:	2000      	movs	r0, #0
20020b08:	f000 ff73 	bl	200219f2 <HAL_Delay_us>
20020b0c:	f885 90ed 	strb.w	r9, [r5, #237]	@ 0xed
20020b10:	f885 a0ec 	strb.w	sl, [r5, #236]	@ 0xec
20020b14:	f000 fe18 	bl	20021748 <BSP_GetFlash3DIV>
20020b18:	4a43      	ldr	r2, [pc, #268]	@ (20020c28 <boot_device_init+0x308>)
20020b1a:	9000      	str	r0, [sp, #0]
20020b1c:	ab07      	add	r3, sp, #28
20020b1e:	4843      	ldr	r0, [pc, #268]	@ (20020c2c <boot_device_init+0x30c>)
20020b20:	a902      	add	r1, sp, #8
20020b22:	f002 fecb 	bl	200238bc <HAL_FLASH_Init>
20020b26:	4e41      	ldr	r6, [pc, #260]	@ (20020c2c <boot_device_init+0x30c>)
20020b28:	bb48      	cbnz	r0, 20020b7e <boot_device_init+0x25e>
20020b2a:	f1b8 0f03 	cmp.w	r8, #3
20020b2e:	d029      	beq.n	20020b84 <boot_device_init+0x264>
20020b30:	4630      	mov	r0, r6
20020b32:	f002 fc3e 	bl	200233b2 <HAL_NAND_PAGE_SIZE>
20020b36:	f8df a110 	ldr.w	sl, [pc, #272]	@ 20020c48 <boot_device_init+0x328>
20020b3a:	f8df 8110 	ldr.w	r8, [pc, #272]	@ 20020c4c <boot_device_init+0x32c>
20020b3e:	f8ca 0000 	str.w	r0, [sl]
20020b42:	4630      	mov	r0, r6
20020b44:	f002 fcf5 	bl	20023532 <HAL_NAND_BLOCK_SIZE>
20020b48:	4649      	mov	r1, r9
20020b4a:	f8c8 0000 	str.w	r0, [r8]
20020b4e:	4630      	mov	r0, r6
20020b50:	f885 90d6 	strb.w	r9, [r5, #214]	@ 0xd6
20020b54:	f002 faec 	bl	20023130 <HAL_NAND_CONF_ECC>
20020b58:	f8da 0000 	ldr.w	r0, [sl]
20020b5c:	f004 ff12 	bl	20025984 <bbm_set_page_size>
20020b60:	f8d8 0000 	ldr.w	r0, [r8]
20020b64:	f004 ff14 	bl	20025990 <bbm_set_blk_size>
20020b68:	4931      	ldr	r1, [pc, #196]	@ (20020c30 <boot_device_init+0x310>)
20020b6a:	f8d5 00f4 	ldr.w	r0, [r5, #244]	@ 0xf4
20020b6e:	f004 fdab 	bl	200256c8 <sif_bbm_init>
20020b72:	f8d5 20f0 	ldr.w	r2, [r5, #240]	@ 0xf0
20020b76:	e730      	b.n	200209da <boot_device_init+0xba>
20020b78:	4b1b      	ldr	r3, [pc, #108]	@ (20020be8 <boot_device_init+0x2c8>)
20020b7a:	6023      	str	r3, [r4, #0]
20020b7c:	e7c1      	b.n	20020b02 <boot_device_init+0x1e2>
20020b7e:	f1b8 0f03 	cmp.w	r8, #3
20020b82:	d1f6      	bne.n	20020b72 <boot_device_init+0x252>
20020b84:	4b1a      	ldr	r3, [pc, #104]	@ (20020bf0 <boot_device_init+0x2d0>)
20020b86:	4a1b      	ldr	r2, [pc, #108]	@ (20020bf4 <boot_device_init+0x2d4>)
20020b88:	601a      	str	r2, [r3, #0]
20020b8a:	4b1c      	ldr	r3, [pc, #112]	@ (20020bfc <boot_device_init+0x2dc>)
20020b8c:	4a1a      	ldr	r2, [pc, #104]	@ (20020bf8 <boot_device_init+0x2d8>)
20020b8e:	601a      	str	r2, [r3, #0]
20020b90:	e7ef      	b.n	20020b72 <boot_device_init+0x252>
20020b92:	f7ff fc71 	bl	20020478 <board_pinmux_sd>
20020b96:	f000 fb59 	bl	2002124c <sdio_sd_init>
20020b9a:	2801      	cmp	r0, #1
20020b9c:	d111      	bne.n	20020bc2 <boot_device_init+0x2a2>
20020b9e:	4b25      	ldr	r3, [pc, #148]	@ (20020c34 <boot_device_init+0x314>)
20020ba0:	6023      	str	r3, [r4, #0]
20020ba2:	4b25      	ldr	r3, [pc, #148]	@ (20020c38 <boot_device_init+0x318>)
20020ba4:	4a16      	ldr	r2, [pc, #88]	@ (20020c00 <boot_device_init+0x2e0>)
20020ba6:	6013      	str	r3, [r2, #0]
20020ba8:	2200      	movs	r2, #0
20020baa:	4b16      	ldr	r3, [pc, #88]	@ (20020c04 <boot_device_init+0x2e4>)
20020bac:	601a      	str	r2, [r3, #0]
20020bae:	e751      	b.n	20020a54 <boot_device_init+0x134>
20020bb0:	f7ff fc62 	bl	20020478 <board_pinmux_sd>
20020bb4:	f000 fa1c 	bl	20020ff0 <sdio_emmc_init>
20020bb8:	4b20      	ldr	r3, [pc, #128]	@ (20020c3c <boot_device_init+0x31c>)
20020bba:	6018      	str	r0, [r3, #0]
20020bbc:	b908      	cbnz	r0, 20020bc2 <boot_device_init+0x2a2>
20020bbe:	4b20      	ldr	r3, [pc, #128]	@ (20020c40 <boot_device_init+0x320>)
20020bc0:	e7ee      	b.n	20020ba0 <boot_device_init+0x280>
20020bc2:	2300      	movs	r3, #0
20020bc4:	e7ee      	b.n	20020ba4 <boot_device_init+0x284>
20020bc6:	481f      	ldr	r0, [pc, #124]	@ (20020c44 <boot_device_init+0x324>)
20020bc8:	f005 fa22 	bl	20026010 <iprintf>
20020bcc:	e742      	b.n	20020a54 <boot_device_init+0x134>
20020bce:	bf00      	nop
20020bd0:	20044a2c 	.word	0x20044a2c
20020bd4:	112a8800 	.word	0x112a8800
20020bd8:	20046d44 	.word	0x20046d44
20020bdc:	20027024 	.word	0x20027024
20020be0:	5008101c 	.word	0x5008101c
20020be4:	20046f78 	.word	0x20046f78
20020be8:	20020615 	.word	0x20020615
20020bec:	20046db8 	.word	0x20046db8
20020bf0:	20046d40 	.word	0x20046d40
20020bf4:	20020591 	.word	0x20020591
20020bf8:	2002053d 	.word	0x2002053d
20020bfc:	20046d3c 	.word	0x20046d3c
20020c00:	20046d34 	.word	0x20046d34
20020c04:	20046d38 	.word	0x20046d38
20020c08:	20027038 	.word	0x20027038
20020c0c:	50081008 	.word	0x50081008
20020c10:	20046d48 	.word	0x20046d48
20020c14:	20047140 	.word	0x20047140
20020c18:	53454346 	.word	0x53454346
20020c1c:	2002704c 	.word	0x2002704c
20020c20:	20020629 	.word	0x20020629
20020c24:	20045ab4 	.word	0x20045ab4
20020c28:	20046e28 	.word	0x20046e28
20020c2c:	20047020 	.word	0x20047020
20020c30:	20044a34 	.word	0x20044a34
20020c34:	200206a9 	.word	0x200206a9
20020c38:	64001000 	.word	0x64001000
20020c3c:	20044a30 	.word	0x20044a30
20020c40:	20020739 	.word	0x20020739
20020c44:	20026b10 	.word	0x20026b10
20020c48:	20042c04 	.word	0x20042c04
20020c4c:	20042c00 	.word	0x20042c00
20020c50:	4a0c      	ldr	r2, [pc, #48]	@ (20020c84 <boot_device_init+0x364>)
20020c52:	4629      	mov	r1, r5
20020c54:	6013      	str	r3, [r2, #0]
20020c56:	4b0c      	ldr	r3, [pc, #48]	@ (20020c88 <boot_device_init+0x368>)
20020c58:	6830      	ldr	r0, [r6, #0]
20020c5a:	681a      	ldr	r2, [r3, #0]
20020c5c:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20020c60:	f043 0301 	orr.w	r3, r3, #1
20020c64:	f882 302c 	strb.w	r3, [r2, #44]	@ 0x2c
20020c68:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020c6c:	6823      	ldr	r3, [r4, #0]
20020c6e:	4798      	blx	r3
20020c70:	e70c      	b.n	20020a8c <boot_device_init+0x16c>
20020c72:	4806      	ldr	r0, [pc, #24]	@ (20020c8c <boot_device_init+0x36c>)
20020c74:	f005 f9cc 	bl	20026010 <iprintf>
20020c78:	2000      	movs	r0, #0
20020c7a:	e708      	b.n	20020a8e <boot_device_init+0x16e>
20020c7c:	7839      	ldrb	r1, [r7, #0]
20020c7e:	4804      	ldr	r0, [pc, #16]	@ (20020c90 <boot_device_init+0x370>)
20020c80:	e7f8      	b.n	20020c74 <boot_device_init+0x354>
20020c82:	bf00      	nop
20020c84:	20042c04 	.word	0x20042c04
20020c88:	20046d38 	.word	0x20046d38
20020c8c:	20026b24 	.word	0x20026b24
20020c90:	20026b4a 	.word	0x20026b4a

20020c94 <sifli_hw_efuse_load_bank0>:
20020c94:	2220      	movs	r2, #32
20020c96:	b508      	push	{r3, lr}
20020c98:	4904      	ldr	r1, [pc, #16]	@ (20020cac <sifli_hw_efuse_load_bank0+0x18>)
20020c9a:	2000      	movs	r0, #0
20020c9c:	f001 fb94 	bl	200223c8 <HAL_EFUSE_Read>
20020ca0:	2800      	cmp	r0, #0
20020ca2:	4802      	ldr	r0, [pc, #8]	@ (20020cac <sifli_hw_efuse_load_bank0+0x18>)
20020ca4:	bf08      	it	eq
20020ca6:	2000      	moveq	r0, #0
20020ca8:	bd08      	pop	{r3, pc}
20020caa:	bf00      	nop
20020cac:	2004711c 	.word	0x2004711c

20020cb0 <update_sec_flash>:
20020cb0:	b570      	push	{r4, r5, r6, lr}
20020cb2:	4604      	mov	r4, r0
20020cb4:	4b08      	ldr	r3, [pc, #32]	@ (20020cd8 <update_sec_flash+0x28>)
20020cb6:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20020cba:	681d      	ldr	r5, [r3, #0]
20020cbc:	4b07      	ldr	r3, [pc, #28]	@ (20020cdc <update_sec_flash+0x2c>)
20020cbe:	4628      	mov	r0, r5
20020cc0:	681b      	ldr	r3, [r3, #0]
20020cc2:	4798      	blx	r3
20020cc4:	4b06      	ldr	r3, [pc, #24]	@ (20020ce0 <update_sec_flash+0x30>)
20020cc6:	4621      	mov	r1, r4
20020cc8:	4628      	mov	r0, r5
20020cca:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20020cce:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020cd2:	681b      	ldr	r3, [r3, #0]
20020cd4:	4718      	bx	r3
20020cd6:	bf00      	nop
20020cd8:	20046d34 	.word	0x20046d34
20020cdc:	20046d3c 	.word	0x20046d3c
20020ce0:	20046d44 	.word	0x20046d44

20020ce4 <boot_images_help>:
20020ce4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020ce8:	4e55      	ldr	r6, [pc, #340]	@ (20020e40 <boot_images_help+0x15c>)
20020cea:	f8df a164 	ldr.w	sl, [pc, #356]	@ 20020e50 <boot_images_help+0x16c>
20020cee:	6833      	ldr	r3, [r6, #0]
20020cf0:	b085      	sub	sp, #20
20020cf2:	4553      	cmp	r3, sl
20020cf4:	d156      	bne.n	20020da4 <boot_images_help+0xc0>
20020cf6:	2208      	movs	r2, #8
20020cf8:	2300      	movs	r3, #0
20020cfa:	f8df b158 	ldr.w	fp, [pc, #344]	@ 20020e54 <boot_images_help+0x170>
20020cfe:	eb0d 0102 	add.w	r1, sp, r2
20020d02:	e9cd 3302 	strd	r3, r3, [sp, #8]
20020d06:	484f      	ldr	r0, [pc, #316]	@ (20020e44 <boot_images_help+0x160>)
20020d08:	f8db 3000 	ldr.w	r3, [fp]
20020d0c:	4798      	blx	r3
20020d0e:	2008      	movs	r0, #8
20020d10:	f007 f87c 	bl	20027e0c <HAL_Get_backup>
20020d14:	4605      	mov	r5, r0
20020d16:	2005      	movs	r0, #5
20020d18:	f007 f878 	bl	20027e0c <HAL_Get_backup>
20020d1c:	f8df 9138 	ldr.w	r9, [pc, #312]	@ 20020e58 <boot_images_help+0x174>
20020d20:	4949      	ldr	r1, [pc, #292]	@ (20020e48 <boot_images_help+0x164>)
20020d22:	f8d9 4000 	ldr.w	r4, [r9]
20020d26:	f8df 8134 	ldr.w	r8, [pc, #308]	@ 20020e5c <boot_images_help+0x178>
20020d2a:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d2e:	f8db 3000 	ldr.w	r3, [fp]
20020d32:	4607      	mov	r7, r0
20020d34:	f8c8 1000 	str.w	r1, [r8]
20020d38:	4620      	mov	r0, r4
20020d3a:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
20020d3e:	4798      	blx	r3
20020d40:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
20020d44:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
20020d48:	4593      	cmp	fp, r2
20020d4a:	d154      	bne.n	20020df6 <boot_images_help+0x112>
20020d4c:	b2eb      	uxtb	r3, r5
20020d4e:	2b04      	cmp	r3, #4
20020d50:	d02b      	beq.n	20020daa <boot_images_help+0xc6>
20020d52:	2b06      	cmp	r3, #6
20020d54:	d03f      	beq.n	20020dd6 <boot_images_help+0xf2>
20020d56:	2b01      	cmp	r3, #1
20020d58:	d148      	bne.n	20020dec <boot_images_help+0x108>
20020d5a:	2005      	movs	r0, #5
20020d5c:	f007 f856 	bl	20027e0c <HAL_Get_backup>
20020d60:	2802      	cmp	r0, #2
20020d62:	d006      	beq.n	20020d72 <boot_images_help+0x8e>
20020d64:	9b02      	ldr	r3, [sp, #8]
20020d66:	4553      	cmp	r3, sl
20020d68:	d106      	bne.n	20020d78 <boot_images_help+0x94>
20020d6a:	f89d 300d 	ldrb.w	r3, [sp, #13]
20020d6e:	2b7f      	cmp	r3, #127	@ 0x7f
20020d70:	d102      	bne.n	20020d78 <boot_images_help+0x94>
20020d72:	4b36      	ldr	r3, [pc, #216]	@ (20020e4c <boot_images_help+0x168>)
20020d74:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
20020d78:	f7ff fbcf 	bl	2002051a <board_init_psram>
20020d7c:	f8d6 3200 	ldr.w	r3, [r6, #512]	@ 0x200
20020d80:	3301      	adds	r3, #1
20020d82:	d002      	beq.n	20020d8a <boot_images_help+0xa6>
20020d84:	200b      	movs	r0, #11
20020d86:	f000 fc2d 	bl	200215e4 <dfu_boot_img_in_flash>
20020d8a:	f8d6 0c08 	ldr.w	r0, [r6, #3080]	@ 0xc08
20020d8e:	1c43      	adds	r3, r0, #1
20020d90:	d008      	beq.n	20020da4 <boot_images_help+0xc0>
20020d92:	f8d9 3000 	ldr.w	r3, [r9]
20020d96:	1ac0      	subs	r0, r0, r3
20020d98:	f5a0 5080 	sub.w	r0, r0, #4096	@ 0x1000
20020d9c:	0a40      	lsrs	r0, r0, #9
20020d9e:	3002      	adds	r0, #2
20020da0:	f000 fc20 	bl	200215e4 <dfu_boot_img_in_flash>
20020da4:	b005      	add	sp, #20
20020da6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020daa:	2008      	movs	r0, #8
20020dac:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020db0:	2106      	movs	r1, #6
20020db2:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20020db6:	f007 f823 	bl	20027e00 <HAL_Set_backup>
20020dba:	f8d8 0000 	ldr.w	r0, [r8]
20020dbe:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020dc2:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20020dc6:	b11f      	cbz	r7, 20020dd0 <boot_images_help+0xec>
20020dc8:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020dcc:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20020dd0:	f7ff ff6e 	bl	20020cb0 <update_sec_flash>
20020dd4:	e7c1      	b.n	20020d5a <boot_images_help+0x76>
20020dd6:	2101      	movs	r1, #1
20020dd8:	2008      	movs	r0, #8
20020dda:	f007 f811 	bl	20027e00 <HAL_Set_backup>
20020dde:	f8d8 0000 	ldr.w	r0, [r8]
20020de2:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020de6:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
20020dea:	e7f1      	b.n	20020dd0 <boot_images_help+0xec>
20020dec:	2101      	movs	r1, #1
20020dee:	2008      	movs	r0, #8
20020df0:	f007 f806 	bl	20027e00 <HAL_Set_backup>
20020df4:	e7b1      	b.n	20020d5a <boot_images_help+0x76>
20020df6:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020dfa:	45a3      	cmp	fp, r4
20020dfc:	d1ad      	bne.n	20020d5a <boot_images_help+0x76>
20020dfe:	b2eb      	uxtb	r3, r5
20020e00:	2b03      	cmp	r3, #3
20020e02:	d005      	beq.n	20020e10 <boot_images_help+0x12c>
20020e04:	2b05      	cmp	r3, #5
20020e06:	d018      	beq.n	20020e3a <boot_images_help+0x156>
20020e08:	2b02      	cmp	r3, #2
20020e0a:	d0a6      	beq.n	20020d5a <boot_images_help+0x76>
20020e0c:	2102      	movs	r1, #2
20020e0e:	e7ee      	b.n	20020dee <boot_images_help+0x10a>
20020e10:	2008      	movs	r0, #8
20020e12:	2105      	movs	r1, #5
20020e14:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20020e18:	9201      	str	r2, [sp, #4]
20020e1a:	f006 fff1 	bl	20027e00 <HAL_Set_backup>
20020e1e:	f8d8 0000 	ldr.w	r0, [r8]
20020e22:	9a01      	ldr	r2, [sp, #4]
20020e24:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020e28:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
20020e2c:	2f00      	cmp	r7, #0
20020e2e:	d0cf      	beq.n	20020dd0 <boot_images_help+0xec>
20020e30:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020e34:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20020e38:	e7ca      	b.n	20020dd0 <boot_images_help+0xec>
20020e3a:	2102      	movs	r1, #2
20020e3c:	e7cc      	b.n	20020dd8 <boot_images_help+0xf4>
20020e3e:	bf00      	nop
20020e40:	20047140 	.word	0x20047140
20020e44:	127c0000 	.word	0x127c0000
20020e48:	20049d54 	.word	0x20049d54
20020e4c:	12001000 	.word	0x12001000
20020e50:	53454346 	.word	0x53454346
20020e54:	20046d44 	.word	0x20046d44
20020e58:	20046d34 	.word	0x20046d34
20020e5c:	20049d50 	.word	0x20049d50

20020e60 <_write>:
20020e60:	2802      	cmp	r0, #2
20020e62:	b510      	push	{r4, lr}
20020e64:	4614      	mov	r4, r2
20020e66:	dc04      	bgt.n	20020e72 <_write+0x12>
20020e68:	4803      	ldr	r0, [pc, #12]	@ (20020e78 <_write+0x18>)
20020e6a:	f7ff fa13 	bl	20020294 <boot_uart_tx>
20020e6e:	4620      	mov	r0, r4
20020e70:	bd10      	pop	{r4, pc}
20020e72:	f04f 34ff 	mov.w	r4, #4294967295
20020e76:	e7fa      	b.n	20020e6e <_write+0xe>
20020e78:	50084000 	.word	0x50084000

20020e7c <entry>:
20020e7c:	b508      	push	{r3, lr}
20020e7e:	f000 fb89 	bl	20021594 <sboot_init>
20020e82:	f7ff fb44 	bl	2002050e <board_init>
20020e86:	f7ff fb3b 	bl	20020500 <board_boot_from>
20020e8a:	4b04      	ldr	r3, [pc, #16]	@ (20020e9c <entry+0x20>)
20020e8c:	7018      	strb	r0, [r3, #0]
20020e8e:	f7ff fd47 	bl	20020920 <boot_device_init>
20020e92:	b108      	cbz	r0, 20020e98 <entry+0x1c>
20020e94:	f7ff ff26 	bl	20020ce4 <boot_images_help>
20020e98:	e7fe      	b.n	20020e98 <entry+0x1c>
20020e9a:	bf00      	nop
20020e9c:	20044a2c 	.word	0x20044a2c

20020ea0 <sd1_init>:
20020ea0:	b510      	push	{r4, lr}
20020ea2:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20020ea6:	68e3      	ldr	r3, [r4, #12]
20020ea8:	2064      	movs	r0, #100	@ 0x64
20020eaa:	f023 0310 	bic.w	r3, r3, #16
20020eae:	60e3      	str	r3, [r4, #12]
20020eb0:	f000 fd9f 	bl	200219f2 <HAL_Delay_us>
20020eb4:	f44f 7280 	mov.w	r2, #256	@ 0x100
20020eb8:	68e3      	ldr	r3, [r4, #12]
20020eba:	f043 0310 	orr.w	r3, r3, #16
20020ebe:	60e3      	str	r3, [r4, #12]
20020ec0:	4b02      	ldr	r3, [pc, #8]	@ (20020ecc <sd1_init+0x2c>)
20020ec2:	631a      	str	r2, [r3, #48]	@ 0x30
20020ec4:	2200      	movs	r2, #0
20020ec6:	63da      	str	r2, [r3, #60]	@ 0x3c
20020ec8:	bd10      	pop	{r4, pc}
20020eca:	bf00      	nop
20020ecc:	50045000 	.word	0x50045000

20020ed0 <sd1_wait_cmd>:
20020ed0:	4b08      	ldr	r3, [pc, #32]	@ (20020ef4 <sd1_wait_cmd+0x24>)
20020ed2:	681a      	ldr	r2, [r3, #0]
20020ed4:	f012 0f0a 	tst.w	r2, #10
20020ed8:	d0fb      	beq.n	20020ed2 <sd1_wait_cmd+0x2>
20020eda:	2202      	movs	r2, #2
20020edc:	601a      	str	r2, [r3, #0]
20020ede:	681a      	ldr	r2, [r3, #0]
20020ee0:	0712      	lsls	r2, r2, #28
20020ee2:	bf5f      	itttt	pl
20020ee4:	6818      	ldrpl	r0, [r3, #0]
20020ee6:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20020eea:	0040      	lslpl	r0, r0, #1
20020eec:	b2c0      	uxtbpl	r0, r0
20020eee:	bf48      	it	mi
20020ef0:	2001      	movmi	r0, #1
20020ef2:	4770      	bx	lr
20020ef4:	50045000 	.word	0x50045000

20020ef8 <sd1_send_cmd>:
20020ef8:	b538      	push	{r3, r4, r5, lr}
20020efa:	4604      	mov	r4, r0
20020efc:	460d      	mov	r5, r1
20020efe:	4b11      	ldr	r3, [pc, #68]	@ (20020f44 <sd1_send_cmd+0x4c>)
20020f00:	6818      	ldr	r0, [r3, #0]
20020f02:	f000 fd76 	bl	200219f2 <HAL_Delay_us>
20020f06:	4b10      	ldr	r3, [pc, #64]	@ (20020f48 <sd1_send_cmd+0x50>)
20020f08:	2c0f      	cmp	r4, #15
20020f0a:	609d      	str	r5, [r3, #8]
20020f0c:	ea4f 4384 	mov.w	r3, r4, lsl #18
20020f10:	d815      	bhi.n	20020f3e <sd1_send_cmd+0x46>
20020f12:	2201      	movs	r2, #1
20020f14:	f248 0111 	movw	r1, #32785	@ 0x8011
20020f18:	40a2      	lsls	r2, r4
20020f1a:	420a      	tst	r2, r1
20020f1c:	d105      	bne.n	20020f2a <sd1_send_cmd+0x32>
20020f1e:	f240 6104 	movw	r1, #1540	@ 0x604
20020f22:	420a      	tst	r2, r1
20020f24:	d00b      	beq.n	20020f3e <sd1_send_cmd+0x46>
20020f26:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
20020f2a:	4a07      	ldr	r2, [pc, #28]	@ (20020f48 <sd1_send_cmd+0x50>)
20020f2c:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
20020f30:	f043 0301 	orr.w	r3, r3, #1
20020f34:	6053      	str	r3, [r2, #4]
20020f36:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20020f3a:	f7ff bfc9 	b.w	20020ed0 <sd1_wait_cmd>
20020f3e:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20020f42:	e7f2      	b.n	20020f2a <sd1_send_cmd+0x32>
20020f44:	20042c08 	.word	0x20042c08
20020f48:	50045000 	.word	0x50045000

20020f4c <sd1_send_acmd>:
20020f4c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20020f4e:	4605      	mov	r5, r0
20020f50:	460f      	mov	r7, r1
20020f52:	2037      	movs	r0, #55	@ 0x37
20020f54:	0411      	lsls	r1, r2, #16
20020f56:	f7ff ffcf 	bl	20020ef8 <sd1_send_cmd>
20020f5a:	4604      	mov	r4, r0
20020f5c:	b968      	cbnz	r0, 20020f7a <sd1_send_acmd+0x2e>
20020f5e:	4b08      	ldr	r3, [pc, #32]	@ (20020f80 <sd1_send_acmd+0x34>)
20020f60:	4e08      	ldr	r6, [pc, #32]	@ (20020f84 <sd1_send_acmd+0x38>)
20020f62:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
20020f66:	60b7      	str	r7, [r6, #8]
20020f68:	6073      	str	r3, [r6, #4]
20020f6a:	f7ff ffb1 	bl	20020ed0 <sd1_wait_cmd>
20020f6e:	2802      	cmp	r0, #2
20020f70:	d104      	bne.n	20020f7c <sd1_send_acmd+0x30>
20020f72:	2d29      	cmp	r5, #41	@ 0x29
20020f74:	d102      	bne.n	20020f7c <sd1_send_acmd+0x30>
20020f76:	2304      	movs	r3, #4
20020f78:	6033      	str	r3, [r6, #0]
20020f7a:	4620      	mov	r0, r4
20020f7c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20020f7e:	bf00      	nop
20020f80:	00010101 	.word	0x00010101
20020f84:	50045000 	.word	0x50045000

20020f88 <sd1_get_rsp>:
20020f88:	b530      	push	{r4, r5, lr}
20020f8a:	4c06      	ldr	r4, [pc, #24]	@ (20020fa4 <sd1_get_rsp+0x1c>)
20020f8c:	68e5      	ldr	r5, [r4, #12]
20020f8e:	7005      	strb	r5, [r0, #0]
20020f90:	6920      	ldr	r0, [r4, #16]
20020f92:	6008      	str	r0, [r1, #0]
20020f94:	6961      	ldr	r1, [r4, #20]
20020f96:	6011      	str	r1, [r2, #0]
20020f98:	69a2      	ldr	r2, [r4, #24]
20020f9a:	601a      	str	r2, [r3, #0]
20020f9c:	69e2      	ldr	r2, [r4, #28]
20020f9e:	9b03      	ldr	r3, [sp, #12]
20020fa0:	601a      	str	r2, [r3, #0]
20020fa2:	bd30      	pop	{r4, r5, pc}
20020fa4:	50045000 	.word	0x50045000

20020fa8 <sd1_read>:
20020fa8:	f04f 33ff 	mov.w	r3, #4294967295
20020fac:	4a04      	ldr	r2, [pc, #16]	@ (20020fc0 <sd1_read+0x18>)
20020fae:	eb03 2341 	add.w	r3, r3, r1, lsl #9
20020fb2:	6293      	str	r3, [r2, #40]	@ 0x28
20020fb4:	4b03      	ldr	r3, [pc, #12]	@ (20020fc4 <sd1_read+0x1c>)
20020fb6:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20020fba:	6253      	str	r3, [r2, #36]	@ 0x24
20020fbc:	4770      	bx	lr
20020fbe:	bf00      	nop
20020fc0:	50045000 	.word	0x50045000
20020fc4:	01ff0301 	.word	0x01ff0301

20020fc8 <sd1_wait_read>:
20020fc8:	4b08      	ldr	r3, [pc, #32]	@ (20020fec <sd1_wait_read+0x24>)
20020fca:	681a      	ldr	r2, [r3, #0]
20020fcc:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20020fd0:	d0fb      	beq.n	20020fca <sd1_wait_read+0x2>
20020fd2:	2220      	movs	r2, #32
20020fd4:	601a      	str	r2, [r3, #0]
20020fd6:	681a      	ldr	r2, [r3, #0]
20020fd8:	0612      	lsls	r2, r2, #24
20020fda:	bf5f      	itttt	pl
20020fdc:	6818      	ldrpl	r0, [r3, #0]
20020fde:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
20020fe2:	0040      	lslpl	r0, r0, #1
20020fe4:	b2c0      	uxtbpl	r0, r0
20020fe6:	bf48      	it	mi
20020fe8:	2001      	movmi	r0, #1
20020fea:	4770      	bx	lr
20020fec:	50045000 	.word	0x50045000

20020ff0 <sdio_emmc_init>:
20020ff0:	b530      	push	{r4, r5, lr}
20020ff2:	b08d      	sub	sp, #52	@ 0x34
20020ff4:	f7ff ff54 	bl	20020ea0 <sd1_init>
20020ff8:	4c6c      	ldr	r4, [pc, #432]	@ (200211ac <sdio_emmc_init+0x1bc>)
20020ffa:	4b6d      	ldr	r3, [pc, #436]	@ (200211b0 <sdio_emmc_init+0x1c0>)
20020ffc:	2500      	movs	r5, #0
20020ffe:	6323      	str	r3, [r4, #48]	@ 0x30
20021000:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021002:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021006:	f043 0302 	orr.w	r3, r3, #2
2002100a:	6323      	str	r3, [r4, #48]	@ 0x30
2002100c:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20021010:	62e5      	str	r5, [r4, #44]	@ 0x2c
20021012:	6223      	str	r3, [r4, #32]
20021014:	f000 fced 	bl	200219f2 <HAL_Delay_us>
20021018:	4629      	mov	r1, r5
2002101a:	4628      	mov	r0, r5
2002101c:	f7ff ff6c 	bl	20020ef8 <sd1_send_cmd>
20021020:	2301      	movs	r3, #1
20021022:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021024:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021026:	0799      	lsls	r1, r3, #30
20021028:	d5fc      	bpl.n	20021024 <sdio_emmc_init+0x34>
2002102a:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
2002102c:	f043 0320 	orr.w	r3, r3, #32
20021030:	63e3      	str	r3, [r4, #60]	@ 0x3c
20021032:	4960      	ldr	r1, [pc, #384]	@ (200211b4 <sdio_emmc_init+0x1c4>)
20021034:	2001      	movs	r0, #1
20021036:	ad07      	add	r5, sp, #28
20021038:	f7ff ff5e 	bl	20020ef8 <sd1_send_cmd>
2002103c:	ab06      	add	r3, sp, #24
2002103e:	aa05      	add	r2, sp, #20
20021040:	a904      	add	r1, sp, #16
20021042:	f10d 000f 	add.w	r0, sp, #15
20021046:	9500      	str	r5, [sp, #0]
20021048:	f7ff ff9e 	bl	20020f88 <sd1_get_rsp>
2002104c:	2014      	movs	r0, #20
2002104e:	f000 fcd0 	bl	200219f2 <HAL_Delay_us>
20021052:	9b04      	ldr	r3, [sp, #16]
20021054:	2b00      	cmp	r3, #0
20021056:	daec      	bge.n	20021032 <sdio_emmc_init+0x42>
20021058:	4a57      	ldr	r2, [pc, #348]	@ (200211b8 <sdio_emmc_init+0x1c8>)
2002105a:	f3c3 7380 	ubfx	r3, r3, #30, #1
2002105e:	f083 0301 	eor.w	r3, r3, #1
20021062:	2100      	movs	r1, #0
20021064:	2002      	movs	r0, #2
20021066:	7013      	strb	r3, [r2, #0]
20021068:	f7ff ff46 	bl	20020ef8 <sd1_send_cmd>
2002106c:	2801      	cmp	r0, #1
2002106e:	f000 8081 	beq.w	20021174 <sdio_emmc_init+0x184>
20021072:	2802      	cmp	r0, #2
20021074:	d07e      	beq.n	20021174 <sdio_emmc_init+0x184>
20021076:	ab08      	add	r3, sp, #32
20021078:	9300      	str	r3, [sp, #0]
2002107a:	aa0a      	add	r2, sp, #40	@ 0x28
2002107c:	ab09      	add	r3, sp, #36	@ 0x24
2002107e:	a90b      	add	r1, sp, #44	@ 0x2c
20021080:	f10d 000f 	add.w	r0, sp, #15
20021084:	f7ff ff80 	bl	20020f88 <sd1_get_rsp>
20021088:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
2002108c:	2003      	movs	r0, #3
2002108e:	f7ff ff33 	bl	20020ef8 <sd1_send_cmd>
20021092:	2801      	cmp	r0, #1
20021094:	d070      	beq.n	20021178 <sdio_emmc_init+0x188>
20021096:	2802      	cmp	r0, #2
20021098:	d070      	beq.n	2002117c <sdio_emmc_init+0x18c>
2002109a:	ab06      	add	r3, sp, #24
2002109c:	9500      	str	r5, [sp, #0]
2002109e:	aa05      	add	r2, sp, #20
200210a0:	a904      	add	r1, sp, #16
200210a2:	f10d 000f 	add.w	r0, sp, #15
200210a6:	f7ff ff6f 	bl	20020f88 <sd1_get_rsp>
200210aa:	f89d 300f 	ldrb.w	r3, [sp, #15]
200210ae:	2b03      	cmp	r3, #3
200210b0:	d166      	bne.n	20021180 <sdio_emmc_init+0x190>
200210b2:	4c3e      	ldr	r4, [pc, #248]	@ (200211ac <sdio_emmc_init+0x1bc>)
200210b4:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210b8:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
200210ba:	2009      	movs	r0, #9
200210bc:	f023 0320 	bic.w	r3, r3, #32
200210c0:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210c2:	f7ff ff19 	bl	20020ef8 <sd1_send_cmd>
200210c6:	2801      	cmp	r0, #1
200210c8:	d05c      	beq.n	20021184 <sdio_emmc_init+0x194>
200210ca:	2802      	cmp	r0, #2
200210cc:	d05c      	beq.n	20021188 <sdio_emmc_init+0x198>
200210ce:	ab06      	add	r3, sp, #24
200210d0:	aa05      	add	r2, sp, #20
200210d2:	a904      	add	r1, sp, #16
200210d4:	f10d 000f 	add.w	r0, sp, #15
200210d8:	9500      	str	r5, [sp, #0]
200210da:	f7ff ff55 	bl	20020f88 <sd1_get_rsp>
200210de:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
200210e2:	6323      	str	r3, [r4, #48]	@ 0x30
200210e4:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200210e6:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210ea:	f043 0302 	orr.w	r3, r3, #2
200210ee:	6323      	str	r3, [r4, #48]	@ 0x30
200210f0:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200210f4:	6223      	str	r3, [r4, #32]
200210f6:	2300      	movs	r3, #0
200210f8:	2007      	movs	r0, #7
200210fa:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210fc:	f7ff fefc 	bl	20020ef8 <sd1_send_cmd>
20021100:	2801      	cmp	r0, #1
20021102:	d043      	beq.n	2002118c <sdio_emmc_init+0x19c>
20021104:	2802      	cmp	r0, #2
20021106:	d043      	beq.n	20021190 <sdio_emmc_init+0x1a0>
20021108:	ab06      	add	r3, sp, #24
2002110a:	9500      	str	r5, [sp, #0]
2002110c:	aa05      	add	r2, sp, #20
2002110e:	a904      	add	r1, sp, #16
20021110:	f10d 000f 	add.w	r0, sp, #15
20021114:	f7ff ff38 	bl	20020f88 <sd1_get_rsp>
20021118:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002111c:	2b07      	cmp	r3, #7
2002111e:	d139      	bne.n	20021194 <sdio_emmc_init+0x1a4>
20021120:	2101      	movs	r1, #1
20021122:	2000      	movs	r0, #0
20021124:	f7ff ff40 	bl	20020fa8 <sd1_read>
20021128:	f04f 33ff 	mov.w	r3, #4294967295
2002112c:	2100      	movs	r1, #0
2002112e:	2011      	movs	r0, #17
20021130:	6023      	str	r3, [r4, #0]
20021132:	f7ff fee1 	bl	20020ef8 <sd1_send_cmd>
20021136:	2801      	cmp	r0, #1
20021138:	d02e      	beq.n	20021198 <sdio_emmc_init+0x1a8>
2002113a:	2802      	cmp	r0, #2
2002113c:	d02e      	beq.n	2002119c <sdio_emmc_init+0x1ac>
2002113e:	ab06      	add	r3, sp, #24
20021140:	9500      	str	r5, [sp, #0]
20021142:	aa05      	add	r2, sp, #20
20021144:	a904      	add	r1, sp, #16
20021146:	f10d 000f 	add.w	r0, sp, #15
2002114a:	f7ff ff1d 	bl	20020f88 <sd1_get_rsp>
2002114e:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021152:	2b11      	cmp	r3, #17
20021154:	d124      	bne.n	200211a0 <sdio_emmc_init+0x1b0>
20021156:	2320      	movs	r3, #32
20021158:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002115a:	f7ff ff35 	bl	20020fc8 <sd1_wait_read>
2002115e:	6823      	ldr	r3, [r4, #0]
20021160:	061a      	lsls	r2, r3, #24
20021162:	d41f      	bmi.n	200211a4 <sdio_emmc_init+0x1b4>
20021164:	6823      	ldr	r3, [r4, #0]
20021166:	065b      	lsls	r3, r3, #25
20021168:	d41e      	bmi.n	200211a8 <sdio_emmc_init+0x1b8>
2002116a:	2080      	movs	r0, #128	@ 0x80
2002116c:	3801      	subs	r0, #1
2002116e:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
20021172:	d1fb      	bne.n	2002116c <sdio_emmc_init+0x17c>
20021174:	b00d      	add	sp, #52	@ 0x34
20021176:	bd30      	pop	{r4, r5, pc}
20021178:	2003      	movs	r0, #3
2002117a:	e7fb      	b.n	20021174 <sdio_emmc_init+0x184>
2002117c:	2004      	movs	r0, #4
2002117e:	e7f9      	b.n	20021174 <sdio_emmc_init+0x184>
20021180:	2005      	movs	r0, #5
20021182:	e7f7      	b.n	20021174 <sdio_emmc_init+0x184>
20021184:	2006      	movs	r0, #6
20021186:	e7f5      	b.n	20021174 <sdio_emmc_init+0x184>
20021188:	2007      	movs	r0, #7
2002118a:	e7f3      	b.n	20021174 <sdio_emmc_init+0x184>
2002118c:	2008      	movs	r0, #8
2002118e:	e7f1      	b.n	20021174 <sdio_emmc_init+0x184>
20021190:	2009      	movs	r0, #9
20021192:	e7ef      	b.n	20021174 <sdio_emmc_init+0x184>
20021194:	200a      	movs	r0, #10
20021196:	e7ed      	b.n	20021174 <sdio_emmc_init+0x184>
20021198:	2012      	movs	r0, #18
2002119a:	e7eb      	b.n	20021174 <sdio_emmc_init+0x184>
2002119c:	2013      	movs	r0, #19
2002119e:	e7e9      	b.n	20021174 <sdio_emmc_init+0x184>
200211a0:	2014      	movs	r0, #20
200211a2:	e7e7      	b.n	20021174 <sdio_emmc_init+0x184>
200211a4:	2015      	movs	r0, #21
200211a6:	e7e5      	b.n	20021174 <sdio_emmc_init+0x184>
200211a8:	2016      	movs	r0, #22
200211aa:	e7e3      	b.n	20021174 <sdio_emmc_init+0x184>
200211ac:	50045000 	.word	0x50045000
200211b0:	00016700 	.word	0x00016700
200211b4:	40000080 	.word	0x40000080
200211b8:	20042c0c 	.word	0x20042c0c

200211bc <emmc_read_data>:
200211bc:	b570      	push	{r4, r5, r6, lr}
200211be:	4606      	mov	r6, r0
200211c0:	460d      	mov	r5, r1
200211c2:	2000      	movs	r0, #0
200211c4:	2101      	movs	r1, #1
200211c6:	b088      	sub	sp, #32
200211c8:	4614      	mov	r4, r2
200211ca:	f7ff feed 	bl	20020fa8 <sd1_read>
200211ce:	f04f 32ff 	mov.w	r2, #4294967295
200211d2:	4b1c      	ldr	r3, [pc, #112]	@ (20021244 <emmc_read_data+0x88>)
200211d4:	601a      	str	r2, [r3, #0]
200211d6:	4b1c      	ldr	r3, [pc, #112]	@ (20021248 <emmc_read_data+0x8c>)
200211d8:	781b      	ldrb	r3, [r3, #0]
200211da:	b903      	cbnz	r3, 200211de <emmc_read_data+0x22>
200211dc:	0a76      	lsrs	r6, r6, #9
200211de:	4631      	mov	r1, r6
200211e0:	2011      	movs	r0, #17
200211e2:	f7ff fe89 	bl	20020ef8 <sd1_send_cmd>
200211e6:	3801      	subs	r0, #1
200211e8:	b2c0      	uxtb	r0, r0
200211ea:	2801      	cmp	r0, #1
200211ec:	d802      	bhi.n	200211f4 <emmc_read_data+0x38>
200211ee:	2000      	movs	r0, #0
200211f0:	b008      	add	sp, #32
200211f2:	bd70      	pop	{r4, r5, r6, pc}
200211f4:	ab07      	add	r3, sp, #28
200211f6:	9300      	str	r3, [sp, #0]
200211f8:	aa05      	add	r2, sp, #20
200211fa:	ab06      	add	r3, sp, #24
200211fc:	a904      	add	r1, sp, #16
200211fe:	f10d 000f 	add.w	r0, sp, #15
20021202:	f7ff fec1 	bl	20020f88 <sd1_get_rsp>
20021206:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002120a:	2b11      	cmp	r3, #17
2002120c:	d1ef      	bne.n	200211ee <emmc_read_data+0x32>
2002120e:	f04f 33ff 	mov.w	r3, #4294967295
20021212:	4e0c      	ldr	r6, [pc, #48]	@ (20021244 <emmc_read_data+0x88>)
20021214:	6033      	str	r3, [r6, #0]
20021216:	2320      	movs	r3, #32
20021218:	62f3      	str	r3, [r6, #44]	@ 0x2c
2002121a:	f7ff fed5 	bl	20020fc8 <sd1_wait_read>
2002121e:	6833      	ldr	r3, [r6, #0]
20021220:	061a      	lsls	r2, r3, #24
20021222:	d4e4      	bmi.n	200211ee <emmc_read_data+0x32>
20021224:	6833      	ldr	r3, [r6, #0]
20021226:	065b      	lsls	r3, r3, #25
20021228:	d4e1      	bmi.n	200211ee <emmc_read_data+0x32>
2002122a:	f024 0303 	bic.w	r3, r4, #3
2002122e:	442b      	add	r3, r5
20021230:	429d      	cmp	r5, r3
20021232:	d101      	bne.n	20021238 <emmc_read_data+0x7c>
20021234:	4620      	mov	r0, r4
20021236:	e7db      	b.n	200211f0 <emmc_read_data+0x34>
20021238:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
2002123c:	f845 2b04 	str.w	r2, [r5], #4
20021240:	e7f6      	b.n	20021230 <emmc_read_data+0x74>
20021242:	bf00      	nop
20021244:	50045000 	.word	0x50045000
20021248:	20042c0c 	.word	0x20042c0c

2002124c <sdio_sd_init>:
2002124c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002124e:	b08d      	sub	sp, #52	@ 0x34
20021250:	f7ff fe26 	bl	20020ea0 <sd1_init>
20021254:	4c83      	ldr	r4, [pc, #524]	@ (20021464 <sdio_sd_init+0x218>)
20021256:	4b84      	ldr	r3, [pc, #528]	@ (20021468 <sdio_sd_init+0x21c>)
20021258:	2500      	movs	r5, #0
2002125a:	6323      	str	r3, [r4, #48]	@ 0x30
2002125c:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002125e:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021262:	f043 0302 	orr.w	r3, r3, #2
20021266:	6323      	str	r3, [r4, #48]	@ 0x30
20021268:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
2002126c:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002126e:	6223      	str	r3, [r4, #32]
20021270:	f000 fbbf 	bl	200219f2 <HAL_Delay_us>
20021274:	4629      	mov	r1, r5
20021276:	4628      	mov	r0, r5
20021278:	f7ff fe3e 	bl	20020ef8 <sd1_send_cmd>
2002127c:	2301      	movs	r3, #1
2002127e:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021280:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021282:	079a      	lsls	r2, r3, #30
20021284:	d5fc      	bpl.n	20021280 <sdio_sd_init+0x34>
20021286:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
2002128a:	2008      	movs	r0, #8
2002128c:	f7ff fe34 	bl	20020ef8 <sd1_send_cmd>
20021290:	3801      	subs	r0, #1
20021292:	b2c0      	uxtb	r0, r0
20021294:	2801      	cmp	r0, #1
20021296:	d802      	bhi.n	2002129e <sdio_sd_init+0x52>
20021298:	2038      	movs	r0, #56	@ 0x38
2002129a:	b00d      	add	sp, #52	@ 0x34
2002129c:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002129e:	ac07      	add	r4, sp, #28
200212a0:	ab06      	add	r3, sp, #24
200212a2:	9400      	str	r4, [sp, #0]
200212a4:	aa05      	add	r2, sp, #20
200212a6:	a904      	add	r1, sp, #16
200212a8:	f10d 000f 	add.w	r0, sp, #15
200212ac:	f7ff fe6c 	bl	20020f88 <sd1_get_rsp>
200212b0:	f89d 300f 	ldrb.w	r3, [sp, #15]
200212b4:	2b08      	cmp	r3, #8
200212b6:	d1ef      	bne.n	20021298 <sdio_sd_init+0x4c>
200212b8:	9b04      	ldr	r3, [sp, #16]
200212ba:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
200212be:	d1eb      	bne.n	20021298 <sdio_sd_init+0x4c>
200212c0:	2200      	movs	r2, #0
200212c2:	2029      	movs	r0, #41	@ 0x29
200212c4:	4969      	ldr	r1, [pc, #420]	@ (2002146c <sdio_sd_init+0x220>)
200212c6:	f7ff fe41 	bl	20020f4c <sd1_send_acmd>
200212ca:	2801      	cmp	r0, #1
200212cc:	f000 80bd 	beq.w	2002144a <sdio_sd_init+0x1fe>
200212d0:	ab06      	add	r3, sp, #24
200212d2:	9400      	str	r4, [sp, #0]
200212d4:	aa05      	add	r2, sp, #20
200212d6:	a904      	add	r1, sp, #16
200212d8:	f10d 000f 	add.w	r0, sp, #15
200212dc:	f7ff fe54 	bl	20020f88 <sd1_get_rsp>
200212e0:	9b04      	ldr	r3, [sp, #16]
200212e2:	2b00      	cmp	r3, #0
200212e4:	db03      	blt.n	200212ee <sdio_sd_init+0xa2>
200212e6:	2002      	movs	r0, #2
200212e8:	f000 fb83 	bl	200219f2 <HAL_Delay_us>
200212ec:	e7e8      	b.n	200212c0 <sdio_sd_init+0x74>
200212ee:	2100      	movs	r1, #0
200212f0:	2002      	movs	r0, #2
200212f2:	f7ff fe01 	bl	20020ef8 <sd1_send_cmd>
200212f6:	3801      	subs	r0, #1
200212f8:	b2c0      	uxtb	r0, r0
200212fa:	2801      	cmp	r0, #1
200212fc:	f240 80a7 	bls.w	2002144e <sdio_sd_init+0x202>
20021300:	ab08      	add	r3, sp, #32
20021302:	9300      	str	r3, [sp, #0]
20021304:	aa0a      	add	r2, sp, #40	@ 0x28
20021306:	ab09      	add	r3, sp, #36	@ 0x24
20021308:	a90b      	add	r1, sp, #44	@ 0x2c
2002130a:	f10d 000f 	add.w	r0, sp, #15
2002130e:	f7ff fe3b 	bl	20020f88 <sd1_get_rsp>
20021312:	2100      	movs	r1, #0
20021314:	2003      	movs	r0, #3
20021316:	f7ff fdef 	bl	20020ef8 <sd1_send_cmd>
2002131a:	3801      	subs	r0, #1
2002131c:	b2c0      	uxtb	r0, r0
2002131e:	2801      	cmp	r0, #1
20021320:	d801      	bhi.n	20021326 <sdio_sd_init+0xda>
20021322:	2033      	movs	r0, #51	@ 0x33
20021324:	e7b9      	b.n	2002129a <sdio_sd_init+0x4e>
20021326:	ab06      	add	r3, sp, #24
20021328:	9400      	str	r4, [sp, #0]
2002132a:	aa05      	add	r2, sp, #20
2002132c:	a904      	add	r1, sp, #16
2002132e:	f10d 000f 	add.w	r0, sp, #15
20021332:	f7ff fe29 	bl	20020f88 <sd1_get_rsp>
20021336:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002133a:	2b03      	cmp	r3, #3
2002133c:	d1f1      	bne.n	20021322 <sdio_sd_init+0xd6>
2002133e:	9f04      	ldr	r7, [sp, #16]
20021340:	2009      	movs	r0, #9
20021342:	0c3d      	lsrs	r5, r7, #16
20021344:	042d      	lsls	r5, r5, #16
20021346:	4629      	mov	r1, r5
20021348:	f7ff fdd6 	bl	20020ef8 <sd1_send_cmd>
2002134c:	3801      	subs	r0, #1
2002134e:	b2c0      	uxtb	r0, r0
20021350:	2801      	cmp	r0, #1
20021352:	d97e      	bls.n	20021452 <sdio_sd_init+0x206>
20021354:	9400      	str	r4, [sp, #0]
20021356:	ab06      	add	r3, sp, #24
20021358:	aa05      	add	r2, sp, #20
2002135a:	a904      	add	r1, sp, #16
2002135c:	f10d 000f 	add.w	r0, sp, #15
20021360:	f7ff fe12 	bl	20020f88 <sd1_get_rsp>
20021364:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021368:	9c06      	ldr	r4, [sp, #24]
2002136a:	9907      	ldr	r1, [sp, #28]
2002136c:	0e23      	lsrs	r3, r4, #24
2002136e:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
20021372:	0e01      	lsrs	r1, r0, #24
20021374:	ea41 2104 	orr.w	r1, r1, r4, lsl #8
20021378:	9105      	str	r1, [sp, #20]
2002137a:	0e11      	lsrs	r1, r2, #24
2002137c:	9304      	str	r3, [sp, #16]
2002137e:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
20021382:	0212      	lsls	r2, r2, #8
20021384:	0f9b      	lsrs	r3, r3, #30
20021386:	9106      	str	r1, [sp, #24]
20021388:	9207      	str	r2, [sp, #28]
2002138a:	d01b      	beq.n	200213c4 <sdio_sd_init+0x178>
2002138c:	2b01      	cmp	r3, #1
2002138e:	d162      	bne.n	20021456 <sdio_sd_init+0x20a>
20021390:	2300      	movs	r3, #0
20021392:	4a37      	ldr	r2, [pc, #220]	@ (20021470 <sdio_sd_init+0x224>)
20021394:	4c33      	ldr	r4, [pc, #204]	@ (20021464 <sdio_sd_init+0x218>)
20021396:	7013      	strb	r3, [r2, #0]
20021398:	f44f 63a0 	mov.w	r3, #1280	@ 0x500
2002139c:	6323      	str	r3, [r4, #48]	@ 0x30
2002139e:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200213a0:	2600      	movs	r6, #0
200213a2:	f043 0302 	orr.w	r3, r3, #2
200213a6:	6323      	str	r3, [r4, #48]	@ 0x30
200213a8:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200213ac:	4629      	mov	r1, r5
200213ae:	6223      	str	r3, [r4, #32]
200213b0:	2007      	movs	r0, #7
200213b2:	63e6      	str	r6, [r4, #60]	@ 0x3c
200213b4:	f7ff fda0 	bl	20020ef8 <sd1_send_cmd>
200213b8:	3801      	subs	r0, #1
200213ba:	b2c0      	uxtb	r0, r0
200213bc:	2801      	cmp	r0, #1
200213be:	d803      	bhi.n	200213c8 <sdio_sd_init+0x17c>
200213c0:	2037      	movs	r0, #55	@ 0x37
200213c2:	e76a      	b.n	2002129a <sdio_sd_init+0x4e>
200213c4:	2301      	movs	r3, #1
200213c6:	e7e4      	b.n	20021392 <sdio_sd_init+0x146>
200213c8:	ad07      	add	r5, sp, #28
200213ca:	ab06      	add	r3, sp, #24
200213cc:	9500      	str	r5, [sp, #0]
200213ce:	aa05      	add	r2, sp, #20
200213d0:	a904      	add	r1, sp, #16
200213d2:	f10d 000f 	add.w	r0, sp, #15
200213d6:	f7ff fdd7 	bl	20020f88 <sd1_get_rsp>
200213da:	f89d 300f 	ldrb.w	r3, [sp, #15]
200213de:	2b07      	cmp	r3, #7
200213e0:	d1ee      	bne.n	200213c0 <sdio_sd_init+0x174>
200213e2:	4631      	mov	r1, r6
200213e4:	2006      	movs	r0, #6
200213e6:	0c3a      	lsrs	r2, r7, #16
200213e8:	f7ff fdb0 	bl	20020f4c <sd1_send_acmd>
200213ec:	3801      	subs	r0, #1
200213ee:	b2c0      	uxtb	r0, r0
200213f0:	2801      	cmp	r0, #1
200213f2:	d932      	bls.n	2002145a <sdio_sd_init+0x20e>
200213f4:	2101      	movs	r1, #1
200213f6:	4630      	mov	r0, r6
200213f8:	f7ff fdd6 	bl	20020fa8 <sd1_read>
200213fc:	4631      	mov	r1, r6
200213fe:	2011      	movs	r0, #17
20021400:	f7ff fd7a 	bl	20020ef8 <sd1_send_cmd>
20021404:	3801      	subs	r0, #1
20021406:	b2c0      	uxtb	r0, r0
20021408:	2801      	cmp	r0, #1
2002140a:	d801      	bhi.n	20021410 <sdio_sd_init+0x1c4>
2002140c:	2052      	movs	r0, #82	@ 0x52
2002140e:	e744      	b.n	2002129a <sdio_sd_init+0x4e>
20021410:	ab06      	add	r3, sp, #24
20021412:	9500      	str	r5, [sp, #0]
20021414:	aa05      	add	r2, sp, #20
20021416:	a904      	add	r1, sp, #16
20021418:	f10d 000f 	add.w	r0, sp, #15
2002141c:	f7ff fdb4 	bl	20020f88 <sd1_get_rsp>
20021420:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021424:	2b11      	cmp	r3, #17
20021426:	d1f1      	bne.n	2002140c <sdio_sd_init+0x1c0>
20021428:	f04f 33ff 	mov.w	r3, #4294967295
2002142c:	6023      	str	r3, [r4, #0]
2002142e:	2320      	movs	r3, #32
20021430:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021432:	f7ff fdc9 	bl	20020fc8 <sd1_wait_read>
20021436:	6823      	ldr	r3, [r4, #0]
20021438:	061b      	lsls	r3, r3, #24
2002143a:	d410      	bmi.n	2002145e <sdio_sd_init+0x212>
2002143c:	6823      	ldr	r3, [r4, #0]
2002143e:	f013 0f40 	tst.w	r3, #64	@ 0x40
20021442:	bf14      	ite	ne
20021444:	2044      	movne	r0, #68	@ 0x44
20021446:	2001      	moveq	r0, #1
20021448:	e727      	b.n	2002129a <sdio_sd_init+0x4e>
2002144a:	2034      	movs	r0, #52	@ 0x34
2002144c:	e725      	b.n	2002129a <sdio_sd_init+0x4e>
2002144e:	2032      	movs	r0, #50	@ 0x32
20021450:	e723      	b.n	2002129a <sdio_sd_init+0x4e>
20021452:	2039      	movs	r0, #57	@ 0x39
20021454:	e721      	b.n	2002129a <sdio_sd_init+0x4e>
20021456:	2054      	movs	r0, #84	@ 0x54
20021458:	e71f      	b.n	2002129a <sdio_sd_init+0x4e>
2002145a:	2036      	movs	r0, #54	@ 0x36
2002145c:	e71d      	b.n	2002129a <sdio_sd_init+0x4e>
2002145e:	204f      	movs	r0, #79	@ 0x4f
20021460:	e71b      	b.n	2002129a <sdio_sd_init+0x4e>
20021462:	bf00      	nop
20021464:	50045000 	.word	0x50045000
20021468:	00016700 	.word	0x00016700
2002146c:	40ff8000 	.word	0x40ff8000
20021470:	20042c0d 	.word	0x20042c0d

20021474 <sd_read_data>:
20021474:	b570      	push	{r4, r5, r6, lr}
20021476:	4606      	mov	r6, r0
20021478:	460d      	mov	r5, r1
2002147a:	2000      	movs	r0, #0
2002147c:	2101      	movs	r1, #1
2002147e:	b088      	sub	sp, #32
20021480:	4614      	mov	r4, r2
20021482:	f7ff fd91 	bl	20020fa8 <sd1_read>
20021486:	4b1b      	ldr	r3, [pc, #108]	@ (200214f4 <sd_read_data+0x80>)
20021488:	781b      	ldrb	r3, [r3, #0]
2002148a:	b903      	cbnz	r3, 2002148e <sd_read_data+0x1a>
2002148c:	0a76      	lsrs	r6, r6, #9
2002148e:	4631      	mov	r1, r6
20021490:	2011      	movs	r0, #17
20021492:	f7ff fd31 	bl	20020ef8 <sd1_send_cmd>
20021496:	3801      	subs	r0, #1
20021498:	b2c0      	uxtb	r0, r0
2002149a:	2801      	cmp	r0, #1
2002149c:	d802      	bhi.n	200214a4 <sd_read_data+0x30>
2002149e:	2000      	movs	r0, #0
200214a0:	b008      	add	sp, #32
200214a2:	bd70      	pop	{r4, r5, r6, pc}
200214a4:	ab07      	add	r3, sp, #28
200214a6:	9300      	str	r3, [sp, #0]
200214a8:	aa05      	add	r2, sp, #20
200214aa:	ab06      	add	r3, sp, #24
200214ac:	a904      	add	r1, sp, #16
200214ae:	f10d 000f 	add.w	r0, sp, #15
200214b2:	f7ff fd69 	bl	20020f88 <sd1_get_rsp>
200214b6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200214ba:	2b11      	cmp	r3, #17
200214bc:	d1ef      	bne.n	2002149e <sd_read_data+0x2a>
200214be:	f04f 33ff 	mov.w	r3, #4294967295
200214c2:	4e0d      	ldr	r6, [pc, #52]	@ (200214f8 <sd_read_data+0x84>)
200214c4:	6033      	str	r3, [r6, #0]
200214c6:	2320      	movs	r3, #32
200214c8:	62f3      	str	r3, [r6, #44]	@ 0x2c
200214ca:	f7ff fd7d 	bl	20020fc8 <sd1_wait_read>
200214ce:	6833      	ldr	r3, [r6, #0]
200214d0:	061a      	lsls	r2, r3, #24
200214d2:	d4e4      	bmi.n	2002149e <sd_read_data+0x2a>
200214d4:	6833      	ldr	r3, [r6, #0]
200214d6:	065b      	lsls	r3, r3, #25
200214d8:	d4e1      	bmi.n	2002149e <sd_read_data+0x2a>
200214da:	f024 0303 	bic.w	r3, r4, #3
200214de:	442b      	add	r3, r5
200214e0:	429d      	cmp	r5, r3
200214e2:	d101      	bne.n	200214e8 <sd_read_data+0x74>
200214e4:	4620      	mov	r0, r4
200214e6:	e7db      	b.n	200214a0 <sd_read_data+0x2c>
200214e8:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
200214ec:	f845 2b04 	str.w	r2, [r5], #4
200214f0:	e7f6      	b.n	200214e0 <sd_read_data+0x6c>
200214f2:	bf00      	nop
200214f4:	20042c0d 	.word	0x20042c0d
200214f8:	50045000 	.word	0x50045000

200214fc <is_addr_in_nor>:
200214fc:	4b09      	ldr	r3, [pc, #36]	@ (20021524 <is_addr_in_nor+0x28>)
200214fe:	4602      	mov	r2, r0
20021500:	681b      	ldr	r3, [r3, #0]
20021502:	b163      	cbz	r3, 2002151e <is_addr_in_nor+0x22>
20021504:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
20021508:	b948      	cbnz	r0, 2002151e <is_addr_in_nor+0x22>
2002150a:	6919      	ldr	r1, [r3, #16]
2002150c:	4291      	cmp	r1, r2
2002150e:	d807      	bhi.n	20021520 <is_addr_in_nor+0x24>
20021510:	695b      	ldr	r3, [r3, #20]
20021512:	4419      	add	r1, r3
20021514:	4291      	cmp	r1, r2
20021516:	bf94      	ite	ls
20021518:	2000      	movls	r0, #0
2002151a:	2001      	movhi	r0, #1
2002151c:	4770      	bx	lr
2002151e:	2000      	movs	r0, #0
20021520:	4770      	bx	lr
20021522:	bf00      	nop
20021524:	20046d38 	.word	0x20046d38

20021528 <sifli_verify_img_cmac_hash>:
20021528:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
2002152c:	461d      	mov	r5, r3
2002152e:	4b16      	ldr	r3, [pc, #88]	@ (20021588 <sifli_verify_img_cmac_hash+0x60>)
20021530:	460e      	mov	r6, r1
20021532:	681b      	ldr	r3, [r3, #0]
20021534:	4617      	mov	r7, r2
20021536:	b092      	sub	sp, #72	@ 0x48
20021538:	b12b      	cbz	r3, 20021546 <sifli_verify_img_cmac_hash+0x1e>
2002153a:	b920      	cbnz	r0, 20021546 <sifli_verify_img_cmac_hash+0x1e>
2002153c:	2220      	movs	r2, #32
2002153e:	2002      	movs	r0, #2
20021540:	4912      	ldr	r1, [pc, #72]	@ (2002158c <sifli_verify_img_cmac_hash+0x64>)
20021542:	4798      	blx	r3
20021544:	4811      	ldr	r0, [pc, #68]	@ (2002158c <sifli_verify_img_cmac_hash+0x64>)
20021546:	4601      	mov	r1, r0
20021548:	2220      	movs	r2, #32
2002154a:	a803      	add	r0, sp, #12
2002154c:	f004 fa40 	bl	200259d0 <sf_crypto_aes_cmac_init>
20021550:	4604      	mov	r4, r0
20021552:	b100      	cbz	r0, 20021556 <sifli_verify_img_cmac_hash+0x2e>
20021554:	e7fe      	b.n	20021554 <sifli_verify_img_cmac_hash+0x2c>
20021556:	f8df 8038 	ldr.w	r8, [pc, #56]	@ 20021590 <sifli_verify_img_cmac_hash+0x68>
2002155a:	2301      	movs	r3, #1
2002155c:	463a      	mov	r2, r7
2002155e:	4631      	mov	r1, r6
20021560:	f8cd 8000 	str.w	r8, [sp]
20021564:	a803      	add	r0, sp, #12
20021566:	f004 fa70 	bl	20025a4a <sf_crypto_aes_cmac_calc>
2002156a:	b950      	cbnz	r0, 20021582 <sifli_verify_img_cmac_hash+0x5a>
2002156c:	2210      	movs	r2, #16
2002156e:	4629      	mov	r1, r5
20021570:	4640      	mov	r0, r8
20021572:	f004 fe93 	bl	2002629c <memcmp>
20021576:	fab0 f080 	clz	r0, r0
2002157a:	0940      	lsrs	r0, r0, #5
2002157c:	b012      	add	sp, #72	@ 0x48
2002157e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021582:	4620      	mov	r0, r4
20021584:	e7fa      	b.n	2002157c <sifli_verify_img_cmac_hash+0x54>
20021586:	bf00      	nop
20021588:	2004713c 	.word	0x2004713c
2002158c:	2004c968 	.word	0x2004c968
20021590:	2004c988 	.word	0x2004c988

20021594 <sboot_init>:
20021594:	b507      	push	{r0, r1, r2, lr}
20021596:	f7ff fb7d 	bl	20020c94 <sifli_hw_efuse_load_bank0>
2002159a:	b150      	cbz	r0, 200215b2 <sboot_init+0x1e>
2002159c:	2302      	movs	r3, #2
2002159e:	21ee      	movs	r1, #238	@ 0xee
200215a0:	f10d 0207 	add.w	r2, sp, #7
200215a4:	f006 fbe4 	bl	20027d70 <HAL_EFUSE_Extract>
200215a8:	2800      	cmp	r0, #0
200215aa:	dc08      	bgt.n	200215be <sboot_init+0x2a>
200215ac:	b003      	add	sp, #12
200215ae:	f85d fb04 	ldr.w	pc, [sp], #4
200215b2:	4807      	ldr	r0, [pc, #28]	@ (200215d0 <sboot_init+0x3c>)
200215b4:	b003      	add	sp, #12
200215b6:	f85d eb04 	ldr.w	lr, [sp], #4
200215ba:	f004 bd91 	b.w	200260e0 <puts>
200215be:	f89d 3007 	ldrb.w	r3, [sp, #7]
200215c2:	2b00      	cmp	r3, #0
200215c4:	d0f2      	beq.n	200215ac <sboot_init+0x18>
200215c6:	2201      	movs	r2, #1
200215c8:	4b02      	ldr	r3, [pc, #8]	@ (200215d4 <sboot_init+0x40>)
200215ca:	701a      	strb	r2, [r3, #0]
200215cc:	e7ee      	b.n	200215ac <sboot_init+0x18>
200215ce:	bf00      	nop
200215d0:	20026b6c 	.word	0x20026b6c
200215d4:	2004c964 	.word	0x2004c964

200215d8 <run_img>:
200215d8:	f8d0 d000 	ldr.w	sp, [r0]
200215dc:	f8d0 f004 	ldr.w	pc, [r0, #4]
200215e0:	4770      	bx	lr
	...

200215e4 <dfu_boot_img_in_flash>:
200215e4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200215e8:	4e27      	ldr	r6, [pc, #156]	@ (20021688 <dfu_boot_img_in_flash+0xa4>)
200215ea:	1e84      	subs	r4, r0, #2
200215ec:	eb06 1300 	add.w	r3, r6, r0, lsl #4
200215f0:	eb06 2040 	add.w	r0, r6, r0, lsl #9
200215f4:	f8d0 7c00 	ldr.w	r7, [r0, #3072]	@ 0xc00
200215f8:	f8d3 8004 	ldr.w	r8, [r3, #4]
200215fc:	68dd      	ldr	r5, [r3, #12]
200215fe:	b177      	cbz	r7, 2002161e <dfu_boot_img_in_flash+0x3a>
20021600:	45a8      	cmp	r8, r5
20021602:	d00c      	beq.n	2002161e <dfu_boot_img_in_flash+0x3a>
20021604:	4628      	mov	r0, r5
20021606:	f7ff ff79 	bl	200214fc <is_addr_in_nor>
2002160a:	b940      	cbnz	r0, 2002161e <dfu_boot_img_in_flash+0x3a>
2002160c:	4b1f      	ldr	r3, [pc, #124]	@ (2002168c <dfu_boot_img_in_flash+0xa8>)
2002160e:	4629      	mov	r1, r5
20021610:	781a      	ldrb	r2, [r3, #0]
20021612:	4b1f      	ldr	r3, [pc, #124]	@ (20021690 <dfu_boot_img_in_flash+0xac>)
20021614:	4640      	mov	r0, r8
20021616:	681b      	ldr	r3, [r3, #0]
20021618:	eb07 1202 	add.w	r2, r7, r2, lsl #4
2002161c:	4798      	blx	r3
2002161e:	2c07      	cmp	r4, #7
20021620:	dc30      	bgt.n	20021684 <dfu_boot_img_in_flash+0xa0>
20021622:	4263      	negs	r3, r4
20021624:	f003 0303 	and.w	r3, r3, #3
20021628:	f004 0703 	and.w	r7, r4, #3
2002162c:	bf58      	it	pl
2002162e:	425f      	negpl	r7, r3
20021630:	2f02      	cmp	r7, #2
20021632:	d827      	bhi.n	20021684 <dfu_boot_img_in_flash+0xa0>
20021634:	4628      	mov	r0, r5
20021636:	f7ff ff61 	bl	200214fc <is_addr_in_nor>
2002163a:	b150      	cbz	r0, 20021652 <dfu_boot_img_in_flash+0x6e>
2002163c:	4815      	ldr	r0, [pc, #84]	@ (20021694 <dfu_boot_img_in_flash+0xb0>)
2002163e:	f104 0208 	add.w	r2, r4, #8
20021642:	0252      	lsls	r2, r2, #9
20021644:	4629      	mov	r1, r5
20021646:	58b2      	ldr	r2, [r6, r2]
20021648:	6800      	ldr	r0, [r0, #0]
2002164a:	eba8 0305 	sub.w	r3, r8, r5
2002164e:	f001 fd32 	bl	200230b6 <HAL_FLASH_ALIAS_CFG>
20021652:	4b0e      	ldr	r3, [pc, #56]	@ (2002168c <dfu_boot_img_in_flash+0xa8>)
20021654:	781b      	ldrb	r3, [r3, #0]
20021656:	b923      	cbnz	r3, 20021662 <dfu_boot_img_in_flash+0x7e>
20021658:	4628      	mov	r0, r5
2002165a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002165e:	f7ff bfbb 	b.w	200215d8 <run_img>
20021662:	2f01      	cmp	r7, #1
20021664:	d1f8      	bne.n	20021658 <dfu_boot_img_in_flash+0x74>
20021666:	3408      	adds	r4, #8
20021668:	0264      	lsls	r4, r4, #9
2002166a:	5932      	ldr	r2, [r6, r4]
2002166c:	4629      	mov	r1, r5
2002166e:	2000      	movs	r0, #0
20021670:	1953      	adds	r3, r2, r5
20021672:	f7ff ff59 	bl	20021528 <sifli_verify_img_cmac_hash>
20021676:	2800      	cmp	r0, #0
20021678:	d1ee      	bne.n	20021658 <dfu_boot_img_in_flash+0x74>
2002167a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002167e:	4806      	ldr	r0, [pc, #24]	@ (20021698 <dfu_boot_img_in_flash+0xb4>)
20021680:	f004 bd2e 	b.w	200260e0 <puts>
20021684:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021688:	20047140 	.word	0x20047140
2002168c:	2004c964 	.word	0x2004c964
20021690:	20046d44 	.word	0x20046d44
20021694:	20046d38 	.word	0x20046d38
20021698:	20026b7d 	.word	0x20026b7d

2002169c <_close>:
2002169c:	f04f 30ff 	mov.w	r0, #4294967295
200216a0:	4770      	bx	lr

200216a2 <_lseek>:
200216a2:	f04f 30ff 	mov.w	r0, #4294967295
200216a6:	4770      	bx	lr

200216a8 <_read>:
200216a8:	2000      	movs	r0, #0
200216aa:	4770      	bx	lr

200216ac <_fstat>:
200216ac:	2000      	movs	r0, #0
200216ae:	4770      	bx	lr

200216b0 <_isatty>:
200216b0:	2001      	movs	r0, #1
200216b2:	4770      	bx	lr

200216b4 <flash_memset>:
200216b4:	4603      	mov	r3, r0
200216b6:	4402      	add	r2, r0
200216b8:	4293      	cmp	r3, r2
200216ba:	d100      	bne.n	200216be <flash_memset+0xa>
200216bc:	4770      	bx	lr
200216be:	f803 1b01 	strb.w	r1, [r3], #1
200216c2:	e7f9      	b.n	200216b8 <flash_memset+0x4>

200216c4 <bsp_psramc_init>:
200216c4:	b570      	push	{r4, r5, r6, lr}
200216c6:	b086      	sub	sp, #24
200216c8:	f000 f832 	bl	20021730 <BSP_GetFlash1DIV>
200216cc:	2100      	movs	r1, #0
200216ce:	2240      	movs	r2, #64	@ 0x40
200216d0:	4605      	mov	r5, r0
200216d2:	4815      	ldr	r0, [pc, #84]	@ (20021728 <bsp_psramc_init+0x64>)
200216d4:	f7ff ffee 	bl	200216b4 <flash_memset>
200216d8:	2214      	movs	r2, #20
200216da:	a801      	add	r0, sp, #4
200216dc:	f7ff ffea 	bl	200216b4 <flash_memset>
200216e0:	4b12      	ldr	r3, [pc, #72]	@ (2002172c <bsp_psramc_init+0x68>)
200216e2:	2001      	movs	r0, #1
200216e4:	9301      	str	r3, [sp, #4]
200216e6:	f006 f9f9 	bl	20027adc <bsp_psram_get_mpi_mode>
200216ea:	2800      	cmp	r0, #0
200216ec:	bf08      	it	eq
200216ee:	2003      	moveq	r0, #3
200216f0:	f04f 5380 	mov.w	r3, #268435456	@ 0x10000000
200216f4:	2210      	movs	r2, #16
200216f6:	9005      	str	r0, [sp, #20]
200216f8:	e9cd 3203 	strd	r3, r2, [sp, #12]
200216fc:	f000 f8bf 	bl	2002187e <SystemPowerOnModeGet>
20021700:	1e41      	subs	r1, r0, #1
20021702:	4248      	negs	r0, r1
20021704:	4e08      	ldr	r6, [pc, #32]	@ (20021728 <bsp_psramc_init+0x64>)
20021706:	4148      	adcs	r0, r1
20021708:	f886 002f 	strb.w	r0, [r6, #47]	@ 0x2f
2002170c:	f006 f9fa 	bl	20027b04 <bsp_psram1_pinmux_init>
20021710:	4604      	mov	r4, r0
20021712:	b100      	cbz	r0, 20021716 <bsp_psramc_init+0x52>
20021714:	e7fe      	b.n	20021714 <bsp_psramc_init+0x50>
20021716:	462a      	mov	r2, r5
20021718:	4630      	mov	r0, r6
2002171a:	a901      	add	r1, sp, #4
2002171c:	f002 fdf4 	bl	20024308 <HAL_MPI_PSRAM_Init>
20021720:	4620      	mov	r0, r4
20021722:	b006      	add	sp, #24
20021724:	bd70      	pop	{r4, r5, r6, pc}
20021726:	bf00      	nop
20021728:	2004c99c 	.word	0x2004c99c
2002172c:	50041000 	.word	0x50041000

20021730 <BSP_GetFlash1DIV>:
20021730:	4b01      	ldr	r3, [pc, #4]	@ (20021738 <BSP_GetFlash1DIV+0x8>)
20021732:	8818      	ldrh	r0, [r3, #0]
20021734:	4770      	bx	lr
20021736:	bf00      	nop
20021738:	20042c12 	.word	0x20042c12

2002173c <BSP_GetFlash2DIV>:
2002173c:	4b01      	ldr	r3, [pc, #4]	@ (20021744 <BSP_GetFlash2DIV+0x8>)
2002173e:	8818      	ldrh	r0, [r3, #0]
20021740:	4770      	bx	lr
20021742:	bf00      	nop
20021744:	20042c10 	.word	0x20042c10

20021748 <BSP_GetFlash3DIV>:
20021748:	4b01      	ldr	r3, [pc, #4]	@ (20021750 <BSP_GetFlash3DIV+0x8>)
2002174a:	8818      	ldrh	r0, [r3, #0]
2002174c:	4770      	bx	lr
2002174e:	bf00      	nop
20021750:	20042c0e 	.word	0x20042c0e

20021754 <BSP_SetFlash1DIV>:
20021754:	4b01      	ldr	r3, [pc, #4]	@ (2002175c <BSP_SetFlash1DIV+0x8>)
20021756:	8018      	strh	r0, [r3, #0]
20021758:	4770      	bx	lr
2002175a:	bf00      	nop
2002175c:	20042c12 	.word	0x20042c12

20021760 <BSP_SetFlash2DIV>:
20021760:	4b01      	ldr	r3, [pc, #4]	@ (20021768 <BSP_SetFlash2DIV+0x8>)
20021762:	8018      	strh	r0, [r3, #0]
20021764:	4770      	bx	lr
20021766:	bf00      	nop
20021768:	20042c10 	.word	0x20042c10

2002176c <BSP_SetFlash3DIV>:
2002176c:	4b01      	ldr	r3, [pc, #4]	@ (20021774 <BSP_SetFlash3DIV+0x8>)
2002176e:	8018      	strh	r0, [r3, #0]
20021770:	4770      	bx	lr
20021772:	bf00      	nop
20021774:	20042c0e 	.word	0x20042c0e

20021778 <BSP_GetOtpBase>:
20021778:	4800      	ldr	r0, [pc, #0]	@ (2002177c <BSP_GetOtpBase+0x4>)
2002177a:	4770      	bx	lr
2002177c:	1200e000 	.word	0x1200e000

20021780 <pmu_ldo_inc>:
20021780:	2000      	movs	r0, #0
20021782:	4770      	bx	lr

20021784 <pmu_ldo_recover>:
20021784:	2000      	movs	r0, #0
20021786:	4770      	bx	lr

20021788 <hw_preinit0>:
20021788:	4770      	bx	lr
	...

2002178c <mpu_dcache_clean>:
2002178c:	f1b0 4fc0 	cmp.w	r0, #1610612736	@ 0x60000000
20021790:	b570      	push	{r4, r5, r6, lr}
20021792:	d336      	bcc.n	20021802 <mpu_dcache_clean+0x76>
20021794:	f5b1 4f80 	cmp.w	r1, #16384	@ 0x4000
20021798:	d921      	bls.n	200217de <mpu_dcache_clean+0x52>
2002179a:	2300      	movs	r3, #0
2002179c:	491a      	ldr	r1, [pc, #104]	@ (20021808 <mpu_dcache_clean+0x7c>)
2002179e:	f8c1 3084 	str.w	r3, [r1, #132]	@ 0x84
200217a2:	f3bf 8f4f 	dsb	sy
200217a6:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
200217aa:	f8d1 3080 	ldr.w	r3, [r1, #128]	@ 0x80
200217ae:	f3c3 00c9 	ubfx	r0, r3, #3, #10
200217b2:	f3c3 334e 	ubfx	r3, r3, #13, #15
200217b6:	015b      	lsls	r3, r3, #5
200217b8:	4602      	mov	r2, r0
200217ba:	ea03 0604 	and.w	r6, r3, r4
200217be:	ea46 7582 	orr.w	r5, r6, r2, lsl #30
200217c2:	3a01      	subs	r2, #1
200217c4:	f8c1 526c 	str.w	r5, [r1, #620]	@ 0x26c
200217c8:	d2f9      	bcs.n	200217be <mpu_dcache_clean+0x32>
200217ca:	3b20      	subs	r3, #32
200217cc:	f113 0f20 	cmn.w	r3, #32
200217d0:	d1f2      	bne.n	200217b8 <mpu_dcache_clean+0x2c>
200217d2:	f3bf 8f4f 	dsb	sy
200217d6:	f3bf 8f6f 	isb	sy
200217da:	2001      	movs	r0, #1
200217dc:	bd70      	pop	{r4, r5, r6, pc}
200217de:	b181      	cbz	r1, 20021802 <mpu_dcache_clean+0x76>
200217e0:	f000 031f 	and.w	r3, r0, #31
200217e4:	440b      	add	r3, r1
200217e6:	f3bf 8f4f 	dsb	sy
200217ea:	4907      	ldr	r1, [pc, #28]	@ (20021808 <mpu_dcache_clean+0x7c>)
200217ec:	4403      	add	r3, r0
200217ee:	f8c1 0268 	str.w	r0, [r1, #616]	@ 0x268
200217f2:	3020      	adds	r0, #32
200217f4:	1a1a      	subs	r2, r3, r0
200217f6:	2a00      	cmp	r2, #0
200217f8:	dcf9      	bgt.n	200217ee <mpu_dcache_clean+0x62>
200217fa:	f3bf 8f4f 	dsb	sy
200217fe:	f3bf 8f6f 	isb	sy
20021802:	2000      	movs	r0, #0
20021804:	e7ea      	b.n	200217dc <mpu_dcache_clean+0x50>
20021806:	bf00      	nop
20021808:	e000ed00 	.word	0xe000ed00

2002180c <cache_disable>:
2002180c:	b570      	push	{r4, r5, r6, lr}
2002180e:	f3bf 8f4f 	dsb	sy
20021812:	f3bf 8f6f 	isb	sy
20021816:	4a18      	ldr	r2, [pc, #96]	@ (20021878 <cache_disable+0x6c>)
20021818:	6953      	ldr	r3, [r2, #20]
2002181a:	f423 3300 	bic.w	r3, r3, #131072	@ 0x20000
2002181e:	6153      	str	r3, [r2, #20]
20021820:	2300      	movs	r3, #0
20021822:	f8c2 3250 	str.w	r3, [r2, #592]	@ 0x250
20021826:	f3bf 8f4f 	dsb	sy
2002182a:	f3bf 8f6f 	isb	sy
2002182e:	f8c2 3084 	str.w	r3, [r2, #132]	@ 0x84
20021832:	f3bf 8f4f 	dsb	sy
20021836:	6953      	ldr	r3, [r2, #20]
20021838:	f423 3380 	bic.w	r3, r3, #65536	@ 0x10000
2002183c:	6153      	str	r3, [r2, #20]
2002183e:	f3bf 8f4f 	dsb	sy
20021842:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
20021846:	f8d2 3080 	ldr.w	r3, [r2, #128]	@ 0x80
2002184a:	f3c3 00c9 	ubfx	r0, r3, #3, #10
2002184e:	f3c3 334e 	ubfx	r3, r3, #13, #15
20021852:	015b      	lsls	r3, r3, #5
20021854:	4601      	mov	r1, r0
20021856:	ea03 0604 	and.w	r6, r3, r4
2002185a:	ea46 7581 	orr.w	r5, r6, r1, lsl #30
2002185e:	3901      	subs	r1, #1
20021860:	f8c2 5274 	str.w	r5, [r2, #628]	@ 0x274
20021864:	d2f9      	bcs.n	2002185a <cache_disable+0x4e>
20021866:	3b20      	subs	r3, #32
20021868:	f113 0f20 	cmn.w	r3, #32
2002186c:	d1f2      	bne.n	20021854 <cache_disable+0x48>
2002186e:	f3bf 8f4f 	dsb	sy
20021872:	f3bf 8f6f 	isb	sy
20021876:	bd70      	pop	{r4, r5, r6, pc}
20021878:	e000ed00 	.word	0xe000ed00

2002187c <SystemPowerOnModeInit>:
2002187c:	4770      	bx	lr

2002187e <SystemPowerOnModeGet>:
2002187e:	2000      	movs	r0, #0
20021880:	4770      	bx	lr
	...

20021884 <SystemInit>:
20021884:	b508      	push	{r3, lr}
20021886:	4a0e      	ldr	r2, [pc, #56]	@ (200218c0 <SystemInit+0x3c>)
20021888:	4b0e      	ldr	r3, [pc, #56]	@ (200218c4 <SystemInit+0x40>)
2002188a:	609a      	str	r2, [r3, #8]
2002188c:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021890:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021894:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021898:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
2002189c:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
200218a0:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
200218a4:	f7ff ff70 	bl	20021788 <hw_preinit0>
200218a8:	f7ff ffb0 	bl	2002180c <cache_disable>
200218ac:	f7fe fcfe 	bl	200202ac <mpu_config>
200218b0:	f7fe fcfd 	bl	200202ae <cache_enable>
200218b4:	f7ff ffe2 	bl	2002187c <SystemPowerOnModeInit>
200218b8:	4b03      	ldr	r3, [pc, #12]	@ (200218c8 <SystemInit+0x44>)
200218ba:	4a04      	ldr	r2, [pc, #16]	@ (200218cc <SystemInit+0x48>)
200218bc:	601a      	str	r2, [r3, #0]
200218be:	bd08      	pop	{r3, pc}
200218c0:	20020000 	.word	0x20020000
200218c4:	e000ed00 	.word	0xe000ed00
200218c8:	20042c14 	.word	0x20042c14
200218cc:	017d7840 	.word	0x017d7840

200218d0 <Reset_Handler>:
200218d0:	f8df d048 	ldr.w	sp, [pc, #72]	@ 2002191c <ACPU2HCPU_IRQHandler+0x2>
200218d4:	4812      	ldr	r0, [pc, #72]	@ (20021920 <ACPU2HCPU_IRQHandler+0x6>)
200218d6:	f380 880a 	msr	MSPLIM, r0
200218da:	f7ff ffd3 	bl	20021884 <SystemInit>
200218de:	4c11      	ldr	r4, [pc, #68]	@ (20021924 <ACPU2HCPU_IRQHandler+0xa>)
200218e0:	4d11      	ldr	r5, [pc, #68]	@ (20021928 <ACPU2HCPU_IRQHandler+0xe>)
200218e2:	42ac      	cmp	r4, r5
200218e4:	da09      	bge.n	200218fa <Reset_Handler+0x2a>
200218e6:	6821      	ldr	r1, [r4, #0]
200218e8:	6862      	ldr	r2, [r4, #4]
200218ea:	68a3      	ldr	r3, [r4, #8]
200218ec:	3b04      	subs	r3, #4
200218ee:	bfa2      	ittt	ge
200218f0:	58c8      	ldrge	r0, [r1, r3]
200218f2:	50d0      	strge	r0, [r2, r3]
200218f4:	e7fa      	bge.n	200218ec <Reset_Handler+0x1c>
200218f6:	340c      	adds	r4, #12
200218f8:	e7f3      	b.n	200218e2 <Reset_Handler+0x12>
200218fa:	4b0c      	ldr	r3, [pc, #48]	@ (2002192c <ACPU2HCPU_IRQHandler+0x12>)
200218fc:	4c0c      	ldr	r4, [pc, #48]	@ (20021930 <ACPU2HCPU_IRQHandler+0x16>)
200218fe:	42a3      	cmp	r3, r4
20021900:	da08      	bge.n	20021914 <Reset_Handler+0x44>
20021902:	6819      	ldr	r1, [r3, #0]
20021904:	685a      	ldr	r2, [r3, #4]
20021906:	2000      	movs	r0, #0
20021908:	3a04      	subs	r2, #4
2002190a:	bfa4      	itt	ge
2002190c:	5088      	strge	r0, [r1, r2]
2002190e:	e7fb      	bge.n	20021908 <Reset_Handler+0x38>
20021910:	3308      	adds	r3, #8
20021912:	e7f4      	b.n	200218fe <Reset_Handler+0x2e>
20021914:	f7ff fab2 	bl	20020e7c <entry>

20021918 <HardFault_Handler>:
20021918:	e7fe      	b.n	20021918 <HardFault_Handler>

2002191a <ACPU2HCPU_IRQHandler>:
2002191a:	e7fe      	b.n	2002191a <ACPU2HCPU_IRQHandler>
2002191c:	20042000 	.word	0x20042000
20021920:	20040000 	.word	0x20040000
20021924:	20027f24 	.word	0x20027f24
20021928:	20027f30 	.word	0x20027f30
2002192c:	20027f30 	.word	0x20027f30
20021930:	20027f38 	.word	0x20027f38

20021934 <__aeabi_unwind_cpp_pr0>:
20021934:	2000      	movs	r0, #0
20021936:	4770      	bx	lr

20021938 <HAL_GetTick>:
20021938:	4b01      	ldr	r3, [pc, #4]	@ (20021940 <HAL_GetTick+0x8>)
2002193a:	6818      	ldr	r0, [r3, #0]
2002193c:	4770      	bx	lr
2002193e:	bf00      	nop
20021940:	2004c9e0 	.word	0x2004c9e0

20021944 <HAL_Delay_us_>:
20021944:	b538      	push	{r3, r4, r5, lr}
20021946:	4604      	mov	r4, r0
20021948:	4d16      	ldr	r5, [pc, #88]	@ (200219a4 <HAL_Delay_us_+0x60>)
2002194a:	b128      	cbz	r0, 20021958 <HAL_Delay_us_+0x14>
2002194c:	682b      	ldr	r3, [r5, #0]
2002194e:	b11b      	cbz	r3, 20021958 <HAL_Delay_us_+0x14>
20021950:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
20021954:	d90a      	bls.n	2002196c <HAL_Delay_us_+0x28>
20021956:	e7fe      	b.n	20021956 <HAL_Delay_us_+0x12>
20021958:	2000      	movs	r0, #0
2002195a:	f002 ff3f 	bl	200247dc <HAL_RCC_GetHCLKFreq>
2002195e:	4b12      	ldr	r3, [pc, #72]	@ (200219a8 <HAL_Delay_us_+0x64>)
20021960:	fbb0 f0f3 	udiv	r0, r0, r3
20021964:	6028      	str	r0, [r5, #0]
20021966:	2c00      	cmp	r4, #0
20021968:	d1f2      	bne.n	20021950 <HAL_Delay_us_+0xc>
2002196a:	bd38      	pop	{r3, r4, r5, pc}
2002196c:	4a0f      	ldr	r2, [pc, #60]	@ (200219ac <HAL_Delay_us_+0x68>)
2002196e:	6813      	ldr	r3, [r2, #0]
20021970:	f013 0301 	ands.w	r3, r3, #1
20021974:	d10d      	bne.n	20021992 <HAL_Delay_us_+0x4e>
20021976:	480e      	ldr	r0, [pc, #56]	@ (200219b0 <HAL_Delay_us_+0x6c>)
20021978:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
2002197c:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
20021980:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
20021984:	6053      	str	r3, [r2, #4]
20021986:	6813      	ldr	r3, [r2, #0]
20021988:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
2002198c:	f043 0301 	orr.w	r3, r3, #1
20021990:	6013      	str	r3, [r2, #0]
20021992:	682b      	ldr	r3, [r5, #0]
20021994:	4a05      	ldr	r2, [pc, #20]	@ (200219ac <HAL_Delay_us_+0x68>)
20021996:	435c      	muls	r4, r3
20021998:	6851      	ldr	r1, [r2, #4]
2002199a:	6853      	ldr	r3, [r2, #4]
2002199c:	1a5b      	subs	r3, r3, r1
2002199e:	429c      	cmp	r4, r3
200219a0:	d8fb      	bhi.n	2002199a <HAL_Delay_us_+0x56>
200219a2:	e7e2      	b.n	2002196a <HAL_Delay_us_+0x26>
200219a4:	2004c9dc 	.word	0x2004c9dc
200219a8:	000f4240 	.word	0x000f4240
200219ac:	e0001000 	.word	0xe0001000
200219b0:	e000ed00 	.word	0xe000ed00

200219b4 <HAL_Delay_us2_>:
200219b4:	b537      	push	{r0, r1, r2, r4, r5, lr}
200219b6:	9001      	str	r0, [sp, #4]
200219b8:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
200219bc:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
200219c0:	6944      	ldr	r4, [r0, #20]
200219c2:	9b01      	ldr	r3, [sp, #4]
200219c4:	4363      	muls	r3, r4
200219c6:	fbb3 f3f2 	udiv	r3, r3, r2
200219ca:	9301      	str	r3, [sp, #4]
200219cc:	2300      	movs	r3, #0
200219ce:	6981      	ldr	r1, [r0, #24]
200219d0:	6982      	ldr	r2, [r0, #24]
200219d2:	428a      	cmp	r2, r1
200219d4:	d0fc      	beq.n	200219d0 <HAL_Delay_us2_+0x1c>
200219d6:	bf25      	ittet	cs
200219d8:	1aa5      	subcs	r5, r4, r2
200219da:	195b      	addcs	r3, r3, r5
200219dc:	185b      	addcc	r3, r3, r1
200219de:	185b      	addcs	r3, r3, r1
200219e0:	9901      	ldr	r1, [sp, #4]
200219e2:	bf38      	it	cc
200219e4:	1a9b      	subcc	r3, r3, r2
200219e6:	4299      	cmp	r1, r3
200219e8:	d801      	bhi.n	200219ee <HAL_Delay_us2_+0x3a>
200219ea:	b003      	add	sp, #12
200219ec:	bd30      	pop	{r4, r5, pc}
200219ee:	4611      	mov	r1, r2
200219f0:	e7ee      	b.n	200219d0 <HAL_Delay_us2_+0x1c>

200219f2 <HAL_Delay_us>:
200219f2:	4603      	mov	r3, r0
200219f4:	b570      	push	{r4, r5, r6, lr}
200219f6:	b1b8      	cbz	r0, 20021a28 <HAL_Delay_us+0x36>
200219f8:	f242 7510 	movw	r5, #10000	@ 0x2710
200219fc:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
20021a00:	42ab      	cmp	r3, r5
20021a02:	bf84      	itt	hi
20021a04:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
20021a08:	f242 7310 	movwhi	r3, #10000	@ 0x2710
20021a0c:	6932      	ldr	r2, [r6, #16]
20021a0e:	bf98      	it	ls
20021a10:	2400      	movls	r4, #0
20021a12:	4618      	mov	r0, r3
20021a14:	bf88      	it	hi
20021a16:	3c10      	subhi	r4, #16
20021a18:	07d3      	lsls	r3, r2, #31
20021a1a:	d508      	bpl.n	20021a2e <HAL_Delay_us+0x3c>
20021a1c:	f7ff ffca 	bl	200219b4 <HAL_Delay_us2_>
20021a20:	4623      	mov	r3, r4
20021a22:	2c00      	cmp	r4, #0
20021a24:	d1ec      	bne.n	20021a00 <HAL_Delay_us+0xe>
20021a26:	e001      	b.n	20021a2c <HAL_Delay_us+0x3a>
20021a28:	f7ff ff8c 	bl	20021944 <HAL_Delay_us_>
20021a2c:	bd70      	pop	{r4, r5, r6, pc}
20021a2e:	f7ff ff89 	bl	20021944 <HAL_Delay_us_>
20021a32:	e7f5      	b.n	20021a20 <HAL_Delay_us+0x2e>

20021a34 <WDT_IRQHandler>:
20021a34:	4770      	bx	lr

20021a36 <DBG_Trigger_IRQHandler>:
20021a36:	4770      	bx	lr

20021a38 <NMI_Handler>:
20021a38:	b508      	push	{r3, lr}
20021a3a:	4b05      	ldr	r3, [pc, #20]	@ (20021a50 <NMI_Handler+0x18>)
20021a3c:	6a1b      	ldr	r3, [r3, #32]
20021a3e:	005b      	lsls	r3, r3, #1
20021a40:	d502      	bpl.n	20021a48 <NMI_Handler+0x10>
20021a42:	f7ff fff8 	bl	20021a36 <DBG_Trigger_IRQHandler>
20021a46:	bd08      	pop	{r3, pc}
20021a48:	f7ff fff4 	bl	20021a34 <WDT_IRQHandler>
20021a4c:	e7fb      	b.n	20021a46 <NMI_Handler+0xe>
20021a4e:	bf00      	nop
20021a50:	5000b000 	.word	0x5000b000

20021a54 <HAL_AES_run_help>:
20021a54:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021a56:	4615      	mov	r5, r2
20021a58:	461e      	mov	r6, r3
20021a5a:	460b      	mov	r3, r1
20021a5c:	f101 4270 	add.w	r2, r1, #4026531840	@ 0xf0000000
20021a60:	4c13      	ldr	r4, [pc, #76]	@ (20021ab0 <HAL_AES_run_help+0x5c>)
20021a62:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20021a66:	bf38      	it	cc
20021a68:	f101 43a0 	addcc.w	r3, r1, #1342177280	@ 0x50000000
20021a6c:	6163      	str	r3, [r4, #20]
20021a6e:	462b      	mov	r3, r5
20021a70:	4607      	mov	r7, r0
20021a72:	f105 4270 	add.w	r2, r5, #4026531840	@ 0xf0000000
20021a76:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20021a7a:	bf38      	it	cc
20021a7c:	f105 43a0 	addcc.w	r3, r5, #1342177280	@ 0x50000000
20021a80:	61a3      	str	r3, [r4, #24]
20021a82:	f106 030f 	add.w	r3, r6, #15
20021a86:	111b      	asrs	r3, r3, #4
20021a88:	61e3      	str	r3, [r4, #28]
20021a8a:	4608      	mov	r0, r1
20021a8c:	6923      	ldr	r3, [r4, #16]
20021a8e:	b10f      	cbz	r7, 20021a94 <HAL_AES_run_help+0x40>
20021a90:	ea43 13c7 	orr.w	r3, r3, r7, lsl #7
20021a94:	6123      	str	r3, [r4, #16]
20021a96:	4631      	mov	r1, r6
20021a98:	f7ff fe78 	bl	2002178c <mpu_dcache_clean>
20021a9c:	4631      	mov	r1, r6
20021a9e:	4628      	mov	r0, r5
20021aa0:	f7ff fe74 	bl	2002178c <mpu_dcache_clean>
20021aa4:	4a02      	ldr	r2, [pc, #8]	@ (20021ab0 <HAL_AES_run_help+0x5c>)
20021aa6:	6813      	ldr	r3, [r2, #0]
20021aa8:	f043 0301 	orr.w	r3, r3, #1
20021aac:	6013      	str	r3, [r2, #0]
20021aae:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021ab0:	5000d000 	.word	0x5000d000

20021ab4 <HAL_AES_reset>:
20021ab4:	2202      	movs	r2, #2
20021ab6:	2000      	movs	r0, #0
20021ab8:	4b01      	ldr	r3, [pc, #4]	@ (20021ac0 <HAL_AES_reset+0xc>)
20021aba:	601a      	str	r2, [r3, #0]
20021abc:	6018      	str	r0, [r3, #0]
20021abe:	4770      	bx	lr
20021ac0:	5000d000 	.word	0x5000d000

20021ac4 <HAL_AES_init>:
20021ac4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021ac6:	4604      	mov	r4, r0
20021ac8:	200c      	movs	r0, #12
20021aca:	461e      	mov	r6, r3
20021acc:	460d      	mov	r5, r1
20021ace:	4617      	mov	r7, r2
20021ad0:	f002 ffd8 	bl	20024a84 <HAL_RCC_EnableModule>
20021ad4:	4b1c      	ldr	r3, [pc, #112]	@ (20021b48 <HAL_AES_init+0x84>)
20021ad6:	685b      	ldr	r3, [r3, #4]
20021ad8:	07db      	lsls	r3, r3, #31
20021ada:	d501      	bpl.n	20021ae0 <HAL_AES_init+0x1c>
20021adc:	f7ff ffea 	bl	20021ab4 <HAL_AES_reset>
20021ae0:	fab4 f184 	clz	r1, r4
20021ae4:	2d18      	cmp	r5, #24
20021ae6:	ea4f 1151 	mov.w	r1, r1, lsr #5
20021aea:	ea4f 1141 	mov.w	r1, r1, lsl #5
20021aee:	d01b      	beq.n	20021b28 <HAL_AES_init+0x64>
20021af0:	2d20      	cmp	r5, #32
20021af2:	d01b      	beq.n	20021b2c <HAL_AES_init+0x68>
20021af4:	2d10      	cmp	r5, #16
20021af6:	d124      	bne.n	20021b42 <HAL_AES_init+0x7e>
20021af8:	2300      	movs	r3, #0
20021afa:	b164      	cbz	r4, 20021b16 <HAL_AES_init+0x52>
20021afc:	4620      	mov	r0, r4
20021afe:	4a13      	ldr	r2, [pc, #76]	@ (20021b4c <HAL_AES_init+0x88>)
20021b00:	f025 0503 	bic.w	r5, r5, #3
20021b04:	4425      	add	r5, r4
20021b06:	1b12      	subs	r2, r2, r4
20021b08:	1814      	adds	r4, r2, r0
20021b0a:	f850 cb04 	ldr.w	ip, [r0], #4
20021b0e:	4285      	cmp	r5, r0
20021b10:	f8c4 c000 	str.w	ip, [r4]
20021b14:	d1f8      	bne.n	20021b08 <HAL_AES_init+0x44>
20021b16:	4331      	orrs	r1, r6
20021b18:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
20021b1c:	4b0a      	ldr	r3, [pc, #40]	@ (20021b48 <HAL_AES_init+0x84>)
20021b1e:	6119      	str	r1, [r3, #16]
20021b20:	b106      	cbz	r6, 20021b24 <HAL_AES_init+0x60>
20021b22:	b92f      	cbnz	r7, 20021b30 <HAL_AES_init+0x6c>
20021b24:	2000      	movs	r0, #0
20021b26:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021b28:	2301      	movs	r3, #1
20021b2a:	e7e6      	b.n	20021afa <HAL_AES_init+0x36>
20021b2c:	2302      	movs	r3, #2
20021b2e:	e7e4      	b.n	20021afa <HAL_AES_init+0x36>
20021b30:	683a      	ldr	r2, [r7, #0]
20021b32:	621a      	str	r2, [r3, #32]
20021b34:	687a      	ldr	r2, [r7, #4]
20021b36:	625a      	str	r2, [r3, #36]	@ 0x24
20021b38:	68ba      	ldr	r2, [r7, #8]
20021b3a:	629a      	str	r2, [r3, #40]	@ 0x28
20021b3c:	68fa      	ldr	r2, [r7, #12]
20021b3e:	62da      	str	r2, [r3, #44]	@ 0x2c
20021b40:	e7f0      	b.n	20021b24 <HAL_AES_init+0x60>
20021b42:	f04f 30ff 	mov.w	r0, #4294967295
20021b46:	e7ee      	b.n	20021b26 <HAL_AES_init+0x62>
20021b48:	5000d000 	.word	0x5000d000
20021b4c:	5000d030 	.word	0x5000d030

20021b50 <HAL_AES_run>:
20021b50:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021b52:	2708      	movs	r7, #8
20021b54:	4e17      	ldr	r6, [pc, #92]	@ (20021bb4 <HAL_AES_run+0x64>)
20021b56:	4614      	mov	r4, r2
20021b58:	461d      	mov	r5, r3
20021b5a:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
20021b5e:	f3bf 8f4f 	dsb	sy
20021b62:	f3bf 8f6f 	isb	sy
20021b66:	2700      	movs	r7, #0
20021b68:	4e13      	ldr	r6, [pc, #76]	@ (20021bb8 <HAL_AES_run+0x68>)
20021b6a:	60f7      	str	r7, [r6, #12]
20021b6c:	f7ff ff72 	bl	20021a54 <HAL_AES_run_help>
20021b70:	6873      	ldr	r3, [r6, #4]
20021b72:	07db      	lsls	r3, r3, #31
20021b74:	d4fc      	bmi.n	20021b70 <HAL_AES_run+0x20>
20021b76:	68b0      	ldr	r0, [r6, #8]
20021b78:	f000 0006 	and.w	r0, r0, #6
20021b7c:	3800      	subs	r0, #0
20021b7e:	bf18      	it	ne
20021b80:	2001      	movne	r0, #1
20021b82:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
20021b86:	d314      	bcc.n	20021bb2 <HAL_AES_run+0x62>
20021b88:	2d00      	cmp	r5, #0
20021b8a:	dd12      	ble.n	20021bb2 <HAL_AES_run+0x62>
20021b8c:	f004 031f 	and.w	r3, r4, #31
20021b90:	442b      	add	r3, r5
20021b92:	f024 021f 	bic.w	r2, r4, #31
20021b96:	f3bf 8f4f 	dsb	sy
20021b9a:	4c08      	ldr	r4, [pc, #32]	@ (20021bbc <HAL_AES_run+0x6c>)
20021b9c:	4413      	add	r3, r2
20021b9e:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
20021ba2:	3220      	adds	r2, #32
20021ba4:	1a99      	subs	r1, r3, r2
20021ba6:	2900      	cmp	r1, #0
20021ba8:	dcf9      	bgt.n	20021b9e <HAL_AES_run+0x4e>
20021baa:	f3bf 8f4f 	dsb	sy
20021bae:	f3bf 8f6f 	isb	sy
20021bb2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021bb4:	e000e100 	.word	0xe000e100
20021bb8:	5000d000 	.word	0x5000d000
20021bbc:	e000ed00 	.word	0xe000ed00

20021bc0 <HAL_NVIC_EnableIRQ>:
20021bc0:	2800      	cmp	r0, #0
20021bc2:	da00      	bge.n	20021bc6 <HAL_NVIC_EnableIRQ+0x6>
20021bc4:	e7fe      	b.n	20021bc4 <HAL_NVIC_EnableIRQ+0x4>
20021bc6:	2301      	movs	r3, #1
20021bc8:	0941      	lsrs	r1, r0, #5
20021bca:	4a03      	ldr	r2, [pc, #12]	@ (20021bd8 <HAL_NVIC_EnableIRQ+0x18>)
20021bcc:	f000 001f 	and.w	r0, r0, #31
20021bd0:	4083      	lsls	r3, r0
20021bd2:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20021bd6:	4770      	bx	lr
20021bd8:	e000e100 	.word	0xe000e100

20021bdc <HAL_NVIC_DisableIRQ>:
20021bdc:	2800      	cmp	r0, #0
20021bde:	da00      	bge.n	20021be2 <HAL_NVIC_DisableIRQ+0x6>
20021be0:	e7fe      	b.n	20021be0 <HAL_NVIC_DisableIRQ+0x4>
20021be2:	2201      	movs	r2, #1
20021be4:	4906      	ldr	r1, [pc, #24]	@ (20021c00 <HAL_NVIC_DisableIRQ+0x24>)
20021be6:	0943      	lsrs	r3, r0, #5
20021be8:	f000 001f 	and.w	r0, r0, #31
20021bec:	4082      	lsls	r2, r0
20021bee:	3320      	adds	r3, #32
20021bf0:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20021bf4:	f3bf 8f4f 	dsb	sy
20021bf8:	f3bf 8f6f 	isb	sy
20021bfc:	4770      	bx	lr
20021bfe:	bf00      	nop
20021c00:	e000e100 	.word	0xe000e100

20021c04 <DMA_IsChannelOwner>:
20021c04:	b510      	push	{r4, lr}
20021c06:	4911      	ldr	r1, [pc, #68]	@ (20021c4c <DMA_IsChannelOwner+0x48>)
20021c08:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021c0a:	4602      	mov	r2, r0
20021c0c:	428b      	cmp	r3, r1
20021c0e:	d003      	beq.n	20021c18 <DMA_IsChannelOwner+0x14>
20021c10:	490f      	ldr	r1, [pc, #60]	@ (20021c50 <DMA_IsChannelOwner+0x4c>)
20021c12:	428b      	cmp	r3, r1
20021c14:	d007      	beq.n	20021c26 <DMA_IsChannelOwner+0x22>
20021c16:	e7fe      	b.n	20021c16 <DMA_IsChannelOwner+0x12>
20021c18:	4b0e      	ldr	r3, [pc, #56]	@ (20021c54 <DMA_IsChannelOwner+0x50>)
20021c1a:	6d10      	ldr	r0, [r2, #80]	@ 0x50
20021c1c:	281f      	cmp	r0, #31
20021c1e:	ea4f 0190 	mov.w	r1, r0, lsr #2
20021c22:	d902      	bls.n	20021c2a <DMA_IsChannelOwner+0x26>
20021c24:	e7fe      	b.n	20021c24 <DMA_IsChannelOwner+0x20>
20021c26:	4b0c      	ldr	r3, [pc, #48]	@ (20021c58 <DMA_IsChannelOwner+0x54>)
20021c28:	e7f7      	b.n	20021c1a <DMA_IsChannelOwner+0x16>
20021c2a:	f3ef 8410 	mrs	r4, PRIMASK
20021c2e:	2001      	movs	r0, #1
20021c30:	f380 8810 	msr	PRIMASK, r0
20021c34:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
20021c38:	7900      	ldrb	r0, [r0, #4]
20021c3a:	b120      	cbz	r0, 20021c46 <DMA_IsChannelOwner+0x42>
20021c3c:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
20021c40:	1a83      	subs	r3, r0, r2
20021c42:	4258      	negs	r0, r3
20021c44:	4158      	adcs	r0, r3
20021c46:	f384 8810 	msr	PRIMASK, r4
20021c4a:	bd10      	pop	{r4, pc}
20021c4c:	50081000 	.word	0x50081000
20021c50:	40001000 	.word	0x40001000
20021c54:	2004ca24 	.word	0x2004ca24
20021c58:	2004c9e4 	.word	0x2004c9e4

20021c5c <DMA_FreeChannel.isra.0>:
20021c5c:	b538      	push	{r3, r4, r5, lr}
20021c5e:	4a13      	ldr	r2, [pc, #76]	@ (20021cac <DMA_FreeChannel.isra.0+0x50>)
20021c60:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021c62:	4293      	cmp	r3, r2
20021c64:	d003      	beq.n	20021c6e <DMA_FreeChannel.isra.0+0x12>
20021c66:	4a12      	ldr	r2, [pc, #72]	@ (20021cb0 <DMA_FreeChannel.isra.0+0x54>)
20021c68:	4293      	cmp	r3, r2
20021c6a:	d008      	beq.n	20021c7e <DMA_FreeChannel.isra.0+0x22>
20021c6c:	e7fe      	b.n	20021c6c <DMA_FreeChannel.isra.0+0x10>
20021c6e:	2132      	movs	r1, #50	@ 0x32
20021c70:	4a10      	ldr	r2, [pc, #64]	@ (20021cb4 <DMA_FreeChannel.isra.0+0x58>)
20021c72:	6d04      	ldr	r4, [r0, #80]	@ 0x50
20021c74:	2c1f      	cmp	r4, #31
20021c76:	ea4f 0394 	mov.w	r3, r4, lsr #2
20021c7a:	d903      	bls.n	20021c84 <DMA_FreeChannel.isra.0+0x28>
20021c7c:	e7fe      	b.n	20021c7c <DMA_FreeChannel.isra.0+0x20>
20021c7e:	2102      	movs	r1, #2
20021c80:	4a0d      	ldr	r2, [pc, #52]	@ (20021cb8 <DMA_FreeChannel.isra.0+0x5c>)
20021c82:	e7f6      	b.n	20021c72 <DMA_FreeChannel.isra.0+0x16>
20021c84:	f3ef 8410 	mrs	r4, PRIMASK
20021c88:	2501      	movs	r5, #1
20021c8a:	f385 8810 	msr	PRIMASK, r5
20021c8e:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
20021c92:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
20021c96:	4290      	cmp	r0, r2
20021c98:	d105      	bne.n	20021ca6 <DMA_FreeChannel.isra.0+0x4a>
20021c9a:	1858      	adds	r0, r3, r1
20021c9c:	b240      	sxtb	r0, r0
20021c9e:	f7ff ff9d 	bl	20021bdc <HAL_NVIC_DisableIRQ>
20021ca2:	2300      	movs	r3, #0
20021ca4:	712b      	strb	r3, [r5, #4]
20021ca6:	f384 8810 	msr	PRIMASK, r4
20021caa:	bd38      	pop	{r3, r4, r5, pc}
20021cac:	50081000 	.word	0x50081000
20021cb0:	40001000 	.word	0x40001000
20021cb4:	2004ca24 	.word	0x2004ca24
20021cb8:	2004c9e4 	.word	0x2004c9e4

20021cbc <DMA_SetBurstSizeAndFix.part.0>:
20021cbc:	6843      	ldr	r3, [r0, #4]
20021cbe:	2b10      	cmp	r3, #16
20021cc0:	d113      	bne.n	20021cea <DMA_SetBurstSizeAndFix.part.0+0x2e>
20021cc2:	8c02      	ldrh	r2, [r0, #32]
20021cc4:	b11a      	cbz	r2, 20021cce <DMA_SetBurstSizeAndFix.part.0+0x12>
20021cc6:	680b      	ldr	r3, [r1, #0]
20021cc8:	f043 5380 	orr.w	r3, r3, #268435456	@ 0x10000000
20021ccc:	600b      	str	r3, [r1, #0]
20021cce:	680b      	ldr	r3, [r1, #0]
20021cd0:	f362 6319 	bfi	r3, r2, #24, #2
20021cd4:	600b      	str	r3, [r1, #0]
20021cd6:	6842      	ldr	r2, [r0, #4]
20021cd8:	b94a      	cbnz	r2, 20021cee <DMA_SetBurstSizeAndFix.part.0+0x32>
20021cda:	8c02      	ldrh	r2, [r0, #32]
20021cdc:	b10a      	cbz	r2, 20021ce2 <DMA_SetBurstSizeAndFix.part.0+0x26>
20021cde:	f043 5300 	orr.w	r3, r3, #536870912	@ 0x20000000
20021ce2:	f362 639b 	bfi	r3, r2, #26, #2
20021ce6:	600b      	str	r3, [r1, #0]
20021ce8:	4770      	bx	lr
20021cea:	2203      	movs	r2, #3
20021cec:	e7ef      	b.n	20021cce <DMA_SetBurstSizeAndFix.part.0+0x12>
20021cee:	2203      	movs	r2, #3
20021cf0:	e7f7      	b.n	20021ce2 <DMA_SetBurstSizeAndFix.part.0+0x26>

20021cf2 <DMA_Init>:
20021cf2:	2302      	movs	r3, #2
20021cf4:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021cf6:	f880 3031 	strb.w	r3, [r0, #49]	@ 0x31
20021cfa:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021cfe:	4604      	mov	r4, r0
20021d00:	2b00      	cmp	r3, #0
20021d02:	bfa2      	ittt	ge
20021d04:	6803      	ldrge	r3, [r0, #0]
20021d06:	6a42      	ldrge	r2, [r0, #36]	@ 0x24
20021d08:	611a      	strge	r2, [r3, #16]
20021d0a:	6805      	ldr	r5, [r0, #0]
20021d0c:	6883      	ldr	r3, [r0, #8]
20021d0e:	6829      	ldr	r1, [r5, #0]
20021d10:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021d14:	f36f 110e 	bfc	r1, #4, #11
20021d18:	d052      	beq.n	20021dc0 <DMA_Init+0xce>
20021d1a:	6a02      	ldr	r2, [r0, #32]
20021d1c:	2a00      	cmp	r2, #0
20021d1e:	d051      	beq.n	20021dc4 <DMA_Init+0xd2>
20021d20:	f5b2 5f80 	cmp.w	r2, #4096	@ 0x1000
20021d24:	bf14      	ite	ne
20021d26:	f44f 5240 	movne.w	r2, #12288	@ 0x3000
20021d2a:	f44f 5200 	moveq.w	r2, #8192	@ 0x2000
20021d2e:	68e0      	ldr	r0, [r4, #12]
20021d30:	4303      	orrs	r3, r0
20021d32:	6920      	ldr	r0, [r4, #16]
20021d34:	4303      	orrs	r3, r0
20021d36:	6960      	ldr	r0, [r4, #20]
20021d38:	4303      	orrs	r3, r0
20021d3a:	69a0      	ldr	r0, [r4, #24]
20021d3c:	4303      	orrs	r3, r0
20021d3e:	69e0      	ldr	r0, [r4, #28]
20021d40:	4303      	orrs	r3, r0
20021d42:	430b      	orrs	r3, r1
20021d44:	4313      	orrs	r3, r2
20021d46:	9301      	str	r3, [sp, #4]
20021d48:	f994 3057 	ldrsb.w	r3, [r4, #87]	@ 0x57
20021d4c:	2b00      	cmp	r3, #0
20021d4e:	da08      	bge.n	20021d62 <DMA_Init+0x70>
20021d50:	6d63      	ldr	r3, [r4, #84]	@ 0x54
20021d52:	f3c3 031e 	ubfx	r3, r3, #0, #31
20021d56:	2b01      	cmp	r3, #1
20021d58:	d803      	bhi.n	20021d62 <DMA_Init+0x70>
20021d5a:	a901      	add	r1, sp, #4
20021d5c:	1d20      	adds	r0, r4, #4
20021d5e:	f7ff ffad 	bl	20021cbc <DMA_SetBurstSizeAndFix.part.0>
20021d62:	9b01      	ldr	r3, [sp, #4]
20021d64:	602b      	str	r3, [r5, #0]
20021d66:	68a3      	ldr	r3, [r4, #8]
20021d68:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021d6c:	d01f      	beq.n	20021dae <DMA_Init+0xbc>
20021d6e:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021d70:	f3c3 0387 	ubfx	r3, r3, #2, #8
20021d74:	f3ef 8110 	mrs	r1, PRIMASK
20021d78:	2201      	movs	r2, #1
20021d7a:	f382 8810 	msr	PRIMASK, r2
20021d7e:	0758      	lsls	r0, r3, #29
20021d80:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
20021d82:	d422      	bmi.n	20021dca <DMA_Init+0xd8>
20021d84:	253f      	movs	r5, #63	@ 0x3f
20021d86:	f003 0307 	and.w	r3, r3, #7
20021d8a:	f8d2 00a8 	ldr.w	r0, [r2, #168]	@ 0xa8
20021d8e:	00db      	lsls	r3, r3, #3
20021d90:	409d      	lsls	r5, r3
20021d92:	ea20 0005 	bic.w	r0, r0, r5
20021d96:	f8c2 00a8 	str.w	r0, [r2, #168]	@ 0xa8
20021d9a:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021d9c:	6862      	ldr	r2, [r4, #4]
20021d9e:	f8d0 50a8 	ldr.w	r5, [r0, #168]	@ 0xa8
20021da2:	409a      	lsls	r2, r3
20021da4:	432a      	orrs	r2, r5
20021da6:	f8c0 20a8 	str.w	r2, [r0, #168]	@ 0xa8
20021daa:	f381 8810 	msr	PRIMASK, r1
20021dae:	69a2      	ldr	r2, [r4, #24]
20021db0:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
20021db4:	d01d      	beq.n	20021df2 <DMA_Init+0x100>
20021db6:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
20021dba:	d024      	beq.n	20021e06 <DMA_Init+0x114>
20021dbc:	b1d2      	cbz	r2, 20021df4 <DMA_Init+0x102>
20021dbe:	e7fe      	b.n	20021dbe <DMA_Init+0xcc>
20021dc0:	2200      	movs	r2, #0
20021dc2:	e7b4      	b.n	20021d2e <DMA_Init+0x3c>
20021dc4:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20021dc8:	e7b1      	b.n	20021d2e <DMA_Init+0x3c>
20021dca:	253f      	movs	r5, #63	@ 0x3f
20021dcc:	f003 0303 	and.w	r3, r3, #3
20021dd0:	f8d2 00ac 	ldr.w	r0, [r2, #172]	@ 0xac
20021dd4:	00db      	lsls	r3, r3, #3
20021dd6:	409d      	lsls	r5, r3
20021dd8:	ea20 0005 	bic.w	r0, r0, r5
20021ddc:	f8c2 00ac 	str.w	r0, [r2, #172]	@ 0xac
20021de0:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021de2:	6862      	ldr	r2, [r4, #4]
20021de4:	f8d0 50ac 	ldr.w	r5, [r0, #172]	@ 0xac
20021de8:	409a      	lsls	r2, r3
20021dea:	432a      	orrs	r2, r5
20021dec:	f8c0 20ac 	str.w	r2, [r0, #172]	@ 0xac
20021df0:	e7db      	b.n	20021daa <DMA_Init+0xb8>
20021df2:	2201      	movs	r2, #1
20021df4:	6963      	ldr	r3, [r4, #20]
20021df6:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20021dfa:	d006      	beq.n	20021e0a <DMA_Init+0x118>
20021dfc:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021e00:	d02c      	beq.n	20021e5c <DMA_Init+0x16a>
20021e02:	b11b      	cbz	r3, 20021e0c <DMA_Init+0x11a>
20021e04:	e7fe      	b.n	20021e04 <DMA_Init+0x112>
20021e06:	2202      	movs	r2, #2
20021e08:	e7f4      	b.n	20021df4 <DMA_Init+0x102>
20021e0a:	2301      	movs	r3, #1
20021e0c:	6921      	ldr	r1, [r4, #16]
20021e0e:	f1a1 0080 	sub.w	r0, r1, #128	@ 0x80
20021e12:	4241      	negs	r1, r0
20021e14:	4141      	adcs	r1, r0
20021e16:	68e0      	ldr	r0, [r4, #12]
20021e18:	f1a0 0540 	sub.w	r5, r0, #64	@ 0x40
20021e1c:	4268      	negs	r0, r5
20021e1e:	4168      	adcs	r0, r5
20021e20:	68a5      	ldr	r5, [r4, #8]
20021e22:	2d10      	cmp	r5, #16
20021e24:	bf1f      	itttt	ne
20021e26:	f884 106d 	strbne.w	r1, [r4, #109]	@ 0x6d
20021e2a:	4619      	movne	r1, r3
20021e2c:	4613      	movne	r3, r2
20021e2e:	460a      	movne	r2, r1
20021e30:	f884 306f 	strb.w	r3, [r4, #111]	@ 0x6f
20021e34:	f884 206e 	strb.w	r2, [r4, #110]	@ 0x6e
20021e38:	f04f 0300 	mov.w	r3, #0
20021e3c:	f04f 0201 	mov.w	r2, #1
20021e40:	64a3      	str	r3, [r4, #72]	@ 0x48
20021e42:	bf06      	itte	eq
20021e44:	f884 006d 	strbeq.w	r0, [r4, #109]	@ 0x6d
20021e48:	f884 106c 	strbeq.w	r1, [r4, #108]	@ 0x6c
20021e4c:	f884 006c 	strbne.w	r0, [r4, #108]	@ 0x6c
20021e50:	f884 2031 	strb.w	r2, [r4, #49]	@ 0x31
20021e54:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021e58:	b003      	add	sp, #12
20021e5a:	bd30      	pop	{r4, r5, pc}
20021e5c:	2302      	movs	r3, #2
20021e5e:	e7d5      	b.n	20021e0c <DMA_Init+0x11a>

20021e60 <DMA_AllocChannel>:
20021e60:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021e62:	4b34      	ldr	r3, [pc, #208]	@ (20021f34 <DMA_AllocChannel+0xd4>)
20021e64:	6802      	ldr	r2, [r0, #0]
20021e66:	4604      	mov	r4, r0
20021e68:	4413      	add	r3, r2
20021e6a:	2ba0      	cmp	r3, #160	@ 0xa0
20021e6c:	d904      	bls.n	20021e78 <DMA_AllocChannel+0x18>
20021e6e:	4b32      	ldr	r3, [pc, #200]	@ (20021f38 <DMA_AllocChannel+0xd8>)
20021e70:	4413      	add	r3, r2
20021e72:	2ba0      	cmp	r3, #160	@ 0xa0
20021e74:	d90f      	bls.n	20021e96 <DMA_AllocChannel+0x36>
20021e76:	e7fe      	b.n	20021e76 <DMA_AllocChannel+0x16>
20021e78:	2032      	movs	r0, #50	@ 0x32
20021e7a:	f8df c0c8 	ldr.w	ip, [pc, #200]	@ 20021f44 <DMA_AllocChannel+0xe4>
20021e7e:	4b2f      	ldr	r3, [pc, #188]	@ (20021f3c <DMA_AllocChannel+0xdc>)
20021e80:	f3ef 8610 	mrs	r6, PRIMASK
20021e84:	2701      	movs	r7, #1
20021e86:	f387 8810 	msr	PRIMASK, r7
20021e8a:	6d22      	ldr	r2, [r4, #80]	@ 0x50
20021e8c:	2a1f      	cmp	r2, #31
20021e8e:	ea4f 0592 	mov.w	r5, r2, lsr #2
20021e92:	d905      	bls.n	20021ea0 <DMA_AllocChannel+0x40>
20021e94:	e7fe      	b.n	20021e94 <DMA_AllocChannel+0x34>
20021e96:	2002      	movs	r0, #2
20021e98:	f8df c0ac 	ldr.w	ip, [pc, #172]	@ 20021f48 <DMA_AllocChannel+0xe8>
20021e9c:	4b28      	ldr	r3, [pc, #160]	@ (20021f40 <DMA_AllocChannel+0xe0>)
20021e9e:	e7ef      	b.n	20021e80 <DMA_AllocChannel+0x20>
20021ea0:	eb03 02c5 	add.w	r2, r3, r5, lsl #3
20021ea4:	f892 e004 	ldrb.w	lr, [r2, #4]
20021ea8:	f1be 0f00 	cmp.w	lr, #0
20021eac:	d038      	beq.n	20021f20 <DMA_AllocChannel+0xc0>
20021eae:	f853 2035 	ldr.w	r2, [r3, r5, lsl #3]
20021eb2:	42a2      	cmp	r2, r4
20021eb4:	d103      	bne.n	20021ebe <DMA_AllocChannel+0x5e>
20021eb6:	f386 8810 	msr	PRIMASK, r6
20021eba:	2002      	movs	r0, #2
20021ebc:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021ebe:	2200      	movs	r2, #0
20021ec0:	791d      	ldrb	r5, [r3, #4]
20021ec2:	bb3d      	cbnz	r5, 20021f14 <DMA_AllocChannel+0xb4>
20021ec4:	2501      	movs	r5, #1
20021ec6:	711d      	strb	r5, [r3, #4]
20021ec8:	b119      	cbz	r1, 20021ed2 <DMA_AllocChannel+0x72>
20021eca:	6819      	ldr	r1, [r3, #0]
20021ecc:	1b09      	subs	r1, r1, r4
20021ece:	bf18      	it	ne
20021ed0:	2101      	movne	r1, #1
20021ed2:	601c      	str	r4, [r3, #0]
20021ed4:	2314      	movs	r3, #20
20021ed6:	fb03 c302 	mla	r3, r3, r2, ip
20021eda:	6023      	str	r3, [r4, #0]
20021edc:	0093      	lsls	r3, r2, #2
20021ede:	6523      	str	r3, [r4, #80]	@ 0x50
20021ee0:	6d63      	ldr	r3, [r4, #84]	@ 0x54
20021ee2:	4410      	add	r0, r2
20021ee4:	f362 031e 	bfi	r3, r2, #0, #31
20021ee8:	b245      	sxtb	r5, r0
20021eea:	6563      	str	r3, [r4, #84]	@ 0x54
20021eec:	f386 8810 	msr	PRIMASK, r6
20021ef0:	b111      	cbz	r1, 20021ef8 <DMA_AllocChannel+0x98>
20021ef2:	4620      	mov	r0, r4
20021ef4:	f7ff fefd 	bl	20021cf2 <DMA_Init>
20021ef8:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
20021efa:	f105 4260 	add.w	r2, r5, #3758096384	@ 0xe0000000
20021efe:	015b      	lsls	r3, r3, #5
20021f00:	b2db      	uxtb	r3, r3
20021f02:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20021f06:	4628      	mov	r0, r5
20021f08:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
20021f0c:	f7ff fe58 	bl	20021bc0 <HAL_NVIC_EnableIRQ>
20021f10:	2000      	movs	r0, #0
20021f12:	e7d3      	b.n	20021ebc <DMA_AllocChannel+0x5c>
20021f14:	3201      	adds	r2, #1
20021f16:	2a08      	cmp	r2, #8
20021f18:	f103 0308 	add.w	r3, r3, #8
20021f1c:	d1d0      	bne.n	20021ec0 <DMA_AllocChannel+0x60>
20021f1e:	e7ca      	b.n	20021eb6 <DMA_AllocChannel+0x56>
20021f20:	7117      	strb	r7, [r2, #4]
20021f22:	b119      	cbz	r1, 20021f2c <DMA_AllocChannel+0xcc>
20021f24:	6811      	ldr	r1, [r2, #0]
20021f26:	1b09      	subs	r1, r1, r4
20021f28:	bf18      	it	ne
20021f2a:	2101      	movne	r1, #1
20021f2c:	4405      	add	r5, r0
20021f2e:	6014      	str	r4, [r2, #0]
20021f30:	b26d      	sxtb	r5, r5
20021f32:	e7db      	b.n	20021eec <DMA_AllocChannel+0x8c>
20021f34:	aff7eff8 	.word	0xaff7eff8
20021f38:	bfffeff8 	.word	0xbfffeff8
20021f3c:	2004ca24 	.word	0x2004ca24
20021f40:	2004c9e4 	.word	0x2004c9e4
20021f44:	50081008 	.word	0x50081008
20021f48:	40001008 	.word	0x40001008

20021f4c <HAL_DMA_Init>:
20021f4c:	b538      	push	{r3, r4, r5, lr}
20021f4e:	4604      	mov	r4, r0
20021f50:	2800      	cmp	r0, #0
20021f52:	d05b      	beq.n	2002200c <HAL_DMA_Init+0xc0>
20021f54:	6883      	ldr	r3, [r0, #8]
20021f56:	f033 0210 	bics.w	r2, r3, #16
20021f5a:	d003      	beq.n	20021f64 <HAL_DMA_Init+0x18>
20021f5c:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021f60:	d000      	beq.n	20021f64 <HAL_DMA_Init+0x18>
20021f62:	e7fe      	b.n	20021f62 <HAL_DMA_Init+0x16>
20021f64:	68e3      	ldr	r3, [r4, #12]
20021f66:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20021f6a:	d000      	beq.n	20021f6e <HAL_DMA_Init+0x22>
20021f6c:	e7fe      	b.n	20021f6c <HAL_DMA_Init+0x20>
20021f6e:	6923      	ldr	r3, [r4, #16]
20021f70:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
20021f74:	d000      	beq.n	20021f78 <HAL_DMA_Init+0x2c>
20021f76:	e7fe      	b.n	20021f76 <HAL_DMA_Init+0x2a>
20021f78:	6963      	ldr	r3, [r4, #20]
20021f7a:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20021f7e:	d003      	beq.n	20021f88 <HAL_DMA_Init+0x3c>
20021f80:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021f84:	d000      	beq.n	20021f88 <HAL_DMA_Init+0x3c>
20021f86:	e7fe      	b.n	20021f86 <HAL_DMA_Init+0x3a>
20021f88:	69a3      	ldr	r3, [r4, #24]
20021f8a:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20021f8e:	d003      	beq.n	20021f98 <HAL_DMA_Init+0x4c>
20021f90:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
20021f94:	d000      	beq.n	20021f98 <HAL_DMA_Init+0x4c>
20021f96:	e7fe      	b.n	20021f96 <HAL_DMA_Init+0x4a>
20021f98:	69e3      	ldr	r3, [r4, #28]
20021f9a:	f033 0320 	bics.w	r3, r3, #32
20021f9e:	d000      	beq.n	20021fa2 <HAL_DMA_Init+0x56>
20021fa0:	e7fe      	b.n	20021fa0 <HAL_DMA_Init+0x54>
20021fa2:	6a23      	ldr	r3, [r4, #32]
20021fa4:	f433 5240 	bics.w	r2, r3, #12288	@ 0x3000
20021fa8:	d000      	beq.n	20021fac <HAL_DMA_Init+0x60>
20021faa:	e7fe      	b.n	20021faa <HAL_DMA_Init+0x5e>
20021fac:	6863      	ldr	r3, [r4, #4]
20021fae:	2b58      	cmp	r3, #88	@ 0x58
20021fb0:	d900      	bls.n	20021fb4 <HAL_DMA_Init+0x68>
20021fb2:	e7fe      	b.n	20021fb2 <HAL_DMA_Init+0x66>
20021fb4:	6821      	ldr	r1, [r4, #0]
20021fb6:	4b17      	ldr	r3, [pc, #92]	@ (20022014 <HAL_DMA_Init+0xc8>)
20021fb8:	440b      	add	r3, r1
20021fba:	2b8c      	cmp	r3, #140	@ 0x8c
20021fbc:	d81a      	bhi.n	20021ff4 <HAL_DMA_Init+0xa8>
20021fbe:	2214      	movs	r2, #20
20021fc0:	fbb3 f3f2 	udiv	r3, r3, r2
20021fc4:	2201      	movs	r2, #1
20021fc6:	4914      	ldr	r1, [pc, #80]	@ (20022018 <HAL_DMA_Init+0xcc>)
20021fc8:	0098      	lsls	r0, r3, #2
20021fca:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021fce:	ea43 73c2 	orr.w	r3, r3, r2, lsl #31
20021fd2:	e9c4 1013 	strd	r1, r0, [r4, #76]	@ 0x4c
20021fd6:	6563      	str	r3, [r4, #84]	@ 0x54
20021fd8:	2100      	movs	r1, #0
20021fda:	4620      	mov	r0, r4
20021fdc:	f7ff ff40 	bl	20021e60 <DMA_AllocChannel>
20021fe0:	4605      	mov	r5, r0
20021fe2:	b9a8      	cbnz	r0, 20022010 <HAL_DMA_Init+0xc4>
20021fe4:	4620      	mov	r0, r4
20021fe6:	f7ff fe84 	bl	20021cf2 <DMA_Init>
20021fea:	4620      	mov	r0, r4
20021fec:	f7ff fe36 	bl	20021c5c <DMA_FreeChannel.isra.0>
20021ff0:	4628      	mov	r0, r5
20021ff2:	bd38      	pop	{r3, r4, r5, pc}
20021ff4:	4b09      	ldr	r3, [pc, #36]	@ (2002201c <HAL_DMA_Init+0xd0>)
20021ff6:	440b      	add	r3, r1
20021ff8:	2b8c      	cmp	r3, #140	@ 0x8c
20021ffa:	d807      	bhi.n	2002200c <HAL_DMA_Init+0xc0>
20021ffc:	2114      	movs	r1, #20
20021ffe:	fbb3 f3f1 	udiv	r3, r3, r1
20022002:	4907      	ldr	r1, [pc, #28]	@ (20022020 <HAL_DMA_Init+0xd4>)
20022004:	0098      	lsls	r0, r3, #2
20022006:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
2002200a:	e7e0      	b.n	20021fce <HAL_DMA_Init+0x82>
2002200c:	2501      	movs	r5, #1
2002200e:	e7ef      	b.n	20021ff0 <HAL_DMA_Init+0xa4>
20022010:	2502      	movs	r5, #2
20022012:	e7ed      	b.n	20021ff0 <HAL_DMA_Init+0xa4>
20022014:	aff7eff8 	.word	0xaff7eff8
20022018:	50081000 	.word	0x50081000
2002201c:	bfffeff8 	.word	0xbfffeff8
20022020:	40001000 	.word	0x40001000

20022024 <HAL_DMA_DeInit>:
20022024:	b570      	push	{r4, r5, r6, lr}
20022026:	4604      	mov	r4, r0
20022028:	2800      	cmp	r0, #0
2002202a:	d060      	beq.n	200220ee <HAL_DMA_DeInit+0xca>
2002202c:	6802      	ldr	r2, [r0, #0]
2002202e:	4b31      	ldr	r3, [pc, #196]	@ (200220f4 <HAL_DMA_DeInit+0xd0>)
20022030:	4413      	add	r3, r2
20022032:	2b8c      	cmp	r3, #140	@ 0x8c
20022034:	d813      	bhi.n	2002205e <HAL_DMA_DeInit+0x3a>
20022036:	2214      	movs	r2, #20
20022038:	fbb3 f3f2 	udiv	r3, r3, r2
2002203c:	009b      	lsls	r3, r3, #2
2002203e:	6503      	str	r3, [r0, #80]	@ 0x50
20022040:	4b2d      	ldr	r3, [pc, #180]	@ (200220f8 <HAL_DMA_DeInit+0xd4>)
20022042:	64e3      	str	r3, [r4, #76]	@ 0x4c
20022044:	f3ef 8510 	mrs	r5, PRIMASK
20022048:	2601      	movs	r6, #1
2002204a:	f386 8810 	msr	PRIMASK, r6
2002204e:	4620      	mov	r0, r4
20022050:	f7ff fdd8 	bl	20021c04 <DMA_IsChannelOwner>
20022054:	b970      	cbnz	r0, 20022074 <HAL_DMA_DeInit+0x50>
20022056:	f385 8810 	msr	PRIMASK, r5
2002205a:	2000      	movs	r0, #0
2002205c:	bd70      	pop	{r4, r5, r6, pc}
2002205e:	4b27      	ldr	r3, [pc, #156]	@ (200220fc <HAL_DMA_DeInit+0xd8>)
20022060:	4413      	add	r3, r2
20022062:	2b8c      	cmp	r3, #140	@ 0x8c
20022064:	d8ee      	bhi.n	20022044 <HAL_DMA_DeInit+0x20>
20022066:	2214      	movs	r2, #20
20022068:	fbb3 f3f2 	udiv	r3, r3, r2
2002206c:	009b      	lsls	r3, r3, #2
2002206e:	6503      	str	r3, [r0, #80]	@ 0x50
20022070:	4b23      	ldr	r3, [pc, #140]	@ (20022100 <HAL_DMA_DeInit+0xdc>)
20022072:	e7e6      	b.n	20022042 <HAL_DMA_DeInit+0x1e>
20022074:	6822      	ldr	r2, [r4, #0]
20022076:	6813      	ldr	r3, [r2, #0]
20022078:	f023 0301 	bic.w	r3, r3, #1
2002207c:	6013      	str	r3, [r2, #0]
2002207e:	2200      	movs	r2, #0
20022080:	6823      	ldr	r3, [r4, #0]
20022082:	601a      	str	r2, [r3, #0]
20022084:	e9d4 2313 	ldrd	r2, r3, [r4, #76]	@ 0x4c
20022088:	f003 031c 	and.w	r3, r3, #28
2002208c:	409e      	lsls	r6, r3
2002208e:	6056      	str	r6, [r2, #4]
20022090:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20022092:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
20022094:	2b0f      	cmp	r3, #15
20022096:	ea4f 0293 	mov.w	r2, r3, lsr #2
2002209a:	d81b      	bhi.n	200220d4 <HAL_DMA_DeInit+0xb0>
2002209c:	203f      	movs	r0, #63	@ 0x3f
2002209e:	005b      	lsls	r3, r3, #1
200220a0:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
200220a4:	f003 0338 	and.w	r3, r3, #56	@ 0x38
200220a8:	fa00 f303 	lsl.w	r3, r0, r3
200220ac:	ea22 0303 	bic.w	r3, r2, r3
200220b0:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
200220b4:	4620      	mov	r0, r4
200220b6:	f7ff fdd1 	bl	20021c5c <DMA_FreeChannel.isra.0>
200220ba:	f385 8810 	msr	PRIMASK, r5
200220be:	2300      	movs	r3, #0
200220c0:	64a3      	str	r3, [r4, #72]	@ 0x48
200220c2:	e9c4 330e 	strd	r3, r3, [r4, #56]	@ 0x38
200220c6:	e9c4 3310 	strd	r3, r3, [r4, #64]	@ 0x40
200220ca:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200220ce:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200220d2:	e7c2      	b.n	2002205a <HAL_DMA_DeInit+0x36>
200220d4:	f002 0303 	and.w	r3, r2, #3
200220d8:	223f      	movs	r2, #63	@ 0x3f
200220da:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
200220de:	00db      	lsls	r3, r3, #3
200220e0:	fa02 f303 	lsl.w	r3, r2, r3
200220e4:	ea20 0303 	bic.w	r3, r0, r3
200220e8:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
200220ec:	e7e2      	b.n	200220b4 <HAL_DMA_DeInit+0x90>
200220ee:	2001      	movs	r0, #1
200220f0:	e7b4      	b.n	2002205c <HAL_DMA_DeInit+0x38>
200220f2:	bf00      	nop
200220f4:	aff7eff8 	.word	0xaff7eff8
200220f8:	50081000 	.word	0x50081000
200220fc:	bfffeff8 	.word	0xbfffeff8
20022100:	40001000 	.word	0x40001000

20022104 <HAL_DMA_PollForTransfer>:
20022104:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
20022108:	f890 3031 	ldrb.w	r3, [r0, #49]	@ 0x31
2002210c:	4617      	mov	r7, r2
2002210e:	2b02      	cmp	r3, #2
20022110:	4604      	mov	r4, r0
20022112:	4688      	mov	r8, r1
20022114:	b2da      	uxtb	r2, r3
20022116:	d005      	beq.n	20022124 <HAL_DMA_PollForTransfer+0x20>
20022118:	2304      	movs	r3, #4
2002211a:	6483      	str	r3, [r0, #72]	@ 0x48
2002211c:	2300      	movs	r3, #0
2002211e:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022122:	e006      	b.n	20022132 <HAL_DMA_PollForTransfer+0x2e>
20022124:	6803      	ldr	r3, [r0, #0]
20022126:	681b      	ldr	r3, [r3, #0]
20022128:	0699      	lsls	r1, r3, #26
2002212a:	d505      	bpl.n	20022138 <HAL_DMA_PollForTransfer+0x34>
2002212c:	f44f 7380 	mov.w	r3, #256	@ 0x100
20022130:	6483      	str	r3, [r0, #72]	@ 0x48
20022132:	2001      	movs	r0, #1
20022134:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
20022138:	6d05      	ldr	r5, [r0, #80]	@ 0x50
2002213a:	f005 051c 	and.w	r5, r5, #28
2002213e:	f1b8 0f00 	cmp.w	r8, #0
20022142:	d12f      	bne.n	200221a4 <HAL_DMA_PollForTransfer+0xa0>
20022144:	fa02 f505 	lsl.w	r5, r2, r5
20022148:	f7ff fbf6 	bl	20021938 <HAL_GetTick>
2002214c:	f04f 0a08 	mov.w	sl, #8
20022150:	4681      	mov	r9, r0
20022152:	e9d4 6313 	ldrd	r6, r3, [r4, #76]	@ 0x4c
20022156:	f003 031c 	and.w	r3, r3, #28
2002215a:	fa0a f103 	lsl.w	r1, sl, r3
2002215e:	6832      	ldr	r2, [r6, #0]
20022160:	ea12 0b05 	ands.w	fp, r2, r5
20022164:	d022      	beq.n	200221ac <HAL_DMA_PollForTransfer+0xa8>
20022166:	f1b8 0f00 	cmp.w	r8, #0
2002216a:	d142      	bne.n	200221f2 <HAL_DMA_PollForTransfer+0xee>
2002216c:	2202      	movs	r2, #2
2002216e:	fa02 f303 	lsl.w	r3, r2, r3
20022172:	6073      	str	r3, [r6, #4]
20022174:	f994 3057 	ldrsb.w	r3, [r4, #87]	@ 0x57
20022178:	2b00      	cmp	r3, #0
2002217a:	da07      	bge.n	2002218c <HAL_DMA_PollForTransfer+0x88>
2002217c:	6d63      	ldr	r3, [r4, #84]	@ 0x54
2002217e:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
20022180:	f3c3 021e 	ubfx	r2, r3, #0, #31
20022184:	2301      	movs	r3, #1
20022186:	4093      	lsls	r3, r2
20022188:	f8c1 30d8 	str.w	r3, [r1, #216]	@ 0xd8
2002218c:	6da3      	ldr	r3, [r4, #88]	@ 0x58
2002218e:	b92b      	cbnz	r3, 2002219c <HAL_DMA_PollForTransfer+0x98>
20022190:	4620      	mov	r0, r4
20022192:	f7ff fd63 	bl	20021c5c <DMA_FreeChannel.isra.0>
20022196:	2301      	movs	r3, #1
20022198:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
2002219c:	2000      	movs	r0, #0
2002219e:	f884 0030 	strb.w	r0, [r4, #48]	@ 0x30
200221a2:	e7c7      	b.n	20022134 <HAL_DMA_PollForTransfer+0x30>
200221a4:	2304      	movs	r3, #4
200221a6:	fa03 f505 	lsl.w	r5, r3, r5
200221aa:	e7cd      	b.n	20022148 <HAL_DMA_PollForTransfer+0x44>
200221ac:	6832      	ldr	r2, [r6, #0]
200221ae:	4211      	tst	r1, r2
200221b0:	d00c      	beq.n	200221cc <HAL_DMA_PollForTransfer+0xc8>
200221b2:	2501      	movs	r5, #1
200221b4:	fa05 f303 	lsl.w	r3, r5, r3
200221b8:	6073      	str	r3, [r6, #4]
200221ba:	4620      	mov	r0, r4
200221bc:	64a5      	str	r5, [r4, #72]	@ 0x48
200221be:	f7ff fd4d 	bl	20021c5c <DMA_FreeChannel.isra.0>
200221c2:	f884 5031 	strb.w	r5, [r4, #49]	@ 0x31
200221c6:	f884 b030 	strb.w	fp, [r4, #48]	@ 0x30
200221ca:	e7b2      	b.n	20022132 <HAL_DMA_PollForTransfer+0x2e>
200221cc:	1c7a      	adds	r2, r7, #1
200221ce:	d0c6      	beq.n	2002215e <HAL_DMA_PollForTransfer+0x5a>
200221d0:	f7ff fbb2 	bl	20021938 <HAL_GetTick>
200221d4:	eba0 0009 	sub.w	r0, r0, r9
200221d8:	42b8      	cmp	r0, r7
200221da:	d801      	bhi.n	200221e0 <HAL_DMA_PollForTransfer+0xdc>
200221dc:	2f00      	cmp	r7, #0
200221de:	d1b8      	bne.n	20022152 <HAL_DMA_PollForTransfer+0x4e>
200221e0:	2320      	movs	r3, #32
200221e2:	4620      	mov	r0, r4
200221e4:	64a3      	str	r3, [r4, #72]	@ 0x48
200221e6:	f7ff fd39 	bl	20021c5c <DMA_FreeChannel.isra.0>
200221ea:	2301      	movs	r3, #1
200221ec:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200221f0:	e794      	b.n	2002211c <HAL_DMA_PollForTransfer+0x18>
200221f2:	2204      	movs	r2, #4
200221f4:	fa02 f303 	lsl.w	r3, r2, r3
200221f8:	6073      	str	r3, [r6, #4]
200221fa:	e7cf      	b.n	2002219c <HAL_DMA_PollForTransfer+0x98>

200221fc <DMA_Remap>:
200221fc:	b530      	push	{r4, r5, lr}
200221fe:	4b15      	ldr	r3, [pc, #84]	@ (20022254 <DMA_Remap+0x58>)
20022200:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
20022202:	429c      	cmp	r4, r3
20022204:	d11b      	bne.n	2002223e <DMA_Remap+0x42>
20022206:	6883      	ldr	r3, [r0, #8]
20022208:	2b10      	cmp	r3, #16
2002220a:	d002      	beq.n	20022212 <DMA_Remap+0x16>
2002220c:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20022210:	d108      	bne.n	20022224 <DMA_Remap+0x28>
20022212:	680b      	ldr	r3, [r1, #0]
20022214:	4c10      	ldr	r4, [pc, #64]	@ (20022258 <DMA_Remap+0x5c>)
20022216:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
2002221a:	42a5      	cmp	r5, r4
2002221c:	bf98      	it	ls
2002221e:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
20022222:	600b      	str	r3, [r1, #0]
20022224:	6883      	ldr	r3, [r0, #8]
20022226:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
2002222a:	d108      	bne.n	2002223e <DMA_Remap+0x42>
2002222c:	6813      	ldr	r3, [r2, #0]
2002222e:	480a      	ldr	r0, [pc, #40]	@ (20022258 <DMA_Remap+0x5c>)
20022230:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
20022234:	4284      	cmp	r4, r0
20022236:	bf98      	it	ls
20022238:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
2002223c:	6013      	str	r3, [r2, #0]
2002223e:	680b      	ldr	r3, [r1, #0]
20022240:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
20022244:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20022248:	bf3c      	itt	cc
2002224a:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
2002224e:	600b      	strcc	r3, [r1, #0]
20022250:	bd30      	pop	{r4, r5, pc}
20022252:	bf00      	nop
20022254:	40001000 	.word	0x40001000
20022258:	0007fffe 	.word	0x0007fffe

2002225c <DMA_Start>:
2002225c:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20022260:	f64f 75ff 	movw	r5, #65535	@ 0xffff
20022264:	4a31      	ldr	r2, [pc, #196]	@ (2002232c <DMA_Start+0xd0>)
20022266:	4e32      	ldr	r6, [pc, #200]	@ (20022330 <DMA_Start+0xd4>)
20022268:	460f      	mov	r7, r1
2002226a:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
2002226c:	6d83      	ldr	r3, [r0, #88]	@ 0x58
2002226e:	4291      	cmp	r1, r2
20022270:	bf18      	it	ne
20022272:	4635      	movne	r5, r6
20022274:	429d      	cmp	r5, r3
20022276:	bf28      	it	cs
20022278:	461d      	movcs	r5, r3
2002227a:	6802      	ldr	r2, [r0, #0]
2002227c:	1b5b      	subs	r3, r3, r5
2002227e:	6583      	str	r3, [r0, #88]	@ 0x58
20022280:	6605      	str	r5, [r0, #96]	@ 0x60
20022282:	6813      	ldr	r3, [r2, #0]
20022284:	f890 606e 	ldrb.w	r6, [r0, #110]	@ 0x6e
20022288:	f023 0301 	bic.w	r3, r3, #1
2002228c:	f890 806f 	ldrb.w	r8, [r0, #111]	@ 0x6f
20022290:	6013      	str	r3, [r2, #0]
20022292:	e9d0 2319 	ldrd	r2, r3, [r0, #100]	@ 0x64
20022296:	e9cd 2300 	strd	r2, r3, [sp]
2002229a:	e9d0 2313 	ldrd	r2, r3, [r0, #76]	@ 0x4c
2002229e:	f003 011c 	and.w	r1, r3, #28
200222a2:	2301      	movs	r3, #1
200222a4:	4604      	mov	r4, r0
200222a6:	408b      	lsls	r3, r1
200222a8:	6053      	str	r3, [r2, #4]
200222aa:	6803      	ldr	r3, [r0, #0]
200222ac:	4669      	mov	r1, sp
200222ae:	605d      	str	r5, [r3, #4]
200222b0:	aa01      	add	r2, sp, #4
200222b2:	f7ff ffa3 	bl	200221fc <DMA_Remap>
200222b6:	e9dd 0300 	ldrd	r0, r3, [sp]
200222ba:	68a1      	ldr	r1, [r4, #8]
200222bc:	6822      	ldr	r2, [r4, #0]
200222be:	2910      	cmp	r1, #16
200222c0:	bf0b      	itete	eq
200222c2:	6093      	streq	r3, [r2, #8]
200222c4:	6090      	strne	r0, [r2, #8]
200222c6:	6823      	ldreq	r3, [r4, #0]
200222c8:	6822      	ldrne	r2, [r4, #0]
200222ca:	bf0c      	ite	eq
200222cc:	60d8      	streq	r0, [r3, #12]
200222ce:	60d3      	strne	r3, [r2, #12]
200222d0:	fa05 f606 	lsl.w	r6, r5, r6
200222d4:	4631      	mov	r1, r6
200222d6:	6e60      	ldr	r0, [r4, #100]	@ 0x64
200222d8:	f7ff fa58 	bl	2002178c <mpu_dcache_clean>
200222dc:	f894 306c 	ldrb.w	r3, [r4, #108]	@ 0x6c
200222e0:	b113      	cbz	r3, 200222e8 <DMA_Start+0x8c>
200222e2:	6e63      	ldr	r3, [r4, #100]	@ 0x64
200222e4:	4433      	add	r3, r6
200222e6:	6663      	str	r3, [r4, #100]	@ 0x64
200222e8:	f894 306d 	ldrb.w	r3, [r4, #109]	@ 0x6d
200222ec:	b123      	cbz	r3, 200222f8 <DMA_Start+0x9c>
200222ee:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
200222f0:	fa05 f508 	lsl.w	r5, r5, r8
200222f4:	442b      	add	r3, r5
200222f6:	66a3      	str	r3, [r4, #104]	@ 0x68
200222f8:	b137      	cbz	r7, 20022308 <DMA_Start+0xac>
200222fa:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
200222fc:	6823      	ldr	r3, [r4, #0]
200222fe:	b15a      	cbz	r2, 20022318 <DMA_Start+0xbc>
20022300:	681a      	ldr	r2, [r3, #0]
20022302:	f042 020e 	orr.w	r2, r2, #14
20022306:	601a      	str	r2, [r3, #0]
20022308:	6822      	ldr	r2, [r4, #0]
2002230a:	6813      	ldr	r3, [r2, #0]
2002230c:	f043 0301 	orr.w	r3, r3, #1
20022310:	6013      	str	r3, [r2, #0]
20022312:	b002      	add	sp, #8
20022314:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022318:	681a      	ldr	r2, [r3, #0]
2002231a:	f022 0204 	bic.w	r2, r2, #4
2002231e:	601a      	str	r2, [r3, #0]
20022320:	6822      	ldr	r2, [r4, #0]
20022322:	6813      	ldr	r3, [r2, #0]
20022324:	f043 030a 	orr.w	r3, r3, #10
20022328:	6013      	str	r3, [r2, #0]
2002232a:	e7ed      	b.n	20022308 <DMA_Start+0xac>
2002232c:	40001000 	.word	0x40001000
20022330:	000fffff 	.word	0x000fffff

20022334 <HAL_DMA_Start>:
20022334:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022336:	461d      	mov	r5, r3
20022338:	69c3      	ldr	r3, [r0, #28]
2002233a:	4604      	mov	r4, r0
2002233c:	2b20      	cmp	r3, #32
2002233e:	460f      	mov	r7, r1
20022340:	4616      	mov	r6, r2
20022342:	d10b      	bne.n	2002235c <HAL_DMA_Start+0x28>
20022344:	b14d      	cbz	r5, 2002235a <HAL_DMA_Start+0x26>
20022346:	f64f 73ff 	movw	r3, #65535	@ 0xffff
2002234a:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
2002234c:	4a1b      	ldr	r2, [pc, #108]	@ (200223bc <HAL_DMA_Start+0x88>)
2002234e:	481c      	ldr	r0, [pc, #112]	@ (200223c0 <HAL_DMA_Start+0x8c>)
20022350:	4291      	cmp	r1, r2
20022352:	bf18      	it	ne
20022354:	4603      	movne	r3, r0
20022356:	42ab      	cmp	r3, r5
20022358:	d800      	bhi.n	2002235c <HAL_DMA_Start+0x28>
2002235a:	e7fe      	b.n	2002235a <HAL_DMA_Start+0x26>
2002235c:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
20022360:	2b01      	cmp	r3, #1
20022362:	d00e      	beq.n	20022382 <HAL_DMA_Start+0x4e>
20022364:	2301      	movs	r3, #1
20022366:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
2002236a:	f894 3031 	ldrb.w	r3, [r4, #49]	@ 0x31
2002236e:	2b01      	cmp	r3, #1
20022370:	b2d9      	uxtb	r1, r3
20022372:	d103      	bne.n	2002237c <HAL_DMA_Start+0x48>
20022374:	4620      	mov	r0, r4
20022376:	f7ff fd73 	bl	20021e60 <DMA_AllocChannel>
2002237a:	b120      	cbz	r0, 20022386 <HAL_DMA_Start+0x52>
2002237c:	2300      	movs	r3, #0
2002237e:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022382:	2002      	movs	r0, #2
20022384:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20022386:	2302      	movs	r3, #2
20022388:	e9c4 5516 	strd	r5, r5, [r4, #88]	@ 0x58
2002238c:	e9c4 7619 	strd	r7, r6, [r4, #100]	@ 0x64
20022390:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022394:	64a0      	str	r0, [r4, #72]	@ 0x48
20022396:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20022398:	2800      	cmp	r0, #0
2002239a:	d0f3      	beq.n	20022384 <HAL_DMA_Start+0x50>
2002239c:	2100      	movs	r1, #0
2002239e:	4620      	mov	r0, r4
200223a0:	f7ff ff5c 	bl	2002225c <DMA_Start>
200223a4:	6da3      	ldr	r3, [r4, #88]	@ 0x58
200223a6:	2b00      	cmp	r3, #0
200223a8:	d0f5      	beq.n	20022396 <HAL_DMA_Start+0x62>
200223aa:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
200223ae:	2100      	movs	r1, #0
200223b0:	4620      	mov	r0, r4
200223b2:	f7ff fea7 	bl	20022104 <HAL_DMA_PollForTransfer>
200223b6:	2800      	cmp	r0, #0
200223b8:	d0ed      	beq.n	20022396 <HAL_DMA_Start+0x62>
200223ba:	e7e3      	b.n	20022384 <HAL_DMA_Start+0x50>
200223bc:	40001000 	.word	0x40001000
200223c0:	000fffff 	.word	0x000fffff

200223c4 <HAL_EFUSE_Init>:
200223c4:	2000      	movs	r0, #0
200223c6:	4770      	bx	lr

200223c8 <HAL_EFUSE_Read>:
200223c8:	2a20      	cmp	r2, #32
200223ca:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200223ce:	4607      	mov	r7, r0
200223d0:	460c      	mov	r4, r1
200223d2:	4690      	mov	r8, r2
200223d4:	dc25      	bgt.n	20022422 <HAL_EFUSE_Read+0x5a>
200223d6:	f3c0 09c4 	ubfx	r9, r0, #3, #5
200223da:	eb09 0302 	add.w	r3, r9, r2
200223de:	2b20      	cmp	r3, #32
200223e0:	dc1f      	bgt.n	20022422 <HAL_EFUSE_Read+0x5a>
200223e2:	f012 0f03 	tst.w	r2, #3
200223e6:	d11c      	bne.n	20022422 <HAL_EFUSE_Read+0x5a>
200223e8:	f010 051f 	ands.w	r5, r0, #31
200223ec:	d119      	bne.n	20022422 <HAL_EFUSE_Read+0x5a>
200223ee:	2003      	movs	r0, #3
200223f0:	f7ff f9c6 	bl	20021780 <pmu_ldo_inc>
200223f4:	4629      	mov	r1, r5
200223f6:	4e1d      	ldr	r6, [pc, #116]	@ (2002246c <HAL_EFUSE_Read+0xa4>)
200223f8:	0a3f      	lsrs	r7, r7, #8
200223fa:	00bb      	lsls	r3, r7, #2
200223fc:	6033      	str	r3, [r6, #0]
200223fe:	6833      	ldr	r3, [r6, #0]
20022400:	4a1b      	ldr	r2, [pc, #108]	@ (20022470 <HAL_EFUSE_Read+0xa8>)
20022402:	f043 0301 	orr.w	r3, r3, #1
20022406:	6033      	str	r3, [r6, #0]
20022408:	68b3      	ldr	r3, [r6, #8]
2002240a:	07db      	lsls	r3, r3, #31
2002240c:	d401      	bmi.n	20022412 <HAL_EFUSE_Read+0x4a>
2002240e:	4291      	cmp	r1, r2
20022410:	d10c      	bne.n	2002242c <HAL_EFUSE_Read+0x64>
20022412:	68b3      	ldr	r3, [r6, #8]
20022414:	4291      	cmp	r1, r2
20022416:	f043 0301 	orr.w	r3, r3, #1
2002241a:	60b3      	str	r3, [r6, #8]
2002241c:	d108      	bne.n	20022430 <HAL_EFUSE_Read+0x68>
2002241e:	f7ff f9b1 	bl	20021784 <pmu_ldo_recover>
20022422:	f04f 0800 	mov.w	r8, #0
20022426:	4640      	mov	r0, r8
20022428:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002242c:	3101      	adds	r1, #1
2002242e:	e7eb      	b.n	20022408 <HAL_EFUSE_Read+0x40>
20022430:	4a10      	ldr	r2, [pc, #64]	@ (20022474 <HAL_EFUSE_Read+0xac>)
20022432:	f009 031c 	and.w	r3, r9, #28
20022436:	eb03 1347 	add.w	r3, r3, r7, lsl #5
2002243a:	f028 0103 	bic.w	r1, r8, #3
2002243e:	441a      	add	r2, r3
20022440:	4421      	add	r1, r4
20022442:	428c      	cmp	r4, r1
20022444:	d102      	bne.n	2002244c <HAL_EFUSE_Read+0x84>
20022446:	f7ff f99d 	bl	20021784 <pmu_ldo_recover>
2002244a:	e7ec      	b.n	20022426 <HAL_EFUSE_Read+0x5e>
2002244c:	f852 3b04 	ldr.w	r3, [r2], #4
20022450:	3404      	adds	r4, #4
20022452:	0a1d      	lsrs	r5, r3, #8
20022454:	f804 3c04 	strb.w	r3, [r4, #-4]
20022458:	f804 5c03 	strb.w	r5, [r4, #-3]
2002245c:	0c1d      	lsrs	r5, r3, #16
2002245e:	0e1b      	lsrs	r3, r3, #24
20022460:	f804 5c02 	strb.w	r5, [r4, #-2]
20022464:	f804 3c01 	strb.w	r3, [r4, #-1]
20022468:	e7eb      	b.n	20022442 <HAL_EFUSE_Read+0x7a>
2002246a:	bf00      	nop
2002246c:	5000c000 	.word	0x5000c000
20022470:	00bb8000 	.word	0x00bb8000
20022474:	5000c030 	.word	0x5000c030

20022478 <HAL_HPAON_EnableXT48>:
20022478:	4b04      	ldr	r3, [pc, #16]	@ (2002248c <HAL_HPAON_EnableXT48+0x14>)
2002247a:	689a      	ldr	r2, [r3, #8]
2002247c:	f042 0202 	orr.w	r2, r2, #2
20022480:	609a      	str	r2, [r3, #8]
20022482:	689a      	ldr	r2, [r3, #8]
20022484:	2a00      	cmp	r2, #0
20022486:	dafc      	bge.n	20022482 <HAL_HPAON_EnableXT48+0xa>
20022488:	4770      	bx	lr
2002248a:	bf00      	nop
2002248c:	500c0000 	.word	0x500c0000

20022490 <HAL_HPAON_DisableXT48>:
20022490:	4a02      	ldr	r2, [pc, #8]	@ (2002249c <HAL_HPAON_DisableXT48+0xc>)
20022492:	6893      	ldr	r3, [r2, #8]
20022494:	f023 0302 	bic.w	r3, r3, #2
20022498:	6093      	str	r3, [r2, #8]
2002249a:	4770      	bx	lr
2002249c:	500c0000 	.word	0x500c0000

200224a0 <HAL_QSPI_Init>:
200224a0:	b510      	push	{r4, lr}
200224a2:	b1e8      	cbz	r0, 200224e0 <HAL_QSPI_Init+0x40>
200224a4:	b1e1      	cbz	r1, 200224e0 <HAL_QSPI_Init+0x40>
200224a6:	2300      	movs	r3, #0
200224a8:	2201      	movs	r2, #1
200224aa:	6043      	str	r3, [r0, #4]
200224ac:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
200224b0:	680c      	ldr	r4, [r1, #0]
200224b2:	6004      	str	r4, [r0, #0]
200224b4:	684a      	ldr	r2, [r1, #4]
200224b6:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
200224ba:	688a      	ldr	r2, [r1, #8]
200224bc:	6102      	str	r2, [r0, #16]
200224be:	68ca      	ldr	r2, [r1, #12]
200224c0:	0512      	lsls	r2, r2, #20
200224c2:	6142      	str	r2, [r0, #20]
200224c4:	22ff      	movs	r2, #255	@ 0xff
200224c6:	f8c4 208c 	str.w	r2, [r4, #140]	@ 0x8c
200224ca:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
200224ce:	6801      	ldr	r1, [r0, #0]
200224d0:	f8c1 4080 	str.w	r4, [r1, #128]	@ 0x80
200224d4:	6801      	ldr	r1, [r0, #0]
200224d6:	620a      	str	r2, [r1, #32]
200224d8:	6801      	ldr	r1, [r0, #0]
200224da:	4618      	mov	r0, r3
200224dc:	644a      	str	r2, [r1, #68]	@ 0x44
200224de:	bd10      	pop	{r4, pc}
200224e0:	2001      	movs	r0, #1
200224e2:	e7fc      	b.n	200224de <HAL_QSPI_Init+0x3e>

200224e4 <HAL_FLASH_SET_AHB_RCMD>:
200224e4:	b138      	cbz	r0, 200224f6 <HAL_FLASH_SET_AHB_RCMD+0x12>
200224e6:	6802      	ldr	r2, [r0, #0]
200224e8:	2000      	movs	r0, #0
200224ea:	6c13      	ldr	r3, [r2, #64]	@ 0x40
200224ec:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
200224f0:	4319      	orrs	r1, r3
200224f2:	6411      	str	r1, [r2, #64]	@ 0x40
200224f4:	4770      	bx	lr
200224f6:	2001      	movs	r0, #1
200224f8:	4770      	bx	lr

200224fa <HAL_FLASH_CFG_AHB_RCMD>:
200224fa:	b570      	push	{r4, r5, r6, lr}
200224fc:	b1c8      	cbz	r0, 20022532 <HAL_FLASH_CFG_AHB_RCMD+0x38>
200224fe:	6805      	ldr	r5, [r0, #0]
20022500:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022504:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022508:	6cac      	ldr	r4, [r5, #72]	@ 0x48
2002250a:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002250e:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022512:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022516:	f36f 0414 	bfc	r4, #0, #21
2002251a:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
2002251e:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022522:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022526:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
2002252a:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
2002252e:	4321      	orrs	r1, r4
20022530:	64a9      	str	r1, [r5, #72]	@ 0x48
20022532:	bd70      	pop	{r4, r5, r6, pc}

20022534 <HAL_FLASH_SET_AHB_WCMD>:
20022534:	b140      	cbz	r0, 20022548 <HAL_FLASH_SET_AHB_WCMD+0x14>
20022536:	6802      	ldr	r2, [r0, #0]
20022538:	2000      	movs	r0, #0
2002253a:	6c13      	ldr	r3, [r2, #64]	@ 0x40
2002253c:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
20022540:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
20022544:	6411      	str	r1, [r2, #64]	@ 0x40
20022546:	4770      	bx	lr
20022548:	2001      	movs	r0, #1
2002254a:	4770      	bx	lr

2002254c <HAL_FLASH_CFG_AHB_WCMD>:
2002254c:	b570      	push	{r4, r5, r6, lr}
2002254e:	b1c8      	cbz	r0, 20022584 <HAL_FLASH_CFG_AHB_WCMD+0x38>
20022550:	6805      	ldr	r5, [r0, #0]
20022552:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022556:	f99d 001c 	ldrsb.w	r0, [sp, #28]
2002255a:	6d2c      	ldr	r4, [r5, #80]	@ 0x50
2002255c:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022560:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022564:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022568:	f36f 0414 	bfc	r4, #0, #21
2002256c:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022570:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022574:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022578:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
2002257c:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
20022580:	4321      	orrs	r1, r4
20022582:	6529      	str	r1, [r5, #80]	@ 0x50
20022584:	bd70      	pop	{r4, r5, r6, pc}

20022586 <HAL_FLASH_WRITE_WORD>:
20022586:	b118      	cbz	r0, 20022590 <HAL_FLASH_WRITE_WORD+0xa>
20022588:	6803      	ldr	r3, [r0, #0]
2002258a:	2000      	movs	r0, #0
2002258c:	6059      	str	r1, [r3, #4]
2002258e:	4770      	bx	lr
20022590:	2001      	movs	r0, #1
20022592:	4770      	bx	lr

20022594 <HAL_FLASH_WRITE_DLEN>:
20022594:	b130      	cbz	r0, 200225a4 <HAL_FLASH_WRITE_DLEN+0x10>
20022596:	6803      	ldr	r3, [r0, #0]
20022598:	3901      	subs	r1, #1
2002259a:	f3c1 0113 	ubfx	r1, r1, #0, #20
2002259e:	2000      	movs	r0, #0
200225a0:	6259      	str	r1, [r3, #36]	@ 0x24
200225a2:	4770      	bx	lr
200225a4:	2001      	movs	r0, #1
200225a6:	4770      	bx	lr

200225a8 <HAL_FLASH_WRITE_DLEN2>:
200225a8:	b130      	cbz	r0, 200225b8 <HAL_FLASH_WRITE_DLEN2+0x10>
200225aa:	6803      	ldr	r3, [r0, #0]
200225ac:	3901      	subs	r1, #1
200225ae:	f3c1 0113 	ubfx	r1, r1, #0, #20
200225b2:	2000      	movs	r0, #0
200225b4:	6399      	str	r1, [r3, #56]	@ 0x38
200225b6:	4770      	bx	lr
200225b8:	2001      	movs	r0, #1
200225ba:	4770      	bx	lr

200225bc <HAL_FLASH_WRITE_ABYTE>:
200225bc:	b108      	cbz	r0, 200225c2 <HAL_FLASH_WRITE_ABYTE+0x6>
200225be:	6803      	ldr	r3, [r0, #0]
200225c0:	6219      	str	r1, [r3, #32]
200225c2:	4770      	bx	lr

200225c4 <HAL_FLASH_IS_CMD_DONE>:
200225c4:	b118      	cbz	r0, 200225ce <HAL_FLASH_IS_CMD_DONE+0xa>
200225c6:	6803      	ldr	r3, [r0, #0]
200225c8:	6918      	ldr	r0, [r3, #16]
200225ca:	f000 0001 	and.w	r0, r0, #1
200225ce:	4770      	bx	lr

200225d0 <HAL_FLASH_CLR_CMD_DONE>:
200225d0:	b120      	cbz	r0, 200225dc <HAL_FLASH_CLR_CMD_DONE+0xc>
200225d2:	6802      	ldr	r2, [r0, #0]
200225d4:	6953      	ldr	r3, [r2, #20]
200225d6:	f043 0301 	orr.w	r3, r3, #1
200225da:	6153      	str	r3, [r2, #20]
200225dc:	4770      	bx	lr

200225de <HAL_FLASH_SET_CMD>:
200225de:	b538      	push	{r3, r4, r5, lr}
200225e0:	460d      	mov	r5, r1
200225e2:	4604      	mov	r4, r0
200225e4:	b1a8      	cbz	r0, 20022612 <HAL_FLASH_SET_CMD+0x34>
200225e6:	6803      	ldr	r3, [r0, #0]
200225e8:	61da      	str	r2, [r3, #28]
200225ea:	6b43      	ldr	r3, [r0, #52]	@ 0x34
200225ec:	b10b      	cbz	r3, 200225f2 <HAL_FLASH_SET_CMD+0x14>
200225ee:	2001      	movs	r0, #1
200225f0:	4798      	blx	r3
200225f2:	6823      	ldr	r3, [r4, #0]
200225f4:	619d      	str	r5, [r3, #24]
200225f6:	4620      	mov	r0, r4
200225f8:	f7ff ffe4 	bl	200225c4 <HAL_FLASH_IS_CMD_DONE>
200225fc:	2800      	cmp	r0, #0
200225fe:	d0fa      	beq.n	200225f6 <HAL_FLASH_SET_CMD+0x18>
20022600:	4620      	mov	r0, r4
20022602:	f7ff ffe5 	bl	200225d0 <HAL_FLASH_CLR_CMD_DONE>
20022606:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20022608:	b10b      	cbz	r3, 2002260e <HAL_FLASH_SET_CMD+0x30>
2002260a:	2000      	movs	r0, #0
2002260c:	4798      	blx	r3
2002260e:	2000      	movs	r0, #0
20022610:	bd38      	pop	{r3, r4, r5, pc}
20022612:	2001      	movs	r0, #1
20022614:	e7fc      	b.n	20022610 <HAL_FLASH_SET_CMD+0x32>

20022616 <HAL_FLASH_CLR_STATUS>:
20022616:	b118      	cbz	r0, 20022620 <HAL_FLASH_CLR_STATUS+0xa>
20022618:	6802      	ldr	r2, [r0, #0]
2002261a:	6953      	ldr	r3, [r2, #20]
2002261c:	4319      	orrs	r1, r3
2002261e:	6151      	str	r1, [r2, #20]
20022620:	4770      	bx	lr

20022622 <HAL_FLASH_STATUS_MATCH>:
20022622:	b118      	cbz	r0, 2002262c <HAL_FLASH_STATUS_MATCH+0xa>
20022624:	6803      	ldr	r3, [r0, #0]
20022626:	6918      	ldr	r0, [r3, #16]
20022628:	f3c0 00c0 	ubfx	r0, r0, #3, #1
2002262c:	4770      	bx	lr

2002262e <HAL_FLASH_IS_PROG_DONE>:
2002262e:	b128      	cbz	r0, 2002263c <HAL_FLASH_IS_PROG_DONE+0xe>
20022630:	6803      	ldr	r3, [r0, #0]
20022632:	6858      	ldr	r0, [r3, #4]
20022634:	43c0      	mvns	r0, r0
20022636:	f000 0001 	and.w	r0, r0, #1
2002263a:	4770      	bx	lr
2002263c:	2001      	movs	r0, #1
2002263e:	4770      	bx	lr

20022640 <HAL_FLASH_READ32>:
20022640:	b108      	cbz	r0, 20022646 <HAL_FLASH_READ32+0x6>
20022642:	6803      	ldr	r3, [r0, #0]
20022644:	6858      	ldr	r0, [r3, #4]
20022646:	4770      	bx	lr

20022648 <HAL_FLASH_SET_TXSLOT>:
20022648:	b120      	cbz	r0, 20022654 <HAL_FLASH_SET_TXSLOT+0xc>
2002264a:	6802      	ldr	r2, [r0, #0]
2002264c:	6d53      	ldr	r3, [r2, #84]	@ 0x54
2002264e:	f361 238e 	bfi	r3, r1, #10, #5
20022652:	6553      	str	r3, [r2, #84]	@ 0x54
20022654:	4770      	bx	lr

20022656 <HAL_FLASH_SET_CLK_rom>:
20022656:	b108      	cbz	r0, 2002265c <HAL_FLASH_SET_CLK_rom+0x6>
20022658:	6803      	ldr	r3, [r0, #0]
2002265a:	60d9      	str	r1, [r3, #12]
2002265c:	4770      	bx	lr

2002265e <HAL_FLASH_GET_DIV>:
2002265e:	b110      	cbz	r0, 20022666 <HAL_FLASH_GET_DIV+0x8>
20022660:	6803      	ldr	r3, [r0, #0]
20022662:	68d8      	ldr	r0, [r3, #12]
20022664:	b2c0      	uxtb	r0, r0
20022666:	4770      	bx	lr

20022668 <HAL_FLASH_MANUAL_CMD>:
20022668:	b570      	push	{r4, r5, r6, lr}
2002266a:	b1e8      	cbz	r0, 200226a8 <HAL_FLASH_MANUAL_CMD+0x40>
2002266c:	6805      	ldr	r5, [r0, #0]
2002266e:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022672:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022676:	6aac      	ldr	r4, [r5, #40]	@ 0x28
20022678:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002267c:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022680:	f36f 0415 	bfc	r4, #0, #22
20022684:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022688:	f99d 6014 	ldrsb.w	r6, [sp, #20]
2002268c:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
20022690:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022694:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022698:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
2002269c:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200226a0:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200226a4:	4321      	orrs	r1, r4
200226a6:	62a9      	str	r1, [r5, #40]	@ 0x28
200226a8:	bd70      	pop	{r4, r5, r6, pc}

200226aa <HAL_FLASH_MANUAL_CMD2>:
200226aa:	b570      	push	{r4, r5, r6, lr}
200226ac:	b1e8      	cbz	r0, 200226ea <HAL_FLASH_MANUAL_CMD2+0x40>
200226ae:	6805      	ldr	r5, [r0, #0]
200226b0:	f99d 601c 	ldrsb.w	r6, [sp, #28]
200226b4:	f99d 0020 	ldrsb.w	r0, [sp, #32]
200226b8:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
200226ba:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200226be:	f99d 6010 	ldrsb.w	r6, [sp, #16]
200226c2:	f36f 0415 	bfc	r4, #0, #22
200226c6:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
200226ca:	f99d 6014 	ldrsb.w	r6, [sp, #20]
200226ce:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
200226d2:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200226d6:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
200226da:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
200226de:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200226e2:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200226e6:	4321      	orrs	r1, r4
200226e8:	63e9      	str	r1, [r5, #60]	@ 0x3c
200226ea:	bd70      	pop	{r4, r5, r6, pc}

200226ec <HAL_FLASH_SET_ALIAS_RANGE>:
200226ec:	b510      	push	{r4, lr}
200226ee:	b158      	cbz	r0, 20022708 <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
200226f0:	4b06      	ldr	r3, [pc, #24]	@ (2002270c <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
200226f2:	6804      	ldr	r4, [r0, #0]
200226f4:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
200226f8:	440a      	add	r2, r1
200226fa:	4019      	ands	r1, r3
200226fc:	6761      	str	r1, [r4, #116]	@ 0x74
200226fe:	401a      	ands	r2, r3
20022700:	6803      	ldr	r3, [r0, #0]
20022702:	2000      	movs	r0, #0
20022704:	679a      	str	r2, [r3, #120]	@ 0x78
20022706:	bd10      	pop	{r4, pc}
20022708:	2001      	movs	r0, #1
2002270a:	e7fc      	b.n	20022706 <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
2002270c:	fffffc00 	.word	0xfffffc00

20022710 <HAL_FLASH_SET_ALIAS_OFFSET>:
20022710:	b128      	cbz	r0, 2002271e <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
20022712:	6803      	ldr	r3, [r0, #0]
20022714:	f36f 0109 	bfc	r1, #0, #10
20022718:	2000      	movs	r0, #0
2002271a:	67d9      	str	r1, [r3, #124]	@ 0x7c
2002271c:	4770      	bx	lr
2002271e:	2001      	movs	r0, #1
20022720:	4770      	bx	lr

20022722 <HAL_FLASH_ENABLE_QSPI>:
20022722:	b150      	cbz	r0, 2002273a <HAL_FLASH_ENABLE_QSPI+0x18>
20022724:	6803      	ldr	r3, [r0, #0]
20022726:	681a      	ldr	r2, [r3, #0]
20022728:	b121      	cbz	r1, 20022734 <HAL_FLASH_ENABLE_QSPI+0x12>
2002272a:	f042 0201 	orr.w	r2, r2, #1
2002272e:	2000      	movs	r0, #0
20022730:	601a      	str	r2, [r3, #0]
20022732:	4770      	bx	lr
20022734:	f022 0201 	bic.w	r2, r2, #1
20022738:	e7f9      	b.n	2002272e <HAL_FLASH_ENABLE_QSPI+0xc>
2002273a:	2001      	movs	r0, #1
2002273c:	4770      	bx	lr

2002273e <HAL_FLASH_ENABLE_OPI>:
2002273e:	b150      	cbz	r0, 20022756 <HAL_FLASH_ENABLE_OPI+0x18>
20022740:	6803      	ldr	r3, [r0, #0]
20022742:	681a      	ldr	r2, [r3, #0]
20022744:	b121      	cbz	r1, 20022750 <HAL_FLASH_ENABLE_OPI+0x12>
20022746:	f442 1200 	orr.w	r2, r2, #2097152	@ 0x200000
2002274a:	2000      	movs	r0, #0
2002274c:	601a      	str	r2, [r3, #0]
2002274e:	4770      	bx	lr
20022750:	f422 1200 	bic.w	r2, r2, #2097152	@ 0x200000
20022754:	e7f9      	b.n	2002274a <HAL_FLASH_ENABLE_OPI+0xc>
20022756:	2001      	movs	r0, #1
20022758:	4770      	bx	lr

2002275a <HAL_FLASH_ENABLE_HYPER>:
2002275a:	b148      	cbz	r0, 20022770 <HAL_FLASH_ENABLE_HYPER+0x16>
2002275c:	6802      	ldr	r2, [r0, #0]
2002275e:	6893      	ldr	r3, [r2, #8]
20022760:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
20022764:	b109      	cbz	r1, 2002276a <HAL_FLASH_ENABLE_HYPER+0x10>
20022766:	f043 0320 	orr.w	r3, r3, #32
2002276a:	2000      	movs	r0, #0
2002276c:	6093      	str	r3, [r2, #8]
2002276e:	4770      	bx	lr
20022770:	2001      	movs	r0, #1
20022772:	4770      	bx	lr

20022774 <HAL_FLASH_ENABLE_CMD2>:
20022774:	b150      	cbz	r0, 2002278c <HAL_FLASH_ENABLE_CMD2+0x18>
20022776:	6803      	ldr	r3, [r0, #0]
20022778:	681a      	ldr	r2, [r3, #0]
2002277a:	b121      	cbz	r1, 20022786 <HAL_FLASH_ENABLE_CMD2+0x12>
2002277c:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
20022780:	2000      	movs	r0, #0
20022782:	601a      	str	r2, [r3, #0]
20022784:	4770      	bx	lr
20022786:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
2002278a:	e7f9      	b.n	20022780 <HAL_FLASH_ENABLE_CMD2+0xc>
2002278c:	2001      	movs	r0, #1
2002278e:	4770      	bx	lr

20022790 <HAL_FLASH_STAUS_MATCH_CMD2>:
20022790:	b150      	cbz	r0, 200227a8 <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
20022792:	6803      	ldr	r3, [r0, #0]
20022794:	681a      	ldr	r2, [r3, #0]
20022796:	b121      	cbz	r1, 200227a2 <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
20022798:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
2002279c:	2000      	movs	r0, #0
2002279e:	601a      	str	r2, [r3, #0]
200227a0:	4770      	bx	lr
200227a2:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
200227a6:	e7f9      	b.n	2002279c <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
200227a8:	2001      	movs	r0, #1
200227aa:	4770      	bx	lr

200227ac <HAL_FLASH_SET_CS_TIME>:
200227ac:	b530      	push	{r4, r5, lr}
200227ae:	b180      	cbz	r0, 200227d2 <HAL_FLASH_SET_CS_TIME+0x26>
200227b0:	6805      	ldr	r5, [r0, #0]
200227b2:	f8bd 000c 	ldrh.w	r0, [sp, #12]
200227b6:	68ac      	ldr	r4, [r5, #8]
200227b8:	0680      	lsls	r0, r0, #26
200227ba:	ea40 5383 	orr.w	r3, r0, r3, lsl #22
200227be:	2000      	movs	r0, #0
200227c0:	ea43 4181 	orr.w	r1, r3, r1, lsl #18
200227c4:	f36f 149e 	bfc	r4, #6, #25
200227c8:	ea41 1282 	orr.w	r2, r1, r2, lsl #6
200227cc:	4322      	orrs	r2, r4
200227ce:	60aa      	str	r2, [r5, #8]
200227d0:	bd30      	pop	{r4, r5, pc}
200227d2:	2001      	movs	r0, #1
200227d4:	e7fc      	b.n	200227d0 <HAL_FLASH_SET_CS_TIME+0x24>

200227d6 <HAL_FLASH_SET_ROW_BOUNDARY>:
200227d6:	b130      	cbz	r0, 200227e6 <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
200227d8:	6802      	ldr	r2, [r0, #0]
200227da:	2000      	movs	r0, #0
200227dc:	6893      	ldr	r3, [r2, #8]
200227de:	f361 0302 	bfi	r3, r1, #0, #3
200227e2:	6093      	str	r3, [r2, #8]
200227e4:	4770      	bx	lr
200227e6:	2001      	movs	r0, #1
200227e8:	4770      	bx	lr

200227ea <HAL_FLASH_SET_LEGACY>:
200227ea:	b148      	cbz	r0, 20022800 <HAL_FLASH_SET_LEGACY+0x16>
200227ec:	6802      	ldr	r2, [r0, #0]
200227ee:	6893      	ldr	r3, [r2, #8]
200227f0:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
200227f4:	b109      	cbz	r1, 200227fa <HAL_FLASH_SET_LEGACY+0x10>
200227f6:	f043 0310 	orr.w	r3, r3, #16
200227fa:	2000      	movs	r0, #0
200227fc:	6093      	str	r3, [r2, #8]
200227fe:	4770      	bx	lr
20022800:	2001      	movs	r0, #1
20022802:	4770      	bx	lr

20022804 <HAL_FLASH_SET_DUAL_MODE>:
20022804:	b150      	cbz	r0, 2002281c <HAL_FLASH_SET_DUAL_MODE+0x18>
20022806:	6803      	ldr	r3, [r0, #0]
20022808:	681a      	ldr	r2, [r3, #0]
2002280a:	b121      	cbz	r1, 20022816 <HAL_FLASH_SET_DUAL_MODE+0x12>
2002280c:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
20022810:	2000      	movs	r0, #0
20022812:	601a      	str	r2, [r3, #0]
20022814:	4770      	bx	lr
20022816:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
2002281a:	e7f9      	b.n	20022810 <HAL_FLASH_SET_DUAL_MODE+0xc>
2002281c:	2001      	movs	r0, #1
2002281e:	4770      	bx	lr

20022820 <HAL_FLASH_SET_X16_MODE>:
20022820:	b150      	cbz	r0, 20022838 <HAL_FLASH_SET_X16_MODE+0x18>
20022822:	6803      	ldr	r3, [r0, #0]
20022824:	681a      	ldr	r2, [r3, #0]
20022826:	b121      	cbz	r1, 20022832 <HAL_FLASH_SET_X16_MODE+0x12>
20022828:	f442 0200 	orr.w	r2, r2, #8388608	@ 0x800000
2002282c:	2000      	movs	r0, #0
2002282e:	601a      	str	r2, [r3, #0]
20022830:	4770      	bx	lr
20022832:	f422 0200 	bic.w	r2, r2, #8388608	@ 0x800000
20022836:	e7f9      	b.n	2002282c <HAL_FLASH_SET_X16_MODE+0xc>
20022838:	2001      	movs	r0, #1
2002283a:	4770      	bx	lr

2002283c <HAL_MPI_EN_FIXLAT>:
2002283c:	2000      	movs	r0, #0
2002283e:	4770      	bx	lr

20022840 <HAL_MPI_ENABLE_DQS>:
20022840:	fab0 f080 	clz	r0, r0
20022844:	0940      	lsrs	r0, r0, #5
20022846:	4770      	bx	lr

20022848 <HAL_MPI_SET_DQS_DELAY>:
20022848:	b138      	cbz	r0, 2002285a <HAL_MPI_SET_DQS_DELAY+0x12>
2002284a:	6802      	ldr	r2, [r0, #0]
2002284c:	2000      	movs	r0, #0
2002284e:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022850:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
20022854:	4319      	orrs	r1, r3
20022856:	6591      	str	r1, [r2, #88]	@ 0x58
20022858:	4770      	bx	lr
2002285a:	2001      	movs	r0, #1
2002285c:	4770      	bx	lr

2002285e <HAL_MPI_SET_SCK>:
2002285e:	b150      	cbz	r0, 20022876 <HAL_MPI_SET_SCK+0x18>
20022860:	6800      	ldr	r0, [r0, #0]
20022862:	0412      	lsls	r2, r2, #16
20022864:	6d83      	ldr	r3, [r0, #88]	@ 0x58
20022866:	ea42 2101 	orr.w	r1, r2, r1, lsl #8
2002286a:	f36f 2310 	bfc	r3, #8, #9
2002286e:	4319      	orrs	r1, r3
20022870:	6581      	str	r1, [r0, #88]	@ 0x58
20022872:	2000      	movs	r0, #0
20022874:	4770      	bx	lr
20022876:	2001      	movs	r0, #1
20022878:	4770      	bx	lr

2002287a <HAL_MPI_CFG_DTR>:
2002287a:	6803      	ldr	r3, [r0, #0]
2002287c:	6d9a      	ldr	r2, [r3, #88]	@ 0x58
2002287e:	b121      	cbz	r1, 2002288a <HAL_MPI_CFG_DTR+0x10>
20022880:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
20022884:	2000      	movs	r0, #0
20022886:	659a      	str	r2, [r3, #88]	@ 0x58
20022888:	4770      	bx	lr
2002288a:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
2002288e:	e7f9      	b.n	20022884 <HAL_MPI_CFG_DTR+0xa>

20022890 <HAL_MPI_MODIFY_RCMD_DELAY>:
20022890:	b130      	cbz	r0, 200228a0 <HAL_MPI_MODIFY_RCMD_DELAY+0x10>
20022892:	6802      	ldr	r2, [r0, #0]
20022894:	6c93      	ldr	r3, [r2, #72]	@ 0x48
20022896:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
2002289a:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
2002289e:	6491      	str	r1, [r2, #72]	@ 0x48
200228a0:	4770      	bx	lr

200228a2 <HAL_MPI_MODIFY_WCMD_DELAY>:
200228a2:	b130      	cbz	r0, 200228b2 <HAL_MPI_MODIFY_WCMD_DELAY+0x10>
200228a4:	6802      	ldr	r2, [r0, #0]
200228a6:	6d13      	ldr	r3, [r2, #80]	@ 0x50
200228a8:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
200228ac:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
200228b0:	6511      	str	r1, [r2, #80]	@ 0x50
200228b2:	4770      	bx	lr

200228b4 <HAL_FLASH_SET_WDT>:
200228b4:	b148      	cbz	r0, 200228ca <HAL_FLASH_SET_WDT+0x16>
200228b6:	6803      	ldr	r3, [r0, #0]
200228b8:	f8d3 2090 	ldr.w	r2, [r3, #144]	@ 0x90
200228bc:	b109      	cbz	r1, 200228c2 <HAL_FLASH_SET_WDT+0xe>
200228be:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
200228c2:	2000      	movs	r0, #0
200228c4:	f8c3 1090 	str.w	r1, [r3, #144]	@ 0x90
200228c8:	4770      	bx	lr
200228ca:	2001      	movs	r0, #1
200228cc:	4770      	bx	lr

200228ce <HAL_FLASH_CONFIG_AHB_READ>:
200228ce:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200228d0:	4605      	mov	r5, r0
200228d2:	2800      	cmp	r0, #0
200228d4:	d03d      	beq.n	20022952 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200228d6:	68c4      	ldr	r4, [r0, #12]
200228d8:	b301      	cbz	r1, 2002291c <HAL_FLASH_CONFIG_AHB_READ+0x4e>
200228da:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
200228de:	2b00      	cmp	r3, #0
200228e0:	d037      	beq.n	20022952 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200228e2:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
200228e6:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
200228ea:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
200228ee:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
200228f2:	9603      	str	r6, [sp, #12]
200228f4:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
200228f8:	9602      	str	r6, [sp, #8]
200228fa:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
200228fe:	9601      	str	r6, [sp, #4]
20022900:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
20022904:	9400      	str	r4, [sp, #0]
20022906:	f7ff fdf8 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
2002290a:	68eb      	ldr	r3, [r5, #12]
2002290c:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
20022910:	4628      	mov	r0, r5
20022912:	f7ff fde7 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
20022916:	2000      	movs	r0, #0
20022918:	b004      	add	sp, #16
2002291a:	bd70      	pop	{r4, r5, r6, pc}
2002291c:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
20022920:	b1bb      	cbz	r3, 20022952 <HAL_FLASH_CONFIG_AHB_READ+0x84>
20022922:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
20022926:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
2002292a:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
2002292e:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
20022932:	9603      	str	r6, [sp, #12]
20022934:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
20022938:	9602      	str	r6, [sp, #8]
2002293a:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
2002293e:	9601      	str	r6, [sp, #4]
20022940:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
20022944:	9400      	str	r4, [sp, #0]
20022946:	f7ff fdd8 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
2002294a:	68eb      	ldr	r3, [r5, #12]
2002294c:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20022950:	e7de      	b.n	20022910 <HAL_FLASH_CONFIG_AHB_READ+0x42>
20022952:	2001      	movs	r0, #1
20022954:	e7e0      	b.n	20022918 <HAL_FLASH_CONFIG_AHB_READ+0x4a>

20022956 <HAL_FLASH_CONFIG_FULL_AHB_READ>:
20022956:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20022958:	4605      	mov	r5, r0
2002295a:	2800      	cmp	r0, #0
2002295c:	d036      	beq.n	200229cc <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
2002295e:	68c4      	ldr	r4, [r0, #12]
20022960:	b1e1      	cbz	r1, 2002299c <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
20022962:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
20022966:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
2002296a:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
2002296e:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
20022972:	9603      	str	r6, [sp, #12]
20022974:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
20022978:	9602      	str	r6, [sp, #8]
2002297a:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
2002297e:	9601      	str	r6, [sp, #4]
20022980:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
20022984:	9400      	str	r4, [sp, #0]
20022986:	f7ff fdb8 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
2002298a:	68eb      	ldr	r3, [r5, #12]
2002298c:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
20022990:	4628      	mov	r0, r5
20022992:	f7ff fda7 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
20022996:	2000      	movs	r0, #0
20022998:	b004      	add	sp, #16
2002299a:	bd70      	pop	{r4, r5, r6, pc}
2002299c:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
200229a0:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
200229a4:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
200229a8:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
200229ac:	9603      	str	r6, [sp, #12]
200229ae:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
200229b2:	9602      	str	r6, [sp, #8]
200229b4:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
200229b8:	9601      	str	r6, [sp, #4]
200229ba:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
200229be:	9400      	str	r4, [sp, #0]
200229c0:	f7ff fd9b 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
200229c4:	68eb      	ldr	r3, [r5, #12]
200229c6:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
200229ca:	e7e1      	b.n	20022990 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
200229cc:	2001      	movs	r0, #1
200229ce:	e7e3      	b.n	20022998 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

200229d0 <HAL_FLASH_PRE_CMD>:
200229d0:	b530      	push	{r4, r5, lr}
200229d2:	68c4      	ldr	r4, [r0, #12]
200229d4:	b087      	sub	sp, #28
200229d6:	b304      	cbz	r4, 20022a1a <HAL_FLASH_PRE_CMD+0x4a>
200229d8:	2938      	cmp	r1, #56	@ 0x38
200229da:	d81e      	bhi.n	20022a1a <HAL_FLASH_PRE_CMD+0x4a>
200229dc:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
200229e0:	440c      	add	r4, r1
200229e2:	7c23      	ldrb	r3, [r4, #16]
200229e4:	b1cb      	cbz	r3, 20022a1a <HAL_FLASH_PRE_CMD+0x4a>
200229e6:	f994 5018 	ldrsb.w	r5, [r4, #24]
200229ea:	f994 3013 	ldrsb.w	r3, [r4, #19]
200229ee:	f994 2012 	ldrsb.w	r2, [r4, #18]
200229f2:	f994 1011 	ldrsb.w	r1, [r4, #17]
200229f6:	9504      	str	r5, [sp, #16]
200229f8:	f994 5017 	ldrsb.w	r5, [r4, #23]
200229fc:	9503      	str	r5, [sp, #12]
200229fe:	f994 5016 	ldrsb.w	r5, [r4, #22]
20022a02:	9502      	str	r5, [sp, #8]
20022a04:	f994 5015 	ldrsb.w	r5, [r4, #21]
20022a08:	9501      	str	r5, [sp, #4]
20022a0a:	f994 4014 	ldrsb.w	r4, [r4, #20]
20022a0e:	9400      	str	r4, [sp, #0]
20022a10:	f7ff fe2a 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20022a14:	2000      	movs	r0, #0
20022a16:	b007      	add	sp, #28
20022a18:	bd30      	pop	{r4, r5, pc}
20022a1a:	2001      	movs	r0, #1
20022a1c:	e7fb      	b.n	20022a16 <HAL_FLASH_PRE_CMD+0x46>

20022a1e <HAL_FLASH_ISSUE_CMD>:
20022a1e:	b5f0      	push	{r4, r5, r6, r7, lr}
20022a20:	68c4      	ldr	r4, [r0, #12]
20022a22:	4606      	mov	r6, r0
20022a24:	4617      	mov	r7, r2
20022a26:	b087      	sub	sp, #28
20022a28:	b354      	cbz	r4, 20022a80 <HAL_FLASH_ISSUE_CMD+0x62>
20022a2a:	2938      	cmp	r1, #56	@ 0x38
20022a2c:	d828      	bhi.n	20022a80 <HAL_FLASH_ISSUE_CMD+0x62>
20022a2e:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
20022a32:	442c      	add	r4, r5
20022a34:	7c23      	ldrb	r3, [r4, #16]
20022a36:	b31b      	cbz	r3, 20022a80 <HAL_FLASH_ISSUE_CMD+0x62>
20022a38:	f994 c018 	ldrsb.w	ip, [r4, #24]
20022a3c:	f994 3013 	ldrsb.w	r3, [r4, #19]
20022a40:	f994 2012 	ldrsb.w	r2, [r4, #18]
20022a44:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022a48:	f8cd c010 	str.w	ip, [sp, #16]
20022a4c:	f994 c017 	ldrsb.w	ip, [r4, #23]
20022a50:	f8cd c00c 	str.w	ip, [sp, #12]
20022a54:	f994 c016 	ldrsb.w	ip, [r4, #22]
20022a58:	f8cd c008 	str.w	ip, [sp, #8]
20022a5c:	f994 c015 	ldrsb.w	ip, [r4, #21]
20022a60:	f8cd c004 	str.w	ip, [sp, #4]
20022a64:	f994 4014 	ldrsb.w	r4, [r4, #20]
20022a68:	9400      	str	r4, [sp, #0]
20022a6a:	f7ff fdfd 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20022a6e:	68f3      	ldr	r3, [r6, #12]
20022a70:	463a      	mov	r2, r7
20022a72:	442b      	add	r3, r5
20022a74:	4630      	mov	r0, r6
20022a76:	7c19      	ldrb	r1, [r3, #16]
20022a78:	f7ff fdb1 	bl	200225de <HAL_FLASH_SET_CMD>
20022a7c:	b007      	add	sp, #28
20022a7e:	bdf0      	pop	{r4, r5, r6, r7, pc}
20022a80:	2001      	movs	r0, #1
20022a82:	e7fb      	b.n	20022a7c <HAL_FLASH_ISSUE_CMD+0x5e>

20022a84 <HAL_FLASH_ISSUE_CMD_SEQ>:
20022a84:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20022a88:	4690      	mov	r8, r2
20022a8a:	68c2      	ldr	r2, [r0, #12]
20022a8c:	4604      	mov	r4, r0
20022a8e:	b086      	sub	sp, #24
20022a90:	2a00      	cmp	r2, #0
20022a92:	d073      	beq.n	20022b7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a94:	2938      	cmp	r1, #56	@ 0x38
20022a96:	d871      	bhi.n	20022b7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a98:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
20022a9c:	19d6      	adds	r6, r2, r7
20022a9e:	7c31      	ldrb	r1, [r6, #16]
20022aa0:	2900      	cmp	r1, #0
20022aa2:	d06b      	beq.n	20022b7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022aa4:	2b38      	cmp	r3, #56	@ 0x38
20022aa6:	d869      	bhi.n	20022b7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022aa8:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
20022aac:	442a      	add	r2, r5
20022aae:	7c13      	ldrb	r3, [r2, #16]
20022ab0:	2b00      	cmp	r3, #0
20022ab2:	d063      	beq.n	20022b7c <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022ab4:	f996 c018 	ldrsb.w	ip, [r6, #24]
20022ab8:	f996 3013 	ldrsb.w	r3, [r6, #19]
20022abc:	f996 2012 	ldrsb.w	r2, [r6, #18]
20022ac0:	f996 1011 	ldrsb.w	r1, [r6, #17]
20022ac4:	f8cd c010 	str.w	ip, [sp, #16]
20022ac8:	f996 c017 	ldrsb.w	ip, [r6, #23]
20022acc:	f8cd c00c 	str.w	ip, [sp, #12]
20022ad0:	f996 c016 	ldrsb.w	ip, [r6, #22]
20022ad4:	f8cd c008 	str.w	ip, [sp, #8]
20022ad8:	f996 c015 	ldrsb.w	ip, [r6, #21]
20022adc:	f8cd c004 	str.w	ip, [sp, #4]
20022ae0:	f996 6014 	ldrsb.w	r6, [r6, #20]
20022ae4:	9600      	str	r6, [sp, #0]
20022ae6:	f7ff fdbf 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20022aea:	68e0      	ldr	r0, [r4, #12]
20022aec:	4428      	add	r0, r5
20022aee:	f990 6018 	ldrsb.w	r6, [r0, #24]
20022af2:	f990 3013 	ldrsb.w	r3, [r0, #19]
20022af6:	f990 2012 	ldrsb.w	r2, [r0, #18]
20022afa:	f990 1011 	ldrsb.w	r1, [r0, #17]
20022afe:	9604      	str	r6, [sp, #16]
20022b00:	f990 6017 	ldrsb.w	r6, [r0, #23]
20022b04:	9603      	str	r6, [sp, #12]
20022b06:	f990 6016 	ldrsb.w	r6, [r0, #22]
20022b0a:	9602      	str	r6, [sp, #8]
20022b0c:	f990 6015 	ldrsb.w	r6, [r0, #21]
20022b10:	9601      	str	r6, [sp, #4]
20022b12:	f990 0014 	ldrsb.w	r0, [r0, #20]
20022b16:	9000      	str	r0, [sp, #0]
20022b18:	4620      	mov	r0, r4
20022b1a:	f7ff fdc6 	bl	200226aa <HAL_FLASH_MANUAL_CMD2>
20022b1e:	2200      	movs	r2, #0
20022b20:	6823      	ldr	r3, [r4, #0]
20022b22:	2101      	movs	r1, #1
20022b24:	f8c3 2084 	str.w	r2, [r3, #132]	@ 0x84
20022b28:	68e3      	ldr	r3, [r4, #12]
20022b2a:	6822      	ldr	r2, [r4, #0]
20022b2c:	442b      	add	r3, r5
20022b2e:	7c1b      	ldrb	r3, [r3, #16]
20022b30:	4620      	mov	r0, r4
20022b32:	62d3      	str	r3, [r2, #44]	@ 0x2c
20022b34:	6823      	ldr	r3, [r4, #0]
20022b36:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
20022b38:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20022b3c:	f7ff fe1a 	bl	20022774 <HAL_FLASH_ENABLE_CMD2>
20022b40:	4620      	mov	r0, r4
20022b42:	f7ff fe25 	bl	20022790 <HAL_FLASH_STAUS_MATCH_CMD2>
20022b46:	6823      	ldr	r3, [r4, #0]
20022b48:	f8c3 801c 	str.w	r8, [r3, #28]
20022b4c:	68e3      	ldr	r3, [r4, #12]
20022b4e:	6822      	ldr	r2, [r4, #0]
20022b50:	443b      	add	r3, r7
20022b52:	7c1b      	ldrb	r3, [r3, #16]
20022b54:	6193      	str	r3, [r2, #24]
20022b56:	4620      	mov	r0, r4
20022b58:	f7ff fd63 	bl	20022622 <HAL_FLASH_STATUS_MATCH>
20022b5c:	2800      	cmp	r0, #0
20022b5e:	d0fa      	beq.n	20022b56 <HAL_FLASH_ISSUE_CMD_SEQ+0xd2>
20022b60:	2109      	movs	r1, #9
20022b62:	4620      	mov	r0, r4
20022b64:	f7ff fd57 	bl	20022616 <HAL_FLASH_CLR_STATUS>
20022b68:	2100      	movs	r1, #0
20022b6a:	f7ff fe03 	bl	20022774 <HAL_FLASH_ENABLE_CMD2>
20022b6e:	4620      	mov	r0, r4
20022b70:	f7ff fe0e 	bl	20022790 <HAL_FLASH_STAUS_MATCH_CMD2>
20022b74:	4608      	mov	r0, r1
20022b76:	b006      	add	sp, #24
20022b78:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022b7c:	2001      	movs	r0, #1
20022b7e:	e7fa      	b.n	20022b76 <HAL_FLASH_ISSUE_CMD_SEQ+0xf2>

20022b80 <nor_qspi_switch>:
20022b80:	b570      	push	{r4, r5, r6, lr}
20022b82:	4604      	mov	r4, r0
20022b84:	b3e0      	cbz	r0, 20022c00 <nor_qspi_switch+0x80>
20022b86:	68c3      	ldr	r3, [r0, #12]
20022b88:	b3d3      	cbz	r3, 20022c00 <nor_qspi_switch+0x80>
20022b8a:	b3c9      	cbz	r1, 20022c00 <nor_qspi_switch+0x80>
20022b8c:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022b90:	2101      	movs	r1, #1
20022b92:	b3b5      	cbz	r5, 20022c02 <nor_qspi_switch+0x82>
20022b94:	f7ff fcfe 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022b98:	2200      	movs	r2, #0
20022b9a:	2114      	movs	r1, #20
20022b9c:	4620      	mov	r0, r4
20022b9e:	f7ff ff3e 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022ba2:	4620      	mov	r0, r4
20022ba4:	f7ff fd4c 	bl	20022640 <HAL_FLASH_READ32>
20022ba8:	f010 0501 	ands.w	r5, r0, #1
20022bac:	d000      	beq.n	20022bb0 <nor_qspi_switch+0x30>
20022bae:	e7fe      	b.n	20022bae <nor_qspi_switch+0x2e>
20022bb0:	462a      	mov	r2, r5
20022bb2:	2115      	movs	r1, #21
20022bb4:	4620      	mov	r0, r4
20022bb6:	f7ff ff32 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022bba:	4606      	mov	r6, r0
20022bbc:	b120      	cbz	r0, 20022bc8 <nor_qspi_switch+0x48>
20022bbe:	462a      	mov	r2, r5
20022bc0:	4629      	mov	r1, r5
20022bc2:	4620      	mov	r0, r4
20022bc4:	f7ff ff2b 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022bc8:	2102      	movs	r1, #2
20022bca:	4620      	mov	r0, r4
20022bcc:	f7ff fcdb 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20022bd0:	2101      	movs	r1, #1
20022bd2:	4620      	mov	r0, r4
20022bd4:	f7ff fcde 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022bd8:	2200      	movs	r2, #0
20022bda:	212b      	movs	r1, #43	@ 0x2b
20022bdc:	4620      	mov	r0, r4
20022bde:	f7ff ff1e 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022be2:	b16e      	cbz	r6, 20022c00 <nor_qspi_switch+0x80>
20022be4:	2101      	movs	r1, #1
20022be6:	4620      	mov	r0, r4
20022be8:	f7ff fcd4 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022bec:	2200      	movs	r2, #0
20022bee:	2102      	movs	r1, #2
20022bf0:	4620      	mov	r0, r4
20022bf2:	f7ff ff14 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022bf6:	4620      	mov	r0, r4
20022bf8:	f7ff fd19 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
20022bfc:	2800      	cmp	r0, #0
20022bfe:	d0f5      	beq.n	20022bec <nor_qspi_switch+0x6c>
20022c00:	bd70      	pop	{r4, r5, r6, pc}
20022c02:	f7ff fcc7 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022c06:	462a      	mov	r2, r5
20022c08:	2102      	movs	r1, #2
20022c0a:	4620      	mov	r0, r4
20022c0c:	f7ff ff07 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c10:	4620      	mov	r0, r4
20022c12:	f7ff fd15 	bl	20022640 <HAL_FLASH_READ32>
20022c16:	462a      	mov	r2, r5
20022c18:	2114      	movs	r1, #20
20022c1a:	4620      	mov	r0, r4
20022c1c:	f7ff feff 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c20:	b910      	cbnz	r0, 20022c28 <nor_qspi_switch+0xa8>
20022c22:	4620      	mov	r0, r4
20022c24:	f7ff fd0c 	bl	20022640 <HAL_FLASH_READ32>
20022c28:	68e3      	ldr	r3, [r4, #12]
20022c2a:	7a1b      	ldrb	r3, [r3, #8]
20022c2c:	b3ab      	cbz	r3, 20022c9a <nor_qspi_switch+0x11a>
20022c2e:	2101      	movs	r1, #1
20022c30:	f003 050f 	and.w	r5, r3, #15
20022c34:	091b      	lsrs	r3, r3, #4
20022c36:	fa01 f303 	lsl.w	r3, r1, r3
20022c3a:	b2db      	uxtb	r3, r3
20022c3c:	b10d      	cbz	r5, 20022c42 <nor_qspi_switch+0xc2>
20022c3e:	461d      	mov	r5, r3
20022c40:	2300      	movs	r3, #0
20022c42:	2200      	movs	r2, #0
20022c44:	2115      	movs	r1, #21
20022c46:	4620      	mov	r0, r4
20022c48:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
20022c4c:	f7ff fee7 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c50:	4606      	mov	r6, r0
20022c52:	b120      	cbz	r0, 20022c5e <nor_qspi_switch+0xde>
20022c54:	2200      	movs	r2, #0
20022c56:	4620      	mov	r0, r4
20022c58:	4611      	mov	r1, r2
20022c5a:	f7ff fee0 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c5e:	4629      	mov	r1, r5
20022c60:	4620      	mov	r0, r4
20022c62:	f7ff fc90 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20022c66:	2102      	movs	r1, #2
20022c68:	4620      	mov	r0, r4
20022c6a:	f7ff fc93 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022c6e:	2200      	movs	r2, #0
20022c70:	2103      	movs	r1, #3
20022c72:	4620      	mov	r0, r4
20022c74:	f7ff fed3 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c78:	2e00      	cmp	r6, #0
20022c7a:	d0c1      	beq.n	20022c00 <nor_qspi_switch+0x80>
20022c7c:	2101      	movs	r1, #1
20022c7e:	4620      	mov	r0, r4
20022c80:	f7ff fc88 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022c84:	2200      	movs	r2, #0
20022c86:	2102      	movs	r1, #2
20022c88:	4620      	mov	r0, r4
20022c8a:	f7ff fec8 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022c8e:	4620      	mov	r0, r4
20022c90:	f7ff fccd 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
20022c94:	2800      	cmp	r0, #0
20022c96:	d0f5      	beq.n	20022c84 <nor_qspi_switch+0x104>
20022c98:	e7b2      	b.n	20022c00 <nor_qspi_switch+0x80>
20022c9a:	2502      	movs	r5, #2
20022c9c:	e7d1      	b.n	20022c42 <nor_qspi_switch+0xc2>

20022c9e <HAL_FLASH_SET_QUAL_SPI>:
20022c9e:	b538      	push	{r3, r4, r5, lr}
20022ca0:	4604      	mov	r4, r0
20022ca2:	460d      	mov	r5, r1
20022ca4:	f7ff ff6c 	bl	20022b80 <nor_qspi_switch>
20022ca8:	4629      	mov	r1, r5
20022caa:	4620      	mov	r0, r4
20022cac:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022cb0:	f7ff be0d 	b.w	200228ce <HAL_FLASH_CONFIG_AHB_READ>

20022cb4 <HAL_FLASH_FADDR_SET_QSPI>:
20022cb4:	b538      	push	{r3, r4, r5, lr}
20022cb6:	4604      	mov	r4, r0
20022cb8:	460d      	mov	r5, r1
20022cba:	f7ff ff61 	bl	20022b80 <nor_qspi_switch>
20022cbe:	4629      	mov	r1, r5
20022cc0:	4620      	mov	r0, r4
20022cc2:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022cc6:	f7ff be46 	b.w	20022956 <HAL_FLASH_CONFIG_FULL_AHB_READ>

20022cca <HAL_FLASH_GET_NOR_ID>:
20022cca:	b510      	push	{r4, lr}
20022ccc:	4604      	mov	r4, r0
20022cce:	b140      	cbz	r0, 20022ce2 <HAL_FLASH_GET_NOR_ID+0x18>
20022cd0:	6802      	ldr	r2, [r0, #0]
20022cd2:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022cd4:	f36f 0315 	bfc	r3, #0, #22
20022cd8:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
20022cdc:	f043 0301 	orr.w	r3, r3, #1
20022ce0:	6293      	str	r3, [r2, #40]	@ 0x28
20022ce2:	2103      	movs	r1, #3
20022ce4:	4620      	mov	r0, r4
20022ce6:	f7ff fc55 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022cea:	2200      	movs	r2, #0
20022cec:	219f      	movs	r1, #159	@ 0x9f
20022cee:	4620      	mov	r0, r4
20022cf0:	f7ff fc75 	bl	200225de <HAL_FLASH_SET_CMD>
20022cf4:	4620      	mov	r0, r4
20022cf6:	f7ff fca3 	bl	20022640 <HAL_FLASH_READ32>
20022cfa:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022cfe:	bd10      	pop	{r4, pc}

20022d00 <HAL_FLASH_CLR_PROTECT>:
20022d00:	b570      	push	{r4, r5, r6, lr}
20022d02:	4604      	mov	r4, r0
20022d04:	2800      	cmp	r0, #0
20022d06:	d03e      	beq.n	20022d86 <HAL_FLASH_CLR_PROTECT+0x86>
20022d08:	68c3      	ldr	r3, [r0, #12]
20022d0a:	2101      	movs	r1, #1
20022d0c:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022d10:	2d00      	cmp	r5, #0
20022d12:	d03b      	beq.n	20022d8c <HAL_FLASH_CLR_PROTECT+0x8c>
20022d14:	f7ff fc3e 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022d18:	2200      	movs	r2, #0
20022d1a:	2102      	movs	r1, #2
20022d1c:	4620      	mov	r0, r4
20022d1e:	f7ff fe7e 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d22:	bb88      	cbnz	r0, 20022d88 <HAL_FLASH_CLR_PROTECT+0x88>
20022d24:	4620      	mov	r0, r4
20022d26:	f7ff fc8b 	bl	20022640 <HAL_FLASH_READ32>
20022d2a:	b2c0      	uxtb	r0, r0
20022d2c:	68e3      	ldr	r3, [r4, #12]
20022d2e:	79dd      	ldrb	r5, [r3, #7]
20022d30:	b10d      	cbz	r5, 20022d36 <HAL_FLASH_CLR_PROTECT+0x36>
20022d32:	ea20 0505 	bic.w	r5, r0, r5
20022d36:	2200      	movs	r2, #0
20022d38:	2115      	movs	r1, #21
20022d3a:	4620      	mov	r0, r4
20022d3c:	f7ff fe6f 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d40:	4606      	mov	r6, r0
20022d42:	b120      	cbz	r0, 20022d4e <HAL_FLASH_CLR_PROTECT+0x4e>
20022d44:	2200      	movs	r2, #0
20022d46:	4620      	mov	r0, r4
20022d48:	4611      	mov	r1, r2
20022d4a:	f7ff fe68 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d4e:	4629      	mov	r1, r5
20022d50:	4620      	mov	r0, r4
20022d52:	f7ff fc18 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20022d56:	2101      	movs	r1, #1
20022d58:	4620      	mov	r0, r4
20022d5a:	f7ff fc1b 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022d5e:	2200      	movs	r2, #0
20022d60:	2103      	movs	r1, #3
20022d62:	4620      	mov	r0, r4
20022d64:	f7ff fe5b 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d68:	b16e      	cbz	r6, 20022d86 <HAL_FLASH_CLR_PROTECT+0x86>
20022d6a:	2101      	movs	r1, #1
20022d6c:	4620      	mov	r0, r4
20022d6e:	f7ff fc11 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022d72:	2200      	movs	r2, #0
20022d74:	2102      	movs	r1, #2
20022d76:	4620      	mov	r0, r4
20022d78:	f7ff fe51 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d7c:	4620      	mov	r0, r4
20022d7e:	f7ff fc56 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
20022d82:	2800      	cmp	r0, #0
20022d84:	d0f5      	beq.n	20022d72 <HAL_FLASH_CLR_PROTECT+0x72>
20022d86:	bd70      	pop	{r4, r5, r6, pc}
20022d88:	2000      	movs	r0, #0
20022d8a:	e7cf      	b.n	20022d2c <HAL_FLASH_CLR_PROTECT+0x2c>
20022d8c:	f7ff fc02 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022d90:	462a      	mov	r2, r5
20022d92:	2102      	movs	r1, #2
20022d94:	4620      	mov	r0, r4
20022d96:	f7ff fe42 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022d9a:	2800      	cmp	r0, #0
20022d9c:	d13e      	bne.n	20022e1c <HAL_FLASH_CLR_PROTECT+0x11c>
20022d9e:	4620      	mov	r0, r4
20022da0:	f7ff fc4e 	bl	20022640 <HAL_FLASH_READ32>
20022da4:	b2c6      	uxtb	r6, r0
20022da6:	2200      	movs	r2, #0
20022da8:	2114      	movs	r1, #20
20022daa:	4620      	mov	r0, r4
20022dac:	f7ff fe37 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022db0:	b918      	cbnz	r0, 20022dba <HAL_FLASH_CLR_PROTECT+0xba>
20022db2:	4620      	mov	r0, r4
20022db4:	f7ff fc44 	bl	20022640 <HAL_FLASH_READ32>
20022db8:	b2c5      	uxtb	r5, r0
20022dba:	68e3      	ldr	r3, [r4, #12]
20022dbc:	79d9      	ldrb	r1, [r3, #7]
20022dbe:	b109      	cbz	r1, 20022dc4 <HAL_FLASH_CLR_PROTECT+0xc4>
20022dc0:	ea26 0101 	bic.w	r1, r6, r1
20022dc4:	2200      	movs	r2, #0
20022dc6:	4620      	mov	r0, r4
20022dc8:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20022dcc:	2115      	movs	r1, #21
20022dce:	f7ff fe26 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022dd2:	4606      	mov	r6, r0
20022dd4:	b120      	cbz	r0, 20022de0 <HAL_FLASH_CLR_PROTECT+0xe0>
20022dd6:	2200      	movs	r2, #0
20022dd8:	4620      	mov	r0, r4
20022dda:	4611      	mov	r1, r2
20022ddc:	f7ff fe1f 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022de0:	4629      	mov	r1, r5
20022de2:	4620      	mov	r0, r4
20022de4:	f7ff fbcf 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20022de8:	2102      	movs	r1, #2
20022dea:	4620      	mov	r0, r4
20022dec:	f7ff fbd2 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022df0:	2200      	movs	r2, #0
20022df2:	2103      	movs	r1, #3
20022df4:	4620      	mov	r0, r4
20022df6:	f7ff fe12 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022dfa:	2e00      	cmp	r6, #0
20022dfc:	d0c3      	beq.n	20022d86 <HAL_FLASH_CLR_PROTECT+0x86>
20022dfe:	2101      	movs	r1, #1
20022e00:	4620      	mov	r0, r4
20022e02:	f7ff fbc7 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022e06:	2200      	movs	r2, #0
20022e08:	2102      	movs	r1, #2
20022e0a:	4620      	mov	r0, r4
20022e0c:	f7ff fe07 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022e10:	4620      	mov	r0, r4
20022e12:	f7ff fc0c 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
20022e16:	2800      	cmp	r0, #0
20022e18:	d0f5      	beq.n	20022e06 <HAL_FLASH_CLR_PROTECT+0x106>
20022e1a:	e7b4      	b.n	20022d86 <HAL_FLASH_CLR_PROTECT+0x86>
20022e1c:	462e      	mov	r6, r5
20022e1e:	e7c2      	b.n	20022da6 <HAL_FLASH_CLR_PROTECT+0xa6>

20022e20 <HAL_FLASH_PreInit>:
20022e20:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022e22:	4604      	mov	r4, r0
20022e24:	b358      	cbz	r0, 20022e7e <HAL_FLASH_PreInit+0x5e>
20022e26:	2300      	movs	r3, #0
20022e28:	22ff      	movs	r2, #255	@ 0xff
20022e2a:	2101      	movs	r1, #1
20022e2c:	f04f 2650 	mov.w	r6, #1342197760	@ 0x50005000
20022e30:	6805      	ldr	r5, [r0, #0]
20022e32:	6043      	str	r3, [r0, #4]
20022e34:	f880 102a 	strb.w	r1, [r0, #42]	@ 0x2a
20022e38:	f880 3028 	strb.w	r3, [r0, #40]	@ 0x28
20022e3c:	f8c5 208c 	str.w	r2, [r5, #140]	@ 0x8c
20022e40:	6805      	ldr	r5, [r0, #0]
20022e42:	f8c5 6080 	str.w	r6, [r5, #128]	@ 0x80
20022e46:	6805      	ldr	r5, [r0, #0]
20022e48:	622a      	str	r2, [r5, #32]
20022e4a:	6805      	ldr	r5, [r0, #0]
20022e4c:	646a      	str	r2, [r5, #68]	@ 0x44
20022e4e:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
20022e52:	6083      	str	r3, [r0, #8]
20022e54:	f7ff fc65 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20022e58:	4620      	mov	r0, r4
20022e5a:	f7ff ff36 	bl	20022cca <HAL_FLASH_GET_NOR_ID>
20022e5e:	f3c0 2707 	ubfx	r7, r0, #8, #8
20022e62:	f3c0 4507 	ubfx	r5, r0, #16, #8
20022e66:	b2c6      	uxtb	r6, r0
20022e68:	4629      	mov	r1, r5
20022e6a:	463a      	mov	r2, r7
20022e6c:	4630      	mov	r0, r6
20022e6e:	f002 f809 	bl	20024e84 <spi_flash_get_cmd_by_id>
20022e72:	4601      	mov	r1, r0
20022e74:	60e0      	str	r0, [r4, #12]
20022e76:	b920      	cbnz	r0, 20022e82 <HAL_FLASH_PreInit+0x62>
20022e78:	4620      	mov	r0, r4
20022e7a:	f7ff fc52 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20022e7e:	2001      	movs	r0, #1
20022e80:	e019      	b.n	20022eb6 <HAL_FLASH_PreInit+0x96>
20022e82:	463a      	mov	r2, r7
20022e84:	4629      	mov	r1, r5
20022e86:	4630      	mov	r0, r6
20022e88:	f002 f824 	bl	20024ed4 <spi_flash_get_otp_base>
20022e8c:	463a      	mov	r2, r7
20022e8e:	63a0      	str	r0, [r4, #56]	@ 0x38
20022e90:	4629      	mov	r1, r5
20022e92:	4630      	mov	r0, r6
20022e94:	f001 ffce 	bl	20024e34 <spi_nor_get_ext_cfg_by_id>
20022e98:	63e0      	str	r0, [r4, #60]	@ 0x3c
20022e9a:	b108      	cbz	r0, 20022ea0 <HAL_FLASH_PreInit+0x80>
20022e9c:	6803      	ldr	r3, [r0, #0]
20022e9e:	63a3      	str	r3, [r4, #56]	@ 0x38
20022ea0:	463a      	mov	r2, r7
20022ea2:	4629      	mov	r1, r5
20022ea4:	4630      	mov	r0, r6
20022ea6:	f002 f801 	bl	20024eac <spi_flash_get_size_by_id>
20022eaa:	b100      	cbz	r0, 20022eae <HAL_FLASH_PreInit+0x8e>
20022eac:	6160      	str	r0, [r4, #20]
20022eae:	f894 502b 	ldrb.w	r5, [r4, #43]	@ 0x2b
20022eb2:	b10d      	cbz	r5, 20022eb8 <HAL_FLASH_PreInit+0x98>
20022eb4:	2000      	movs	r0, #0
20022eb6:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20022eb8:	4620      	mov	r0, r4
20022eba:	f7ff ff21 	bl	20022d00 <HAL_FLASH_CLR_PROTECT>
20022ebe:	6963      	ldr	r3, [r4, #20]
20022ec0:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20022ec4:	d90d      	bls.n	20022ee2 <HAL_FLASH_PreInit+0xc2>
20022ec6:	2121      	movs	r1, #33	@ 0x21
20022ec8:	462a      	mov	r2, r5
20022eca:	4620      	mov	r0, r4
20022ecc:	f7ff fda7 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022ed0:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022ed4:	b919      	cbnz	r1, 20022ede <HAL_FLASH_PreInit+0xbe>
20022ed6:	4620      	mov	r0, r4
20022ed8:	f7ff feec 	bl	20022cb4 <HAL_FLASH_FADDR_SET_QSPI>
20022edc:	e7ea      	b.n	20022eb4 <HAL_FLASH_PreInit+0x94>
20022ede:	2101      	movs	r1, #1
20022ee0:	e7f9      	b.n	20022ed6 <HAL_FLASH_PreInit+0xb6>
20022ee2:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022ee6:	b919      	cbnz	r1, 20022ef0 <HAL_FLASH_PreInit+0xd0>
20022ee8:	4620      	mov	r0, r4
20022eea:	f7ff fed8 	bl	20022c9e <HAL_FLASH_SET_QUAL_SPI>
20022eee:	e7e1      	b.n	20022eb4 <HAL_FLASH_PreInit+0x94>
20022ef0:	2101      	movs	r1, #1
20022ef2:	e7f9      	b.n	20022ee8 <HAL_FLASH_PreInit+0xc8>

20022ef4 <HAL_QSPI_SET_CLK_INV>:
20022ef4:	b120      	cbz	r0, 20022f00 <HAL_QSPI_SET_CLK_INV+0xc>
20022ef6:	6802      	ldr	r2, [r0, #0]
20022ef8:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022efa:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20022efe:	6593      	str	r3, [r2, #88]	@ 0x58
20022f00:	4770      	bx	lr

20022f02 <HAL_QSPI_READ_OTP>:
20022f02:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022f06:	4691      	mov	r9, r2
20022f08:	4605      	mov	r5, r0
20022f0a:	2800      	cmp	r0, #0
20022f0c:	d044      	beq.n	20022f98 <HAL_QSPI_READ_OTP+0x96>
20022f0e:	68c4      	ldr	r4, [r0, #12]
20022f10:	b1b4      	cbz	r4, 20022f40 <HAL_QSPI_READ_OTP+0x3e>
20022f12:	f5b1 5f80 	cmp.w	r1, #4096	@ 0x1000
20022f16:	d33f      	bcc.n	20022f98 <HAL_QSPI_READ_OTP+0x96>
20022f18:	79a2      	ldrb	r2, [r4, #6]
20022f1a:	3201      	adds	r2, #1
20022f1c:	ebb1 3f02 	cmp.w	r1, r2, lsl #12
20022f20:	d23a      	bcs.n	20022f98 <HAL_QSPI_READ_OTP+0x96>
20022f22:	7ae0      	ldrb	r0, [r4, #11]
20022f24:	f3c1 0209 	ubfx	r2, r1, #0, #10
20022f28:	441a      	add	r2, r3
20022f2a:	ebb2 2f00 	cmp.w	r2, r0, lsl #8
20022f2e:	d833      	bhi.n	20022f98 <HAL_QSPI_READ_OTP+0x96>
20022f30:	461c      	mov	r4, r3
20022f32:	2700      	movs	r7, #0
20022f34:	46a2      	mov	sl, r4
20022f36:	6bab      	ldr	r3, [r5, #56]	@ 0x38
20022f38:	18ce      	adds	r6, r1, r3
20022f3a:	f1ba 0f00 	cmp.w	sl, #0
20022f3e:	dc02      	bgt.n	20022f46 <HAL_QSPI_READ_OTP+0x44>
20022f40:	4620      	mov	r0, r4
20022f42:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20022f46:	f1ba 0f40 	cmp.w	sl, #64	@ 0x40
20022f4a:	46d0      	mov	r8, sl
20022f4c:	bfa8      	it	ge
20022f4e:	f04f 0840 	movge.w	r8, #64	@ 0x40
20022f52:	4628      	mov	r0, r5
20022f54:	4641      	mov	r1, r8
20022f56:	f7ff fb1d 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20022f5a:	4632      	mov	r2, r6
20022f5c:	2132      	movs	r1, #50	@ 0x32
20022f5e:	4628      	mov	r0, r5
20022f60:	f7ff fd5d 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20022f64:	463b      	mov	r3, r7
20022f66:	2f00      	cmp	r7, #0
20022f68:	bfb8      	it	lt
20022f6a:	1cfb      	addlt	r3, r7, #3
20022f6c:	ea4f 01a8 	mov.w	r1, r8, asr #2
20022f70:	f023 0203 	bic.w	r2, r3, #3
20022f74:	eb01 01a3 	add.w	r1, r1, r3, asr #2
20022f78:	444a      	add	r2, r9
20022f7a:	eb09 0181 	add.w	r1, r9, r1, lsl #2
20022f7e:	428a      	cmp	r2, r1
20022f80:	d104      	bne.n	20022f8c <HAL_QSPI_READ_OTP+0x8a>
20022f82:	4447      	add	r7, r8
20022f84:	4446      	add	r6, r8
20022f86:	ebaa 0a08 	sub.w	sl, sl, r8
20022f8a:	e7d6      	b.n	20022f3a <HAL_QSPI_READ_OTP+0x38>
20022f8c:	4628      	mov	r0, r5
20022f8e:	f7ff fb57 	bl	20022640 <HAL_FLASH_READ32>
20022f92:	f842 0b04 	str.w	r0, [r2], #4
20022f96:	e7f2      	b.n	20022f7e <HAL_QSPI_READ_OTP+0x7c>
20022f98:	2400      	movs	r4, #0
20022f9a:	e7d1      	b.n	20022f40 <HAL_QSPI_READ_OTP+0x3e>

20022f9c <HAL_FLASH_RELEASE_DPD>:
20022f9c:	b538      	push	{r3, r4, r5, lr}
20022f9e:	4604      	mov	r4, r0
20022fa0:	b1d0      	cbz	r0, 20022fd8 <HAL_FLASH_RELEASE_DPD+0x3c>
20022fa2:	6803      	ldr	r3, [r0, #0]
20022fa4:	21ab      	movs	r1, #171	@ 0xab
20022fa6:	681d      	ldr	r5, [r3, #0]
20022fa8:	f015 0501 	ands.w	r5, r5, #1
20022fac:	bf02      	ittt	eq
20022fae:	681a      	ldreq	r2, [r3, #0]
20022fb0:	f042 0201 	orreq.w	r2, r2, #1
20022fb4:	601a      	streq	r2, [r3, #0]
20022fb6:	6802      	ldr	r2, [r0, #0]
20022fb8:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022fba:	f36f 0315 	bfc	r3, #0, #22
20022fbe:	f043 0301 	orr.w	r3, r3, #1
20022fc2:	6293      	str	r3, [r2, #40]	@ 0x28
20022fc4:	2200      	movs	r2, #0
20022fc6:	f7ff fb0a 	bl	200225de <HAL_FLASH_SET_CMD>
20022fca:	b925      	cbnz	r5, 20022fd6 <HAL_FLASH_RELEASE_DPD+0x3a>
20022fcc:	6822      	ldr	r2, [r4, #0]
20022fce:	6813      	ldr	r3, [r2, #0]
20022fd0:	f023 0301 	bic.w	r3, r3, #1
20022fd4:	6013      	str	r3, [r2, #0]
20022fd6:	bd38      	pop	{r3, r4, r5, pc}
20022fd8:	2001      	movs	r0, #1
20022fda:	e7fc      	b.n	20022fd6 <HAL_FLASH_RELEASE_DPD+0x3a>

20022fdc <flash_handle_valid>:
20022fdc:	b118      	cbz	r0, 20022fe6 <flash_handle_valid+0xa>
20022fde:	68c0      	ldr	r0, [r0, #12]
20022fe0:	3800      	subs	r0, #0
20022fe2:	bf18      	it	ne
20022fe4:	2001      	movne	r0, #1
20022fe6:	4770      	bx	lr

20022fe8 <HAL_GET_FLASH_MID>:
20022fe8:	2000      	movs	r0, #0
20022fea:	4770      	bx	lr

20022fec <HAL_FLASH_DMA_START>:
20022fec:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022ff0:	4688      	mov	r8, r1
20022ff2:	4699      	mov	r9, r3
20022ff4:	4604      	mov	r4, r0
20022ff6:	2800      	cmp	r0, #0
20022ff8:	d045      	beq.n	20023086 <HAL_FLASH_DMA_START+0x9a>
20022ffa:	6883      	ldr	r3, [r0, #8]
20022ffc:	2b00      	cmp	r3, #0
20022ffe:	d042      	beq.n	20023086 <HAL_FLASH_DMA_START+0x9a>
20023000:	f1b9 0f00 	cmp.w	r9, #0
20023004:	d03f      	beq.n	20023086 <HAL_FLASH_DMA_START+0x9a>
20023006:	6801      	ldr	r1, [r0, #0]
20023008:	680f      	ldr	r7, [r1, #0]
2002300a:	b332      	cbz	r2, 2002305a <HAL_FLASH_DMA_START+0x6e>
2002300c:	2210      	movs	r2, #16
2002300e:	609a      	str	r2, [r3, #8]
20023010:	2300      	movs	r3, #0
20023012:	6882      	ldr	r2, [r0, #8]
20023014:	464e      	mov	r6, r9
20023016:	6153      	str	r3, [r2, #20]
20023018:	6882      	ldr	r2, [r0, #8]
2002301a:	6193      	str	r3, [r2, #24]
2002301c:	6882      	ldr	r2, [r0, #8]
2002301e:	60d3      	str	r3, [r2, #12]
20023020:	2280      	movs	r2, #128	@ 0x80
20023022:	6883      	ldr	r3, [r0, #8]
20023024:	611a      	str	r2, [r3, #16]
20023026:	6805      	ldr	r5, [r0, #0]
20023028:	3504      	adds	r5, #4
2002302a:	68a0      	ldr	r0, [r4, #8]
2002302c:	f7fe fffa 	bl	20022024 <HAL_DMA_DeInit>
20023030:	bb50      	cbnz	r0, 20023088 <HAL_FLASH_DMA_START+0x9c>
20023032:	68a0      	ldr	r0, [r4, #8]
20023034:	f7fe ff8a 	bl	20021f4c <HAL_DMA_Init>
20023038:	bb30      	cbnz	r0, 20023088 <HAL_FLASH_DMA_START+0x9c>
2002303a:	6823      	ldr	r3, [r4, #0]
2002303c:	f047 0720 	orr.w	r7, r7, #32
20023040:	601f      	str	r7, [r3, #0]
20023042:	6822      	ldr	r2, [r4, #0]
20023044:	f109 33ff 	add.w	r3, r9, #4294967295
20023048:	6253      	str	r3, [r2, #36]	@ 0x24
2002304a:	4641      	mov	r1, r8
2002304c:	4633      	mov	r3, r6
2002304e:	462a      	mov	r2, r5
20023050:	68a0      	ldr	r0, [r4, #8]
20023052:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20023056:	f7ff b96d 	b.w	20022334 <HAL_DMA_Start>
2002305a:	f44f 7100 	mov.w	r1, #512	@ 0x200
2002305e:	609a      	str	r2, [r3, #8]
20023060:	6883      	ldr	r3, [r0, #8]
20023062:	f109 0603 	add.w	r6, r9, #3
20023066:	6159      	str	r1, [r3, #20]
20023068:	f44f 6100 	mov.w	r1, #2048	@ 0x800
2002306c:	6883      	ldr	r3, [r0, #8]
2002306e:	4645      	mov	r5, r8
20023070:	6199      	str	r1, [r3, #24]
20023072:	6883      	ldr	r3, [r0, #8]
20023074:	08b6      	lsrs	r6, r6, #2
20023076:	60da      	str	r2, [r3, #12]
20023078:	2280      	movs	r2, #128	@ 0x80
2002307a:	6883      	ldr	r3, [r0, #8]
2002307c:	611a      	str	r2, [r3, #16]
2002307e:	6803      	ldr	r3, [r0, #0]
20023080:	f103 0804 	add.w	r8, r3, #4
20023084:	e7d1      	b.n	2002302a <HAL_FLASH_DMA_START+0x3e>
20023086:	2001      	movs	r0, #1
20023088:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

2002308c <HAL_FLASH_DMA_WAIT_DONE>:
2002308c:	b510      	push	{r4, lr}
2002308e:	460a      	mov	r2, r1
20023090:	4604      	mov	r4, r0
20023092:	b170      	cbz	r0, 200230b2 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20023094:	6880      	ldr	r0, [r0, #8]
20023096:	b160      	cbz	r0, 200230b2 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20023098:	6b61      	ldr	r1, [r4, #52]	@ 0x34
2002309a:	b111      	cbz	r1, 200230a2 <HAL_FLASH_DMA_WAIT_DONE+0x16>
2002309c:	f04f 32ff 	mov.w	r2, #4294967295
200230a0:	2100      	movs	r1, #0
200230a2:	f7ff f82f 	bl	20022104 <HAL_DMA_PollForTransfer>
200230a6:	6822      	ldr	r2, [r4, #0]
200230a8:	6813      	ldr	r3, [r2, #0]
200230aa:	f023 0320 	bic.w	r3, r3, #32
200230ae:	6013      	str	r3, [r2, #0]
200230b0:	bd10      	pop	{r4, pc}
200230b2:	2001      	movs	r0, #1
200230b4:	e7fc      	b.n	200230b0 <HAL_FLASH_DMA_WAIT_DONE+0x24>

200230b6 <HAL_FLASH_ALIAS_CFG>:
200230b6:	b538      	push	{r3, r4, r5, lr}
200230b8:	461d      	mov	r5, r3
200230ba:	4604      	mov	r4, r0
200230bc:	b158      	cbz	r0, 200230d6 <HAL_FLASH_ALIAS_CFG+0x20>
200230be:	6903      	ldr	r3, [r0, #16]
200230c0:	428b      	cmp	r3, r1
200230c2:	bf98      	it	ls
200230c4:	1ac9      	subls	r1, r1, r3
200230c6:	f7ff fb11 	bl	200226ec <HAL_FLASH_SET_ALIAS_RANGE>
200230ca:	4629      	mov	r1, r5
200230cc:	4620      	mov	r0, r4
200230ce:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200230d2:	f7ff bb1d 	b.w	20022710 <HAL_FLASH_SET_ALIAS_OFFSET>
200230d6:	bd38      	pop	{r3, r4, r5, pc}

200230d8 <nand_read_id>:
200230d8:	b510      	push	{r4, lr}
200230da:	460b      	mov	r3, r1
200230dc:	4604      	mov	r4, r0
200230de:	b086      	sub	sp, #24
200230e0:	b320      	cbz	r0, 2002312c <nand_read_id+0x54>
200230e2:	2908      	cmp	r1, #8
200230e4:	f04f 0100 	mov.w	r1, #0
200230e8:	f04f 0201 	mov.w	r2, #1
200230ec:	bf83      	ittte	hi
200230ee:	460b      	movhi	r3, r1
200230f0:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
200230f4:	e9cd 1100 	strdhi	r1, r1, [sp]
200230f8:	e9cd 1102 	strdls	r1, r1, [sp, #8]
200230fc:	bf8e      	itee	hi
200230fe:	4619      	movhi	r1, r3
20023100:	e9cd 1100 	strdls	r1, r1, [sp]
20023104:	b25b      	sxtbls	r3, r3
20023106:	9204      	str	r2, [sp, #16]
20023108:	f7ff faae 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
2002310c:	2103      	movs	r1, #3
2002310e:	4620      	mov	r0, r4
20023110:	f7ff fa40 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023114:	2200      	movs	r2, #0
20023116:	219f      	movs	r1, #159	@ 0x9f
20023118:	4620      	mov	r0, r4
2002311a:	f7ff fa60 	bl	200225de <HAL_FLASH_SET_CMD>
2002311e:	4620      	mov	r0, r4
20023120:	f7ff fa8e 	bl	20022640 <HAL_FLASH_READ32>
20023124:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20023128:	b006      	add	sp, #24
2002312a:	bd10      	pop	{r4, pc}
2002312c:	20ff      	movs	r0, #255	@ 0xff
2002312e:	e7fb      	b.n	20023128 <nand_read_id+0x50>

20023130 <HAL_NAND_CONF_ECC>:
20023130:	b538      	push	{r3, r4, r5, lr}
20023132:	460d      	mov	r5, r1
20023134:	4604      	mov	r4, r0
20023136:	b398      	cbz	r0, 200231a0 <HAL_NAND_CONF_ECC+0x70>
20023138:	68c3      	ldr	r3, [r0, #12]
2002313a:	b38b      	cbz	r3, 200231a0 <HAL_NAND_CONF_ECC+0x70>
2002313c:	799a      	ldrb	r2, [r3, #6]
2002313e:	b392      	cbz	r2, 200231a6 <HAL_NAND_CONF_ECC+0x76>
20023140:	7a9b      	ldrb	r3, [r3, #10]
20023142:	b383      	cbz	r3, 200231a6 <HAL_NAND_CONF_ECC+0x76>
20023144:	2101      	movs	r1, #1
20023146:	f7ff fa25 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
2002314a:	68e3      	ldr	r3, [r4, #12]
2002314c:	2102      	movs	r1, #2
2002314e:	799a      	ldrb	r2, [r3, #6]
20023150:	4620      	mov	r0, r4
20023152:	f7ff fc64 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023156:	4620      	mov	r0, r4
20023158:	f7ff fa72 	bl	20022640 <HAL_FLASH_READ32>
2002315c:	68e3      	ldr	r3, [r4, #12]
2002315e:	7a9b      	ldrb	r3, [r3, #10]
20023160:	b1dd      	cbz	r5, 2002319a <HAL_NAND_CONF_ECC+0x6a>
20023162:	ea43 0100 	orr.w	r1, r3, r0
20023166:	4620      	mov	r0, r4
20023168:	f7ff fa0d 	bl	20022586 <HAL_FLASH_WRITE_WORD>
2002316c:	2101      	movs	r1, #1
2002316e:	4620      	mov	r0, r4
20023170:	f7ff fa10 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023174:	68e3      	ldr	r3, [r4, #12]
20023176:	2103      	movs	r1, #3
20023178:	799a      	ldrb	r2, [r3, #6]
2002317a:	4620      	mov	r0, r4
2002317c:	f7ff fc4f 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023180:	68e3      	ldr	r3, [r4, #12]
20023182:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20023186:	2102      	movs	r1, #2
20023188:	799a      	ldrb	r2, [r3, #6]
2002318a:	4620      	mov	r0, r4
2002318c:	f7ff fc47 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023190:	4620      	mov	r0, r4
20023192:	f7ff fa55 	bl	20022640 <HAL_FLASH_READ32>
20023196:	2000      	movs	r0, #0
20023198:	bd38      	pop	{r3, r4, r5, pc}
2002319a:	ea20 0103 	bic.w	r1, r0, r3
2002319e:	e7e2      	b.n	20023166 <HAL_NAND_CONF_ECC+0x36>
200231a0:	f04f 30ff 	mov.w	r0, #4294967295
200231a4:	e7f8      	b.n	20023198 <HAL_NAND_CONF_ECC+0x68>
200231a6:	f06f 0001 	mvn.w	r0, #1
200231aa:	e7f5      	b.n	20023198 <HAL_NAND_CONF_ECC+0x68>

200231ac <HAL_NAND_GET_ECC_STATUS>:
200231ac:	b510      	push	{r4, lr}
200231ae:	4604      	mov	r4, r0
200231b0:	b320      	cbz	r0, 200231fc <HAL_NAND_GET_ECC_STATUS+0x50>
200231b2:	68c2      	ldr	r2, [r0, #12]
200231b4:	b31a      	cbz	r2, 200231fe <HAL_NAND_GET_ECC_STATUS+0x52>
200231b6:	7913      	ldrb	r3, [r2, #4]
200231b8:	b31b      	cbz	r3, 20023202 <HAL_NAND_GET_ECC_STATUS+0x56>
200231ba:	79d3      	ldrb	r3, [r2, #7]
200231bc:	b30b      	cbz	r3, 20023202 <HAL_NAND_GET_ECC_STATUS+0x56>
200231be:	2101      	movs	r1, #1
200231c0:	f7ff f9e8 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
200231c4:	68e3      	ldr	r3, [r4, #12]
200231c6:	2102      	movs	r1, #2
200231c8:	791a      	ldrb	r2, [r3, #4]
200231ca:	4620      	mov	r0, r4
200231cc:	f7ff fc27 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
200231d0:	4620      	mov	r0, r4
200231d2:	f7ff fa35 	bl	20022640 <HAL_FLASH_READ32>
200231d6:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
200231da:	2a3f      	cmp	r2, #63	@ 0x3f
200231dc:	ea4f 1312 	mov.w	r3, r2, lsr #4
200231e0:	d804      	bhi.n	200231ec <HAL_NAND_GET_ECC_STATUS+0x40>
200231e2:	2b01      	cmp	r3, #1
200231e4:	d808      	bhi.n	200231f8 <HAL_NAND_GET_ECC_STATUS+0x4c>
200231e6:	f000 0030 	and.w	r0, r0, #48	@ 0x30
200231ea:	e007      	b.n	200231fc <HAL_NAND_GET_ECC_STATUS+0x50>
200231ec:	3b04      	subs	r3, #4
200231ee:	2b01      	cmp	r3, #1
200231f0:	d8f9      	bhi.n	200231e6 <HAL_NAND_GET_ECC_STATUS+0x3a>
200231f2:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
200231f6:	e001      	b.n	200231fc <HAL_NAND_GET_ECC_STATUS+0x50>
200231f8:	f000 0070 	and.w	r0, r0, #112	@ 0x70
200231fc:	bd10      	pop	{r4, pc}
200231fe:	4610      	mov	r0, r2
20023200:	e7fc      	b.n	200231fc <HAL_NAND_GET_ECC_STATUS+0x50>
20023202:	4618      	mov	r0, r3
20023204:	e7fa      	b.n	200231fc <HAL_NAND_GET_ECC_STATUS+0x50>
	...

20023208 <HAL_NAND_CHECK_ECC>:
20023208:	4603      	mov	r3, r0
2002320a:	1108      	asrs	r0, r1, #4
2002320c:	b172      	cbz	r2, 2002322c <HAL_NAND_CHECK_ECC+0x24>
2002320e:	2b07      	cmp	r3, #7
20023210:	d80c      	bhi.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
20023212:	e8df f003 	tbb	[pc, r3]
20023216:	0d04      	.short	0x0d04
20023218:	3f352e18 	.word	0x3f352e18
2002321c:	4c47      	.short	0x4c47
2002321e:	b128      	cbz	r0, 2002322c <HAL_NAND_CHECK_ECC+0x24>
20023220:	2801      	cmp	r0, #1
20023222:	6813      	ldr	r3, [r2, #0]
20023224:	d10a      	bne.n	2002323c <HAL_NAND_CHECK_ECC+0x34>
20023226:	f043 0301 	orr.w	r3, r3, #1
2002322a:	6013      	str	r3, [r2, #0]
2002322c:	2000      	movs	r0, #0
2002322e:	4770      	bx	lr
20023230:	f020 0302 	bic.w	r3, r0, #2
20023234:	2b01      	cmp	r3, #1
20023236:	d003      	beq.n	20023240 <HAL_NAND_CHECK_ECC+0x38>
20023238:	b1d0      	cbz	r0, 20023270 <HAL_NAND_CHECK_ECC+0x68>
2002323a:	6813      	ldr	r3, [r2, #0]
2002323c:	4303      	orrs	r3, r0
2002323e:	e016      	b.n	2002326e <HAL_NAND_CHECK_ECC+0x66>
20023240:	6813      	ldr	r3, [r2, #0]
20023242:	4303      	orrs	r3, r0
20023244:	e7f1      	b.n	2002322a <HAL_NAND_CHECK_ECC+0x22>
20023246:	2805      	cmp	r0, #5
20023248:	d8f7      	bhi.n	2002323a <HAL_NAND_CHECK_ECC+0x32>
2002324a:	a301      	add	r3, pc, #4	@ (adr r3, 20023250 <HAL_NAND_CHECK_ECC+0x48>)
2002324c:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
20023250:	2002322d 	.word	0x2002322d
20023254:	20023241 	.word	0x20023241
20023258:	20023269 	.word	0x20023269
2002325c:	20023241 	.word	0x20023241
20023260:	2002323b 	.word	0x2002323b
20023264:	20023241 	.word	0x20023241
20023268:	6813      	ldr	r3, [r2, #0]
2002326a:	f043 0302 	orr.w	r3, r3, #2
2002326e:	6013      	str	r3, [r2, #0]
20023270:	4770      	bx	lr
20023272:	2800      	cmp	r0, #0
20023274:	d0da      	beq.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
20023276:	1e43      	subs	r3, r0, #1
20023278:	2b05      	cmp	r3, #5
2002327a:	6813      	ldr	r3, [r2, #0]
2002327c:	d9e1      	bls.n	20023242 <HAL_NAND_CHECK_ECC+0x3a>
2002327e:	e7dd      	b.n	2002323c <HAL_NAND_CHECK_ECC+0x34>
20023280:	07c3      	lsls	r3, r0, #31
20023282:	f000 0103 	and.w	r1, r0, #3
20023286:	d402      	bmi.n	2002328e <HAL_NAND_CHECK_ECC+0x86>
20023288:	2900      	cmp	r1, #0
2002328a:	d0cf      	beq.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
2002328c:	e7d5      	b.n	2002323a <HAL_NAND_CHECK_ECC+0x32>
2002328e:	6813      	ldr	r3, [r2, #0]
20023290:	430b      	orrs	r3, r1
20023292:	e7ca      	b.n	2002322a <HAL_NAND_CHECK_ECC+0x22>
20023294:	2800      	cmp	r0, #0
20023296:	d0c9      	beq.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
20023298:	6813      	ldr	r3, [r2, #0]
2002329a:	2808      	cmp	r0, #8
2002329c:	ea43 0300 	orr.w	r3, r3, r0
200232a0:	dce5      	bgt.n	2002326e <HAL_NAND_CHECK_ECC+0x66>
200232a2:	e7c2      	b.n	2002322a <HAL_NAND_CHECK_ECC+0x22>
200232a4:	2800      	cmp	r0, #0
200232a6:	d0c1      	beq.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
200232a8:	1e43      	subs	r3, r0, #1
200232aa:	2b01      	cmp	r3, #1
200232ac:	e7e5      	b.n	2002327a <HAL_NAND_CHECK_ECC+0x72>
200232ae:	2800      	cmp	r0, #0
200232b0:	d0bc      	beq.n	2002322c <HAL_NAND_CHECK_ECC+0x24>
200232b2:	1e43      	subs	r3, r0, #1
200232b4:	2b02      	cmp	r3, #2
200232b6:	e7e0      	b.n	2002327a <HAL_NAND_CHECK_ECC+0x72>

200232b8 <HAL_NAND_GET_ECC_RESULT>:
200232b8:	b510      	push	{r4, lr}
200232ba:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
200232be:	4604      	mov	r4, r0
200232c0:	b90b      	cbnz	r3, 200232c6 <HAL_NAND_GET_ECC_RESULT+0xe>
200232c2:	2000      	movs	r0, #0
200232c4:	bd10      	pop	{r4, pc}
200232c6:	f7ff ff71 	bl	200231ac <HAL_NAND_GET_ECC_STATUS>
200232ca:	4601      	mov	r1, r0
200232cc:	2800      	cmp	r0, #0
200232ce:	d0f8      	beq.n	200232c2 <HAL_NAND_GET_ECC_RESULT+0xa>
200232d0:	6862      	ldr	r2, [r4, #4]
200232d2:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
200232d4:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
200232d8:	6062      	str	r2, [r4, #4]
200232da:	b938      	cbnz	r0, 200232ec <HAL_NAND_GET_ECC_RESULT+0x34>
200232dc:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
200232e0:	1d22      	adds	r2, r4, #4
200232e2:	0900      	lsrs	r0, r0, #4
200232e4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200232e8:	f7ff bf8e 	b.w	20023208 <HAL_NAND_CHECK_ECC>
200232ec:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
200232f0:	ea4f 1321 	mov.w	r3, r1, asr #4
200232f4:	db00      	blt.n	200232f8 <HAL_NAND_GET_ECC_RESULT+0x40>
200232f6:	e7fe      	b.n	200232f6 <HAL_NAND_GET_ECC_RESULT+0x3e>
200232f8:	6801      	ldr	r1, [r0, #0]
200232fa:	40d9      	lsrs	r1, r3
200232fc:	f011 0f01 	tst.w	r1, #1
20023300:	bf18      	it	ne
20023302:	4618      	movne	r0, r3
20023304:	ea43 0302 	orr.w	r3, r3, r2
20023308:	bf08      	it	eq
2002330a:	2000      	moveq	r0, #0
2002330c:	6063      	str	r3, [r4, #4]
2002330e:	e7d9      	b.n	200232c4 <HAL_NAND_GET_ECC_RESULT+0xc>

20023310 <HAL_NAND_EN_QUAL>:
20023310:	b538      	push	{r3, r4, r5, lr}
20023312:	460d      	mov	r5, r1
20023314:	4604      	mov	r4, r0
20023316:	b348      	cbz	r0, 2002336c <HAL_NAND_EN_QUAL+0x5c>
20023318:	68c3      	ldr	r3, [r0, #12]
2002331a:	b33b      	cbz	r3, 2002336c <HAL_NAND_EN_QUAL+0x5c>
2002331c:	799a      	ldrb	r2, [r3, #6]
2002331e:	b10a      	cbz	r2, 20023324 <HAL_NAND_EN_QUAL+0x14>
20023320:	7a1b      	ldrb	r3, [r3, #8]
20023322:	b90b      	cbnz	r3, 20023328 <HAL_NAND_EN_QUAL+0x18>
20023324:	2000      	movs	r0, #0
20023326:	bd38      	pop	{r3, r4, r5, pc}
20023328:	2101      	movs	r1, #1
2002332a:	f7ff f933 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
2002332e:	68e3      	ldr	r3, [r4, #12]
20023330:	2102      	movs	r1, #2
20023332:	799a      	ldrb	r2, [r3, #6]
20023334:	4620      	mov	r0, r4
20023336:	f7ff fb72 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
2002333a:	4620      	mov	r0, r4
2002333c:	f7ff f980 	bl	20022640 <HAL_FLASH_READ32>
20023340:	68e3      	ldr	r3, [r4, #12]
20023342:	7a1b      	ldrb	r3, [r3, #8]
20023344:	b17d      	cbz	r5, 20023366 <HAL_NAND_EN_QUAL+0x56>
20023346:	ea43 0100 	orr.w	r1, r3, r0
2002334a:	4620      	mov	r0, r4
2002334c:	f7ff f91b 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20023350:	2101      	movs	r1, #1
20023352:	4620      	mov	r0, r4
20023354:	f7ff f91e 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023358:	68e3      	ldr	r3, [r4, #12]
2002335a:	2103      	movs	r1, #3
2002335c:	4620      	mov	r0, r4
2002335e:	799a      	ldrb	r2, [r3, #6]
20023360:	f7ff fb5d 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023364:	e7de      	b.n	20023324 <HAL_NAND_EN_QUAL+0x14>
20023366:	ea20 0103 	bic.w	r1, r0, r3
2002336a:	e7ee      	b.n	2002334a <HAL_NAND_EN_QUAL+0x3a>
2002336c:	f04f 30ff 	mov.w	r0, #4294967295
20023370:	e7d9      	b.n	20023326 <HAL_NAND_EN_QUAL+0x16>

20023372 <nand_clear_status>:
20023372:	b538      	push	{r3, r4, r5, lr}
20023374:	460d      	mov	r5, r1
20023376:	2101      	movs	r1, #1
20023378:	4604      	mov	r4, r0
2002337a:	f7ff f90b 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
2002337e:	2dc9      	cmp	r5, #201	@ 0xc9
20023380:	d001      	beq.n	20023386 <nand_clear_status+0x14>
20023382:	2d01      	cmp	r5, #1
20023384:	d109      	bne.n	2002339a <nand_clear_status+0x28>
20023386:	2102      	movs	r1, #2
20023388:	4620      	mov	r0, r4
2002338a:	f7ff f8fc 	bl	20022586 <HAL_FLASH_WRITE_WORD>
2002338e:	68e3      	ldr	r3, [r4, #12]
20023390:	2103      	movs	r1, #3
20023392:	4620      	mov	r0, r4
20023394:	795a      	ldrb	r2, [r3, #5]
20023396:	f7ff fb42 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
2002339a:	2100      	movs	r1, #0
2002339c:	4620      	mov	r0, r4
2002339e:	f7ff f8f2 	bl	20022586 <HAL_FLASH_WRITE_WORD>
200233a2:	68e3      	ldr	r3, [r4, #12]
200233a4:	2103      	movs	r1, #3
200233a6:	4620      	mov	r0, r4
200233a8:	795a      	ldrb	r2, [r3, #5]
200233aa:	f7ff fb38 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
200233ae:	2000      	movs	r0, #0
200233b0:	bd38      	pop	{r3, r4, r5, pc}

200233b2 <HAL_NAND_PAGE_SIZE>:
200233b2:	b140      	cbz	r0, 200233c6 <HAL_NAND_PAGE_SIZE+0x14>
200233b4:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
200233b8:	f013 0f01 	tst.w	r3, #1
200233bc:	bf14      	ite	ne
200233be:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
200233c2:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
200233c6:	4770      	bx	lr

200233c8 <HAL_NAND_READ_WITHOOB>:
200233c8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200233cc:	b085      	sub	sp, #20
200233ce:	460e      	mov	r6, r1
200233d0:	4691      	mov	r9, r2
200233d2:	461d      	mov	r5, r3
200233d4:	4604      	mov	r4, r0
200233d6:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
200233d8:	b1b0      	cbz	r0, 20023408 <HAL_NAND_READ_WITHOOB+0x40>
200233da:	68c3      	ldr	r3, [r0, #12]
200233dc:	b1a3      	cbz	r3, 20023408 <HAL_NAND_READ_WITHOOB+0x40>
200233de:	69c3      	ldr	r3, [r0, #28]
200233e0:	b193      	cbz	r3, 20023408 <HAL_NAND_READ_WITHOOB+0x40>
200233e2:	2f80      	cmp	r7, #128	@ 0x80
200233e4:	d810      	bhi.n	20023408 <HAL_NAND_READ_WITHOOB+0x40>
200233e6:	f7ff ffe4 	bl	200233b2 <HAL_NAND_PAGE_SIZE>
200233ea:	f100 3aff 	add.w	sl, r0, #4294967295
200233ee:	ea0a 0a01 	and.w	sl, sl, r1
200233f2:	eb0a 0305 	add.w	r3, sl, r5
200233f6:	4283      	cmp	r3, r0
200233f8:	4680      	mov	r8, r0
200233fa:	d907      	bls.n	2002340c <HAL_NAND_READ_WITHOOB+0x44>
200233fc:	2002      	movs	r0, #2
200233fe:	6060      	str	r0, [r4, #4]
20023400:	2000      	movs	r0, #0
20023402:	b005      	add	sp, #20
20023404:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20023408:	2001      	movs	r0, #1
2002340a:	e7f8      	b.n	200233fe <HAL_NAND_READ_WITHOOB+0x36>
2002340c:	2300      	movs	r3, #0
2002340e:	6063      	str	r3, [r4, #4]
20023410:	6923      	ldr	r3, [r4, #16]
20023412:	f04f 0b00 	mov.w	fp, #0
20023416:	428b      	cmp	r3, r1
20023418:	bf98      	it	ls
2002341a:	1ace      	subls	r6, r1, r3
2002341c:	fbb6 f2f0 	udiv	r2, r6, r0
20023420:	2104      	movs	r1, #4
20023422:	4620      	mov	r0, r4
20023424:	f7ff fafb 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023428:	2014      	movs	r0, #20
2002342a:	f7fe fa8b 	bl	20021944 <HAL_Delay_us_>
2002342e:	2101      	movs	r1, #1
20023430:	4620      	mov	r0, r4
20023432:	f7ff f8af 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023436:	2005      	movs	r0, #5
20023438:	f7fe fa84 	bl	20021944 <HAL_Delay_us_>
2002343c:	68e2      	ldr	r2, [r4, #12]
2002343e:	2102      	movs	r1, #2
20023440:	7912      	ldrb	r2, [r2, #4]
20023442:	4620      	mov	r0, r4
20023444:	f7ff faeb 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023448:	4620      	mov	r0, r4
2002344a:	f7ff f8f9 	bl	20022640 <HAL_FLASH_READ32>
2002344e:	07c1      	lsls	r1, r0, #31
20023450:	d4f1      	bmi.n	20023436 <HAL_NAND_READ_WITHOOB+0x6e>
20023452:	f1bb 0f00 	cmp.w	fp, #0
20023456:	d102      	bne.n	2002345e <HAL_NAND_READ_WITHOOB+0x96>
20023458:	f04f 0b01 	mov.w	fp, #1
2002345c:	e7eb      	b.n	20023436 <HAL_NAND_READ_WITHOOB+0x6e>
2002345e:	4620      	mov	r0, r4
20023460:	f7ff ff2a 	bl	200232b8 <HAL_NAND_GET_ECC_RESULT>
20023464:	b110      	cbz	r0, 2002346c <HAL_NAND_READ_WITHOOB+0xa4>
20023466:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
2002346a:	e7c8      	b.n	200233fe <HAL_NAND_READ_WITHOOB+0x36>
2002346c:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
20023470:	68e3      	ldr	r3, [r4, #12]
20023472:	bbb2      	cbnz	r2, 200234e2 <HAL_NAND_READ_WITHOOB+0x11a>
20023474:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023478:	4620      	mov	r0, r4
2002347a:	f7ff f833 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
2002347e:	68e0      	ldr	r0, [r4, #12]
20023480:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
20023484:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023488:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
2002348c:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
20023490:	f8cd c00c 	str.w	ip, [sp, #12]
20023494:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023498:	f8cd c008 	str.w	ip, [sp, #8]
2002349c:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
200234a0:	f8cd c004 	str.w	ip, [sp, #4]
200234a4:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
200234a8:	9000      	str	r0, [sp, #0]
200234aa:	4620      	mov	r0, r4
200234ac:	f7ff f825 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
200234b0:	03b2      	lsls	r2, r6, #14
200234b2:	f8d4 b010 	ldr.w	fp, [r4, #16]
200234b6:	d504      	bpl.n	200234c2 <HAL_NAND_READ_WITHOOB+0xfa>
200234b8:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
200234bc:	b10a      	cbz	r2, 200234c2 <HAL_NAND_READ_WITHOOB+0xfa>
200234be:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
200234c2:	ea49 0205 	orr.w	r2, r9, r5
200234c6:	ea42 020a 	orr.w	r2, r2, sl
200234ca:	0793      	lsls	r3, r2, #30
200234cc:	d102      	bne.n	200234d4 <HAL_NAND_READ_WITHOOB+0x10c>
200234ce:	1e6a      	subs	r2, r5, #1
200234d0:	2afe      	cmp	r2, #254	@ 0xfe
200234d2:	d821      	bhi.n	20023518 <HAL_NAND_READ_WITHOOB+0x150>
200234d4:	462a      	mov	r2, r5
200234d6:	4648      	mov	r0, r9
200234d8:	eb0b 010a 	add.w	r1, fp, sl
200234dc:	f002 ff5d 	bl	2002639a <memcpy>
200234e0:	e01d      	b.n	2002351e <HAL_NAND_READ_WITHOOB+0x156>
200234e2:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
200234e6:	4620      	mov	r0, r4
200234e8:	f7fe fffc 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
200234ec:	68e0      	ldr	r0, [r4, #12]
200234ee:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
200234f2:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
200234f6:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
200234fa:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
200234fe:	f8cd c00c 	str.w	ip, [sp, #12]
20023502:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
20023506:	f8cd c008 	str.w	ip, [sp, #8]
2002350a:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
2002350e:	f8cd c004 	str.w	ip, [sp, #4]
20023512:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
20023516:	e7c7      	b.n	200234a8 <HAL_NAND_READ_WITHOOB+0xe0>
20023518:	f1b9 0f00 	cmp.w	r9, #0
2002351c:	d1da      	bne.n	200234d4 <HAL_NAND_READ_WITHOOB+0x10c>
2002351e:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
20023520:	b12b      	cbz	r3, 2002352e <HAL_NAND_READ_WITHOOB+0x166>
20023522:	463a      	mov	r2, r7
20023524:	4618      	mov	r0, r3
20023526:	eb0b 0108 	add.w	r1, fp, r8
2002352a:	f002 ff36 	bl	2002639a <memcpy>
2002352e:	1978      	adds	r0, r7, r5
20023530:	e767      	b.n	20023402 <HAL_NAND_READ_WITHOOB+0x3a>

20023532 <HAL_NAND_BLOCK_SIZE>:
20023532:	b508      	push	{r3, lr}
20023534:	4602      	mov	r2, r0
20023536:	f7ff ff3c 	bl	200233b2 <HAL_NAND_PAGE_SIZE>
2002353a:	b128      	cbz	r0, 20023548 <HAL_NAND_BLOCK_SIZE+0x16>
2002353c:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20023540:	079b      	lsls	r3, r3, #30
20023542:	bf4c      	ite	mi
20023544:	01c0      	lslmi	r0, r0, #7
20023546:	0180      	lslpl	r0, r0, #6
20023548:	bd08      	pop	{r3, pc}

2002354a <HAL_NAND_GET_BADBLK>:
2002354a:	b51f      	push	{r0, r1, r2, r3, r4, lr}
2002354c:	4604      	mov	r4, r0
2002354e:	b910      	cbnz	r0, 20023556 <HAL_NAND_GET_BADBLK+0xc>
20023550:	2000      	movs	r0, #0
20023552:	b004      	add	sp, #16
20023554:	bd10      	pop	{r4, pc}
20023556:	6a03      	ldr	r3, [r0, #32]
20023558:	2b00      	cmp	r3, #0
2002355a:	d0f9      	beq.n	20023550 <HAL_NAND_GET_BADBLK+0x6>
2002355c:	f7ff ffe9 	bl	20023532 <HAL_NAND_BLOCK_SIZE>
20023560:	2304      	movs	r3, #4
20023562:	9301      	str	r3, [sp, #4]
20023564:	ab03      	add	r3, sp, #12
20023566:	9300      	str	r3, [sp, #0]
20023568:	2300      	movs	r3, #0
2002356a:	4341      	muls	r1, r0
2002356c:	461a      	mov	r2, r3
2002356e:	4620      	mov	r0, r4
20023570:	f7ff ff2a 	bl	200233c8 <HAL_NAND_READ_WITHOOB>
20023574:	b140      	cbz	r0, 20023588 <HAL_NAND_GET_BADBLK+0x3e>
20023576:	f89d 300c 	ldrb.w	r3, [sp, #12]
2002357a:	2bff      	cmp	r3, #255	@ 0xff
2002357c:	d0e8      	beq.n	20023550 <HAL_NAND_GET_BADBLK+0x6>
2002357e:	9803      	ldr	r0, [sp, #12]
20023580:	2800      	cmp	r0, #0
20023582:	bf08      	it	eq
20023584:	2001      	moveq	r0, #1
20023586:	e7e4      	b.n	20023552 <HAL_NAND_GET_BADBLK+0x8>
20023588:	2001      	movs	r0, #1
2002358a:	e7e2      	b.n	20023552 <HAL_NAND_GET_BADBLK+0x8>

2002358c <HAL_QSPIEX_WRITE_PAGE>:
2002358c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023590:	b099      	sub	sp, #100	@ 0x64
20023592:	4604      	mov	r4, r0
20023594:	460e      	mov	r6, r1
20023596:	4691      	mov	r9, r2
20023598:	f7ff fd20 	bl	20022fdc <flash_handle_valid>
2002359c:	b318      	cbz	r0, 200235e6 <HAL_QSPIEX_WRITE_PAGE+0x5a>
2002359e:	2b00      	cmp	r3, #0
200235a0:	f000 80d7 	beq.w	20023752 <HAL_QSPIEX_WRITE_PAGE+0x1c6>
200235a4:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
200235a8:	bf28      	it	cs
200235aa:	f44f 7380 	movcs.w	r3, #256	@ 0x100
200235ae:	68a1      	ldr	r1, [r4, #8]
200235b0:	461d      	mov	r5, r3
200235b2:	6962      	ldr	r2, [r4, #20]
200235b4:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200235b8:	2900      	cmp	r1, #0
200235ba:	d03b      	beq.n	20023634 <HAL_QSPIEX_WRITE_PAGE+0xa8>
200235bc:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
200235c0:	d914      	bls.n	200235ec <HAL_QSPIEX_WRITE_PAGE+0x60>
200235c2:	2b02      	cmp	r3, #2
200235c4:	bf14      	ite	ne
200235c6:	2727      	movne	r7, #39	@ 0x27
200235c8:	2728      	moveq	r7, #40	@ 0x28
200235ca:	4639      	mov	r1, r7
200235cc:	4620      	mov	r0, r4
200235ce:	f7ff f9ff 	bl	200229d0 <HAL_FLASH_PRE_CMD>
200235d2:	4649      	mov	r1, r9
200235d4:	462b      	mov	r3, r5
200235d6:	2201      	movs	r2, #1
200235d8:	4620      	mov	r0, r4
200235da:	f7ff fd07 	bl	20022fec <HAL_FLASH_DMA_START>
200235de:	4601      	mov	r1, r0
200235e0:	b148      	cbz	r0, 200235f6 <HAL_QSPIEX_WRITE_PAGE+0x6a>
200235e2:	2500      	movs	r5, #0
200235e4:	4628      	mov	r0, r5
200235e6:	b019      	add	sp, #100	@ 0x64
200235e8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200235ec:	2b02      	cmp	r3, #2
200235ee:	bf14      	ite	ne
200235f0:	2716      	movne	r7, #22
200235f2:	2717      	moveq	r7, #23
200235f4:	e7e9      	b.n	200235ca <HAL_QSPIEX_WRITE_PAGE+0x3e>
200235f6:	4632      	mov	r2, r6
200235f8:	4620      	mov	r0, r4
200235fa:	f7ff fa10 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
200235fe:	2101      	movs	r1, #1
20023600:	4620      	mov	r0, r4
20023602:	f7fe ffd1 	bl	200225a8 <HAL_FLASH_WRITE_DLEN2>
20023606:	2301      	movs	r3, #1
20023608:	4632      	mov	r2, r6
2002360a:	9300      	str	r3, [sp, #0]
2002360c:	4639      	mov	r1, r7
2002360e:	2302      	movs	r3, #2
20023610:	4620      	mov	r0, r4
20023612:	f7ff fa37 	bl	20022a84 <HAL_FLASH_ISSUE_CMD_SEQ>
20023616:	2800      	cmp	r0, #0
20023618:	d1e3      	bne.n	200235e2 <HAL_QSPIEX_WRITE_PAGE+0x56>
2002361a:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
2002361e:	4620      	mov	r0, r4
20023620:	f7ff fd34 	bl	2002308c <HAL_FLASH_DMA_WAIT_DONE>
20023624:	2800      	cmp	r0, #0
20023626:	d1dc      	bne.n	200235e2 <HAL_QSPIEX_WRITE_PAGE+0x56>
20023628:	6822      	ldr	r2, [r4, #0]
2002362a:	6813      	ldr	r3, [r2, #0]
2002362c:	f023 0320 	bic.w	r3, r3, #32
20023630:	6013      	str	r3, [r2, #0]
20023632:	e7d7      	b.n	200235e4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023634:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023638:	f240 8082 	bls.w	20023740 <HAL_QSPIEX_WRITE_PAGE+0x1b4>
2002363c:	2b02      	cmp	r3, #2
2002363e:	bf14      	ite	ne
20023640:	2327      	movne	r3, #39	@ 0x27
20023642:	2328      	moveq	r3, #40	@ 0x28
20023644:	462f      	mov	r7, r5
20023646:	f04f 0800 	mov.w	r8, #0
2002364a:	9303      	str	r3, [sp, #12]
2002364c:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
20023650:	2f40      	cmp	r7, #64	@ 0x40
20023652:	bfd4      	ite	le
20023654:	ea0a 0a07 	andle.w	sl, sl, r7
20023658:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
2002365c:	f1ba 0f00 	cmp.w	sl, #0
20023660:	d03f      	beq.n	200236e2 <HAL_QSPIEX_WRITE_PAGE+0x156>
20023662:	2200      	movs	r2, #0
20023664:	4620      	mov	r0, r4
20023666:	4611      	mov	r1, r2
20023668:	f7ff f9d9 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
2002366c:	eb09 0308 	add.w	r3, r9, r8
20023670:	f10d 0c20 	add.w	ip, sp, #32
20023674:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023678:	4662      	mov	r2, ip
2002367a:	6818      	ldr	r0, [r3, #0]
2002367c:	6859      	ldr	r1, [r3, #4]
2002367e:	3308      	adds	r3, #8
20023680:	c203      	stmia	r2!, {r0, r1}
20023682:	4573      	cmp	r3, lr
20023684:	4694      	mov	ip, r2
20023686:	d1f7      	bne.n	20023678 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023688:	f04f 0b00 	mov.w	fp, #0
2002368c:	ea4f 02aa 	mov.w	r2, sl, asr #2
20023690:	ab08      	add	r3, sp, #32
20023692:	f853 1b04 	ldr.w	r1, [r3], #4
20023696:	4620      	mov	r0, r4
20023698:	9205      	str	r2, [sp, #20]
2002369a:	9304      	str	r3, [sp, #16]
2002369c:	f7fe ff73 	bl	20022586 <HAL_FLASH_WRITE_WORD>
200236a0:	9a05      	ldr	r2, [sp, #20]
200236a2:	f10b 0b01 	add.w	fp, fp, #1
200236a6:	4593      	cmp	fp, r2
200236a8:	9b04      	ldr	r3, [sp, #16]
200236aa:	d1f2      	bne.n	20023692 <HAL_QSPIEX_WRITE_PAGE+0x106>
200236ac:	4651      	mov	r1, sl
200236ae:	4620      	mov	r0, r4
200236b0:	f7fe ff70 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
200236b4:	4620      	mov	r0, r4
200236b6:	9903      	ldr	r1, [sp, #12]
200236b8:	eb06 0208 	add.w	r2, r6, r8
200236bc:	f7ff f9af 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
200236c0:	2101      	movs	r1, #1
200236c2:	4620      	mov	r0, r4
200236c4:	f7fe ff66 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
200236c8:	2200      	movs	r2, #0
200236ca:	2102      	movs	r1, #2
200236cc:	4620      	mov	r0, r4
200236ce:	f7ff f9a6 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
200236d2:	4620      	mov	r0, r4
200236d4:	f7fe ffab 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
200236d8:	2800      	cmp	r0, #0
200236da:	d0f1      	beq.n	200236c0 <HAL_QSPIEX_WRITE_PAGE+0x134>
200236dc:	eba7 070a 	sub.w	r7, r7, sl
200236e0:	44d0      	add	r8, sl
200236e2:	1e7b      	subs	r3, r7, #1
200236e4:	2b02      	cmp	r3, #2
200236e6:	d830      	bhi.n	2002374a <HAL_QSPIEX_WRITE_PAGE+0x1be>
200236e8:	6923      	ldr	r3, [r4, #16]
200236ea:	4446      	add	r6, r8
200236ec:	4333      	orrs	r3, r6
200236ee:	681b      	ldr	r3, [r3, #0]
200236f0:	463a      	mov	r2, r7
200236f2:	eb09 0108 	add.w	r1, r9, r8
200236f6:	a807      	add	r0, sp, #28
200236f8:	9307      	str	r3, [sp, #28]
200236fa:	f002 fe4e 	bl	2002639a <memcpy>
200236fe:	2200      	movs	r2, #0
20023700:	4620      	mov	r0, r4
20023702:	4611      	mov	r1, r2
20023704:	f7ff f98b 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023708:	9907      	ldr	r1, [sp, #28]
2002370a:	4620      	mov	r0, r4
2002370c:	f7fe ff3b 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20023710:	2104      	movs	r1, #4
20023712:	4620      	mov	r0, r4
20023714:	f7fe ff3e 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023718:	4632      	mov	r2, r6
2002371a:	4620      	mov	r0, r4
2002371c:	9903      	ldr	r1, [sp, #12]
2002371e:	f7ff f97e 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023722:	2101      	movs	r1, #1
20023724:	4620      	mov	r0, r4
20023726:	f7fe ff35 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
2002372a:	2200      	movs	r2, #0
2002372c:	2102      	movs	r1, #2
2002372e:	4620      	mov	r0, r4
20023730:	f7ff f975 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023734:	4620      	mov	r0, r4
20023736:	f7fe ff7a 	bl	2002262e <HAL_FLASH_IS_PROG_DONE>
2002373a:	2800      	cmp	r0, #0
2002373c:	d0f1      	beq.n	20023722 <HAL_QSPIEX_WRITE_PAGE+0x196>
2002373e:	e751      	b.n	200235e4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023740:	2b02      	cmp	r3, #2
20023742:	bf14      	ite	ne
20023744:	2316      	movne	r3, #22
20023746:	2317      	moveq	r3, #23
20023748:	e77c      	b.n	20023644 <HAL_QSPIEX_WRITE_PAGE+0xb8>
2002374a:	2f00      	cmp	r7, #0
2002374c:	f73f af7e 	bgt.w	2002364c <HAL_QSPIEX_WRITE_PAGE+0xc0>
20023750:	e748      	b.n	200235e4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023752:	4618      	mov	r0, r3
20023754:	e747      	b.n	200235e6 <HAL_QSPIEX_WRITE_PAGE+0x5a>

20023756 <HAL_QSPIEX_SECT_ERASE>:
20023756:	b573      	push	{r0, r1, r4, r5, r6, lr}
20023758:	4604      	mov	r4, r0
2002375a:	460d      	mov	r5, r1
2002375c:	f7ff fc3e 	bl	20022fdc <flash_handle_valid>
20023760:	b1e8      	cbz	r0, 2002379e <HAL_QSPIEX_SECT_ERASE+0x48>
20023762:	6963      	ldr	r3, [r4, #20]
20023764:	460a      	mov	r2, r1
20023766:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
2002376a:	f04f 0100 	mov.w	r1, #0
2002376e:	4620      	mov	r0, r4
20023770:	bf94      	ite	ls
20023772:	261b      	movls	r6, #27
20023774:	2629      	movhi	r6, #41	@ 0x29
20023776:	f7ff f952 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
2002377a:	2101      	movs	r1, #1
2002377c:	4620      	mov	r0, r4
2002377e:	f7fe ff13 	bl	200225a8 <HAL_FLASH_WRITE_DLEN2>
20023782:	2301      	movs	r3, #1
20023784:	462a      	mov	r2, r5
20023786:	9300      	str	r3, [sp, #0]
20023788:	4631      	mov	r1, r6
2002378a:	2302      	movs	r3, #2
2002378c:	4620      	mov	r0, r4
2002378e:	f7ff f979 	bl	20022a84 <HAL_FLASH_ISSUE_CMD_SEQ>
20023792:	3800      	subs	r0, #0
20023794:	bf18      	it	ne
20023796:	2001      	movne	r0, #1
20023798:	4240      	negs	r0, r0
2002379a:	b002      	add	sp, #8
2002379c:	bd70      	pop	{r4, r5, r6, pc}
2002379e:	f04f 30ff 	mov.w	r0, #4294967295
200237a2:	e7fa      	b.n	2002379a <HAL_QSPIEX_SECT_ERASE+0x44>

200237a4 <HAL_QSPI_GET_SRC_CLK>:
200237a4:	b508      	push	{r3, lr}
200237a6:	b318      	cbz	r0, 200237f0 <HAL_QSPI_GET_SRC_CLK+0x4c>
200237a8:	6803      	ldr	r3, [r0, #0]
200237aa:	4a12      	ldr	r2, [pc, #72]	@ (200237f4 <HAL_QSPI_GET_SRC_CLK+0x50>)
200237ac:	4293      	cmp	r3, r2
200237ae:	d010      	beq.n	200237d2 <HAL_QSPI_GET_SRC_CLK+0x2e>
200237b0:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
200237b4:	4293      	cmp	r3, r2
200237b6:	d00e      	beq.n	200237d6 <HAL_QSPI_GET_SRC_CLK+0x32>
200237b8:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
200237bc:	4293      	cmp	r3, r2
200237be:	d117      	bne.n	200237f0 <HAL_QSPI_GET_SRC_CLK+0x4c>
200237c0:	2008      	movs	r0, #8
200237c2:	f000 ff61 	bl	20024688 <HAL_RCC_HCPU_GetClockSrc>
200237c6:	2802      	cmp	r0, #2
200237c8:	d107      	bne.n	200237da <HAL_QSPI_GET_SRC_CLK+0x36>
200237ca:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200237ce:	f000 bf9f 	b.w	20024710 <HAL_RCC_HCPU_GetDLL2Freq>
200237d2:	2004      	movs	r0, #4
200237d4:	e7f5      	b.n	200237c2 <HAL_QSPI_GET_SRC_CLK+0x1e>
200237d6:	2006      	movs	r0, #6
200237d8:	e7f3      	b.n	200237c2 <HAL_QSPI_GET_SRC_CLK+0x1e>
200237da:	2803      	cmp	r0, #3
200237dc:	d103      	bne.n	200237e6 <HAL_QSPI_GET_SRC_CLK+0x42>
200237de:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200237e2:	f000 bf98 	b.w	20024716 <HAL_RCC_HCPU_GetDLL3Freq>
200237e6:	2001      	movs	r0, #1
200237e8:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200237ec:	f000 bfee 	b.w	200247cc <HAL_RCC_GetSysCLKFreq>
200237f0:	2000      	movs	r0, #0
200237f2:	bd08      	pop	{r3, pc}
200237f4:	50041000 	.word	0x50041000

200237f8 <HAL_QSPI_GET_CLK>:
200237f8:	b538      	push	{r3, r4, r5, lr}
200237fa:	4605      	mov	r5, r0
200237fc:	b908      	cbnz	r0, 20023802 <HAL_QSPI_GET_CLK+0xa>
200237fe:	2000      	movs	r0, #0
20023800:	bd38      	pop	{r3, r4, r5, pc}
20023802:	f7fe ff2c 	bl	2002265e <HAL_FLASH_GET_DIV>
20023806:	4604      	mov	r4, r0
20023808:	2800      	cmp	r0, #0
2002380a:	d0f8      	beq.n	200237fe <HAL_QSPI_GET_CLK+0x6>
2002380c:	4628      	mov	r0, r5
2002380e:	f7ff ffc9 	bl	200237a4 <HAL_QSPI_GET_SRC_CLK>
20023812:	fbb0 f0f4 	udiv	r0, r0, r4
20023816:	e7f3      	b.n	20023800 <HAL_QSPI_GET_CLK+0x8>

20023818 <HAL_QSPI_READ_ID>:
20023818:	b138      	cbz	r0, 2002382a <HAL_QSPI_READ_ID+0x12>
2002381a:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
2002381e:	b113      	cbz	r3, 20023826 <HAL_QSPI_READ_ID+0xe>
20023820:	2100      	movs	r1, #0
20023822:	f7ff bc59 	b.w	200230d8 <nand_read_id>
20023826:	f7ff ba50 	b.w	20022cca <HAL_FLASH_GET_NOR_ID>
2002382a:	20ff      	movs	r0, #255	@ 0xff
2002382c:	4770      	bx	lr

2002382e <HAL_NOR_CFG_DTR>:
2002382e:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20023830:	4604      	mov	r4, r0
20023832:	460a      	mov	r2, r1
20023834:	b351      	cbz	r1, 2002388c <HAL_NOR_CFG_DTR+0x5e>
20023836:	68c5      	ldr	r5, [r0, #12]
20023838:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
2002383c:	2b00      	cmp	r3, #0
2002383e:	d03b      	beq.n	200238b8 <HAL_NOR_CFG_DTR+0x8a>
20023840:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
20023844:	b3c3      	cbz	r3, 200238b8 <HAL_NOR_CFG_DTR+0x8a>
20023846:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
2002384a:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
2002384e:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
20023852:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
20023856:	9603      	str	r6, [sp, #12]
20023858:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
2002385c:	9602      	str	r6, [sp, #8]
2002385e:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
20023862:	9601      	str	r6, [sp, #4]
20023864:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
20023868:	9500      	str	r5, [sp, #0]
2002386a:	f7fe fe46 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
2002386e:	68e3      	ldr	r3, [r4, #12]
20023870:	4620      	mov	r0, r4
20023872:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
20023876:	f7fe fe35 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
2002387a:	2101      	movs	r1, #1
2002387c:	4620      	mov	r0, r4
2002387e:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
20023882:	f7fe fffa 	bl	2002287a <HAL_MPI_CFG_DTR>
20023886:	2000      	movs	r0, #0
20023888:	b004      	add	sp, #16
2002388a:	bd70      	pop	{r4, r5, r6, pc}
2002388c:	f7fe fff5 	bl	2002287a <HAL_MPI_CFG_DTR>
20023890:	6963      	ldr	r3, [r4, #20]
20023892:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20023896:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
2002389a:	d906      	bls.n	200238aa <HAL_NOR_CFG_DTR+0x7c>
2002389c:	b919      	cbnz	r1, 200238a6 <HAL_NOR_CFG_DTR+0x78>
2002389e:	4620      	mov	r0, r4
200238a0:	f7ff f859 	bl	20022956 <HAL_FLASH_CONFIG_FULL_AHB_READ>
200238a4:	e7ef      	b.n	20023886 <HAL_NOR_CFG_DTR+0x58>
200238a6:	2101      	movs	r1, #1
200238a8:	e7f9      	b.n	2002389e <HAL_NOR_CFG_DTR+0x70>
200238aa:	b919      	cbnz	r1, 200238b4 <HAL_NOR_CFG_DTR+0x86>
200238ac:	4620      	mov	r0, r4
200238ae:	f7ff f80e 	bl	200228ce <HAL_FLASH_CONFIG_AHB_READ>
200238b2:	e7e8      	b.n	20023886 <HAL_NOR_CFG_DTR+0x58>
200238b4:	2101      	movs	r1, #1
200238b6:	e7f9      	b.n	200238ac <HAL_NOR_CFG_DTR+0x7e>
200238b8:	2001      	movs	r0, #1
200238ba:	e7e5      	b.n	20023888 <HAL_NOR_CFG_DTR+0x5a>

200238bc <HAL_FLASH_Init>:
200238bc:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200238c0:	460e      	mov	r6, r1
200238c2:	4690      	mov	r8, r2
200238c4:	461f      	mov	r7, r3
200238c6:	4604      	mov	r4, r0
200238c8:	b087      	sub	sp, #28
200238ca:	2800      	cmp	r0, #0
200238cc:	f000 80e5 	beq.w	20023a9a <HAL_FLASH_Init+0x1de>
200238d0:	2900      	cmp	r1, #0
200238d2:	f000 80e2 	beq.w	20023a9a <HAL_FLASH_Init+0x1de>
200238d6:	f7fe fde3 	bl	200224a0 <HAL_QSPI_Init>
200238da:	6820      	ldr	r0, [r4, #0]
200238dc:	f7ff fb84 	bl	20022fe8 <HAL_GET_FLASH_MID>
200238e0:	6933      	ldr	r3, [r6, #16]
200238e2:	2100      	movs	r1, #0
200238e4:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
200238e8:	68b3      	ldr	r3, [r6, #8]
200238ea:	4605      	mov	r5, r0
200238ec:	64a3      	str	r3, [r4, #72]	@ 0x48
200238ee:	68f3      	ldr	r3, [r6, #12]
200238f0:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
200238f4:	051b      	lsls	r3, r3, #20
200238f6:	64e3      	str	r3, [r4, #76]	@ 0x4c
200238f8:	2302      	movs	r3, #2
200238fa:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
200238fe:	6933      	ldr	r3, [r6, #16]
20023900:	f8c4 8008 	str.w	r8, [r4, #8]
20023904:	1e5a      	subs	r2, r3, #1
20023906:	4253      	negs	r3, r2
20023908:	4153      	adcs	r3, r2
2002390a:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
2002390e:	f1b8 0f00 	cmp.w	r8, #0
20023912:	d058      	beq.n	200239c6 <HAL_FLASH_Init+0x10a>
20023914:	2f00      	cmp	r7, #0
20023916:	d056      	beq.n	200239c6 <HAL_FLASH_Init+0x10a>
20023918:	683b      	ldr	r3, [r7, #0]
2002391a:	f8c8 3000 	str.w	r3, [r8]
2002391e:	68a3      	ldr	r3, [r4, #8]
20023920:	68fa      	ldr	r2, [r7, #12]
20023922:	605a      	str	r2, [r3, #4]
20023924:	2210      	movs	r2, #16
20023926:	68a3      	ldr	r3, [r4, #8]
20023928:	609a      	str	r2, [r3, #8]
2002392a:	2280      	movs	r2, #128	@ 0x80
2002392c:	68a3      	ldr	r3, [r4, #8]
2002392e:	60d9      	str	r1, [r3, #12]
20023930:	68a3      	ldr	r3, [r4, #8]
20023932:	611a      	str	r2, [r3, #16]
20023934:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20023938:	68a3      	ldr	r3, [r4, #8]
2002393a:	6159      	str	r1, [r3, #20]
2002393c:	68a3      	ldr	r3, [r4, #8]
2002393e:	6199      	str	r1, [r3, #24]
20023940:	68a3      	ldr	r3, [r4, #8]
20023942:	61d9      	str	r1, [r3, #28]
20023944:	68a3      	ldr	r3, [r4, #8]
20023946:	621a      	str	r2, [r3, #32]
20023948:	68a3      	ldr	r3, [r4, #8]
2002394a:	6259      	str	r1, [r3, #36]	@ 0x24
2002394c:	b1c0      	cbz	r0, 20023980 <HAL_FLASH_Init+0xc4>
2002394e:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
20023952:	4298      	cmp	r0, r3
20023954:	d014      	beq.n	20023980 <HAL_FLASH_Init+0xc4>
20023956:	2701      	movs	r7, #1
20023958:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
2002395c:	2b00      	cmp	r3, #0
2002395e:	d13d      	bne.n	200239dc <HAL_FLASH_Init+0x120>
20023960:	2f00      	cmp	r7, #0
20023962:	d15a      	bne.n	20023a1a <HAL_FLASH_Init+0x15e>
20023964:	4620      	mov	r0, r4
20023966:	f7ff fb19 	bl	20022f9c <HAL_FLASH_RELEASE_DPD>
2002396a:	4638      	mov	r0, r7
2002396c:	f7fe f841 	bl	200219f2 <HAL_Delay_us>
20023970:	2032      	movs	r0, #50	@ 0x32
20023972:	f7fe f83e 	bl	200219f2 <HAL_Delay_us>
20023976:	4620      	mov	r0, r4
20023978:	f7ff ff4e 	bl	20023818 <HAL_QSPI_READ_ID>
2002397c:	4605      	mov	r5, r0
2002397e:	e04c      	b.n	20023a1a <HAL_FLASH_Init+0x15e>
20023980:	2101      	movs	r1, #1
20023982:	4620      	mov	r0, r4
20023984:	f7fe fe60 	bl	20022648 <HAL_FLASH_SET_TXSLOT>
20023988:	4baf      	ldr	r3, [pc, #700]	@ (20023c48 <HAL_FLASH_Init+0x38c>)
2002398a:	69a2      	ldr	r2, [r4, #24]
2002398c:	4620      	mov	r0, r4
2002398e:	429a      	cmp	r2, r3
20023990:	f04f 0200 	mov.w	r2, #0
20023994:	bf8c      	ite	hi
20023996:	2101      	movhi	r1, #1
20023998:	4611      	movls	r1, r2
2002399a:	f7ff faab 	bl	20022ef4 <HAL_QSPI_SET_CLK_INV>
2002399e:	4620      	mov	r0, r4
200239a0:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
200239a4:	f7fe fe57 	bl	20022656 <HAL_FLASH_SET_CLK_rom>
200239a8:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
200239ac:	b12b      	cbz	r3, 200239ba <HAL_FLASH_Init+0xfe>
200239ae:	2b01      	cmp	r3, #1
200239b0:	d110      	bne.n	200239d4 <HAL_FLASH_Init+0x118>
200239b2:	2100      	movs	r1, #0
200239b4:	4620      	mov	r0, r4
200239b6:	f7fe ff25 	bl	20022804 <HAL_FLASH_SET_DUAL_MODE>
200239ba:	2101      	movs	r1, #1
200239bc:	4620      	mov	r0, r4
200239be:	f7fe feb0 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
200239c2:	2700      	movs	r7, #0
200239c4:	e7c8      	b.n	20023958 <HAL_FLASH_Init+0x9c>
200239c6:	2d00      	cmp	r5, #0
200239c8:	d0de      	beq.n	20023988 <HAL_FLASH_Init+0xcc>
200239ca:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200239ce:	429d      	cmp	r5, r3
200239d0:	d1c1      	bne.n	20023956 <HAL_FLASH_Init+0x9a>
200239d2:	e7d9      	b.n	20023988 <HAL_FLASH_Init+0xcc>
200239d4:	2b02      	cmp	r3, #2
200239d6:	d1f0      	bne.n	200239ba <HAL_FLASH_Init+0xfe>
200239d8:	2101      	movs	r1, #1
200239da:	e7eb      	b.n	200239b4 <HAL_FLASH_Init+0xf8>
200239dc:	6822      	ldr	r2, [r4, #0]
200239de:	2600      	movs	r6, #0
200239e0:	6893      	ldr	r3, [r2, #8]
200239e2:	4631      	mov	r1, r6
200239e4:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
200239e8:	6093      	str	r3, [r2, #8]
200239ea:	2301      	movs	r3, #1
200239ec:	4632      	mov	r2, r6
200239ee:	4620      	mov	r0, r4
200239f0:	e9cd 6303 	strd	r6, r3, [sp, #12]
200239f4:	e9cd 6601 	strd	r6, r6, [sp, #4]
200239f8:	4633      	mov	r3, r6
200239fa:	9600      	str	r6, [sp, #0]
200239fc:	f7fe fe34 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20023a00:	4632      	mov	r2, r6
20023a02:	21ff      	movs	r1, #255	@ 0xff
20023a04:	4620      	mov	r0, r4
20023a06:	f7fe fdea 	bl	200225de <HAL_FLASH_SET_CMD>
20023a0a:	4630      	mov	r0, r6
20023a0c:	f7fd fff1 	bl	200219f2 <HAL_Delay_us>
20023a10:	20c8      	movs	r0, #200	@ 0xc8
20023a12:	f7fd ffee 	bl	200219f2 <HAL_Delay_us>
20023a16:	2f00      	cmp	r7, #0
20023a18:	d0ad      	beq.n	20023976 <HAL_FLASH_Init+0xba>
20023a1a:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023a1e:	b2ee      	uxtb	r6, r5
20023a20:	f3c5 2807 	ubfx	r8, r5, #8, #8
20023a24:	6425      	str	r5, [r4, #64]	@ 0x40
20023a26:	f3c5 4507 	ubfx	r5, r5, #16, #8
20023a2a:	4642      	mov	r2, r8
20023a2c:	4629      	mov	r1, r5
20023a2e:	4630      	mov	r0, r6
20023a30:	b3ab      	cbz	r3, 20023a9e <HAL_FLASH_Init+0x1e2>
20023a32:	f001 fa85 	bl	20024f40 <spi_nand_get_cmd_by_id>
20023a36:	60e0      	str	r0, [r4, #12]
20023a38:	bba0      	cbnz	r0, 20023aa4 <HAL_FLASH_Init+0x1e8>
20023a3a:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023a3e:	b32b      	cbz	r3, 20023a8c <HAL_FLASH_Init+0x1d0>
20023a40:	2108      	movs	r1, #8
20023a42:	4620      	mov	r0, r4
20023a44:	f7ff fb48 	bl	200230d8 <nand_read_id>
20023a48:	f3c0 2807 	ubfx	r8, r0, #8, #8
20023a4c:	f3c0 4507 	ubfx	r5, r0, #16, #8
20023a50:	b2c6      	uxtb	r6, r0
20023a52:	6420      	str	r0, [r4, #64]	@ 0x40
20023a54:	4642      	mov	r2, r8
20023a56:	4629      	mov	r1, r5
20023a58:	4630      	mov	r0, r6
20023a5a:	f001 fa71 	bl	20024f40 <spi_nand_get_cmd_by_id>
20023a5e:	60e0      	str	r0, [r4, #12]
20023a60:	bb00      	cbnz	r0, 20023aa4 <HAL_FLASH_Init+0x1e8>
20023a62:	210f      	movs	r1, #15
20023a64:	4620      	mov	r0, r4
20023a66:	f7ff fb37 	bl	200230d8 <nand_read_id>
20023a6a:	f3c0 2807 	ubfx	r8, r0, #8, #8
20023a6e:	f3c0 4507 	ubfx	r5, r0, #16, #8
20023a72:	b2c6      	uxtb	r6, r0
20023a74:	6420      	str	r0, [r4, #64]	@ 0x40
20023a76:	4642      	mov	r2, r8
20023a78:	4629      	mov	r1, r5
20023a7a:	4630      	mov	r0, r6
20023a7c:	f001 fa60 	bl	20024f40 <spi_nand_get_cmd_by_id>
20023a80:	60e0      	str	r0, [r4, #12]
20023a82:	b978      	cbnz	r0, 20023aa4 <HAL_FLASH_Init+0x1e8>
20023a84:	f001 fa74 	bl	20024f70 <spi_nand_get_default_ctable>
20023a88:	60e0      	str	r0, [r4, #12]
20023a8a:	b958      	cbnz	r0, 20023aa4 <HAL_FLASH_Init+0x1e8>
20023a8c:	2100      	movs	r1, #0
20023a8e:	4620      	mov	r0, r4
20023a90:	f7fe fe47 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20023a94:	2300      	movs	r3, #0
20023a96:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
20023a9a:	2001      	movs	r0, #1
20023a9c:	e052      	b.n	20023b44 <HAL_FLASH_Init+0x288>
20023a9e:	f001 f9f1 	bl	20024e84 <spi_flash_get_cmd_by_id>
20023aa2:	e7c8      	b.n	20023a36 <HAL_FLASH_Init+0x17a>
20023aa4:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023aa8:	4642      	mov	r2, r8
20023aaa:	4629      	mov	r1, r5
20023aac:	4630      	mov	r0, r6
20023aae:	2b00      	cmp	r3, #0
20023ab0:	d04b      	beq.n	20023b4a <HAL_FLASH_Init+0x28e>
20023ab2:	f001 fa6b 	bl	20024f8c <spi_nand_get_size_by_id>
20023ab6:	4642      	mov	r2, r8
20023ab8:	4629      	mov	r1, r5
20023aba:	4681      	mov	r9, r0
20023abc:	4630      	mov	r0, r6
20023abe:	f001 fa6f 	bl	20024fa0 <spi_nand_get_plane_select_flag>
20023ac2:	4642      	mov	r2, r8
20023ac4:	4629      	mov	r1, r5
20023ac6:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
20023aca:	4630      	mov	r0, r6
20023acc:	f001 fa71 	bl	20024fb2 <spi_nand_get_big_page_flag>
20023ad0:	4642      	mov	r2, r8
20023ad2:	4629      	mov	r1, r5
20023ad4:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
20023ad8:	4630      	mov	r0, r6
20023ada:	f001 fa73 	bl	20024fc4 <spi_nand_get_ecc_mode>
20023ade:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
20023ae2:	4642      	mov	r2, r8
20023ae4:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
20023ae8:	4629      	mov	r1, r5
20023aea:	4630      	mov	r0, r6
20023aec:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
20023af0:	f001 fa38 	bl	20024f64 <spi_nand_get_ext_cfg_by_id>
20023af4:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023af6:	f1b9 0f00 	cmp.w	r9, #0
20023afa:	d003      	beq.n	20023b04 <HAL_FLASH_Init+0x248>
20023afc:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
20023b00:	f8c4 9014 	str.w	r9, [r4, #20]
20023b04:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023b08:	2b00      	cmp	r3, #0
20023b0a:	d17d      	bne.n	20023c08 <HAL_FLASH_Init+0x34c>
20023b0c:	2f00      	cmp	r7, #0
20023b0e:	d178      	bne.n	20023c02 <HAL_FLASH_Init+0x346>
20023b10:	4620      	mov	r0, r4
20023b12:	f7ff f8f5 	bl	20022d00 <HAL_FLASH_CLR_PROTECT>
20023b16:	6963      	ldr	r3, [r4, #20]
20023b18:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023b1c:	d945      	bls.n	20023baa <HAL_FLASH_Init+0x2ee>
20023b1e:	463a      	mov	r2, r7
20023b20:	2121      	movs	r1, #33	@ 0x21
20023b22:	4620      	mov	r0, r4
20023b24:	f7fe ff7b 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023b28:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023b2c:	bb0b      	cbnz	r3, 20023b72 <HAL_FLASH_Init+0x2b6>
20023b2e:	4639      	mov	r1, r7
20023b30:	4620      	mov	r0, r4
20023b32:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023b36:	f7ff f8bd 	bl	20022cb4 <HAL_FLASH_FADDR_SET_QSPI>
20023b3a:	2107      	movs	r1, #7
20023b3c:	4620      	mov	r0, r4
20023b3e:	f7fe fe4a 	bl	200227d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20023b42:	2000      	movs	r0, #0
20023b44:	b007      	add	sp, #28
20023b46:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20023b4a:	f001 f9af 	bl	20024eac <spi_flash_get_size_by_id>
20023b4e:	4642      	mov	r2, r8
20023b50:	4629      	mov	r1, r5
20023b52:	4681      	mov	r9, r0
20023b54:	4630      	mov	r0, r6
20023b56:	f001 f9bd 	bl	20024ed4 <spi_flash_get_otp_base>
20023b5a:	4642      	mov	r2, r8
20023b5c:	63a0      	str	r0, [r4, #56]	@ 0x38
20023b5e:	4629      	mov	r1, r5
20023b60:	4630      	mov	r0, r6
20023b62:	f001 f967 	bl	20024e34 <spi_nor_get_ext_cfg_by_id>
20023b66:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023b68:	2800      	cmp	r0, #0
20023b6a:	d0c4      	beq.n	20023af6 <HAL_FLASH_Init+0x23a>
20023b6c:	6803      	ldr	r3, [r0, #0]
20023b6e:	63a3      	str	r3, [r4, #56]	@ 0x38
20023b70:	e7c1      	b.n	20023af6 <HAL_FLASH_Init+0x23a>
20023b72:	2101      	movs	r1, #1
20023b74:	4620      	mov	r0, r4
20023b76:	f7ff f89d 	bl	20022cb4 <HAL_FLASH_FADDR_SET_QSPI>
20023b7a:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
20023b7e:	f1b9 0f01 	cmp.w	r9, #1
20023b82:	d1da      	bne.n	20023b3a <HAL_FLASH_Init+0x27e>
20023b84:	4642      	mov	r2, r8
20023b86:	4629      	mov	r1, r5
20023b88:	4630      	mov	r0, r6
20023b8a:	f001 f999 	bl	20024ec0 <spi_flash_is_support_dtr>
20023b8e:	b120      	cbz	r0, 20023b9a <HAL_FLASH_Init+0x2de>
20023b90:	4649      	mov	r1, r9
20023b92:	4620      	mov	r0, r4
20023b94:	f7ff fe4b 	bl	2002382e <HAL_NOR_CFG_DTR>
20023b98:	e7cf      	b.n	20023b3a <HAL_FLASH_Init+0x27e>
20023b9a:	463a      	mov	r2, r7
20023b9c:	4639      	mov	r1, r7
20023b9e:	4620      	mov	r0, r4
20023ba0:	f7fe fe6b 	bl	2002287a <HAL_MPI_CFG_DTR>
20023ba4:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023ba8:	e7c7      	b.n	20023b3a <HAL_FLASH_Init+0x27e>
20023baa:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023bae:	b933      	cbnz	r3, 20023bbe <HAL_FLASH_Init+0x302>
20023bb0:	4639      	mov	r1, r7
20023bb2:	4620      	mov	r0, r4
20023bb4:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023bb8:	f7ff f871 	bl	20022c9e <HAL_FLASH_SET_QUAL_SPI>
20023bbc:	e7c1      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023bbe:	2101      	movs	r1, #1
20023bc0:	4620      	mov	r0, r4
20023bc2:	f7ff f86c 	bl	20022c9e <HAL_FLASH_SET_QUAL_SPI>
20023bc6:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
20023bca:	f1b9 0f01 	cmp.w	r9, #1
20023bce:	d112      	bne.n	20023bf6 <HAL_FLASH_Init+0x33a>
20023bd0:	4642      	mov	r2, r8
20023bd2:	4629      	mov	r1, r5
20023bd4:	4630      	mov	r0, r6
20023bd6:	f001 f973 	bl	20024ec0 <spi_flash_is_support_dtr>
20023bda:	b120      	cbz	r0, 20023be6 <HAL_FLASH_Init+0x32a>
20023bdc:	4649      	mov	r1, r9
20023bde:	4620      	mov	r0, r4
20023be0:	f7ff fe25 	bl	2002382e <HAL_NOR_CFG_DTR>
20023be4:	e7ad      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023be6:	463a      	mov	r2, r7
20023be8:	4639      	mov	r1, r7
20023bea:	4620      	mov	r0, r4
20023bec:	f7fe fe45 	bl	2002287a <HAL_MPI_CFG_DTR>
20023bf0:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023bf4:	e7a5      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023bf6:	463a      	mov	r2, r7
20023bf8:	4639      	mov	r1, r7
20023bfa:	4620      	mov	r0, r4
20023bfc:	f7fe fe3d 	bl	2002287a <HAL_MPI_CFG_DTR>
20023c00:	e79f      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023c02:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023c06:	e79c      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023c08:	2101      	movs	r1, #1
20023c0a:	4620      	mov	r0, r4
20023c0c:	f7fe fcc2 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023c10:	68e3      	ldr	r3, [r4, #12]
20023c12:	2102      	movs	r1, #2
20023c14:	791a      	ldrb	r2, [r3, #4]
20023c16:	4620      	mov	r0, r4
20023c18:	f7fe ff01 	bl	20022a1e <HAL_FLASH_ISSUE_CMD>
20023c1c:	4620      	mov	r0, r4
20023c1e:	f7fe fd0f 	bl	20022640 <HAL_FLASH_READ32>
20023c22:	4605      	mov	r5, r0
20023c24:	200a      	movs	r0, #10
20023c26:	f7fd fee4 	bl	200219f2 <HAL_Delay_us>
20023c2a:	07eb      	lsls	r3, r5, #31
20023c2c:	d4ec      	bmi.n	20023c08 <HAL_FLASH_Init+0x34c>
20023c2e:	4631      	mov	r1, r6
20023c30:	4620      	mov	r0, r4
20023c32:	f7ff fb9e 	bl	20023372 <nand_clear_status>
20023c36:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023c3a:	2b02      	cmp	r3, #2
20023c3c:	d181      	bne.n	20023b42 <HAL_FLASH_Init+0x286>
20023c3e:	2101      	movs	r1, #1
20023c40:	4620      	mov	r0, r4
20023c42:	f7ff fb65 	bl	20023310 <HAL_NAND_EN_QUAL>
20023c46:	e77c      	b.n	20023b42 <HAL_FLASH_Init+0x286>
20023c48:	03938700 	.word	0x03938700

20023c4c <HAL_MPI_OPSRAM_CAL_DELAY>:
20023c4c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20023c50:	4b21      	ldr	r3, [pc, #132]	@ (20023cd8 <HAL_MPI_OPSRAM_CAL_DELAY+0x8c>)
20023c52:	4616      	mov	r6, r2
20023c54:	6982      	ldr	r2, [r0, #24]
20023c56:	4605      	mov	r5, r0
20023c58:	429a      	cmp	r2, r3
20023c5a:	460f      	mov	r7, r1
20023c5c:	d805      	bhi.n	20023c6a <HAL_MPI_OPSRAM_CAL_DELAY+0x1e>
20023c5e:	231f      	movs	r3, #31
20023c60:	2000      	movs	r0, #0
20023c62:	700b      	strb	r3, [r1, #0]
20023c64:	7033      	strb	r3, [r6, #0]
20023c66:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023c6a:	f04f 4200 	mov.w	r2, #2147483648	@ 0x80000000
20023c6e:	6803      	ldr	r3, [r0, #0]
20023c70:	2000      	movs	r0, #0
20023c72:	65da      	str	r2, [r3, #92]	@ 0x5c
20023c74:	f7fd febd 	bl	200219f2 <HAL_Delay_us>
20023c78:	2400      	movs	r4, #0
20023c7a:	682b      	ldr	r3, [r5, #0]
20023c7c:	0222      	lsls	r2, r4, #8
20023c7e:	659a      	str	r2, [r3, #88]	@ 0x58
20023c80:	200a      	movs	r0, #10
20023c82:	f7fd feb6 	bl	200219f2 <HAL_Delay_us>
20023c86:	682b      	ldr	r3, [r5, #0]
20023c88:	46a0      	mov	r8, r4
20023c8a:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023c8c:	3401      	adds	r4, #1
20023c8e:	03da      	lsls	r2, r3, #15
20023c90:	d502      	bpl.n	20023c98 <HAL_MPI_OPSRAM_CAL_DELAY+0x4c>
20023c92:	2c80      	cmp	r4, #128	@ 0x80
20023c94:	d1f1      	bne.n	20023c7a <HAL_MPI_OPSRAM_CAL_DELAY+0x2e>
20023c96:	46a0      	mov	r8, r4
20023c98:	f108 0401 	add.w	r4, r8, #1
20023c9c:	2c7f      	cmp	r4, #127	@ 0x7f
20023c9e:	d905      	bls.n	20023cac <HAL_MPI_OPSRAM_CAL_DELAY+0x60>
20023ca0:	2001      	movs	r0, #1
20023ca2:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
20023ca6:	682b      	ldr	r3, [r5, #0]
20023ca8:	65da      	str	r2, [r3, #92]	@ 0x5c
20023caa:	e7dc      	b.n	20023c66 <HAL_MPI_OPSRAM_CAL_DELAY+0x1a>
20023cac:	682b      	ldr	r3, [r5, #0]
20023cae:	0222      	lsls	r2, r4, #8
20023cb0:	659a      	str	r2, [r3, #88]	@ 0x58
20023cb2:	200a      	movs	r0, #10
20023cb4:	f7fd fe9d 	bl	200219f2 <HAL_Delay_us>
20023cb8:	682b      	ldr	r3, [r5, #0]
20023cba:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023cbc:	03db      	lsls	r3, r3, #15
20023cbe:	d401      	bmi.n	20023cc4 <HAL_MPI_OPSRAM_CAL_DELAY+0x78>
20023cc0:	3401      	adds	r4, #1
20023cc2:	e7eb      	b.n	20023c9c <HAL_MPI_OPSRAM_CAL_DELAY+0x50>
20023cc4:	eba4 0408 	sub.w	r4, r4, r8
20023cc8:	f3c4 0447 	ubfx	r4, r4, #1, #8
20023ccc:	1f63      	subs	r3, r4, #5
20023cce:	703b      	strb	r3, [r7, #0]
20023cd0:	2000      	movs	r0, #0
20023cd2:	7034      	strb	r4, [r6, #0]
20023cd4:	e7e5      	b.n	20023ca2 <HAL_MPI_OPSRAM_CAL_DELAY+0x56>
20023cd6:	bf00      	nop
20023cd8:	016e3600 	.word	0x016e3600

20023cdc <HAL_SPI_PSRAM_Init>:
20023cdc:	b537      	push	{r0, r1, r2, r4, r5, lr}
20023cde:	4614      	mov	r4, r2
20023ce0:	4605      	mov	r5, r0
20023ce2:	2800      	cmp	r0, #0
20023ce4:	d043      	beq.n	20023d6e <HAL_SPI_PSRAM_Init+0x92>
20023ce6:	2900      	cmp	r1, #0
20023ce8:	d041      	beq.n	20023d6e <HAL_SPI_PSRAM_Init+0x92>
20023cea:	f7fe fbd9 	bl	200224a0 <HAL_QSPI_Init>
20023cee:	4628      	mov	r0, r5
20023cf0:	b2e1      	uxtb	r1, r4
20023cf2:	f7fe fcb0 	bl	20022656 <HAL_FLASH_SET_CLK_rom>
20023cf6:	4628      	mov	r0, r5
20023cf8:	f7ff fd7e 	bl	200237f8 <HAL_QSPI_GET_CLK>
20023cfc:	4b1d      	ldr	r3, [pc, #116]	@ (20023d74 <HAL_SPI_PSRAM_Init+0x98>)
20023cfe:	4298      	cmp	r0, r3
20023d00:	d930      	bls.n	20023d64 <HAL_SPI_PSRAM_Init+0x88>
20023d02:	4b1d      	ldr	r3, [pc, #116]	@ (20023d78 <HAL_SPI_PSRAM_Init+0x9c>)
20023d04:	4298      	cmp	r0, r3
20023d06:	d92f      	bls.n	20023d68 <HAL_SPI_PSRAM_Init+0x8c>
20023d08:	4b1c      	ldr	r3, [pc, #112]	@ (20023d7c <HAL_SPI_PSRAM_Init+0xa0>)
20023d0a:	4298      	cmp	r0, r3
20023d0c:	d922      	bls.n	20023d54 <HAL_SPI_PSRAM_Init+0x78>
20023d0e:	f240 34b6 	movw	r4, #950	@ 0x3b6
20023d12:	f240 4374 	movw	r3, #1140	@ 0x474
20023d16:	4a1a      	ldr	r2, [pc, #104]	@ (20023d80 <HAL_SPI_PSRAM_Init+0xa4>)
20023d18:	4290      	cmp	r0, r2
20023d1a:	bf88      	it	hi
20023d1c:	461c      	movhi	r4, r3
20023d1e:	2200      	movs	r2, #0
20023d20:	2101      	movs	r1, #1
20023d22:	4628      	mov	r0, r5
20023d24:	f7ff f8e6 	bl	20022ef4 <HAL_QSPI_SET_CLK_INV>
20023d28:	2100      	movs	r1, #0
20023d2a:	4622      	mov	r2, r4
20023d2c:	2302      	movs	r3, #2
20023d2e:	4628      	mov	r0, r5
20023d30:	9100      	str	r1, [sp, #0]
20023d32:	f7fe fd3b 	bl	200227ac <HAL_FLASH_SET_CS_TIME>
20023d36:	4604      	mov	r4, r0
20023d38:	b948      	cbnz	r0, 20023d4e <HAL_SPI_PSRAM_Init+0x72>
20023d3a:	2106      	movs	r1, #6
20023d3c:	4628      	mov	r0, r5
20023d3e:	f7fe fd4a 	bl	200227d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20023d42:	4604      	mov	r4, r0
20023d44:	b918      	cbnz	r0, 20023d4e <HAL_SPI_PSRAM_Init+0x72>
20023d46:	2101      	movs	r1, #1
20023d48:	4628      	mov	r0, r5
20023d4a:	f7fe fcea 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20023d4e:	4620      	mov	r0, r4
20023d50:	b003      	add	sp, #12
20023d52:	bd30      	pop	{r4, r5, pc}
20023d54:	4b0b      	ldr	r3, [pc, #44]	@ (20023d84 <HAL_SPI_PSRAM_Init+0xa8>)
20023d56:	f44f 743e 	mov.w	r4, #760	@ 0x2f8
20023d5a:	4298      	cmp	r0, r3
20023d5c:	d8df      	bhi.n	20023d1e <HAL_SPI_PSRAM_Init+0x42>
20023d5e:	2200      	movs	r2, #0
20023d60:	4611      	mov	r1, r2
20023d62:	e7de      	b.n	20023d22 <HAL_SPI_PSRAM_Init+0x46>
20023d64:	24b4      	movs	r4, #180	@ 0xb4
20023d66:	e7fa      	b.n	20023d5e <HAL_SPI_PSRAM_Init+0x82>
20023d68:	f44f 74be 	mov.w	r4, #380	@ 0x17c
20023d6c:	e7f7      	b.n	20023d5e <HAL_SPI_PSRAM_Init+0x82>
20023d6e:	2401      	movs	r4, #1
20023d70:	e7ed      	b.n	20023d4e <HAL_SPI_PSRAM_Init+0x72>
20023d72:	bf00      	nop
20023d74:	016e3600 	.word	0x016e3600
20023d78:	02dc6c00 	.word	0x02dc6c00
20023d7c:	05b8d800 	.word	0x05b8d800
20023d80:	07270e00 	.word	0x07270e00
20023d84:	03938700 	.word	0x03938700

20023d88 <HAL_MPI_MR_WRITE>:
20023d88:	b5f0      	push	{r4, r5, r6, r7, lr}
20023d8a:	460e      	mov	r6, r1
20023d8c:	4617      	mov	r7, r2
20023d8e:	4605      	mov	r5, r0
20023d90:	b087      	sub	sp, #28
20023d92:	b1d8      	cbz	r0, 20023dcc <HAL_MPI_MR_WRITE+0x44>
20023d94:	2207      	movs	r2, #7
20023d96:	2400      	movs	r4, #0
20023d98:	2303      	movs	r3, #3
20023d9a:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023d9e:	2101      	movs	r1, #1
20023da0:	e9cd 4301 	strd	r4, r3, [sp, #4]
20023da4:	9400      	str	r4, [sp, #0]
20023da6:	4623      	mov	r3, r4
20023da8:	f7fe fc5e 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20023dac:	2102      	movs	r1, #2
20023dae:	4628      	mov	r0, r5
20023db0:	f7fe fbf0 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023db4:	4639      	mov	r1, r7
20023db6:	4628      	mov	r0, r5
20023db8:	f7fe fbe5 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20023dbc:	4632      	mov	r2, r6
20023dbe:	21c0      	movs	r1, #192	@ 0xc0
20023dc0:	4628      	mov	r0, r5
20023dc2:	f7fe fc0c 	bl	200225de <HAL_FLASH_SET_CMD>
20023dc6:	4620      	mov	r0, r4
20023dc8:	b007      	add	sp, #28
20023dca:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023dcc:	2001      	movs	r0, #1
20023dce:	e7fb      	b.n	20023dc8 <HAL_MPI_MR_WRITE+0x40>

20023dd0 <HAL_MPI_SET_FIXLAT>:
20023dd0:	e92d 41ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, lr}
20023dd4:	460c      	mov	r4, r1
20023dd6:	4616      	mov	r6, r2
20023dd8:	461f      	mov	r7, r3
20023dda:	4605      	mov	r5, r0
20023ddc:	2800      	cmp	r0, #0
20023dde:	d040      	beq.n	20023e62 <HAL_MPI_SET_FIXLAT+0x92>
20023de0:	466b      	mov	r3, sp
20023de2:	4a21      	ldr	r2, [pc, #132]	@ (20023e68 <HAL_MPI_SET_FIXLAT+0x98>)
20023de4:	6810      	ldr	r0, [r2, #0]
20023de6:	6851      	ldr	r1, [r2, #4]
20023de8:	c303      	stmia	r3!, {r0, r1}
20023dea:	6890      	ldr	r0, [r2, #8]
20023dec:	68d1      	ldr	r1, [r2, #12]
20023dee:	c303      	stmia	r3!, {r0, r1}
20023df0:	4628      	mov	r0, r5
20023df2:	b2e1      	uxtb	r1, r4
20023df4:	f7fe fd22 	bl	2002283c <HAL_MPI_EN_FIXLAT>
20023df8:	f107 0310 	add.w	r3, r7, #16
20023dfc:	446b      	add	r3, sp
20023dfe:	f813 8c08 	ldrb.w	r8, [r3, #-8]
20023e02:	ea4f 1848 	mov.w	r8, r8, lsl #5
20023e06:	fa5f f888 	uxtb.w	r8, r8
20023e0a:	b30c      	cbz	r4, 20023e50 <HAL_MPI_SET_FIXLAT+0x80>
20023e0c:	ab04      	add	r3, sp, #16
20023e0e:	eb03 0356 	add.w	r3, r3, r6, lsr #1
20023e12:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023e16:	00a4      	lsls	r4, r4, #2
20023e18:	f044 0421 	orr.w	r4, r4, #33	@ 0x21
20023e1c:	b264      	sxtb	r4, r4
20023e1e:	f004 02fd 	and.w	r2, r4, #253	@ 0xfd
20023e22:	2100      	movs	r1, #0
20023e24:	4628      	mov	r0, r5
20023e26:	f7ff ffaf 	bl	20023d88 <HAL_MPI_MR_WRITE>
20023e2a:	1e71      	subs	r1, r6, #1
20023e2c:	4628      	mov	r0, r5
20023e2e:	b249      	sxtb	r1, r1
20023e30:	f7fe fd2e 	bl	20022890 <HAL_MPI_MODIFY_RCMD_DELAY>
20023e34:	4642      	mov	r2, r8
20023e36:	2104      	movs	r1, #4
20023e38:	4628      	mov	r0, r5
20023e3a:	f7ff ffa5 	bl	20023d88 <HAL_MPI_MR_WRITE>
20023e3e:	1e79      	subs	r1, r7, #1
20023e40:	4628      	mov	r0, r5
20023e42:	b249      	sxtb	r1, r1
20023e44:	f7fe fd2d 	bl	200228a2 <HAL_MPI_MODIFY_WCMD_DELAY>
20023e48:	2000      	movs	r0, #0
20023e4a:	b004      	add	sp, #16
20023e4c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023e50:	f106 0310 	add.w	r3, r6, #16
20023e54:	446b      	add	r3, sp
20023e56:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023e5a:	00a4      	lsls	r4, r4, #2
20023e5c:	f044 0401 	orr.w	r4, r4, #1
20023e60:	e7dc      	b.n	20023e1c <HAL_MPI_SET_FIXLAT+0x4c>
20023e62:	2001      	movs	r0, #1
20023e64:	e7f1      	b.n	20023e4a <HAL_MPI_SET_FIXLAT+0x7a>
20023e66:	bf00      	nop
20023e68:	20027664 	.word	0x20027664

20023e6c <HAL_LEGACY_MR_WRITE>:
20023e6c:	b5f0      	push	{r4, r5, r6, r7, lr}
20023e6e:	460e      	mov	r6, r1
20023e70:	4617      	mov	r7, r2
20023e72:	4604      	mov	r4, r0
20023e74:	b087      	sub	sp, #28
20023e76:	b1e0      	cbz	r0, 20023eb2 <HAL_LEGACY_MR_WRITE+0x46>
20023e78:	2207      	movs	r2, #7
20023e7a:	2500      	movs	r5, #0
20023e7c:	2302      	movs	r3, #2
20023e7e:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023e82:	e9cd 5301 	strd	r5, r3, [sp, #4]
20023e86:	9500      	str	r5, [sp, #0]
20023e88:	f990 302e 	ldrsb.w	r3, [r0, #46]	@ 0x2e
20023e8c:	2101      	movs	r1, #1
20023e8e:	f7fe fbeb 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20023e92:	2104      	movs	r1, #4
20023e94:	4620      	mov	r0, r4
20023e96:	f7fe fb7d 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
20023e9a:	4639      	mov	r1, r7
20023e9c:	4620      	mov	r0, r4
20023e9e:	f7fe fb72 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20023ea2:	4632      	mov	r2, r6
20023ea4:	21c0      	movs	r1, #192	@ 0xc0
20023ea6:	4620      	mov	r0, r4
20023ea8:	f7fe fb99 	bl	200225de <HAL_FLASH_SET_CMD>
20023eac:	4628      	mov	r0, r5
20023eae:	b007      	add	sp, #28
20023eb0:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023eb2:	2001      	movs	r0, #1
20023eb4:	e7fb      	b.n	20023eae <HAL_LEGACY_MR_WRITE+0x42>

20023eb6 <HAL_LEGACY_CFG_READ>:
20023eb6:	b530      	push	{r4, r5, lr}
20023eb8:	4605      	mov	r5, r0
20023eba:	b085      	sub	sp, #20
20023ebc:	b1a0      	cbz	r0, 20023ee8 <HAL_LEGACY_CFG_READ+0x32>
20023ebe:	2400      	movs	r4, #0
20023ec0:	2107      	movs	r1, #7
20023ec2:	2302      	movs	r3, #2
20023ec4:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20023ec8:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023ecc:	0052      	lsls	r2, r2, #1
20023ece:	e9cd 4300 	strd	r4, r3, [sp]
20023ed2:	b252      	sxtb	r2, r2
20023ed4:	4623      	mov	r3, r4
20023ed6:	f7fe fb10 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
20023eda:	4621      	mov	r1, r4
20023edc:	4628      	mov	r0, r5
20023ede:	f7fe fb01 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
20023ee2:	4620      	mov	r0, r4
20023ee4:	b005      	add	sp, #20
20023ee6:	bd30      	pop	{r4, r5, pc}
20023ee8:	2001      	movs	r0, #1
20023eea:	e7fb      	b.n	20023ee4 <HAL_LEGACY_CFG_READ+0x2e>

20023eec <HAL_LEGACY_CFG_WRITE>:
20023eec:	b530      	push	{r4, r5, lr}
20023eee:	4605      	mov	r5, r0
20023ef0:	b085      	sub	sp, #20
20023ef2:	b190      	cbz	r0, 20023f1a <HAL_LEGACY_CFG_WRITE+0x2e>
20023ef4:	2107      	movs	r1, #7
20023ef6:	2400      	movs	r4, #0
20023ef8:	2302      	movs	r3, #2
20023efa:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023efe:	e9cd 4300 	strd	r4, r3, [sp]
20023f02:	4623      	mov	r3, r4
20023f04:	f990 202e 	ldrsb.w	r2, [r0, #46]	@ 0x2e
20023f08:	f7fe fb20 	bl	2002254c <HAL_FLASH_CFG_AHB_WCMD>
20023f0c:	2180      	movs	r1, #128	@ 0x80
20023f0e:	4628      	mov	r0, r5
20023f10:	f7fe fb10 	bl	20022534 <HAL_FLASH_SET_AHB_WCMD>
20023f14:	4620      	mov	r0, r4
20023f16:	b005      	add	sp, #20
20023f18:	bd30      	pop	{r4, r5, pc}
20023f1a:	2001      	movs	r0, #1
20023f1c:	e7fb      	b.n	20023f16 <HAL_LEGACY_CFG_WRITE+0x2a>

20023f1e <HAL_PSRAM_RESET>:
20023f1e:	b5f0      	push	{r4, r5, r6, r7, lr}
20023f20:	4604      	mov	r4, r0
20023f22:	b087      	sub	sp, #28
20023f24:	2800      	cmp	r0, #0
20023f26:	d03b      	beq.n	20023fa0 <HAL_PSRAM_RESET+0x82>
20023f28:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
20023f2c:	2b05      	cmp	r3, #5
20023f2e:	d034      	beq.n	20023f9a <HAL_PSRAM_RESET+0x7c>
20023f30:	3b03      	subs	r3, #3
20023f32:	2b01      	cmp	r3, #1
20023f34:	d82e      	bhi.n	20023f94 <HAL_PSRAM_RESET+0x76>
20023f36:	2601      	movs	r6, #1
20023f38:	2703      	movs	r7, #3
20023f3a:	2300      	movs	r3, #0
20023f3c:	2507      	movs	r5, #7
20023f3e:	b276      	sxtb	r6, r6
20023f40:	b27f      	sxtb	r7, r7
20023f42:	461a      	mov	r2, r3
20023f44:	2101      	movs	r1, #1
20023f46:	4620      	mov	r0, r4
20023f48:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023f4c:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023f50:	9600      	str	r6, [sp, #0]
20023f52:	f7fe fb89 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20023f56:	2200      	movs	r2, #0
20023f58:	21ff      	movs	r1, #255	@ 0xff
20023f5a:	4620      	mov	r0, r4
20023f5c:	f7fe fb3f 	bl	200225de <HAL_FLASH_SET_CMD>
20023f60:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023f64:	2b05      	cmp	r3, #5
20023f66:	d10f      	bne.n	20023f88 <HAL_PSRAM_RESET+0x6a>
20023f68:	2300      	movs	r3, #0
20023f6a:	2101      	movs	r1, #1
20023f6c:	461a      	mov	r2, r3
20023f6e:	4620      	mov	r0, r4
20023f70:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023f74:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023f78:	9600      	str	r6, [sp, #0]
20023f7a:	f7fe fb75 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
20023f7e:	2200      	movs	r2, #0
20023f80:	21ff      	movs	r1, #255	@ 0xff
20023f82:	4620      	mov	r0, r4
20023f84:	f7fe fb2b 	bl	200225de <HAL_FLASH_SET_CMD>
20023f88:	2000      	movs	r0, #0
20023f8a:	f7fd fd32 	bl	200219f2 <HAL_Delay_us>
20023f8e:	2003      	movs	r0, #3
20023f90:	f7fd fd2f 	bl	200219f2 <HAL_Delay_us>
20023f94:	2000      	movs	r0, #0
20023f96:	b007      	add	sp, #28
20023f98:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023f9a:	2603      	movs	r6, #3
20023f9c:	2702      	movs	r7, #2
20023f9e:	e7cc      	b.n	20023f3a <HAL_PSRAM_RESET+0x1c>
20023fa0:	2001      	movs	r0, #1
20023fa2:	e7f8      	b.n	20023f96 <HAL_PSRAM_RESET+0x78>

20023fa4 <HAL_OPI_PSRAM_Init>:
20023fa4:	b530      	push	{r4, r5, lr}
20023fa6:	4604      	mov	r4, r0
20023fa8:	b085      	sub	sp, #20
20023faa:	2800      	cmp	r0, #0
20023fac:	d076      	beq.n	2002409c <HAL_OPI_PSRAM_Init+0xf8>
20023fae:	2900      	cmp	r1, #0
20023fb0:	d074      	beq.n	2002409c <HAL_OPI_PSRAM_Init+0xf8>
20023fb2:	f7fe fa75 	bl	200224a0 <HAL_QSPI_Init>
20023fb6:	6823      	ldr	r3, [r4, #0]
20023fb8:	2101      	movs	r1, #1
20023fba:	4620      	mov	r0, r4
20023fbc:	681d      	ldr	r5, [r3, #0]
20023fbe:	f7fe fbbe 	bl	2002273e <HAL_FLASH_ENABLE_OPI>
20023fc2:	2101      	movs	r1, #1
20023fc4:	4620      	mov	r0, r4
20023fc6:	f7fe fb46 	bl	20022656 <HAL_FLASH_SET_CLK_rom>
20023fca:	4620      	mov	r0, r4
20023fcc:	f7ff fc14 	bl	200237f8 <HAL_QSPI_GET_CLK>
20023fd0:	0840      	lsrs	r0, r0, #1
20023fd2:	61a0      	str	r0, [r4, #24]
20023fd4:	f10d 020e 	add.w	r2, sp, #14
20023fd8:	4620      	mov	r0, r4
20023fda:	f10d 010f 	add.w	r1, sp, #15
20023fde:	f7ff fe35 	bl	20023c4c <HAL_MPI_OPSRAM_CAL_DELAY>
20023fe2:	4603      	mov	r3, r0
20023fe4:	b100      	cbz	r0, 20023fe8 <HAL_OPI_PSRAM_Init+0x44>
20023fe6:	e7fe      	b.n	20023fe6 <HAL_OPI_PSRAM_Init+0x42>
20023fe8:	69a2      	ldr	r2, [r4, #24]
20023fea:	492d      	ldr	r1, [pc, #180]	@ (200240a0 <HAL_OPI_PSRAM_Init+0xfc>)
20023fec:	428a      	cmp	r2, r1
20023fee:	d93b      	bls.n	20024068 <HAL_OPI_PSRAM_Init+0xc4>
20023ff0:	4b2c      	ldr	r3, [pc, #176]	@ (200240a4 <HAL_OPI_PSRAM_Init+0x100>)
20023ff2:	429a      	cmp	r2, r3
20023ff4:	d93c      	bls.n	20024070 <HAL_OPI_PSRAM_Init+0xcc>
20023ff6:	440b      	add	r3, r1
20023ff8:	429a      	cmp	r2, r3
20023ffa:	d93f      	bls.n	2002407c <HAL_OPI_PSRAM_Init+0xd8>
20023ffc:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20024000:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20024004:	429a      	cmp	r2, r3
20024006:	d93f      	bls.n	20024088 <HAL_OPI_PSRAM_Init+0xe4>
20024008:	2107      	movs	r1, #7
2002400a:	2014      	movs	r0, #20
2002400c:	2308      	movs	r3, #8
2002400e:	f240 5232 	movw	r2, #1330	@ 0x532
20024012:	f884 102d 	strb.w	r1, [r4, #45]	@ 0x2d
20024016:	f884 102e 	strb.w	r1, [r4, #46]	@ 0x2e
2002401a:	2106      	movs	r1, #6
2002401c:	9000      	str	r0, [sp, #0]
2002401e:	4620      	mov	r0, r4
20024020:	f7fe fbc4 	bl	200227ac <HAL_FLASH_SET_CS_TIME>
20024024:	2107      	movs	r1, #7
20024026:	4620      	mov	r0, r4
20024028:	f7fe fbd5 	bl	200227d6 <HAL_FLASH_SET_ROW_BOUNDARY>
2002402c:	2101      	movs	r1, #1
2002402e:	4620      	mov	r0, r4
20024030:	f7fe fc06 	bl	20022840 <HAL_MPI_ENABLE_DQS>
20024034:	f89d 100e 	ldrb.w	r1, [sp, #14]
20024038:	4620      	mov	r0, r4
2002403a:	f7fe fc05 	bl	20022848 <HAL_MPI_SET_DQS_DELAY>
2002403e:	2200      	movs	r2, #0
20024040:	f89d 100f 	ldrb.w	r1, [sp, #15]
20024044:	4620      	mov	r0, r4
20024046:	f7fe fc0a 	bl	2002285e <HAL_MPI_SET_SCK>
2002404a:	2101      	movs	r1, #1
2002404c:	4620      	mov	r0, r4
2002404e:	f7fe fb68 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20024052:	07eb      	lsls	r3, r5, #31
20024054:	d405      	bmi.n	20024062 <HAL_OPI_PSRAM_Init+0xbe>
20024056:	4b14      	ldr	r3, [pc, #80]	@ (200240a8 <HAL_OPI_PSRAM_Init+0x104>)
20024058:	681b      	ldr	r3, [r3, #0]
2002405a:	f003 0303 	and.w	r3, r3, #3
2002405e:	2b03      	cmp	r3, #3
20024060:	d118      	bne.n	20024094 <HAL_OPI_PSRAM_Init+0xf0>
20024062:	2000      	movs	r0, #0
20024064:	b005      	add	sp, #20
20024066:	bd30      	pop	{r4, r5, pc}
20024068:	2103      	movs	r1, #3
2002406a:	22b4      	movs	r2, #180	@ 0xb4
2002406c:	4608      	mov	r0, r1
2002406e:	e7d0      	b.n	20024012 <HAL_OPI_PSRAM_Init+0x6e>
20024070:	2105      	movs	r1, #5
20024072:	200e      	movs	r0, #14
20024074:	2303      	movs	r3, #3
20024076:	f240 32b6 	movw	r2, #950	@ 0x3b6
2002407a:	e7ca      	b.n	20024012 <HAL_OPI_PSRAM_Init+0x6e>
2002407c:	2106      	movs	r1, #6
2002407e:	2011      	movs	r0, #17
20024080:	2305      	movs	r3, #5
20024082:	f240 4274 	movw	r2, #1140	@ 0x474
20024086:	e7c4      	b.n	20024012 <HAL_OPI_PSRAM_Init+0x6e>
20024088:	2106      	movs	r1, #6
2002408a:	2013      	movs	r0, #19
2002408c:	460b      	mov	r3, r1
2002408e:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20024092:	e7be      	b.n	20024012 <HAL_OPI_PSRAM_Init+0x6e>
20024094:	4620      	mov	r0, r4
20024096:	f7ff ff42 	bl	20023f1e <HAL_PSRAM_RESET>
2002409a:	e7e2      	b.n	20024062 <HAL_OPI_PSRAM_Init+0xbe>
2002409c:	2001      	movs	r0, #1
2002409e:	e7e1      	b.n	20024064 <HAL_OPI_PSRAM_Init+0xc0>
200240a0:	016e3600 	.word	0x016e3600
200240a4:	07270e00 	.word	0x07270e00
200240a8:	500c0000 	.word	0x500c0000

200240ac <HAL_LEGACY_PSRAM_Init>:
200240ac:	b5f0      	push	{r4, r5, r6, r7, lr}
200240ae:	4604      	mov	r4, r0
200240b0:	b085      	sub	sp, #20
200240b2:	2800      	cmp	r0, #0
200240b4:	f000 809e 	beq.w	200241f4 <HAL_LEGACY_PSRAM_Init+0x148>
200240b8:	2900      	cmp	r1, #0
200240ba:	f000 809b 	beq.w	200241f4 <HAL_LEGACY_PSRAM_Init+0x148>
200240be:	f7fe f9ef 	bl	200224a0 <HAL_QSPI_Init>
200240c2:	6823      	ldr	r3, [r4, #0]
200240c4:	2101      	movs	r1, #1
200240c6:	4620      	mov	r0, r4
200240c8:	681e      	ldr	r6, [r3, #0]
200240ca:	f7fe fb38 	bl	2002273e <HAL_FLASH_ENABLE_OPI>
200240ce:	2101      	movs	r1, #1
200240d0:	4620      	mov	r0, r4
200240d2:	f7fe fac0 	bl	20022656 <HAL_FLASH_SET_CLK_rom>
200240d6:	4620      	mov	r0, r4
200240d8:	f7ff fb8e 	bl	200237f8 <HAL_QSPI_GET_CLK>
200240dc:	0845      	lsrs	r5, r0, #1
200240de:	61a5      	str	r5, [r4, #24]
200240e0:	4620      	mov	r0, r4
200240e2:	f10d 020e 	add.w	r2, sp, #14
200240e6:	f10d 010f 	add.w	r1, sp, #15
200240ea:	f7ff fdaf 	bl	20023c4c <HAL_MPI_OPSRAM_CAL_DELAY>
200240ee:	4603      	mov	r3, r0
200240f0:	b100      	cbz	r0, 200240f4 <HAL_LEGACY_PSRAM_Init+0x48>
200240f2:	e7fe      	b.n	200240f2 <HAL_LEGACY_PSRAM_Init+0x46>
200240f4:	4a40      	ldr	r2, [pc, #256]	@ (200241f8 <HAL_LEGACY_PSRAM_Init+0x14c>)
200240f6:	4f41      	ldr	r7, [pc, #260]	@ (200241fc <HAL_LEGACY_PSRAM_Init+0x150>)
200240f8:	4295      	cmp	r5, r2
200240fa:	d95a      	bls.n	200241b2 <HAL_LEGACY_PSRAM_Init+0x106>
200240fc:	42bd      	cmp	r5, r7
200240fe:	d95b      	bls.n	200241b8 <HAL_LEGACY_PSRAM_Init+0x10c>
20024100:	4b3f      	ldr	r3, [pc, #252]	@ (20024200 <HAL_LEGACY_PSRAM_Init+0x154>)
20024102:	429d      	cmp	r5, r3
20024104:	d95d      	bls.n	200241c2 <HAL_LEGACY_PSRAM_Init+0x116>
20024106:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
2002410a:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
2002410e:	429d      	cmp	r5, r3
20024110:	d95c      	bls.n	200241cc <HAL_LEGACY_PSRAM_Init+0x120>
20024112:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20024116:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
2002411a:	429d      	cmp	r5, r3
2002411c:	d85b      	bhi.n	200241d6 <HAL_LEGACY_PSRAM_Init+0x12a>
2002411e:	2114      	movs	r1, #20
20024120:	2308      	movs	r3, #8
20024122:	f240 5232 	movw	r2, #1330	@ 0x532
20024126:	9100      	str	r1, [sp, #0]
20024128:	4620      	mov	r0, r4
2002412a:	2106      	movs	r1, #6
2002412c:	f7fe fb3e 	bl	200227ac <HAL_FLASH_SET_CS_TIME>
20024130:	2107      	movs	r1, #7
20024132:	4620      	mov	r0, r4
20024134:	f7fe fb4f 	bl	200227d6 <HAL_FLASH_SET_ROW_BOUNDARY>
20024138:	2101      	movs	r1, #1
2002413a:	4620      	mov	r0, r4
2002413c:	f7fe fb80 	bl	20022840 <HAL_MPI_ENABLE_DQS>
20024140:	f89d 100e 	ldrb.w	r1, [sp, #14]
20024144:	4620      	mov	r0, r4
20024146:	f7fe fb7f 	bl	20022848 <HAL_MPI_SET_DQS_DELAY>
2002414a:	2200      	movs	r2, #0
2002414c:	f89d 100f 	ldrb.w	r1, [sp, #15]
20024150:	4620      	mov	r0, r4
20024152:	f7fe fb84 	bl	2002285e <HAL_MPI_SET_SCK>
20024156:	2101      	movs	r1, #1
20024158:	4620      	mov	r0, r4
2002415a:	f7fe fb46 	bl	200227ea <HAL_FLASH_SET_LEGACY>
2002415e:	2101      	movs	r1, #1
20024160:	4620      	mov	r0, r4
20024162:	f7fe fade 	bl	20022722 <HAL_FLASH_ENABLE_QSPI>
20024166:	07f3      	lsls	r3, r6, #31
20024168:	d405      	bmi.n	20024176 <HAL_LEGACY_PSRAM_Init+0xca>
2002416a:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
2002416e:	b913      	cbnz	r3, 20024176 <HAL_LEGACY_PSRAM_Init+0xca>
20024170:	4620      	mov	r0, r4
20024172:	f7ff fed4 	bl	20023f1e <HAL_PSRAM_RESET>
20024176:	42bd      	cmp	r5, r7
20024178:	d932      	bls.n	200241e0 <HAL_LEGACY_PSRAM_Init+0x134>
2002417a:	4b22      	ldr	r3, [pc, #136]	@ (20024204 <HAL_LEGACY_PSRAM_Init+0x158>)
2002417c:	429d      	cmp	r5, r3
2002417e:	d934      	bls.n	200241ea <HAL_LEGACY_PSRAM_Init+0x13e>
20024180:	2206      	movs	r2, #6
20024182:	2302      	movs	r3, #2
20024184:	2588      	movs	r5, #136	@ 0x88
20024186:	263b      	movs	r6, #59	@ 0x3b
20024188:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
2002418c:	2101      	movs	r1, #1
2002418e:	f884 202d 	strb.w	r2, [r4, #45]	@ 0x2d
20024192:	4620      	mov	r0, r4
20024194:	f7fe fb52 	bl	2002283c <HAL_MPI_EN_FIXLAT>
20024198:	4632      	mov	r2, r6
2002419a:	2100      	movs	r1, #0
2002419c:	4620      	mov	r0, r4
2002419e:	f7ff fe65 	bl	20023e6c <HAL_LEGACY_MR_WRITE>
200241a2:	462a      	mov	r2, r5
200241a4:	2104      	movs	r1, #4
200241a6:	4620      	mov	r0, r4
200241a8:	f7ff fe60 	bl	20023e6c <HAL_LEGACY_MR_WRITE>
200241ac:	2000      	movs	r0, #0
200241ae:	b005      	add	sp, #20
200241b0:	bdf0      	pop	{r4, r5, r6, r7, pc}
200241b2:	2103      	movs	r1, #3
200241b4:	22b4      	movs	r2, #180	@ 0xb4
200241b6:	e7b6      	b.n	20024126 <HAL_LEGACY_PSRAM_Init+0x7a>
200241b8:	210e      	movs	r1, #14
200241ba:	2303      	movs	r3, #3
200241bc:	f240 32b6 	movw	r2, #950	@ 0x3b6
200241c0:	e7b1      	b.n	20024126 <HAL_LEGACY_PSRAM_Init+0x7a>
200241c2:	2111      	movs	r1, #17
200241c4:	2305      	movs	r3, #5
200241c6:	f240 4274 	movw	r2, #1140	@ 0x474
200241ca:	e7ac      	b.n	20024126 <HAL_LEGACY_PSRAM_Init+0x7a>
200241cc:	2113      	movs	r1, #19
200241ce:	2306      	movs	r3, #6
200241d0:	f240 42d3 	movw	r2, #1235	@ 0x4d3
200241d4:	e7a7      	b.n	20024126 <HAL_LEGACY_PSRAM_Init+0x7a>
200241d6:	2117      	movs	r1, #23
200241d8:	2309      	movs	r3, #9
200241da:	f44f 62be 	mov.w	r2, #1520	@ 0x5f0
200241de:	e7a2      	b.n	20024126 <HAL_LEGACY_PSRAM_Init+0x7a>
200241e0:	2204      	movs	r2, #4
200241e2:	2300      	movs	r3, #0
200241e4:	2508      	movs	r5, #8
200241e6:	2633      	movs	r6, #51	@ 0x33
200241e8:	e7ce      	b.n	20024188 <HAL_LEGACY_PSRAM_Init+0xdc>
200241ea:	2205      	movs	r2, #5
200241ec:	2300      	movs	r3, #0
200241ee:	2508      	movs	r5, #8
200241f0:	2637      	movs	r6, #55	@ 0x37
200241f2:	e7c9      	b.n	20024188 <HAL_LEGACY_PSRAM_Init+0xdc>
200241f4:	2001      	movs	r0, #1
200241f6:	e7da      	b.n	200241ae <HAL_LEGACY_PSRAM_Init+0x102>
200241f8:	016e3600 	.word	0x016e3600
200241fc:	07270e00 	.word	0x07270e00
20024200:	08954400 	.word	0x08954400
20024204:	094c5f00 	.word	0x094c5f00

20024208 <HAL_HYPER_PSRAM_WriteCR>:
20024208:	b570      	push	{r4, r5, r6, lr}
2002420a:	460e      	mov	r6, r1
2002420c:	4615      	mov	r5, r2
2002420e:	4604      	mov	r4, r0
20024210:	b086      	sub	sp, #24
20024212:	b1f8      	cbz	r0, 20024254 <HAL_HYPER_PSRAM_WriteCR+0x4c>
20024214:	2207      	movs	r2, #7
20024216:	2303      	movs	r3, #3
20024218:	e9cd 2301 	strd	r2, r3, [sp, #4]
2002421c:	2300      	movs	r3, #0
2002421e:	e9cd 2203 	strd	r2, r2, [sp, #12]
20024222:	9300      	str	r3, [sp, #0]
20024224:	2101      	movs	r1, #1
20024226:	f7fe fa1f 	bl	20022668 <HAL_FLASH_MANUAL_CMD>
2002422a:	4631      	mov	r1, r6
2002422c:	4620      	mov	r0, r4
2002422e:	f7fe f9c5 	bl	200225bc <HAL_FLASH_WRITE_ABYTE>
20024232:	2102      	movs	r1, #2
20024234:	4620      	mov	r0, r4
20024236:	f7fe f9ad 	bl	20022594 <HAL_FLASH_WRITE_DLEN>
2002423a:	4629      	mov	r1, r5
2002423c:	4620      	mov	r0, r4
2002423e:	f7fe f9a2 	bl	20022586 <HAL_FLASH_WRITE_WORD>
20024242:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20024246:	2160      	movs	r1, #96	@ 0x60
20024248:	4620      	mov	r0, r4
2002424a:	b006      	add	sp, #24
2002424c:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20024250:	f7fe b9c5 	b.w	200225de <HAL_FLASH_SET_CMD>
20024254:	b006      	add	sp, #24
20024256:	bd70      	pop	{r4, r5, r6, pc}

20024258 <HAL_HYPER_PSRAM_Init>:
20024258:	b538      	push	{r3, r4, r5, lr}
2002425a:	4605      	mov	r5, r0
2002425c:	2201      	movs	r2, #1
2002425e:	f7ff fea1 	bl	20023fa4 <HAL_OPI_PSRAM_Init>
20024262:	69ac      	ldr	r4, [r5, #24]
20024264:	4b12      	ldr	r3, [pc, #72]	@ (200242b0 <HAL_HYPER_PSRAM_Init+0x58>)
20024266:	429c      	cmp	r4, r3
20024268:	d91c      	bls.n	200242a4 <HAL_HYPER_PSRAM_Init+0x4c>
2002426a:	4b12      	ldr	r3, [pc, #72]	@ (200242b4 <HAL_HYPER_PSRAM_Init+0x5c>)
2002426c:	429c      	cmp	r4, r3
2002426e:	d91b      	bls.n	200242a8 <HAL_HYPER_PSRAM_Init+0x50>
20024270:	4b11      	ldr	r3, [pc, #68]	@ (200242b8 <HAL_HYPER_PSRAM_Init+0x60>)
20024272:	429c      	cmp	r4, r3
20024274:	d91a      	bls.n	200242ac <HAL_HYPER_PSRAM_Init+0x54>
20024276:	4b11      	ldr	r3, [pc, #68]	@ (200242bc <HAL_HYPER_PSRAM_Init+0x64>)
20024278:	429c      	cmp	r4, r3
2002427a:	bf8c      	ite	hi
2002427c:	2402      	movhi	r4, #2
2002427e:	2401      	movls	r4, #1
20024280:	2101      	movs	r1, #1
20024282:	4628      	mov	r0, r5
20024284:	f7fe fa69 	bl	2002275a <HAL_FLASH_ENABLE_HYPER>
20024288:	f240 428f 	movw	r2, #1167	@ 0x48f
2002428c:	4628      	mov	r0, r5
2002428e:	ea42 3204 	orr.w	r2, r2, r4, lsl #12
20024292:	2100      	movs	r1, #0
20024294:	f7ff ffb8 	bl	20024208 <HAL_HYPER_PSRAM_WriteCR>
20024298:	2101      	movs	r1, #1
2002429a:	4628      	mov	r0, r5
2002429c:	f7fe face 	bl	2002283c <HAL_MPI_EN_FIXLAT>
200242a0:	2000      	movs	r0, #0
200242a2:	bd38      	pop	{r3, r4, r5, pc}
200242a4:	240e      	movs	r4, #14
200242a6:	e7eb      	b.n	20024280 <HAL_HYPER_PSRAM_Init+0x28>
200242a8:	240f      	movs	r4, #15
200242aa:	e7e9      	b.n	20024280 <HAL_HYPER_PSRAM_Init+0x28>
200242ac:	2400      	movs	r4, #0
200242ae:	e7e7      	b.n	20024280 <HAL_HYPER_PSRAM_Init+0x28>
200242b0:	0510ff40 	.word	0x0510ff40
200242b4:	0632ea00 	.word	0x0632ea00
200242b8:	07ed6b40 	.word	0x07ed6b40
200242bc:	09e4f580 	.word	0x09e4f580

200242c0 <HAL_HYPER_CFG_READ>:
200242c0:	b51f      	push	{r0, r1, r2, r3, r4, lr}
200242c2:	b160      	cbz	r0, 200242de <HAL_HYPER_CFG_READ+0x1e>
200242c4:	2107      	movs	r1, #7
200242c6:	2303      	movs	r3, #3
200242c8:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
200242cc:	e9cd 1300 	strd	r1, r3, [sp]
200242d0:	3a01      	subs	r2, #1
200242d2:	2300      	movs	r3, #0
200242d4:	e9cd 1102 	strd	r1, r1, [sp, #8]
200242d8:	b252      	sxtb	r2, r2
200242da:	f7fe f90e 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
200242de:	b005      	add	sp, #20
200242e0:	f85d fb04 	ldr.w	pc, [sp], #4

200242e4 <HAL_HYPER_CFG_WRITE>:
200242e4:	b51f      	push	{r0, r1, r2, r3, r4, lr}
200242e6:	b160      	cbz	r0, 20024302 <HAL_HYPER_CFG_WRITE+0x1e>
200242e8:	2107      	movs	r1, #7
200242ea:	2303      	movs	r3, #3
200242ec:	f890 202e 	ldrb.w	r2, [r0, #46]	@ 0x2e
200242f0:	e9cd 1300 	strd	r1, r3, [sp]
200242f4:	3a01      	subs	r2, #1
200242f6:	2300      	movs	r3, #0
200242f8:	e9cd 1102 	strd	r1, r1, [sp, #8]
200242fc:	b252      	sxtb	r2, r2
200242fe:	f7fe f925 	bl	2002254c <HAL_FLASH_CFG_AHB_WCMD>
20024302:	b005      	add	sp, #20
20024304:	f85d fb04 	ldr.w	pc, [sp], #4

20024308 <HAL_MPI_PSRAM_Init>:
20024308:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
2002430c:	690b      	ldr	r3, [r1, #16]
2002430e:	4604      	mov	r4, r0
20024310:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
20024314:	690b      	ldr	r3, [r1, #16]
20024316:	3b03      	subs	r3, #3
20024318:	2b03      	cmp	r3, #3
2002431a:	f200 8085 	bhi.w	20024428 <HAL_MPI_PSRAM_Init+0x120>
2002431e:	e8df f003 	tbb	[pc, r3]
20024322:	6302      	.short	0x6302
20024324:	7958      	.short	0x7958
20024326:	4620      	mov	r0, r4
20024328:	f7ff fe3c 	bl	20023fa4 <HAL_OPI_PSRAM_Init>
2002432c:	2203      	movs	r2, #3
2002432e:	4606      	mov	r6, r0
20024330:	2108      	movs	r1, #8
20024332:	4620      	mov	r0, r4
20024334:	f7ff fd28 	bl	20023d88 <HAL_MPI_MR_WRITE>
20024338:	4620      	mov	r0, r4
2002433a:	f7ff fa5d 	bl	200237f8 <HAL_QSPI_GET_CLK>
2002433e:	4b4d      	ldr	r3, [pc, #308]	@ (20024474 <HAL_MPI_PSRAM_Init+0x16c>)
20024340:	4298      	cmp	r0, r3
20024342:	d95f      	bls.n	20024404 <HAL_MPI_PSRAM_Init+0xfc>
20024344:	f103 63a4 	add.w	r3, r3, #85983232	@ 0x5200000
20024348:	f503 4383 	add.w	r3, r3, #16768	@ 0x4180
2002434c:	4298      	cmp	r0, r3
2002434e:	d95b      	bls.n	20024408 <HAL_MPI_PSRAM_Init+0x100>
20024350:	f103 7337 	add.w	r3, r3, #47972352	@ 0x2dc0000
20024354:	f503 43d8 	add.w	r3, r3, #27648	@ 0x6c00
20024358:	4298      	cmp	r0, r3
2002435a:	d957      	bls.n	2002440c <HAL_MPI_PSRAM_Init+0x104>
2002435c:	4b46      	ldr	r3, [pc, #280]	@ (20024478 <HAL_MPI_PSRAM_Init+0x170>)
2002435e:	4298      	cmp	r0, r3
20024360:	d956      	bls.n	20024410 <HAL_MPI_PSRAM_Init+0x108>
20024362:	4b46      	ldr	r3, [pc, #280]	@ (2002447c <HAL_MPI_PSRAM_Init+0x174>)
20024364:	4298      	cmp	r0, r3
20024366:	bf94      	ite	ls
20024368:	2507      	movls	r5, #7
2002436a:	2500      	movhi	r5, #0
2002436c:	f04f 0800 	mov.w	r8, #0
20024370:	2707      	movs	r7, #7
20024372:	f04f 0a03 	mov.w	sl, #3
20024376:	ea4f 0945 	mov.w	r9, r5, lsl #1
2002437a:	4643      	mov	r3, r8
2002437c:	f109 32ff 	add.w	r2, r9, #4294967295
20024380:	4639      	mov	r1, r7
20024382:	4620      	mov	r0, r4
20024384:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024388:	e9cd 8a00 	strd	r8, sl, [sp]
2002438c:	f7fe f8b5 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
20024390:	4641      	mov	r1, r8
20024392:	4620      	mov	r0, r4
20024394:	f7fe f8a6 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
20024398:	4643      	mov	r3, r8
2002439a:	1e6a      	subs	r2, r5, #1
2002439c:	4639      	mov	r1, r7
2002439e:	4620      	mov	r0, r4
200243a0:	e9cd 7702 	strd	r7, r7, [sp, #8]
200243a4:	e9cd 8a00 	strd	r8, sl, [sp]
200243a8:	f7fe f8d0 	bl	2002254c <HAL_FLASH_CFG_AHB_WCMD>
200243ac:	2180      	movs	r1, #128	@ 0x80
200243ae:	4620      	mov	r0, r4
200243b0:	f7fe f8c0 	bl	20022534 <HAL_FLASH_SET_AHB_WCMD>
200243b4:	462b      	mov	r3, r5
200243b6:	464a      	mov	r2, r9
200243b8:	2101      	movs	r1, #1
200243ba:	4620      	mov	r0, r4
200243bc:	f7ff fd08 	bl	20023dd0 <HAL_MPI_SET_FIXLAT>
200243c0:	f64f 71ff 	movw	r1, #65535	@ 0xffff
200243c4:	4620      	mov	r0, r4
200243c6:	f7fe fa75 	bl	200228b4 <HAL_FLASH_SET_WDT>
200243ca:	4630      	mov	r0, r6
200243cc:	b004      	add	sp, #16
200243ce:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200243d2:	4620      	mov	r0, r4
200243d4:	f7ff fe6a 	bl	200240ac <HAL_LEGACY_PSRAM_Init>
200243d8:	4620      	mov	r0, r4
200243da:	f7ff fd6c 	bl	20023eb6 <HAL_LEGACY_CFG_READ>
200243de:	4620      	mov	r0, r4
200243e0:	f7ff fd84 	bl	20023eec <HAL_LEGACY_CFG_WRITE>
200243e4:	2600      	movs	r6, #0
200243e6:	e7eb      	b.n	200243c0 <HAL_MPI_PSRAM_Init+0xb8>
200243e8:	4620      	mov	r0, r4
200243ea:	f7ff fddb 	bl	20023fa4 <HAL_OPI_PSRAM_Init>
200243ee:	2243      	movs	r2, #67	@ 0x43
200243f0:	4606      	mov	r6, r0
200243f2:	2108      	movs	r1, #8
200243f4:	4620      	mov	r0, r4
200243f6:	f7ff fcc7 	bl	20023d88 <HAL_MPI_MR_WRITE>
200243fa:	2101      	movs	r1, #1
200243fc:	4620      	mov	r0, r4
200243fe:	f7fe fa0f 	bl	20022820 <HAL_FLASH_SET_X16_MODE>
20024402:	e799      	b.n	20024338 <HAL_MPI_PSRAM_Init+0x30>
20024404:	2503      	movs	r5, #3
20024406:	e7b1      	b.n	2002436c <HAL_MPI_PSRAM_Init+0x64>
20024408:	2504      	movs	r5, #4
2002440a:	e7af      	b.n	2002436c <HAL_MPI_PSRAM_Init+0x64>
2002440c:	2505      	movs	r5, #5
2002440e:	e7ad      	b.n	2002436c <HAL_MPI_PSRAM_Init+0x64>
20024410:	2506      	movs	r5, #6
20024412:	e7ab      	b.n	2002436c <HAL_MPI_PSRAM_Init+0x64>
20024414:	4620      	mov	r0, r4
20024416:	f7ff ff1f 	bl	20024258 <HAL_HYPER_PSRAM_Init>
2002441a:	4620      	mov	r0, r4
2002441c:	f7ff ff50 	bl	200242c0 <HAL_HYPER_CFG_READ>
20024420:	4620      	mov	r0, r4
20024422:	f7ff ff5f 	bl	200242e4 <HAL_HYPER_CFG_WRITE>
20024426:	e7dd      	b.n	200243e4 <HAL_MPI_PSRAM_Init+0xdc>
20024428:	2600      	movs	r6, #0
2002442a:	2503      	movs	r5, #3
2002442c:	f04f 0801 	mov.w	r8, #1
20024430:	2702      	movs	r7, #2
20024432:	4620      	mov	r0, r4
20024434:	f7ff fc52 	bl	20023cdc <HAL_SPI_PSRAM_Init>
20024438:	4633      	mov	r3, r6
2002443a:	2206      	movs	r2, #6
2002443c:	4629      	mov	r1, r5
2002443e:	4620      	mov	r0, r4
20024440:	e9cd 6700 	strd	r6, r7, [sp]
20024444:	e9cd 5802 	strd	r5, r8, [sp, #8]
20024448:	f7fe f857 	bl	200224fa <HAL_FLASH_CFG_AHB_RCMD>
2002444c:	21eb      	movs	r1, #235	@ 0xeb
2002444e:	4620      	mov	r0, r4
20024450:	f7fe f848 	bl	200224e4 <HAL_FLASH_SET_AHB_RCMD>
20024454:	4633      	mov	r3, r6
20024456:	4632      	mov	r2, r6
20024458:	4629      	mov	r1, r5
2002445a:	4620      	mov	r0, r4
2002445c:	e9cd 6700 	strd	r6, r7, [sp]
20024460:	e9cd 5802 	strd	r5, r8, [sp, #8]
20024464:	f7fe f872 	bl	2002254c <HAL_FLASH_CFG_AHB_WCMD>
20024468:	2138      	movs	r1, #56	@ 0x38
2002446a:	4620      	mov	r0, r4
2002446c:	f7fe f862 	bl	20022534 <HAL_FLASH_SET_AHB_WCMD>
20024470:	4606      	mov	r6, r0
20024472:	e7a5      	b.n	200243c0 <HAL_MPI_PSRAM_Init+0xb8>
20024474:	07de2901 	.word	0x07de2901
20024478:	13c9eb01 	.word	0x13c9eb01
2002447c:	17d78401 	.word	0x17d78401

20024480 <HAL_PIN_Set2>:
20024480:	0a03      	lsrs	r3, r0, #8
20024482:	1e5a      	subs	r2, r3, #1
20024484:	2a53      	cmp	r2, #83	@ 0x53
20024486:	b2c0      	uxtb	r0, r0
20024488:	d80e      	bhi.n	200244a8 <HAL_PIN_Set2+0x28>
2002448a:	4a09      	ldr	r2, [pc, #36]	@ (200244b0 <HAL_PIN_Set2+0x30>)
2002448c:	009b      	lsls	r3, r3, #2
2002448e:	441a      	add	r2, r3
20024490:	6813      	ldr	r3, [r2, #0]
20024492:	f401 7140 	and.w	r1, r1, #768	@ 0x300
20024496:	f36f 0309 	bfc	r3, #0, #10
2002449a:	430b      	orrs	r3, r1
2002449c:	4303      	orrs	r3, r0
2002449e:	f443 6380 	orr.w	r3, r3, #1024	@ 0x400
200244a2:	2000      	movs	r0, #0
200244a4:	6013      	str	r3, [r2, #0]
200244a6:	4770      	bx	lr
200244a8:	f04f 30ff 	mov.w	r0, #4294967295
200244ac:	4770      	bx	lr
200244ae:	bf00      	nop
200244b0:	50002ffc 	.word	0x50002ffc

200244b4 <HAL_PIN_Set>:
200244b4:	3801      	subs	r0, #1
200244b6:	2853      	cmp	r0, #83	@ 0x53
200244b8:	b570      	push	{r4, r5, r6, lr}
200244ba:	f04f 0400 	mov.w	r4, #0
200244be:	d824      	bhi.n	2002450a <HAL_PIN_Set+0x56>
200244c0:	0083      	lsls	r3, r0, #2
200244c2:	f1a1 0510 	sub.w	r5, r1, #16
200244c6:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
200244ca:	2dee      	cmp	r5, #238	@ 0xee
200244cc:	f503 5340 	add.w	r3, r3, #12288	@ 0x3000
200244d0:	d80c      	bhi.n	200244ec <HAL_PIN_Set+0x38>
200244d2:	b2cc      	uxtb	r4, r1
200244d4:	2000      	movs	r0, #0
200244d6:	6819      	ldr	r1, [r3, #0]
200244d8:	f402 7240 	and.w	r2, r2, #768	@ 0x300
200244dc:	4322      	orrs	r2, r4
200244de:	f36f 0109 	bfc	r1, #0, #10
200244e2:	430a      	orrs	r2, r1
200244e4:	f442 6280 	orr.w	r2, r2, #1024	@ 0x400
200244e8:	601a      	str	r2, [r3, #0]
200244ea:	bd70      	pop	{r4, r5, r6, pc}
200244ec:	4d08      	ldr	r5, [pc, #32]	@ (20024510 <HAL_PIN_Set+0x5c>)
200244ee:	f855 0020 	ldr.w	r0, [r5, r0, lsl #2]
200244f2:	f100 0640 	add.w	r6, r0, #64	@ 0x40
200244f6:	8845      	ldrh	r5, [r0, #2]
200244f8:	b13d      	cbz	r5, 2002450a <HAL_PIN_Set+0x56>
200244fa:	428d      	cmp	r5, r1
200244fc:	d101      	bne.n	20024502 <HAL_PIN_Set+0x4e>
200244fe:	7804      	ldrb	r4, [r0, #0]
20024500:	e7e8      	b.n	200244d4 <HAL_PIN_Set+0x20>
20024502:	3004      	adds	r0, #4
20024504:	42b0      	cmp	r0, r6
20024506:	d1f6      	bne.n	200244f6 <HAL_PIN_Set+0x42>
20024508:	e7e4      	b.n	200244d4 <HAL_PIN_Set+0x20>
2002450a:	f04f 30ff 	mov.w	r0, #4294967295
2002450e:	e7ec      	b.n	200244ea <HAL_PIN_Set+0x36>
20024510:	20027060 	.word	0x20027060

20024514 <HAL_PIN_Set_DS0>:
20024514:	2854      	cmp	r0, #84	@ 0x54
20024516:	dc0e      	bgt.n	20024536 <HAL_PIN_Set_DS0+0x22>
20024518:	b168      	cbz	r0, 20024536 <HAL_PIN_Set_DS0+0x22>
2002451a:	4b08      	ldr	r3, [pc, #32]	@ (2002453c <HAL_PIN_Set_DS0+0x28>)
2002451c:	0080      	lsls	r0, r0, #2
2002451e:	4403      	add	r3, r0
20024520:	b12a      	cbz	r2, 2002452e <HAL_PIN_Set_DS0+0x1a>
20024522:	681a      	ldr	r2, [r3, #0]
20024524:	f442 5200 	orr.w	r2, r2, #8192	@ 0x2000
20024528:	2000      	movs	r0, #0
2002452a:	601a      	str	r2, [r3, #0]
2002452c:	4770      	bx	lr
2002452e:	681a      	ldr	r2, [r3, #0]
20024530:	f422 5200 	bic.w	r2, r2, #8192	@ 0x2000
20024534:	e7f8      	b.n	20024528 <HAL_PIN_Set_DS0+0x14>
20024536:	f04f 30ff 	mov.w	r0, #4294967295
2002453a:	4770      	bx	lr
2002453c:	50002ffc 	.word	0x50002ffc

20024540 <HAL_PIN_Set_DS1>:
20024540:	2854      	cmp	r0, #84	@ 0x54
20024542:	dc0e      	bgt.n	20024562 <HAL_PIN_Set_DS1+0x22>
20024544:	b168      	cbz	r0, 20024562 <HAL_PIN_Set_DS1+0x22>
20024546:	4b08      	ldr	r3, [pc, #32]	@ (20024568 <HAL_PIN_Set_DS1+0x28>)
20024548:	0080      	lsls	r0, r0, #2
2002454a:	4403      	add	r3, r0
2002454c:	b12a      	cbz	r2, 2002455a <HAL_PIN_Set_DS1+0x1a>
2002454e:	681a      	ldr	r2, [r3, #0]
20024550:	f442 4280 	orr.w	r2, r2, #16384	@ 0x4000
20024554:	2000      	movs	r0, #0
20024556:	601a      	str	r2, [r3, #0]
20024558:	4770      	bx	lr
2002455a:	681a      	ldr	r2, [r3, #0]
2002455c:	f422 4280 	bic.w	r2, r2, #16384	@ 0x4000
20024560:	e7f8      	b.n	20024554 <HAL_PIN_Set_DS1+0x14>
20024562:	f04f 30ff 	mov.w	r0, #4294967295
20024566:	4770      	bx	lr
20024568:	50002ffc 	.word	0x50002ffc

2002456c <HAL_PMU_EnableDLL>:
2002456c:	4b05      	ldr	r3, [pc, #20]	@ (20024584 <HAL_PMU_EnableDLL+0x18>)
2002456e:	6eda      	ldr	r2, [r3, #108]	@ 0x6c
20024570:	b120      	cbz	r0, 2002457c <HAL_PMU_EnableDLL+0x10>
20024572:	f042 0220 	orr.w	r2, r2, #32
20024576:	2000      	movs	r0, #0
20024578:	66da      	str	r2, [r3, #108]	@ 0x6c
2002457a:	4770      	bx	lr
2002457c:	f022 0220 	bic.w	r2, r2, #32
20024580:	e7f9      	b.n	20024576 <HAL_PMU_EnableDLL+0xa>
20024582:	bf00      	nop
20024584:	500ca000 	.word	0x500ca000

20024588 <HAL_PMU_LoadCalData>:
20024588:	b510      	push	{r4, lr}
2002458a:	4c27      	ldr	r4, [pc, #156]	@ (20024628 <HAL_PMU_LoadCalData+0xa0>)
2002458c:	220f      	movs	r2, #15
2002458e:	4621      	mov	r1, r4
20024590:	2006      	movs	r0, #6
20024592:	f000 fb97 	bl	20024cc4 <BSP_CONFIG_get>
20024596:	2800      	cmp	r0, #0
20024598:	dd44      	ble.n	20024624 <HAL_PMU_LoadCalData+0x9c>
2002459a:	2301      	movs	r3, #1
2002459c:	7862      	ldrb	r2, [r4, #1]
2002459e:	f804 3c01 	strb.w	r3, [r4, #-1]
200245a2:	7821      	ldrb	r1, [r4, #0]
200245a4:	4b21      	ldr	r3, [pc, #132]	@ (2002462c <HAL_PMU_LoadCalData+0xa4>)
200245a6:	0792      	lsls	r2, r2, #30
200245a8:	6ad8      	ldr	r0, [r3, #44]	@ 0x2c
200245aa:	0649      	lsls	r1, r1, #25
200245ac:	f001 6160 	and.w	r1, r1, #234881024	@ 0xe000000
200245b0:	f002 4280 	and.w	r2, r2, #1073741824	@ 0x40000000
200245b4:	430a      	orrs	r2, r1
200245b6:	f020 419c 	bic.w	r1, r0, #1308622848	@ 0x4e000000
200245ba:	430a      	orrs	r2, r1
200245bc:	62da      	str	r2, [r3, #44]	@ 0x2c
200245be:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
200245c2:	78e1      	ldrb	r1, [r4, #3]
200245c4:	f361 0203 	bfi	r2, r1, #0, #4
200245c8:	f8c3 2094 	str.w	r2, [r3, #148]	@ 0x94
200245cc:	695a      	ldr	r2, [r3, #20]
200245ce:	7921      	ldrb	r1, [r4, #4]
200245d0:	f361 228d 	bfi	r2, r1, #10, #4
200245d4:	615a      	str	r2, [r3, #20]
200245d6:	7962      	ldrb	r2, [r4, #5]
200245d8:	79a0      	ldrb	r0, [r4, #6]
200245da:	6e19      	ldr	r1, [r3, #96]	@ 0x60
200245dc:	00d2      	lsls	r2, r2, #3
200245de:	02c0      	lsls	r0, r0, #11
200245e0:	f002 0278 	and.w	r2, r2, #120	@ 0x78
200245e4:	f400 40f0 	and.w	r0, r0, #30720	@ 0x7800
200245e8:	f021 1178 	bic.w	r1, r1, #7864440	@ 0x780078
200245ec:	f421 41f0 	bic.w	r1, r1, #30720	@ 0x7800
200245f0:	4302      	orrs	r2, r0
200245f2:	430a      	orrs	r2, r1
200245f4:	79e1      	ldrb	r1, [r4, #7]
200245f6:	04c9      	lsls	r1, r1, #19
200245f8:	f401 01f0 	and.w	r1, r1, #7864320	@ 0x780000
200245fc:	430a      	orrs	r2, r1
200245fe:	661a      	str	r2, [r3, #96]	@ 0x60
20024600:	6a59      	ldr	r1, [r3, #36]	@ 0x24
20024602:	7a22      	ldrb	r2, [r4, #8]
20024604:	f021 0127 	bic.w	r1, r1, #39	@ 0x27
20024608:	f002 0207 	and.w	r2, r2, #7
2002460c:	430a      	orrs	r2, r1
2002460e:	7a61      	ldrb	r1, [r4, #9]
20024610:	0149      	lsls	r1, r1, #5
20024612:	f001 0120 	and.w	r1, r1, #32
20024616:	430a      	orrs	r2, r1
20024618:	625a      	str	r2, [r3, #36]	@ 0x24
2002461a:	6a9a      	ldr	r2, [r3, #40]	@ 0x28
2002461c:	7ba1      	ldrb	r1, [r4, #14]
2002461e:	f361 0203 	bfi	r2, r1, #0, #4
20024622:	629a      	str	r2, [r3, #40]	@ 0x28
20024624:	bd10      	pop	{r4, pc}
20024626:	bf00      	nop
20024628:	2004ca65 	.word	0x2004ca65
2002462c:	500ca000 	.word	0x500ca000

20024630 <HAL_RCC_HCPU_ConfigSxModeVolt>:
20024630:	b507      	push	{r0, r1, r2, lr}
20024632:	4a13      	ldr	r2, [pc, #76]	@ (20024680 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
20024634:	4913      	ldr	r1, [pc, #76]	@ (20024684 <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20024636:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
2002463a:	f8d1 3098 	ldr.w	r3, [r1, #152]	@ 0x98
2002463e:	7892      	ldrb	r2, [r2, #2]
20024640:	2802      	cmp	r0, #2
20024642:	f362 0304 	bfi	r3, r2, #0, #5
20024646:	f8c1 3098 	str.w	r3, [r1, #152]	@ 0x98
2002464a:	f10d 0007 	add.w	r0, sp, #7
2002464e:	d111      	bne.n	20024674 <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
20024650:	f003 fbea 	bl	20027e28 <HAL_PMU_GetHpsysVoutRef>
20024654:	b110      	cbz	r0, 2002465c <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20024656:	230b      	movs	r3, #11
20024658:	f88d 3007 	strb.w	r3, [sp, #7]
2002465c:	4a09      	ldr	r2, [pc, #36]	@ (20024684 <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
2002465e:	f89d 1007 	ldrb.w	r1, [sp, #7]
20024662:	f8d2 3090 	ldr.w	r3, [r2, #144]	@ 0x90
20024666:	f361 0303 	bfi	r3, r1, #0, #4
2002466a:	f8c2 3090 	str.w	r3, [r2, #144]	@ 0x90
2002466e:	b003      	add	sp, #12
20024670:	f85d fb04 	ldr.w	pc, [sp], #4
20024674:	f003 fbe4 	bl	20027e40 <HAL_PMU_GetHpsysVoutRef2>
20024678:	2800      	cmp	r0, #0
2002467a:	d0ef      	beq.n	2002465c <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
2002467c:	230e      	movs	r3, #14
2002467e:	e7eb      	b.n	20024658 <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
20024680:	20027684 	.word	0x20027684
20024684:	500ca000 	.word	0x500ca000

20024688 <HAL_RCC_HCPU_GetClockSrc>:
20024688:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002468c:	2810      	cmp	r0, #16
2002468e:	6a1a      	ldr	r2, [r3, #32]
20024690:	d80c      	bhi.n	200246ac <HAL_RCC_HCPU_GetClockSrc+0x24>
20024692:	4b07      	ldr	r3, [pc, #28]	@ (200246b0 <HAL_RCC_HCPU_GetClockSrc+0x28>)
20024694:	40c3      	lsrs	r3, r0
20024696:	f013 0f01 	tst.w	r3, #1
2002469a:	bf0c      	ite	eq
2002469c:	2301      	moveq	r3, #1
2002469e:	2303      	movne	r3, #3
200246a0:	4083      	lsls	r3, r0
200246a2:	4013      	ands	r3, r2
200246a4:	fa23 f000 	lsr.w	r0, r3, r0
200246a8:	b2c0      	uxtb	r0, r0
200246aa:	4770      	bx	lr
200246ac:	2301      	movs	r3, #1
200246ae:	e7f7      	b.n	200246a0 <HAL_RCC_HCPU_GetClockSrc+0x18>
200246b0:	00012ff1 	.word	0x00012ff1

200246b4 <HAL_RCC_HCPU_GetDLLFreq>:
200246b4:	2801      	cmp	r0, #1
200246b6:	d003      	beq.n	200246c0 <HAL_RCC_HCPU_GetDLLFreq+0xc>
200246b8:	2802      	cmp	r0, #2
200246ba:	d00e      	beq.n	200246da <HAL_RCC_HCPU_GetDLLFreq+0x26>
200246bc:	2000      	movs	r0, #0
200246be:	4770      	bx	lr
200246c0:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200246c4:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
200246c6:	b163      	cbz	r3, 200246e2 <HAL_RCC_HCPU_GetDLLFreq+0x2e>
200246c8:	f013 0001 	ands.w	r0, r3, #1
200246cc:	d00a      	beq.n	200246e4 <HAL_RCC_HCPU_GetDLLFreq+0x30>
200246ce:	4806      	ldr	r0, [pc, #24]	@ (200246e8 <HAL_RCC_HCPU_GetDLLFreq+0x34>)
200246d0:	f3c3 0383 	ubfx	r3, r3, #2, #4
200246d4:	fb03 0000 	mla	r0, r3, r0, r0
200246d8:	4770      	bx	lr
200246da:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200246de:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
200246e0:	e7f1      	b.n	200246c6 <HAL_RCC_HCPU_GetDLLFreq+0x12>
200246e2:	4618      	mov	r0, r3
200246e4:	4770      	bx	lr
200246e6:	bf00      	nop
200246e8:	016e3600 	.word	0x016e3600

200246ec <HAL_RCC_HCPU_GetDLL1Freq>:
200246ec:	2001      	movs	r0, #1
200246ee:	f7ff bfe1 	b.w	200246b4 <HAL_RCC_HCPU_GetDLLFreq>
	...

200246f4 <HAL_RCC_GetSysCLKFreq.part.0>:
200246f4:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200246f8:	6a1b      	ldr	r3, [r3, #32]
200246fa:	f003 0303 	and.w	r3, r3, #3
200246fe:	2b03      	cmp	r3, #3
20024700:	d101      	bne.n	20024706 <HAL_RCC_GetSysCLKFreq.part.0+0x12>
20024702:	f7ff bff3 	b.w	200246ec <HAL_RCC_HCPU_GetDLL1Freq>
20024706:	4801      	ldr	r0, [pc, #4]	@ (2002470c <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
20024708:	4770      	bx	lr
2002470a:	bf00      	nop
2002470c:	02dc6c00 	.word	0x02dc6c00

20024710 <HAL_RCC_HCPU_GetDLL2Freq>:
20024710:	2002      	movs	r0, #2
20024712:	f7ff bfcf 	b.w	200246b4 <HAL_RCC_HCPU_GetDLLFreq>

20024716 <HAL_RCC_HCPU_GetDLL3Freq>:
20024716:	2000      	movs	r0, #0
20024718:	4770      	bx	lr
	...

2002471c <HAL_RCC_HCPU_EnableDLL>:
2002471c:	4b1a      	ldr	r3, [pc, #104]	@ (20024788 <HAL_RCC_HCPU_EnableDLL+0x6c>)
2002471e:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
20024722:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
20024726:	4299      	cmp	r1, r3
20024728:	b510      	push	{r4, lr}
2002472a:	d82a      	bhi.n	20024782 <HAL_RCC_HCPU_EnableDLL+0x66>
2002472c:	2801      	cmp	r0, #1
2002472e:	d002      	beq.n	20024736 <HAL_RCC_HCPU_EnableDLL+0x1a>
20024730:	2802      	cmp	r0, #2
20024732:	d024      	beq.n	2002477e <HAL_RCC_HCPU_EnableDLL+0x62>
20024734:	e7fe      	b.n	20024734 <HAL_RCC_HCPU_EnableDLL+0x18>
20024736:	4c15      	ldr	r4, [pc, #84]	@ (2002478c <HAL_RCC_HCPU_EnableDLL+0x70>)
20024738:	4a15      	ldr	r2, [pc, #84]	@ (20024790 <HAL_RCC_HCPU_EnableDLL+0x74>)
2002473a:	2000      	movs	r0, #0
2002473c:	6c53      	ldr	r3, [r2, #68]	@ 0x44
2002473e:	f043 0301 	orr.w	r3, r3, #1
20024742:	6453      	str	r3, [r2, #68]	@ 0x44
20024744:	4a13      	ldr	r2, [pc, #76]	@ (20024794 <HAL_RCC_HCPU_EnableDLL+0x78>)
20024746:	6823      	ldr	r3, [r4, #0]
20024748:	fbb1 f1f2 	udiv	r1, r1, r2
2002474c:	f023 0301 	bic.w	r3, r3, #1
20024750:	6023      	str	r3, [r4, #0]
20024752:	6823      	ldr	r3, [r4, #0]
20024754:	f423 4380 	bic.w	r3, r3, #16384	@ 0x4000
20024758:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
2002475c:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
20024760:	f443 5300 	orr.w	r3, r3, #8192	@ 0x2000
20024764:	f043 0301 	orr.w	r3, r3, #1
20024768:	6023      	str	r3, [r4, #0]
2002476a:	f7fd f942 	bl	200219f2 <HAL_Delay_us>
2002476e:	200a      	movs	r0, #10
20024770:	f7fd f93f 	bl	200219f2 <HAL_Delay_us>
20024774:	6823      	ldr	r3, [r4, #0]
20024776:	2b00      	cmp	r3, #0
20024778:	dafc      	bge.n	20024774 <HAL_RCC_HCPU_EnableDLL+0x58>
2002477a:	2000      	movs	r0, #0
2002477c:	bd10      	pop	{r4, pc}
2002477e:	4c06      	ldr	r4, [pc, #24]	@ (20024798 <HAL_RCC_HCPU_EnableDLL+0x7c>)
20024780:	e7da      	b.n	20024738 <HAL_RCC_HCPU_EnableDLL+0x1c>
20024782:	2001      	movs	r0, #1
20024784:	e7fa      	b.n	2002477c <HAL_RCC_HCPU_EnableDLL+0x60>
20024786:	bf00      	nop
20024788:	15752a00 	.word	0x15752a00
2002478c:	5000002c 	.word	0x5000002c
20024790:	5000b000 	.word	0x5000b000
20024794:	016e3600 	.word	0x016e3600
20024798:	50000030 	.word	0x50000030

2002479c <HAL_RCC_HCPU_EnableDLL1>:
2002479c:	4601      	mov	r1, r0
2002479e:	2001      	movs	r0, #1
200247a0:	f7ff bfbc 	b.w	2002471c <HAL_RCC_HCPU_EnableDLL>

200247a4 <HAL_RCC_HCPU_EnableDLL2>:
200247a4:	4601      	mov	r1, r0
200247a6:	2002      	movs	r0, #2
200247a8:	f7ff bfb8 	b.w	2002471c <HAL_RCC_HCPU_EnableDLL>

200247ac <HAL_RCC_HCPU_DisableDLL1>:
200247ac:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
200247b0:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
200247b2:	2000      	movs	r0, #0
200247b4:	f023 0301 	bic.w	r3, r3, #1
200247b8:	62d3      	str	r3, [r2, #44]	@ 0x2c
200247ba:	4770      	bx	lr

200247bc <HAL_RCC_HCPU_DisableDLL2>:
200247bc:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
200247c0:	6b13      	ldr	r3, [r2, #48]	@ 0x30
200247c2:	2000      	movs	r0, #0
200247c4:	f023 0301 	bic.w	r3, r3, #1
200247c8:	6313      	str	r3, [r2, #48]	@ 0x30
200247ca:	4770      	bx	lr

200247cc <HAL_RCC_GetSysCLKFreq>:
200247cc:	2801      	cmp	r0, #1
200247ce:	d101      	bne.n	200247d4 <HAL_RCC_GetSysCLKFreq+0x8>
200247d0:	f7ff bf90 	b.w	200246f4 <HAL_RCC_GetSysCLKFreq.part.0>
200247d4:	4800      	ldr	r0, [pc, #0]	@ (200247d8 <HAL_RCC_GetSysCLKFreq+0xc>)
200247d6:	4770      	bx	lr
200247d8:	02dc6c00 	.word	0x02dc6c00

200247dc <HAL_RCC_GetHCLKFreq>:
200247dc:	1e02      	subs	r2, r0, #0
200247de:	bf08      	it	eq
200247e0:	2201      	moveq	r2, #1
200247e2:	b508      	push	{r3, lr}
200247e4:	4610      	mov	r0, r2
200247e6:	f7ff fff1 	bl	200247cc <HAL_RCC_GetSysCLKFreq>
200247ea:	2a01      	cmp	r2, #1
200247ec:	d002      	beq.n	200247f4 <HAL_RCC_GetHCLKFreq+0x18>
200247ee:	2a02      	cmp	r2, #2
200247f0:	d00a      	beq.n	20024808 <HAL_RCC_GetHCLKFreq+0x2c>
200247f2:	e7fe      	b.n	200247f2 <HAL_RCC_GetHCLKFreq+0x16>
200247f4:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200247f8:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
200247fa:	b2db      	uxtb	r3, r3
200247fc:	2b01      	cmp	r3, #1
200247fe:	bfb8      	it	lt
20024800:	2301      	movlt	r3, #1
20024802:	fbb0 f0f3 	udiv	r0, r0, r3
20024806:	bd08      	pop	{r3, pc}
20024808:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
2002480c:	695b      	ldr	r3, [r3, #20]
2002480e:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
20024812:	e7f3      	b.n	200247fc <HAL_RCC_GetHCLKFreq+0x20>

20024814 <HAL_RCC_HCPU_ClockSelect>:
20024814:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024818:	b510      	push	{r4, lr}
2002481a:	2810      	cmp	r0, #16
2002481c:	6a1b      	ldr	r3, [r3, #32]
2002481e:	d817      	bhi.n	20024850 <HAL_RCC_HCPU_ClockSelect+0x3c>
20024820:	4a0c      	ldr	r2, [pc, #48]	@ (20024854 <HAL_RCC_HCPU_ClockSelect+0x40>)
20024822:	40c2      	lsrs	r2, r0
20024824:	f012 0f01 	tst.w	r2, #1
20024828:	bf0c      	ite	eq
2002482a:	2201      	moveq	r2, #1
2002482c:	2203      	movne	r2, #3
2002482e:	fa02 f400 	lsl.w	r4, r2, r0
20024832:	4011      	ands	r1, r2
20024834:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024838:	ea23 0304 	bic.w	r3, r3, r4
2002483c:	4081      	lsls	r1, r0
2002483e:	430b      	orrs	r3, r1
20024840:	6213      	str	r3, [r2, #32]
20024842:	b920      	cbnz	r0, 2002484e <HAL_RCC_HCPU_ClockSelect+0x3a>
20024844:	2001      	movs	r0, #1
20024846:	f7ff ffc9 	bl	200247dc <HAL_RCC_GetHCLKFreq>
2002484a:	4b03      	ldr	r3, [pc, #12]	@ (20024858 <HAL_RCC_HCPU_ClockSelect+0x44>)
2002484c:	6018      	str	r0, [r3, #0]
2002484e:	bd10      	pop	{r4, pc}
20024850:	2201      	movs	r2, #1
20024852:	e7ec      	b.n	2002482e <HAL_RCC_HCPU_ClockSelect+0x1a>
20024854:	00012ff1 	.word	0x00012ff1
20024858:	20042c14 	.word	0x20042c14

2002485c <HAL_RCC_HCPU_SetDiv>:
2002485c:	2800      	cmp	r0, #0
2002485e:	bfd8      	it	le
20024860:	2000      	movle	r0, #0
20024862:	b508      	push	{r3, lr}
20024864:	bfcc      	ite	gt
20024866:	23ff      	movgt	r3, #255	@ 0xff
20024868:	4603      	movle	r3, r0
2002486a:	2900      	cmp	r1, #0
2002486c:	db12      	blt.n	20024894 <HAL_RCC_HCPU_SetDiv+0x38>
2002486e:	2a00      	cmp	r2, #0
20024870:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
20024874:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
20024878:	da0e      	bge.n	20024898 <HAL_RCC_HCPU_SetDiv+0x3c>
2002487a:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
2002487e:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
20024880:	ea22 0303 	bic.w	r3, r2, r3
20024884:	4303      	orrs	r3, r0
20024886:	624b      	str	r3, [r1, #36]	@ 0x24
20024888:	2001      	movs	r0, #1
2002488a:	f7ff ffa7 	bl	200247dc <HAL_RCC_GetHCLKFreq>
2002488e:	4b07      	ldr	r3, [pc, #28]	@ (200248ac <HAL_RCC_HCPU_SetDiv+0x50>)
20024890:	6018      	str	r0, [r3, #0]
20024892:	bd08      	pop	{r3, pc}
20024894:	2a00      	cmp	r2, #0
20024896:	db04      	blt.n	200248a2 <HAL_RCC_HCPU_SetDiv+0x46>
20024898:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
2002489c:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
200248a0:	e7eb      	b.n	2002487a <HAL_RCC_HCPU_SetDiv+0x1e>
200248a2:	2b00      	cmp	r3, #0
200248a4:	d0f0      	beq.n	20024888 <HAL_RCC_HCPU_SetDiv+0x2c>
200248a6:	23ff      	movs	r3, #255	@ 0xff
200248a8:	e7e7      	b.n	2002487a <HAL_RCC_HCPU_SetDiv+0x1e>
200248aa:	bf00      	nop
200248ac:	20042c14 	.word	0x20042c14

200248b0 <HAL_RCC_HCPU_SwitchDvfsD2S>:
200248b0:	b570      	push	{r4, r5, r6, lr}
200248b2:	460c      	mov	r4, r1
200248b4:	4d19      	ldr	r5, [pc, #100]	@ (2002491c <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
200248b6:	4606      	mov	r6, r0
200248b8:	f7ff feba 	bl	20024630 <HAL_RCC_HCPU_ConfigSxModeVolt>
200248bc:	692b      	ldr	r3, [r5, #16]
200248be:	20fa      	movs	r0, #250	@ 0xfa
200248c0:	f023 0301 	bic.w	r3, r3, #1
200248c4:	612b      	str	r3, [r5, #16]
200248c6:	f7fd f894 	bl	200219f2 <HAL_Delay_us>
200248ca:	2c30      	cmp	r4, #48	@ 0x30
200248cc:	d80d      	bhi.n	200248ea <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
200248ce:	2100      	movs	r1, #0
200248d0:	4608      	mov	r0, r1
200248d2:	f7ff ff9f 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
200248d6:	2030      	movs	r0, #48	@ 0x30
200248d8:	2204      	movs	r2, #4
200248da:	2100      	movs	r1, #0
200248dc:	fbb0 f0f4 	udiv	r0, r0, r4
200248e0:	f7ff ffbc 	bl	2002485c <HAL_RCC_HCPU_SetDiv>
200248e4:	2400      	movs	r4, #0
200248e6:	4620      	mov	r0, r4
200248e8:	bd70      	pop	{r4, r5, r6, pc}
200248ea:	f7fd fdc5 	bl	20022478 <HAL_HPAON_EnableXT48>
200248ee:	480c      	ldr	r0, [pc, #48]	@ (20024920 <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
200248f0:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
200248f4:	6843      	ldr	r3, [r0, #4]
200248f6:	480b      	ldr	r0, [pc, #44]	@ (20024924 <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
200248f8:	61eb      	str	r3, [r5, #28]
200248fa:	4360      	muls	r0, r4
200248fc:	f7ff ff4e 	bl	2002479c <HAL_RCC_HCPU_EnableDLL1>
20024900:	4604      	mov	r4, r0
20024902:	2800      	cmp	r0, #0
20024904:	d1ef      	bne.n	200248e6 <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
20024906:	2101      	movs	r1, #1
20024908:	2206      	movs	r2, #6
2002490a:	4608      	mov	r0, r1
2002490c:	f7ff ffa6 	bl	2002485c <HAL_RCC_HCPU_SetDiv>
20024910:	2103      	movs	r1, #3
20024912:	4620      	mov	r0, r4
20024914:	f7ff ff7e 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20024918:	e7e4      	b.n	200248e4 <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
2002491a:	bf00      	nop
2002491c:	5000b000 	.word	0x5000b000
20024920:	20027684 	.word	0x20027684
20024924:	000f4240 	.word	0x000f4240

20024928 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
20024928:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
2002492c:	4c1d      	ldr	r4, [pc, #116]	@ (200249a4 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
2002492e:	4f1e      	ldr	r7, [pc, #120]	@ (200249a8 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
20024930:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
20024934:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
20024936:	7892      	ldrb	r2, [r2, #2]
20024938:	4605      	mov	r5, r0
2002493a:	f362 4396 	bfi	r3, r2, #18, #5
2002493e:	ea4f 08c0 	mov.w	r8, r0, lsl #3
20024942:	633b      	str	r3, [r7, #48]	@ 0x30
20024944:	f10d 0007 	add.w	r0, sp, #7
20024948:	460e      	mov	r6, r1
2002494a:	f003 fa6d 	bl	20027e28 <HAL_PMU_GetHpsysVoutRef>
2002494e:	b110      	cbz	r0, 20024956 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
20024950:	230b      	movs	r3, #11
20024952:	f88d 3007 	strb.w	r3, [sp, #7]
20024956:	f89d 1007 	ldrb.w	r1, [sp, #7]
2002495a:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
2002495e:	6d3b      	ldr	r3, [r7, #80]	@ 0x50
20024960:	440a      	add	r2, r1
20024962:	2100      	movs	r1, #0
20024964:	f362 0385 	bfi	r3, r2, #2, #4
20024968:	4608      	mov	r0, r1
2002496a:	653b      	str	r3, [r7, #80]	@ 0x50
2002496c:	f7ff ff52 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20024970:	2e30      	cmp	r6, #48	@ 0x30
20024972:	d900      	bls.n	20024976 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
20024974:	e7fe      	b.n	20024974 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
20024976:	2030      	movs	r0, #48	@ 0x30
20024978:	2204      	movs	r2, #4
2002497a:	2100      	movs	r1, #0
2002497c:	fbb0 f0f6 	udiv	r0, r0, r6
20024980:	f7ff ff6c 	bl	2002485c <HAL_RCC_HCPU_SetDiv>
20024984:	f7ff ff12 	bl	200247ac <HAL_RCC_HCPU_DisableDLL1>
20024988:	f7fd fd82 	bl	20022490 <HAL_HPAON_DisableXT48>
2002498c:	4444      	add	r4, r8
2002498e:	4b07      	ldr	r3, [pc, #28]	@ (200249ac <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
20024990:	6862      	ldr	r2, [r4, #4]
20024992:	61da      	str	r2, [r3, #28]
20024994:	691a      	ldr	r2, [r3, #16]
20024996:	f042 0201 	orr.w	r2, r2, #1
2002499a:	611a      	str	r2, [r3, #16]
2002499c:	b002      	add	sp, #8
2002499e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200249a2:	bf00      	nop
200249a4:	20027684 	.word	0x20027684
200249a8:	500ca000 	.word	0x500ca000
200249ac:	5000b000 	.word	0x5000b000

200249b0 <HAL_RCC_HCPU_ConfigDvfs>:
200249b0:	b570      	push	{r4, r5, r6, lr}
200249b2:	4e31      	ldr	r6, [pc, #196]	@ (20024a78 <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
200249b4:	4605      	mov	r5, r0
200249b6:	7833      	ldrb	r3, [r6, #0]
200249b8:	460c      	mov	r4, r1
200249ba:	2b01      	cmp	r3, #1
200249bc:	d943      	bls.n	20024a46 <HAL_RCC_HCPU_ConfigDvfs+0x96>
200249be:	3b02      	subs	r3, #2
200249c0:	2b01      	cmp	r3, #1
200249c2:	d902      	bls.n	200249ca <HAL_RCC_HCPU_ConfigDvfs+0x1a>
200249c4:	2501      	movs	r5, #1
200249c6:	4628      	mov	r0, r5
200249c8:	bd70      	pop	{r4, r5, r6, pc}
200249ca:	4b2c      	ldr	r3, [pc, #176]	@ (20024a7c <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
200249cc:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
200249d0:	f7ff fe9e 	bl	20024710 <HAL_RCC_HCPU_GetDLL2Freq>
200249d4:	4290      	cmp	r0, r2
200249d6:	d8f5      	bhi.n	200249c4 <HAL_RCC_HCPU_ConfigDvfs+0x14>
200249d8:	2901      	cmp	r1, #1
200249da:	d805      	bhi.n	200249e8 <HAL_RCC_HCPU_ConfigDvfs+0x38>
200249dc:	4629      	mov	r1, r5
200249de:	4620      	mov	r0, r4
200249e0:	f7ff ffa2 	bl	20024928 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
200249e4:	2500      	movs	r5, #0
200249e6:	e035      	b.n	20024a54 <HAL_RCC_HCPU_ConfigDvfs+0xa4>
200249e8:	2100      	movs	r1, #0
200249ea:	4608      	mov	r0, r1
200249ec:	f7ff ff12 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
200249f0:	4620      	mov	r0, r4
200249f2:	f7ff fe1d 	bl	20024630 <HAL_RCC_HCPU_ConfigSxModeVolt>
200249f6:	20fa      	movs	r0, #250	@ 0xfa
200249f8:	f7fc fffb 	bl	200219f2 <HAL_Delay_us>
200249fc:	f7ff fed6 	bl	200247ac <HAL_RCC_HCPU_DisableDLL1>
20024a00:	2d30      	cmp	r5, #48	@ 0x30
20024a02:	d80d      	bhi.n	20024a20 <HAL_RCC_HCPU_ConfigDvfs+0x70>
20024a04:	f7fd fd44 	bl	20022490 <HAL_HPAON_DisableXT48>
20024a08:	2100      	movs	r1, #0
20024a0a:	4608      	mov	r0, r1
20024a0c:	f7ff ff02 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20024a10:	2204      	movs	r2, #4
20024a12:	2100      	movs	r1, #0
20024a14:	2030      	movs	r0, #48	@ 0x30
20024a16:	fbb0 f0f5 	udiv	r0, r0, r5
20024a1a:	f7ff ff1f 	bl	2002485c <HAL_RCC_HCPU_SetDiv>
20024a1e:	e7e1      	b.n	200249e4 <HAL_RCC_HCPU_ConfigDvfs+0x34>
20024a20:	f7fd fd2a 	bl	20022478 <HAL_HPAON_EnableXT48>
20024a24:	4816      	ldr	r0, [pc, #88]	@ (20024a80 <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
20024a26:	4368      	muls	r0, r5
20024a28:	f7ff feb8 	bl	2002479c <HAL_RCC_HCPU_EnableDLL1>
20024a2c:	4605      	mov	r5, r0
20024a2e:	2800      	cmp	r0, #0
20024a30:	d1c8      	bne.n	200249c4 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20024a32:	2101      	movs	r1, #1
20024a34:	2206      	movs	r2, #6
20024a36:	4608      	mov	r0, r1
20024a38:	f7ff ff10 	bl	2002485c <HAL_RCC_HCPU_SetDiv>
20024a3c:	2103      	movs	r1, #3
20024a3e:	4628      	mov	r0, r5
20024a40:	f7ff fee8 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20024a44:	e7ce      	b.n	200249e4 <HAL_RCC_HCPU_ConfigDvfs+0x34>
20024a46:	2901      	cmp	r1, #1
20024a48:	d909      	bls.n	20024a5e <HAL_RCC_HCPU_ConfigDvfs+0xae>
20024a4a:	4601      	mov	r1, r0
20024a4c:	4620      	mov	r0, r4
20024a4e:	f7ff ff2f 	bl	200248b0 <HAL_RCC_HCPU_SwitchDvfsD2S>
20024a52:	4605      	mov	r5, r0
20024a54:	2000      	movs	r0, #0
20024a56:	7034      	strb	r4, [r6, #0]
20024a58:	f7fc ffcb 	bl	200219f2 <HAL_Delay_us>
20024a5c:	e7b3      	b.n	200249c6 <HAL_RCC_HCPU_ConfigDvfs+0x16>
20024a5e:	428b      	cmp	r3, r1
20024a60:	d103      	bne.n	20024a6a <HAL_RCC_HCPU_ConfigDvfs+0xba>
20024a62:	f04f 32ff 	mov.w	r2, #4294967295
20024a66:	4611      	mov	r1, r2
20024a68:	e7d4      	b.n	20024a14 <HAL_RCC_HCPU_ConfigDvfs+0x64>
20024a6a:	2190      	movs	r1, #144	@ 0x90
20024a6c:	2002      	movs	r0, #2
20024a6e:	f7ff ff1f 	bl	200248b0 <HAL_RCC_HCPU_SwitchDvfsD2S>
20024a72:	2800      	cmp	r0, #0
20024a74:	d1a6      	bne.n	200249c4 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20024a76:	e7b1      	b.n	200249dc <HAL_RCC_HCPU_ConfigDvfs+0x2c>
20024a78:	20042c18 	.word	0x20042c18
20024a7c:	20027674 	.word	0x20027674
20024a80:	000f4240 	.word	0x000f4240

20024a84 <HAL_RCC_EnableModule>:
20024a84:	1c43      	adds	r3, r0, #1
20024a86:	d014      	beq.n	20024ab2 <HAL_RCC_EnableModule+0x2e>
20024a88:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
20024a8c:	b282      	uxth	r2, r0
20024a8e:	d000      	beq.n	20024a92 <HAL_RCC_EnableModule+0xe>
20024a90:	e7fe      	b.n	20024a90 <HAL_RCC_EnableModule+0xc>
20024a92:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
20024a96:	f3c0 2181 	ubfx	r1, r0, #10, #2
20024a9a:	f3c0 2301 	ubfx	r3, r0, #8, #2
20024a9e:	b2d2      	uxtb	r2, r2
20024aa0:	d108      	bne.n	20024ab4 <HAL_RCC_EnableModule+0x30>
20024aa2:	009b      	lsls	r3, r3, #2
20024aa4:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20024aa8:	3310      	adds	r3, #16
20024aaa:	2101      	movs	r1, #1
20024aac:	fa01 f202 	lsl.w	r2, r1, r2
20024ab0:	601a      	str	r2, [r3, #0]
20024ab2:	4770      	bx	lr
20024ab4:	2901      	cmp	r1, #1
20024ab6:	d104      	bne.n	20024ac2 <HAL_RCC_EnableModule+0x3e>
20024ab8:	009b      	lsls	r3, r3, #2
20024aba:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
20024abe:	3308      	adds	r3, #8
20024ac0:	e7f3      	b.n	20024aaa <HAL_RCC_EnableModule+0x26>
20024ac2:	2902      	cmp	r1, #2
20024ac4:	d108      	bne.n	20024ad8 <HAL_RCC_EnableModule+0x54>
20024ac6:	2301      	movs	r3, #1
20024ac8:	4904      	ldr	r1, [pc, #16]	@ (20024adc <HAL_RCC_EnableModule+0x58>)
20024aca:	4093      	lsls	r3, r2
20024acc:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20024ad0:	4303      	orrs	r3, r0
20024ad2:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
20024ad6:	4770      	bx	lr
20024ad8:	e7fe      	b.n	20024ad8 <HAL_RCC_EnableModule+0x54>
20024ada:	bf00      	nop
20024adc:	50002000 	.word	0x50002000

20024ae0 <HAL_RCC_HCPU_ConfigHCLK>:
20024ae0:	28f0      	cmp	r0, #240	@ 0xf0
20024ae2:	d80d      	bhi.n	20024b00 <HAL_RCC_HCPU_ConfigHCLK+0x20>
20024ae4:	2890      	cmp	r0, #144	@ 0x90
20024ae6:	d807      	bhi.n	20024af8 <HAL_RCC_HCPU_ConfigHCLK+0x18>
20024ae8:	2830      	cmp	r0, #48	@ 0x30
20024aea:	d807      	bhi.n	20024afc <HAL_RCC_HCPU_ConfigHCLK+0x1c>
20024aec:	2818      	cmp	r0, #24
20024aee:	bf94      	ite	ls
20024af0:	2100      	movls	r1, #0
20024af2:	2101      	movhi	r1, #1
20024af4:	f7ff bf5c 	b.w	200249b0 <HAL_RCC_HCPU_ConfigDvfs>
20024af8:	2103      	movs	r1, #3
20024afa:	e7fb      	b.n	20024af4 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024afc:	2102      	movs	r1, #2
20024afe:	e7f9      	b.n	20024af4 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024b00:	2001      	movs	r0, #1
20024b02:	4770      	bx	lr

20024b04 <BSP_OTP_CFG_READ.part.0>:
20024b04:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024b06:	4606      	mov	r6, r0
20024b08:	2500      	movs	r5, #0
20024b0a:	4608      	mov	r0, r1
20024b0c:	9f06      	ldr	r7, [sp, #24]
20024b0e:	5d59      	ldrb	r1, [r3, r5]
20024b10:	29ff      	cmp	r1, #255	@ 0xff
20024b12:	d101      	bne.n	20024b18 <BSP_OTP_CFG_READ.part.0+0x14>
20024b14:	2400      	movs	r4, #0
20024b16:	e013      	b.n	20024b40 <BSP_OTP_CFG_READ.part.0+0x3c>
20024b18:	195c      	adds	r4, r3, r5
20024b1a:	42b1      	cmp	r1, r6
20024b1c:	7864      	ldrb	r4, [r4, #1]
20024b1e:	d006      	beq.n	20024b2e <BSP_OTP_CFG_READ.part.0+0x2a>
20024b20:	1961      	adds	r1, r4, r5
20024b22:	3102      	adds	r1, #2
20024b24:	42b9      	cmp	r1, r7
20024b26:	daf5      	bge.n	20024b14 <BSP_OTP_CFG_READ.part.0+0x10>
20024b28:	3402      	adds	r4, #2
20024b2a:	4425      	add	r5, r4
20024b2c:	e7ef      	b.n	20024b0e <BSP_OTP_CFG_READ.part.0+0xa>
20024b2e:	b13c      	cbz	r4, 20024b40 <BSP_OTP_CFG_READ.part.0+0x3c>
20024b30:	4294      	cmp	r4, r2
20024b32:	bfa8      	it	ge
20024b34:	4614      	movge	r4, r2
20024b36:	3502      	adds	r5, #2
20024b38:	4622      	mov	r2, r4
20024b3a:	1959      	adds	r1, r3, r5
20024b3c:	f001 fc2d 	bl	2002639a <memcpy>
20024b40:	b2e0      	uxtb	r0, r4
20024b42:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}

20024b44 <BSP_OTP_CFG_READ>:
20024b44:	b410      	push	{r4}
20024b46:	b11b      	cbz	r3, 20024b50 <BSP_OTP_CFG_READ+0xc>
20024b48:	f85d 4b04 	ldr.w	r4, [sp], #4
20024b4c:	f7ff bfda 	b.w	20024b04 <BSP_OTP_CFG_READ.part.0>
20024b50:	4618      	mov	r0, r3
20024b52:	f85d 4b04 	ldr.w	r4, [sp], #4
20024b56:	4770      	bx	lr

20024b58 <BSP_OTP_ReadCfg>:
20024b58:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024b5a:	9f08      	ldr	r7, [sp, #32]
20024b5c:	4604      	mov	r4, r0
20024b5e:	9700      	str	r7, [sp, #0]
20024b60:	460d      	mov	r5, r1
20024b62:	4616      	mov	r6, r2
20024b64:	f7ff ffee 	bl	20024b44 <BSP_OTP_CFG_READ>
20024b68:	b998      	cbnz	r0, 20024b92 <BSP_OTP_ReadCfg+0x3a>
20024b6a:	f44f 7780 	mov.w	r7, #256	@ 0x100
20024b6e:	4632      	mov	r2, r6
20024b70:	4629      	mov	r1, r5
20024b72:	4620      	mov	r0, r4
20024b74:	4b08      	ldr	r3, [pc, #32]	@ (20024b98 <BSP_OTP_ReadCfg+0x40>)
20024b76:	9700      	str	r7, [sp, #0]
20024b78:	f7ff ffc4 	bl	20024b04 <BSP_OTP_CFG_READ.part.0>
20024b7c:	b948      	cbnz	r0, 20024b92 <BSP_OTP_ReadCfg+0x3a>
20024b7e:	4632      	mov	r2, r6
20024b80:	4629      	mov	r1, r5
20024b82:	4620      	mov	r0, r4
20024b84:	4b05      	ldr	r3, [pc, #20]	@ (20024b9c <BSP_OTP_ReadCfg+0x44>)
20024b86:	9708      	str	r7, [sp, #32]
20024b88:	b003      	add	sp, #12
20024b8a:	e8bd 40f0 	ldmia.w	sp!, {r4, r5, r6, r7, lr}
20024b8e:	f7ff bfb9 	b.w	20024b04 <BSP_OTP_CFG_READ.part.0>
20024b92:	b003      	add	sp, #12
20024b94:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024b96:	bf00      	nop
20024b98:	2004cb74 	.word	0x2004cb74
20024b9c:	2004ca74 	.word	0x2004ca74

20024ba0 <BSP_GetFlashByAddr>:
20024ba0:	f100 4370 	add.w	r3, r0, #4026531840	@ 0xf0000000
20024ba4:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20024ba8:	d30c      	bcc.n	20024bc4 <BSP_GetFlashByAddr+0x24>
20024baa:	f100 436e 	add.w	r3, r0, #3992977408	@ 0xee000000
20024bae:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20024bb2:	d309      	bcc.n	20024bc8 <BSP_GetFlashByAddr+0x28>
20024bb4:	f100 406c 	add.w	r0, r0, #3959422976	@ 0xec000000
20024bb8:	f1b0 6f40 	cmp.w	r0, #201326592	@ 0xc000000
20024bbc:	4803      	ldr	r0, [pc, #12]	@ (20024bcc <BSP_GetFlashByAddr+0x2c>)
20024bbe:	bf28      	it	cs
20024bc0:	2000      	movcs	r0, #0
20024bc2:	4770      	bx	lr
20024bc4:	4802      	ldr	r0, [pc, #8]	@ (20024bd0 <BSP_GetFlashByAddr+0x30>)
20024bc6:	4770      	bx	lr
20024bc8:	4802      	ldr	r0, [pc, #8]	@ (20024bd4 <BSP_GetFlashByAddr+0x34>)
20024bca:	4770      	bx	lr
20024bcc:	50043000 	.word	0x50043000
20024bd0:	50041000 	.word	0x50041000
20024bd4:	50042000 	.word	0x50042000

20024bd8 <BSP_Get_UserOTP_Cache>:
20024bd8:	4800      	ldr	r0, [pc, #0]	@ (20024bdc <BSP_Get_UserOTP_Cache+0x4>)
20024bda:	4770      	bx	lr
20024bdc:	2004cb74 	.word	0x2004cb74

20024be0 <BSP_Get_CustOTP_Cache>:
20024be0:	4800      	ldr	r0, [pc, #0]	@ (20024be4 <BSP_Get_CustOTP_Cache+0x4>)
20024be2:	4770      	bx	lr
20024be4:	2004ca74 	.word	0x2004ca74

20024be8 <BSP_System_Config>:
20024be8:	b570      	push	{r4, r5, r6, lr}
20024bea:	b09c      	sub	sp, #112	@ 0x70
20024bec:	f7fd fbea 	bl	200223c4 <HAL_EFUSE_Init>
20024bf0:	4604      	mov	r4, r0
20024bf2:	2800      	cmp	r0, #0
20024bf4:	d160      	bne.n	20024cb8 <BSP_System_Config+0xd0>
20024bf6:	f7fc fefc 	bl	200219f2 <HAL_Delay_us>
20024bfa:	200a      	movs	r0, #10
20024bfc:	f7fc fef9 	bl	200219f2 <HAL_Delay_us>
20024c00:	2220      	movs	r2, #32
20024c02:	4621      	mov	r1, r4
20024c04:	482e      	ldr	r0, [pc, #184]	@ (20024cc0 <BSP_System_Config+0xd8>)
20024c06:	f001 fb59 	bl	200262bc <memset>
20024c0a:	2220      	movs	r2, #32
20024c0c:	f44f 7080 	mov.w	r0, #256	@ 0x100
20024c10:	492b      	ldr	r1, [pc, #172]	@ (20024cc0 <BSP_System_Config+0xd8>)
20024c12:	f7fd fbd9 	bl	200223c8 <HAL_EFUSE_Read>
20024c16:	2820      	cmp	r0, #32
20024c18:	4605      	mov	r5, r0
20024c1a:	d14f      	bne.n	20024cbc <BSP_System_Config+0xd4>
20024c1c:	f7ff fcb4 	bl	20024588 <HAL_PMU_LoadCalData>
20024c20:	f7fc fdaa 	bl	20021778 <BSP_GetOtpBase>
20024c24:	4606      	mov	r6, r0
20024c26:	2240      	movs	r2, #64	@ 0x40
20024c28:	4621      	mov	r1, r4
20024c2a:	a80c      	add	r0, sp, #48	@ 0x30
20024c2c:	f001 fb46 	bl	200262bc <memset>
20024c30:	4630      	mov	r0, r6
20024c32:	f7ff ffb5 	bl	20024ba0 <BSP_GetFlashByAddr>
20024c36:	900c      	str	r0, [sp, #48]	@ 0x30
20024c38:	b900      	cbnz	r0, 20024c3c <BSP_System_Config+0x54>
20024c3a:	e7fe      	b.n	20024c3a <BSP_System_Config+0x52>
20024c3c:	a80c      	add	r0, sp, #48	@ 0x30
20024c3e:	f7fe f8ef 	bl	20022e20 <HAL_FLASH_PreInit>
20024c42:	b100      	cbz	r0, 20024c46 <BSP_System_Config+0x5e>
20024c44:	e7fe      	b.n	20024c44 <BSP_System_Config+0x5c>
20024c46:	462b      	mov	r3, r5
20024c48:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
20024c4c:	aa04      	add	r2, sp, #16
20024c4e:	a80c      	add	r0, sp, #48	@ 0x30
20024c50:	f7fe f957 	bl	20022f02 <HAL_QSPI_READ_OTP>
20024c54:	2800      	cmp	r0, #0
20024c56:	dc00      	bgt.n	20024c5a <BSP_System_Config+0x72>
20024c58:	e7fe      	b.n	20024c58 <BSP_System_Config+0x70>
20024c5a:	f7ff ffbd 	bl	20024bd8 <BSP_Get_UserOTP_Cache>
20024c5e:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024c62:	4602      	mov	r2, r0
20024c64:	f44f 5100 	mov.w	r1, #8192	@ 0x2000
20024c68:	a80c      	add	r0, sp, #48	@ 0x30
20024c6a:	f7fe f94a 	bl	20022f02 <HAL_QSPI_READ_OTP>
20024c6e:	2800      	cmp	r0, #0
20024c70:	dc00      	bgt.n	20024c74 <BSP_System_Config+0x8c>
20024c72:	e7fe      	b.n	20024c72 <BSP_System_Config+0x8a>
20024c74:	f7ff ffb4 	bl	20024be0 <BSP_Get_CustOTP_Cache>
20024c78:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024c7c:	4602      	mov	r2, r0
20024c7e:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20024c82:	a80c      	add	r0, sp, #48	@ 0x30
20024c84:	f7fe f93d 	bl	20022f02 <HAL_QSPI_READ_OTP>
20024c88:	2800      	cmp	r0, #0
20024c8a:	dc00      	bgt.n	20024c8e <BSP_System_Config+0xa6>
20024c8c:	e7fe      	b.n	20024c8c <BSP_System_Config+0xa4>
20024c8e:	9000      	str	r0, [sp, #0]
20024c90:	2204      	movs	r2, #4
20024c92:	2003      	movs	r0, #3
20024c94:	ab04      	add	r3, sp, #16
20024c96:	a903      	add	r1, sp, #12
20024c98:	f7ff ff5e 	bl	20024b58 <BSP_OTP_ReadCfg>
20024c9c:	b910      	cbnz	r0, 20024ca4 <BSP_System_Config+0xbc>
20024c9e:	2000      	movs	r0, #0
20024ca0:	b01c      	add	sp, #112	@ 0x70
20024ca2:	bd70      	pop	{r4, r5, r6, pc}
20024ca4:	9803      	ldr	r0, [sp, #12]
20024ca6:	2800      	cmp	r0, #0
20024ca8:	d0f9      	beq.n	20024c9e <BSP_System_Config+0xb6>
20024caa:	f240 33ff 	movw	r3, #1023	@ 0x3ff
20024cae:	4298      	cmp	r0, r3
20024cb0:	d0f5      	beq.n	20024c9e <BSP_System_Config+0xb6>
20024cb2:	f003 f901 	bl	20027eb8 <BSP_HxtCbank_Config>
20024cb6:	e7f2      	b.n	20024c9e <BSP_System_Config+0xb6>
20024cb8:	2001      	movs	r0, #1
20024cba:	e7f1      	b.n	20024ca0 <BSP_System_Config+0xb8>
20024cbc:	2002      	movs	r0, #2
20024cbe:	e7ef      	b.n	20024ca0 <BSP_System_Config+0xb8>
20024cc0:	2004cc74 	.word	0x2004cc74

20024cc4 <BSP_CONFIG_get>:
20024cc4:	b5f0      	push	{r4, r5, r6, r7, lr}
20024cc6:	4604      	mov	r4, r0
20024cc8:	4610      	mov	r0, r2
20024cca:	b109      	cbz	r1, 20024cd0 <BSP_CONFIG_get+0xc>
20024ccc:	2a00      	cmp	r2, #0
20024cce:	dc01      	bgt.n	20024cd4 <BSP_CONFIG_get+0x10>
20024cd0:	2000      	movs	r0, #0
20024cd2:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024cd4:	4b56      	ldr	r3, [pc, #344]	@ (20024e30 <BSP_CONFIG_get+0x16c>)
20024cd6:	781a      	ldrb	r2, [r3, #0]
20024cd8:	2a00      	cmp	r2, #0
20024cda:	d0f9      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024cdc:	2c04      	cmp	r4, #4
20024cde:	d152      	bne.n	20024d86 <BSP_CONFIG_get+0xc2>
20024ce0:	280d      	cmp	r0, #13
20024ce2:	ddf5      	ble.n	20024cd0 <BSP_CONFIG_get+0xc>
20024ce4:	795a      	ldrb	r2, [r3, #5]
20024ce6:	f893 c004 	ldrb.w	ip, [r3, #4]
20024cea:	0212      	lsls	r2, r2, #8
20024cec:	f402 6270 	and.w	r2, r2, #3840	@ 0xf00
20024cf0:	ea4c 0c02 	orr.w	ip, ip, r2
20024cf4:	f8a1 c000 	strh.w	ip, [r1]
20024cf8:	799d      	ldrb	r5, [r3, #6]
20024cfa:	795a      	ldrb	r2, [r3, #5]
20024cfc:	012d      	lsls	r5, r5, #4
20024cfe:	f005 0510 	and.w	r5, r5, #16
20024d02:	ea45 1512 	orr.w	r5, r5, r2, lsr #4
20024d06:	808d      	strh	r5, [r1, #4]
20024d08:	79df      	ldrb	r7, [r3, #7]
20024d0a:	799a      	ldrb	r2, [r3, #6]
20024d0c:	01ff      	lsls	r7, r7, #7
20024d0e:	f407 6778 	and.w	r7, r7, #3968	@ 0xf80
20024d12:	ea47 0752 	orr.w	r7, r7, r2, lsr #1
20024d16:	804f      	strh	r7, [r1, #2]
20024d18:	7a1c      	ldrb	r4, [r3, #8]
20024d1a:	79da      	ldrb	r2, [r3, #7]
20024d1c:	00e4      	lsls	r4, r4, #3
20024d1e:	f004 0418 	and.w	r4, r4, #24
20024d22:	ea44 1452 	orr.w	r4, r4, r2, lsr #5
20024d26:	80cc      	strh	r4, [r1, #6]
20024d28:	7a5a      	ldrb	r2, [r3, #9]
20024d2a:	7a1e      	ldrb	r6, [r3, #8]
20024d2c:	0192      	lsls	r2, r2, #6
20024d2e:	f402 627c 	and.w	r2, r2, #4032	@ 0xfc0
20024d32:	ea42 0296 	orr.w	r2, r2, r6, lsr #2
20024d36:	810a      	strh	r2, [r1, #8]
20024d38:	7a9e      	ldrb	r6, [r3, #10]
20024d3a:	7a5b      	ldrb	r3, [r3, #9]
20024d3c:	00b6      	lsls	r6, r6, #2
20024d3e:	f006 063c 	and.w	r6, r6, #60	@ 0x3c
20024d42:	ea46 1393 	orr.w	r3, r6, r3, lsr #6
20024d46:	eb05 0585 	add.w	r5, r5, r5, lsl #2
20024d4a:	eb04 0484 	add.w	r4, r4, r4, lsl #2
20024d4e:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024d52:	eb05 0585 	add.w	r5, r5, r5, lsl #2
20024d56:	eb04 0484 	add.w	r4, r4, r4, lsl #2
20024d5a:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024d5e:	00ad      	lsls	r5, r5, #2
20024d60:	00a4      	lsls	r4, r4, #2
20024d62:	009b      	lsls	r3, r3, #2
20024d64:	808d      	strh	r5, [r1, #4]
20024d66:	80cc      	strh	r4, [r1, #6]
20024d68:	814b      	strh	r3, [r1, #10]
20024d6a:	f1bc 0f00 	cmp.w	ip, #0
20024d6e:	d0af      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d70:	2d00      	cmp	r5, #0
20024d72:	d0ad      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d74:	2f00      	cmp	r7, #0
20024d76:	d0ab      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d78:	2c00      	cmp	r4, #0
20024d7a:	d0a9      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d7c:	2a00      	cmp	r2, #0
20024d7e:	d0a7      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d80:	2b00      	cmp	r3, #0
20024d82:	d0a5      	beq.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d84:	e7a5      	b.n	20024cd2 <BSP_CONFIG_get+0xe>
20024d86:	2c06      	cmp	r4, #6
20024d88:	d132      	bne.n	20024df0 <BSP_CONFIG_get+0x12c>
20024d8a:	280e      	cmp	r0, #14
20024d8c:	dda0      	ble.n	20024cd0 <BSP_CONFIG_get+0xc>
20024d8e:	f002 0207 	and.w	r2, r2, #7
20024d92:	700a      	strb	r2, [r1, #0]
20024d94:	781a      	ldrb	r2, [r3, #0]
20024d96:	f3c2 04c0 	ubfx	r4, r2, #3, #1
20024d9a:	704c      	strb	r4, [r1, #1]
20024d9c:	785c      	ldrb	r4, [r3, #1]
20024d9e:	0912      	lsrs	r2, r2, #4
20024da0:	f004 050f 	and.w	r5, r4, #15
20024da4:	0924      	lsrs	r4, r4, #4
20024da6:	708a      	strb	r2, [r1, #2]
20024da8:	70cd      	strb	r5, [r1, #3]
20024daa:	710c      	strb	r4, [r1, #4]
20024dac:	7b5c      	ldrb	r4, [r3, #13]
20024dae:	789e      	ldrb	r6, [r3, #2]
20024db0:	0924      	lsrs	r4, r4, #4
20024db2:	730c      	strb	r4, [r1, #12]
20024db4:	7b9d      	ldrb	r5, [r3, #14]
20024db6:	f005 050f 	and.w	r5, r5, #15
20024dba:	734d      	strb	r5, [r1, #13]
20024dbc:	0935      	lsrs	r5, r6, #4
20024dbe:	718d      	strb	r5, [r1, #6]
20024dc0:	78dd      	ldrb	r5, [r3, #3]
20024dc2:	f006 060f 	and.w	r6, r6, #15
20024dc6:	f005 070f 	and.w	r7, r5, #15
20024dca:	71cf      	strb	r7, [r1, #7]
20024dcc:	7b5f      	ldrb	r7, [r3, #13]
20024dce:	092d      	lsrs	r5, r5, #4
20024dd0:	f007 0707 	and.w	r7, r7, #7
20024dd4:	720f      	strb	r7, [r1, #8]
20024dd6:	7b5b      	ldrb	r3, [r3, #13]
20024dd8:	738d      	strb	r5, [r1, #14]
20024dda:	f3c3 03c0 	ubfx	r3, r3, #3, #1
20024dde:	724b      	strb	r3, [r1, #9]
20024de0:	714e      	strb	r6, [r1, #5]
20024de2:	2a00      	cmp	r2, #0
20024de4:	f43f af74 	beq.w	20024cd0 <BSP_CONFIG_get+0xc>
20024de8:	2c00      	cmp	r4, #0
20024dea:	f43f af71 	beq.w	20024cd0 <BSP_CONFIG_get+0xc>
20024dee:	e770      	b.n	20024cd2 <BSP_CONFIG_get+0xe>
20024df0:	2c15      	cmp	r4, #21
20024df2:	f47f af6d 	bne.w	20024cd0 <BSP_CONFIG_get+0xc>
20024df6:	2807      	cmp	r0, #7
20024df8:	f77f af6a 	ble.w	20024cd0 <BSP_CONFIG_get+0xc>
20024dfc:	7a9a      	ldrb	r2, [r3, #10]
20024dfe:	0912      	lsrs	r2, r2, #4
20024e00:	700a      	strb	r2, [r1, #0]
20024e02:	7ada      	ldrb	r2, [r3, #11]
20024e04:	f002 023f 	and.w	r2, r2, #63	@ 0x3f
20024e08:	704a      	strb	r2, [r1, #1]
20024e0a:	7b1a      	ldrb	r2, [r3, #12]
20024e0c:	7adc      	ldrb	r4, [r3, #11]
20024e0e:	0092      	lsls	r2, r2, #2
20024e10:	f002 021c 	and.w	r2, r2, #28
20024e14:	ea42 1294 	orr.w	r2, r2, r4, lsr #6
20024e18:	708a      	strb	r2, [r1, #2]
20024e1a:	7b1a      	ldrb	r2, [r3, #12]
20024e1c:	08d2      	lsrs	r2, r2, #3
20024e1e:	70ca      	strb	r2, [r1, #3]
20024e20:	7b9a      	ldrb	r2, [r3, #14]
20024e22:	7bdb      	ldrb	r3, [r3, #15]
20024e24:	011b      	lsls	r3, r3, #4
20024e26:	ea43 1312 	orr.w	r3, r3, r2, lsr #4
20024e2a:	710b      	strb	r3, [r1, #4]
20024e2c:	e751      	b.n	20024cd2 <BSP_CONFIG_get+0xe>
20024e2e:	bf00      	nop
20024e30:	2004cc74 	.word	0x2004cc74

20024e34 <spi_nor_get_ext_cfg_by_id>:
20024e34:	2000      	movs	r0, #0
20024e36:	4770      	bx	lr

20024e38 <spi_nor_get_user_flash_cfg>:
20024e38:	2000      	movs	r0, #0
20024e3a:	4770      	bx	lr

20024e3c <spi_flash_get_rdid>:
20024e3c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024e3e:	4604      	mov	r4, r0
20024e40:	3801      	subs	r0, #1
20024e42:	b2c0      	uxtb	r0, r0
20024e44:	28fd      	cmp	r0, #253	@ 0xfd
20024e46:	d816      	bhi.n	20024e76 <spi_flash_get_rdid+0x3a>
20024e48:	2500      	movs	r5, #0
20024e4a:	4e0d      	ldr	r6, [pc, #52]	@ (20024e80 <spi_flash_get_rdid+0x44>)
20024e4c:	f856 0b04 	ldr.w	r0, [r6], #4
20024e50:	7807      	ldrb	r7, [r0, #0]
20024e52:	b937      	cbnz	r7, 20024e62 <spi_flash_get_rdid+0x26>
20024e54:	3501      	adds	r5, #1
20024e56:	2d06      	cmp	r5, #6
20024e58:	d1f8      	bne.n	20024e4c <spi_flash_get_rdid+0x10>
20024e5a:	4620      	mov	r0, r4
20024e5c:	f7ff ffec 	bl	20024e38 <spi_nor_get_user_flash_cfg>
20024e60:	e00d      	b.n	20024e7e <spi_flash_get_rdid+0x42>
20024e62:	42a7      	cmp	r7, r4
20024e64:	d105      	bne.n	20024e72 <spi_flash_get_rdid+0x36>
20024e66:	7847      	ldrb	r7, [r0, #1]
20024e68:	4297      	cmp	r7, r2
20024e6a:	d102      	bne.n	20024e72 <spi_flash_get_rdid+0x36>
20024e6c:	7887      	ldrb	r7, [r0, #2]
20024e6e:	428f      	cmp	r7, r1
20024e70:	d003      	beq.n	20024e7a <spi_flash_get_rdid+0x3e>
20024e72:	3008      	adds	r0, #8
20024e74:	e7ec      	b.n	20024e50 <spi_flash_get_rdid+0x14>
20024e76:	2000      	movs	r0, #0
20024e78:	e001      	b.n	20024e7e <spi_flash_get_rdid+0x42>
20024e7a:	b103      	cbz	r3, 20024e7e <spi_flash_get_rdid+0x42>
20024e7c:	701d      	strb	r5, [r3, #0]
20024e7e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024e80:	20042c1c 	.word	0x20042c1c

20024e84 <spi_flash_get_cmd_by_id>:
20024e84:	b507      	push	{r0, r1, r2, lr}
20024e86:	f10d 0307 	add.w	r3, sp, #7
20024e8a:	f7ff ffd7 	bl	20024e3c <spi_flash_get_rdid>
20024e8e:	4b06      	ldr	r3, [pc, #24]	@ (20024ea8 <spi_flash_get_cmd_by_id+0x24>)
20024e90:	b140      	cbz	r0, 20024ea4 <spi_flash_get_cmd_by_id+0x20>
20024e92:	f44f 7105 	mov.w	r1, #532	@ 0x214
20024e96:	f89d 2007 	ldrb.w	r2, [sp, #7]
20024e9a:	fb01 3002 	mla	r0, r1, r2, r3
20024e9e:	b003      	add	sp, #12
20024ea0:	f85d fb04 	ldr.w	pc, [sp], #4
20024ea4:	4618      	mov	r0, r3
20024ea6:	e7fa      	b.n	20024e9e <spi_flash_get_cmd_by_id+0x1a>
20024ea8:	20042e64 	.word	0x20042e64

20024eac <spi_flash_get_size_by_id>:
20024eac:	b508      	push	{r3, lr}
20024eae:	2300      	movs	r3, #0
20024eb0:	f7ff ffc4 	bl	20024e3c <spi_flash_get_rdid>
20024eb4:	b108      	cbz	r0, 20024eba <spi_flash_get_size_by_id+0xe>
20024eb6:	6840      	ldr	r0, [r0, #4]
20024eb8:	bd08      	pop	{r3, pc}
20024eba:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
20024ebe:	e7fb      	b.n	20024eb8 <spi_flash_get_size_by_id+0xc>

20024ec0 <spi_flash_is_support_dtr>:
20024ec0:	b508      	push	{r3, lr}
20024ec2:	2300      	movs	r3, #0
20024ec4:	f7ff ffba 	bl	20024e3c <spi_flash_get_rdid>
20024ec8:	b110      	cbz	r0, 20024ed0 <spi_flash_is_support_dtr+0x10>
20024eca:	78c0      	ldrb	r0, [r0, #3]
20024ecc:	f000 0001 	and.w	r0, r0, #1
20024ed0:	bd08      	pop	{r3, pc}
	...

20024ed4 <spi_flash_get_otp_base>:
20024ed4:	b508      	push	{r3, lr}
20024ed6:	2300      	movs	r3, #0
20024ed8:	f7ff ffb0 	bl	20024e3c <spi_flash_get_rdid>
20024edc:	b130      	cbz	r0, 20024eec <spi_flash_get_otp_base+0x18>
20024ede:	78c3      	ldrb	r3, [r0, #3]
20024ee0:	4803      	ldr	r0, [pc, #12]	@ (20024ef0 <spi_flash_get_otp_base+0x1c>)
20024ee2:	f003 0306 	and.w	r3, r3, #6
20024ee6:	2b02      	cmp	r3, #2
20024ee8:	bf18      	it	ne
20024eea:	2000      	movne	r0, #0
20024eec:	bd08      	pop	{r3, pc}
20024eee:	bf00      	nop
20024ef0:	00ffc000 	.word	0x00ffc000

20024ef4 <spi_nand_get_user_flash_cfg>:
20024ef4:	2000      	movs	r0, #0
20024ef6:	4770      	bx	lr

20024ef8 <spi_nand_get_rdid>:
20024ef8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024efa:	4604      	mov	r4, r0
20024efc:	3801      	subs	r0, #1
20024efe:	b2c0      	uxtb	r0, r0
20024f00:	28fd      	cmp	r0, #253	@ 0xfd
20024f02:	d816      	bhi.n	20024f32 <spi_nand_get_rdid+0x3a>
20024f04:	2500      	movs	r5, #0
20024f06:	4e0d      	ldr	r6, [pc, #52]	@ (20024f3c <spi_nand_get_rdid+0x44>)
20024f08:	f856 0b04 	ldr.w	r0, [r6], #4
20024f0c:	7807      	ldrb	r7, [r0, #0]
20024f0e:	b937      	cbnz	r7, 20024f1e <spi_nand_get_rdid+0x26>
20024f10:	3501      	adds	r5, #1
20024f12:	2d06      	cmp	r5, #6
20024f14:	d1f8      	bne.n	20024f08 <spi_nand_get_rdid+0x10>
20024f16:	4620      	mov	r0, r4
20024f18:	f7ff ffec 	bl	20024ef4 <spi_nand_get_user_flash_cfg>
20024f1c:	e00d      	b.n	20024f3a <spi_nand_get_rdid+0x42>
20024f1e:	42a7      	cmp	r7, r4
20024f20:	d105      	bne.n	20024f2e <spi_nand_get_rdid+0x36>
20024f22:	7847      	ldrb	r7, [r0, #1]
20024f24:	4297      	cmp	r7, r2
20024f26:	d102      	bne.n	20024f2e <spi_nand_get_rdid+0x36>
20024f28:	7887      	ldrb	r7, [r0, #2]
20024f2a:	428f      	cmp	r7, r1
20024f2c:	d003      	beq.n	20024f36 <spi_nand_get_rdid+0x3e>
20024f2e:	3008      	adds	r0, #8
20024f30:	e7ec      	b.n	20024f0c <spi_nand_get_rdid+0x14>
20024f32:	2000      	movs	r0, #0
20024f34:	e001      	b.n	20024f3a <spi_nand_get_rdid+0x42>
20024f36:	b103      	cbz	r3, 20024f3a <spi_nand_get_rdid+0x42>
20024f38:	701d      	strb	r5, [r3, #0]
20024f3a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024f3c:	20043adc 	.word	0x20043adc

20024f40 <spi_nand_get_cmd_by_id>:
20024f40:	b507      	push	{r0, r1, r2, lr}
20024f42:	f10d 0307 	add.w	r3, sp, #7
20024f46:	f7ff ffd7 	bl	20024ef8 <spi_nand_get_rdid>
20024f4a:	b130      	cbz	r0, 20024f5a <spi_nand_get_cmd_by_id+0x1a>
20024f4c:	f44f 7205 	mov.w	r2, #532	@ 0x214
20024f50:	f89d 3007 	ldrb.w	r3, [sp, #7]
20024f54:	4802      	ldr	r0, [pc, #8]	@ (20024f60 <spi_nand_get_cmd_by_id+0x20>)
20024f56:	fb02 0003 	mla	r0, r2, r3, r0
20024f5a:	b003      	add	sp, #12
20024f5c:	f85d fb04 	ldr.w	pc, [sp], #4
20024f60:	20043d2c 	.word	0x20043d2c

20024f64 <spi_nand_get_ext_cfg_by_id>:
20024f64:	2000      	movs	r0, #0
20024f66:	4770      	bx	lr

20024f68 <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
20024f68:	f04f 30ff 	mov.w	r0, #4294967295
20024f6c:	4770      	bx	lr
	...

20024f70 <spi_nand_get_default_ctable>:
20024f70:	b508      	push	{r3, lr}
20024f72:	f7ff fff9 	bl	20024f68 <HAL_GET_NAND_FLASH_DEFAUT_IDX>
20024f76:	1e03      	subs	r3, r0, #0
20024f78:	bfa5      	ittet	ge
20024f7a:	f44f 7205 	movge.w	r2, #532	@ 0x214
20024f7e:	4802      	ldrge	r0, [pc, #8]	@ (20024f88 <spi_nand_get_default_ctable+0x18>)
20024f80:	2000      	movlt	r0, #0
20024f82:	fb02 0003 	mlage	r0, r2, r3, r0
20024f86:	bd08      	pop	{r3, pc}
20024f88:	20043d2c 	.word	0x20043d2c

20024f8c <spi_nand_get_size_by_id>:
20024f8c:	b508      	push	{r3, lr}
20024f8e:	2300      	movs	r3, #0
20024f90:	f7ff ffb2 	bl	20024ef8 <spi_nand_get_rdid>
20024f94:	b108      	cbz	r0, 20024f9a <spi_nand_get_size_by_id+0xe>
20024f96:	6840      	ldr	r0, [r0, #4]
20024f98:	bd08      	pop	{r3, pc}
20024f9a:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20024f9e:	e7fb      	b.n	20024f98 <spi_nand_get_size_by_id+0xc>

20024fa0 <spi_nand_get_plane_select_flag>:
20024fa0:	b508      	push	{r3, lr}
20024fa2:	2300      	movs	r3, #0
20024fa4:	f7ff ffa8 	bl	20024ef8 <spi_nand_get_rdid>
20024fa8:	b110      	cbz	r0, 20024fb0 <spi_nand_get_plane_select_flag+0x10>
20024faa:	78c0      	ldrb	r0, [r0, #3]
20024fac:	f3c0 0040 	ubfx	r0, r0, #1, #1
20024fb0:	bd08      	pop	{r3, pc}

20024fb2 <spi_nand_get_big_page_flag>:
20024fb2:	b508      	push	{r3, lr}
20024fb4:	2300      	movs	r3, #0
20024fb6:	f7ff ff9f 	bl	20024ef8 <spi_nand_get_rdid>
20024fba:	b110      	cbz	r0, 20024fc2 <spi_nand_get_big_page_flag+0x10>
20024fbc:	78c0      	ldrb	r0, [r0, #3]
20024fbe:	f3c0 0081 	ubfx	r0, r0, #2, #2
20024fc2:	bd08      	pop	{r3, pc}

20024fc4 <spi_nand_get_ecc_mode>:
20024fc4:	b508      	push	{r3, lr}
20024fc6:	2300      	movs	r3, #0
20024fc8:	f7ff ff96 	bl	20024ef8 <spi_nand_get_rdid>
20024fcc:	b108      	cbz	r0, 20024fd2 <spi_nand_get_ecc_mode+0xe>
20024fce:	78c0      	ldrb	r0, [r0, #3]
20024fd0:	0900      	lsrs	r0, r0, #4
20024fd2:	bd08      	pop	{r3, pc}

20024fd4 <bbm_map_check.part.0>:
20024fd4:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024fd6:	4b21      	ldr	r3, [pc, #132]	@ (2002505c <bbm_map_check.part.0+0x88>)
20024fd8:	4606      	mov	r6, r0
20024fda:	681d      	ldr	r5, [r3, #0]
20024fdc:	4b20      	ldr	r3, [pc, #128]	@ (20025060 <bbm_map_check.part.0+0x8c>)
20024fde:	3d04      	subs	r5, #4
20024fe0:	681f      	ldr	r7, [r3, #0]
20024fe2:	2300      	movs	r3, #0
20024fe4:	f100 0e1a 	add.w	lr, r0, #26
20024fe8:	42ab      	cmp	r3, r5
20024fea:	db02      	blt.n	20024ff2 <bbm_map_check.part.0+0x1e>
20024fec:	2000      	movs	r0, #0
20024fee:	b003      	add	sp, #12
20024ff0:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024ff2:	8b31      	ldrh	r1, [r6, #24]
20024ff4:	b321      	cbz	r1, 20025040 <bbm_map_check.part.0+0x6c>
20024ff6:	8b72      	ldrh	r2, [r6, #26]
20024ff8:	b33a      	cbz	r2, 2002504a <bbm_map_check.part.0+0x76>
20024ffa:	42b9      	cmp	r1, r7
20024ffc:	d201      	bcs.n	20025002 <bbm_map_check.part.0+0x2e>
20024ffe:	4297      	cmp	r7, r2
20025000:	d905      	bls.n	2002500e <bbm_map_check.part.0+0x3a>
20025002:	4b18      	ldr	r3, [pc, #96]	@ (20025064 <bbm_map_check.part.0+0x90>)
20025004:	681b      	ldr	r3, [r3, #0]
20025006:	b10b      	cbz	r3, 2002500c <bbm_map_check.part.0+0x38>
20025008:	4817      	ldr	r0, [pc, #92]	@ (20025068 <bbm_map_check.part.0+0x94>)
2002500a:	4798      	blx	r3
2002500c:	e7fe      	b.n	2002500c <bbm_map_check.part.0+0x38>
2002500e:	3301      	adds	r3, #1
20025010:	461c      	mov	r4, r3
20025012:	42ac      	cmp	r4, r5
20025014:	db01      	blt.n	2002501a <bbm_map_check.part.0+0x46>
20025016:	3604      	adds	r6, #4
20025018:	e7e6      	b.n	20024fe8 <bbm_map_check.part.0+0x14>
2002501a:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
2002501e:	f1bc 0f00 	cmp.w	ip, #0
20025022:	d0f8      	beq.n	20025016 <bbm_map_check.part.0+0x42>
20025024:	4562      	cmp	r2, ip
20025026:	d109      	bne.n	2002503c <bbm_map_check.part.0+0x68>
20025028:	4b0e      	ldr	r3, [pc, #56]	@ (20025064 <bbm_map_check.part.0+0x90>)
2002502a:	681d      	ldr	r5, [r3, #0]
2002502c:	b12d      	cbz	r5, 2002503a <bbm_map_check.part.0+0x66>
2002502e:	3406      	adds	r4, #6
20025030:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
20025034:	480d      	ldr	r0, [pc, #52]	@ (2002506c <bbm_map_check.part.0+0x98>)
20025036:	9200      	str	r2, [sp, #0]
20025038:	47a8      	blx	r5
2002503a:	e7fe      	b.n	2002503a <bbm_map_check.part.0+0x66>
2002503c:	3401      	adds	r4, #1
2002503e:	e7e8      	b.n	20025012 <bbm_map_check.part.0+0x3e>
20025040:	eb00 0283 	add.w	r2, r0, r3, lsl #2
20025044:	8b52      	ldrh	r2, [r2, #26]
20025046:	2a00      	cmp	r2, #0
20025048:	d0d0      	beq.n	20024fec <bbm_map_check.part.0+0x18>
2002504a:	4a06      	ldr	r2, [pc, #24]	@ (20025064 <bbm_map_check.part.0+0x90>)
2002504c:	6814      	ldr	r4, [r2, #0]
2002504e:	b124      	cbz	r4, 2002505a <bbm_map_check.part.0+0x86>
20025050:	eb00 0383 	add.w	r3, r0, r3, lsl #2
20025054:	8b5a      	ldrh	r2, [r3, #26]
20025056:	4806      	ldr	r0, [pc, #24]	@ (20025070 <bbm_map_check.part.0+0x9c>)
20025058:	47a0      	blx	r4
2002505a:	e7fe      	b.n	2002505a <bbm_map_check.part.0+0x86>
2002505c:	2004cca4 	.word	0x2004cca4
20025060:	2004cca8 	.word	0x2004cca8
20025064:	2004cc94 	.word	0x2004cc94
20025068:	20026ba0 	.word	0x20026ba0
2002506c:	20026bbd 	.word	0x20026bbd
20025070:	20026c0a 	.word	0x20026c0a

20025074 <bbm_crc_check>:
20025074:	f04f 32ff 	mov.w	r2, #4294967295
20025078:	b510      	push	{r4, lr}
2002507a:	4c07      	ldr	r4, [pc, #28]	@ (20025098 <bbm_crc_check+0x24>)
2002507c:	4401      	add	r1, r0
2002507e:	4288      	cmp	r0, r1
20025080:	d101      	bne.n	20025086 <bbm_crc_check+0x12>
20025082:	43d0      	mvns	r0, r2
20025084:	bd10      	pop	{r4, pc}
20025086:	f810 3b01 	ldrb.w	r3, [r0], #1
2002508a:	4053      	eors	r3, r2
2002508c:	b2db      	uxtb	r3, r3
2002508e:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
20025092:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
20025096:	e7f2      	b.n	2002507e <bbm_crc_check+0xa>
20025098:	200276a4 	.word	0x200276a4

2002509c <bbm_get_phy_blk>:
2002509c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002509e:	4b14      	ldr	r3, [pc, #80]	@ (200250f0 <bbm_get_phy_blk+0x54>)
200250a0:	4601      	mov	r1, r0
200250a2:	681e      	ldr	r6, [r3, #0]
200250a4:	42b0      	cmp	r0, r6
200250a6:	d21e      	bcs.n	200250e6 <bbm_get_phy_blk+0x4a>
200250a8:	b138      	cbz	r0, 200250ba <bbm_get_phy_blk+0x1e>
200250aa:	4b12      	ldr	r3, [pc, #72]	@ (200250f4 <bbm_get_phy_blk+0x58>)
200250ac:	2200      	movs	r2, #0
200250ae:	681c      	ldr	r4, [r3, #0]
200250b0:	4b11      	ldr	r3, [pc, #68]	@ (200250f8 <bbm_get_phy_blk+0x5c>)
200250b2:	3c04      	subs	r4, #4
200250b4:	461d      	mov	r5, r3
200250b6:	4294      	cmp	r4, r2
200250b8:	dc00      	bgt.n	200250bc <bbm_get_phy_blk+0x20>
200250ba:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200250bc:	8b1f      	ldrh	r7, [r3, #24]
200250be:	428f      	cmp	r7, r1
200250c0:	d10a      	bne.n	200250d8 <bbm_get_phy_blk+0x3c>
200250c2:	eb05 0582 	add.w	r5, r5, r2, lsl #2
200250c6:	8b6a      	ldrh	r2, [r5, #26]
200250c8:	4296      	cmp	r6, r2
200250ca:	dd0f      	ble.n	200250ec <bbm_get_phy_blk+0x50>
200250cc:	4b0b      	ldr	r3, [pc, #44]	@ (200250fc <bbm_get_phy_blk+0x60>)
200250ce:	681b      	ldr	r3, [r3, #0]
200250d0:	b10b      	cbz	r3, 200250d6 <bbm_get_phy_blk+0x3a>
200250d2:	480b      	ldr	r0, [pc, #44]	@ (20025100 <bbm_get_phy_blk+0x64>)
200250d4:	4798      	blx	r3
200250d6:	e7fe      	b.n	200250d6 <bbm_get_phy_blk+0x3a>
200250d8:	b917      	cbnz	r7, 200250e0 <bbm_get_phy_blk+0x44>
200250da:	8b5f      	ldrh	r7, [r3, #26]
200250dc:	2f00      	cmp	r7, #0
200250de:	d0ec      	beq.n	200250ba <bbm_get_phy_blk+0x1e>
200250e0:	3201      	adds	r2, #1
200250e2:	3304      	adds	r3, #4
200250e4:	e7e7      	b.n	200250b6 <bbm_get_phy_blk+0x1a>
200250e6:	f04f 30ff 	mov.w	r0, #4294967295
200250ea:	e7e6      	b.n	200250ba <bbm_get_phy_blk+0x1e>
200250ec:	4610      	mov	r0, r2
200250ee:	e7e4      	b.n	200250ba <bbm_get_phy_blk+0x1e>
200250f0:	2004cca8 	.word	0x2004cca8
200250f4:	2004cca4 	.word	0x2004cca4
200250f8:	2004ccac 	.word	0x2004ccac
200250fc:	2004cc94 	.word	0x2004cc94
20025100:	20026c28 	.word	0x20026c28

20025104 <bbm_get_version_inblk>:
20025104:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025108:	4607      	mov	r7, r0
2002510a:	4688      	mov	r8, r1
2002510c:	b087      	sub	sp, #28
2002510e:	2900      	cmp	r1, #0
20025110:	d14b      	bne.n	200251aa <bbm_get_version_inblk+0xa6>
20025112:	2500      	movs	r5, #0
20025114:	4628      	mov	r0, r5
20025116:	b007      	add	sp, #28
20025118:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
2002511c:	2200      	movs	r2, #0
2002511e:	e9cd 2201 	strd	r2, r2, [sp, #4]
20025122:	4e26      	ldr	r6, [pc, #152]	@ (200251bc <bbm_get_version_inblk+0xb8>)
20025124:	9100      	str	r1, [sp, #0]
20025126:	4638      	mov	r0, r7
20025128:	4621      	mov	r1, r4
2002512a:	6833      	ldr	r3, [r6, #0]
2002512c:	f7fb fb4c 	bl	200207c8 <port_read_page>
20025130:	2800      	cmp	r0, #0
20025132:	dd32      	ble.n	2002519a <bbm_get_version_inblk+0x96>
20025134:	6832      	ldr	r2, [r6, #0]
20025136:	6813      	ldr	r3, [r2, #0]
20025138:	455b      	cmp	r3, fp
2002513a:	d123      	bne.n	20025184 <bbm_get_version_inblk+0x80>
2002513c:	6856      	ldr	r6, [r2, #4]
2002513e:	f3c6 061e 	ubfx	r6, r6, #0, #31
20025142:	42ae      	cmp	r6, r5
20025144:	dd15      	ble.n	20025172 <bbm_get_version_inblk+0x6e>
20025146:	4610      	mov	r0, r2
20025148:	2110      	movs	r1, #16
2002514a:	9205      	str	r2, [sp, #20]
2002514c:	f7ff ff92 	bl	20025074 <bbm_crc_check>
20025150:	9a05      	ldr	r2, [sp, #20]
20025152:	6913      	ldr	r3, [r2, #16]
20025154:	4283      	cmp	r3, r0
20025156:	d113      	bne.n	20025180 <bbm_get_version_inblk+0x7c>
20025158:	f8c8 4000 	str.w	r4, [r8]
2002515c:	4635      	mov	r5, r6
2002515e:	3401      	adds	r4, #1
20025160:	f8da 1000 	ldr.w	r1, [sl]
20025164:	f8d9 3000 	ldr.w	r3, [r9]
20025168:	fbb3 f3f1 	udiv	r3, r3, r1
2002516c:	42a3      	cmp	r3, r4
2002516e:	d8d5      	bhi.n	2002511c <bbm_get_version_inblk+0x18>
20025170:	e7d0      	b.n	20025114 <bbm_get_version_inblk+0x10>
20025172:	4b13      	ldr	r3, [pc, #76]	@ (200251c0 <bbm_get_version_inblk+0xbc>)
20025174:	681b      	ldr	r3, [r3, #0]
20025176:	b11b      	cbz	r3, 20025180 <bbm_get_version_inblk+0x7c>
20025178:	4632      	mov	r2, r6
2002517a:	4629      	mov	r1, r5
2002517c:	4811      	ldr	r0, [pc, #68]	@ (200251c4 <bbm_get_version_inblk+0xc0>)
2002517e:	4798      	blx	r3
20025180:	462e      	mov	r6, r5
20025182:	e7eb      	b.n	2002515c <bbm_get_version_inblk+0x58>
20025184:	1c5a      	adds	r2, r3, #1
20025186:	d0c5      	beq.n	20025114 <bbm_get_version_inblk+0x10>
20025188:	4a0d      	ldr	r2, [pc, #52]	@ (200251c0 <bbm_get_version_inblk+0xbc>)
2002518a:	6815      	ldr	r5, [r2, #0]
2002518c:	2d00      	cmp	r5, #0
2002518e:	d0c0      	beq.n	20025112 <bbm_get_version_inblk+0xe>
20025190:	4622      	mov	r2, r4
20025192:	4639      	mov	r1, r7
20025194:	480c      	ldr	r0, [pc, #48]	@ (200251c8 <bbm_get_version_inblk+0xc4>)
20025196:	47a8      	blx	r5
20025198:	e7bb      	b.n	20025112 <bbm_get_version_inblk+0xe>
2002519a:	4b09      	ldr	r3, [pc, #36]	@ (200251c0 <bbm_get_version_inblk+0xbc>)
2002519c:	681b      	ldr	r3, [r3, #0]
2002519e:	2b00      	cmp	r3, #0
200251a0:	d0ee      	beq.n	20025180 <bbm_get_version_inblk+0x7c>
200251a2:	4622      	mov	r2, r4
200251a4:	4639      	mov	r1, r7
200251a6:	4809      	ldr	r0, [pc, #36]	@ (200251cc <bbm_get_version_inblk+0xc8>)
200251a8:	e7e9      	b.n	2002517e <bbm_get_version_inblk+0x7a>
200251aa:	2400      	movs	r4, #0
200251ac:	f8df a020 	ldr.w	sl, [pc, #32]	@ 200251d0 <bbm_get_version_inblk+0xcc>
200251b0:	4625      	mov	r5, r4
200251b2:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 200251d4 <bbm_get_version_inblk+0xd0>
200251b6:	f8df b020 	ldr.w	fp, [pc, #32]	@ 200251d8 <bbm_get_version_inblk+0xd4>
200251ba:	e7d1      	b.n	20025160 <bbm_get_version_inblk+0x5c>
200251bc:	2004cc98 	.word	0x2004cc98
200251c0:	2004cc94 	.word	0x2004cc94
200251c4:	20026c47 	.word	0x20026c47
200251c8:	20026c74 	.word	0x20026c74
200251cc:	20026ca5 	.word	0x20026ca5
200251d0:	200449a4 	.word	0x200449a4
200251d4:	200449a8 	.word	0x200449a8
200251d8:	5366424d 	.word	0x5366424d

200251dc <bbm_get_map_table>:
200251dc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200251e0:	2801      	cmp	r0, #1
200251e2:	4607      	mov	r7, r0
200251e4:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 20025344 <bbm_get_map_table+0x168>
200251e8:	b087      	sub	sp, #28
200251ea:	dd0a      	ble.n	20025202 <bbm_get_map_table+0x26>
200251ec:	f8db 3000 	ldr.w	r3, [fp]
200251f0:	b91b      	cbnz	r3, 200251fa <bbm_get_map_table+0x1e>
200251f2:	2000      	movs	r0, #0
200251f4:	b007      	add	sp, #28
200251f6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200251fa:	4601      	mov	r1, r0
200251fc:	4847      	ldr	r0, [pc, #284]	@ (2002531c <bbm_get_map_table+0x140>)
200251fe:	4798      	blx	r3
20025200:	e7f7      	b.n	200251f2 <bbm_get_map_table+0x16>
20025202:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 20025348 <bbm_get_map_table+0x16c>
20025206:	2800      	cmp	r0, #0
20025208:	d163      	bne.n	200252d2 <bbm_get_map_table+0xf6>
2002520a:	f8b8 6000 	ldrh.w	r6, [r8]
2002520e:	f8b8 5002 	ldrh.w	r5, [r8, #2]
20025212:	2e00      	cmp	r6, #0
20025214:	d062      	beq.n	200252dc <bbm_get_map_table+0x100>
20025216:	4630      	mov	r0, r6
20025218:	a904      	add	r1, sp, #16
2002521a:	f7ff ff73 	bl	20025104 <bbm_get_version_inblk>
2002521e:	4681      	mov	r9, r0
20025220:	2d00      	cmp	r5, #0
20025222:	d05d      	beq.n	200252e0 <bbm_get_map_table+0x104>
20025224:	4628      	mov	r0, r5
20025226:	a905      	add	r1, sp, #20
20025228:	f7ff ff6c 	bl	20025104 <bbm_get_version_inblk>
2002522c:	4604      	mov	r4, r0
2002522e:	f8db a000 	ldr.w	sl, [fp]
20025232:	f1ba 0f00 	cmp.w	sl, #0
20025236:	d005      	beq.n	20025244 <bbm_get_map_table+0x68>
20025238:	4623      	mov	r3, r4
2002523a:	4632      	mov	r2, r6
2002523c:	4649      	mov	r1, r9
2002523e:	4838      	ldr	r0, [pc, #224]	@ (20025320 <bbm_get_map_table+0x144>)
20025240:	9500      	str	r5, [sp, #0]
20025242:	47d0      	blx	sl
20025244:	45a1      	cmp	r9, r4
20025246:	d0d4      	beq.n	200251f2 <bbm_get_map_table+0x16>
20025248:	f04f 0200 	mov.w	r2, #0
2002524c:	bf98      	it	ls
2002524e:	462e      	movls	r6, r5
20025250:	f107 0308 	add.w	r3, r7, #8
20025254:	bf94      	ite	ls
20025256:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
2002525a:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
2002525e:	e9cd 2201 	strd	r2, r2, [sp, #4]
20025262:	4b30      	ldr	r3, [pc, #192]	@ (20025324 <bbm_get_map_table+0x148>)
20025264:	bf88      	it	hi
20025266:	f8dd a010 	ldrhi.w	sl, [sp, #16]
2002526a:	681b      	ldr	r3, [r3, #0]
2002526c:	bf98      	it	ls
2002526e:	f8dd a014 	ldrls.w	sl, [sp, #20]
20025272:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 2002534c <bbm_get_map_table+0x170>
20025276:	9300      	str	r3, [sp, #0]
20025278:	4651      	mov	r1, sl
2002527a:	4630      	mov	r0, r6
2002527c:	f8d8 3000 	ldr.w	r3, [r8]
20025280:	bf88      	it	hi
20025282:	464c      	movhi	r4, r9
20025284:	f7fb faa0 	bl	200207c8 <port_read_page>
20025288:	2800      	cmp	r0, #0
2002528a:	f8db 5000 	ldr.w	r5, [fp]
2002528e:	dd38      	ble.n	20025302 <bbm_get_map_table+0x126>
20025290:	f8d8 8000 	ldr.w	r8, [r8]
20025294:	4b24      	ldr	r3, [pc, #144]	@ (20025328 <bbm_get_map_table+0x14c>)
20025296:	f8d8 2000 	ldr.w	r2, [r8]
2002529a:	429a      	cmp	r2, r3
2002529c:	d12b      	bne.n	200252f6 <bbm_get_map_table+0x11a>
2002529e:	2110      	movs	r1, #16
200252a0:	4640      	mov	r0, r8
200252a2:	f7ff fee7 	bl	20025074 <bbm_crc_check>
200252a6:	f8d8 2010 	ldr.w	r2, [r8, #16]
200252aa:	4601      	mov	r1, r0
200252ac:	4282      	cmp	r2, r0
200252ae:	d11e      	bne.n	200252ee <bbm_get_map_table+0x112>
200252b0:	f8d8 1004 	ldr.w	r1, [r8, #4]
200252b4:	f3c1 011e 	ubfx	r1, r1, #0, #31
200252b8:	42a1      	cmp	r1, r4
200252ba:	d113      	bne.n	200252e4 <bbm_get_map_table+0x108>
200252bc:	f44f 7202 	mov.w	r2, #520	@ 0x208
200252c0:	481a      	ldr	r0, [pc, #104]	@ (2002532c <bbm_get_map_table+0x150>)
200252c2:	4641      	mov	r1, r8
200252c4:	fb02 0007 	mla	r0, r2, r7, r0
200252c8:	f001 f867 	bl	2002639a <memcpy>
200252cc:	bb0d      	cbnz	r5, 20025312 <bbm_get_map_table+0x136>
200252ce:	4620      	mov	r0, r4
200252d0:	e790      	b.n	200251f4 <bbm_get_map_table+0x18>
200252d2:	f8b8 6004 	ldrh.w	r6, [r8, #4]
200252d6:	f8b8 5006 	ldrh.w	r5, [r8, #6]
200252da:	e79a      	b.n	20025212 <bbm_get_map_table+0x36>
200252dc:	46b1      	mov	r9, r6
200252de:	e79f      	b.n	20025220 <bbm_get_map_table+0x44>
200252e0:	462c      	mov	r4, r5
200252e2:	e7a4      	b.n	2002522e <bbm_get_map_table+0x52>
200252e4:	b115      	cbz	r5, 200252ec <bbm_get_map_table+0x110>
200252e6:	4622      	mov	r2, r4
200252e8:	4811      	ldr	r0, [pc, #68]	@ (20025330 <bbm_get_map_table+0x154>)
200252ea:	47a8      	blx	r5
200252ec:	e7fe      	b.n	200252ec <bbm_get_map_table+0x110>
200252ee:	b10d      	cbz	r5, 200252f4 <bbm_get_map_table+0x118>
200252f0:	4810      	ldr	r0, [pc, #64]	@ (20025334 <bbm_get_map_table+0x158>)
200252f2:	47a8      	blx	r5
200252f4:	e7fe      	b.n	200252f4 <bbm_get_map_table+0x118>
200252f6:	b11d      	cbz	r5, 20025300 <bbm_get_map_table+0x124>
200252f8:	4652      	mov	r2, sl
200252fa:	4631      	mov	r1, r6
200252fc:	480e      	ldr	r0, [pc, #56]	@ (20025338 <bbm_get_map_table+0x15c>)
200252fe:	47a8      	blx	r5
20025300:	e7fe      	b.n	20025300 <bbm_get_map_table+0x124>
20025302:	2d00      	cmp	r5, #0
20025304:	f43f af75 	beq.w	200251f2 <bbm_get_map_table+0x16>
20025308:	4652      	mov	r2, sl
2002530a:	4631      	mov	r1, r6
2002530c:	480b      	ldr	r0, [pc, #44]	@ (2002533c <bbm_get_map_table+0x160>)
2002530e:	47a8      	blx	r5
20025310:	e76f      	b.n	200251f2 <bbm_get_map_table+0x16>
20025312:	4621      	mov	r1, r4
20025314:	480a      	ldr	r0, [pc, #40]	@ (20025340 <bbm_get_map_table+0x164>)
20025316:	47a8      	blx	r5
20025318:	e7d9      	b.n	200252ce <bbm_get_map_table+0xf2>
2002531a:	bf00      	nop
2002531c:	20026cc3 	.word	0x20026cc3
20025320:	20026cd7 	.word	0x20026cd7
20025324:	200449a4 	.word	0x200449a4
20025328:	5366424d 	.word	0x5366424d
2002532c:	2004ccac 	.word	0x2004ccac
20025330:	20026cfd 	.word	0x20026cfd
20025334:	20026d47 	.word	0x20026d47
20025338:	20026d59 	.word	0x20026d59
2002533c:	20026d8e 	.word	0x20026d8e
20025340:	20026dba 	.word	0x20026dba
20025344:	2004cc94 	.word	0x2004cc94
20025348:	2004d0bc 	.word	0x2004d0bc
2002534c:	2004cc98 	.word	0x2004cc98

20025350 <bbm_get_page_num>:
20025350:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20025354:	4605      	mov	r5, r0
20025356:	2400      	movs	r4, #0
20025358:	4f13      	ldr	r7, [pc, #76]	@ (200253a8 <bbm_get_page_num+0x58>)
2002535a:	4e14      	ldr	r6, [pc, #80]	@ (200253ac <bbm_get_page_num+0x5c>)
2002535c:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 200253b0 <bbm_get_page_num+0x60>
20025360:	b085      	sub	sp, #20
20025362:	6839      	ldr	r1, [r7, #0]
20025364:	6833      	ldr	r3, [r6, #0]
20025366:	fbb3 f3f1 	udiv	r3, r3, r1
2002536a:	42a3      	cmp	r3, r4
2002536c:	d802      	bhi.n	20025374 <bbm_get_page_num+0x24>
2002536e:	f04f 34ff 	mov.w	r4, #4294967295
20025372:	e015      	b.n	200253a0 <bbm_get_page_num+0x50>
20025374:	2200      	movs	r2, #0
20025376:	e9cd 2201 	strd	r2, r2, [sp, #4]
2002537a:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 200253b4 <bbm_get_page_num+0x64>
2002537e:	9100      	str	r1, [sp, #0]
20025380:	4628      	mov	r0, r5
20025382:	4621      	mov	r1, r4
20025384:	f8d9 3000 	ldr.w	r3, [r9]
20025388:	f7fb fa1e 	bl	200207c8 <port_read_page>
2002538c:	b120      	cbz	r0, 20025398 <bbm_get_page_num+0x48>
2002538e:	f8d9 3000 	ldr.w	r3, [r9]
20025392:	681b      	ldr	r3, [r3, #0]
20025394:	4543      	cmp	r3, r8
20025396:	d101      	bne.n	2002539c <bbm_get_page_num+0x4c>
20025398:	3401      	adds	r4, #1
2002539a:	e7e2      	b.n	20025362 <bbm_get_page_num+0x12>
2002539c:	3301      	adds	r3, #1
2002539e:	d1fb      	bne.n	20025398 <bbm_get_page_num+0x48>
200253a0:	4620      	mov	r0, r4
200253a2:	b005      	add	sp, #20
200253a4:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200253a8:	200449a4 	.word	0x200449a4
200253ac:	200449a8 	.word	0x200449a8
200253b0:	5366424d 	.word	0x5366424d
200253b4:	2004cc98 	.word	0x2004cc98

200253b8 <bbm_read_page>:
200253b8:	b5f0      	push	{r4, r5, r6, r7, lr}
200253ba:	4604      	mov	r4, r0
200253bc:	b085      	sub	sp, #20
200253be:	b280      	uxth	r0, r0
200253c0:	461f      	mov	r7, r3
200253c2:	460d      	mov	r5, r1
200253c4:	4616      	mov	r6, r2
200253c6:	f7ff fe69 	bl	2002509c <bbm_get_phy_blk>
200253ca:	1c43      	adds	r3, r0, #1
200253cc:	d108      	bne.n	200253e0 <bbm_read_page+0x28>
200253ce:	4b0a      	ldr	r3, [pc, #40]	@ (200253f8 <bbm_read_page+0x40>)
200253d0:	681b      	ldr	r3, [r3, #0]
200253d2:	b113      	cbz	r3, 200253da <bbm_read_page+0x22>
200253d4:	4621      	mov	r1, r4
200253d6:	4809      	ldr	r0, [pc, #36]	@ (200253fc <bbm_read_page+0x44>)
200253d8:	4798      	blx	r3
200253da:	2000      	movs	r0, #0
200253dc:	b005      	add	sp, #20
200253de:	bdf0      	pop	{r4, r5, r6, r7, pc}
200253e0:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
200253e2:	4632      	mov	r2, r6
200253e4:	9302      	str	r3, [sp, #8]
200253e6:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
200253e8:	4629      	mov	r1, r5
200253ea:	9301      	str	r3, [sp, #4]
200253ec:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
200253ee:	9300      	str	r3, [sp, #0]
200253f0:	463b      	mov	r3, r7
200253f2:	f7fb f9e9 	bl	200207c8 <port_read_page>
200253f6:	e7f1      	b.n	200253dc <bbm_read_page+0x24>
200253f8:	2004cc94 	.word	0x2004cc94
200253fc:	20026dcd 	.word	0x20026dcd

20025400 <port_write_page>:
20025400:	4b01      	ldr	r3, [pc, #4]	@ (20025408 <port_write_page+0x8>)
20025402:	6818      	ldr	r0, [r3, #0]
20025404:	4770      	bx	lr
20025406:	bf00      	nop
20025408:	200449a4 	.word	0x200449a4

2002540c <bbm_write_talbe.isra.0>:
2002540c:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
2002540e:	4604      	mov	r4, r0
20025410:	4608      	mov	r0, r1
20025412:	460e      	mov	r6, r1
20025414:	f7ff ff9c 	bl	20025350 <bbm_get_page_num>
20025418:	1e05      	subs	r5, r0, #0
2002541a:	db25      	blt.n	20025468 <bbm_write_talbe.isra.0+0x5c>
2002541c:	4b13      	ldr	r3, [pc, #76]	@ (2002546c <bbm_write_talbe.isra.0+0x60>)
2002541e:	681a      	ldr	r2, [r3, #0]
20025420:	4b13      	ldr	r3, [pc, #76]	@ (20025470 <bbm_write_talbe.isra.0+0x64>)
20025422:	681b      	ldr	r3, [r3, #0]
20025424:	fbb3 f3f2 	udiv	r3, r3, r2
20025428:	429d      	cmp	r5, r3
2002542a:	da1d      	bge.n	20025468 <bbm_write_talbe.isra.0+0x5c>
2002542c:	4f11      	ldr	r7, [pc, #68]	@ (20025474 <bbm_write_talbe.isra.0+0x68>)
2002542e:	21ff      	movs	r1, #255	@ 0xff
20025430:	6838      	ldr	r0, [r7, #0]
20025432:	f000 ff43 	bl	200262bc <memset>
20025436:	4264      	negs	r4, r4
20025438:	490f      	ldr	r1, [pc, #60]	@ (20025478 <bbm_write_talbe.isra.0+0x6c>)
2002543a:	f404 7402 	and.w	r4, r4, #520	@ 0x208
2002543e:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025442:	6838      	ldr	r0, [r7, #0]
20025444:	4421      	add	r1, r4
20025446:	f000 ffa8 	bl	2002639a <memcpy>
2002544a:	6838      	ldr	r0, [r7, #0]
2002544c:	b160      	cbz	r0, 20025468 <bbm_write_talbe.isra.0+0x5c>
2002544e:	6802      	ldr	r2, [r0, #0]
20025450:	4b0a      	ldr	r3, [pc, #40]	@ (2002547c <bbm_write_talbe.isra.0+0x70>)
20025452:	429a      	cmp	r2, r3
20025454:	d108      	bne.n	20025468 <bbm_write_talbe.isra.0+0x5c>
20025456:	f7ff fdbd 	bl	20024fd4 <bbm_map_check.part.0>
2002545a:	2300      	movs	r3, #0
2002545c:	9300      	str	r3, [sp, #0]
2002545e:	4629      	mov	r1, r5
20025460:	4630      	mov	r0, r6
20025462:	683a      	ldr	r2, [r7, #0]
20025464:	f7ff ffcc 	bl	20025400 <port_write_page>
20025468:	b003      	add	sp, #12
2002546a:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002546c:	200449a4 	.word	0x200449a4
20025470:	200449a8 	.word	0x200449a8
20025474:	2004cc98 	.word	0x2004cc98
20025478:	2004ccac 	.word	0x2004ccac
2002547c:	5366424d 	.word	0x5366424d

20025480 <port_erase_block>:
20025480:	2000      	movs	r0, #0
20025482:	4770      	bx	lr

20025484 <bbm_init_table>:
20025484:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025488:	4c7c      	ldr	r4, [pc, #496]	@ (2002567c <bbm_init_table+0x1f8>)
2002548a:	4b7d      	ldr	r3, [pc, #500]	@ (20025680 <bbm_init_table+0x1fc>)
2002548c:	6822      	ldr	r2, [r4, #0]
2002548e:	b085      	sub	sp, #20
20025490:	429a      	cmp	r2, r3
20025492:	f000 80ed 	beq.w	20025670 <bbm_init_table+0x1ec>
20025496:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
2002549a:	429a      	cmp	r2, r3
2002549c:	f000 80e8 	beq.w	20025670 <bbm_init_table+0x1ec>
200254a0:	6023      	str	r3, [r4, #0]
200254a2:	2301      	movs	r3, #1
200254a4:	6063      	str	r3, [r4, #4]
200254a6:	2300      	movs	r3, #0
200254a8:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 200256b4 <bbm_init_table+0x230>
200254ac:	8123      	strh	r3, [r4, #8]
200254ae:	f8d9 3000 	ldr.w	r3, [r9]
200254b2:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 200256b8 <bbm_init_table+0x234>
200254b6:	3b04      	subs	r3, #4
200254b8:	f8df a200 	ldr.w	sl, [pc, #512]	@ 200256bc <bbm_init_table+0x238>
200254bc:	8163      	strh	r3, [r4, #10]
200254be:	f8d8 3000 	ldr.w	r3, [r8]
200254c2:	f8da 5000 	ldr.w	r5, [sl]
200254c6:	3b01      	subs	r3, #1
200254c8:	4e6e      	ldr	r6, [pc, #440]	@ (20025684 <bbm_init_table+0x200>)
200254ca:	81a3      	strh	r3, [r4, #12]
200254cc:	81e5      	strh	r5, [r4, #14]
200254ce:	f8d8 3000 	ldr.w	r3, [r8]
200254d2:	429d      	cmp	r5, r3
200254d4:	db10      	blt.n	200254f8 <bbm_init_table+0x74>
200254d6:	2500      	movs	r5, #0
200254d8:	462f      	mov	r7, r5
200254da:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 20025684 <bbm_init_table+0x200>
200254de:	f8da 6000 	ldr.w	r6, [sl]
200254e2:	42b5      	cmp	r5, r6
200254e4:	db1d      	blt.n	20025522 <bbm_init_table+0x9e>
200254e6:	8963      	ldrh	r3, [r4, #10]
200254e8:	2b00      	cmp	r3, #0
200254ea:	d148      	bne.n	2002557e <bbm_init_table+0xfa>
200254ec:	4b65      	ldr	r3, [pc, #404]	@ (20025684 <bbm_init_table+0x200>)
200254ee:	681b      	ldr	r3, [r3, #0]
200254f0:	b10b      	cbz	r3, 200254f6 <bbm_init_table+0x72>
200254f2:	4865      	ldr	r0, [pc, #404]	@ (20025688 <bbm_init_table+0x204>)
200254f4:	4798      	blx	r3
200254f6:	e7fe      	b.n	200254f6 <bbm_init_table+0x72>
200254f8:	4628      	mov	r0, r5
200254fa:	f7fb f9cb 	bl	20020894 <bbm_get_bb>
200254fe:	b950      	cbnz	r0, 20025516 <bbm_init_table+0x92>
20025500:	4628      	mov	r0, r5
20025502:	f7ff ffbd 	bl	20025480 <port_erase_block>
20025506:	b120      	cbz	r0, 20025512 <bbm_init_table+0x8e>
20025508:	6833      	ldr	r3, [r6, #0]
2002550a:	b113      	cbz	r3, 20025512 <bbm_init_table+0x8e>
2002550c:	4629      	mov	r1, r5
2002550e:	485f      	ldr	r0, [pc, #380]	@ (2002568c <bbm_init_table+0x208>)
20025510:	4798      	blx	r3
20025512:	3501      	adds	r5, #1
20025514:	e7db      	b.n	200254ce <bbm_init_table+0x4a>
20025516:	6833      	ldr	r3, [r6, #0]
20025518:	2b00      	cmp	r3, #0
2002551a:	d0fa      	beq.n	20025512 <bbm_init_table+0x8e>
2002551c:	4629      	mov	r1, r5
2002551e:	485c      	ldr	r0, [pc, #368]	@ (20025690 <bbm_init_table+0x20c>)
20025520:	e7f6      	b.n	20025510 <bbm_init_table+0x8c>
20025522:	4628      	mov	r0, r5
20025524:	f7fb f9b6 	bl	20020894 <bbm_get_bb>
20025528:	b338      	cbz	r0, 2002557a <bbm_init_table+0xf6>
2002552a:	f8db 3000 	ldr.w	r3, [fp]
2002552e:	b113      	cbz	r3, 20025536 <bbm_init_table+0xb2>
20025530:	4629      	mov	r1, r5
20025532:	4858      	ldr	r0, [pc, #352]	@ (20025694 <bbm_init_table+0x210>)
20025534:	4798      	blx	r3
20025536:	89a0      	ldrh	r0, [r4, #12]
20025538:	f7fb f9ac 	bl	20020894 <bbm_get_bb>
2002553c:	89a3      	ldrh	r3, [r4, #12]
2002553e:	4606      	mov	r6, r0
20025540:	3b01      	subs	r3, #1
20025542:	81a3      	strh	r3, [r4, #12]
20025544:	8963      	ldrh	r3, [r4, #10]
20025546:	3b01      	subs	r3, #1
20025548:	b29b      	uxth	r3, r3
2002554a:	8163      	strh	r3, [r4, #10]
2002554c:	b108      	cbz	r0, 20025552 <bbm_init_table+0xce>
2002554e:	2b00      	cmp	r3, #0
20025550:	d1f1      	bne.n	20025536 <bbm_init_table+0xb2>
20025552:	f8db 3000 	ldr.w	r3, [fp]
20025556:	b11b      	cbz	r3, 20025560 <bbm_init_table+0xdc>
20025558:	463a      	mov	r2, r7
2002555a:	4629      	mov	r1, r5
2002555c:	484e      	ldr	r0, [pc, #312]	@ (20025698 <bbm_init_table+0x214>)
2002555e:	4798      	blx	r3
20025560:	b93e      	cbnz	r6, 20025572 <bbm_init_table+0xee>
20025562:	89a2      	ldrh	r2, [r4, #12]
20025564:	1dbb      	adds	r3, r7, #6
20025566:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
2002556a:	3201      	adds	r2, #1
2002556c:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20025570:	805a      	strh	r2, [r3, #2]
20025572:	8923      	ldrh	r3, [r4, #8]
20025574:	3701      	adds	r7, #1
20025576:	3301      	adds	r3, #1
20025578:	8123      	strh	r3, [r4, #8]
2002557a:	3501      	adds	r5, #1
2002557c:	e7af      	b.n	200254de <bbm_init_table+0x5a>
2002557e:	2110      	movs	r1, #16
20025580:	483e      	ldr	r0, [pc, #248]	@ (2002567c <bbm_init_table+0x1f8>)
20025582:	f7ff fd77 	bl	20025074 <bbm_crc_check>
20025586:	f8d9 1000 	ldr.w	r1, [r9]
2002558a:	6120      	str	r0, [r4, #16]
2002558c:	3904      	subs	r1, #4
2002558e:	0089      	lsls	r1, r1, #2
20025590:	4842      	ldr	r0, [pc, #264]	@ (2002569c <bbm_init_table+0x218>)
20025592:	f7ff fd6f 	bl	20025074 <bbm_crc_check>
20025596:	f44f 7202 	mov.w	r2, #520	@ 0x208
2002559a:	4938      	ldr	r1, [pc, #224]	@ (2002567c <bbm_init_table+0x1f8>)
2002559c:	6160      	str	r0, [r4, #20]
2002559e:	1888      	adds	r0, r1, r2
200255a0:	f000 fefb 	bl	2002639a <memcpy>
200255a4:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
200255a8:	2110      	movs	r1, #16
200255aa:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
200255ae:	483c      	ldr	r0, [pc, #240]	@ (200256a0 <bbm_init_table+0x21c>)
200255b0:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
200255b4:	f7ff fd5e 	bl	20025074 <bbm_crc_check>
200255b8:	2700      	movs	r7, #0
200255ba:	f8df a104 	ldr.w	sl, [pc, #260]	@ 200256c0 <bbm_init_table+0x23c>
200255be:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 200256c4 <bbm_init_table+0x240>
200255c2:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
200255c6:	f8d8 3000 	ldr.w	r3, [r8]
200255ca:	429e      	cmp	r6, r3
200255cc:	db08      	blt.n	200255e0 <bbm_init_table+0x15c>
200255ce:	2f03      	cmp	r7, #3
200255d0:	dc2f      	bgt.n	20025632 <bbm_init_table+0x1ae>
200255d2:	4b2c      	ldr	r3, [pc, #176]	@ (20025684 <bbm_init_table+0x200>)
200255d4:	681b      	ldr	r3, [r3, #0]
200255d6:	b113      	cbz	r3, 200255de <bbm_init_table+0x15a>
200255d8:	4639      	mov	r1, r7
200255da:	4832      	ldr	r0, [pc, #200]	@ (200256a4 <bbm_init_table+0x220>)
200255dc:	4798      	blx	r3
200255de:	e7fe      	b.n	200255de <bbm_init_table+0x15a>
200255e0:	4630      	mov	r0, r6
200255e2:	f7fb f957 	bl	20020894 <bbm_get_bb>
200255e6:	4604      	mov	r4, r0
200255e8:	bb08      	cbnz	r0, 2002562e <bbm_init_table+0x1aa>
200255ea:	f8da 5000 	ldr.w	r5, [sl]
200255ee:	21ff      	movs	r1, #255	@ 0xff
200255f0:	462a      	mov	r2, r5
200255f2:	f8d9 0000 	ldr.w	r0, [r9]
200255f6:	f000 fe61 	bl	200262bc <memset>
200255fa:	e9cd 4401 	strd	r4, r4, [sp, #4]
200255fe:	9500      	str	r5, [sp, #0]
20025600:	f8d9 3000 	ldr.w	r3, [r9]
20025604:	4622      	mov	r2, r4
20025606:	4621      	mov	r1, r4
20025608:	4630      	mov	r0, r6
2002560a:	f7fb f8dd 	bl	200207c8 <port_read_page>
2002560e:	f8da 3000 	ldr.w	r3, [sl]
20025612:	4298      	cmp	r0, r3
20025614:	d109      	bne.n	2002562a <bbm_init_table+0x1a6>
20025616:	f8d9 3000 	ldr.w	r3, [r9]
2002561a:	681b      	ldr	r3, [r3, #0]
2002561c:	3301      	adds	r3, #1
2002561e:	bf01      	itttt	eq
20025620:	4b21      	ldreq	r3, [pc, #132]	@ (200256a8 <bbm_init_table+0x224>)
20025622:	1d3a      	addeq	r2, r7, #4
20025624:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
20025628:	3701      	addeq	r7, #1
2002562a:	2f03      	cmp	r7, #3
2002562c:	dc01      	bgt.n	20025632 <bbm_init_table+0x1ae>
2002562e:	3601      	adds	r6, #1
20025630:	e7c9      	b.n	200255c6 <bbm_init_table+0x142>
20025632:	2500      	movs	r5, #0
20025634:	4c1c      	ldr	r4, [pc, #112]	@ (200256a8 <bbm_init_table+0x224>)
20025636:	2000      	movs	r0, #0
20025638:	8921      	ldrh	r1, [r4, #8]
2002563a:	f7ff fee7 	bl	2002540c <bbm_write_talbe.isra.0>
2002563e:	8923      	ldrh	r3, [r4, #8]
20025640:	2001      	movs	r0, #1
20025642:	8961      	ldrh	r1, [r4, #10]
20025644:	8023      	strh	r3, [r4, #0]
20025646:	8223      	strh	r3, [r4, #16]
20025648:	8125      	strh	r5, [r4, #8]
2002564a:	f7ff fedf 	bl	2002540c <bbm_write_talbe.isra.0>
2002564e:	8963      	ldrh	r3, [r4, #10]
20025650:	8165      	strh	r5, [r4, #10]
20025652:	80a3      	strh	r3, [r4, #4]
20025654:	8263      	strh	r3, [r4, #18]
20025656:	89a3      	ldrh	r3, [r4, #12]
20025658:	8063      	strh	r3, [r4, #2]
2002565a:	89e3      	ldrh	r3, [r4, #14]
2002565c:	80e3      	strh	r3, [r4, #6]
2002565e:	4b09      	ldr	r3, [pc, #36]	@ (20025684 <bbm_init_table+0x200>)
20025660:	681b      	ldr	r3, [r3, #0]
20025662:	b10b      	cbz	r3, 20025668 <bbm_init_table+0x1e4>
20025664:	4811      	ldr	r0, [pc, #68]	@ (200256ac <bbm_init_table+0x228>)
20025666:	4798      	blx	r3
20025668:	2000      	movs	r0, #0
2002566a:	b005      	add	sp, #20
2002566c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025670:	4b04      	ldr	r3, [pc, #16]	@ (20025684 <bbm_init_table+0x200>)
20025672:	681b      	ldr	r3, [r3, #0]
20025674:	b10b      	cbz	r3, 2002567a <bbm_init_table+0x1f6>
20025676:	480e      	ldr	r0, [pc, #56]	@ (200256b0 <bbm_init_table+0x22c>)
20025678:	4798      	blx	r3
2002567a:	e7fe      	b.n	2002567a <bbm_init_table+0x1f6>
2002567c:	2004ccac 	.word	0x2004ccac
20025680:	5366424d 	.word	0x5366424d
20025684:	2004cc94 	.word	0x2004cc94
20025688:	20026e62 	.word	0x20026e62
2002568c:	20026df0 	.word	0x20026df0
20025690:	20026e12 	.word	0x20026e12
20025694:	20026e2f 	.word	0x20026e2f
20025698:	20026e4e 	.word	0x20026e4e
2002569c:	2004ccc4 	.word	0x2004ccc4
200256a0:	2004ceb4 	.word	0x2004ceb4
200256a4:	20026e7c 	.word	0x20026e7c
200256a8:	2004d0bc 	.word	0x2004d0bc
200256ac:	20026ea3 	.word	0x20026ea3
200256b0:	20026ebf 	.word	0x20026ebf
200256b4:	2004cca4 	.word	0x2004cca4
200256b8:	2004cca0 	.word	0x2004cca0
200256bc:	2004cca8 	.word	0x2004cca8
200256c0:	200449a4 	.word	0x200449a4
200256c4:	2004cc98 	.word	0x2004cc98

200256c8 <sif_bbm_init>:
200256c8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200256cc:	b087      	sub	sp, #28
200256ce:	2900      	cmp	r1, #0
200256d0:	f000 8129 	beq.w	20025926 <sif_bbm_init+0x25e>
200256d4:	4b95      	ldr	r3, [pc, #596]	@ (2002592c <sif_bbm_init+0x264>)
200256d6:	681a      	ldr	r2, [r3, #0]
200256d8:	2a01      	cmp	r2, #1
200256da:	d108      	bne.n	200256ee <sif_bbm_init+0x26>
200256dc:	4b94      	ldr	r3, [pc, #592]	@ (20025930 <sif_bbm_init+0x268>)
200256de:	681b      	ldr	r3, [r3, #0]
200256e0:	b10b      	cbz	r3, 200256e6 <sif_bbm_init+0x1e>
200256e2:	4894      	ldr	r0, [pc, #592]	@ (20025934 <sif_bbm_init+0x26c>)
200256e4:	4798      	blx	r3
200256e6:	2000      	movs	r0, #0
200256e8:	b007      	add	sp, #28
200256ea:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200256ee:	2201      	movs	r2, #1
200256f0:	601a      	str	r2, [r3, #0]
200256f2:	4b91      	ldr	r3, [pc, #580]	@ (20025938 <sif_bbm_init+0x270>)
200256f4:	681c      	ldr	r4, [r3, #0]
200256f6:	b904      	cbnz	r4, 200256fa <sif_bbm_init+0x32>
200256f8:	e7fe      	b.n	200256f8 <sif_bbm_init+0x30>
200256fa:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 20025978 <sif_bbm_init+0x2b0>
200256fe:	f8da 2000 	ldr.w	r2, [sl]
20025702:	b902      	cbnz	r2, 20025706 <sif_bbm_init+0x3e>
20025704:	e7fe      	b.n	20025704 <sif_bbm_init+0x3c>
20025706:	fbb0 f4f4 	udiv	r4, r0, r4
2002570a:	f04f 0800 	mov.w	r8, #0
2002570e:	4a8b      	ldr	r2, [pc, #556]	@ (2002593c <sif_bbm_init+0x274>)
20025710:	f8df b268 	ldr.w	fp, [pc, #616]	@ 2002597c <sif_bbm_init+0x2b4>
20025714:	0963      	lsrs	r3, r4, #5
20025716:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20025980 <sif_bbm_init+0x2b8>
2002571a:	6013      	str	r3, [r2, #0]
2002571c:	f8cb 4000 	str.w	r4, [fp]
20025720:	1ae4      	subs	r4, r4, r3
20025722:	4b87      	ldr	r3, [pc, #540]	@ (20025940 <sif_bbm_init+0x278>)
20025724:	2218      	movs	r2, #24
20025726:	f8c9 1000 	str.w	r1, [r9]
2002572a:	4886      	ldr	r0, [pc, #536]	@ (20025944 <sif_bbm_init+0x27c>)
2002572c:	2100      	movs	r1, #0
2002572e:	601c      	str	r4, [r3, #0]
20025730:	f000 fdc4 	bl	200262bc <memset>
20025734:	f44f 6282 	mov.w	r2, #1040	@ 0x410
20025738:	2100      	movs	r1, #0
2002573a:	4883      	ldr	r0, [pc, #524]	@ (20025948 <sif_bbm_init+0x280>)
2002573c:	f000 fdbe 	bl	200262bc <memset>
20025740:	4647      	mov	r7, r8
20025742:	4646      	mov	r6, r8
20025744:	f8db 3000 	ldr.w	r3, [fp]
20025748:	429c      	cmp	r4, r3
2002574a:	db02      	blt.n	20025752 <sif_bbm_init+0x8a>
2002574c:	f04f 35ff 	mov.w	r5, #4294967295
20025750:	e064      	b.n	2002581c <sif_bbm_init+0x154>
20025752:	4620      	mov	r0, r4
20025754:	f7fb f89e 	bl	20020894 <bbm_get_bb>
20025758:	4605      	mov	r5, r0
2002575a:	b138      	cbz	r0, 2002576c <sif_bbm_init+0xa4>
2002575c:	4b74      	ldr	r3, [pc, #464]	@ (20025930 <sif_bbm_init+0x268>)
2002575e:	681b      	ldr	r3, [r3, #0]
20025760:	b113      	cbz	r3, 20025768 <sif_bbm_init+0xa0>
20025762:	4621      	mov	r1, r4
20025764:	4879      	ldr	r0, [pc, #484]	@ (2002594c <sif_bbm_init+0x284>)
20025766:	4798      	blx	r3
20025768:	3401      	adds	r4, #1
2002576a:	e7eb      	b.n	20025744 <sif_bbm_init+0x7c>
2002576c:	f8da 2000 	ldr.w	r2, [sl]
20025770:	21ff      	movs	r1, #255	@ 0xff
20025772:	f8d9 0000 	ldr.w	r0, [r9]
20025776:	9205      	str	r2, [sp, #20]
20025778:	f000 fda0 	bl	200262bc <memset>
2002577c:	9a05      	ldr	r2, [sp, #20]
2002577e:	e9cd 5501 	strd	r5, r5, [sp, #4]
20025782:	9200      	str	r2, [sp, #0]
20025784:	f8d9 3000 	ldr.w	r3, [r9]
20025788:	462a      	mov	r2, r5
2002578a:	4629      	mov	r1, r5
2002578c:	4620      	mov	r0, r4
2002578e:	f7fb f81b 	bl	200207c8 <port_read_page>
20025792:	f8da 3000 	ldr.w	r3, [sl]
20025796:	4298      	cmp	r0, r3
20025798:	d12e      	bne.n	200257f8 <sif_bbm_init+0x130>
2002579a:	f8d9 1000 	ldr.w	r1, [r9]
2002579e:	486c      	ldr	r0, [pc, #432]	@ (20025950 <sif_bbm_init+0x288>)
200257a0:	680b      	ldr	r3, [r1, #0]
200257a2:	b2a2      	uxth	r2, r4
200257a4:	4283      	cmp	r3, r0
200257a6:	4b67      	ldr	r3, [pc, #412]	@ (20025944 <sif_bbm_init+0x27c>)
200257a8:	d11f      	bne.n	200257ea <sif_bbm_init+0x122>
200257aa:	f991 1007 	ldrsb.w	r1, [r1, #7]
200257ae:	2900      	cmp	r1, #0
200257b0:	bfb5      	itete	lt
200257b2:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
200257b6:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
200257ba:	808a      	strhlt	r2, [r1, #4]
200257bc:	3601      	addge	r6, #1
200257be:	bfb8      	it	lt
200257c0:	3701      	addlt	r7, #1
200257c2:	eb06 0208 	add.w	r2, r6, r8
200257c6:	443a      	add	r2, r7
200257c8:	2a03      	cmp	r2, #3
200257ca:	ddcd      	ble.n	20025768 <sif_bbm_init+0xa0>
200257cc:	2e00      	cmp	r6, #0
200257ce:	f000 8081 	beq.w	200258d4 <sif_bbm_init+0x20c>
200257d2:	2f00      	cmp	r7, #0
200257d4:	d07e      	beq.n	200258d4 <sif_bbm_init+0x20c>
200257d6:	2e01      	cmp	r6, #1
200257d8:	d001      	beq.n	200257de <sif_bbm_init+0x116>
200257da:	2f01      	cmp	r7, #1
200257dc:	d11e      	bne.n	2002581c <sif_bbm_init+0x154>
200257de:	8819      	ldrh	r1, [r3, #0]
200257e0:	891a      	ldrh	r2, [r3, #8]
200257e2:	b981      	cbnz	r1, 20025806 <sif_bbm_init+0x13e>
200257e4:	801a      	strh	r2, [r3, #0]
200257e6:	895a      	ldrh	r2, [r3, #10]
200257e8:	e013      	b.n	20025812 <sif_bbm_init+0x14a>
200257ea:	f108 0104 	add.w	r1, r8, #4
200257ee:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
200257f2:	f108 0801 	add.w	r8, r8, #1
200257f6:	e7e4      	b.n	200257c2 <sif_bbm_init+0xfa>
200257f8:	4b4d      	ldr	r3, [pc, #308]	@ (20025930 <sif_bbm_init+0x268>)
200257fa:	681b      	ldr	r3, [r3, #0]
200257fc:	2b00      	cmp	r3, #0
200257fe:	d0b3      	beq.n	20025768 <sif_bbm_init+0xa0>
20025800:	4854      	ldr	r0, [pc, #336]	@ (20025954 <sif_bbm_init+0x28c>)
20025802:	1c61      	adds	r1, r4, #1
20025804:	e7af      	b.n	20025766 <sif_bbm_init+0x9e>
20025806:	8859      	ldrh	r1, [r3, #2]
20025808:	b909      	cbnz	r1, 2002580e <sif_bbm_init+0x146>
2002580a:	805a      	strh	r2, [r3, #2]
2002580c:	e7eb      	b.n	200257e6 <sif_bbm_init+0x11e>
2002580e:	2a00      	cmp	r2, #0
20025810:	d0e9      	beq.n	200257e6 <sif_bbm_init+0x11e>
20025812:	8899      	ldrh	r1, [r3, #4]
20025814:	2900      	cmp	r1, #0
20025816:	d158      	bne.n	200258ca <sif_bbm_init+0x202>
20025818:	809a      	strh	r2, [r3, #4]
2002581a:	2502      	movs	r5, #2
2002581c:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 20025930 <sif_bbm_init+0x268>
20025820:	f8d9 4000 	ldr.w	r4, [r9]
20025824:	b124      	cbz	r4, 20025830 <sif_bbm_init+0x168>
20025826:	4643      	mov	r3, r8
20025828:	463a      	mov	r2, r7
2002582a:	4631      	mov	r1, r6
2002582c:	484a      	ldr	r0, [pc, #296]	@ (20025958 <sif_bbm_init+0x290>)
2002582e:	47a0      	blx	r4
20025830:	f8d9 3000 	ldr.w	r3, [r9]
20025834:	b113      	cbz	r3, 2002583c <sif_bbm_init+0x174>
20025836:	4629      	mov	r1, r5
20025838:	4848      	ldr	r0, [pc, #288]	@ (2002595c <sif_bbm_init+0x294>)
2002583a:	4798      	blx	r3
2002583c:	f035 0002 	bics.w	r0, r5, #2
20025840:	d164      	bne.n	2002590c <sif_bbm_init+0x244>
20025842:	f7ff fccb 	bl	200251dc <bbm_get_map_table>
20025846:	4605      	mov	r5, r0
20025848:	2001      	movs	r0, #1
2002584a:	f7ff fcc7 	bl	200251dc <bbm_get_map_table>
2002584e:	f8d9 6000 	ldr.w	r6, [r9]
20025852:	4604      	mov	r4, r0
20025854:	b13e      	cbz	r6, 20025866 <sif_bbm_init+0x19e>
20025856:	4a3b      	ldr	r2, [pc, #236]	@ (20025944 <sif_bbm_init+0x27c>)
20025858:	4629      	mov	r1, r5
2002585a:	8a53      	ldrh	r3, [r2, #18]
2002585c:	9300      	str	r3, [sp, #0]
2002585e:	8a12      	ldrh	r2, [r2, #16]
20025860:	4603      	mov	r3, r0
20025862:	483f      	ldr	r0, [pc, #252]	@ (20025960 <sif_bbm_init+0x298>)
20025864:	47b0      	blx	r6
20025866:	42a5      	cmp	r5, r4
20025868:	4c37      	ldr	r4, [pc, #220]	@ (20025948 <sif_bbm_init+0x280>)
2002586a:	dd35      	ble.n	200258d8 <sif_bbm_init+0x210>
2002586c:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025870:	4621      	mov	r1, r4
20025872:	18a0      	adds	r0, r4, r2
20025874:	f000 fd91 	bl	2002639a <memcpy>
20025878:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
2002587c:	2110      	movs	r1, #16
2002587e:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025882:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20025886:	f504 7002 	add.w	r0, r4, #520	@ 0x208
2002588a:	f7ff fbf3 	bl	20025074 <bbm_crc_check>
2002588e:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20025892:	2001      	movs	r0, #1
20025894:	4b2b      	ldr	r3, [pc, #172]	@ (20025944 <sif_bbm_init+0x27c>)
20025896:	8a59      	ldrh	r1, [r3, #18]
20025898:	f7ff fdb8 	bl	2002540c <bbm_write_talbe.isra.0>
2002589c:	6822      	ldr	r2, [r4, #0]
2002589e:	4b2c      	ldr	r3, [pc, #176]	@ (20025950 <sif_bbm_init+0x288>)
200258a0:	429a      	cmp	r2, r3
200258a2:	d12d      	bne.n	20025900 <sif_bbm_init+0x238>
200258a4:	4828      	ldr	r0, [pc, #160]	@ (20025948 <sif_bbm_init+0x280>)
200258a6:	f7ff fb95 	bl	20024fd4 <bbm_map_check.part.0>
200258aa:	f8d9 4000 	ldr.w	r4, [r9]
200258ae:	b12c      	cbz	r4, 200258bc <sif_bbm_init+0x1f4>
200258b0:	4b2c      	ldr	r3, [pc, #176]	@ (20025964 <sif_bbm_init+0x29c>)
200258b2:	4924      	ldr	r1, [pc, #144]	@ (20025944 <sif_bbm_init+0x27c>)
200258b4:	482c      	ldr	r0, [pc, #176]	@ (20025968 <sif_bbm_init+0x2a0>)
200258b6:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
200258ba:	47a0      	blx	r4
200258bc:	f8d9 3000 	ldr.w	r3, [r9]
200258c0:	2b00      	cmp	r3, #0
200258c2:	f43f af10 	beq.w	200256e6 <sif_bbm_init+0x1e>
200258c6:	4829      	ldr	r0, [pc, #164]	@ (2002596c <sif_bbm_init+0x2a4>)
200258c8:	e70c      	b.n	200256e4 <sif_bbm_init+0x1c>
200258ca:	88d9      	ldrh	r1, [r3, #6]
200258cc:	2900      	cmp	r1, #0
200258ce:	d1a4      	bne.n	2002581a <sif_bbm_init+0x152>
200258d0:	80da      	strh	r2, [r3, #6]
200258d2:	e7a2      	b.n	2002581a <sif_bbm_init+0x152>
200258d4:	2501      	movs	r5, #1
200258d6:	e7a1      	b.n	2002581c <sif_bbm_init+0x154>
200258d8:	dae0      	bge.n	2002589c <sif_bbm_init+0x1d4>
200258da:	f44f 7202 	mov.w	r2, #520	@ 0x208
200258de:	4620      	mov	r0, r4
200258e0:	18a1      	adds	r1, r4, r2
200258e2:	f000 fd5a 	bl	2002639a <memcpy>
200258e6:	79e3      	ldrb	r3, [r4, #7]
200258e8:	2110      	movs	r1, #16
200258ea:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
200258ee:	71e3      	strb	r3, [r4, #7]
200258f0:	4620      	mov	r0, r4
200258f2:	f7ff fbbf 	bl	20025074 <bbm_crc_check>
200258f6:	4b13      	ldr	r3, [pc, #76]	@ (20025944 <sif_bbm_init+0x27c>)
200258f8:	6120      	str	r0, [r4, #16]
200258fa:	8a19      	ldrh	r1, [r3, #16]
200258fc:	2000      	movs	r0, #0
200258fe:	e7cb      	b.n	20025898 <sif_bbm_init+0x1d0>
20025900:	f8d9 3000 	ldr.w	r3, [r9]
20025904:	b10b      	cbz	r3, 2002590a <sif_bbm_init+0x242>
20025906:	481a      	ldr	r0, [pc, #104]	@ (20025970 <sif_bbm_init+0x2a8>)
20025908:	4798      	blx	r3
2002590a:	e7fe      	b.n	2002590a <sif_bbm_init+0x242>
2002590c:	2d01      	cmp	r5, #1
2002590e:	d102      	bne.n	20025916 <sif_bbm_init+0x24e>
20025910:	f7ff fdb8 	bl	20025484 <bbm_init_table>
20025914:	e7c9      	b.n	200258aa <sif_bbm_init+0x1e2>
20025916:	f8d9 3000 	ldr.w	r3, [r9]
2002591a:	b11b      	cbz	r3, 20025924 <sif_bbm_init+0x25c>
2002591c:	f04f 31ff 	mov.w	r1, #4294967295
20025920:	4814      	ldr	r0, [pc, #80]	@ (20025974 <sif_bbm_init+0x2ac>)
20025922:	4798      	blx	r3
20025924:	e7fe      	b.n	20025924 <sif_bbm_init+0x25c>
20025926:	f04f 30ff 	mov.w	r0, #4294967295
2002592a:	e6dd      	b.n	200256e8 <sif_bbm_init+0x20>
2002592c:	2004cc9c 	.word	0x2004cc9c
20025930:	2004cc94 	.word	0x2004cc94
20025934:	20026ed3 	.word	0x20026ed3
20025938:	200449a8 	.word	0x200449a8
2002593c:	2004cca4 	.word	0x2004cca4
20025940:	2004cca8 	.word	0x2004cca8
20025944:	2004d0bc 	.word	0x2004d0bc
20025948:	2004ccac 	.word	0x2004ccac
2002594c:	20026f01 	.word	0x20026f01
20025950:	5366424d 	.word	0x5366424d
20025954:	20026f0d 	.word	0x20026f0d
20025958:	20026f2c 	.word	0x20026f2c
2002595c:	20026f4b 	.word	0x20026f4b
20025960:	20026f5d 	.word	0x20026f5d
20025964:	2004ceb4 	.word	0x2004ceb4
20025968:	20026fb8 	.word	0x20026fb8
2002596c:	20026fdc 	.word	0x20026fdc
20025970:	20026f81 	.word	0x20026f81
20025974:	20026f97 	.word	0x20026f97
20025978:	200449a4 	.word	0x200449a4
2002597c:	2004cca0 	.word	0x2004cca0
20025980:	2004cc98 	.word	0x2004cc98

20025984 <bbm_set_page_size>:
20025984:	4b01      	ldr	r3, [pc, #4]	@ (2002598c <bbm_set_page_size+0x8>)
20025986:	6018      	str	r0, [r3, #0]
20025988:	4770      	bx	lr
2002598a:	bf00      	nop
2002598c:	200449a4 	.word	0x200449a4

20025990 <bbm_set_blk_size>:
20025990:	4b01      	ldr	r3, [pc, #4]	@ (20025998 <bbm_set_blk_size+0x8>)
20025992:	6018      	str	r0, [r3, #0]
20025994:	4770      	bx	lr
20025996:	bf00      	nop
20025998:	200449a8 	.word	0x200449a8

2002599c <sf_crypto_cmac_gen_subkey>:
2002599c:	2300      	movs	r3, #0
2002599e:	b530      	push	{r4, r5, lr}
200259a0:	f100 0210 	add.w	r2, r0, #16
200259a4:	f101 0410 	add.w	r4, r1, #16
200259a8:	f812 5d01 	ldrb.w	r5, [r2, #-1]!
200259ac:	ea43 0345 	orr.w	r3, r3, r5, lsl #1
200259b0:	f804 3d01 	strb.w	r3, [r4, #-1]!
200259b4:	7813      	ldrb	r3, [r2, #0]
200259b6:	4282      	cmp	r2, r0
200259b8:	ea4f 13d3 	mov.w	r3, r3, lsr #7
200259bc:	d1f4      	bne.n	200259a8 <sf_crypto_cmac_gen_subkey+0xc>
200259be:	f992 3000 	ldrsb.w	r3, [r2]
200259c2:	2b00      	cmp	r3, #0
200259c4:	bfbe      	ittt	lt
200259c6:	7bcb      	ldrblt	r3, [r1, #15]
200259c8:	f083 0387 	eorlt.w	r3, r3, #135	@ 0x87
200259cc:	73cb      	strblt	r3, [r1, #15]
200259ce:	bd30      	pop	{r4, r5, pc}

200259d0 <sf_crypto_aes_cmac_init>:
200259d0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200259d4:	2a20      	cmp	r2, #32
200259d6:	4604      	mov	r4, r0
200259d8:	460e      	mov	r6, r1
200259da:	4615      	mov	r5, r2
200259dc:	b08c      	sub	sp, #48	@ 0x30
200259de:	d12e      	bne.n	20025a3e <sf_crypto_aes_cmac_init+0x6e>
200259e0:	b380      	cbz	r0, 20025a44 <sf_crypto_aes_cmac_init+0x74>
200259e2:	2710      	movs	r7, #16
200259e4:	ab04      	add	r3, sp, #16
200259e6:	6001      	str	r1, [r0, #0]
200259e8:	8082      	strh	r2, [r0, #4]
200259ea:	2100      	movs	r1, #0
200259ec:	463a      	mov	r2, r7
200259ee:	4618      	mov	r0, r3
200259f0:	f000 fc64 	bl	200262bc <memset>
200259f4:	2300      	movs	r3, #0
200259f6:	f10d 0820 	add.w	r8, sp, #32
200259fa:	4629      	mov	r1, r5
200259fc:	9000      	str	r0, [sp, #0]
200259fe:	461a      	mov	r2, r3
20025a00:	4630      	mov	r0, r6
20025a02:	e9cd 7801 	strd	r7, r8, [sp, #4]
20025a06:	f000 f8da 	bl	20025bbe <sf_crypto_aes_enc_sync>
20025a0a:	4605      	mov	r5, r0
20025a0c:	b100      	cbz	r0, 20025a10 <sf_crypto_aes_cmac_init+0x40>
20025a0e:	e7fe      	b.n	20025a0e <sf_crypto_aes_cmac_init+0x3e>
20025a10:	1da6      	adds	r6, r4, #6
20025a12:	4631      	mov	r1, r6
20025a14:	4640      	mov	r0, r8
20025a16:	f7ff ffc1 	bl	2002599c <sf_crypto_cmac_gen_subkey>
20025a1a:	4630      	mov	r0, r6
20025a1c:	f104 0116 	add.w	r1, r4, #22
20025a20:	f7ff ffbc 	bl	2002599c <sf_crypto_cmac_gen_subkey>
20025a24:	463a      	mov	r2, r7
20025a26:	4629      	mov	r1, r5
20025a28:	f104 0028 	add.w	r0, r4, #40	@ 0x28
20025a2c:	f000 fc46 	bl	200262bc <memset>
20025a30:	f240 1301 	movw	r3, #257	@ 0x101
20025a34:	8723      	strh	r3, [r4, #56]	@ 0x38
20025a36:	4628      	mov	r0, r5
20025a38:	b00c      	add	sp, #48	@ 0x30
20025a3a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025a3e:	f06f 0502 	mvn.w	r5, #2
20025a42:	e7f8      	b.n	20025a36 <sf_crypto_aes_cmac_init+0x66>
20025a44:	f04f 35ff 	mov.w	r5, #4294967295
20025a48:	e7f5      	b.n	20025a36 <sf_crypto_aes_cmac_init+0x66>

20025a4a <sf_crypto_aes_cmac_calc>:
20025a4a:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20025a4e:	b089      	sub	sp, #36	@ 0x24
20025a50:	460f      	mov	r7, r1
20025a52:	4604      	mov	r4, r0
20025a54:	9e10      	ldr	r6, [sp, #64]	@ 0x40
20025a56:	b138      	cbz	r0, 20025a68 <sf_crypto_aes_cmac_calc+0x1e>
20025a58:	b136      	cbz	r6, 20025a68 <sf_crypto_aes_cmac_calc+0x1e>
20025a5a:	f890 1039 	ldrb.w	r1, [r0, #57]	@ 0x39
20025a5e:	2900      	cmp	r1, #0
20025a60:	f000 80aa 	beq.w	20025bb8 <sf_crypto_aes_cmac_calc+0x16e>
20025a64:	b11a      	cbz	r2, 20025a6e <sf_crypto_aes_cmac_calc+0x24>
20025a66:	b957      	cbnz	r7, 20025a7e <sf_crypto_aes_cmac_calc+0x34>
20025a68:	f04f 30ff 	mov.w	r0, #4294967295
20025a6c:	e0a1      	b.n	20025bb2 <sf_crypto_aes_cmac_calc+0x168>
20025a6e:	f890 1038 	ldrb.w	r1, [r0, #56]	@ 0x38
20025a72:	b109      	cbz	r1, 20025a78 <sf_crypto_aes_cmac_calc+0x2e>
20025a74:	2b00      	cmp	r3, #0
20025a76:	d16e      	bne.n	20025b56 <sf_crypto_aes_cmac_calc+0x10c>
20025a78:	f06f 0003 	mvn.w	r0, #3
20025a7c:	e099      	b.n	20025bb2 <sf_crypto_aes_cmac_calc+0x168>
20025a7e:	f002 000f 	and.w	r0, r2, #15
20025a82:	b973      	cbnz	r3, 20025aa2 <sf_crypto_aes_cmac_calc+0x58>
20025a84:	2800      	cmp	r0, #0
20025a86:	d1f7      	bne.n	20025a78 <sf_crypto_aes_cmac_calc+0x2e>
20025a88:	e9cd 2601 	strd	r2, r6, [sp, #4]
20025a8c:	9700      	str	r7, [sp, #0]
20025a8e:	2303      	movs	r3, #3
20025a90:	88a1      	ldrh	r1, [r4, #4]
20025a92:	6820      	ldr	r0, [r4, #0]
20025a94:	f104 0228 	add.w	r2, r4, #40	@ 0x28
20025a98:	f000 f891 	bl	20025bbe <sf_crypto_aes_enc_sync>
20025a9c:	2800      	cmp	r0, #0
20025a9e:	d07b      	beq.n	20025b98 <sf_crypto_aes_cmac_calc+0x14e>
20025aa0:	e7fe      	b.n	20025aa0 <sf_crypto_aes_cmac_calc+0x56>
20025aa2:	320f      	adds	r2, #15
20025aa4:	ea4f 1812 	mov.w	r8, r2, lsr #4
20025aa8:	f108 31ff 	add.w	r1, r8, #4294967295
20025aac:	eb07 1101 	add.w	r1, r7, r1, lsl #4
20025ab0:	b3c0      	cbz	r0, 20025b24 <sf_crypto_aes_cmac_calc+0xda>
20025ab2:	f1c0 0910 	rsb	r9, r0, #16
20025ab6:	fa1f f989 	uxth.w	r9, r9
20025aba:	f1c9 0510 	rsb	r5, r9, #16
20025abe:	462a      	mov	r2, r5
20025ac0:	a804      	add	r0, sp, #16
20025ac2:	f000 fc6a 	bl	2002639a <memcpy>
20025ac6:	f105 0320 	add.w	r3, r5, #32
20025aca:	eb0d 0203 	add.w	r2, sp, r3
20025ace:	2380      	movs	r3, #128	@ 0x80
20025ad0:	f802 3c10 	strb.w	r3, [r2, #-16]
20025ad4:	ab08      	add	r3, sp, #32
20025ad6:	eba3 0209 	sub.w	r2, r3, r9
20025ada:	2100      	movs	r1, #0
20025adc:	2301      	movs	r3, #1
20025ade:	454b      	cmp	r3, r9
20025ae0:	d33f      	bcc.n	20025b62 <sf_crypto_aes_cmac_calc+0x118>
20025ae2:	aa04      	add	r2, sp, #16
20025ae4:	f104 0315 	add.w	r3, r4, #21
20025ae8:	f104 0025 	add.w	r0, r4, #37	@ 0x25
20025aec:	7811      	ldrb	r1, [r2, #0]
20025aee:	f813 5f01 	ldrb.w	r5, [r3, #1]!
20025af2:	4069      	eors	r1, r5
20025af4:	4283      	cmp	r3, r0
20025af6:	f802 1b01 	strb.w	r1, [r2], #1
20025afa:	d1f7      	bne.n	20025aec <sf_crypto_aes_cmac_calc+0xa2>
20025afc:	f1b8 0f01 	cmp.w	r8, #1
20025b00:	f104 0528 	add.w	r5, r4, #40	@ 0x28
20025b04:	d93b      	bls.n	20025b7e <sf_crypto_aes_cmac_calc+0x134>
20025b06:	f108 38ff 	add.w	r8, r8, #4294967295
20025b0a:	ea4f 1308 	mov.w	r3, r8, lsl #4
20025b0e:	e9cd 7300 	strd	r7, r3, [sp]
20025b12:	9602      	str	r6, [sp, #8]
20025b14:	2303      	movs	r3, #3
20025b16:	462a      	mov	r2, r5
20025b18:	88a1      	ldrh	r1, [r4, #4]
20025b1a:	6820      	ldr	r0, [r4, #0]
20025b1c:	f000 f84f 	bl	20025bbe <sf_crypto_aes_enc_sync>
20025b20:	b318      	cbz	r0, 20025b6a <sf_crypto_aes_cmac_calc+0x120>
20025b22:	e7fe      	b.n	20025b22 <sf_crypto_aes_cmac_calc+0xd8>
20025b24:	460b      	mov	r3, r1
20025b26:	ad04      	add	r5, sp, #16
20025b28:	f101 0c10 	add.w	ip, r1, #16
20025b2c:	462a      	mov	r2, r5
20025b2e:	6818      	ldr	r0, [r3, #0]
20025b30:	6859      	ldr	r1, [r3, #4]
20025b32:	3308      	adds	r3, #8
20025b34:	c203      	stmia	r2!, {r0, r1}
20025b36:	4563      	cmp	r3, ip
20025b38:	4615      	mov	r5, r2
20025b3a:	d1f7      	bne.n	20025b2c <sf_crypto_aes_cmac_calc+0xe2>
20025b3c:	ab04      	add	r3, sp, #16
20025b3e:	1d62      	adds	r2, r4, #5
20025b40:	f104 0015 	add.w	r0, r4, #21
20025b44:	7819      	ldrb	r1, [r3, #0]
20025b46:	f812 5f01 	ldrb.w	r5, [r2, #1]!
20025b4a:	4069      	eors	r1, r5
20025b4c:	4282      	cmp	r2, r0
20025b4e:	f803 1b01 	strb.w	r1, [r3], #1
20025b52:	d1f7      	bne.n	20025b44 <sf_crypto_aes_cmac_calc+0xfa>
20025b54:	e7d2      	b.n	20025afc <sf_crypto_aes_cmac_calc+0xb2>
20025b56:	4615      	mov	r5, r2
20025b58:	f04f 0910 	mov.w	r9, #16
20025b5c:	f04f 0801 	mov.w	r8, #1
20025b60:	e7b1      	b.n	20025ac6 <sf_crypto_aes_cmac_calc+0x7c>
20025b62:	f802 1f01 	strb.w	r1, [r2, #1]!
20025b66:	3301      	adds	r3, #1
20025b68:	e7b9      	b.n	20025ade <sf_crypto_aes_cmac_calc+0x94>
20025b6a:	4633      	mov	r3, r6
20025b6c:	462a      	mov	r2, r5
20025b6e:	f106 0110 	add.w	r1, r6, #16
20025b72:	f853 0b04 	ldr.w	r0, [r3], #4
20025b76:	428b      	cmp	r3, r1
20025b78:	f842 0b04 	str.w	r0, [r2], #4
20025b7c:	d1f9      	bne.n	20025b72 <sf_crypto_aes_cmac_calc+0x128>
20025b7e:	2310      	movs	r3, #16
20025b80:	9301      	str	r3, [sp, #4]
20025b82:	446b      	add	r3, sp
20025b84:	9300      	str	r3, [sp, #0]
20025b86:	9602      	str	r6, [sp, #8]
20025b88:	2303      	movs	r3, #3
20025b8a:	462a      	mov	r2, r5
20025b8c:	88a1      	ldrh	r1, [r4, #4]
20025b8e:	6820      	ldr	r0, [r4, #0]
20025b90:	f000 f815 	bl	20025bbe <sf_crypto_aes_enc_sync>
20025b94:	b100      	cbz	r0, 20025b98 <sf_crypto_aes_cmac_calc+0x14e>
20025b96:	e7fe      	b.n	20025b96 <sf_crypto_aes_cmac_calc+0x14c>
20025b98:	f104 0328 	add.w	r3, r4, #40	@ 0x28
20025b9c:	f106 0210 	add.w	r2, r6, #16
20025ba0:	f856 1b04 	ldr.w	r1, [r6], #4
20025ba4:	4296      	cmp	r6, r2
20025ba6:	f843 1b04 	str.w	r1, [r3], #4
20025baa:	d1f9      	bne.n	20025ba0 <sf_crypto_aes_cmac_calc+0x156>
20025bac:	2000      	movs	r0, #0
20025bae:	f884 0038 	strb.w	r0, [r4, #56]	@ 0x38
20025bb2:	b009      	add	sp, #36	@ 0x24
20025bb4:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20025bb8:	f06f 0001 	mvn.w	r0, #1
20025bbc:	e7f9      	b.n	20025bb2 <sf_crypto_aes_cmac_calc+0x168>

20025bbe <sf_crypto_aes_enc_sync>:
20025bbe:	b508      	push	{r3, lr}
20025bc0:	f7fb ff80 	bl	20021ac4 <HAL_AES_init>
20025bc4:	b100      	cbz	r0, 20025bc8 <sf_crypto_aes_enc_sync+0xa>
20025bc6:	e7fe      	b.n	20025bc6 <sf_crypto_aes_enc_sync+0x8>
20025bc8:	2001      	movs	r0, #1
20025bca:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
20025bce:	9902      	ldr	r1, [sp, #8]
20025bd0:	f7fb ffbe 	bl	20021b50 <HAL_AES_run>
20025bd4:	b100      	cbz	r0, 20025bd8 <sf_crypto_aes_enc_sync+0x1a>
20025bd6:	e7fe      	b.n	20025bd6 <sf_crypto_aes_enc_sync+0x18>
20025bd8:	bd08      	pop	{r3, pc}
	...

20025bdc <sbrk_aligned>:
20025bdc:	b570      	push	{r4, r5, r6, lr}
20025bde:	4e0f      	ldr	r6, [pc, #60]	@ (20025c1c <sbrk_aligned+0x40>)
20025be0:	460c      	mov	r4, r1
20025be2:	4605      	mov	r5, r0
20025be4:	6831      	ldr	r1, [r6, #0]
20025be6:	b911      	cbnz	r1, 20025bee <sbrk_aligned+0x12>
20025be8:	f000 fba4 	bl	20026334 <_sbrk_r>
20025bec:	6030      	str	r0, [r6, #0]
20025bee:	4621      	mov	r1, r4
20025bf0:	4628      	mov	r0, r5
20025bf2:	f000 fb9f 	bl	20026334 <_sbrk_r>
20025bf6:	1c43      	adds	r3, r0, #1
20025bf8:	d103      	bne.n	20025c02 <sbrk_aligned+0x26>
20025bfa:	f04f 34ff 	mov.w	r4, #4294967295
20025bfe:	4620      	mov	r0, r4
20025c00:	bd70      	pop	{r4, r5, r6, pc}
20025c02:	1cc4      	adds	r4, r0, #3
20025c04:	f024 0403 	bic.w	r4, r4, #3
20025c08:	42a0      	cmp	r0, r4
20025c0a:	d0f8      	beq.n	20025bfe <sbrk_aligned+0x22>
20025c0c:	1a21      	subs	r1, r4, r0
20025c0e:	4628      	mov	r0, r5
20025c10:	f000 fb90 	bl	20026334 <_sbrk_r>
20025c14:	3001      	adds	r0, #1
20025c16:	d1f2      	bne.n	20025bfe <sbrk_aligned+0x22>
20025c18:	e7ef      	b.n	20025bfa <sbrk_aligned+0x1e>
20025c1a:	bf00      	nop
20025c1c:	2004d0d4 	.word	0x2004d0d4

20025c20 <_malloc_r>:
20025c20:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025c24:	1ccd      	adds	r5, r1, #3
20025c26:	4606      	mov	r6, r0
20025c28:	f025 0503 	bic.w	r5, r5, #3
20025c2c:	3508      	adds	r5, #8
20025c2e:	2d0c      	cmp	r5, #12
20025c30:	bf38      	it	cc
20025c32:	250c      	movcc	r5, #12
20025c34:	2d00      	cmp	r5, #0
20025c36:	db01      	blt.n	20025c3c <_malloc_r+0x1c>
20025c38:	42a9      	cmp	r1, r5
20025c3a:	d904      	bls.n	20025c46 <_malloc_r+0x26>
20025c3c:	230c      	movs	r3, #12
20025c3e:	6033      	str	r3, [r6, #0]
20025c40:	2000      	movs	r0, #0
20025c42:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20025c46:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 20025d1c <_malloc_r+0xfc>
20025c4a:	f000 f869 	bl	20025d20 <__malloc_lock>
20025c4e:	f8d8 3000 	ldr.w	r3, [r8]
20025c52:	461c      	mov	r4, r3
20025c54:	bb44      	cbnz	r4, 20025ca8 <_malloc_r+0x88>
20025c56:	4629      	mov	r1, r5
20025c58:	4630      	mov	r0, r6
20025c5a:	f7ff ffbf 	bl	20025bdc <sbrk_aligned>
20025c5e:	1c43      	adds	r3, r0, #1
20025c60:	4604      	mov	r4, r0
20025c62:	d158      	bne.n	20025d16 <_malloc_r+0xf6>
20025c64:	f8d8 4000 	ldr.w	r4, [r8]
20025c68:	4627      	mov	r7, r4
20025c6a:	2f00      	cmp	r7, #0
20025c6c:	d143      	bne.n	20025cf6 <_malloc_r+0xd6>
20025c6e:	2c00      	cmp	r4, #0
20025c70:	d04b      	beq.n	20025d0a <_malloc_r+0xea>
20025c72:	6823      	ldr	r3, [r4, #0]
20025c74:	4639      	mov	r1, r7
20025c76:	4630      	mov	r0, r6
20025c78:	eb04 0903 	add.w	r9, r4, r3
20025c7c:	f000 fb5a 	bl	20026334 <_sbrk_r>
20025c80:	4581      	cmp	r9, r0
20025c82:	d142      	bne.n	20025d0a <_malloc_r+0xea>
20025c84:	6821      	ldr	r1, [r4, #0]
20025c86:	4630      	mov	r0, r6
20025c88:	1a6d      	subs	r5, r5, r1
20025c8a:	4629      	mov	r1, r5
20025c8c:	f7ff ffa6 	bl	20025bdc <sbrk_aligned>
20025c90:	3001      	adds	r0, #1
20025c92:	d03a      	beq.n	20025d0a <_malloc_r+0xea>
20025c94:	6823      	ldr	r3, [r4, #0]
20025c96:	442b      	add	r3, r5
20025c98:	6023      	str	r3, [r4, #0]
20025c9a:	f8d8 3000 	ldr.w	r3, [r8]
20025c9e:	685a      	ldr	r2, [r3, #4]
20025ca0:	bb62      	cbnz	r2, 20025cfc <_malloc_r+0xdc>
20025ca2:	f8c8 7000 	str.w	r7, [r8]
20025ca6:	e00f      	b.n	20025cc8 <_malloc_r+0xa8>
20025ca8:	6822      	ldr	r2, [r4, #0]
20025caa:	1b52      	subs	r2, r2, r5
20025cac:	d420      	bmi.n	20025cf0 <_malloc_r+0xd0>
20025cae:	2a0b      	cmp	r2, #11
20025cb0:	d917      	bls.n	20025ce2 <_malloc_r+0xc2>
20025cb2:	1961      	adds	r1, r4, r5
20025cb4:	42a3      	cmp	r3, r4
20025cb6:	6025      	str	r5, [r4, #0]
20025cb8:	bf18      	it	ne
20025cba:	6059      	strne	r1, [r3, #4]
20025cbc:	6863      	ldr	r3, [r4, #4]
20025cbe:	bf08      	it	eq
20025cc0:	f8c8 1000 	streq.w	r1, [r8]
20025cc4:	5162      	str	r2, [r4, r5]
20025cc6:	604b      	str	r3, [r1, #4]
20025cc8:	4630      	mov	r0, r6
20025cca:	f000 f82f 	bl	20025d2c <__malloc_unlock>
20025cce:	f104 000b 	add.w	r0, r4, #11
20025cd2:	1d23      	adds	r3, r4, #4
20025cd4:	f020 0007 	bic.w	r0, r0, #7
20025cd8:	1ac2      	subs	r2, r0, r3
20025cda:	bf1c      	itt	ne
20025cdc:	1a1b      	subne	r3, r3, r0
20025cde:	50a3      	strne	r3, [r4, r2]
20025ce0:	e7af      	b.n	20025c42 <_malloc_r+0x22>
20025ce2:	6862      	ldr	r2, [r4, #4]
20025ce4:	42a3      	cmp	r3, r4
20025ce6:	bf0c      	ite	eq
20025ce8:	f8c8 2000 	streq.w	r2, [r8]
20025cec:	605a      	strne	r2, [r3, #4]
20025cee:	e7eb      	b.n	20025cc8 <_malloc_r+0xa8>
20025cf0:	4623      	mov	r3, r4
20025cf2:	6864      	ldr	r4, [r4, #4]
20025cf4:	e7ae      	b.n	20025c54 <_malloc_r+0x34>
20025cf6:	463c      	mov	r4, r7
20025cf8:	687f      	ldr	r7, [r7, #4]
20025cfa:	e7b6      	b.n	20025c6a <_malloc_r+0x4a>
20025cfc:	461a      	mov	r2, r3
20025cfe:	685b      	ldr	r3, [r3, #4]
20025d00:	42a3      	cmp	r3, r4
20025d02:	d1fb      	bne.n	20025cfc <_malloc_r+0xdc>
20025d04:	2300      	movs	r3, #0
20025d06:	6053      	str	r3, [r2, #4]
20025d08:	e7de      	b.n	20025cc8 <_malloc_r+0xa8>
20025d0a:	230c      	movs	r3, #12
20025d0c:	4630      	mov	r0, r6
20025d0e:	6033      	str	r3, [r6, #0]
20025d10:	f000 f80c 	bl	20025d2c <__malloc_unlock>
20025d14:	e794      	b.n	20025c40 <_malloc_r+0x20>
20025d16:	6005      	str	r5, [r0, #0]
20025d18:	e7d6      	b.n	20025cc8 <_malloc_r+0xa8>
20025d1a:	bf00      	nop
20025d1c:	2004d0d8 	.word	0x2004d0d8

20025d20 <__malloc_lock>:
20025d20:	4801      	ldr	r0, [pc, #4]	@ (20025d28 <__malloc_lock+0x8>)
20025d22:	f000 bb2a 	b.w	2002637a <__retarget_lock_acquire_recursive>
20025d26:	bf00      	nop
20025d28:	2004d21c 	.word	0x2004d21c

20025d2c <__malloc_unlock>:
20025d2c:	4801      	ldr	r0, [pc, #4]	@ (20025d34 <__malloc_unlock+0x8>)
20025d2e:	f000 bb25 	b.w	2002637c <__retarget_lock_release_recursive>
20025d32:	bf00      	nop
20025d34:	2004d21c 	.word	0x2004d21c

20025d38 <__sflush_r>:
20025d38:	f9b1 200c 	ldrsh.w	r2, [r1, #12]
20025d3c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025d40:	0716      	lsls	r6, r2, #28
20025d42:	4605      	mov	r5, r0
20025d44:	460c      	mov	r4, r1
20025d46:	d451      	bmi.n	20025dec <__sflush_r+0xb4>
20025d48:	684b      	ldr	r3, [r1, #4]
20025d4a:	2b00      	cmp	r3, #0
20025d4c:	dc02      	bgt.n	20025d54 <__sflush_r+0x1c>
20025d4e:	6c0b      	ldr	r3, [r1, #64]	@ 0x40
20025d50:	2b00      	cmp	r3, #0
20025d52:	dd49      	ble.n	20025de8 <__sflush_r+0xb0>
20025d54:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025d56:	2e00      	cmp	r6, #0
20025d58:	d046      	beq.n	20025de8 <__sflush_r+0xb0>
20025d5a:	2300      	movs	r3, #0
20025d5c:	f412 5280 	ands.w	r2, r2, #4096	@ 0x1000
20025d60:	682f      	ldr	r7, [r5, #0]
20025d62:	602b      	str	r3, [r5, #0]
20025d64:	d031      	beq.n	20025dca <__sflush_r+0x92>
20025d66:	6d62      	ldr	r2, [r4, #84]	@ 0x54
20025d68:	89a3      	ldrh	r3, [r4, #12]
20025d6a:	0759      	lsls	r1, r3, #29
20025d6c:	d505      	bpl.n	20025d7a <__sflush_r+0x42>
20025d6e:	6863      	ldr	r3, [r4, #4]
20025d70:	1ad2      	subs	r2, r2, r3
20025d72:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20025d74:	b10b      	cbz	r3, 20025d7a <__sflush_r+0x42>
20025d76:	6c23      	ldr	r3, [r4, #64]	@ 0x40
20025d78:	1ad2      	subs	r2, r2, r3
20025d7a:	2300      	movs	r3, #0
20025d7c:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025d7e:	6a21      	ldr	r1, [r4, #32]
20025d80:	4628      	mov	r0, r5
20025d82:	47b0      	blx	r6
20025d84:	1c42      	adds	r2, r0, #1
20025d86:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025d8a:	d106      	bne.n	20025d9a <__sflush_r+0x62>
20025d8c:	6829      	ldr	r1, [r5, #0]
20025d8e:	291d      	cmp	r1, #29
20025d90:	d845      	bhi.n	20025e1e <__sflush_r+0xe6>
20025d92:	4a28      	ldr	r2, [pc, #160]	@ (20025e34 <__sflush_r+0xfc>)
20025d94:	40ca      	lsrs	r2, r1
20025d96:	07d6      	lsls	r6, r2, #31
20025d98:	d541      	bpl.n	20025e1e <__sflush_r+0xe6>
20025d9a:	2200      	movs	r2, #0
20025d9c:	04d9      	lsls	r1, r3, #19
20025d9e:	6062      	str	r2, [r4, #4]
20025da0:	6922      	ldr	r2, [r4, #16]
20025da2:	6022      	str	r2, [r4, #0]
20025da4:	d504      	bpl.n	20025db0 <__sflush_r+0x78>
20025da6:	1c42      	adds	r2, r0, #1
20025da8:	d101      	bne.n	20025dae <__sflush_r+0x76>
20025daa:	682b      	ldr	r3, [r5, #0]
20025dac:	b903      	cbnz	r3, 20025db0 <__sflush_r+0x78>
20025dae:	6560      	str	r0, [r4, #84]	@ 0x54
20025db0:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20025db2:	602f      	str	r7, [r5, #0]
20025db4:	b1c1      	cbz	r1, 20025de8 <__sflush_r+0xb0>
20025db6:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025dba:	4299      	cmp	r1, r3
20025dbc:	d002      	beq.n	20025dc4 <__sflush_r+0x8c>
20025dbe:	4628      	mov	r0, r5
20025dc0:	f000 faf8 	bl	200263b4 <_free_r>
20025dc4:	2300      	movs	r3, #0
20025dc6:	6363      	str	r3, [r4, #52]	@ 0x34
20025dc8:	e00e      	b.n	20025de8 <__sflush_r+0xb0>
20025dca:	2301      	movs	r3, #1
20025dcc:	6a21      	ldr	r1, [r4, #32]
20025dce:	4628      	mov	r0, r5
20025dd0:	47b0      	blx	r6
20025dd2:	4602      	mov	r2, r0
20025dd4:	1c50      	adds	r0, r2, #1
20025dd6:	d1c7      	bne.n	20025d68 <__sflush_r+0x30>
20025dd8:	682b      	ldr	r3, [r5, #0]
20025dda:	2b00      	cmp	r3, #0
20025ddc:	d0c4      	beq.n	20025d68 <__sflush_r+0x30>
20025dde:	2b1d      	cmp	r3, #29
20025de0:	d001      	beq.n	20025de6 <__sflush_r+0xae>
20025de2:	2b16      	cmp	r3, #22
20025de4:	d119      	bne.n	20025e1a <__sflush_r+0xe2>
20025de6:	602f      	str	r7, [r5, #0]
20025de8:	2000      	movs	r0, #0
20025dea:	e01d      	b.n	20025e28 <__sflush_r+0xf0>
20025dec:	690f      	ldr	r7, [r1, #16]
20025dee:	2f00      	cmp	r7, #0
20025df0:	d0fa      	beq.n	20025de8 <__sflush_r+0xb0>
20025df2:	0793      	lsls	r3, r2, #30
20025df4:	680e      	ldr	r6, [r1, #0]
20025df6:	600f      	str	r7, [r1, #0]
20025df8:	bf0c      	ite	eq
20025dfa:	694b      	ldreq	r3, [r1, #20]
20025dfc:	2300      	movne	r3, #0
20025dfe:	eba6 0807 	sub.w	r8, r6, r7
20025e02:	608b      	str	r3, [r1, #8]
20025e04:	f1b8 0f00 	cmp.w	r8, #0
20025e08:	ddee      	ble.n	20025de8 <__sflush_r+0xb0>
20025e0a:	4643      	mov	r3, r8
20025e0c:	463a      	mov	r2, r7
20025e0e:	6a21      	ldr	r1, [r4, #32]
20025e10:	4628      	mov	r0, r5
20025e12:	6aa6      	ldr	r6, [r4, #40]	@ 0x28
20025e14:	47b0      	blx	r6
20025e16:	2800      	cmp	r0, #0
20025e18:	dc08      	bgt.n	20025e2c <__sflush_r+0xf4>
20025e1a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025e1e:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
20025e22:	f04f 30ff 	mov.w	r0, #4294967295
20025e26:	81a3      	strh	r3, [r4, #12]
20025e28:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025e2c:	4407      	add	r7, r0
20025e2e:	eba8 0800 	sub.w	r8, r8, r0
20025e32:	e7e7      	b.n	20025e04 <__sflush_r+0xcc>
20025e34:	20400001 	.word	0x20400001

20025e38 <_fflush_r>:
20025e38:	b538      	push	{r3, r4, r5, lr}
20025e3a:	690b      	ldr	r3, [r1, #16]
20025e3c:	4605      	mov	r5, r0
20025e3e:	460c      	mov	r4, r1
20025e40:	b913      	cbnz	r3, 20025e48 <_fflush_r+0x10>
20025e42:	2500      	movs	r5, #0
20025e44:	4628      	mov	r0, r5
20025e46:	bd38      	pop	{r3, r4, r5, pc}
20025e48:	b118      	cbz	r0, 20025e52 <_fflush_r+0x1a>
20025e4a:	6a03      	ldr	r3, [r0, #32]
20025e4c:	b90b      	cbnz	r3, 20025e52 <_fflush_r+0x1a>
20025e4e:	f000 f8a9 	bl	20025fa4 <__sinit>
20025e52:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025e56:	2b00      	cmp	r3, #0
20025e58:	d0f3      	beq.n	20025e42 <_fflush_r+0xa>
20025e5a:	6e62      	ldr	r2, [r4, #100]	@ 0x64
20025e5c:	07d0      	lsls	r0, r2, #31
20025e5e:	d404      	bmi.n	20025e6a <_fflush_r+0x32>
20025e60:	0599      	lsls	r1, r3, #22
20025e62:	d402      	bmi.n	20025e6a <_fflush_r+0x32>
20025e64:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025e66:	f000 fa88 	bl	2002637a <__retarget_lock_acquire_recursive>
20025e6a:	4628      	mov	r0, r5
20025e6c:	4621      	mov	r1, r4
20025e6e:	f7ff ff63 	bl	20025d38 <__sflush_r>
20025e72:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025e74:	4605      	mov	r5, r0
20025e76:	07da      	lsls	r2, r3, #31
20025e78:	d4e4      	bmi.n	20025e44 <_fflush_r+0xc>
20025e7a:	89a3      	ldrh	r3, [r4, #12]
20025e7c:	059b      	lsls	r3, r3, #22
20025e7e:	d4e1      	bmi.n	20025e44 <_fflush_r+0xc>
20025e80:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025e82:	f000 fa7b 	bl	2002637c <__retarget_lock_release_recursive>
20025e86:	e7dd      	b.n	20025e44 <_fflush_r+0xc>

20025e88 <std>:
20025e88:	2300      	movs	r3, #0
20025e8a:	b510      	push	{r4, lr}
20025e8c:	4604      	mov	r4, r0
20025e8e:	6083      	str	r3, [r0, #8]
20025e90:	8181      	strh	r1, [r0, #12]
20025e92:	4619      	mov	r1, r3
20025e94:	6643      	str	r3, [r0, #100]	@ 0x64
20025e96:	81c2      	strh	r2, [r0, #14]
20025e98:	2208      	movs	r2, #8
20025e9a:	6183      	str	r3, [r0, #24]
20025e9c:	e9c0 3300 	strd	r3, r3, [r0]
20025ea0:	e9c0 3304 	strd	r3, r3, [r0, #16]
20025ea4:	305c      	adds	r0, #92	@ 0x5c
20025ea6:	f000 fa09 	bl	200262bc <memset>
20025eaa:	4b0d      	ldr	r3, [pc, #52]	@ (20025ee0 <std+0x58>)
20025eac:	6224      	str	r4, [r4, #32]
20025eae:	6263      	str	r3, [r4, #36]	@ 0x24
20025eb0:	4b0c      	ldr	r3, [pc, #48]	@ (20025ee4 <std+0x5c>)
20025eb2:	62a3      	str	r3, [r4, #40]	@ 0x28
20025eb4:	4b0c      	ldr	r3, [pc, #48]	@ (20025ee8 <std+0x60>)
20025eb6:	62e3      	str	r3, [r4, #44]	@ 0x2c
20025eb8:	4b0c      	ldr	r3, [pc, #48]	@ (20025eec <std+0x64>)
20025eba:	6323      	str	r3, [r4, #48]	@ 0x30
20025ebc:	4b0c      	ldr	r3, [pc, #48]	@ (20025ef0 <std+0x68>)
20025ebe:	429c      	cmp	r4, r3
20025ec0:	d006      	beq.n	20025ed0 <std+0x48>
20025ec2:	f103 0268 	add.w	r2, r3, #104	@ 0x68
20025ec6:	4294      	cmp	r4, r2
20025ec8:	d002      	beq.n	20025ed0 <std+0x48>
20025eca:	33d0      	adds	r3, #208	@ 0xd0
20025ecc:	429c      	cmp	r4, r3
20025ece:	d105      	bne.n	20025edc <std+0x54>
20025ed0:	f104 0058 	add.w	r0, r4, #88	@ 0x58
20025ed4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025ed8:	f000 ba4e 	b.w	20026378 <__retarget_lock_init_recursive>
20025edc:	bd10      	pop	{r4, pc}
20025ede:	bf00      	nop
20025ee0:	200260f1 	.word	0x200260f1
20025ee4:	20026113 	.word	0x20026113
20025ee8:	2002614b 	.word	0x2002614b
20025eec:	20026171 	.word	0x20026171
20025ef0:	2004d0dc 	.word	0x2004d0dc

20025ef4 <stdio_exit_handler>:
20025ef4:	4a02      	ldr	r2, [pc, #8]	@ (20025f00 <stdio_exit_handler+0xc>)
20025ef6:	4903      	ldr	r1, [pc, #12]	@ (20025f04 <stdio_exit_handler+0x10>)
20025ef8:	4803      	ldr	r0, [pc, #12]	@ (20025f08 <stdio_exit_handler+0x14>)
20025efa:	f000 b86b 	b.w	20025fd4 <_fwalk_sglue>
20025efe:	bf00      	nop
20025f00:	200449ac 	.word	0x200449ac
20025f04:	20025e39 	.word	0x20025e39
20025f08:	200449bc 	.word	0x200449bc

20025f0c <cleanup_stdio>:
20025f0c:	6841      	ldr	r1, [r0, #4]
20025f0e:	4b0c      	ldr	r3, [pc, #48]	@ (20025f40 <cleanup_stdio+0x34>)
20025f10:	4299      	cmp	r1, r3
20025f12:	b510      	push	{r4, lr}
20025f14:	4604      	mov	r4, r0
20025f16:	d001      	beq.n	20025f1c <cleanup_stdio+0x10>
20025f18:	f7ff ff8e 	bl	20025e38 <_fflush_r>
20025f1c:	68a1      	ldr	r1, [r4, #8]
20025f1e:	4b09      	ldr	r3, [pc, #36]	@ (20025f44 <cleanup_stdio+0x38>)
20025f20:	4299      	cmp	r1, r3
20025f22:	d002      	beq.n	20025f2a <cleanup_stdio+0x1e>
20025f24:	4620      	mov	r0, r4
20025f26:	f7ff ff87 	bl	20025e38 <_fflush_r>
20025f2a:	68e1      	ldr	r1, [r4, #12]
20025f2c:	4b06      	ldr	r3, [pc, #24]	@ (20025f48 <cleanup_stdio+0x3c>)
20025f2e:	4299      	cmp	r1, r3
20025f30:	d004      	beq.n	20025f3c <cleanup_stdio+0x30>
20025f32:	4620      	mov	r0, r4
20025f34:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025f38:	f7ff bf7e 	b.w	20025e38 <_fflush_r>
20025f3c:	bd10      	pop	{r4, pc}
20025f3e:	bf00      	nop
20025f40:	2004d0dc 	.word	0x2004d0dc
20025f44:	2004d144 	.word	0x2004d144
20025f48:	2004d1ac 	.word	0x2004d1ac

20025f4c <global_stdio_init.part.0>:
20025f4c:	4b0c      	ldr	r3, [pc, #48]	@ (20025f80 <global_stdio_init.part.0+0x34>)
20025f4e:	2104      	movs	r1, #4
20025f50:	4a0c      	ldr	r2, [pc, #48]	@ (20025f84 <global_stdio_init.part.0+0x38>)
20025f52:	480d      	ldr	r0, [pc, #52]	@ (20025f88 <global_stdio_init.part.0+0x3c>)
20025f54:	b510      	push	{r4, lr}
20025f56:	601a      	str	r2, [r3, #0]
20025f58:	2200      	movs	r2, #0
20025f5a:	f7ff ff95 	bl	20025e88 <std>
20025f5e:	4b0a      	ldr	r3, [pc, #40]	@ (20025f88 <global_stdio_init.part.0+0x3c>)
20025f60:	2201      	movs	r2, #1
20025f62:	2109      	movs	r1, #9
20025f64:	461c      	mov	r4, r3
20025f66:	f103 0068 	add.w	r0, r3, #104	@ 0x68
20025f6a:	f7ff ff8d 	bl	20025e88 <std>
20025f6e:	2202      	movs	r2, #2
20025f70:	f104 00d0 	add.w	r0, r4, #208	@ 0xd0
20025f74:	2112      	movs	r1, #18
20025f76:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025f7a:	f7ff bf85 	b.w	20025e88 <std>
20025f7e:	bf00      	nop
20025f80:	2004d214 	.word	0x2004d214
20025f84:	20025ef5 	.word	0x20025ef5
20025f88:	2004d0dc 	.word	0x2004d0dc

20025f8c <__sfp_lock_acquire>:
20025f8c:	4801      	ldr	r0, [pc, #4]	@ (20025f94 <__sfp_lock_acquire+0x8>)
20025f8e:	f000 b9f4 	b.w	2002637a <__retarget_lock_acquire_recursive>
20025f92:	bf00      	nop
20025f94:	2004d21d 	.word	0x2004d21d

20025f98 <__sfp_lock_release>:
20025f98:	4801      	ldr	r0, [pc, #4]	@ (20025fa0 <__sfp_lock_release+0x8>)
20025f9a:	f000 b9ef 	b.w	2002637c <__retarget_lock_release_recursive>
20025f9e:	bf00      	nop
20025fa0:	2004d21d 	.word	0x2004d21d

20025fa4 <__sinit>:
20025fa4:	b510      	push	{r4, lr}
20025fa6:	4604      	mov	r4, r0
20025fa8:	f7ff fff0 	bl	20025f8c <__sfp_lock_acquire>
20025fac:	6a23      	ldr	r3, [r4, #32]
20025fae:	b11b      	cbz	r3, 20025fb8 <__sinit+0x14>
20025fb0:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025fb4:	f7ff bff0 	b.w	20025f98 <__sfp_lock_release>
20025fb8:	4b04      	ldr	r3, [pc, #16]	@ (20025fcc <__sinit+0x28>)
20025fba:	6223      	str	r3, [r4, #32]
20025fbc:	4b04      	ldr	r3, [pc, #16]	@ (20025fd0 <__sinit+0x2c>)
20025fbe:	681b      	ldr	r3, [r3, #0]
20025fc0:	2b00      	cmp	r3, #0
20025fc2:	d1f5      	bne.n	20025fb0 <__sinit+0xc>
20025fc4:	f7ff ffc2 	bl	20025f4c <global_stdio_init.part.0>
20025fc8:	e7f2      	b.n	20025fb0 <__sinit+0xc>
20025fca:	bf00      	nop
20025fcc:	20025f0d 	.word	0x20025f0d
20025fd0:	2004d214 	.word	0x2004d214

20025fd4 <_fwalk_sglue>:
20025fd4:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025fd8:	4607      	mov	r7, r0
20025fda:	4688      	mov	r8, r1
20025fdc:	4614      	mov	r4, r2
20025fde:	2600      	movs	r6, #0
20025fe0:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
20025fe4:	f1b9 0901 	subs.w	r9, r9, #1
20025fe8:	d505      	bpl.n	20025ff6 <_fwalk_sglue+0x22>
20025fea:	6824      	ldr	r4, [r4, #0]
20025fec:	2c00      	cmp	r4, #0
20025fee:	d1f7      	bne.n	20025fe0 <_fwalk_sglue+0xc>
20025ff0:	4630      	mov	r0, r6
20025ff2:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20025ff6:	89ab      	ldrh	r3, [r5, #12]
20025ff8:	2b01      	cmp	r3, #1
20025ffa:	d907      	bls.n	2002600c <_fwalk_sglue+0x38>
20025ffc:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
20026000:	3301      	adds	r3, #1
20026002:	d003      	beq.n	2002600c <_fwalk_sglue+0x38>
20026004:	4629      	mov	r1, r5
20026006:	4638      	mov	r0, r7
20026008:	47c0      	blx	r8
2002600a:	4306      	orrs	r6, r0
2002600c:	3568      	adds	r5, #104	@ 0x68
2002600e:	e7e9      	b.n	20025fe4 <_fwalk_sglue+0x10>

20026010 <iprintf>:
20026010:	b40f      	push	{r0, r1, r2, r3}
20026012:	b507      	push	{r0, r1, r2, lr}
20026014:	4906      	ldr	r1, [pc, #24]	@ (20026030 <iprintf+0x20>)
20026016:	ab04      	add	r3, sp, #16
20026018:	6808      	ldr	r0, [r1, #0]
2002601a:	f853 2b04 	ldr.w	r2, [r3], #4
2002601e:	6881      	ldr	r1, [r0, #8]
20026020:	9301      	str	r3, [sp, #4]
20026022:	f000 fa3b 	bl	2002649c <_vfiprintf_r>
20026026:	b003      	add	sp, #12
20026028:	f85d eb04 	ldr.w	lr, [sp], #4
2002602c:	b004      	add	sp, #16
2002602e:	4770      	bx	lr
20026030:	200449b8 	.word	0x200449b8

20026034 <_puts_r>:
20026034:	6a03      	ldr	r3, [r0, #32]
20026036:	b570      	push	{r4, r5, r6, lr}
20026038:	4605      	mov	r5, r0
2002603a:	460e      	mov	r6, r1
2002603c:	6884      	ldr	r4, [r0, #8]
2002603e:	b90b      	cbnz	r3, 20026044 <_puts_r+0x10>
20026040:	f7ff ffb0 	bl	20025fa4 <__sinit>
20026044:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20026046:	07db      	lsls	r3, r3, #31
20026048:	d405      	bmi.n	20026056 <_puts_r+0x22>
2002604a:	89a3      	ldrh	r3, [r4, #12]
2002604c:	0598      	lsls	r0, r3, #22
2002604e:	d402      	bmi.n	20026056 <_puts_r+0x22>
20026050:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20026052:	f000 f992 	bl	2002637a <__retarget_lock_acquire_recursive>
20026056:	89a3      	ldrh	r3, [r4, #12]
20026058:	0719      	lsls	r1, r3, #28
2002605a:	d502      	bpl.n	20026062 <_puts_r+0x2e>
2002605c:	6923      	ldr	r3, [r4, #16]
2002605e:	2b00      	cmp	r3, #0
20026060:	d135      	bne.n	200260ce <_puts_r+0x9a>
20026062:	4621      	mov	r1, r4
20026064:	4628      	mov	r0, r5
20026066:	f000 f8c5 	bl	200261f4 <__swsetup_r>
2002606a:	b380      	cbz	r0, 200260ce <_puts_r+0x9a>
2002606c:	f04f 35ff 	mov.w	r5, #4294967295
20026070:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20026072:	07da      	lsls	r2, r3, #31
20026074:	d405      	bmi.n	20026082 <_puts_r+0x4e>
20026076:	89a3      	ldrh	r3, [r4, #12]
20026078:	059b      	lsls	r3, r3, #22
2002607a:	d402      	bmi.n	20026082 <_puts_r+0x4e>
2002607c:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002607e:	f000 f97d 	bl	2002637c <__retarget_lock_release_recursive>
20026082:	4628      	mov	r0, r5
20026084:	bd70      	pop	{r4, r5, r6, pc}
20026086:	2b00      	cmp	r3, #0
20026088:	da04      	bge.n	20026094 <_puts_r+0x60>
2002608a:	69a2      	ldr	r2, [r4, #24]
2002608c:	4293      	cmp	r3, r2
2002608e:	db17      	blt.n	200260c0 <_puts_r+0x8c>
20026090:	290a      	cmp	r1, #10
20026092:	d015      	beq.n	200260c0 <_puts_r+0x8c>
20026094:	6823      	ldr	r3, [r4, #0]
20026096:	1c5a      	adds	r2, r3, #1
20026098:	6022      	str	r2, [r4, #0]
2002609a:	7019      	strb	r1, [r3, #0]
2002609c:	68a3      	ldr	r3, [r4, #8]
2002609e:	f816 1f01 	ldrb.w	r1, [r6, #1]!
200260a2:	3b01      	subs	r3, #1
200260a4:	60a3      	str	r3, [r4, #8]
200260a6:	2900      	cmp	r1, #0
200260a8:	d1ed      	bne.n	20026086 <_puts_r+0x52>
200260aa:	2b00      	cmp	r3, #0
200260ac:	da11      	bge.n	200260d2 <_puts_r+0x9e>
200260ae:	4622      	mov	r2, r4
200260b0:	210a      	movs	r1, #10
200260b2:	4628      	mov	r0, r5
200260b4:	f000 f860 	bl	20026178 <__swbuf_r>
200260b8:	3001      	adds	r0, #1
200260ba:	d0d7      	beq.n	2002606c <_puts_r+0x38>
200260bc:	250a      	movs	r5, #10
200260be:	e7d7      	b.n	20026070 <_puts_r+0x3c>
200260c0:	4622      	mov	r2, r4
200260c2:	4628      	mov	r0, r5
200260c4:	f000 f858 	bl	20026178 <__swbuf_r>
200260c8:	3001      	adds	r0, #1
200260ca:	d1e7      	bne.n	2002609c <_puts_r+0x68>
200260cc:	e7ce      	b.n	2002606c <_puts_r+0x38>
200260ce:	3e01      	subs	r6, #1
200260d0:	e7e4      	b.n	2002609c <_puts_r+0x68>
200260d2:	6823      	ldr	r3, [r4, #0]
200260d4:	1c5a      	adds	r2, r3, #1
200260d6:	6022      	str	r2, [r4, #0]
200260d8:	220a      	movs	r2, #10
200260da:	701a      	strb	r2, [r3, #0]
200260dc:	e7ee      	b.n	200260bc <_puts_r+0x88>
	...

200260e0 <puts>:
200260e0:	4b02      	ldr	r3, [pc, #8]	@ (200260ec <puts+0xc>)
200260e2:	4601      	mov	r1, r0
200260e4:	6818      	ldr	r0, [r3, #0]
200260e6:	f7ff bfa5 	b.w	20026034 <_puts_r>
200260ea:	bf00      	nop
200260ec:	200449b8 	.word	0x200449b8

200260f0 <__sread>:
200260f0:	b510      	push	{r4, lr}
200260f2:	460c      	mov	r4, r1
200260f4:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200260f8:	f000 f90a 	bl	20026310 <_read_r>
200260fc:	2800      	cmp	r0, #0
200260fe:	bfab      	itete	ge
20026100:	6d63      	ldrge	r3, [r4, #84]	@ 0x54
20026102:	89a3      	ldrhlt	r3, [r4, #12]
20026104:	181b      	addge	r3, r3, r0
20026106:	f423 5380 	biclt.w	r3, r3, #4096	@ 0x1000
2002610a:	bfac      	ite	ge
2002610c:	6563      	strge	r3, [r4, #84]	@ 0x54
2002610e:	81a3      	strhlt	r3, [r4, #12]
20026110:	bd10      	pop	{r4, pc}

20026112 <__swrite>:
20026112:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20026116:	461f      	mov	r7, r3
20026118:	898b      	ldrh	r3, [r1, #12]
2002611a:	4605      	mov	r5, r0
2002611c:	460c      	mov	r4, r1
2002611e:	05db      	lsls	r3, r3, #23
20026120:	4616      	mov	r6, r2
20026122:	d505      	bpl.n	20026130 <__swrite+0x1e>
20026124:	2302      	movs	r3, #2
20026126:	2200      	movs	r2, #0
20026128:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
2002612c:	f000 f8de 	bl	200262ec <_lseek_r>
20026130:	89a3      	ldrh	r3, [r4, #12]
20026132:	4632      	mov	r2, r6
20026134:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20026138:	4628      	mov	r0, r5
2002613a:	f423 5380 	bic.w	r3, r3, #4096	@ 0x1000
2002613e:	81a3      	strh	r3, [r4, #12]
20026140:	463b      	mov	r3, r7
20026142:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
20026146:	f000 b905 	b.w	20026354 <_write_r>

2002614a <__sseek>:
2002614a:	b510      	push	{r4, lr}
2002614c:	460c      	mov	r4, r1
2002614e:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20026152:	f000 f8cb 	bl	200262ec <_lseek_r>
20026156:	1c42      	adds	r2, r0, #1
20026158:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002615c:	bf15      	itete	ne
2002615e:	6560      	strne	r0, [r4, #84]	@ 0x54
20026160:	f423 5380 	biceq.w	r3, r3, #4096	@ 0x1000
20026164:	f443 5380 	orrne.w	r3, r3, #4096	@ 0x1000
20026168:	81a3      	strheq	r3, [r4, #12]
2002616a:	bf18      	it	ne
2002616c:	81a3      	strhne	r3, [r4, #12]
2002616e:	bd10      	pop	{r4, pc}

20026170 <__sclose>:
20026170:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20026174:	f000 b8aa 	b.w	200262cc <_close_r>

20026178 <__swbuf_r>:
20026178:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002617a:	460e      	mov	r6, r1
2002617c:	4614      	mov	r4, r2
2002617e:	4605      	mov	r5, r0
20026180:	b118      	cbz	r0, 2002618a <__swbuf_r+0x12>
20026182:	6a03      	ldr	r3, [r0, #32]
20026184:	b90b      	cbnz	r3, 2002618a <__swbuf_r+0x12>
20026186:	f7ff ff0d 	bl	20025fa4 <__sinit>
2002618a:	69a3      	ldr	r3, [r4, #24]
2002618c:	60a3      	str	r3, [r4, #8]
2002618e:	89a3      	ldrh	r3, [r4, #12]
20026190:	071a      	lsls	r2, r3, #28
20026192:	d501      	bpl.n	20026198 <__swbuf_r+0x20>
20026194:	6923      	ldr	r3, [r4, #16]
20026196:	b943      	cbnz	r3, 200261aa <__swbuf_r+0x32>
20026198:	4621      	mov	r1, r4
2002619a:	4628      	mov	r0, r5
2002619c:	f000 f82a 	bl	200261f4 <__swsetup_r>
200261a0:	b118      	cbz	r0, 200261aa <__swbuf_r+0x32>
200261a2:	f04f 37ff 	mov.w	r7, #4294967295
200261a6:	4638      	mov	r0, r7
200261a8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200261aa:	6823      	ldr	r3, [r4, #0]
200261ac:	b2f6      	uxtb	r6, r6
200261ae:	6922      	ldr	r2, [r4, #16]
200261b0:	4637      	mov	r7, r6
200261b2:	1a98      	subs	r0, r3, r2
200261b4:	6963      	ldr	r3, [r4, #20]
200261b6:	4283      	cmp	r3, r0
200261b8:	dc05      	bgt.n	200261c6 <__swbuf_r+0x4e>
200261ba:	4621      	mov	r1, r4
200261bc:	4628      	mov	r0, r5
200261be:	f7ff fe3b 	bl	20025e38 <_fflush_r>
200261c2:	2800      	cmp	r0, #0
200261c4:	d1ed      	bne.n	200261a2 <__swbuf_r+0x2a>
200261c6:	68a3      	ldr	r3, [r4, #8]
200261c8:	3b01      	subs	r3, #1
200261ca:	60a3      	str	r3, [r4, #8]
200261cc:	6823      	ldr	r3, [r4, #0]
200261ce:	1c5a      	adds	r2, r3, #1
200261d0:	6022      	str	r2, [r4, #0]
200261d2:	701e      	strb	r6, [r3, #0]
200261d4:	1c43      	adds	r3, r0, #1
200261d6:	6962      	ldr	r2, [r4, #20]
200261d8:	429a      	cmp	r2, r3
200261da:	d004      	beq.n	200261e6 <__swbuf_r+0x6e>
200261dc:	89a3      	ldrh	r3, [r4, #12]
200261de:	07db      	lsls	r3, r3, #31
200261e0:	d5e1      	bpl.n	200261a6 <__swbuf_r+0x2e>
200261e2:	2e0a      	cmp	r6, #10
200261e4:	d1df      	bne.n	200261a6 <__swbuf_r+0x2e>
200261e6:	4621      	mov	r1, r4
200261e8:	4628      	mov	r0, r5
200261ea:	f7ff fe25 	bl	20025e38 <_fflush_r>
200261ee:	2800      	cmp	r0, #0
200261f0:	d0d9      	beq.n	200261a6 <__swbuf_r+0x2e>
200261f2:	e7d6      	b.n	200261a2 <__swbuf_r+0x2a>

200261f4 <__swsetup_r>:
200261f4:	b538      	push	{r3, r4, r5, lr}
200261f6:	4b28      	ldr	r3, [pc, #160]	@ (20026298 <__swsetup_r+0xa4>)
200261f8:	4605      	mov	r5, r0
200261fa:	460c      	mov	r4, r1
200261fc:	6818      	ldr	r0, [r3, #0]
200261fe:	b118      	cbz	r0, 20026208 <__swsetup_r+0x14>
20026200:	6a03      	ldr	r3, [r0, #32]
20026202:	b90b      	cbnz	r3, 20026208 <__swsetup_r+0x14>
20026204:	f7ff fece 	bl	20025fa4 <__sinit>
20026208:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002620c:	071a      	lsls	r2, r3, #28
2002620e:	d421      	bmi.n	20026254 <__swsetup_r+0x60>
20026210:	06d8      	lsls	r0, r3, #27
20026212:	d407      	bmi.n	20026224 <__swsetup_r+0x30>
20026214:	2209      	movs	r2, #9
20026216:	602a      	str	r2, [r5, #0]
20026218:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
2002621c:	f04f 30ff 	mov.w	r0, #4294967295
20026220:	81a3      	strh	r3, [r4, #12]
20026222:	e030      	b.n	20026286 <__swsetup_r+0x92>
20026224:	0759      	lsls	r1, r3, #29
20026226:	d512      	bpl.n	2002624e <__swsetup_r+0x5a>
20026228:	6b61      	ldr	r1, [r4, #52]	@ 0x34
2002622a:	b141      	cbz	r1, 2002623e <__swsetup_r+0x4a>
2002622c:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20026230:	4299      	cmp	r1, r3
20026232:	d002      	beq.n	2002623a <__swsetup_r+0x46>
20026234:	4628      	mov	r0, r5
20026236:	f000 f8bd 	bl	200263b4 <_free_r>
2002623a:	2300      	movs	r3, #0
2002623c:	6363      	str	r3, [r4, #52]	@ 0x34
2002623e:	2200      	movs	r2, #0
20026240:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20026244:	6062      	str	r2, [r4, #4]
20026246:	f023 0324 	bic.w	r3, r3, #36	@ 0x24
2002624a:	6922      	ldr	r2, [r4, #16]
2002624c:	6022      	str	r2, [r4, #0]
2002624e:	f043 0308 	orr.w	r3, r3, #8
20026252:	81a3      	strh	r3, [r4, #12]
20026254:	6922      	ldr	r2, [r4, #16]
20026256:	b93a      	cbnz	r2, 20026268 <__swsetup_r+0x74>
20026258:	059a      	lsls	r2, r3, #22
2002625a:	d501      	bpl.n	20026260 <__swsetup_r+0x6c>
2002625c:	0618      	lsls	r0, r3, #24
2002625e:	d503      	bpl.n	20026268 <__swsetup_r+0x74>
20026260:	4621      	mov	r1, r4
20026262:	4628      	mov	r0, r5
20026264:	f000 fbe8 	bl	20026a38 <__smakebuf_r>
20026268:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002626c:	f013 0201 	ands.w	r2, r3, #1
20026270:	d00a      	beq.n	20026288 <__swsetup_r+0x94>
20026272:	2200      	movs	r2, #0
20026274:	60a2      	str	r2, [r4, #8]
20026276:	6962      	ldr	r2, [r4, #20]
20026278:	4252      	negs	r2, r2
2002627a:	61a2      	str	r2, [r4, #24]
2002627c:	6922      	ldr	r2, [r4, #16]
2002627e:	b942      	cbnz	r2, 20026292 <__swsetup_r+0x9e>
20026280:	f013 0080 	ands.w	r0, r3, #128	@ 0x80
20026284:	d1c8      	bne.n	20026218 <__swsetup_r+0x24>
20026286:	bd38      	pop	{r3, r4, r5, pc}
20026288:	0799      	lsls	r1, r3, #30
2002628a:	bf58      	it	pl
2002628c:	6962      	ldrpl	r2, [r4, #20]
2002628e:	60a2      	str	r2, [r4, #8]
20026290:	e7f4      	b.n	2002627c <__swsetup_r+0x88>
20026292:	2000      	movs	r0, #0
20026294:	e7f7      	b.n	20026286 <__swsetup_r+0x92>
20026296:	bf00      	nop
20026298:	200449b8 	.word	0x200449b8

2002629c <memcmp>:
2002629c:	3901      	subs	r1, #1
2002629e:	4402      	add	r2, r0
200262a0:	b510      	push	{r4, lr}
200262a2:	4290      	cmp	r0, r2
200262a4:	d101      	bne.n	200262aa <memcmp+0xe>
200262a6:	2000      	movs	r0, #0
200262a8:	e005      	b.n	200262b6 <memcmp+0x1a>
200262aa:	7803      	ldrb	r3, [r0, #0]
200262ac:	f811 4f01 	ldrb.w	r4, [r1, #1]!
200262b0:	42a3      	cmp	r3, r4
200262b2:	d001      	beq.n	200262b8 <memcmp+0x1c>
200262b4:	1b18      	subs	r0, r3, r4
200262b6:	bd10      	pop	{r4, pc}
200262b8:	3001      	adds	r0, #1
200262ba:	e7f2      	b.n	200262a2 <memcmp+0x6>

200262bc <memset>:
200262bc:	4402      	add	r2, r0
200262be:	4603      	mov	r3, r0
200262c0:	4293      	cmp	r3, r2
200262c2:	d100      	bne.n	200262c6 <memset+0xa>
200262c4:	4770      	bx	lr
200262c6:	f803 1b01 	strb.w	r1, [r3], #1
200262ca:	e7f9      	b.n	200262c0 <memset+0x4>

200262cc <_close_r>:
200262cc:	b538      	push	{r3, r4, r5, lr}
200262ce:	2300      	movs	r3, #0
200262d0:	4d05      	ldr	r5, [pc, #20]	@ (200262e8 <_close_r+0x1c>)
200262d2:	4604      	mov	r4, r0
200262d4:	4608      	mov	r0, r1
200262d6:	602b      	str	r3, [r5, #0]
200262d8:	f7fb f9e0 	bl	2002169c <_close>
200262dc:	1c43      	adds	r3, r0, #1
200262de:	d102      	bne.n	200262e6 <_close_r+0x1a>
200262e0:	682b      	ldr	r3, [r5, #0]
200262e2:	b103      	cbz	r3, 200262e6 <_close_r+0x1a>
200262e4:	6023      	str	r3, [r4, #0]
200262e6:	bd38      	pop	{r3, r4, r5, pc}
200262e8:	2004d218 	.word	0x2004d218

200262ec <_lseek_r>:
200262ec:	b538      	push	{r3, r4, r5, lr}
200262ee:	4604      	mov	r4, r0
200262f0:	4d06      	ldr	r5, [pc, #24]	@ (2002630c <_lseek_r+0x20>)
200262f2:	4608      	mov	r0, r1
200262f4:	4611      	mov	r1, r2
200262f6:	2200      	movs	r2, #0
200262f8:	602a      	str	r2, [r5, #0]
200262fa:	461a      	mov	r2, r3
200262fc:	f7fb f9d1 	bl	200216a2 <_lseek>
20026300:	1c43      	adds	r3, r0, #1
20026302:	d102      	bne.n	2002630a <_lseek_r+0x1e>
20026304:	682b      	ldr	r3, [r5, #0]
20026306:	b103      	cbz	r3, 2002630a <_lseek_r+0x1e>
20026308:	6023      	str	r3, [r4, #0]
2002630a:	bd38      	pop	{r3, r4, r5, pc}
2002630c:	2004d218 	.word	0x2004d218

20026310 <_read_r>:
20026310:	b538      	push	{r3, r4, r5, lr}
20026312:	4604      	mov	r4, r0
20026314:	4d06      	ldr	r5, [pc, #24]	@ (20026330 <_read_r+0x20>)
20026316:	4608      	mov	r0, r1
20026318:	4611      	mov	r1, r2
2002631a:	2200      	movs	r2, #0
2002631c:	602a      	str	r2, [r5, #0]
2002631e:	461a      	mov	r2, r3
20026320:	f7fb f9c2 	bl	200216a8 <_read>
20026324:	1c43      	adds	r3, r0, #1
20026326:	d102      	bne.n	2002632e <_read_r+0x1e>
20026328:	682b      	ldr	r3, [r5, #0]
2002632a:	b103      	cbz	r3, 2002632e <_read_r+0x1e>
2002632c:	6023      	str	r3, [r4, #0]
2002632e:	bd38      	pop	{r3, r4, r5, pc}
20026330:	2004d218 	.word	0x2004d218

20026334 <_sbrk_r>:
20026334:	b538      	push	{r3, r4, r5, lr}
20026336:	2300      	movs	r3, #0
20026338:	4d05      	ldr	r5, [pc, #20]	@ (20026350 <_sbrk_r+0x1c>)
2002633a:	4604      	mov	r4, r0
2002633c:	4608      	mov	r0, r1
2002633e:	602b      	str	r3, [r5, #0]
20026340:	f000 fbd6 	bl	20026af0 <_sbrk>
20026344:	1c43      	adds	r3, r0, #1
20026346:	d102      	bne.n	2002634e <_sbrk_r+0x1a>
20026348:	682b      	ldr	r3, [r5, #0]
2002634a:	b103      	cbz	r3, 2002634e <_sbrk_r+0x1a>
2002634c:	6023      	str	r3, [r4, #0]
2002634e:	bd38      	pop	{r3, r4, r5, pc}
20026350:	2004d218 	.word	0x2004d218

20026354 <_write_r>:
20026354:	b538      	push	{r3, r4, r5, lr}
20026356:	4604      	mov	r4, r0
20026358:	4d06      	ldr	r5, [pc, #24]	@ (20026374 <_write_r+0x20>)
2002635a:	4608      	mov	r0, r1
2002635c:	4611      	mov	r1, r2
2002635e:	2200      	movs	r2, #0
20026360:	602a      	str	r2, [r5, #0]
20026362:	461a      	mov	r2, r3
20026364:	f7fa fd7c 	bl	20020e60 <_write>
20026368:	1c43      	adds	r3, r0, #1
2002636a:	d102      	bne.n	20026372 <_write_r+0x1e>
2002636c:	682b      	ldr	r3, [r5, #0]
2002636e:	b103      	cbz	r3, 20026372 <_write_r+0x1e>
20026370:	6023      	str	r3, [r4, #0]
20026372:	bd38      	pop	{r3, r4, r5, pc}
20026374:	2004d218 	.word	0x2004d218

20026378 <__retarget_lock_init_recursive>:
20026378:	4770      	bx	lr

2002637a <__retarget_lock_acquire_recursive>:
2002637a:	4770      	bx	lr

2002637c <__retarget_lock_release_recursive>:
2002637c:	4770      	bx	lr

2002637e <memchr>:
2002637e:	b2c9      	uxtb	r1, r1
20026380:	4603      	mov	r3, r0
20026382:	4402      	add	r2, r0
20026384:	b510      	push	{r4, lr}
20026386:	4293      	cmp	r3, r2
20026388:	4618      	mov	r0, r3
2002638a:	d101      	bne.n	20026390 <memchr+0x12>
2002638c:	2000      	movs	r0, #0
2002638e:	e003      	b.n	20026398 <memchr+0x1a>
20026390:	7804      	ldrb	r4, [r0, #0]
20026392:	3301      	adds	r3, #1
20026394:	428c      	cmp	r4, r1
20026396:	d1f6      	bne.n	20026386 <memchr+0x8>
20026398:	bd10      	pop	{r4, pc}

2002639a <memcpy>:
2002639a:	440a      	add	r2, r1
2002639c:	1e43      	subs	r3, r0, #1
2002639e:	4291      	cmp	r1, r2
200263a0:	d100      	bne.n	200263a4 <memcpy+0xa>
200263a2:	4770      	bx	lr
200263a4:	b510      	push	{r4, lr}
200263a6:	f811 4b01 	ldrb.w	r4, [r1], #1
200263aa:	4291      	cmp	r1, r2
200263ac:	f803 4f01 	strb.w	r4, [r3, #1]!
200263b0:	d1f9      	bne.n	200263a6 <memcpy+0xc>
200263b2:	bd10      	pop	{r4, pc}

200263b4 <_free_r>:
200263b4:	b538      	push	{r3, r4, r5, lr}
200263b6:	4605      	mov	r5, r0
200263b8:	2900      	cmp	r1, #0
200263ba:	d041      	beq.n	20026440 <_free_r+0x8c>
200263bc:	f851 3c04 	ldr.w	r3, [r1, #-4]
200263c0:	1f0c      	subs	r4, r1, #4
200263c2:	2b00      	cmp	r3, #0
200263c4:	bfb8      	it	lt
200263c6:	18e4      	addlt	r4, r4, r3
200263c8:	f7ff fcaa 	bl	20025d20 <__malloc_lock>
200263cc:	4a1d      	ldr	r2, [pc, #116]	@ (20026444 <_free_r+0x90>)
200263ce:	6813      	ldr	r3, [r2, #0]
200263d0:	b933      	cbnz	r3, 200263e0 <_free_r+0x2c>
200263d2:	6063      	str	r3, [r4, #4]
200263d4:	6014      	str	r4, [r2, #0]
200263d6:	4628      	mov	r0, r5
200263d8:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200263dc:	f7ff bca6 	b.w	20025d2c <__malloc_unlock>
200263e0:	42a3      	cmp	r3, r4
200263e2:	d908      	bls.n	200263f6 <_free_r+0x42>
200263e4:	6820      	ldr	r0, [r4, #0]
200263e6:	1821      	adds	r1, r4, r0
200263e8:	428b      	cmp	r3, r1
200263ea:	bf01      	itttt	eq
200263ec:	6819      	ldreq	r1, [r3, #0]
200263ee:	685b      	ldreq	r3, [r3, #4]
200263f0:	1809      	addeq	r1, r1, r0
200263f2:	6021      	streq	r1, [r4, #0]
200263f4:	e7ed      	b.n	200263d2 <_free_r+0x1e>
200263f6:	461a      	mov	r2, r3
200263f8:	685b      	ldr	r3, [r3, #4]
200263fa:	b10b      	cbz	r3, 20026400 <_free_r+0x4c>
200263fc:	42a3      	cmp	r3, r4
200263fe:	d9fa      	bls.n	200263f6 <_free_r+0x42>
20026400:	6811      	ldr	r1, [r2, #0]
20026402:	1850      	adds	r0, r2, r1
20026404:	42a0      	cmp	r0, r4
20026406:	d10b      	bne.n	20026420 <_free_r+0x6c>
20026408:	6820      	ldr	r0, [r4, #0]
2002640a:	4401      	add	r1, r0
2002640c:	1850      	adds	r0, r2, r1
2002640e:	6011      	str	r1, [r2, #0]
20026410:	4283      	cmp	r3, r0
20026412:	d1e0      	bne.n	200263d6 <_free_r+0x22>
20026414:	6818      	ldr	r0, [r3, #0]
20026416:	685b      	ldr	r3, [r3, #4]
20026418:	4408      	add	r0, r1
2002641a:	6053      	str	r3, [r2, #4]
2002641c:	6010      	str	r0, [r2, #0]
2002641e:	e7da      	b.n	200263d6 <_free_r+0x22>
20026420:	d902      	bls.n	20026428 <_free_r+0x74>
20026422:	230c      	movs	r3, #12
20026424:	602b      	str	r3, [r5, #0]
20026426:	e7d6      	b.n	200263d6 <_free_r+0x22>
20026428:	6820      	ldr	r0, [r4, #0]
2002642a:	1821      	adds	r1, r4, r0
2002642c:	428b      	cmp	r3, r1
2002642e:	bf02      	ittt	eq
20026430:	6819      	ldreq	r1, [r3, #0]
20026432:	685b      	ldreq	r3, [r3, #4]
20026434:	1809      	addeq	r1, r1, r0
20026436:	6063      	str	r3, [r4, #4]
20026438:	bf08      	it	eq
2002643a:	6021      	streq	r1, [r4, #0]
2002643c:	6054      	str	r4, [r2, #4]
2002643e:	e7ca      	b.n	200263d6 <_free_r+0x22>
20026440:	bd38      	pop	{r3, r4, r5, pc}
20026442:	bf00      	nop
20026444:	2004d0d8 	.word	0x2004d0d8

20026448 <__sfputc_r>:
20026448:	6893      	ldr	r3, [r2, #8]
2002644a:	3b01      	subs	r3, #1
2002644c:	2b00      	cmp	r3, #0
2002644e:	b410      	push	{r4}
20026450:	6093      	str	r3, [r2, #8]
20026452:	da08      	bge.n	20026466 <__sfputc_r+0x1e>
20026454:	6994      	ldr	r4, [r2, #24]
20026456:	42a3      	cmp	r3, r4
20026458:	db01      	blt.n	2002645e <__sfputc_r+0x16>
2002645a:	290a      	cmp	r1, #10
2002645c:	d103      	bne.n	20026466 <__sfputc_r+0x1e>
2002645e:	f85d 4b04 	ldr.w	r4, [sp], #4
20026462:	f7ff be89 	b.w	20026178 <__swbuf_r>
20026466:	6813      	ldr	r3, [r2, #0]
20026468:	1c58      	adds	r0, r3, #1
2002646a:	6010      	str	r0, [r2, #0]
2002646c:	4608      	mov	r0, r1
2002646e:	7019      	strb	r1, [r3, #0]
20026470:	f85d 4b04 	ldr.w	r4, [sp], #4
20026474:	4770      	bx	lr

20026476 <__sfputs_r>:
20026476:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20026478:	4606      	mov	r6, r0
2002647a:	460f      	mov	r7, r1
2002647c:	4614      	mov	r4, r2
2002647e:	18d5      	adds	r5, r2, r3
20026480:	42ac      	cmp	r4, r5
20026482:	d101      	bne.n	20026488 <__sfputs_r+0x12>
20026484:	2000      	movs	r0, #0
20026486:	e007      	b.n	20026498 <__sfputs_r+0x22>
20026488:	463a      	mov	r2, r7
2002648a:	f814 1b01 	ldrb.w	r1, [r4], #1
2002648e:	4630      	mov	r0, r6
20026490:	f7ff ffda 	bl	20026448 <__sfputc_r>
20026494:	1c43      	adds	r3, r0, #1
20026496:	d1f3      	bne.n	20026480 <__sfputs_r+0xa>
20026498:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

2002649c <_vfiprintf_r>:
2002649c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200264a0:	460d      	mov	r5, r1
200264a2:	b09d      	sub	sp, #116	@ 0x74
200264a4:	4614      	mov	r4, r2
200264a6:	4698      	mov	r8, r3
200264a8:	4606      	mov	r6, r0
200264aa:	b118      	cbz	r0, 200264b4 <_vfiprintf_r+0x18>
200264ac:	6a03      	ldr	r3, [r0, #32]
200264ae:	b90b      	cbnz	r3, 200264b4 <_vfiprintf_r+0x18>
200264b0:	f7ff fd78 	bl	20025fa4 <__sinit>
200264b4:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
200264b6:	07d9      	lsls	r1, r3, #31
200264b8:	d405      	bmi.n	200264c6 <_vfiprintf_r+0x2a>
200264ba:	89ab      	ldrh	r3, [r5, #12]
200264bc:	059a      	lsls	r2, r3, #22
200264be:	d402      	bmi.n	200264c6 <_vfiprintf_r+0x2a>
200264c0:	6da8      	ldr	r0, [r5, #88]	@ 0x58
200264c2:	f7ff ff5a 	bl	2002637a <__retarget_lock_acquire_recursive>
200264c6:	89ab      	ldrh	r3, [r5, #12]
200264c8:	071b      	lsls	r3, r3, #28
200264ca:	d501      	bpl.n	200264d0 <_vfiprintf_r+0x34>
200264cc:	692b      	ldr	r3, [r5, #16]
200264ce:	b99b      	cbnz	r3, 200264f8 <_vfiprintf_r+0x5c>
200264d0:	4629      	mov	r1, r5
200264d2:	4630      	mov	r0, r6
200264d4:	f7ff fe8e 	bl	200261f4 <__swsetup_r>
200264d8:	b170      	cbz	r0, 200264f8 <_vfiprintf_r+0x5c>
200264da:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
200264dc:	07dc      	lsls	r4, r3, #31
200264de:	d504      	bpl.n	200264ea <_vfiprintf_r+0x4e>
200264e0:	f04f 30ff 	mov.w	r0, #4294967295
200264e4:	b01d      	add	sp, #116	@ 0x74
200264e6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200264ea:	89ab      	ldrh	r3, [r5, #12]
200264ec:	0598      	lsls	r0, r3, #22
200264ee:	d4f7      	bmi.n	200264e0 <_vfiprintf_r+0x44>
200264f0:	6da8      	ldr	r0, [r5, #88]	@ 0x58
200264f2:	f7ff ff43 	bl	2002637c <__retarget_lock_release_recursive>
200264f6:	e7f3      	b.n	200264e0 <_vfiprintf_r+0x44>
200264f8:	2300      	movs	r3, #0
200264fa:	f8cd 800c 	str.w	r8, [sp, #12]
200264fe:	f04f 0901 	mov.w	r9, #1
20026502:	f8df 81b4 	ldr.w	r8, [pc, #436]	@ 200266b8 <_vfiprintf_r+0x21c>
20026506:	9309      	str	r3, [sp, #36]	@ 0x24
20026508:	2320      	movs	r3, #32
2002650a:	f88d 3029 	strb.w	r3, [sp, #41]	@ 0x29
2002650e:	2330      	movs	r3, #48	@ 0x30
20026510:	f88d 302a 	strb.w	r3, [sp, #42]	@ 0x2a
20026514:	4623      	mov	r3, r4
20026516:	469a      	mov	sl, r3
20026518:	f813 2b01 	ldrb.w	r2, [r3], #1
2002651c:	b10a      	cbz	r2, 20026522 <_vfiprintf_r+0x86>
2002651e:	2a25      	cmp	r2, #37	@ 0x25
20026520:	d1f9      	bne.n	20026516 <_vfiprintf_r+0x7a>
20026522:	ebba 0b04 	subs.w	fp, sl, r4
20026526:	d00b      	beq.n	20026540 <_vfiprintf_r+0xa4>
20026528:	465b      	mov	r3, fp
2002652a:	4622      	mov	r2, r4
2002652c:	4629      	mov	r1, r5
2002652e:	4630      	mov	r0, r6
20026530:	f7ff ffa1 	bl	20026476 <__sfputs_r>
20026534:	3001      	adds	r0, #1
20026536:	f000 80a7 	beq.w	20026688 <_vfiprintf_r+0x1ec>
2002653a:	9a09      	ldr	r2, [sp, #36]	@ 0x24
2002653c:	445a      	add	r2, fp
2002653e:	9209      	str	r2, [sp, #36]	@ 0x24
20026540:	f89a 3000 	ldrb.w	r3, [sl]
20026544:	2b00      	cmp	r3, #0
20026546:	f000 809f 	beq.w	20026688 <_vfiprintf_r+0x1ec>
2002654a:	2300      	movs	r3, #0
2002654c:	f04f 32ff 	mov.w	r2, #4294967295
20026550:	f10a 0a01 	add.w	sl, sl, #1
20026554:	9304      	str	r3, [sp, #16]
20026556:	9307      	str	r3, [sp, #28]
20026558:	f88d 3053 	strb.w	r3, [sp, #83]	@ 0x53
2002655c:	931a      	str	r3, [sp, #104]	@ 0x68
2002655e:	e9cd 2305 	strd	r2, r3, [sp, #20]
20026562:	4654      	mov	r4, sl
20026564:	2205      	movs	r2, #5
20026566:	4854      	ldr	r0, [pc, #336]	@ (200266b8 <_vfiprintf_r+0x21c>)
20026568:	f814 1b01 	ldrb.w	r1, [r4], #1
2002656c:	f7ff ff07 	bl	2002637e <memchr>
20026570:	9a04      	ldr	r2, [sp, #16]
20026572:	b9d8      	cbnz	r0, 200265ac <_vfiprintf_r+0x110>
20026574:	06d1      	lsls	r1, r2, #27
20026576:	bf44      	itt	mi
20026578:	2320      	movmi	r3, #32
2002657a:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
2002657e:	0713      	lsls	r3, r2, #28
20026580:	bf44      	itt	mi
20026582:	232b      	movmi	r3, #43	@ 0x2b
20026584:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20026588:	f89a 3000 	ldrb.w	r3, [sl]
2002658c:	2b2a      	cmp	r3, #42	@ 0x2a
2002658e:	d015      	beq.n	200265bc <_vfiprintf_r+0x120>
20026590:	9a07      	ldr	r2, [sp, #28]
20026592:	4654      	mov	r4, sl
20026594:	2000      	movs	r0, #0
20026596:	f04f 0c0a 	mov.w	ip, #10
2002659a:	4621      	mov	r1, r4
2002659c:	f811 3b01 	ldrb.w	r3, [r1], #1
200265a0:	3b30      	subs	r3, #48	@ 0x30
200265a2:	2b09      	cmp	r3, #9
200265a4:	d94b      	bls.n	2002663e <_vfiprintf_r+0x1a2>
200265a6:	b1b0      	cbz	r0, 200265d6 <_vfiprintf_r+0x13a>
200265a8:	9207      	str	r2, [sp, #28]
200265aa:	e014      	b.n	200265d6 <_vfiprintf_r+0x13a>
200265ac:	eba0 0308 	sub.w	r3, r0, r8
200265b0:	46a2      	mov	sl, r4
200265b2:	fa09 f303 	lsl.w	r3, r9, r3
200265b6:	4313      	orrs	r3, r2
200265b8:	9304      	str	r3, [sp, #16]
200265ba:	e7d2      	b.n	20026562 <_vfiprintf_r+0xc6>
200265bc:	9b03      	ldr	r3, [sp, #12]
200265be:	1d19      	adds	r1, r3, #4
200265c0:	681b      	ldr	r3, [r3, #0]
200265c2:	2b00      	cmp	r3, #0
200265c4:	9103      	str	r1, [sp, #12]
200265c6:	bfbb      	ittet	lt
200265c8:	425b      	neglt	r3, r3
200265ca:	f042 0202 	orrlt.w	r2, r2, #2
200265ce:	9307      	strge	r3, [sp, #28]
200265d0:	9307      	strlt	r3, [sp, #28]
200265d2:	bfb8      	it	lt
200265d4:	9204      	strlt	r2, [sp, #16]
200265d6:	7823      	ldrb	r3, [r4, #0]
200265d8:	2b2e      	cmp	r3, #46	@ 0x2e
200265da:	d10a      	bne.n	200265f2 <_vfiprintf_r+0x156>
200265dc:	7863      	ldrb	r3, [r4, #1]
200265de:	2b2a      	cmp	r3, #42	@ 0x2a
200265e0:	d132      	bne.n	20026648 <_vfiprintf_r+0x1ac>
200265e2:	9b03      	ldr	r3, [sp, #12]
200265e4:	3402      	adds	r4, #2
200265e6:	1d1a      	adds	r2, r3, #4
200265e8:	681b      	ldr	r3, [r3, #0]
200265ea:	ea43 73e3 	orr.w	r3, r3, r3, asr #31
200265ee:	9203      	str	r2, [sp, #12]
200265f0:	9305      	str	r3, [sp, #20]
200265f2:	f8df a0d4 	ldr.w	sl, [pc, #212]	@ 200266c8 <_vfiprintf_r+0x22c>
200265f6:	2203      	movs	r2, #3
200265f8:	7821      	ldrb	r1, [r4, #0]
200265fa:	4650      	mov	r0, sl
200265fc:	f7ff febf 	bl	2002637e <memchr>
20026600:	b138      	cbz	r0, 20026612 <_vfiprintf_r+0x176>
20026602:	eba0 000a 	sub.w	r0, r0, sl
20026606:	2240      	movs	r2, #64	@ 0x40
20026608:	9b04      	ldr	r3, [sp, #16]
2002660a:	3401      	adds	r4, #1
2002660c:	4082      	lsls	r2, r0
2002660e:	4313      	orrs	r3, r2
20026610:	9304      	str	r3, [sp, #16]
20026612:	f814 1b01 	ldrb.w	r1, [r4], #1
20026616:	2206      	movs	r2, #6
20026618:	4828      	ldr	r0, [pc, #160]	@ (200266bc <_vfiprintf_r+0x220>)
2002661a:	f88d 1028 	strb.w	r1, [sp, #40]	@ 0x28
2002661e:	f7ff feae 	bl	2002637e <memchr>
20026622:	2800      	cmp	r0, #0
20026624:	d03f      	beq.n	200266a6 <_vfiprintf_r+0x20a>
20026626:	4b26      	ldr	r3, [pc, #152]	@ (200266c0 <_vfiprintf_r+0x224>)
20026628:	bb1b      	cbnz	r3, 20026672 <_vfiprintf_r+0x1d6>
2002662a:	9b03      	ldr	r3, [sp, #12]
2002662c:	3307      	adds	r3, #7
2002662e:	f023 0307 	bic.w	r3, r3, #7
20026632:	3308      	adds	r3, #8
20026634:	9303      	str	r3, [sp, #12]
20026636:	9b09      	ldr	r3, [sp, #36]	@ 0x24
20026638:	443b      	add	r3, r7
2002663a:	9309      	str	r3, [sp, #36]	@ 0x24
2002663c:	e76a      	b.n	20026514 <_vfiprintf_r+0x78>
2002663e:	fb0c 3202 	mla	r2, ip, r2, r3
20026642:	460c      	mov	r4, r1
20026644:	2001      	movs	r0, #1
20026646:	e7a8      	b.n	2002659a <_vfiprintf_r+0xfe>
20026648:	2300      	movs	r3, #0
2002664a:	3401      	adds	r4, #1
2002664c:	f04f 0c0a 	mov.w	ip, #10
20026650:	4619      	mov	r1, r3
20026652:	9305      	str	r3, [sp, #20]
20026654:	4620      	mov	r0, r4
20026656:	f810 2b01 	ldrb.w	r2, [r0], #1
2002665a:	3a30      	subs	r2, #48	@ 0x30
2002665c:	2a09      	cmp	r2, #9
2002665e:	d903      	bls.n	20026668 <_vfiprintf_r+0x1cc>
20026660:	2b00      	cmp	r3, #0
20026662:	d0c6      	beq.n	200265f2 <_vfiprintf_r+0x156>
20026664:	9105      	str	r1, [sp, #20]
20026666:	e7c4      	b.n	200265f2 <_vfiprintf_r+0x156>
20026668:	fb0c 2101 	mla	r1, ip, r1, r2
2002666c:	4604      	mov	r4, r0
2002666e:	2301      	movs	r3, #1
20026670:	e7f0      	b.n	20026654 <_vfiprintf_r+0x1b8>
20026672:	ab03      	add	r3, sp, #12
20026674:	462a      	mov	r2, r5
20026676:	a904      	add	r1, sp, #16
20026678:	4630      	mov	r0, r6
2002667a:	9300      	str	r3, [sp, #0]
2002667c:	4b11      	ldr	r3, [pc, #68]	@ (200266c4 <_vfiprintf_r+0x228>)
2002667e:	f3af 8000 	nop.w
20026682:	4607      	mov	r7, r0
20026684:	1c78      	adds	r0, r7, #1
20026686:	d1d6      	bne.n	20026636 <_vfiprintf_r+0x19a>
20026688:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
2002668a:	07d9      	lsls	r1, r3, #31
2002668c:	d405      	bmi.n	2002669a <_vfiprintf_r+0x1fe>
2002668e:	89ab      	ldrh	r3, [r5, #12]
20026690:	059a      	lsls	r2, r3, #22
20026692:	d402      	bmi.n	2002669a <_vfiprintf_r+0x1fe>
20026694:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20026696:	f7ff fe71 	bl	2002637c <__retarget_lock_release_recursive>
2002669a:	89ab      	ldrh	r3, [r5, #12]
2002669c:	065b      	lsls	r3, r3, #25
2002669e:	f53f af1f 	bmi.w	200264e0 <_vfiprintf_r+0x44>
200266a2:	9809      	ldr	r0, [sp, #36]	@ 0x24
200266a4:	e71e      	b.n	200264e4 <_vfiprintf_r+0x48>
200266a6:	ab03      	add	r3, sp, #12
200266a8:	462a      	mov	r2, r5
200266aa:	a904      	add	r1, sp, #16
200266ac:	4630      	mov	r0, r6
200266ae:	9300      	str	r3, [sp, #0]
200266b0:	4b04      	ldr	r3, [pc, #16]	@ (200266c4 <_vfiprintf_r+0x228>)
200266b2:	f000 f87d 	bl	200267b0 <_printf_i>
200266b6:	e7e4      	b.n	20026682 <_vfiprintf_r+0x1e6>
200266b8:	20026fef 	.word	0x20026fef
200266bc:	20026ff9 	.word	0x20026ff9
200266c0:	00000000 	.word	0x00000000
200266c4:	20026477 	.word	0x20026477
200266c8:	20026ff5 	.word	0x20026ff5

200266cc <_printf_common>:
200266cc:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200266d0:	4616      	mov	r6, r2
200266d2:	4698      	mov	r8, r3
200266d4:	688a      	ldr	r2, [r1, #8]
200266d6:	4607      	mov	r7, r0
200266d8:	690b      	ldr	r3, [r1, #16]
200266da:	460c      	mov	r4, r1
200266dc:	f8dd 9020 	ldr.w	r9, [sp, #32]
200266e0:	4293      	cmp	r3, r2
200266e2:	bfb8      	it	lt
200266e4:	4613      	movlt	r3, r2
200266e6:	6033      	str	r3, [r6, #0]
200266e8:	f891 2043 	ldrb.w	r2, [r1, #67]	@ 0x43
200266ec:	b10a      	cbz	r2, 200266f2 <_printf_common+0x26>
200266ee:	3301      	adds	r3, #1
200266f0:	6033      	str	r3, [r6, #0]
200266f2:	6823      	ldr	r3, [r4, #0]
200266f4:	0699      	lsls	r1, r3, #26
200266f6:	bf42      	ittt	mi
200266f8:	6833      	ldrmi	r3, [r6, #0]
200266fa:	3302      	addmi	r3, #2
200266fc:	6033      	strmi	r3, [r6, #0]
200266fe:	6825      	ldr	r5, [r4, #0]
20026700:	f015 0506 	ands.w	r5, r5, #6
20026704:	d106      	bne.n	20026714 <_printf_common+0x48>
20026706:	f104 0a19 	add.w	sl, r4, #25
2002670a:	68e3      	ldr	r3, [r4, #12]
2002670c:	6832      	ldr	r2, [r6, #0]
2002670e:	1a9b      	subs	r3, r3, r2
20026710:	42ab      	cmp	r3, r5
20026712:	dc2b      	bgt.n	2002676c <_printf_common+0xa0>
20026714:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
20026718:	6822      	ldr	r2, [r4, #0]
2002671a:	3b00      	subs	r3, #0
2002671c:	bf18      	it	ne
2002671e:	2301      	movne	r3, #1
20026720:	0692      	lsls	r2, r2, #26
20026722:	d430      	bmi.n	20026786 <_printf_common+0xba>
20026724:	f104 0243 	add.w	r2, r4, #67	@ 0x43
20026728:	4641      	mov	r1, r8
2002672a:	4638      	mov	r0, r7
2002672c:	47c8      	blx	r9
2002672e:	3001      	adds	r0, #1
20026730:	d023      	beq.n	2002677a <_printf_common+0xae>
20026732:	6823      	ldr	r3, [r4, #0]
20026734:	341a      	adds	r4, #26
20026736:	f854 2c0a 	ldr.w	r2, [r4, #-10]
2002673a:	f003 0306 	and.w	r3, r3, #6
2002673e:	2b04      	cmp	r3, #4
20026740:	bf0a      	itet	eq
20026742:	f854 5c0e 	ldreq.w	r5, [r4, #-14]
20026746:	2500      	movne	r5, #0
20026748:	6833      	ldreq	r3, [r6, #0]
2002674a:	f04f 0600 	mov.w	r6, #0
2002674e:	bf08      	it	eq
20026750:	1aed      	subeq	r5, r5, r3
20026752:	f854 3c12 	ldr.w	r3, [r4, #-18]
20026756:	bf08      	it	eq
20026758:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
2002675c:	4293      	cmp	r3, r2
2002675e:	bfc4      	itt	gt
20026760:	1a9b      	subgt	r3, r3, r2
20026762:	18ed      	addgt	r5, r5, r3
20026764:	42b5      	cmp	r5, r6
20026766:	d11a      	bne.n	2002679e <_printf_common+0xd2>
20026768:	2000      	movs	r0, #0
2002676a:	e008      	b.n	2002677e <_printf_common+0xb2>
2002676c:	2301      	movs	r3, #1
2002676e:	4652      	mov	r2, sl
20026770:	4641      	mov	r1, r8
20026772:	4638      	mov	r0, r7
20026774:	47c8      	blx	r9
20026776:	3001      	adds	r0, #1
20026778:	d103      	bne.n	20026782 <_printf_common+0xb6>
2002677a:	f04f 30ff 	mov.w	r0, #4294967295
2002677e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20026782:	3501      	adds	r5, #1
20026784:	e7c1      	b.n	2002670a <_printf_common+0x3e>
20026786:	18e1      	adds	r1, r4, r3
20026788:	1c5a      	adds	r2, r3, #1
2002678a:	2030      	movs	r0, #48	@ 0x30
2002678c:	3302      	adds	r3, #2
2002678e:	4422      	add	r2, r4
20026790:	f881 0043 	strb.w	r0, [r1, #67]	@ 0x43
20026794:	f894 1045 	ldrb.w	r1, [r4, #69]	@ 0x45
20026798:	f882 1043 	strb.w	r1, [r2, #67]	@ 0x43
2002679c:	e7c2      	b.n	20026724 <_printf_common+0x58>
2002679e:	2301      	movs	r3, #1
200267a0:	4622      	mov	r2, r4
200267a2:	4641      	mov	r1, r8
200267a4:	4638      	mov	r0, r7
200267a6:	47c8      	blx	r9
200267a8:	3001      	adds	r0, #1
200267aa:	d0e6      	beq.n	2002677a <_printf_common+0xae>
200267ac:	3601      	adds	r6, #1
200267ae:	e7d9      	b.n	20026764 <_printf_common+0x98>

200267b0 <_printf_i>:
200267b0:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
200267b4:	7e0f      	ldrb	r7, [r1, #24]
200267b6:	4691      	mov	r9, r2
200267b8:	4680      	mov	r8, r0
200267ba:	460c      	mov	r4, r1
200267bc:	2f78      	cmp	r7, #120	@ 0x78
200267be:	469a      	mov	sl, r3
200267c0:	9e0c      	ldr	r6, [sp, #48]	@ 0x30
200267c2:	f101 0243 	add.w	r2, r1, #67	@ 0x43
200267c6:	d807      	bhi.n	200267d8 <_printf_i+0x28>
200267c8:	2f62      	cmp	r7, #98	@ 0x62
200267ca:	d80a      	bhi.n	200267e2 <_printf_i+0x32>
200267cc:	2f00      	cmp	r7, #0
200267ce:	f000 80d2 	beq.w	20026976 <_printf_i+0x1c6>
200267d2:	2f58      	cmp	r7, #88	@ 0x58
200267d4:	f000 80b7 	beq.w	20026946 <_printf_i+0x196>
200267d8:	f104 0642 	add.w	r6, r4, #66	@ 0x42
200267dc:	f884 7042 	strb.w	r7, [r4, #66]	@ 0x42
200267e0:	e03a      	b.n	20026858 <_printf_i+0xa8>
200267e2:	f1a7 0363 	sub.w	r3, r7, #99	@ 0x63
200267e6:	2b15      	cmp	r3, #21
200267e8:	d8f6      	bhi.n	200267d8 <_printf_i+0x28>
200267ea:	a101      	add	r1, pc, #4	@ (adr r1, 200267f0 <_printf_i+0x40>)
200267ec:	f851 f023 	ldr.w	pc, [r1, r3, lsl #2]
200267f0:	20026849 	.word	0x20026849
200267f4:	2002685d 	.word	0x2002685d
200267f8:	200267d9 	.word	0x200267d9
200267fc:	200267d9 	.word	0x200267d9
20026800:	200267d9 	.word	0x200267d9
20026804:	200267d9 	.word	0x200267d9
20026808:	2002685d 	.word	0x2002685d
2002680c:	200267d9 	.word	0x200267d9
20026810:	200267d9 	.word	0x200267d9
20026814:	200267d9 	.word	0x200267d9
20026818:	200267d9 	.word	0x200267d9
2002681c:	2002695d 	.word	0x2002695d
20026820:	20026887 	.word	0x20026887
20026824:	20026913 	.word	0x20026913
20026828:	200267d9 	.word	0x200267d9
2002682c:	200267d9 	.word	0x200267d9
20026830:	2002697f 	.word	0x2002697f
20026834:	200267d9 	.word	0x200267d9
20026838:	20026887 	.word	0x20026887
2002683c:	200267d9 	.word	0x200267d9
20026840:	200267d9 	.word	0x200267d9
20026844:	2002691b 	.word	0x2002691b
20026848:	6833      	ldr	r3, [r6, #0]
2002684a:	1d1a      	adds	r2, r3, #4
2002684c:	681b      	ldr	r3, [r3, #0]
2002684e:	6032      	str	r2, [r6, #0]
20026850:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20026854:	f884 3042 	strb.w	r3, [r4, #66]	@ 0x42
20026858:	2301      	movs	r3, #1
2002685a:	e09d      	b.n	20026998 <_printf_i+0x1e8>
2002685c:	6833      	ldr	r3, [r6, #0]
2002685e:	6820      	ldr	r0, [r4, #0]
20026860:	1d19      	adds	r1, r3, #4
20026862:	6031      	str	r1, [r6, #0]
20026864:	0606      	lsls	r6, r0, #24
20026866:	d501      	bpl.n	2002686c <_printf_i+0xbc>
20026868:	681d      	ldr	r5, [r3, #0]
2002686a:	e003      	b.n	20026874 <_printf_i+0xc4>
2002686c:	0645      	lsls	r5, r0, #25
2002686e:	d5fb      	bpl.n	20026868 <_printf_i+0xb8>
20026870:	f9b3 5000 	ldrsh.w	r5, [r3]
20026874:	2d00      	cmp	r5, #0
20026876:	da03      	bge.n	20026880 <_printf_i+0xd0>
20026878:	232d      	movs	r3, #45	@ 0x2d
2002687a:	426d      	negs	r5, r5
2002687c:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026880:	4859      	ldr	r0, [pc, #356]	@ (200269e8 <_printf_i+0x238>)
20026882:	230a      	movs	r3, #10
20026884:	e010      	b.n	200268a8 <_printf_i+0xf8>
20026886:	6821      	ldr	r1, [r4, #0]
20026888:	6833      	ldr	r3, [r6, #0]
2002688a:	0608      	lsls	r0, r1, #24
2002688c:	f853 5b04 	ldr.w	r5, [r3], #4
20026890:	d402      	bmi.n	20026898 <_printf_i+0xe8>
20026892:	0649      	lsls	r1, r1, #25
20026894:	bf48      	it	mi
20026896:	b2ad      	uxthmi	r5, r5
20026898:	2f6f      	cmp	r7, #111	@ 0x6f
2002689a:	4853      	ldr	r0, [pc, #332]	@ (200269e8 <_printf_i+0x238>)
2002689c:	6033      	str	r3, [r6, #0]
2002689e:	d159      	bne.n	20026954 <_printf_i+0x1a4>
200268a0:	2308      	movs	r3, #8
200268a2:	2100      	movs	r1, #0
200268a4:	f884 1043 	strb.w	r1, [r4, #67]	@ 0x43
200268a8:	6866      	ldr	r6, [r4, #4]
200268aa:	2e00      	cmp	r6, #0
200268ac:	60a6      	str	r6, [r4, #8]
200268ae:	db05      	blt.n	200268bc <_printf_i+0x10c>
200268b0:	6821      	ldr	r1, [r4, #0]
200268b2:	432e      	orrs	r6, r5
200268b4:	f021 0104 	bic.w	r1, r1, #4
200268b8:	6021      	str	r1, [r4, #0]
200268ba:	d04d      	beq.n	20026958 <_printf_i+0x1a8>
200268bc:	4616      	mov	r6, r2
200268be:	fbb5 f1f3 	udiv	r1, r5, r3
200268c2:	fb03 5711 	mls	r7, r3, r1, r5
200268c6:	5dc7      	ldrb	r7, [r0, r7]
200268c8:	f806 7d01 	strb.w	r7, [r6, #-1]!
200268cc:	462f      	mov	r7, r5
200268ce:	460d      	mov	r5, r1
200268d0:	42bb      	cmp	r3, r7
200268d2:	d9f4      	bls.n	200268be <_printf_i+0x10e>
200268d4:	2b08      	cmp	r3, #8
200268d6:	d10b      	bne.n	200268f0 <_printf_i+0x140>
200268d8:	6823      	ldr	r3, [r4, #0]
200268da:	07df      	lsls	r7, r3, #31
200268dc:	d508      	bpl.n	200268f0 <_printf_i+0x140>
200268de:	6923      	ldr	r3, [r4, #16]
200268e0:	6861      	ldr	r1, [r4, #4]
200268e2:	4299      	cmp	r1, r3
200268e4:	bfde      	ittt	le
200268e6:	2330      	movle	r3, #48	@ 0x30
200268e8:	f806 3c01 	strble.w	r3, [r6, #-1]
200268ec:	f106 36ff 	addle.w	r6, r6, #4294967295
200268f0:	1b92      	subs	r2, r2, r6
200268f2:	6122      	str	r2, [r4, #16]
200268f4:	464b      	mov	r3, r9
200268f6:	aa03      	add	r2, sp, #12
200268f8:	4621      	mov	r1, r4
200268fa:	4640      	mov	r0, r8
200268fc:	f8cd a000 	str.w	sl, [sp]
20026900:	f7ff fee4 	bl	200266cc <_printf_common>
20026904:	3001      	adds	r0, #1
20026906:	d14c      	bne.n	200269a2 <_printf_i+0x1f2>
20026908:	f04f 30ff 	mov.w	r0, #4294967295
2002690c:	b004      	add	sp, #16
2002690e:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20026912:	6823      	ldr	r3, [r4, #0]
20026914:	f043 0320 	orr.w	r3, r3, #32
20026918:	6023      	str	r3, [r4, #0]
2002691a:	2778      	movs	r7, #120	@ 0x78
2002691c:	4833      	ldr	r0, [pc, #204]	@ (200269ec <_printf_i+0x23c>)
2002691e:	6823      	ldr	r3, [r4, #0]
20026920:	f884 7045 	strb.w	r7, [r4, #69]	@ 0x45
20026924:	061f      	lsls	r7, r3, #24
20026926:	6831      	ldr	r1, [r6, #0]
20026928:	f851 5b04 	ldr.w	r5, [r1], #4
2002692c:	d402      	bmi.n	20026934 <_printf_i+0x184>
2002692e:	065f      	lsls	r7, r3, #25
20026930:	bf48      	it	mi
20026932:	b2ad      	uxthmi	r5, r5
20026934:	6031      	str	r1, [r6, #0]
20026936:	07d9      	lsls	r1, r3, #31
20026938:	bf44      	itt	mi
2002693a:	f043 0320 	orrmi.w	r3, r3, #32
2002693e:	6023      	strmi	r3, [r4, #0]
20026940:	b11d      	cbz	r5, 2002694a <_printf_i+0x19a>
20026942:	2310      	movs	r3, #16
20026944:	e7ad      	b.n	200268a2 <_printf_i+0xf2>
20026946:	4828      	ldr	r0, [pc, #160]	@ (200269e8 <_printf_i+0x238>)
20026948:	e7e9      	b.n	2002691e <_printf_i+0x16e>
2002694a:	6823      	ldr	r3, [r4, #0]
2002694c:	f023 0320 	bic.w	r3, r3, #32
20026950:	6023      	str	r3, [r4, #0]
20026952:	e7f6      	b.n	20026942 <_printf_i+0x192>
20026954:	230a      	movs	r3, #10
20026956:	e7a4      	b.n	200268a2 <_printf_i+0xf2>
20026958:	4616      	mov	r6, r2
2002695a:	e7bb      	b.n	200268d4 <_printf_i+0x124>
2002695c:	6833      	ldr	r3, [r6, #0]
2002695e:	6825      	ldr	r5, [r4, #0]
20026960:	1d18      	adds	r0, r3, #4
20026962:	6961      	ldr	r1, [r4, #20]
20026964:	6030      	str	r0, [r6, #0]
20026966:	062e      	lsls	r6, r5, #24
20026968:	681b      	ldr	r3, [r3, #0]
2002696a:	d501      	bpl.n	20026970 <_printf_i+0x1c0>
2002696c:	6019      	str	r1, [r3, #0]
2002696e:	e002      	b.n	20026976 <_printf_i+0x1c6>
20026970:	0668      	lsls	r0, r5, #25
20026972:	d5fb      	bpl.n	2002696c <_printf_i+0x1bc>
20026974:	8019      	strh	r1, [r3, #0]
20026976:	2300      	movs	r3, #0
20026978:	4616      	mov	r6, r2
2002697a:	6123      	str	r3, [r4, #16]
2002697c:	e7ba      	b.n	200268f4 <_printf_i+0x144>
2002697e:	6833      	ldr	r3, [r6, #0]
20026980:	2100      	movs	r1, #0
20026982:	1d1a      	adds	r2, r3, #4
20026984:	6032      	str	r2, [r6, #0]
20026986:	681e      	ldr	r6, [r3, #0]
20026988:	6862      	ldr	r2, [r4, #4]
2002698a:	4630      	mov	r0, r6
2002698c:	f7ff fcf7 	bl	2002637e <memchr>
20026990:	b108      	cbz	r0, 20026996 <_printf_i+0x1e6>
20026992:	1b80      	subs	r0, r0, r6
20026994:	6060      	str	r0, [r4, #4]
20026996:	6863      	ldr	r3, [r4, #4]
20026998:	6123      	str	r3, [r4, #16]
2002699a:	2300      	movs	r3, #0
2002699c:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
200269a0:	e7a8      	b.n	200268f4 <_printf_i+0x144>
200269a2:	6923      	ldr	r3, [r4, #16]
200269a4:	4632      	mov	r2, r6
200269a6:	4649      	mov	r1, r9
200269a8:	4640      	mov	r0, r8
200269aa:	47d0      	blx	sl
200269ac:	3001      	adds	r0, #1
200269ae:	d0ab      	beq.n	20026908 <_printf_i+0x158>
200269b0:	6823      	ldr	r3, [r4, #0]
200269b2:	079b      	lsls	r3, r3, #30
200269b4:	d413      	bmi.n	200269de <_printf_i+0x22e>
200269b6:	68e0      	ldr	r0, [r4, #12]
200269b8:	9b03      	ldr	r3, [sp, #12]
200269ba:	4298      	cmp	r0, r3
200269bc:	bfb8      	it	lt
200269be:	4618      	movlt	r0, r3
200269c0:	e7a4      	b.n	2002690c <_printf_i+0x15c>
200269c2:	2301      	movs	r3, #1
200269c4:	4632      	mov	r2, r6
200269c6:	4649      	mov	r1, r9
200269c8:	4640      	mov	r0, r8
200269ca:	47d0      	blx	sl
200269cc:	3001      	adds	r0, #1
200269ce:	d09b      	beq.n	20026908 <_printf_i+0x158>
200269d0:	3501      	adds	r5, #1
200269d2:	68e3      	ldr	r3, [r4, #12]
200269d4:	9903      	ldr	r1, [sp, #12]
200269d6:	1a5b      	subs	r3, r3, r1
200269d8:	42ab      	cmp	r3, r5
200269da:	dcf2      	bgt.n	200269c2 <_printf_i+0x212>
200269dc:	e7eb      	b.n	200269b6 <_printf_i+0x206>
200269de:	2500      	movs	r5, #0
200269e0:	f104 0619 	add.w	r6, r4, #25
200269e4:	e7f5      	b.n	200269d2 <_printf_i+0x222>
200269e6:	bf00      	nop
200269e8:	20027000 	.word	0x20027000
200269ec:	20027011 	.word	0x20027011

200269f0 <__swhatbuf_r>:
200269f0:	b570      	push	{r4, r5, r6, lr}
200269f2:	460c      	mov	r4, r1
200269f4:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200269f8:	b096      	sub	sp, #88	@ 0x58
200269fa:	4615      	mov	r5, r2
200269fc:	2900      	cmp	r1, #0
200269fe:	461e      	mov	r6, r3
20026a00:	da0a      	bge.n	20026a18 <__swhatbuf_r+0x28>
20026a02:	89a1      	ldrh	r1, [r4, #12]
20026a04:	f011 0180 	ands.w	r1, r1, #128	@ 0x80
20026a08:	d113      	bne.n	20026a32 <__swhatbuf_r+0x42>
20026a0a:	f44f 6280 	mov.w	r2, #1024	@ 0x400
20026a0e:	2000      	movs	r0, #0
20026a10:	6031      	str	r1, [r6, #0]
20026a12:	602a      	str	r2, [r5, #0]
20026a14:	b016      	add	sp, #88	@ 0x58
20026a16:	bd70      	pop	{r4, r5, r6, pc}
20026a18:	466a      	mov	r2, sp
20026a1a:	f000 f847 	bl	20026aac <_fstat_r>
20026a1e:	2800      	cmp	r0, #0
20026a20:	dbef      	blt.n	20026a02 <__swhatbuf_r+0x12>
20026a22:	9901      	ldr	r1, [sp, #4]
20026a24:	f401 4170 	and.w	r1, r1, #61440	@ 0xf000
20026a28:	f5a1 5300 	sub.w	r3, r1, #8192	@ 0x2000
20026a2c:	4259      	negs	r1, r3
20026a2e:	4159      	adcs	r1, r3
20026a30:	e7eb      	b.n	20026a0a <__swhatbuf_r+0x1a>
20026a32:	2100      	movs	r1, #0
20026a34:	2240      	movs	r2, #64	@ 0x40
20026a36:	e7ea      	b.n	20026a0e <__swhatbuf_r+0x1e>

20026a38 <__smakebuf_r>:
20026a38:	898b      	ldrh	r3, [r1, #12]
20026a3a:	b573      	push	{r0, r1, r4, r5, r6, lr}
20026a3c:	079e      	lsls	r6, r3, #30
20026a3e:	4605      	mov	r5, r0
20026a40:	460c      	mov	r4, r1
20026a42:	d507      	bpl.n	20026a54 <__smakebuf_r+0x1c>
20026a44:	f104 0347 	add.w	r3, r4, #71	@ 0x47
20026a48:	6023      	str	r3, [r4, #0]
20026a4a:	6123      	str	r3, [r4, #16]
20026a4c:	2301      	movs	r3, #1
20026a4e:	6163      	str	r3, [r4, #20]
20026a50:	b002      	add	sp, #8
20026a52:	bd70      	pop	{r4, r5, r6, pc}
20026a54:	ab01      	add	r3, sp, #4
20026a56:	466a      	mov	r2, sp
20026a58:	f7ff ffca 	bl	200269f0 <__swhatbuf_r>
20026a5c:	9e00      	ldr	r6, [sp, #0]
20026a5e:	4628      	mov	r0, r5
20026a60:	4631      	mov	r1, r6
20026a62:	f7ff f8dd 	bl	20025c20 <_malloc_r>
20026a66:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20026a6a:	b938      	cbnz	r0, 20026a7c <__smakebuf_r+0x44>
20026a6c:	059a      	lsls	r2, r3, #22
20026a6e:	d4ef      	bmi.n	20026a50 <__smakebuf_r+0x18>
20026a70:	f023 0303 	bic.w	r3, r3, #3
20026a74:	f043 0302 	orr.w	r3, r3, #2
20026a78:	81a3      	strh	r3, [r4, #12]
20026a7a:	e7e3      	b.n	20026a44 <__smakebuf_r+0xc>
20026a7c:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20026a80:	6020      	str	r0, [r4, #0]
20026a82:	81a3      	strh	r3, [r4, #12]
20026a84:	9b01      	ldr	r3, [sp, #4]
20026a86:	e9c4 0604 	strd	r0, r6, [r4, #16]
20026a8a:	2b00      	cmp	r3, #0
20026a8c:	d0e0      	beq.n	20026a50 <__smakebuf_r+0x18>
20026a8e:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20026a92:	4628      	mov	r0, r5
20026a94:	f000 f81c 	bl	20026ad0 <_isatty_r>
20026a98:	2800      	cmp	r0, #0
20026a9a:	d0d9      	beq.n	20026a50 <__smakebuf_r+0x18>
20026a9c:	89a3      	ldrh	r3, [r4, #12]
20026a9e:	f023 0303 	bic.w	r3, r3, #3
20026aa2:	f043 0301 	orr.w	r3, r3, #1
20026aa6:	81a3      	strh	r3, [r4, #12]
20026aa8:	e7d2      	b.n	20026a50 <__smakebuf_r+0x18>
	...

20026aac <_fstat_r>:
20026aac:	b538      	push	{r3, r4, r5, lr}
20026aae:	2300      	movs	r3, #0
20026ab0:	4d06      	ldr	r5, [pc, #24]	@ (20026acc <_fstat_r+0x20>)
20026ab2:	4604      	mov	r4, r0
20026ab4:	4608      	mov	r0, r1
20026ab6:	4611      	mov	r1, r2
20026ab8:	602b      	str	r3, [r5, #0]
20026aba:	f7fa fdf7 	bl	200216ac <_fstat>
20026abe:	1c43      	adds	r3, r0, #1
20026ac0:	d102      	bne.n	20026ac8 <_fstat_r+0x1c>
20026ac2:	682b      	ldr	r3, [r5, #0]
20026ac4:	b103      	cbz	r3, 20026ac8 <_fstat_r+0x1c>
20026ac6:	6023      	str	r3, [r4, #0]
20026ac8:	bd38      	pop	{r3, r4, r5, pc}
20026aca:	bf00      	nop
20026acc:	2004d218 	.word	0x2004d218

20026ad0 <_isatty_r>:
20026ad0:	b538      	push	{r3, r4, r5, lr}
20026ad2:	2300      	movs	r3, #0
20026ad4:	4d05      	ldr	r5, [pc, #20]	@ (20026aec <_isatty_r+0x1c>)
20026ad6:	4604      	mov	r4, r0
20026ad8:	4608      	mov	r0, r1
20026ada:	602b      	str	r3, [r5, #0]
20026adc:	f7fa fde8 	bl	200216b0 <_isatty>
20026ae0:	1c43      	adds	r3, r0, #1
20026ae2:	d102      	bne.n	20026aea <_isatty_r+0x1a>
20026ae4:	682b      	ldr	r3, [r5, #0]
20026ae6:	b103      	cbz	r3, 20026aea <_isatty_r+0x1a>
20026ae8:	6023      	str	r3, [r4, #0]
20026aea:	bd38      	pop	{r3, r4, r5, pc}
20026aec:	2004d218 	.word	0x2004d218

20026af0 <_sbrk>:
20026af0:	4a05      	ldr	r2, [pc, #20]	@ (20026b08 <_sbrk+0x18>)
20026af2:	4603      	mov	r3, r0
20026af4:	6810      	ldr	r0, [r2, #0]
20026af6:	b110      	cbz	r0, 20026afe <_sbrk+0xe>
20026af8:	4403      	add	r3, r0
20026afa:	6013      	str	r3, [r2, #0]
20026afc:	4770      	bx	lr
20026afe:	4803      	ldr	r0, [pc, #12]	@ (20026b0c <_sbrk+0x1c>)
20026b00:	4403      	add	r3, r0
20026b02:	6013      	str	r3, [r2, #0]
20026b04:	4770      	bx	lr
20026b06:	bf00      	nop
20026b08:	2004d220 	.word	0x2004d220
20026b0c:	20042000 	.word	0x20042000
20026b10:	61766e69 	.word	0x61766e69
20026b14:	2064696c 	.word	0x2064696c
20026b18:	746f6f62 	.word	0x746f6f62
20026b1c:	76656420 	.word	0x76656420
20026b20:	00656369 	.word	0x00656369
20026b24:	693a4c42 	.word	0x693a4c42
20026b28:	6c61766e 	.word	0x6c61766e
20026b2c:	66206469 	.word	0x66206469
20026b30:	20626174 	.word	0x20626174
20026b34:	6967616d 	.word	0x6967616d
20026b38:	72662063 	.word	0x72662063
20026b3c:	64206d6f 	.word	0x64206d6f
20026b40:	63697665 	.word	0x63697665
20026b44:	64253a65 	.word	0x64253a65
20026b48:	4c42000a 	.word	0x4c42000a
20026b4c:	6f6f623a 	.word	0x6f6f623a
20026b50:	65642074 	.word	0x65642074
20026b54:	65636976 	.word	0x65636976
20026b58:	696e6920 	.word	0x696e6920
20026b5c:	61662074 	.word	0x61662074
20026b60:	66206c69 	.word	0x66206c69
20026b64:	3a6d6f72 	.word	0x3a6d6f72
20026b68:	000a6425 	.word	0x000a6425
20026b6c:	64616f6c 	.word	0x64616f6c
20026b70:	6e616220 	.word	0x6e616220
20026b74:	6620306b 	.word	0x6620306b
20026b78:	736c6961 	.word	0x736c6961
20026b7c:	616d6900 	.word	0x616d6900
20026b80:	73206567 	.word	0x73206567
20026b84:	616e6769 	.word	0x616e6769
20026b88:	65727574 	.word	0x65727574
20026b8c:	72657620 	.word	0x72657620
20026b90:	63696669 	.word	0x63696669
20026b94:	6f697461 	.word	0x6f697461
20026b98:	6166206e 	.word	0x6166206e
20026b9c:	00736c69 	.word	0x00736c69
20026ba0:	2070614d 	.word	0x2070614d
20026ba4:	6f727265 	.word	0x6f727265
20026ba8:	6c203a72 	.word	0x6c203a72
20026bac:	6369676f 	.word	0x6369676f
20026bb0:	2c642520 	.word	0x2c642520
20026bb4:	79687020 	.word	0x79687020
20026bb8:	0a642520 	.word	0x0a642520
20026bbc:	52524500 	.word	0x52524500
20026bc0:	2032203a 	.word	0x2032203a
20026bc4:	69676f6c 	.word	0x69676f6c
20026bc8:	6c622063 	.word	0x6c622063
20026bcc:	736b636f 	.word	0x736b636f
20026bd0:	70616d20 	.word	0x70616d20
20026bd4:	206f7420 	.word	0x206f7420
20026bd8:	656d6173 	.word	0x656d6173
20026bdc:	6b6c6220 	.word	0x6b6c6220
20026be0:	6f6c203a 	.word	0x6f6c203a
20026be4:	30636967 	.word	0x30636967
20026be8:	2c642520 	.word	0x2c642520
20026bec:	79687020 	.word	0x79687020
20026bf0:	64252030 	.word	0x64252030
20026bf4:	6f6c202c 	.word	0x6f6c202c
20026bf8:	31636967 	.word	0x31636967
20026bfc:	2c642520 	.word	0x2c642520
20026c00:	79687020 	.word	0x79687020
20026c04:	64252031 	.word	0x64252031
20026c08:	614d000a 	.word	0x614d000a
20026c0c:	72652070 	.word	0x72652070
20026c10:	30726f72 	.word	0x30726f72
20026c14:	6f6c203a 	.word	0x6f6c203a
20026c18:	20636967 	.word	0x20636967
20026c1c:	202c6425 	.word	0x202c6425
20026c20:	20796870 	.word	0x20796870
20026c24:	000a6425 	.word	0x000a6425
20026c28:	20746547 	.word	0x20746547
20026c2c:	2070616d 	.word	0x2070616d
20026c30:	636f6c62 	.word	0x636f6c62
20026c34:	7265206b 	.word	0x7265206b
20026c38:	20726f72 	.word	0x20726f72
20026c3c:	2d206425 	.word	0x2d206425
20026c40:	25203e2d 	.word	0x25203e2d
20026c44:	42000a64 	.word	0x42000a64
20026c48:	76204d42 	.word	0x76204d42
20026c4c:	69737265 	.word	0x69737265
20026c50:	6e206e6f 	.word	0x6e206e6f
20026c54:	6920746f 	.word	0x6920746f
20026c58:	6572636e 	.word	0x6572636e
20026c5c:	64657361 	.word	0x64657361
20026c60:	7270203a 	.word	0x7270203a
20026c64:	25207665 	.word	0x25207665
20026c68:	63202c64 	.word	0x63202c64
20026c6c:	20727275 	.word	0x20727275
20026c70:	000a6425 	.word	0x000a6425
20026c74:	41544144 	.word	0x41544144
20026c78:	746f6e20 	.word	0x746f6e20
20026c7c:	61657220 	.word	0x61657220
20026c80:	616e6f73 	.word	0x616e6f73
20026c84:	20656c62 	.word	0x20656c62
20026c88:	42206e69 	.word	0x42206e69
20026c8c:	62204d42 	.word	0x62204d42
20026c90:	25206b6c 	.word	0x25206b6c
20026c94:	61702064 	.word	0x61702064
20026c98:	25206567 	.word	0x25206567
20026c9c:	30203a64 	.word	0x30203a64
20026ca0:	0a782578 	.word	0x0a782578
20026ca4:	61655200 	.word	0x61655200
20026ca8:	62622064 	.word	0x62622064
20026cac:	6c62206d 	.word	0x6c62206d
20026cb0:	6425206b 	.word	0x6425206b
20026cb4:	67617020 	.word	0x67617020
20026cb8:	64252065 	.word	0x64252065
20026cbc:	69616620 	.word	0x69616620
20026cc0:	49000a6c 	.word	0x49000a6c
20026cc4:	6c61766e 	.word	0x6c61766e
20026cc8:	42206469 	.word	0x42206469
20026ccc:	49204d42 	.word	0x49204d42
20026cd0:	25205844 	.word	0x25205844
20026cd4:	56000a64 	.word	0x56000a64
20026cd8:	64252031 	.word	0x64252031
20026cdc:	206e6920 	.word	0x206e6920
20026ce0:	636f6c62 	.word	0x636f6c62
20026ce4:	6425206b 	.word	0x6425206b
20026ce8:	3256202c 	.word	0x3256202c
20026cec:	20642520 	.word	0x20642520
20026cf0:	62206e69 	.word	0x62206e69
20026cf4:	6b636f6c 	.word	0x6b636f6c
20026cf8:	0a642520 	.word	0x0a642520
20026cfc:	6d615300 	.word	0x6d615300
20026d00:	69687465 	.word	0x69687465
20026d04:	6d20676e 	.word	0x6d20676e
20026d08:	20747375 	.word	0x20747375
20026d0c:	77206562 	.word	0x77206562
20026d10:	676e6f72 	.word	0x676e6f72
20026d14:	6567202c 	.word	0x6567202c
20026d18:	656e2074 	.word	0x656e2074
20026d1c:	65762077 	.word	0x65762077
20026d20:	6f697372 	.word	0x6f697372
20026d24:	6425206e 	.word	0x6425206e
20026d28:	206f6420 	.word	0x206f6420
20026d2c:	20746f6e 	.word	0x20746f6e
20026d30:	656d6173 	.word	0x656d6173
20026d34:	206f7420 	.word	0x206f7420
20026d38:	76657270 	.word	0x76657270
20026d3c:	65686320 	.word	0x65686320
20026d40:	25206b63 	.word	0x25206b63
20026d44:	43000a64 	.word	0x43000a64
20026d48:	63204352 	.word	0x63204352
20026d4c:	6b636568 	.word	0x6b636568
20026d50:	72726520 	.word	0x72726520
20026d54:	0a20726f 	.word	0x0a20726f
20026d58:	61655200 	.word	0x61655200
20026d5c:	62622064 	.word	0x62622064
20026d60:	6c62206d 	.word	0x6c62206d
20026d64:	6425206b 	.word	0x6425206b
20026d68:	67617020 	.word	0x67617020
20026d6c:	64252065 	.word	0x64252065
20026d70:	74616420 	.word	0x74616420
20026d74:	6f6e2061 	.word	0x6f6e2061
20026d78:	72772074 	.word	0x72772074
20026d7c:	20657469 	.word	0x20657469
20026d80:	20726f66 	.word	0x20726f66
20026d84:	20646e32 	.word	0x20646e32
20026d88:	656d6974 	.word	0x656d6974
20026d8c:	6552000a 	.word	0x6552000a
20026d90:	62206461 	.word	0x62206461
20026d94:	62206d62 	.word	0x62206d62
20026d98:	25206b6c 	.word	0x25206b6c
20026d9c:	61702064 	.word	0x61702064
20026da0:	25206567 	.word	0x25206567
20026da4:	61662064 	.word	0x61662064
20026da8:	66206c69 	.word	0x66206c69
20026dac:	3220726f 	.word	0x3220726f
20026db0:	7420646e 	.word	0x7420646e
20026db4:	3f656d69 	.word	0x3f656d69
20026db8:	614c000a 	.word	0x614c000a
20026dbc:	74736574 	.word	0x74736574
20026dc0:	72657620 	.word	0x72657620
20026dc4:	6e6f6973 	.word	0x6e6f6973
20026dc8:	0a642520 	.word	0x0a642520
20026dcc:	74654700 	.word	0x74654700
20026dd0:	79687020 	.word	0x79687020
20026dd4:	6b6c6220 	.word	0x6b6c6220
20026dd8:	726f6620 	.word	0x726f6620
20026ddc:	20642520 	.word	0x20642520
20026de0:	6c696166 	.word	0x6c696166
20026de4:	65687720 	.word	0x65687720
20026de8:	6572206e 	.word	0x6572206e
20026dec:	000a6461 	.word	0x000a6461
20026df0:	636f6c42 	.word	0x636f6c42
20026df4:	6425206b 	.word	0x6425206b
20026df8:	61726520 	.word	0x61726520
20026dfc:	66206573 	.word	0x66206573
20026e00:	2c6c6961 	.word	0x2c6c6961
20026e04:	72616d20 	.word	0x72616d20
20026e08:	7361206b 	.word	0x7361206b
20026e0c:	64616220 	.word	0x64616220
20026e10:	6c42000a 	.word	0x6c42000a
20026e14:	206b636f 	.word	0x206b636f
20026e18:	63206425 	.word	0x63206425
20026e1c:	6b636568 	.word	0x6b636568
20026e20:	20736120 	.word	0x20736120
20026e24:	20646162 	.word	0x20646162
20026e28:	636f6c62 	.word	0x636f6c62
20026e2c:	42000a6b 	.word	0x42000a6b
20026e30:	6b636f6c 	.word	0x6b636f6c
20026e34:	20642520 	.word	0x20642520
20026e38:	62207369 	.word	0x62207369
20026e3c:	69206461 	.word	0x69206461
20026e40:	7375206e 	.word	0x7375206e
20026e44:	62207265 	.word	0x62207265
20026e48:	6b636f6c 	.word	0x6b636f6c
20026e4c:	6162000a 	.word	0x6162000a
20026e50:	64252064 	.word	0x64252064
20026e54:	6572202c 	.word	0x6572202c
20026e58:	63616c70 	.word	0x63616c70
20026e5c:	64252065 	.word	0x64252065
20026e60:	6f4e000a 	.word	0x6f4e000a
20026e64:	63616220 	.word	0x63616220
20026e68:	2070756b 	.word	0x2070756b
20026e6c:	636f6c62 	.word	0x636f6c62
20026e70:	6e61206b 	.word	0x6e61206b
20026e74:	6f6d2079 	.word	0x6f6d2079
20026e78:	000a6572 	.word	0x000a6572
20026e7c:	74706d65 	.word	0x74706d65
20026e80:	61742079 	.word	0x61742079
20026e84:	20656c62 	.word	0x20656c62
20026e88:	6e206425 	.word	0x6e206425
20026e8c:	6520746f 	.word	0x6520746f
20026e90:	67756f6e 	.word	0x67756f6e
20026e94:	6f662068 	.word	0x6f662068
20026e98:	6e692072 	.word	0x6e692072
20026e9c:	61697469 	.word	0x61697469
20026ea0:	55000a6c 	.word	0x55000a6c
20026ea4:	74616470 	.word	0x74616470
20026ea8:	61742065 	.word	0x61742065
20026eac:	20656c62 	.word	0x20656c62
20026eb0:	66206f74 	.word	0x66206f74
20026eb4:	6873616c 	.word	0x6873616c
20026eb8:	6e6f6420 	.word	0x6e6f6420
20026ebc:	49000a65 	.word	0x49000a65
20026ec0:	6974696e 	.word	0x6974696e
20026ec4:	74206c61 	.word	0x74206c61
20026ec8:	656c6261 	.word	0x656c6261
20026ecc:	69616620 	.word	0x69616620
20026ed0:	42000a6c 	.word	0x42000a6c
20026ed4:	69204d42 	.word	0x69204d42
20026ed8:	6974696e 	.word	0x6974696e
20026edc:	7a696c61 	.word	0x7a696c61
20026ee0:	62206465 	.word	0x62206465
20026ee4:	726f6665 	.word	0x726f6665
20026ee8:	64202c65 	.word	0x64202c65
20026eec:	6f6e206f 	.word	0x6f6e206f
20026ef0:	6e692074 	.word	0x6e692074
20026ef4:	61207469 	.word	0x61207469
20026ef8:	6d20796e 	.word	0x6d20796e
20026efc:	0a65726f 	.word	0x0a65726f
20026f00:	54454400 	.word	0x54454400
20026f04:	20642520 	.word	0x20642520
20026f08:	0a646162 	.word	0x0a646162
20026f0c:	4b4c4200 	.word	0x4b4c4200
20026f10:	20642520 	.word	0x20642520
20026f14:	64616572 	.word	0x64616572
20026f18:	69616620 	.word	0x69616620
20026f1c:	6d202c6c 	.word	0x6d202c6c
20026f20:	206b7261 	.word	0x206b7261
20026f24:	62207361 	.word	0x62207361
20026f28:	000a6461 	.word	0x000a6461
20026f2c:	20746564 	.word	0x20746564
20026f30:	206d6262 	.word	0x206d6262
20026f34:	6c626174 	.word	0x6c626174
20026f38:	69772065 	.word	0x69772065
20026f3c:	25206874 	.word	0x25206874
20026f40:	25202c64 	.word	0x25202c64
20026f44:	25202c64 	.word	0x25202c64
20026f48:	64000a64 	.word	0x64000a64
20026f4c:	63657465 	.word	0x63657465
20026f50:	65722074 	.word	0x65722074
20026f54:	746c7573 	.word	0x746c7573
20026f58:	0a642520 	.word	0x0a642520
20026f5c:	20317600 	.word	0x20317600
20026f60:	69206425 	.word	0x69206425
20026f64:	6c62206e 	.word	0x6c62206e
20026f68:	6425206b 	.word	0x6425206b
20026f6c:	3276202c 	.word	0x3276202c
20026f70:	20642520 	.word	0x20642520
20026f74:	62206e69 	.word	0x62206e69
20026f78:	6b636f6c 	.word	0x6b636f6c
20026f7c:	0a642520 	.word	0x0a642520
20026f80:	65684300 	.word	0x65684300
20026f84:	62206b63 	.word	0x62206b63
20026f88:	74206d62 	.word	0x74206d62
20026f8c:	656c6261 	.word	0x656c6261
20026f90:	69616620 	.word	0x69616620
20026f94:	64000a6c 	.word	0x64000a6c
20026f98:	63657465 	.word	0x63657465
20026f9c:	65722074 	.word	0x65722074
20026fa0:	746c7573 	.word	0x746c7573
20026fa4:	20642520 	.word	0x20642520
20026fa8:	20746f6e 	.word	0x20746f6e
20026fac:	73616572 	.word	0x73616572
20026fb0:	62616e6f 	.word	0x62616e6f
20026fb4:	000a656c 	.word	0x000a656c
20026fb8:	204d4242 	.word	0x204d4242
20026fbc:	3a4d454d 	.word	0x3a4d454d
20026fc0:	78746320 	.word	0x78746320
20026fc4:	2c702520 	.word	0x2c702520
20026fc8:	70616d20 	.word	0x70616d20
20026fcc:	70252031 	.word	0x70252031
20026fd0:	616d202c 	.word	0x616d202c
20026fd4:	25203270 	.word	0x25203270
20026fd8:	000a2070 	.word	0x000a2070
20026fdc:	5f666973 	.word	0x5f666973
20026fe0:	5f6d6262 	.word	0x5f6d6262
20026fe4:	74696e69 	.word	0x74696e69
20026fe8:	6e6f6420 	.word	0x6e6f6420
20026fec:	23000a65 	.word	0x23000a65
20026ff0:	202b302d 	.word	0x202b302d
20026ff4:	4c6c6800 	.word	0x4c6c6800
20026ff8:	67666500 	.word	0x67666500
20026ffc:	00474645 	.word	0x00474645
20027000:	33323130 	.word	0x33323130
20027004:	37363534 	.word	0x37363534
20027008:	42413938 	.word	0x42413938
2002700c:	46454443 	.word	0x46454443
20027010:	32313000 	.word	0x32313000
20027014:	36353433 	.word	0x36353433
20027018:	61393837 	.word	0x61393837
2002701c:	65646362 	.word	0x65646362
20027020:	00000066 	.word	0x00000066
20027024:	50042000 	.word	0x50042000
20027028:	00000002 	.word	0x00000002
2002702c:	12000000 	.word	0x12000000
20027030:	00000004 	.word	0x00000004
20027034:	00000000 	.word	0x00000000
20027038:	50041000 	.word	0x50041000
2002703c:	00000002 	.word	0x00000002
20027040:	10000000 	.word	0x10000000
20027044:	00000004 	.word	0x00000004
20027048:	00000000 	.word	0x00000000
2002704c:	50043000 	.word	0x50043000
20027050:	00000002 	.word	0x00000002
20027054:	14000000 	.word	0x14000000
20027058:	00000004 	.word	0x00000004
2002705c:	00000000 	.word	0x00000000

20027060 <pad_fsel_func_tbls>:
20027060:	20027658 2002764c 20027640 20027634     Xv. Lv. @v. 4v. 
20027070:	20027628 2002761c 20027610 20027604     (v. .v. .v. .v. 
20027080:	200275f8 200275e8 200275dc 200275cc     .u. .u. .u. .u. 
20027090:	200275b8 200275b0 200275a4 20027598     .u. .u. .u. .u. 
200270a0:	2002758c 20027580 20027574 20027564     .u. .u. tu. du. 
200270b0:	20027554 20027544 20027534 20027524     Tu. Du. 4u. $u. 
200270c0:	20027514 20027500 200274f0 200274e4     .u. .u. .t. .t. 
200270d0:	200274d0 200274bc 200274a8 20027494     .t. .t. .t. .t. 
200270e0:	20027480 2002746c 20027458 20027448     .t. lt. Xt. Ht. 
200270f0:	2002743c 20027428 20027418 20027408     <t. (t. .t. .t. 
20027100:	200273f8 200273e8 200273d8 200273c8     .s. .s. .s. .s. 
20027110:	200273b8 200273a8 20027398 20027390     .s. .s. .s. .s. 
20027120:	20027380 20027370 2002735c 20027348     .s. ps. \s. Hs. 
20027130:	20027338 20027328 20027318 20027308     8s. (s. .s. .s. 
20027140:	200272fc 200272ec 200272e0 200272d4     .r. .r. .r. .r. 
20027150:	200272cc 200272c4 200272bc 200272a8     .r. .r. .r. .r. 
20027160:	20027298 20027284 20027270 20027260     .r. .r. pr. `r. 
20027170:	20027250 20027240 20027230 20027224     Pr. @r. 0r. $r. 
20027180:	20027218 2002720c 20027200 200271f4     .r. .r. .r. .q. 
20027190:	200271e8 200271e0 200271d8 200271d0     .q. .q. .q. .q. 
200271a0:	200271c8 200271c0 200271b8 200271b0     .q. .q. .q. .q. 

200271b0 <pad_pa57_fsel_func_tbl>:
200271b0:	01670000 00000000                       ..g.....

200271b8 <pad_pa56_fsel_func_tbl>:
200271b8:	01660000 00000000                       ..f.....

200271c0 <pad_pa55_fsel_func_tbl>:
200271c0:	01650000 00000000                       ..e.....

200271c8 <pad_pa54_fsel_func_tbl>:
200271c8:	01640000 00000000                       ..d.....

200271d0 <pad_pa53_fsel_func_tbl>:
200271d0:	01630000 00000000                       ..c.....

200271d8 <pad_pa52_fsel_func_tbl>:
200271d8:	01620000 00000000                       ..b.....

200271e0 <pad_pa51_fsel_func_tbl>:
200271e0:	01610000 00000000                       ..a.....

200271e8 <pad_pa50_fsel_func_tbl>:
200271e8:	01600000 01870003 00000000              ..`.........

200271f4 <pad_pa49_fsel_func_tbl>:
200271f4:	015f0000 01860003 00000000              .._.........

20027200 <pad_pa48_fsel_func_tbl>:
20027200:	015e0000 01850003 00000000              ..^.........

2002720c <pad_pa47_fsel_func_tbl>:
2002720c:	015d0000 01830003 00000000              ..].........

20027218 <pad_pa46_fsel_func_tbl>:
20027218:	015c0000 01890003 00000000              ..\.........

20027224 <pad_pa45_fsel_func_tbl>:
20027224:	015b0000 01880003 00000000              ..[.........

20027230 <pad_pa44_fsel_func_tbl>:
20027230:	015a0000 018c0001 01b70007 00000000     ..Z.............

20027240 <pad_pa43_fsel_func_tbl>:
20027240:	01590000 018b0001 01b60007 00000000     ..Y.............

20027250 <pad_pa42_fsel_func_tbl>:
20027250:	01580000 017c0002 01b50007 00000000     ..X...|.........

20027260 <pad_pa41_fsel_func_tbl>:
20027260:	01570000 017b0002 01b40007 00000000     ..W...{.........

20027270 <pad_pa40_fsel_func_tbl>:
20027270:	01560000 01750001 017a0002 01b30007     ..V...u...z.....
20027280:	00000000                                ....

20027284 <pad_pa39_fsel_func_tbl>:
20027284:	01550000 01740001 01780002 01b20007     ..U...t...x.....
20027294:	00000000                                ....

20027298 <pad_pa38_fsel_func_tbl>:
20027298:	01540000 01760001 017e0002 00000000     ..T...v...~.....

200272a8 <pad_pa37_fsel_func_tbl>:
200272a8:	01530000 01770001 017d0002 01b10007     ..S...w...}.....
200272b8:	00000000                                ....

200272bc <pad_pa36_fsel_func_tbl>:
200272bc:	01520000 00000000                       ..R.....

200272c4 <pad_pa35_fsel_func_tbl>:
200272c4:	01510000 00000000                       ..Q.....

200272cc <pad_pa34_fsel_func_tbl>:
200272cc:	01500000 00000000                       ..P.....

200272d4 <pad_pa33_fsel_func_tbl>:
200272d4:	014f0000 01870003 00000000              ..O.........

200272e0 <pad_pa32_fsel_func_tbl>:
200272e0:	014e0000 01860003 00000000              ..N.........

200272ec <pad_pa31_fsel_func_tbl>:
200272ec:	014d0000 01850003 01b00007 00000000     ..M.............

200272fc <pad_pa30_fsel_func_tbl>:
200272fc:	014c0000 01830003 00000000              ..L.........

20027308 <pad_pa29_fsel_func_tbl>:
20027308:	014b0000 01710001 01890003 00000000     ..K...q.........

20027318 <pad_pa28_fsel_func_tbl>:
20027318:	014a0000 01700001 01880003 00000000     ..J...p.........

20027328 <pad_pa27_fsel_func_tbl>:
20027328:	01490000 017c0002 01870003 00000000     ..I...|.........

20027338 <pad_pa26_fsel_func_tbl>:
20027338:	01480000 017b0002 01860003 00000000     ..H...{.........

20027348 <pad_pa25_fsel_func_tbl>:
20027348:	01470000 01720001 017a0002 01850003     ..G...r...z.....
20027358:	00000000                                ....

2002735c <pad_pa24_fsel_func_tbl>:
2002735c:	01460000 01730001 01780002 01830003     ..F...s...x.....
2002736c:	00000000                                ....

20027370 <pad_pa23_fsel_func_tbl>:
20027370:	01450000 017e0002 01890003 00000000     ..E...~.........

20027380 <pad_pa22_fsel_func_tbl>:
20027380:	01440000 017d0002 01880003 00000000     ..D...}.........

20027390 <pad_pa21_fsel_func_tbl>:
20027390:	01430000 00000000                       ..C.....

20027398 <pad_pa20_fsel_func_tbl>:
20027398:	01420000 018d0001 01b80007 00000000     ..B.............

200273a8 <pad_pa19_fsel_func_tbl>:
200273a8:	01410000 00200001 018c0002 00000000     ..A... .........

200273b8 <pad_pa18_fsel_func_tbl>:
200273b8:	01400000 00210001 018b0002 00000000     ..@...!.........

200273c8 <pad_pa17_fsel_func_tbl>:
200273c8:	013f0000 012d0001 017c0002 00000000     ..?...-...|.....

200273d8 <pad_pa16_fsel_func_tbl>:
200273d8:	013e0000 01260001 017b0002 00000000     ..>...&...{.....

200273e8 <pad_pa15_fsel_func_tbl>:
200273e8:	013d0000 012a0001 017a0002 00000000     ..=...*...z.....

200273f8 <pad_pa14_fsel_func_tbl>:
200273f8:	013c0000 012c0001 01780002 00000000     ..<...,...x.....

20027408 <pad_pa13_fsel_func_tbl>:
20027408:	013b0000 012b0001 017e0002 00000000     ..;...+...~.....

20027418 <pad_pa12_fsel_func_tbl>:
20027418:	013a0000 01270001 017d0002 00000000     ..:...'...}.....

20027428 <pad_pa11_fsel_func_tbl>:
20027428:	01390000 01280001 017c0002 018a0007     ..9...(...|.....
20027438:	00000000                                ....

2002743c <pad_pa10_fsel_func_tbl>:
2002743c:	01380000 017b0002 00000000              ..8...{.....

20027448 <pad_pa09_fsel_func_tbl>:
20027448:	01370000 017a0002 01af0007 00000000     ..7...z.........

20027458 <pad_pa08_fsel_func_tbl>:
20027458:	01360000 016d0001 01780002 01ae0007     ..6...m...x.....
20027468:	00000000                                ....

2002746c <pad_pa07_fsel_func_tbl>:
2002746c:	01350000 016c0001 017e0002 01ad0007     ..5...l...~.....
2002747c:	00000000                                ....

20027480 <pad_pa06_fsel_func_tbl>:
20027480:	01340000 016b0001 017d0002 01ac0007     ..4...k...}.....
20027490:	00000000                                ....

20027494 <pad_pa05_fsel_func_tbl>:
20027494:	01330000 016a0001 01870003 01ab0007     ..3...j.........
200274a4:	00000000                                ....

200274a8 <pad_pa04_fsel_func_tbl>:
200274a8:	01320000 01690001 01860003 01aa0007     ..2...i.........
200274b8:	00000000                                ....

200274bc <pad_pa03_fsel_func_tbl>:
200274bc:	01310000 01680001 01850003 01a90007     ..1...h.........
200274cc:	00000000                                ....

200274d0 <pad_pa02_fsel_func_tbl>:
200274d0:	01300000 016f0001 01830003 01a80007     ..0...o.........
200274e0:	00000000                                ....

200274e4 <pad_pa01_fsel_func_tbl>:
200274e4:	012f0000 01890003 00000000              ../.........

200274f0 <pad_pa00_fsel_func_tbl>:
200274f0:	012e0000 016e0001 01880003 00000000     ......n.........

20027500 <pad_sb12_fsel_func_tbl>:
20027500:	011a0001 011b0002 01180003 01160004     ................
20027510:	00000000                                ....

20027514 <pad_sb11_fsel_func_tbl>:
20027514:	01250001 01160003 01210004 00000000     ..%.......!.....

20027524 <pad_sb10_fsel_func_tbl>:
20027524:	01240001 011b0003 011e0004 00000000     ..$.............

20027534 <pad_sb09_fsel_func_tbl>:
20027534:	01230001 01250003 01260004 00000000     ..#...%...&.....

20027544 <pad_sb08_fsel_func_tbl>:
20027544:	01220001 01240003 012d0004 00000000     .."...$...-.....

20027554 <pad_sb07_fsel_func_tbl>:
20027554:	01160001 01230003 012a0004 00000000     ......#...*.....

20027564 <pad_sb06_fsel_func_tbl>:
20027564:	01170001 01220003 01180004 00000000     ......".........

20027574 <pad_sb05_fsel_func_tbl>:
20027574:	01180001 011f0004 00000000              ............

20027580 <pad_sb04_fsel_func_tbl>:
20027580:	01210001 01200004 00000000              ..!... .....

2002758c <pad_sb03_fsel_func_tbl>:
2002758c:	01200001 01270004 00000000              .. ...'.....

20027598 <pad_sb02_fsel_func_tbl>:
20027598:	011f0001 012b0004 00000000              ......+.....

200275a4 <pad_sb01_fsel_func_tbl>:
200275a4:	011e0001 012c0004 00000000              ......,.....

200275b0 <pad_sb00_fsel_func_tbl>:
200275b0:	01190001 00000000                       ........

200275b8 <pad_sa12_fsel_func_tbl>:
200275b8:	010a0001 010b0002 01080003 01020004     ................
200275c8:	00000000                                ....

200275cc <pad_sa11_fsel_func_tbl>:
200275cc:	01150001 01060003 01050004 00000000     ................

200275dc <pad_sa10_fsel_func_tbl>:
200275dc:	01140001 01000004 00000000              ............

200275e8 <pad_sa09_fsel_func_tbl>:
200275e8:	01130001 010b0003 01050004 00000000     ................

200275f8 <pad_sa08_fsel_func_tbl>:
200275f8:	01120001 01150003 00000000              ............

20027604 <pad_sa07_fsel_func_tbl>:
20027604:	01060001 01140003 00000000              ............

20027610 <pad_sa06_fsel_func_tbl>:
20027610:	01070001 01130003 00000000              ............

2002761c <pad_sa05_fsel_func_tbl>:
2002761c:	01080001 01120003 00000000              ............

20027628 <pad_sa04_fsel_func_tbl>:
20027628:	01110001 01040004 00000000              ............

20027634 <pad_sa03_fsel_func_tbl>:
20027634:	01100001 01010004 00000000              ............

20027640 <pad_sa02_fsel_func_tbl>:
20027640:	010f0001 01030004 00000000              ............

2002764c <pad_sa01_fsel_func_tbl>:
2002764c:	010e0001 01040004 00000000              ............

20027658 <pad_sa00_fsel_func_tbl>:
20027658:	01090001 01010004 00000000 00000000     ................
20027668:	04030201 00000000 01060204              ............

20027674 <hpsys_dll2_limit>:
	...
2002767c:	112a8800 112a8800                       ..*...*.

20027684 <hpsys_dvfs_config>:
20027684:	000906fb 00100330 000a08fd 00110331     ....0.......1...
20027694:	000d0b00 00130213 000f0e02 00130213     ................

200276a4 <crc32tab>:
200276a4:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
200276b4:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
200276c4:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
200276d4:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
200276e4:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
200276f4:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
20027704:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
20027714:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
20027724:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
20027734:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
20027744:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
20027754:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
20027764:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
20027774:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
20027784:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
20027794:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
200277a4:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
200277b4:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
200277c4:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
200277d4:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
200277e4:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
200277f4:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
20027804:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
20027814:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
20027824:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
20027834:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
20027844:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
20027854:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
20027864:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
20027874:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
20027884:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
20027894:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
200278a4:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
200278b4:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
200278c4:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
200278d4:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
200278e4:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
200278f4:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
20027904:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
20027914:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
20027924:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
20027934:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
20027944:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
20027954:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
20027964:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
20027974:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
20027984:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
20027994:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
200279a4:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
200279b4:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
200279c4:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
200279d4:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
200279e4:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
200279f4:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
20027a04:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
20027a14:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
20027a24:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
20027a34:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
20027a44:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
20027a54:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
20027a64:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
20027a74:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
20027a84:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
20027a94:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

20027aa4 <_init>:
20027aa4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027aa6:	bf00      	nop
20027aa8:	bcf8      	pop	{r3, r4, r5, r6, r7}
20027aaa:	bc08      	pop	{r3}
20027aac:	469e      	mov	lr, r3
20027aae:	4770      	bx	lr

20027ab0 <_fini>:
20027ab0:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027ab2:	bf00      	nop
20027ab4:	bcf8      	pop	{r3, r4, r5, r6, r7}
20027ab6:	bc08      	pop	{r3}
20027ab8:	469e      	mov	lr, r3
20027aba:	4770      	bx	lr

20027abc <__EH_FRAME_BEGIN__>:
20027abc:	0000 0000                                   ....

Disassembly of section .l1_ret_text_bsp_psram_init_info:

20027ac0 <bsp_psram_init_info>:
20027ac0:	4b04      	ldr	r3, [pc, #16]	@ (20027ad4 <bsp_psram_init_info+0x14>)
20027ac2:	4a05      	ldr	r2, [pc, #20]	@ (20027ad8 <bsp_psram_init_info+0x18>)
20027ac4:	685b      	ldr	r3, [r3, #4]
20027ac6:	2000      	movs	r0, #0
20027ac8:	f3c3 3301 	ubfx	r3, r3, #12, #2
20027acc:	7053      	strb	r3, [r2, #1]
20027ace:	2301      	movs	r3, #1
20027ad0:	7013      	strb	r3, [r2, #0]
20027ad2:	4770      	bx	lr
20027ad4:	5000b000 	.word	0x5000b000
20027ad8:	2004c998 	.word	0x2004c998

Disassembly of section .l1_ret_text_bsp_psram_get_mpi_mode:

20027adc <bsp_psram_get_mpi_mode>:
20027adc:	2801      	cmp	r0, #1
20027ade:	b508      	push	{r3, lr}
20027ae0:	d10a      	bne.n	20027af8 <bsp_psram_get_mpi_mode+0x1c>
20027ae2:	4906      	ldr	r1, [pc, #24]	@ (20027afc <bsp_psram_get_mpi_mode+0x20>)
20027ae4:	780b      	ldrb	r3, [r1, #0]
20027ae6:	b90b      	cbnz	r3, 20027aec <bsp_psram_get_mpi_mode+0x10>
20027ae8:	f7ff ffea 	bl	20027ac0 <bsp_psram_init_info>
20027aec:	784b      	ldrb	r3, [r1, #1]
20027aee:	4a04      	ldr	r2, [pc, #16]	@ (20027b00 <bsp_psram_get_mpi_mode+0x24>)
20027af0:	5cd0      	ldrb	r0, [r2, r3]
20027af2:	f000 000f 	and.w	r0, r0, #15
20027af6:	bd08      	pop	{r3, pc}
20027af8:	2000      	movs	r0, #0
20027afa:	e7fc      	b.n	20027af6 <bsp_psram_get_mpi_mode+0x1a>
20027afc:	2004c998 	.word	0x2004c998
20027b00:	20027f10 	.word	0x20027f10

Disassembly of section .l1_ret_text_bsp_psram1_pinmux_init:

20027b04 <bsp_psram1_pinmux_init>:
20027b04:	b538      	push	{r3, r4, r5, lr}
20027b06:	4998      	ldr	r1, [pc, #608]	@ (20027d68 <bsp_psram1_pinmux_init+0x264>)
20027b08:	780b      	ldrb	r3, [r1, #0]
20027b0a:	b90b      	cbnz	r3, 20027b10 <bsp_psram1_pinmux_init+0xc>
20027b0c:	f7ff ffd8 	bl	20027ac0 <bsp_psram_init_info>
20027b10:	784b      	ldrb	r3, [r1, #1]
20027b12:	4a96      	ldr	r2, [pc, #600]	@ (20027d6c <bsp_psram1_pinmux_init+0x268>)
20027b14:	5cd4      	ldrb	r4, [r2, r3]
20027b16:	0924      	lsrs	r4, r4, #4
20027b18:	2c01      	cmp	r4, #1
20027b1a:	d175      	bne.n	20027c08 <bsp_psram1_pinmux_init+0x104>
20027b1c:	4623      	mov	r3, r4
20027b1e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b22:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027b26:	2002      	movs	r0, #2
20027b28:	f7fc fcc4 	bl	200244b4 <HAL_PIN_Set>
20027b2c:	4623      	mov	r3, r4
20027b2e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b32:	f240 110f 	movw	r1, #271	@ 0x10f
20027b36:	2003      	movs	r0, #3
20027b38:	f7fc fcbc 	bl	200244b4 <HAL_PIN_Set>
20027b3c:	4623      	mov	r3, r4
20027b3e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b42:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027b46:	2004      	movs	r0, #4
20027b48:	f7fc fcb4 	bl	200244b4 <HAL_PIN_Set>
20027b4c:	4623      	mov	r3, r4
20027b4e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b52:	f240 1111 	movw	r1, #273	@ 0x111
20027b56:	2005      	movs	r0, #5
20027b58:	f7fc fcac 	bl	200244b4 <HAL_PIN_Set>
20027b5c:	4623      	mov	r3, r4
20027b5e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b62:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027b66:	2009      	movs	r0, #9
20027b68:	f7fc fca4 	bl	200244b4 <HAL_PIN_Set>
20027b6c:	4623      	mov	r3, r4
20027b6e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b72:	f240 1113 	movw	r1, #275	@ 0x113
20027b76:	200a      	movs	r0, #10
20027b78:	f7fc fc9c 	bl	200244b4 <HAL_PIN_Set>
20027b7c:	4623      	mov	r3, r4
20027b7e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b82:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027b86:	200b      	movs	r0, #11
20027b88:	f7fc fc94 	bl	200244b4 <HAL_PIN_Set>
20027b8c:	4623      	mov	r3, r4
20027b8e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b92:	f240 1115 	movw	r1, #277	@ 0x115
20027b96:	200c      	movs	r0, #12
20027b98:	f7fc fc8c 	bl	200244b4 <HAL_PIN_Set>
20027b9c:	4623      	mov	r3, r4
20027b9e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027ba2:	f240 1109 	movw	r1, #265	@ 0x109
20027ba6:	4620      	mov	r0, r4
20027ba8:	f7fc fc84 	bl	200244b4 <HAL_PIN_Set>
20027bac:	4623      	mov	r3, r4
20027bae:	2200      	movs	r2, #0
20027bb0:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027bb4:	2006      	movs	r0, #6
20027bb6:	f7fc fc7d 	bl	200244b4 <HAL_PIN_Set>
20027bba:	4623      	mov	r3, r4
20027bbc:	2200      	movs	r2, #0
20027bbe:	f240 1107 	movw	r1, #263	@ 0x107
20027bc2:	2007      	movs	r0, #7
20027bc4:	f7fc fc76 	bl	200244b4 <HAL_PIN_Set>
20027bc8:	4623      	mov	r3, r4
20027bca:	2200      	movs	r2, #0
20027bcc:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027bd0:	2008      	movs	r0, #8
20027bd2:	f7fc fc6f 	bl	200244b4 <HAL_PIN_Set>
20027bd6:	4623      	mov	r3, r4
20027bd8:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bdc:	f44f 7185 	mov.w	r1, #266	@ 0x10a
20027be0:	200d      	movs	r0, #13
20027be2:	f7fc fc67 	bl	200244b4 <HAL_PIN_Set>
20027be6:	2500      	movs	r5, #0
20027be8:	2400      	movs	r4, #0
20027bea:	2201      	movs	r2, #1
20027bec:	3401      	adds	r4, #1
20027bee:	4611      	mov	r1, r2
20027bf0:	4620      	mov	r0, r4
20027bf2:	f7fc fc8f 	bl	20024514 <HAL_PIN_Set_DS0>
20027bf6:	2200      	movs	r2, #0
20027bf8:	2101      	movs	r1, #1
20027bfa:	4620      	mov	r0, r4
20027bfc:	f7fc fca0 	bl	20024540 <HAL_PIN_Set_DS1>
20027c00:	2c0d      	cmp	r4, #13
20027c02:	d1f2      	bne.n	20027bea <bsp_psram1_pinmux_init+0xe6>
20027c04:	4628      	mov	r0, r5
20027c06:	bd38      	pop	{r3, r4, r5, pc}
20027c08:	2c02      	cmp	r4, #2
20027c0a:	d153      	bne.n	20027cb4 <bsp_psram1_pinmux_init+0x1b0>
20027c0c:	2301      	movs	r3, #1
20027c0e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c12:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027c16:	4620      	mov	r0, r4
20027c18:	f7fc fc4c 	bl	200244b4 <HAL_PIN_Set>
20027c1c:	2301      	movs	r3, #1
20027c1e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c22:	f240 110f 	movw	r1, #271	@ 0x10f
20027c26:	2003      	movs	r0, #3
20027c28:	f7fc fc44 	bl	200244b4 <HAL_PIN_Set>
20027c2c:	2301      	movs	r3, #1
20027c2e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c32:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027c36:	2004      	movs	r0, #4
20027c38:	f7fc fc3c 	bl	200244b4 <HAL_PIN_Set>
20027c3c:	2301      	movs	r3, #1
20027c3e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c42:	f240 1111 	movw	r1, #273	@ 0x111
20027c46:	2005      	movs	r0, #5
20027c48:	f7fc fc34 	bl	200244b4 <HAL_PIN_Set>
20027c4c:	2301      	movs	r3, #1
20027c4e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c52:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027c56:	2009      	movs	r0, #9
20027c58:	f7fc fc2c 	bl	200244b4 <HAL_PIN_Set>
20027c5c:	2301      	movs	r3, #1
20027c5e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c62:	f240 1113 	movw	r1, #275	@ 0x113
20027c66:	200a      	movs	r0, #10
20027c68:	f7fc fc24 	bl	200244b4 <HAL_PIN_Set>
20027c6c:	2301      	movs	r3, #1
20027c6e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c72:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027c76:	200b      	movs	r0, #11
20027c78:	f7fc fc1c 	bl	200244b4 <HAL_PIN_Set>
20027c7c:	2301      	movs	r3, #1
20027c7e:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c82:	f240 1115 	movw	r1, #277	@ 0x115
20027c86:	200c      	movs	r0, #12
20027c88:	f7fc fc14 	bl	200244b4 <HAL_PIN_Set>
20027c8c:	2301      	movs	r3, #1
20027c8e:	2200      	movs	r2, #0
20027c90:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027c94:	2006      	movs	r0, #6
20027c96:	f7fc fc0d 	bl	200244b4 <HAL_PIN_Set>
20027c9a:	2301      	movs	r3, #1
20027c9c:	2200      	movs	r2, #0
20027c9e:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027ca2:	2008      	movs	r0, #8
20027ca4:	f7fc fc06 	bl	200244b4 <HAL_PIN_Set>
20027ca8:	2301      	movs	r3, #1
20027caa:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cae:	f240 110b 	movw	r1, #267	@ 0x10b
20027cb2:	e795      	b.n	20027be0 <bsp_psram1_pinmux_init+0xdc>
20027cb4:	2c03      	cmp	r4, #3
20027cb6:	d154      	bne.n	20027d62 <bsp_psram1_pinmux_init+0x25e>
20027cb8:	2301      	movs	r3, #1
20027cba:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cbe:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027cc2:	2002      	movs	r0, #2
20027cc4:	f7fc fbf6 	bl	200244b4 <HAL_PIN_Set>
20027cc8:	2301      	movs	r3, #1
20027cca:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cce:	f240 110f 	movw	r1, #271	@ 0x10f
20027cd2:	4620      	mov	r0, r4
20027cd4:	f7fc fbee 	bl	200244b4 <HAL_PIN_Set>
20027cd8:	2301      	movs	r3, #1
20027cda:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cde:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027ce2:	2004      	movs	r0, #4
20027ce4:	f7fc fbe6 	bl	200244b4 <HAL_PIN_Set>
20027ce8:	2301      	movs	r3, #1
20027cea:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cee:	f240 1111 	movw	r1, #273	@ 0x111
20027cf2:	2005      	movs	r0, #5
20027cf4:	f7fc fbde 	bl	200244b4 <HAL_PIN_Set>
20027cf8:	2301      	movs	r3, #1
20027cfa:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cfe:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027d02:	2006      	movs	r0, #6
20027d04:	f7fc fbd6 	bl	200244b4 <HAL_PIN_Set>
20027d08:	2301      	movs	r3, #1
20027d0a:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027d0e:	f240 1113 	movw	r1, #275	@ 0x113
20027d12:	2007      	movs	r0, #7
20027d14:	f7fc fbce 	bl	200244b4 <HAL_PIN_Set>
20027d18:	2301      	movs	r3, #1
20027d1a:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027d1e:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027d22:	2008      	movs	r0, #8
20027d24:	f7fc fbc6 	bl	200244b4 <HAL_PIN_Set>
20027d28:	2301      	movs	r3, #1
20027d2a:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027d2e:	f240 1115 	movw	r1, #277	@ 0x115
20027d32:	2009      	movs	r0, #9
20027d34:	f7fc fbbe 	bl	200244b4 <HAL_PIN_Set>
20027d38:	2301      	movs	r3, #1
20027d3a:	2200      	movs	r2, #0
20027d3c:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027d40:	200d      	movs	r0, #13
20027d42:	f7fc fbb7 	bl	200244b4 <HAL_PIN_Set>
20027d46:	2301      	movs	r3, #1
20027d48:	2200      	movs	r2, #0
20027d4a:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027d4e:	200c      	movs	r0, #12
20027d50:	f7fc fbb0 	bl	200244b4 <HAL_PIN_Set>
20027d54:	2301      	movs	r3, #1
20027d56:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027d5a:	f240 110b 	movw	r1, #267	@ 0x10b
20027d5e:	200a      	movs	r0, #10
20027d60:	e73f      	b.n	20027be2 <bsp_psram1_pinmux_init+0xde>
20027d62:	f04f 35ff 	mov.w	r5, #4294967295
20027d66:	e73f      	b.n	20027be8 <bsp_psram1_pinmux_init+0xe4>
20027d68:	2004c998 	.word	0x2004c998
20027d6c:	20027f10 	.word	0x20027f10

Disassembly of section .l1_ret_text_HAL_EFUSE_Extract:

20027d70 <HAL_EFUSE_Extract>:
20027d70:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20027d74:	2800      	cmp	r0, #0
20027d76:	d041      	beq.n	20027dfc <HAL_EFUSE_Extract+0x8c>
20027d78:	2a00      	cmp	r2, #0
20027d7a:	d03f      	beq.n	20027dfc <HAL_EFUSE_Extract+0x8c>
20027d7c:	18cc      	adds	r4, r1, r3
20027d7e:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20027d82:	dc3b      	bgt.n	20027dfc <HAL_EFUSE_Extract+0x8c>
20027d84:	2400      	movs	r4, #0
20027d86:	46a4      	mov	ip, r4
20027d88:	094e      	lsrs	r6, r1, #5
20027d8a:	1ddd      	adds	r5, r3, #7
20027d8c:	f850 7026 	ldr.w	r7, [r0, r6, lsl #2]
20027d90:	f001 011f 	and.w	r1, r1, #31
20027d94:	f3c5 05cf 	ubfx	r5, r5, #3, #16
20027d98:	42a5      	cmp	r5, r4
20027d9a:	d807      	bhi.n	20027dac <HAL_EFUSE_Extract+0x3c>
20027d9c:	2400      	movs	r4, #0
20027d9e:	46a6      	mov	lr, r4
20027da0:	46a4      	mov	ip, r4
20027da2:	459c      	cmp	ip, r3
20027da4:	d106      	bne.n	20027db4 <HAL_EFUSE_Extract+0x44>
20027da6:	4618      	mov	r0, r3
20027da8:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027dac:	f802 c004 	strb.w	ip, [r2, r4]
20027db0:	3401      	adds	r4, #1
20027db2:	e7f1      	b.n	20027d98 <HAL_EFUSE_Extract+0x28>
20027db4:	fa27 f501 	lsr.w	r5, r7, r1
20027db8:	3101      	adds	r1, #1
20027dba:	f812 800e 	ldrb.w	r8, [r2, lr]
20027dbe:	b289      	uxth	r1, r1
20027dc0:	f005 0501 	and.w	r5, r5, #1
20027dc4:	2920      	cmp	r1, #32
20027dc6:	fa05 f504 	lsl.w	r5, r5, r4
20027dca:	bf08      	it	eq
20027dcc:	3601      	addeq	r6, #1
20027dce:	ea45 0508 	orr.w	r5, r5, r8
20027dd2:	f104 0401 	add.w	r4, r4, #1
20027dd6:	b2a4      	uxth	r4, r4
20027dd8:	f802 500e 	strb.w	r5, [r2, lr]
20027ddc:	bf02      	ittt	eq
20027dde:	b2b6      	uxtheq	r6, r6
20027de0:	2100      	moveq	r1, #0
20027de2:	f850 7026 	ldreq.w	r7, [r0, r6, lsl #2]
20027de6:	2c08      	cmp	r4, #8
20027de8:	bf04      	itt	eq
20027dea:	f10e 0401 	addeq.w	r4, lr, #1
20027dee:	fa1f fe84 	uxtheq.w	lr, r4
20027df2:	f10c 0c01 	add.w	ip, ip, #1
20027df6:	bf08      	it	eq
20027df8:	2400      	moveq	r4, #0
20027dfa:	e7d2      	b.n	20027da2 <HAL_EFUSE_Extract+0x32>
20027dfc:	2300      	movs	r3, #0
20027dfe:	e7d2      	b.n	20027da6 <HAL_EFUSE_Extract+0x36>

Disassembly of section .l1_ret_text_HAL_Set_backup:

20027e00 <HAL_Set_backup>:
20027e00:	4b01      	ldr	r3, [pc, #4]	@ (20027e08 <HAL_Set_backup+0x8>)
20027e02:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
20027e06:	4770      	bx	lr
20027e08:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

20027e0c <HAL_Get_backup>:
20027e0c:	4b01      	ldr	r3, [pc, #4]	@ (20027e14 <HAL_Get_backup+0x8>)
20027e0e:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
20027e12:	4770      	bx	lr
20027e14:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_SET_HXT_CBANK:

20027e18 <HAL_PMU_SET_HXT_CBANK>:
20027e18:	4a02      	ldr	r2, [pc, #8]	@ (20027e24 <HAL_PMU_SET_HXT_CBANK+0xc>)
20027e1a:	6ed3      	ldr	r3, [r2, #108]	@ 0x6c
20027e1c:	f360 531d 	bfi	r3, r0, #20, #10
20027e20:	66d3      	str	r3, [r2, #108]	@ 0x6c
20027e22:	4770      	bx	lr
20027e24:	500ca000 	.word	0x500ca000

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

20027e28 <HAL_PMU_GetHpsysVoutRef>:
20027e28:	4b04      	ldr	r3, [pc, #16]	@ (20027e3c <HAL_PMU_GetHpsysVoutRef+0x14>)
20027e2a:	781a      	ldrb	r2, [r3, #0]
20027e2c:	b122      	cbz	r2, 20027e38 <HAL_PMU_GetHpsysVoutRef+0x10>
20027e2e:	b118      	cbz	r0, 20027e38 <HAL_PMU_GetHpsysVoutRef+0x10>
20027e30:	78db      	ldrb	r3, [r3, #3]
20027e32:	7003      	strb	r3, [r0, #0]
20027e34:	2000      	movs	r0, #0
20027e36:	4770      	bx	lr
20027e38:	2001      	movs	r0, #1
20027e3a:	4770      	bx	lr
20027e3c:	2004ca64 	.word	0x2004ca64

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

20027e40 <HAL_PMU_GetHpsysVoutRef2>:
20027e40:	4b04      	ldr	r3, [pc, #16]	@ (20027e54 <HAL_PMU_GetHpsysVoutRef2+0x14>)
20027e42:	781a      	ldrb	r2, [r3, #0]
20027e44:	b122      	cbz	r2, 20027e50 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027e46:	b118      	cbz	r0, 20027e50 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027e48:	7b5b      	ldrb	r3, [r3, #13]
20027e4a:	7003      	strb	r3, [r0, #0]
20027e4c:	2000      	movs	r0, #0
20027e4e:	4770      	bx	lr
20027e50:	2001      	movs	r0, #1
20027e52:	4770      	bx	lr
20027e54:	2004ca64 	.word	0x2004ca64

Disassembly of section .l1_ret_text_HAL_PMU_ConfigPeriLdo:

20027e58 <HAL_PMU_ConfigPeriLdo>:
20027e58:	2810      	cmp	r0, #16
20027e5a:	b510      	push	{r4, lr}
20027e5c:	d823      	bhi.n	20027ea6 <HAL_PMU_ConfigPeriLdo+0x4e>
20027e5e:	4b13      	ldr	r3, [pc, #76]	@ (20027eac <HAL_PMU_ConfigPeriLdo+0x54>)
20027e60:	40c3      	lsrs	r3, r0
20027e62:	07db      	lsls	r3, r3, #31
20027e64:	d51f      	bpl.n	20027ea6 <HAL_PMU_ConfigPeriLdo+0x4e>
20027e66:	2900      	cmp	r1, #0
20027e68:	bf0c      	ite	eq
20027e6a:	2104      	moveq	r1, #4
20027e6c:	2101      	movne	r1, #1
20027e6e:	4081      	lsls	r1, r0
20027e70:	b158      	cbz	r0, 20027e8a <HAL_PMU_ConfigPeriLdo+0x32>
20027e72:	2305      	movs	r3, #5
20027e74:	fa03 f000 	lsl.w	r0, r3, r0
20027e78:	4c0d      	ldr	r4, [pc, #52]	@ (20027eb0 <HAL_PMU_ConfigPeriLdo+0x58>)
20027e7a:	6e23      	ldr	r3, [r4, #96]	@ 0x60
20027e7c:	ea23 0300 	bic.w	r3, r3, r0
20027e80:	430b      	orrs	r3, r1
20027e82:	6623      	str	r3, [r4, #96]	@ 0x60
20027e84:	b952      	cbnz	r2, 20027e9c <HAL_PMU_ConfigPeriLdo+0x44>
20027e86:	2000      	movs	r0, #0
20027e88:	bd10      	pop	{r4, pc}
20027e8a:	4b0a      	ldr	r3, [pc, #40]	@ (20027eb4 <HAL_PMU_ConfigPeriLdo+0x5c>)
20027e8c:	781b      	ldrb	r3, [r3, #0]
20027e8e:	b91b      	cbnz	r3, 20027e98 <HAL_PMU_ConfigPeriLdo+0x40>
20027e90:	207d      	movs	r0, #125	@ 0x7d
20027e92:	f041 0170 	orr.w	r1, r1, #112	@ 0x70
20027e96:	e7ef      	b.n	20027e78 <HAL_PMU_ConfigPeriLdo+0x20>
20027e98:	2005      	movs	r0, #5
20027e9a:	e7ed      	b.n	20027e78 <HAL_PMU_ConfigPeriLdo+0x20>
20027e9c:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
20027ea0:	f7f9 fda7 	bl	200219f2 <HAL_Delay_us>
20027ea4:	e7ef      	b.n	20027e86 <HAL_PMU_ConfigPeriLdo+0x2e>
20027ea6:	2001      	movs	r0, #1
20027ea8:	e7ee      	b.n	20027e88 <HAL_PMU_ConfigPeriLdo+0x30>
20027eaa:	bf00      	nop
20027eac:	00010101 	.word	0x00010101
20027eb0:	500ca000 	.word	0x500ca000
20027eb4:	2004ca64 	.word	0x2004ca64

Disassembly of section .l1_ret_text_BSP_HxtCbank_Config:

20027eb8 <BSP_HxtCbank_Config>:
20027eb8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027eba:	4607      	mov	r7, r0
20027ebc:	2000      	movs	r0, #0
20027ebe:	f7fc fbe3 	bl	20024688 <HAL_RCC_HCPU_GetClockSrc>
20027ec2:	2100      	movs	r1, #0
20027ec4:	4604      	mov	r4, r0
20027ec6:	4608      	mov	r0, r1
20027ec8:	f7fc fca4 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20027ecc:	f7fc fc0e 	bl	200246ec <HAL_RCC_HCPU_GetDLL1Freq>
20027ed0:	4606      	mov	r6, r0
20027ed2:	f7fc fc1d 	bl	20024710 <HAL_RCC_HCPU_GetDLL2Freq>
20027ed6:	4605      	mov	r5, r0
20027ed8:	4638      	mov	r0, r7
20027eda:	f7ff ff9d 	bl	20027e18 <HAL_PMU_SET_HXT_CBANK>
20027ede:	2000      	movs	r0, #0
20027ee0:	f7f9 fd87 	bl	200219f2 <HAL_Delay_us>
20027ee4:	2028      	movs	r0, #40	@ 0x28
20027ee6:	f7f9 fd84 	bl	200219f2 <HAL_Delay_us>
20027eea:	f7fc fc5f 	bl	200247ac <HAL_RCC_HCPU_DisableDLL1>
20027eee:	f7fc fc65 	bl	200247bc <HAL_RCC_HCPU_DisableDLL2>
20027ef2:	4630      	mov	r0, r6
20027ef4:	f7fc fc52 	bl	2002479c <HAL_RCC_HCPU_EnableDLL1>
20027ef8:	4628      	mov	r0, r5
20027efa:	f7fc fc53 	bl	200247a4 <HAL_RCC_HCPU_EnableDLL2>
20027efe:	4621      	mov	r1, r4
20027f00:	2000      	movs	r0, #0
20027f02:	f7fc fc87 	bl	20024814 <HAL_RCC_HCPU_ClockSelect>
20027f06:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
20027f0a:	2000      	movs	r0, #0
20027f0c:	f7f9 bd71 	b.w	200219f2 <HAL_Delay_us>
