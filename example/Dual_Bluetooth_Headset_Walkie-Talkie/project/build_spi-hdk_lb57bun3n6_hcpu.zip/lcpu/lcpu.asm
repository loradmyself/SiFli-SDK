
build_spi-hdk_lb57bun3n6_hcpu\lcpu\lcpu.elf:     file format elf32-littlearm


Disassembly of section .text:

00400000 <deregister_tm_clones-0x100>:
  400000:	20400670 	.word	0x20400670
  400004:	00000115 	.word	0x00000115
  400008:	00002c6d 	.word	0x00002c6d
  40000c:	00000251 	.word	0x00000251
  400010:	0000028d 	.word	0x0000028d
  400014:	00000129 	.word	0x00000129
  400018:	0000012b 	.word	0x0000012b
  40001c:	0000012d 	.word	0x0000012d
	...
  40002c:	0000012f 	.word	0x0000012f
  400030:	00000131 	.word	0x00000131
  400034:	00000000 	.word	0x00000000
  400038:	000001b5 	.word	0x000001b5
  40003c:	00002ee9 	.word	0x00002ee9
  400040:	00000e2d 	.word	0x00000e2d
  400044:	00004f05 	.word	0x00004f05
  400048:	0000013b 	.word	0x0000013b
  40004c:	0000013d 	.word	0x0000013d
  400050:	0000013f 	.word	0x0000013f
  400054:	00000141 	.word	0x00000141
  400058:	00000143 	.word	0x00000143
  40005c:	00000145 	.word	0x00000145
  400060:	00000147 	.word	0x00000147
  400064:	00000149 	.word	0x00000149
  400068:	0000014b 	.word	0x0000014b
  40006c:	00006d89 	.word	0x00006d89
  400070:	0000014f 	.word	0x0000014f
  400074:	00000151 	.word	0x00000151
  400078:	00000153 	.word	0x00000153
  40007c:	000057c9 	.word	0x000057c9
  400080:	00000157 	.word	0x00000157
  400084:	00000159 	.word	0x00000159
  400088:	00002d09 	.word	0x00002d09
  40008c:	0000015d 	.word	0x0000015d
  400090:	0000015f 	.word	0x0000015f
  400094:	00000161 	.word	0x00000161
  400098:	00000163 	.word	0x00000163
  40009c:	00001d3d 	.word	0x00001d3d
  4000a0:	004001db 	.word	0x004001db
  4000a4:	00000169 	.word	0x00000169
  4000a8:	0000016b 	.word	0x0000016b
  4000ac:	0000016d 	.word	0x0000016d
  4000b0:	0000016f 	.word	0x0000016f
  4000b4:	00000171 	.word	0x00000171
  4000b8:	00000173 	.word	0x00000173
  4000bc:	00000175 	.word	0x00000175
	...

00400100 <deregister_tm_clones>:
  400100:	4803      	ldr	r0, [pc, #12]	@ (400110 <deregister_tm_clones+0x10>)
  400102:	4b04      	ldr	r3, [pc, #16]	@ (400114 <deregister_tm_clones+0x14>)
  400104:	4283      	cmp	r3, r0
  400106:	d002      	beq.n	40010e <deregister_tm_clones+0xe>
  400108:	4b03      	ldr	r3, [pc, #12]	@ (400118 <deregister_tm_clones+0x18>)
  40010a:	b103      	cbz	r3, 40010e <deregister_tm_clones+0xe>
  40010c:	4718      	bx	r3
  40010e:	4770      	bx	lr
  400110:	20400270 	.word	0x20400270
  400114:	20400270 	.word	0x20400270
  400118:	00000000 	.word	0x00000000

0040011c <register_tm_clones>:
  40011c:	4b06      	ldr	r3, [pc, #24]	@ (400138 <register_tm_clones+0x1c>)
  40011e:	4907      	ldr	r1, [pc, #28]	@ (40013c <register_tm_clones+0x20>)
  400120:	1ac9      	subs	r1, r1, r3
  400122:	1089      	asrs	r1, r1, #2
  400124:	bf48      	it	mi
  400126:	3101      	addmi	r1, #1
  400128:	1049      	asrs	r1, r1, #1
  40012a:	d003      	beq.n	400134 <register_tm_clones+0x18>
  40012c:	4b04      	ldr	r3, [pc, #16]	@ (400140 <register_tm_clones+0x24>)
  40012e:	b10b      	cbz	r3, 400134 <register_tm_clones+0x18>
  400130:	4801      	ldr	r0, [pc, #4]	@ (400138 <register_tm_clones+0x1c>)
  400132:	4718      	bx	r3
  400134:	4770      	bx	lr
  400136:	bf00      	nop
  400138:	20400270 	.word	0x20400270
  40013c:	20400270 	.word	0x20400270
  400140:	00000000 	.word	0x00000000

00400144 <__do_global_dtors_aux>:
  400144:	b510      	push	{r4, lr}
  400146:	4c06      	ldr	r4, [pc, #24]	@ (400160 <__do_global_dtors_aux+0x1c>)
  400148:	7823      	ldrb	r3, [r4, #0]
  40014a:	b943      	cbnz	r3, 40015e <__do_global_dtors_aux+0x1a>
  40014c:	f7ff ffd8 	bl	400100 <deregister_tm_clones>
  400150:	4b04      	ldr	r3, [pc, #16]	@ (400164 <__do_global_dtors_aux+0x20>)
  400152:	b113      	cbz	r3, 40015a <__do_global_dtors_aux+0x16>
  400154:	4804      	ldr	r0, [pc, #16]	@ (400168 <__do_global_dtors_aux+0x24>)
  400156:	f3af 8000 	nop.w
  40015a:	2301      	movs	r3, #1
  40015c:	7023      	strb	r3, [r4, #0]
  40015e:	bd10      	pop	{r4, pc}
  400160:	20400670 	.word	0x20400670
  400164:	00000000 	.word	0x00000000
  400168:	0040024c 	.word	0x0040024c

0040016c <frame_dummy>:
  40016c:	b508      	push	{r3, lr}
  40016e:	4b05      	ldr	r3, [pc, #20]	@ (400184 <frame_dummy+0x18>)
  400170:	b11b      	cbz	r3, 40017a <frame_dummy+0xe>
  400172:	4905      	ldr	r1, [pc, #20]	@ (400188 <frame_dummy+0x1c>)
  400174:	4805      	ldr	r0, [pc, #20]	@ (40018c <frame_dummy+0x20>)
  400176:	f3af 8000 	nop.w
  40017a:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
  40017e:	f7ff bfcd 	b.w	40011c <register_tm_clones>
  400182:	bf00      	nop
  400184:	00000000 	.word	0x00000000
  400188:	20400674 	.word	0x20400674
  40018c:	0040024c 	.word	0x0040024c
  400190:	f8df d048 	ldr.w	sp, [pc, #72]	@ 4001dc <ACPU2LCPU_IRQHandler+0x2>
  400194:	4812      	ldr	r0, [pc, #72]	@ (4001e0 <ACPU2LCPU_IRQHandler+0x6>)
  400196:	f380 880a 	msr	MSPLIM, r0
  40019a:	f402 fed5 	bl	2f48 <SystemInit>
  40019e:	4c11      	ldr	r4, [pc, #68]	@ (4001e4 <ACPU2LCPU_IRQHandler+0xa>)
  4001a0:	4d11      	ldr	r5, [pc, #68]	@ (4001e8 <ACPU2LCPU_IRQHandler+0xe>)
  4001a2:	42ac      	cmp	r4, r5
  4001a4:	da09      	bge.n	4001ba <frame_dummy+0x4e>
  4001a6:	6821      	ldr	r1, [r4, #0]
  4001a8:	6862      	ldr	r2, [r4, #4]
  4001aa:	68a3      	ldr	r3, [r4, #8]
  4001ac:	3b04      	subs	r3, #4
  4001ae:	bfa2      	ittt	ge
  4001b0:	58c8      	ldrge	r0, [r1, r3]
  4001b2:	50d0      	strge	r0, [r2, r3]
  4001b4:	e7fa      	bge.n	4001ac <frame_dummy+0x40>
  4001b6:	340c      	adds	r4, #12
  4001b8:	e7f3      	b.n	4001a2 <frame_dummy+0x36>
  4001ba:	4b0c      	ldr	r3, [pc, #48]	@ (4001ec <ACPU2LCPU_IRQHandler+0x12>)
  4001bc:	4c0c      	ldr	r4, [pc, #48]	@ (4001f0 <ACPU2LCPU_IRQHandler+0x16>)
  4001be:	42a3      	cmp	r3, r4
  4001c0:	da08      	bge.n	4001d4 <frame_dummy+0x68>
  4001c2:	6819      	ldr	r1, [r3, #0]
  4001c4:	685a      	ldr	r2, [r3, #4]
  4001c6:	2000      	movs	r0, #0
  4001c8:	3a04      	subs	r2, #4
  4001ca:	bfa4      	itt	ge
  4001cc:	5088      	strge	r0, [r1, r2]
  4001ce:	e7fb      	bge.n	4001c8 <frame_dummy+0x5c>
  4001d0:	3308      	adds	r3, #8
  4001d2:	e7f4      	b.n	4001be <frame_dummy+0x52>
  4001d4:	f000 f819 	bl	40020a <entry>
  4001d8:	e7fe      	b.n	4001d8 <frame_dummy+0x6c>

004001da <ACPU2LCPU_IRQHandler>:
  4001da:	e7fe      	b.n	4001da <ACPU2LCPU_IRQHandler>
  4001dc:	20400670 	.word	0x20400670
  4001e0:	20400270 	.word	0x20400270
  4001e4:	00400260 	.word	0x00400260
  4001e8:	00400260 	.word	0x00400260
  4001ec:	00400260 	.word	0x00400260
  4001f0:	00400268 	.word	0x00400268

004001f4 <__aeabi_unwind_cpp_pr0>:
  4001f4:	2000      	movs	r0, #0
  4001f6:	4770      	bx	lr

004001f8 <rti_start>:
  4001f8:	2000      	movs	r0, #0
  4001fa:	4770      	bx	lr

004001fc <rti_board_start>:
  4001fc:	2000      	movs	r0, #0
  4001fe:	4770      	bx	lr

00400200 <rti_board_end>:
  400200:	2000      	movs	r0, #0
  400202:	4770      	bx	lr

00400204 <rti_end>:
  400204:	2000      	movs	r0, #0
  400206:	4770      	bx	lr

00400208 <pre_main>:
  400208:	4770      	bx	lr

0040020a <entry>:
  40020a:	b508      	push	{r3, lr}
  40020c:	f7ff fffc 	bl	400208 <pre_main>
  400210:	f456 fb36 	bl	56880 <rtthread_startup>
  400214:	2000      	movs	r0, #0
  400216:	bd08      	pop	{r3, pc}

00400218 <_init>:
  400218:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
  40021a:	bf00      	nop
  40021c:	bcf8      	pop	{r3, r4, r5, r6, r7}
  40021e:	bc08      	pop	{r3}
  400220:	469e      	mov	lr, r3
  400222:	4770      	bx	lr

00400224 <_fini>:
  400224:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
  400226:	bf00      	nop
  400228:	bcf8      	pop	{r3, r4, r5, r6, r7}
  40022a:	bc08      	pop	{r3}
  40022c:	469e      	mov	lr, r3
  40022e:	4770      	bx	lr

00400230 <__fsymtab_end>:
  400230:	004001f9 	.word	0x004001f9
  400234:	004001fd 	.word	0x004001fd
  400238:	00400201 	.word	0x00400201
  40023c:	0002b745 	.word	0x0002b745
  400240:	00005485 	.word	0x00005485
  400244:	0005aaa1 	.word	0x0005aaa1
  400248:	00400205 	.word	0x00400205

0040024c <__EH_FRAME_BEGIN__>:
  40024c:	00000000                                ....
