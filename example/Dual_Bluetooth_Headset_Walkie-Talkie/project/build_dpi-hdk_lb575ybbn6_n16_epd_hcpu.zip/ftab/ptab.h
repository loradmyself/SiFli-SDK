#ifndef __PTAB__H__
#define __PTAB__H__




/* flash3 */
#undef  FLASH_TABLE_START_ADDR
#define FLASH_TABLE_START_ADDR                             (0x14000000)
#undef  FLASH_TABLE_SIZE
#define FLASH_TABLE_SIZE                                   (0x00008000)
#undef  FLASH_TABLE_OFFSET
#define FLASH_TABLE_OFFSET                                 (0x00000000)
#undef  APP_FTAB_CODE_START_ADDR
#define APP_FTAB_CODE_START_ADDR                           (0x14000000)
#undef  APP_FTAB_CODE_SIZE
#define APP_FTAB_CODE_SIZE                                 (0x00008000)
#undef  APP_FTAB_CODE_OFFSET
#define APP_FTAB_CODE_OFFSET                               (0x00000000)
#define CODE_START_ADDR                                    (APP_FTAB_CODE_START_ADDR)
#define CODE_SIZE                                          (APP_FTAB_CODE_SIZE)
#undef  HCPU_FLASH_CODE_START_ADDR
#define HCPU_FLASH_CODE_START_ADDR                         (0x14020000)
#undef  HCPU_FLASH_CODE_SIZE
#define HCPU_FLASH_CODE_SIZE                               (0x00700000)
#undef  HCPU_FLASH_CODE_OFFSET
#define HCPU_FLASH_CODE_OFFSET                             (0x00020000)
#undef  APP_MAIN_CODE_START_ADDR
#define APP_MAIN_CODE_START_ADDR                           (0x14020000)
#undef  APP_MAIN_CODE_SIZE
#define APP_MAIN_CODE_SIZE                                 (0x00700000)
#undef  APP_MAIN_CODE_OFFSET
#define APP_MAIN_CODE_OFFSET                               (0x00020000)
#undef  APP_ACPU_CODE_START_ADDR
#define APP_ACPU_CODE_START_ADDR                           (0x14720000)
#undef  APP_ACPU_CODE_SIZE
#define APP_ACPU_CODE_SIZE                                 (0x00040000)
#undef  APP_ACPU_CODE_OFFSET
#define APP_ACPU_CODE_OFFSET                               (0x00720000)
#undef  ACPU_CODE_REGION1_START_ADDR
#define ACPU_CODE_REGION1_START_ADDR                       (0x14720000)
#undef  ACPU_CODE_REGION1_SIZE
#define ACPU_CODE_REGION1_SIZE                             (0x00040000)
#undef  ACPU_CODE_REGION1_OFFSET
#define ACPU_CODE_REGION1_OFFSET                           (0x00720000)
#undef  DFU_FLASH_CODE_START_ADDR
#define DFU_FLASH_CODE_START_ADDR                          (0x14760000)
#undef  DFU_FLASH_CODE_SIZE
#define DFU_FLASH_CODE_SIZE                                (0x00060000)
#undef  DFU_FLASH_CODE_OFFSET
#define DFU_FLASH_CODE_OFFSET                              (0x00760000)
#undef  APP_DFU_CODE_START_ADDR
#define APP_DFU_CODE_START_ADDR                            (0x14760000)
#undef  APP_DFU_CODE_SIZE
#define APP_DFU_CODE_SIZE                                  (0x00060000)
#undef  APP_DFU_CODE_OFFSET
#define APP_DFU_CODE_OFFSET                                (0x00760000)
#undef  DFU_DOWNLOAD_REGION_START_ADDR
#define DFU_DOWNLOAD_REGION_START_ADDR                     (0x147C0000)
#undef  DFU_DOWNLOAD_REGION_SIZE
#define DFU_DOWNLOAD_REGION_SIZE                           (0x00120000)
#undef  DFU_DOWNLOAD_REGION_OFFSET
#define DFU_DOWNLOAD_REGION_OFFSET                         (0x007C0000)
#undef  FS_REGION_START_ADDR
#define FS_REGION_START_ADDR                               (0x148E0000)
#undef  FS_REGION_SIZE
#define FS_REGION_SIZE                                     (0x00400000)
#undef  FS_REGION_OFFSET
#define FS_REGION_OFFSET                                   (0x008E0000)
#undef  KVDB_DFU_REGION_START_ADDR
#define KVDB_DFU_REGION_START_ADDR                         (0x14CE0000)
#undef  KVDB_DFU_REGION_SIZE
#define KVDB_DFU_REGION_SIZE                               (0x00004000)
#undef  KVDB_DFU_REGION_OFFSET
#define KVDB_DFU_REGION_OFFSET                             (0x00CE0000)
#undef  KVDB_BLE_REGION_START_ADDR
#define KVDB_BLE_REGION_START_ADDR                         (0x14CE4000)
#undef  KVDB_BLE_REGION_SIZE
#define KVDB_BLE_REGION_SIZE                               (0x00004000)
#undef  KVDB_BLE_REGION_OFFSET
#define KVDB_BLE_REGION_OFFSET                             (0x00CE4000)
#undef  CUSTOM_EPD_WAVE_TABLE_START_ADDR
#define CUSTOM_EPD_WAVE_TABLE_START_ADDR                   (0x14CE8000)
#undef  CUSTOM_EPD_WAVE_TABLE_SIZE
#define CUSTOM_EPD_WAVE_TABLE_SIZE                         (0x00020000)
#undef  CUSTOM_EPD_WAVE_TABLE_OFFSET
#define CUSTOM_EPD_WAVE_TABLE_OFFSET                       (0x00CE8000)


/* psram1 */
#undef  PSRAM_DATA_START_ADDR
#define PSRAM_DATA_START_ADDR                              (0x60000000)
#undef  PSRAM_DATA_SIZE
#define PSRAM_DATA_SIZE                                    (0x00400000)
#undef  PSRAM_DATA_OFFSET
#define PSRAM_DATA_OFFSET                                  (0x00000000)


/* psram2 */
#undef  PSRAM_DATA2_START_ADDR
#define PSRAM_DATA2_START_ADDR                             (0x62000000)
#undef  PSRAM_DATA2_SIZE
#define PSRAM_DATA2_SIZE                                   (0x00400000)
#undef  PSRAM_DATA2_OFFSET
#define PSRAM_DATA2_OFFSET                                 (0x00000000)


/* hpsys_ram */
#undef  BOOTLOADER_RAM_DATA_START_ADDR
#define BOOTLOADER_RAM_DATA_START_ADDR                     (0x20040000)
#undef  BOOTLOADER_RAM_DATA_SIZE
#define BOOTLOADER_RAM_DATA_SIZE                           (0x00010000)
#undef  BOOTLOADER_RAM_DATA_OFFSET
#define BOOTLOADER_RAM_DATA_OFFSET                         (0x00040000)
#undef  FLASH_BOOT_LOADER_START_ADDR
#define FLASH_BOOT_LOADER_START_ADDR                       (0x20020000)
#undef  FLASH_BOOT_LOADER_SIZE
#define FLASH_BOOT_LOADER_SIZE                             (0x00010000)
#undef  FLASH_BOOT_LOADER_OFFSET
#define FLASH_BOOT_LOADER_OFFSET                           (0x00020000)
#undef  APP_BOOTLOADER_CODE_START_ADDR
#define APP_BOOTLOADER_CODE_START_ADDR                     (0x20020000)
#undef  APP_BOOTLOADER_CODE_SIZE
#define APP_BOOTLOADER_CODE_SIZE                           (0x00010000)
#undef  APP_BOOTLOADER_CODE_OFFSET
#define APP_BOOTLOADER_CODE_OFFSET                         (0x00020000)
#undef  HCPU_RAM_DATA_START_ADDR
#define HCPU_RAM_DATA_START_ADDR                           (0x20000000)
#undef  HCPU_RAM_DATA_SIZE
#define HCPU_RAM_DATA_SIZE                                 (0x0006FC00)
#undef  HCPU_RAM_DATA_OFFSET
#define HCPU_RAM_DATA_OFFSET                               (0x00000000)
#undef  ACPU_RAM_DATA_START_ADDR
#define ACPU_RAM_DATA_START_ADDR                           (0x2006FC00)
#undef  ACPU_RAM_DATA_SIZE
#define ACPU_RAM_DATA_SIZE                                 (0x0000FC00)
#undef  ACPU_RAM_DATA_OFFSET
#define ACPU_RAM_DATA_OFFSET                               (0x0006FC00)



#endif
