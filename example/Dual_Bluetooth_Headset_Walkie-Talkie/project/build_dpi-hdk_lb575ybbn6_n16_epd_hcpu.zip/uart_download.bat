@echo off
title=uart download
set WORK_PATH=%~dp0
set CURR_PATH=%cd%
cd %WORK_PATH%
:start
echo,
echo      Uart Download
echo,
set /p input=please input the serial port num:
goto download
:download
echo com%input%
sftool -p COM%input% -c SF32LB57 -m nor write_flash "bootloader\bootloader.bin@0x14010000" "main.bin@0x14020000" "ftab\ftab.bin@0x14000000" "fs_root.bin@0x148E0000"

if "%ENV_ROOT%"=="" pause

