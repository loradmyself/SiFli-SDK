
build_dpi-hdk_lb575ybbn6_n16_epd_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020204 <deregister_tm_clones>:
20020204:	4803      	ldr	r0, [pc, #12]	@ (20020214 <deregister_tm_clones+0x10>)
20020206:	4b04      	ldr	r3, [pc, #16]	@ (20020218 <deregister_tm_clones+0x14>)
20020208:	4283      	cmp	r3, r0
2002020a:	d002      	beq.n	20020212 <deregister_tm_clones+0xe>
2002020c:	4b03      	ldr	r3, [pc, #12]	@ (2002021c <deregister_tm_clones+0x18>)
2002020e:	b103      	cbz	r3, 20020212 <deregister_tm_clones+0xe>
20020210:	4718      	bx	r3
20020212:	4770      	bx	lr
20020214:	20044a08 	.word	0x20044a08
20020218:	20044a08 	.word	0x20044a08
2002021c:	00000000 	.word	0x00000000

20020220 <register_tm_clones>:
20020220:	4b06      	ldr	r3, [pc, #24]	@ (2002023c <register_tm_clones+0x1c>)
20020222:	4907      	ldr	r1, [pc, #28]	@ (20020240 <register_tm_clones+0x20>)
20020224:	1ac9      	subs	r1, r1, r3
20020226:	1089      	asrs	r1, r1, #2
20020228:	bf48      	it	mi
2002022a:	3101      	addmi	r1, #1
2002022c:	1049      	asrs	r1, r1, #1
2002022e:	d003      	beq.n	20020238 <register_tm_clones+0x18>
20020230:	4b04      	ldr	r3, [pc, #16]	@ (20020244 <register_tm_clones+0x24>)
20020232:	b10b      	cbz	r3, 20020238 <register_tm_clones+0x18>
20020234:	4801      	ldr	r0, [pc, #4]	@ (2002023c <register_tm_clones+0x1c>)
20020236:	4718      	bx	r3
20020238:	4770      	bx	lr
2002023a:	bf00      	nop
2002023c:	20044a08 	.word	0x20044a08
20020240:	20044a08 	.word	0x20044a08
20020244:	00000000 	.word	0x00000000

20020248 <__do_global_dtors_aux>:
20020248:	b510      	push	{r4, lr}
2002024a:	4c06      	ldr	r4, [pc, #24]	@ (20020264 <__do_global_dtors_aux+0x1c>)
2002024c:	7823      	ldrb	r3, [r4, #0]
2002024e:	b943      	cbnz	r3, 20020262 <__do_global_dtors_aux+0x1a>
20020250:	f7ff ffd8 	bl	20020204 <deregister_tm_clones>
20020254:	4b04      	ldr	r3, [pc, #16]	@ (20020268 <__do_global_dtors_aux+0x20>)
20020256:	b113      	cbz	r3, 2002025e <__do_global_dtors_aux+0x16>
20020258:	4804      	ldr	r0, [pc, #16]	@ (2002026c <__do_global_dtors_aux+0x24>)
2002025a:	f3af 8000 	nop.w
2002025e:	2301      	movs	r3, #1
20020260:	7023      	strb	r3, [r4, #0]
20020262:	bd10      	pop	{r4, pc}
20020264:	20044a08 	.word	0x20044a08
20020268:	00000000 	.word	0x00000000
2002026c:	200274e4 	.word	0x200274e4

20020270 <frame_dummy>:
20020270:	b508      	push	{r3, lr}
20020272:	4b05      	ldr	r3, [pc, #20]	@ (20020288 <frame_dummy+0x18>)
20020274:	b11b      	cbz	r3, 2002027e <frame_dummy+0xe>
20020276:	4905      	ldr	r1, [pc, #20]	@ (2002028c <frame_dummy+0x1c>)
20020278:	4805      	ldr	r0, [pc, #20]	@ (20020290 <frame_dummy+0x20>)
2002027a:	f3af 8000 	nop.w
2002027e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020282:	f7ff bfcd 	b.w	20020220 <register_tm_clones>
20020286:	bf00      	nop
20020288:	00000000 	.word	0x00000000
2002028c:	20044a0c 	.word	0x20044a0c
20020290:	200274e4 	.word	0x200274e4

20020294 <boot_uart_tx>:
20020294:	2300      	movs	r3, #0
20020296:	b510      	push	{r4, lr}
20020298:	4293      	cmp	r3, r2
2002029a:	db00      	blt.n	2002029e <boot_uart_tx+0xa>
2002029c:	bd10      	pop	{r4, pc}
2002029e:	69c4      	ldr	r4, [r0, #28]
200202a0:	0624      	lsls	r4, r4, #24
200202a2:	d5fc      	bpl.n	2002029e <boot_uart_tx+0xa>
200202a4:	5ccc      	ldrb	r4, [r1, r3]
200202a6:	3301      	adds	r3, #1
200202a8:	6284      	str	r4, [r0, #40]	@ 0x28
200202aa:	e7f5      	b.n	20020298 <boot_uart_tx+0x4>

200202ac <mpu_config>:
200202ac:	4770      	bx	lr

200202ae <cache_enable>:
200202ae:	4770      	bx	lr

200202b0 <board_pinmux_mpi1_type1>:
200202b0:	b510      	push	{r4, lr}
200202b2:	2100      	movs	r1, #0
200202b4:	f640 3004 	movw	r0, #2820	@ 0xb04
200202b8:	f003 ffd0 	bl	2002425c <HAL_PIN_Set2>
200202bc:	2100      	movs	r1, #0
200202be:	f44f 7082 	mov.w	r0, #260	@ 0x104
200202c2:	f003 ffcb 	bl	2002425c <HAL_PIN_Set2>
200202c6:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202ca:	f640 5004 	movw	r0, #3332	@ 0xd04
200202ce:	f003 ffc5 	bl	2002425c <HAL_PIN_Set2>
200202d2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202d6:	f44f 7041 	mov.w	r0, #772	@ 0x304
200202da:	f003 ffbf 	bl	2002425c <HAL_PIN_Set2>
200202de:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202e2:	f240 5004 	movw	r0, #1284	@ 0x504
200202e6:	f003 ffb9 	bl	2002425c <HAL_PIN_Set2>
200202ea:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202ee:	f640 4004 	movw	r0, #3076	@ 0xc04
200202f2:	f003 ffb3 	bl	2002425c <HAL_PIN_Set2>
200202f6:	2400      	movs	r4, #0
200202f8:	2201      	movs	r2, #1
200202fa:	3401      	adds	r4, #1
200202fc:	4611      	mov	r1, r2
200202fe:	4620      	mov	r0, r4
20020300:	f003 fff6 	bl	200242f0 <HAL_PIN_Set_DS0>
20020304:	2200      	movs	r2, #0
20020306:	2101      	movs	r1, #1
20020308:	4620      	mov	r0, r4
2002030a:	f004 f807 	bl	2002431c <HAL_PIN_Set_DS1>
2002030e:	2c0d      	cmp	r4, #13
20020310:	d1f2      	bne.n	200202f8 <board_pinmux_mpi1_type1+0x48>
20020312:	bd10      	pop	{r4, pc}

20020314 <board_pinmux_mpi1_type2>:
20020314:	b510      	push	{r4, lr}
20020316:	2100      	movs	r1, #0
20020318:	f640 3004 	movw	r0, #2820	@ 0xb04
2002031c:	f003 ff9e 	bl	2002425c <HAL_PIN_Set2>
20020320:	2100      	movs	r1, #0
20020322:	f240 4004 	movw	r0, #1028	@ 0x404
20020326:	f003 ff99 	bl	2002425c <HAL_PIN_Set2>
2002032a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002032e:	f640 5004 	movw	r0, #3332	@ 0xd04
20020332:	f003 ff93 	bl	2002425c <HAL_PIN_Set2>
20020336:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002033a:	f44f 7041 	mov.w	r0, #772	@ 0x304
2002033e:	f003 ff8d 	bl	2002425c <HAL_PIN_Set2>
20020342:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020346:	f44f 7001 	mov.w	r0, #516	@ 0x204
2002034a:	f003 ff87 	bl	2002425c <HAL_PIN_Set2>
2002034e:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020352:	f640 2004 	movw	r0, #2564	@ 0xa04
20020356:	f003 ff81 	bl	2002425c <HAL_PIN_Set2>
2002035a:	2400      	movs	r4, #0
2002035c:	2201      	movs	r2, #1
2002035e:	3401      	adds	r4, #1
20020360:	4611      	mov	r1, r2
20020362:	4620      	mov	r0, r4
20020364:	f003 ffc4 	bl	200242f0 <HAL_PIN_Set_DS0>
20020368:	2200      	movs	r2, #0
2002036a:	2101      	movs	r1, #1
2002036c:	4620      	mov	r0, r4
2002036e:	f003 ffd5 	bl	2002431c <HAL_PIN_Set_DS1>
20020372:	2c0d      	cmp	r4, #13
20020374:	d1f2      	bne.n	2002035c <board_pinmux_mpi1_type2+0x48>
20020376:	bd10      	pop	{r4, pc}

20020378 <board_pinmux_mpi2>:
20020378:	b510      	push	{r4, lr}
2002037a:	2100      	movs	r1, #0
2002037c:	f641 2004 	movw	r0, #6660	@ 0x1a04
20020380:	f003 ff6c 	bl	2002425c <HAL_PIN_Set2>
20020384:	2100      	movs	r1, #0
20020386:	f241 4004 	movw	r0, #5124	@ 0x1404
2002038a:	f003 ff67 	bl	2002425c <HAL_PIN_Set2>
2002038e:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020392:	f641 0004 	movw	r0, #6148	@ 0x1804
20020396:	f003 ff61 	bl	2002425c <HAL_PIN_Set2>
2002039a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002039e:	f241 3004 	movw	r0, #4868	@ 0x1304
200203a2:	f003 ff5b 	bl	2002425c <HAL_PIN_Set2>
200203a6:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203aa:	f241 2004 	movw	r0, #4612	@ 0x1204
200203ae:	f003 ff55 	bl	2002425c <HAL_PIN_Set2>
200203b2:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203b6:	f641 1004 	movw	r0, #6404	@ 0x1904
200203ba:	f003 ff4f 	bl	2002425c <HAL_PIN_Set2>
200203be:	240e      	movs	r4, #14
200203c0:	2201      	movs	r2, #1
200203c2:	4620      	mov	r0, r4
200203c4:	4611      	mov	r1, r2
200203c6:	f003 ff93 	bl	200242f0 <HAL_PIN_Set_DS0>
200203ca:	4620      	mov	r0, r4
200203cc:	2200      	movs	r2, #0
200203ce:	2101      	movs	r1, #1
200203d0:	3401      	adds	r4, #1
200203d2:	f003 ffa3 	bl	2002431c <HAL_PIN_Set_DS1>
200203d6:	2c1b      	cmp	r4, #27
200203d8:	d1f2      	bne.n	200203c0 <board_pinmux_mpi2+0x48>
200203da:	bd10      	pop	{r4, pc}

200203dc <board_pinmux_mpi3>:
200203dc:	b510      	push	{r4, lr}
200203de:	2100      	movs	r1, #0
200203e0:	f642 3001 	movw	r0, #11009	@ 0x2b01
200203e4:	f003 ff3a 	bl	2002425c <HAL_PIN_Set2>
200203e8:	2100      	movs	r1, #0
200203ea:	f242 7001 	movw	r0, #9985	@ 0x2701
200203ee:	f003 ff35 	bl	2002425c <HAL_PIN_Set2>
200203f2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200203f6:	f642 2001 	movw	r0, #10753	@ 0x2a01
200203fa:	f003 ff2f 	bl	2002425c <HAL_PIN_Set2>
200203fe:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020402:	f642 0001 	movw	r0, #10241	@ 0x2801
20020406:	f003 ff29 	bl	2002425c <HAL_PIN_Set2>
2002040a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002040e:	f642 1001 	movw	r0, #10497	@ 0x2901
20020412:	f003 ff23 	bl	2002425c <HAL_PIN_Set2>
20020416:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002041a:	f642 4001 	movw	r0, #11265	@ 0x2c01
2002041e:	f003 ff1d 	bl	2002425c <HAL_PIN_Set2>
20020422:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20020426:	4b13      	ldr	r3, [pc, #76]	@ (20020474 <board_pinmux_mpi3+0x98>)
20020428:	2427      	movs	r4, #39	@ 0x27
2002042a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002042e:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20020432:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020436:	f44f 4200 	mov.w	r2, #32768	@ 0x8000
2002043a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002043e:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020442:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020446:	f44f 4280 	mov.w	r2, #16384	@ 0x4000
2002044a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002044e:	f44f 3200 	mov.w	r2, #131072	@ 0x20000
20020452:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020456:	2201      	movs	r2, #1
20020458:	4620      	mov	r0, r4
2002045a:	4611      	mov	r1, r2
2002045c:	f003 ff48 	bl	200242f0 <HAL_PIN_Set_DS0>
20020460:	4620      	mov	r0, r4
20020462:	2200      	movs	r2, #0
20020464:	2101      	movs	r1, #1
20020466:	3401      	adds	r4, #1
20020468:	f003 ff58 	bl	2002431c <HAL_PIN_Set_DS1>
2002046c:	2c2d      	cmp	r4, #45	@ 0x2d
2002046e:	d1f2      	bne.n	20020456 <board_pinmux_mpi3+0x7a>
20020470:	bd10      	pop	{r4, pc}
20020472:	bf00      	nop
20020474:	500ca000 	.word	0x500ca000

20020478 <board_pinmux_sd>:
20020478:	b510      	push	{r4, lr}
2002047a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002047e:	f642 2002 	movw	r0, #10754	@ 0x2a02
20020482:	f003 feeb 	bl	2002425c <HAL_PIN_Set2>
20020486:	f44f 4300 	mov.w	r3, #32768	@ 0x8000
2002048a:	4c1c      	ldr	r4, [pc, #112]	@ (200204fc <board_pinmux_sd+0x84>)
2002048c:	2014      	movs	r0, #20
2002048e:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
20020492:	f001 fa8e 	bl	200219b2 <HAL_Delay_us>
20020496:	2100      	movs	r1, #0
20020498:	f642 1002 	movw	r0, #10498	@ 0x2902
2002049c:	f003 fede 	bl	2002425c <HAL_PIN_Set2>
200204a0:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204a4:	f642 3002 	movw	r0, #11010	@ 0x2b02
200204a8:	f003 fed8 	bl	2002425c <HAL_PIN_Set2>
200204ac:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204b0:	f642 4002 	movw	r0, #11266	@ 0x2c02
200204b4:	f003 fed2 	bl	2002425c <HAL_PIN_Set2>
200204b8:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204bc:	f242 7002 	movw	r0, #9986	@ 0x2702
200204c0:	f003 fecc 	bl	2002425c <HAL_PIN_Set2>
200204c4:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204c8:	f642 0002 	movw	r0, #10242	@ 0x2802
200204cc:	f003 fec6 	bl	2002425c <HAL_PIN_Set2>
200204d0:	f44f 4380 	mov.w	r3, #16384	@ 0x4000
200204d4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204d8:	f44f 3380 	mov.w	r3, #65536	@ 0x10000
200204dc:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e0:	f44f 3300 	mov.w	r3, #131072	@ 0x20000
200204e4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e8:	f44f 5380 	mov.w	r3, #4096	@ 0x1000
200204ec:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f0:	f44f 5300 	mov.w	r3, #8192	@ 0x2000
200204f4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f8:	bd10      	pop	{r4, pc}
200204fa:	bf00      	nop
200204fc:	500ca000 	.word	0x500ca000

20020500 <board_boot_from>:
20020500:	b508      	push	{r3, lr}
20020502:	2000      	movs	r0, #0
20020504:	f007 fb42 	bl	20027b8c <HAL_Get_backup>
20020508:	f000 000f 	and.w	r0, r0, #15
2002050c:	bd08      	pop	{r3, pc}

2002050e <board_init>:
2002050e:	4770      	bx	lr

20020510 <bootloader_switch_clock>:
20020510:	b508      	push	{r3, lr}
20020512:	2102      	movs	r1, #2
20020514:	2004      	movs	r0, #4
20020516:	f004 f80f 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
2002051a:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002051e:	2102      	movs	r1, #2
20020520:	2006      	movs	r0, #6
20020522:	f004 b809 	b.w	20024538 <HAL_RCC_HCPU_ClockSelect>

20020526 <board_init_psram>:
20020526:	2201      	movs	r2, #1
20020528:	b508      	push	{r3, lr}
2002052a:	4611      	mov	r1, r2
2002052c:	2000      	movs	r0, #0
2002052e:	f007 fb4b 	bl	20027bc8 <HAL_PMU_ConfigPeriLdo>
20020532:	2001      	movs	r0, #1
20020534:	f7ff ffec 	bl	20020510 <bootloader_switch_clock>
20020538:	2002      	movs	r0, #2
2002053a:	f001 f92f 	bl	2002179c <BSP_SetFlash1DIV>
2002053e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020542:	f001 b8c5 	b.w	200216d0 <bsp_psramc_init>
	...

20020548 <erase_nor>:
20020548:	b570      	push	{r4, r5, r6, lr}
2002054a:	4b13      	ldr	r3, [pc, #76]	@ (20020598 <erase_nor+0x50>)
2002054c:	460c      	mov	r4, r1
2002054e:	681e      	ldr	r6, [r3, #0]
20020550:	6933      	ldr	r3, [r6, #16]
20020552:	4283      	cmp	r3, r0
20020554:	d901      	bls.n	2002055a <erase_nor+0x12>
20020556:	2001      	movs	r0, #1
20020558:	bd70      	pop	{r4, r5, r6, pc}
2002055a:	6972      	ldr	r2, [r6, #20]
2002055c:	441a      	add	r2, r3
2002055e:	4282      	cmp	r2, r0
20020560:	d3f9      	bcc.n	20020556 <erase_nor+0xe>
20020562:	1ac0      	subs	r0, r0, r3
20020564:	f3c0 030b 	ubfx	r3, r0, #0, #12
20020568:	b97b      	cbnz	r3, 2002058a <erase_nor+0x42>
2002056a:	f3c1 030b 	ubfx	r3, r1, #0, #12
2002056e:	b97b      	cbnz	r3, 20020590 <erase_nor+0x48>
20020570:	1845      	adds	r5, r0, r1
20020572:	1b29      	subs	r1, r5, r4
20020574:	b90c      	cbnz	r4, 2002057a <erase_nor+0x32>
20020576:	4620      	mov	r0, r4
20020578:	e7ee      	b.n	20020558 <erase_nor+0x10>
2002057a:	4630      	mov	r0, r6
2002057c:	f002 ffd9 	bl	20023532 <HAL_QSPIEX_SECT_ERASE>
20020580:	2800      	cmp	r0, #0
20020582:	d1e8      	bne.n	20020556 <erase_nor+0xe>
20020584:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
20020588:	e7f3      	b.n	20020572 <erase_nor+0x2a>
2002058a:	f04f 30ff 	mov.w	r0, #4294967295
2002058e:	e7e3      	b.n	20020558 <erase_nor+0x10>
20020590:	f06f 0001 	mvn.w	r0, #1
20020594:	e7e0      	b.n	20020558 <erase_nor+0x10>
20020596:	bf00      	nop
20020598:	20046d30 	.word	0x20046d30

2002059c <write_nor>:
2002059c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200205a0:	4b1e      	ldr	r3, [pc, #120]	@ (2002061c <write_nor+0x80>)
200205a2:	460f      	mov	r7, r1
200205a4:	f8d3 8000 	ldr.w	r8, [r3]
200205a8:	4616      	mov	r6, r2
200205aa:	f8d8 5010 	ldr.w	r5, [r8, #16]
200205ae:	4285      	cmp	r5, r0
200205b0:	d902      	bls.n	200205b8 <write_nor+0x1c>
200205b2:	2000      	movs	r0, #0
200205b4:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200205b8:	f8d8 2014 	ldr.w	r2, [r8, #20]
200205bc:	442a      	add	r2, r5
200205be:	4282      	cmp	r2, r0
200205c0:	d3f7      	bcc.n	200205b2 <write_nor+0x16>
200205c2:	1b45      	subs	r5, r0, r5
200205c4:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
200205c8:	d012      	beq.n	200205f0 <write_nor+0x54>
200205ca:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
200205ce:	42b4      	cmp	r4, r6
200205d0:	bf28      	it	cs
200205d2:	4634      	movcs	r4, r6
200205d4:	460a      	mov	r2, r1
200205d6:	4623      	mov	r3, r4
200205d8:	4629      	mov	r1, r5
200205da:	4640      	mov	r0, r8
200205dc:	f002 fec4 	bl	20023368 <HAL_QSPIEX_WRITE_PAGE>
200205e0:	4284      	cmp	r4, r0
200205e2:	d1e6      	bne.n	200205b2 <write_nor+0x16>
200205e4:	4425      	add	r5, r4
200205e6:	4427      	add	r7, r4
200205e8:	1b34      	subs	r4, r6, r4
200205ea:	b91c      	cbnz	r4, 200205f4 <write_nor+0x58>
200205ec:	4630      	mov	r0, r6
200205ee:	e7e1      	b.n	200205b4 <write_nor+0x18>
200205f0:	4634      	mov	r4, r6
200205f2:	e7fa      	b.n	200205ea <write_nor+0x4e>
200205f4:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
200205f8:	46a1      	mov	r9, r4
200205fa:	bf28      	it	cs
200205fc:	f44f 7980 	movcs.w	r9, #256	@ 0x100
20020600:	463a      	mov	r2, r7
20020602:	464b      	mov	r3, r9
20020604:	4629      	mov	r1, r5
20020606:	4640      	mov	r0, r8
20020608:	f002 feae 	bl	20023368 <HAL_QSPIEX_WRITE_PAGE>
2002060c:	4581      	cmp	r9, r0
2002060e:	d1d0      	bne.n	200205b2 <write_nor+0x16>
20020610:	444d      	add	r5, r9
20020612:	444f      	add	r7, r9
20020614:	eba4 0409 	sub.w	r4, r4, r9
20020618:	e7e7      	b.n	200205ea <write_nor+0x4e>
2002061a:	bf00      	nop
2002061c:	20046d30 	.word	0x20046d30

20020620 <read_nor>:
20020620:	460b      	mov	r3, r1
20020622:	b510      	push	{r4, lr}
20020624:	4614      	mov	r4, r2
20020626:	4601      	mov	r1, r0
20020628:	4618      	mov	r0, r3
2002062a:	f005 fbb0 	bl	20025d8e <memcpy>
2002062e:	4620      	mov	r0, r4
20020630:	bd10      	pop	{r4, pc}
	...

20020634 <read_nand>:
20020634:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020638:	2600      	movs	r6, #0
2002063a:	460f      	mov	r7, r1
2002063c:	4615      	mov	r5, r2
2002063e:	46b0      	mov	r8, r6
20020640:	4b19      	ldr	r3, [pc, #100]	@ (200206a8 <read_nand+0x74>)
20020642:	f8df a068 	ldr.w	sl, [pc, #104]	@ 200206ac <read_nand+0x78>
20020646:	681b      	ldr	r3, [r3, #0]
20020648:	f8df b064 	ldr.w	fp, [pc, #100]	@ 200206b0 <read_nand+0x7c>
2002064c:	691b      	ldr	r3, [r3, #16]
2002064e:	4604      	mov	r4, r0
20020650:	4283      	cmp	r3, r0
20020652:	b085      	sub	sp, #20
20020654:	bf98      	it	ls
20020656:	1ac4      	subls	r4, r0, r3
20020658:	b91d      	cbnz	r5, 20020662 <read_nand+0x2e>
2002065a:	4630      	mov	r0, r6
2002065c:	b005      	add	sp, #20
2002065e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020662:	f8da 1000 	ldr.w	r1, [sl]
20020666:	f8db 0000 	ldr.w	r0, [fp]
2002066a:	42a9      	cmp	r1, r5
2002066c:	fbb0 fcf1 	udiv	ip, r0, r1
20020670:	4689      	mov	r9, r1
20020672:	f101 32ff 	add.w	r2, r1, #4294967295
20020676:	bf28      	it	cs
20020678:	46a9      	movcs	r9, r5
2002067a:	fbb4 f1f1 	udiv	r1, r4, r1
2002067e:	f10c 3cff 	add.w	ip, ip, #4294967295
20020682:	fbb4 f0f0 	udiv	r0, r4, r0
20020686:	e9cd 8801 	strd	r8, r8, [sp, #4]
2002068a:	f8cd 9000 	str.w	r9, [sp]
2002068e:	19bb      	adds	r3, r7, r6
20020690:	4022      	ands	r2, r4
20020692:	ea0c 0101 	and.w	r1, ip, r1
20020696:	f004 fb89 	bl	20024dac <bbm_read_page>
2002069a:	4548      	cmp	r0, r9
2002069c:	d1dd      	bne.n	2002065a <read_nand+0x26>
2002069e:	4406      	add	r6, r0
200206a0:	1a2d      	subs	r5, r5, r0
200206a2:	4404      	add	r4, r0
200206a4:	e7d8      	b.n	20020658 <read_nand+0x24>
200206a6:	bf00      	nop
200206a8:	20046d30 	.word	0x20046d30
200206ac:	20042c04 	.word	0x20042c04
200206b0:	20042c00 	.word	0x20042c00

200206b4 <read_sdnand>:
200206b4:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200206b8:	f3c0 0408 	ubfx	r4, r0, #0, #9
200206bc:	460e      	mov	r6, r1
200206be:	4615      	mov	r5, r2
200206c0:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
200206c4:	b38c      	cbz	r4, 2002072a <read_sdnand+0x76>
200206c6:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 20020740 <read_sdnand+0x8c>
200206ca:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
200206ce:	eba8 0004 	sub.w	r0, r8, r4
200206d2:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206d6:	4649      	mov	r1, r9
200206d8:	f000 fed2 	bl	20021480 <sd_read_data>
200206dc:	42af      	cmp	r7, r5
200206de:	bf28      	it	cs
200206e0:	462f      	movcs	r7, r5
200206e2:	4630      	mov	r0, r6
200206e4:	eb09 0104 	add.w	r1, r9, r4
200206e8:	463a      	mov	r2, r7
200206ea:	f005 fb50 	bl	20025d8e <memcpy>
200206ee:	1bec      	subs	r4, r5, r7
200206f0:	44b8      	add	r8, r7
200206f2:	443e      	add	r6, r7
200206f4:	2700      	movs	r7, #0
200206f6:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
200206fa:	f02a 0a01 	bic.w	sl, sl, #1
200206fe:	4557      	cmp	r7, sl
20020700:	eb07 0906 	add.w	r9, r7, r6
20020704:	eb08 0007 	add.w	r0, r8, r7
20020708:	d111      	bne.n	2002072e <read_sdnand+0x7a>
2002070a:	f3c4 0408 	ubfx	r4, r4, #0, #9
2002070e:	b14c      	cbz	r4, 20020724 <read_sdnand+0x70>
20020710:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020714:	490a      	ldr	r1, [pc, #40]	@ (20020740 <read_sdnand+0x8c>)
20020716:	f000 feb3 	bl	20021480 <sd_read_data>
2002071a:	4622      	mov	r2, r4
2002071c:	4648      	mov	r0, r9
2002071e:	4908      	ldr	r1, [pc, #32]	@ (20020740 <read_sdnand+0x8c>)
20020720:	f005 fb35 	bl	20025d8e <memcpy>
20020724:	4628      	mov	r0, r5
20020726:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002072a:	4614      	mov	r4, r2
2002072c:	e7e2      	b.n	200206f4 <read_sdnand+0x40>
2002072e:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020732:	4649      	mov	r1, r9
20020734:	f000 fea4 	bl	20021480 <sd_read_data>
20020738:	f507 7700 	add.w	r7, r7, #512	@ 0x200
2002073c:	e7df      	b.n	200206fe <read_sdnand+0x4a>
2002073e:	bf00      	nop
20020740:	20046b2c 	.word	0x20046b2c

20020744 <read_sdemmc>:
20020744:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020748:	f3c0 0408 	ubfx	r4, r0, #0, #9
2002074c:	460e      	mov	r6, r1
2002074e:	4615      	mov	r5, r2
20020750:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020754:	b38c      	cbz	r4, 200207ba <read_sdemmc+0x76>
20020756:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 200207d0 <read_sdemmc+0x8c>
2002075a:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
2002075e:	eba8 0004 	sub.w	r0, r8, r4
20020762:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020766:	4649      	mov	r1, r9
20020768:	f000 fd2e 	bl	200211c8 <emmc_read_data>
2002076c:	42af      	cmp	r7, r5
2002076e:	bf28      	it	cs
20020770:	462f      	movcs	r7, r5
20020772:	4630      	mov	r0, r6
20020774:	eb09 0104 	add.w	r1, r9, r4
20020778:	463a      	mov	r2, r7
2002077a:	f005 fb08 	bl	20025d8e <memcpy>
2002077e:	1bec      	subs	r4, r5, r7
20020780:	44b8      	add	r8, r7
20020782:	443e      	add	r6, r7
20020784:	2700      	movs	r7, #0
20020786:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
2002078a:	f02a 0a01 	bic.w	sl, sl, #1
2002078e:	4557      	cmp	r7, sl
20020790:	eb07 0906 	add.w	r9, r7, r6
20020794:	eb08 0007 	add.w	r0, r8, r7
20020798:	d111      	bne.n	200207be <read_sdemmc+0x7a>
2002079a:	f3c4 0408 	ubfx	r4, r4, #0, #9
2002079e:	b14c      	cbz	r4, 200207b4 <read_sdemmc+0x70>
200207a0:	f44f 7200 	mov.w	r2, #512	@ 0x200
200207a4:	490a      	ldr	r1, [pc, #40]	@ (200207d0 <read_sdemmc+0x8c>)
200207a6:	f000 fd0f 	bl	200211c8 <emmc_read_data>
200207aa:	4622      	mov	r2, r4
200207ac:	4648      	mov	r0, r9
200207ae:	4908      	ldr	r1, [pc, #32]	@ (200207d0 <read_sdemmc+0x8c>)
200207b0:	f005 faed 	bl	20025d8e <memcpy>
200207b4:	4628      	mov	r0, r5
200207b6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200207ba:	4614      	mov	r4, r2
200207bc:	e7e2      	b.n	20020784 <read_sdemmc+0x40>
200207be:	f44f 7200 	mov.w	r2, #512	@ 0x200
200207c2:	4649      	mov	r1, r9
200207c4:	f000 fd00 	bl	200211c8 <emmc_read_data>
200207c8:	f507 7700 	add.w	r7, r7, #512	@ 0x200
200207cc:	e7df      	b.n	2002078e <read_sdemmc+0x4a>
200207ce:	bf00      	nop
200207d0:	20046b2c 	.word	0x20046b2c

200207d4 <port_read_page>:
200207d4:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200207d8:	4615      	mov	r5, r2
200207da:	460e      	mov	r6, r1
200207dc:	492b      	ldr	r1, [pc, #172]	@ (2002088c <port_read_page+0xb8>)
200207de:	461a      	mov	r2, r3
200207e0:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
200207e4:	680f      	ldr	r7, [r1, #0]
200207e6:	18e9      	adds	r1, r5, r3
200207e8:	428f      	cmp	r7, r1
200207ea:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
200207ee:	d200      	bcs.n	200207f2 <port_read_page+0x1e>
200207f0:	e7fe      	b.n	200207f0 <port_read_page+0x1c>
200207f2:	4927      	ldr	r1, [pc, #156]	@ (20020890 <port_read_page+0xbc>)
200207f4:	f107 0980 	add.w	r9, r7, #128	@ 0x80
200207f8:	f1b9 0f00 	cmp.w	r9, #0
200207fc:	6809      	ldr	r1, [r1, #0]
200207fe:	dd18      	ble.n	20020832 <port_read_page+0x5e>
20020800:	4c24      	ldr	r4, [pc, #144]	@ (20020894 <port_read_page+0xc0>)
20020802:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
20020806:	f004 081f 	and.w	r8, r4, #31
2002080a:	44c8      	add	r8, r9
2002080c:	f024 041f 	bic.w	r4, r4, #31
20020810:	f3bf 8f4f 	dsb	sy
20020814:	f8df a084 	ldr.w	sl, [pc, #132]	@ 2002089c <port_read_page+0xc8>
20020818:	44a0      	add	r8, r4
2002081a:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
2002081e:	3420      	adds	r4, #32
20020820:	eba8 0904 	sub.w	r9, r8, r4
20020824:	f1b9 0f00 	cmp.w	r9, #0
20020828:	dcf7      	bgt.n	2002081a <port_read_page+0x46>
2002082a:	f3bf 8f4f 	dsb	sy
2002082e:	f3bf 8f6f 	isb	sy
20020832:	07c4      	lsls	r4, r0, #31
20020834:	d51e      	bpl.n	20020874 <port_read_page+0xa0>
20020836:	4c17      	ldr	r4, [pc, #92]	@ (20020894 <port_read_page+0xc0>)
20020838:	f894 80d7 	ldrb.w	r8, [r4, #215]	@ 0xd7
2002083c:	f1b8 0f00 	cmp.w	r8, #0
20020840:	d018      	beq.n	20020874 <port_read_page+0xa0>
20020842:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
20020846:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
2002084a:	f004 041f 	and.w	r4, r4, #31
2002084e:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020852:	f028 081f 	bic.w	r8, r8, #31
20020856:	f3bf 8f4f 	dsb	sy
2002085a:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 2002089c <port_read_page+0xc8>
2002085e:	3c20      	subs	r4, #32
20020860:	2c00      	cmp	r4, #0
20020862:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
20020866:	f108 0820 	add.w	r8, r8, #32
2002086a:	dcf8      	bgt.n	2002085e <port_read_page+0x8a>
2002086c:	f3bf 8f4f 	dsb	sy
20020870:	f3bf 8f6f 	isb	sy
20020874:	fb07 5506 	mla	r5, r7, r6, r5
20020878:	e9cd ce08 	strd	ip, lr, [sp, #32]
2002087c:	fb01 5100 	mla	r1, r1, r0, r5
20020880:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020884:	4804      	ldr	r0, [pc, #16]	@ (20020898 <port_read_page+0xc4>)
20020886:	f002 bc8d 	b.w	200231a4 <HAL_NAND_READ_WITHOOB>
2002088a:	bf00      	nop
2002088c:	20042c04 	.word	0x20042c04
20020890:	20042c00 	.word	0x20042c00
20020894:	20046f70 	.word	0x20046f70
20020898:	20047018 	.word	0x20047018
2002089c:	e000ed00 	.word	0xe000ed00

200208a0 <bbm_get_bb>:
200208a0:	b410      	push	{r4}
200208a2:	4b1e      	ldr	r3, [pc, #120]	@ (2002091c <bbm_get_bb+0x7c>)
200208a4:	4601      	mov	r1, r0
200208a6:	6818      	ldr	r0, [r3, #0]
200208a8:	3080      	adds	r0, #128	@ 0x80
200208aa:	2800      	cmp	r0, #0
200208ac:	dd14      	ble.n	200208d8 <bbm_get_bb+0x38>
200208ae:	4b1c      	ldr	r3, [pc, #112]	@ (20020920 <bbm_get_bb+0x80>)
200208b0:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208b2:	f003 021f 	and.w	r2, r3, #31
200208b6:	4402      	add	r2, r0
200208b8:	f023 031f 	bic.w	r3, r3, #31
200208bc:	f3bf 8f4f 	dsb	sy
200208c0:	4c18      	ldr	r4, [pc, #96]	@ (20020924 <bbm_get_bb+0x84>)
200208c2:	441a      	add	r2, r3
200208c4:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
200208c8:	3320      	adds	r3, #32
200208ca:	1ad0      	subs	r0, r2, r3
200208cc:	2800      	cmp	r0, #0
200208ce:	dcf9      	bgt.n	200208c4 <bbm_get_bb+0x24>
200208d0:	f3bf 8f4f 	dsb	sy
200208d4:	f3bf 8f6f 	isb	sy
200208d8:	07cb      	lsls	r3, r1, #31
200208da:	d51a      	bpl.n	20020912 <bbm_get_bb+0x72>
200208dc:	4b10      	ldr	r3, [pc, #64]	@ (20020920 <bbm_get_bb+0x80>)
200208de:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
200208e2:	b1b2      	cbz	r2, 20020912 <bbm_get_bb+0x72>
200208e4:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208e6:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
200208ea:	f003 031f 	and.w	r3, r3, #31
200208ee:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
200208f2:	f022 021f 	bic.w	r2, r2, #31
200208f6:	f3bf 8f4f 	dsb	sy
200208fa:	480a      	ldr	r0, [pc, #40]	@ (20020924 <bbm_get_bb+0x84>)
200208fc:	3b20      	subs	r3, #32
200208fe:	2b00      	cmp	r3, #0
20020900:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
20020904:	f102 0220 	add.w	r2, r2, #32
20020908:	dcf8      	bgt.n	200208fc <bbm_get_bb+0x5c>
2002090a:	f3bf 8f4f 	dsb	sy
2002090e:	f3bf 8f6f 	isb	sy
20020912:	4805      	ldr	r0, [pc, #20]	@ (20020928 <bbm_get_bb+0x88>)
20020914:	f85d 4b04 	ldr.w	r4, [sp], #4
20020918:	f002 bd05 	b.w	20023326 <HAL_NAND_GET_BADBLK>
2002091c:	20042c04 	.word	0x20042c04
20020920:	20046f70 	.word	0x20046f70
20020924:	e000ed00 	.word	0xe000ed00
20020928:	20046fc4 	.word	0x20046fc4

2002092c <boot_device_init>:
2002092c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020930:	b08c      	sub	sp, #48	@ 0x30
20020932:	f001 fd47 	bl	200223c4 <HAL_HPAON_EnableXT48>
20020936:	2101      	movs	r1, #1
20020938:	2000      	movs	r0, #0
2002093a:	f003 fdfd 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
2002093e:	2101      	movs	r1, #1
20020940:	200c      	movs	r0, #12
20020942:	f003 fdf9 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20020946:	2001      	movs	r0, #1
20020948:	f003 fcfe 	bl	20024348 <HAL_PMU_EnableDLL>
2002094c:	4fa3      	ldr	r7, [pc, #652]	@ (20020bdc <boot_device_init+0x2b0>)
2002094e:	2090      	movs	r0, #144	@ 0x90
20020950:	f003 ff58 	bl	20024804 <HAL_RCC_HCPU_ConfigHCLK>
20020954:	48a2      	ldr	r0, [pc, #648]	@ (20020be0 <boot_device_init+0x2b4>)
20020956:	f003 fdbf 	bl	200244d8 <HAL_RCC_HCPU_EnableDLL2>
2002095a:	783b      	ldrb	r3, [r7, #0]
2002095c:	4ca1      	ldr	r4, [pc, #644]	@ (20020be4 <boot_device_init+0x2b8>)
2002095e:	2b06      	cmp	r3, #6
20020960:	f200 8137 	bhi.w	20020bd2 <boot_device_init+0x2a6>
20020964:	e8df f013 	tbh	[pc, r3, lsl #1]
20020968:	00440007 	.word	0x00440007
2002096c:	009f0044 	.word	0x009f0044
20020970:	011b009f 	.word	0x011b009f
20020974:	012a      	.short	0x012a
20020976:	2006      	movs	r0, #6
20020978:	4e9b      	ldr	r6, [pc, #620]	@ (20020be8 <boot_device_init+0x2bc>)
2002097a:	f000 ff15 	bl	200217a8 <BSP_SetFlash2DIV>
2002097e:	ad02      	add	r5, sp, #8
20020980:	2102      	movs	r1, #2
20020982:	2006      	movs	r0, #6
20020984:	f003 fdd8 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20020988:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002098a:	c50f      	stmia	r5!, {r0, r1, r2, r3}
2002098c:	6833      	ldr	r3, [r6, #0]
2002098e:	2210      	movs	r2, #16
20020990:	2100      	movs	r1, #0
20020992:	602b      	str	r3, [r5, #0]
20020994:	a808      	add	r0, sp, #32
20020996:	f005 f98b 	bl	20025cb0 <memset>
2002099a:	4b94      	ldr	r3, [pc, #592]	@ (20020bec <boot_device_init+0x2c0>)
2002099c:	2601      	movs	r6, #1
2002099e:	9307      	str	r3, [sp, #28]
200209a0:	2333      	movs	r3, #51	@ 0x33
200209a2:	960a      	str	r6, [sp, #40]	@ 0x28
200209a4:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
200209a8:	f7ff fce6 	bl	20020378 <board_pinmux_mpi2>
200209ac:	2302      	movs	r3, #2
200209ae:	4d90      	ldr	r5, [pc, #576]	@ (20020bf0 <boot_device_init+0x2c4>)
200209b0:	9303      	str	r3, [sp, #12]
200209b2:	4b90      	ldr	r3, [pc, #576]	@ (20020bf4 <boot_device_init+0x2c8>)
200209b4:	2000      	movs	r0, #0
200209b6:	6023      	str	r3, [r4, #0]
200209b8:	f000 fffb 	bl	200219b2 <HAL_Delay_us>
200209bc:	f885 6099 	strb.w	r6, [r5, #153]	@ 0x99
200209c0:	f000 fee0 	bl	20021784 <BSP_GetFlash2DIV>
200209c4:	f105 0654 	add.w	r6, r5, #84	@ 0x54
200209c8:	4a8b      	ldr	r2, [pc, #556]	@ (20020bf8 <boot_device_init+0x2cc>)
200209ca:	9000      	str	r0, [sp, #0]
200209cc:	ab07      	add	r3, sp, #28
200209ce:	4630      	mov	r0, r6
200209d0:	a902      	add	r1, sp, #8
200209d2:	f002 fe61 	bl	20023698 <HAL_FLASH_Init>
200209d6:	4b89      	ldr	r3, [pc, #548]	@ (20020bfc <boot_device_init+0x2d0>)
200209d8:	4a89      	ldr	r2, [pc, #548]	@ (20020c00 <boot_device_init+0x2d4>)
200209da:	601a      	str	r2, [r3, #0]
200209dc:	4a89      	ldr	r2, [pc, #548]	@ (20020c04 <boot_device_init+0x2d8>)
200209de:	4b8a      	ldr	r3, [pc, #552]	@ (20020c08 <boot_device_init+0x2dc>)
200209e0:	601a      	str	r2, [r3, #0]
200209e2:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
200209e6:	4b89      	ldr	r3, [pc, #548]	@ (20020c0c <boot_device_init+0x2e0>)
200209e8:	601a      	str	r2, [r3, #0]
200209ea:	4b89      	ldr	r3, [pc, #548]	@ (20020c10 <boot_device_init+0x2e4>)
200209ec:	601e      	str	r6, [r3, #0]
200209ee:	e037      	b.n	20020a60 <boot_device_init+0x134>
200209f0:	2006      	movs	r0, #6
200209f2:	4e88      	ldr	r6, [pc, #544]	@ (20020c14 <boot_device_init+0x2e8>)
200209f4:	f000 fed2 	bl	2002179c <BSP_SetFlash1DIV>
200209f8:	ad02      	add	r5, sp, #8
200209fa:	2102      	movs	r1, #2
200209fc:	2004      	movs	r0, #4
200209fe:	f003 fd9b 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20020a02:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020a04:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020a06:	6833      	ldr	r3, [r6, #0]
20020a08:	2210      	movs	r2, #16
20020a0a:	602b      	str	r3, [r5, #0]
20020a0c:	2100      	movs	r1, #0
20020a0e:	a808      	add	r0, sp, #32
20020a10:	f005 f94e 	bl	20025cb0 <memset>
20020a14:	4b80      	ldr	r3, [pc, #512]	@ (20020c18 <boot_device_init+0x2ec>)
20020a16:	4d76      	ldr	r5, [pc, #472]	@ (20020bf0 <boot_device_init+0x2c4>)
20020a18:	9307      	str	r3, [sp, #28]
20020a1a:	2332      	movs	r3, #50	@ 0x32
20020a1c:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020a20:	2301      	movs	r3, #1
20020a22:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
20020a26:	783b      	ldrb	r3, [r7, #0]
20020a28:	2b01      	cmp	r3, #1
20020a2a:	d139      	bne.n	20020aa0 <boot_device_init+0x174>
20020a2c:	f7ff fc40 	bl	200202b0 <board_pinmux_mpi1_type1>
20020a30:	2302      	movs	r3, #2
20020a32:	9303      	str	r3, [sp, #12]
20020a34:	f000 fea0 	bl	20021778 <BSP_GetFlash1DIV>
20020a38:	4a78      	ldr	r2, [pc, #480]	@ (20020c1c <boot_device_init+0x2f0>)
20020a3a:	9000      	str	r0, [sp, #0]
20020a3c:	ab07      	add	r3, sp, #28
20020a3e:	486c      	ldr	r0, [pc, #432]	@ (20020bf0 <boot_device_init+0x2c4>)
20020a40:	a902      	add	r1, sp, #8
20020a42:	f002 fe29 	bl	20023698 <HAL_FLASH_Init>
20020a46:	4b6b      	ldr	r3, [pc, #428]	@ (20020bf4 <boot_device_init+0x2c8>)
20020a48:	4a6d      	ldr	r2, [pc, #436]	@ (20020c00 <boot_device_init+0x2d4>)
20020a4a:	6023      	str	r3, [r4, #0]
20020a4c:	4b6b      	ldr	r3, [pc, #428]	@ (20020bfc <boot_device_init+0x2d0>)
20020a4e:	601a      	str	r2, [r3, #0]
20020a50:	4b6d      	ldr	r3, [pc, #436]	@ (20020c08 <boot_device_init+0x2dc>)
20020a52:	4a6c      	ldr	r2, [pc, #432]	@ (20020c04 <boot_device_init+0x2d8>)
20020a54:	601a      	str	r2, [r3, #0]
20020a56:	4b6d      	ldr	r3, [pc, #436]	@ (20020c0c <boot_device_init+0x2e0>)
20020a58:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020a5a:	601a      	str	r2, [r3, #0]
20020a5c:	4b6c      	ldr	r3, [pc, #432]	@ (20020c10 <boot_device_init+0x2e4>)
20020a5e:	601d      	str	r5, [r3, #0]
20020a60:	6823      	ldr	r3, [r4, #0]
20020a62:	2b00      	cmp	r3, #0
20020a64:	f000 8110 	beq.w	20020c88 <boot_device_init+0x35c>
20020a68:	4e68      	ldr	r6, [pc, #416]	@ (20020c0c <boot_device_init+0x2e0>)
20020a6a:	6830      	ldr	r0, [r6, #0]
20020a6c:	2800      	cmp	r0, #0
20020a6e:	f000 810b 	beq.w	20020c88 <boot_device_init+0x35c>
20020a72:	4d6b      	ldr	r5, [pc, #428]	@ (20020c20 <boot_device_init+0x2f4>)
20020a74:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020a78:	4629      	mov	r1, r5
20020a7a:	4798      	blx	r3
20020a7c:	682a      	ldr	r2, [r5, #0]
20020a7e:	4b69      	ldr	r3, [pc, #420]	@ (20020c24 <boot_device_init+0x2f8>)
20020a80:	7839      	ldrb	r1, [r7, #0]
20020a82:	429a      	cmp	r2, r3
20020a84:	f040 80fb 	bne.w	20020c7e <boot_device_init+0x352>
20020a88:	2904      	cmp	r1, #4
20020a8a:	d105      	bne.n	20020a98 <boot_device_init+0x16c>
20020a8c:	f8d5 30a4 	ldr.w	r3, [r5, #164]	@ 0xa4
20020a90:	1e5a      	subs	r2, r3, #1
20020a92:	3203      	adds	r2, #3
20020a94:	f240 80e2 	bls.w	20020c5c <boot_device_init+0x330>
20020a98:	2001      	movs	r0, #1
20020a9a:	b00c      	add	sp, #48	@ 0x30
20020a9c:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020aa0:	f7ff fc38 	bl	20020314 <board_pinmux_mpi1_type2>
20020aa4:	e7c4      	b.n	20020a30 <boot_device_init+0x104>
20020aa6:	2006      	movs	r0, #6
20020aa8:	4e5f      	ldr	r6, [pc, #380]	@ (20020c28 <boot_device_init+0x2fc>)
20020aaa:	f000 fe83 	bl	200217b4 <BSP_SetFlash3DIV>
20020aae:	ad02      	add	r5, sp, #8
20020ab0:	2102      	movs	r1, #2
20020ab2:	2008      	movs	r0, #8
20020ab4:	f003 fd40 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20020ab8:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020aba:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020abc:	f897 8000 	ldrb.w	r8, [r7]
20020ac0:	6833      	ldr	r3, [r6, #0]
20020ac2:	f1b8 0a03 	subs.w	sl, r8, #3
20020ac6:	602b      	str	r3, [r5, #0]
20020ac8:	f04f 0210 	mov.w	r2, #16
20020acc:	f04f 0100 	mov.w	r1, #0
20020ad0:	a808      	add	r0, sp, #32
20020ad2:	bf18      	it	ne
20020ad4:	f04f 0a01 	movne.w	sl, #1
20020ad8:	f005 f8ea 	bl	20025cb0 <memset>
20020adc:	4b4e      	ldr	r3, [pc, #312]	@ (20020c18 <boot_device_init+0x2ec>)
20020ade:	2502      	movs	r5, #2
20020ae0:	9307      	str	r3, [sp, #28]
20020ae2:	2332      	movs	r3, #50	@ 0x32
20020ae4:	950a      	str	r5, [sp, #40]	@ 0x28
20020ae6:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020aea:	f7ff fc77 	bl	200203dc <board_pinmux_mpi3>
20020aee:	f1b8 0f03 	cmp.w	r8, #3
20020af2:	9503      	str	r5, [sp, #12]
20020af4:	4d3e      	ldr	r5, [pc, #248]	@ (20020bf0 <boot_device_init+0x2c4>)
20020af6:	d045      	beq.n	20020b84 <boot_device_init+0x258>
20020af8:	4b4c      	ldr	r3, [pc, #304]	@ (20020c2c <boot_device_init+0x300>)
20020afa:	6023      	str	r3, [r4, #0]
20020afc:	9b04      	ldr	r3, [sp, #16]
20020afe:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020b02:	9304      	str	r3, [sp, #16]
20020b04:	2301      	movs	r3, #1
20020b06:	9306      	str	r3, [sp, #24]
20020b08:	4b49      	ldr	r3, [pc, #292]	@ (20020c30 <boot_device_init+0x304>)
20020b0a:	f8c5 30c4 	str.w	r3, [r5, #196]	@ 0xc4
20020b0e:	f04f 0901 	mov.w	r9, #1
20020b12:	2000      	movs	r0, #0
20020b14:	f000 ff4d 	bl	200219b2 <HAL_Delay_us>
20020b18:	f885 90ed 	strb.w	r9, [r5, #237]	@ 0xed
20020b1c:	f885 a0ec 	strb.w	sl, [r5, #236]	@ 0xec
20020b20:	f000 fe36 	bl	20021790 <BSP_GetFlash3DIV>
20020b24:	4a43      	ldr	r2, [pc, #268]	@ (20020c34 <boot_device_init+0x308>)
20020b26:	9000      	str	r0, [sp, #0]
20020b28:	ab07      	add	r3, sp, #28
20020b2a:	4843      	ldr	r0, [pc, #268]	@ (20020c38 <boot_device_init+0x30c>)
20020b2c:	a902      	add	r1, sp, #8
20020b2e:	f002 fdb3 	bl	20023698 <HAL_FLASH_Init>
20020b32:	4e41      	ldr	r6, [pc, #260]	@ (20020c38 <boot_device_init+0x30c>)
20020b34:	bb48      	cbnz	r0, 20020b8a <boot_device_init+0x25e>
20020b36:	f1b8 0f03 	cmp.w	r8, #3
20020b3a:	d029      	beq.n	20020b90 <boot_device_init+0x264>
20020b3c:	4630      	mov	r0, r6
20020b3e:	f002 fb26 	bl	2002318e <HAL_NAND_PAGE_SIZE>
20020b42:	f8df a110 	ldr.w	sl, [pc, #272]	@ 20020c54 <boot_device_init+0x328>
20020b46:	f8df 8110 	ldr.w	r8, [pc, #272]	@ 20020c58 <boot_device_init+0x32c>
20020b4a:	f8ca 0000 	str.w	r0, [sl]
20020b4e:	4630      	mov	r0, r6
20020b50:	f002 fbdd 	bl	2002330e <HAL_NAND_BLOCK_SIZE>
20020b54:	4649      	mov	r1, r9
20020b56:	f8c8 0000 	str.w	r0, [r8]
20020b5a:	4630      	mov	r0, r6
20020b5c:	f885 90d6 	strb.w	r9, [r5, #214]	@ 0xd6
20020b60:	f002 f9d5 	bl	20022f0e <HAL_NAND_CONF_ECC>
20020b64:	f8da 0000 	ldr.w	r0, [sl]
20020b68:	f004 fc06 	bl	20025378 <bbm_set_page_size>
20020b6c:	f8d8 0000 	ldr.w	r0, [r8]
20020b70:	f004 fc08 	bl	20025384 <bbm_set_blk_size>
20020b74:	4931      	ldr	r1, [pc, #196]	@ (20020c3c <boot_device_init+0x310>)
20020b76:	f8d5 00f4 	ldr.w	r0, [r5, #244]	@ 0xf4
20020b7a:	f004 fa9f 	bl	200250bc <sif_bbm_init>
20020b7e:	f8d5 20f0 	ldr.w	r2, [r5, #240]	@ 0xf0
20020b82:	e730      	b.n	200209e6 <boot_device_init+0xba>
20020b84:	4b1b      	ldr	r3, [pc, #108]	@ (20020bf4 <boot_device_init+0x2c8>)
20020b86:	6023      	str	r3, [r4, #0]
20020b88:	e7c1      	b.n	20020b0e <boot_device_init+0x1e2>
20020b8a:	f1b8 0f03 	cmp.w	r8, #3
20020b8e:	d1f6      	bne.n	20020b7e <boot_device_init+0x252>
20020b90:	4b1a      	ldr	r3, [pc, #104]	@ (20020bfc <boot_device_init+0x2d0>)
20020b92:	4a1b      	ldr	r2, [pc, #108]	@ (20020c00 <boot_device_init+0x2d4>)
20020b94:	601a      	str	r2, [r3, #0]
20020b96:	4b1c      	ldr	r3, [pc, #112]	@ (20020c08 <boot_device_init+0x2dc>)
20020b98:	4a1a      	ldr	r2, [pc, #104]	@ (20020c04 <boot_device_init+0x2d8>)
20020b9a:	601a      	str	r2, [r3, #0]
20020b9c:	e7ef      	b.n	20020b7e <boot_device_init+0x252>
20020b9e:	f7ff fc6b 	bl	20020478 <board_pinmux_sd>
20020ba2:	f000 fb59 	bl	20021258 <sdio_sd_init>
20020ba6:	2801      	cmp	r0, #1
20020ba8:	d111      	bne.n	20020bce <boot_device_init+0x2a2>
20020baa:	4b25      	ldr	r3, [pc, #148]	@ (20020c40 <boot_device_init+0x314>)
20020bac:	6023      	str	r3, [r4, #0]
20020bae:	4b25      	ldr	r3, [pc, #148]	@ (20020c44 <boot_device_init+0x318>)
20020bb0:	4a16      	ldr	r2, [pc, #88]	@ (20020c0c <boot_device_init+0x2e0>)
20020bb2:	6013      	str	r3, [r2, #0]
20020bb4:	2200      	movs	r2, #0
20020bb6:	4b16      	ldr	r3, [pc, #88]	@ (20020c10 <boot_device_init+0x2e4>)
20020bb8:	601a      	str	r2, [r3, #0]
20020bba:	e751      	b.n	20020a60 <boot_device_init+0x134>
20020bbc:	f7ff fc5c 	bl	20020478 <board_pinmux_sd>
20020bc0:	f000 fa1c 	bl	20020ffc <sdio_emmc_init>
20020bc4:	4b20      	ldr	r3, [pc, #128]	@ (20020c48 <boot_device_init+0x31c>)
20020bc6:	6018      	str	r0, [r3, #0]
20020bc8:	b908      	cbnz	r0, 20020bce <boot_device_init+0x2a2>
20020bca:	4b20      	ldr	r3, [pc, #128]	@ (20020c4c <boot_device_init+0x320>)
20020bcc:	e7ee      	b.n	20020bac <boot_device_init+0x280>
20020bce:	2300      	movs	r3, #0
20020bd0:	e7ee      	b.n	20020bb0 <boot_device_init+0x284>
20020bd2:	481f      	ldr	r0, [pc, #124]	@ (20020c50 <boot_device_init+0x324>)
20020bd4:	f004 ff16 	bl	20025a04 <iprintf>
20020bd8:	e742      	b.n	20020a60 <boot_device_init+0x134>
20020bda:	bf00      	nop
20020bdc:	20044a24 	.word	0x20044a24
20020be0:	112a8800 	.word	0x112a8800
20020be4:	20046d3c 	.word	0x20046d3c
20020be8:	20026a24 	.word	0x20026a24
20020bec:	5008101c 	.word	0x5008101c
20020bf0:	20046f70 	.word	0x20046f70
20020bf4:	20020621 	.word	0x20020621
20020bf8:	20046db0 	.word	0x20046db0
20020bfc:	20046d38 	.word	0x20046d38
20020c00:	2002059d 	.word	0x2002059d
20020c04:	20020549 	.word	0x20020549
20020c08:	20046d34 	.word	0x20046d34
20020c0c:	20046d2c 	.word	0x20046d2c
20020c10:	20046d30 	.word	0x20046d30
20020c14:	20026a38 	.word	0x20026a38
20020c18:	50081008 	.word	0x50081008
20020c1c:	20046d40 	.word	0x20046d40
20020c20:	20047138 	.word	0x20047138
20020c24:	53454346 	.word	0x53454346
20020c28:	20026a4c 	.word	0x20026a4c
20020c2c:	20020635 	.word	0x20020635
20020c30:	20045aac 	.word	0x20045aac
20020c34:	20046e20 	.word	0x20046e20
20020c38:	20047018 	.word	0x20047018
20020c3c:	20044a2c 	.word	0x20044a2c
20020c40:	200206b5 	.word	0x200206b5
20020c44:	64001000 	.word	0x64001000
20020c48:	20044a28 	.word	0x20044a28
20020c4c:	20020745 	.word	0x20020745
20020c50:	20026504 	.word	0x20026504
20020c54:	20042c04 	.word	0x20042c04
20020c58:	20042c00 	.word	0x20042c00
20020c5c:	4a0c      	ldr	r2, [pc, #48]	@ (20020c90 <boot_device_init+0x364>)
20020c5e:	4629      	mov	r1, r5
20020c60:	6013      	str	r3, [r2, #0]
20020c62:	4b0c      	ldr	r3, [pc, #48]	@ (20020c94 <boot_device_init+0x368>)
20020c64:	6830      	ldr	r0, [r6, #0]
20020c66:	681a      	ldr	r2, [r3, #0]
20020c68:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20020c6c:	f043 0301 	orr.w	r3, r3, #1
20020c70:	f882 302c 	strb.w	r3, [r2, #44]	@ 0x2c
20020c74:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020c78:	6823      	ldr	r3, [r4, #0]
20020c7a:	4798      	blx	r3
20020c7c:	e70c      	b.n	20020a98 <boot_device_init+0x16c>
20020c7e:	4806      	ldr	r0, [pc, #24]	@ (20020c98 <boot_device_init+0x36c>)
20020c80:	f004 fec0 	bl	20025a04 <iprintf>
20020c84:	2000      	movs	r0, #0
20020c86:	e708      	b.n	20020a9a <boot_device_init+0x16e>
20020c88:	7839      	ldrb	r1, [r7, #0]
20020c8a:	4804      	ldr	r0, [pc, #16]	@ (20020c9c <boot_device_init+0x370>)
20020c8c:	e7f8      	b.n	20020c80 <boot_device_init+0x354>
20020c8e:	bf00      	nop
20020c90:	20042c04 	.word	0x20042c04
20020c94:	20046d30 	.word	0x20046d30
20020c98:	20026518 	.word	0x20026518
20020c9c:	2002653e 	.word	0x2002653e

20020ca0 <sifli_hw_efuse_load_bank0>:
20020ca0:	2220      	movs	r2, #32
20020ca2:	b508      	push	{r3, lr}
20020ca4:	4904      	ldr	r1, [pc, #16]	@ (20020cb8 <sifli_hw_efuse_load_bank0+0x18>)
20020ca6:	2000      	movs	r0, #0
20020ca8:	f001 fb34 	bl	20022314 <HAL_EFUSE_Read>
20020cac:	2800      	cmp	r0, #0
20020cae:	4802      	ldr	r0, [pc, #8]	@ (20020cb8 <sifli_hw_efuse_load_bank0+0x18>)
20020cb0:	bf08      	it	eq
20020cb2:	2000      	moveq	r0, #0
20020cb4:	bd08      	pop	{r3, pc}
20020cb6:	bf00      	nop
20020cb8:	20047114 	.word	0x20047114

20020cbc <update_sec_flash>:
20020cbc:	b570      	push	{r4, r5, r6, lr}
20020cbe:	4604      	mov	r4, r0
20020cc0:	4b08      	ldr	r3, [pc, #32]	@ (20020ce4 <update_sec_flash+0x28>)
20020cc2:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20020cc6:	681d      	ldr	r5, [r3, #0]
20020cc8:	4b07      	ldr	r3, [pc, #28]	@ (20020ce8 <update_sec_flash+0x2c>)
20020cca:	4628      	mov	r0, r5
20020ccc:	681b      	ldr	r3, [r3, #0]
20020cce:	4798      	blx	r3
20020cd0:	4b06      	ldr	r3, [pc, #24]	@ (20020cec <update_sec_flash+0x30>)
20020cd2:	4621      	mov	r1, r4
20020cd4:	4628      	mov	r0, r5
20020cd6:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20020cda:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020cde:	681b      	ldr	r3, [r3, #0]
20020ce0:	4718      	bx	r3
20020ce2:	bf00      	nop
20020ce4:	20046d2c 	.word	0x20046d2c
20020ce8:	20046d34 	.word	0x20046d34
20020cec:	20046d3c 	.word	0x20046d3c

20020cf0 <boot_images_help>:
20020cf0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020cf4:	4e55      	ldr	r6, [pc, #340]	@ (20020e4c <boot_images_help+0x15c>)
20020cf6:	f8df a164 	ldr.w	sl, [pc, #356]	@ 20020e5c <boot_images_help+0x16c>
20020cfa:	6833      	ldr	r3, [r6, #0]
20020cfc:	b085      	sub	sp, #20
20020cfe:	4553      	cmp	r3, sl
20020d00:	d156      	bne.n	20020db0 <boot_images_help+0xc0>
20020d02:	2208      	movs	r2, #8
20020d04:	2300      	movs	r3, #0
20020d06:	f8df b158 	ldr.w	fp, [pc, #344]	@ 20020e60 <boot_images_help+0x170>
20020d0a:	eb0d 0102 	add.w	r1, sp, r2
20020d0e:	e9cd 3302 	strd	r3, r3, [sp, #8]
20020d12:	484f      	ldr	r0, [pc, #316]	@ (20020e50 <boot_images_help+0x160>)
20020d14:	f8db 3000 	ldr.w	r3, [fp]
20020d18:	4798      	blx	r3
20020d1a:	2008      	movs	r0, #8
20020d1c:	f006 ff36 	bl	20027b8c <HAL_Get_backup>
20020d20:	4605      	mov	r5, r0
20020d22:	2005      	movs	r0, #5
20020d24:	f006 ff32 	bl	20027b8c <HAL_Get_backup>
20020d28:	f8df 9138 	ldr.w	r9, [pc, #312]	@ 20020e64 <boot_images_help+0x174>
20020d2c:	4949      	ldr	r1, [pc, #292]	@ (20020e54 <boot_images_help+0x164>)
20020d2e:	f8d9 4000 	ldr.w	r4, [r9]
20020d32:	f8df 8134 	ldr.w	r8, [pc, #308]	@ 20020e68 <boot_images_help+0x178>
20020d36:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d3a:	f8db 3000 	ldr.w	r3, [fp]
20020d3e:	4607      	mov	r7, r0
20020d40:	f8c8 1000 	str.w	r1, [r8]
20020d44:	4620      	mov	r0, r4
20020d46:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
20020d4a:	4798      	blx	r3
20020d4c:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
20020d50:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
20020d54:	4593      	cmp	fp, r2
20020d56:	d154      	bne.n	20020e02 <boot_images_help+0x112>
20020d58:	b2eb      	uxtb	r3, r5
20020d5a:	2b04      	cmp	r3, #4
20020d5c:	d02b      	beq.n	20020db6 <boot_images_help+0xc6>
20020d5e:	2b06      	cmp	r3, #6
20020d60:	d03f      	beq.n	20020de2 <boot_images_help+0xf2>
20020d62:	2b01      	cmp	r3, #1
20020d64:	d148      	bne.n	20020df8 <boot_images_help+0x108>
20020d66:	2005      	movs	r0, #5
20020d68:	f006 ff10 	bl	20027b8c <HAL_Get_backup>
20020d6c:	2802      	cmp	r0, #2
20020d6e:	d006      	beq.n	20020d7e <boot_images_help+0x8e>
20020d70:	9b02      	ldr	r3, [sp, #8]
20020d72:	4553      	cmp	r3, sl
20020d74:	d106      	bne.n	20020d84 <boot_images_help+0x94>
20020d76:	f89d 300d 	ldrb.w	r3, [sp, #13]
20020d7a:	2b7f      	cmp	r3, #127	@ 0x7f
20020d7c:	d102      	bne.n	20020d84 <boot_images_help+0x94>
20020d7e:	4b36      	ldr	r3, [pc, #216]	@ (20020e58 <boot_images_help+0x168>)
20020d80:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
20020d84:	f7ff fbcf 	bl	20020526 <board_init_psram>
20020d88:	f8d6 3200 	ldr.w	r3, [r6, #512]	@ 0x200
20020d8c:	3301      	adds	r3, #1
20020d8e:	d002      	beq.n	20020d96 <boot_images_help+0xa6>
20020d90:	200b      	movs	r0, #11
20020d92:	f000 fc2d 	bl	200215f0 <dfu_boot_img_in_flash>
20020d96:	f8d6 0c08 	ldr.w	r0, [r6, #3080]	@ 0xc08
20020d9a:	1c43      	adds	r3, r0, #1
20020d9c:	d008      	beq.n	20020db0 <boot_images_help+0xc0>
20020d9e:	f8d9 3000 	ldr.w	r3, [r9]
20020da2:	1ac0      	subs	r0, r0, r3
20020da4:	f5a0 5080 	sub.w	r0, r0, #4096	@ 0x1000
20020da8:	0a40      	lsrs	r0, r0, #9
20020daa:	3002      	adds	r0, #2
20020dac:	f000 fc20 	bl	200215f0 <dfu_boot_img_in_flash>
20020db0:	b005      	add	sp, #20
20020db2:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020db6:	2008      	movs	r0, #8
20020db8:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020dbc:	2106      	movs	r1, #6
20020dbe:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20020dc2:	f006 fedd 	bl	20027b80 <HAL_Set_backup>
20020dc6:	f8d8 0000 	ldr.w	r0, [r8]
20020dca:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020dce:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20020dd2:	b11f      	cbz	r7, 20020ddc <boot_images_help+0xec>
20020dd4:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020dd8:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20020ddc:	f7ff ff6e 	bl	20020cbc <update_sec_flash>
20020de0:	e7c1      	b.n	20020d66 <boot_images_help+0x76>
20020de2:	2101      	movs	r1, #1
20020de4:	2008      	movs	r0, #8
20020de6:	f006 fecb 	bl	20027b80 <HAL_Set_backup>
20020dea:	f8d8 0000 	ldr.w	r0, [r8]
20020dee:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020df2:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
20020df6:	e7f1      	b.n	20020ddc <boot_images_help+0xec>
20020df8:	2101      	movs	r1, #1
20020dfa:	2008      	movs	r0, #8
20020dfc:	f006 fec0 	bl	20027b80 <HAL_Set_backup>
20020e00:	e7b1      	b.n	20020d66 <boot_images_help+0x76>
20020e02:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020e06:	45a3      	cmp	fp, r4
20020e08:	d1ad      	bne.n	20020d66 <boot_images_help+0x76>
20020e0a:	b2eb      	uxtb	r3, r5
20020e0c:	2b03      	cmp	r3, #3
20020e0e:	d005      	beq.n	20020e1c <boot_images_help+0x12c>
20020e10:	2b05      	cmp	r3, #5
20020e12:	d018      	beq.n	20020e46 <boot_images_help+0x156>
20020e14:	2b02      	cmp	r3, #2
20020e16:	d0a6      	beq.n	20020d66 <boot_images_help+0x76>
20020e18:	2102      	movs	r1, #2
20020e1a:	e7ee      	b.n	20020dfa <boot_images_help+0x10a>
20020e1c:	2008      	movs	r0, #8
20020e1e:	2105      	movs	r1, #5
20020e20:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20020e24:	9201      	str	r2, [sp, #4]
20020e26:	f006 feab 	bl	20027b80 <HAL_Set_backup>
20020e2a:	f8d8 0000 	ldr.w	r0, [r8]
20020e2e:	9a01      	ldr	r2, [sp, #4]
20020e30:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020e34:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
20020e38:	2f00      	cmp	r7, #0
20020e3a:	d0cf      	beq.n	20020ddc <boot_images_help+0xec>
20020e3c:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020e40:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20020e44:	e7ca      	b.n	20020ddc <boot_images_help+0xec>
20020e46:	2102      	movs	r1, #2
20020e48:	e7cc      	b.n	20020de4 <boot_images_help+0xf4>
20020e4a:	bf00      	nop
20020e4c:	20047138 	.word	0x20047138
20020e50:	147c0000 	.word	0x147c0000
20020e54:	20049d4c 	.word	0x20049d4c
20020e58:	14001000 	.word	0x14001000
20020e5c:	53454346 	.word	0x53454346
20020e60:	20046d3c 	.word	0x20046d3c
20020e64:	20046d2c 	.word	0x20046d2c
20020e68:	20049d48 	.word	0x20049d48

20020e6c <_write>:
20020e6c:	2802      	cmp	r0, #2
20020e6e:	b510      	push	{r4, lr}
20020e70:	4614      	mov	r4, r2
20020e72:	dc04      	bgt.n	20020e7e <_write+0x12>
20020e74:	4803      	ldr	r0, [pc, #12]	@ (20020e84 <_write+0x18>)
20020e76:	f7ff fa0d 	bl	20020294 <boot_uart_tx>
20020e7a:	4620      	mov	r0, r4
20020e7c:	bd10      	pop	{r4, pc}
20020e7e:	f04f 34ff 	mov.w	r4, #4294967295
20020e82:	e7fa      	b.n	20020e7a <_write+0xe>
20020e84:	50084000 	.word	0x50084000

20020e88 <entry>:
20020e88:	b508      	push	{r3, lr}
20020e8a:	f000 fb89 	bl	200215a0 <sboot_init>
20020e8e:	f7ff fb3e 	bl	2002050e <board_init>
20020e92:	f7ff fb35 	bl	20020500 <board_boot_from>
20020e96:	4b04      	ldr	r3, [pc, #16]	@ (20020ea8 <entry+0x20>)
20020e98:	7018      	strb	r0, [r3, #0]
20020e9a:	f7ff fd47 	bl	2002092c <boot_device_init>
20020e9e:	b108      	cbz	r0, 20020ea4 <entry+0x1c>
20020ea0:	f7ff ff26 	bl	20020cf0 <boot_images_help>
20020ea4:	e7fe      	b.n	20020ea4 <entry+0x1c>
20020ea6:	bf00      	nop
20020ea8:	20044a24 	.word	0x20044a24

20020eac <sd1_init>:
20020eac:	b510      	push	{r4, lr}
20020eae:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20020eb2:	68e3      	ldr	r3, [r4, #12]
20020eb4:	2064      	movs	r0, #100	@ 0x64
20020eb6:	f023 0310 	bic.w	r3, r3, #16
20020eba:	60e3      	str	r3, [r4, #12]
20020ebc:	f000 fd79 	bl	200219b2 <HAL_Delay_us>
20020ec0:	f44f 7280 	mov.w	r2, #256	@ 0x100
20020ec4:	68e3      	ldr	r3, [r4, #12]
20020ec6:	f043 0310 	orr.w	r3, r3, #16
20020eca:	60e3      	str	r3, [r4, #12]
20020ecc:	4b02      	ldr	r3, [pc, #8]	@ (20020ed8 <sd1_init+0x2c>)
20020ece:	631a      	str	r2, [r3, #48]	@ 0x30
20020ed0:	2200      	movs	r2, #0
20020ed2:	63da      	str	r2, [r3, #60]	@ 0x3c
20020ed4:	bd10      	pop	{r4, pc}
20020ed6:	bf00      	nop
20020ed8:	50045000 	.word	0x50045000

20020edc <sd1_wait_cmd>:
20020edc:	4b08      	ldr	r3, [pc, #32]	@ (20020f00 <sd1_wait_cmd+0x24>)
20020ede:	681a      	ldr	r2, [r3, #0]
20020ee0:	f012 0f0a 	tst.w	r2, #10
20020ee4:	d0fb      	beq.n	20020ede <sd1_wait_cmd+0x2>
20020ee6:	2202      	movs	r2, #2
20020ee8:	601a      	str	r2, [r3, #0]
20020eea:	681a      	ldr	r2, [r3, #0]
20020eec:	0712      	lsls	r2, r2, #28
20020eee:	bf5f      	itttt	pl
20020ef0:	6818      	ldrpl	r0, [r3, #0]
20020ef2:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20020ef6:	0040      	lslpl	r0, r0, #1
20020ef8:	b2c0      	uxtbpl	r0, r0
20020efa:	bf48      	it	mi
20020efc:	2001      	movmi	r0, #1
20020efe:	4770      	bx	lr
20020f00:	50045000 	.word	0x50045000

20020f04 <sd1_send_cmd>:
20020f04:	b538      	push	{r3, r4, r5, lr}
20020f06:	4604      	mov	r4, r0
20020f08:	460d      	mov	r5, r1
20020f0a:	4b11      	ldr	r3, [pc, #68]	@ (20020f50 <sd1_send_cmd+0x4c>)
20020f0c:	6818      	ldr	r0, [r3, #0]
20020f0e:	f000 fd50 	bl	200219b2 <HAL_Delay_us>
20020f12:	4b10      	ldr	r3, [pc, #64]	@ (20020f54 <sd1_send_cmd+0x50>)
20020f14:	2c0f      	cmp	r4, #15
20020f16:	609d      	str	r5, [r3, #8]
20020f18:	ea4f 4384 	mov.w	r3, r4, lsl #18
20020f1c:	d815      	bhi.n	20020f4a <sd1_send_cmd+0x46>
20020f1e:	2201      	movs	r2, #1
20020f20:	f248 0111 	movw	r1, #32785	@ 0x8011
20020f24:	40a2      	lsls	r2, r4
20020f26:	420a      	tst	r2, r1
20020f28:	d105      	bne.n	20020f36 <sd1_send_cmd+0x32>
20020f2a:	f240 6104 	movw	r1, #1540	@ 0x604
20020f2e:	420a      	tst	r2, r1
20020f30:	d00b      	beq.n	20020f4a <sd1_send_cmd+0x46>
20020f32:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
20020f36:	4a07      	ldr	r2, [pc, #28]	@ (20020f54 <sd1_send_cmd+0x50>)
20020f38:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
20020f3c:	f043 0301 	orr.w	r3, r3, #1
20020f40:	6053      	str	r3, [r2, #4]
20020f42:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20020f46:	f7ff bfc9 	b.w	20020edc <sd1_wait_cmd>
20020f4a:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20020f4e:	e7f2      	b.n	20020f36 <sd1_send_cmd+0x32>
20020f50:	20042c08 	.word	0x20042c08
20020f54:	50045000 	.word	0x50045000

20020f58 <sd1_send_acmd>:
20020f58:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20020f5a:	4605      	mov	r5, r0
20020f5c:	460f      	mov	r7, r1
20020f5e:	2037      	movs	r0, #55	@ 0x37
20020f60:	0411      	lsls	r1, r2, #16
20020f62:	f7ff ffcf 	bl	20020f04 <sd1_send_cmd>
20020f66:	4604      	mov	r4, r0
20020f68:	b968      	cbnz	r0, 20020f86 <sd1_send_acmd+0x2e>
20020f6a:	4b08      	ldr	r3, [pc, #32]	@ (20020f8c <sd1_send_acmd+0x34>)
20020f6c:	4e08      	ldr	r6, [pc, #32]	@ (20020f90 <sd1_send_acmd+0x38>)
20020f6e:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
20020f72:	60b7      	str	r7, [r6, #8]
20020f74:	6073      	str	r3, [r6, #4]
20020f76:	f7ff ffb1 	bl	20020edc <sd1_wait_cmd>
20020f7a:	2802      	cmp	r0, #2
20020f7c:	d104      	bne.n	20020f88 <sd1_send_acmd+0x30>
20020f7e:	2d29      	cmp	r5, #41	@ 0x29
20020f80:	d102      	bne.n	20020f88 <sd1_send_acmd+0x30>
20020f82:	2304      	movs	r3, #4
20020f84:	6033      	str	r3, [r6, #0]
20020f86:	4620      	mov	r0, r4
20020f88:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20020f8a:	bf00      	nop
20020f8c:	00010101 	.word	0x00010101
20020f90:	50045000 	.word	0x50045000

20020f94 <sd1_get_rsp>:
20020f94:	b530      	push	{r4, r5, lr}
20020f96:	4c06      	ldr	r4, [pc, #24]	@ (20020fb0 <sd1_get_rsp+0x1c>)
20020f98:	68e5      	ldr	r5, [r4, #12]
20020f9a:	7005      	strb	r5, [r0, #0]
20020f9c:	6920      	ldr	r0, [r4, #16]
20020f9e:	6008      	str	r0, [r1, #0]
20020fa0:	6961      	ldr	r1, [r4, #20]
20020fa2:	6011      	str	r1, [r2, #0]
20020fa4:	69a2      	ldr	r2, [r4, #24]
20020fa6:	601a      	str	r2, [r3, #0]
20020fa8:	69e2      	ldr	r2, [r4, #28]
20020faa:	9b03      	ldr	r3, [sp, #12]
20020fac:	601a      	str	r2, [r3, #0]
20020fae:	bd30      	pop	{r4, r5, pc}
20020fb0:	50045000 	.word	0x50045000

20020fb4 <sd1_read>:
20020fb4:	f04f 33ff 	mov.w	r3, #4294967295
20020fb8:	4a04      	ldr	r2, [pc, #16]	@ (20020fcc <sd1_read+0x18>)
20020fba:	eb03 2341 	add.w	r3, r3, r1, lsl #9
20020fbe:	6293      	str	r3, [r2, #40]	@ 0x28
20020fc0:	4b03      	ldr	r3, [pc, #12]	@ (20020fd0 <sd1_read+0x1c>)
20020fc2:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20020fc6:	6253      	str	r3, [r2, #36]	@ 0x24
20020fc8:	4770      	bx	lr
20020fca:	bf00      	nop
20020fcc:	50045000 	.word	0x50045000
20020fd0:	01ff0301 	.word	0x01ff0301

20020fd4 <sd1_wait_read>:
20020fd4:	4b08      	ldr	r3, [pc, #32]	@ (20020ff8 <sd1_wait_read+0x24>)
20020fd6:	681a      	ldr	r2, [r3, #0]
20020fd8:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20020fdc:	d0fb      	beq.n	20020fd6 <sd1_wait_read+0x2>
20020fde:	2220      	movs	r2, #32
20020fe0:	601a      	str	r2, [r3, #0]
20020fe2:	681a      	ldr	r2, [r3, #0]
20020fe4:	0612      	lsls	r2, r2, #24
20020fe6:	bf5f      	itttt	pl
20020fe8:	6818      	ldrpl	r0, [r3, #0]
20020fea:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
20020fee:	0040      	lslpl	r0, r0, #1
20020ff0:	b2c0      	uxtbpl	r0, r0
20020ff2:	bf48      	it	mi
20020ff4:	2001      	movmi	r0, #1
20020ff6:	4770      	bx	lr
20020ff8:	50045000 	.word	0x50045000

20020ffc <sdio_emmc_init>:
20020ffc:	b530      	push	{r4, r5, lr}
20020ffe:	b08d      	sub	sp, #52	@ 0x34
20021000:	f7ff ff54 	bl	20020eac <sd1_init>
20021004:	4c6c      	ldr	r4, [pc, #432]	@ (200211b8 <sdio_emmc_init+0x1bc>)
20021006:	4b6d      	ldr	r3, [pc, #436]	@ (200211bc <sdio_emmc_init+0x1c0>)
20021008:	2500      	movs	r5, #0
2002100a:	6323      	str	r3, [r4, #48]	@ 0x30
2002100c:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002100e:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021012:	f043 0302 	orr.w	r3, r3, #2
20021016:	6323      	str	r3, [r4, #48]	@ 0x30
20021018:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
2002101c:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002101e:	6223      	str	r3, [r4, #32]
20021020:	f000 fcc7 	bl	200219b2 <HAL_Delay_us>
20021024:	4629      	mov	r1, r5
20021026:	4628      	mov	r0, r5
20021028:	f7ff ff6c 	bl	20020f04 <sd1_send_cmd>
2002102c:	2301      	movs	r3, #1
2002102e:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021030:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021032:	0799      	lsls	r1, r3, #30
20021034:	d5fc      	bpl.n	20021030 <sdio_emmc_init+0x34>
20021036:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021038:	f043 0320 	orr.w	r3, r3, #32
2002103c:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002103e:	4960      	ldr	r1, [pc, #384]	@ (200211c0 <sdio_emmc_init+0x1c4>)
20021040:	2001      	movs	r0, #1
20021042:	ad07      	add	r5, sp, #28
20021044:	f7ff ff5e 	bl	20020f04 <sd1_send_cmd>
20021048:	ab06      	add	r3, sp, #24
2002104a:	aa05      	add	r2, sp, #20
2002104c:	a904      	add	r1, sp, #16
2002104e:	f10d 000f 	add.w	r0, sp, #15
20021052:	9500      	str	r5, [sp, #0]
20021054:	f7ff ff9e 	bl	20020f94 <sd1_get_rsp>
20021058:	2014      	movs	r0, #20
2002105a:	f000 fcaa 	bl	200219b2 <HAL_Delay_us>
2002105e:	9b04      	ldr	r3, [sp, #16]
20021060:	2b00      	cmp	r3, #0
20021062:	daec      	bge.n	2002103e <sdio_emmc_init+0x42>
20021064:	4a57      	ldr	r2, [pc, #348]	@ (200211c4 <sdio_emmc_init+0x1c8>)
20021066:	f3c3 7380 	ubfx	r3, r3, #30, #1
2002106a:	f083 0301 	eor.w	r3, r3, #1
2002106e:	2100      	movs	r1, #0
20021070:	2002      	movs	r0, #2
20021072:	7013      	strb	r3, [r2, #0]
20021074:	f7ff ff46 	bl	20020f04 <sd1_send_cmd>
20021078:	2801      	cmp	r0, #1
2002107a:	f000 8081 	beq.w	20021180 <sdio_emmc_init+0x184>
2002107e:	2802      	cmp	r0, #2
20021080:	d07e      	beq.n	20021180 <sdio_emmc_init+0x184>
20021082:	ab08      	add	r3, sp, #32
20021084:	9300      	str	r3, [sp, #0]
20021086:	aa0a      	add	r2, sp, #40	@ 0x28
20021088:	ab09      	add	r3, sp, #36	@ 0x24
2002108a:	a90b      	add	r1, sp, #44	@ 0x2c
2002108c:	f10d 000f 	add.w	r0, sp, #15
20021090:	f7ff ff80 	bl	20020f94 <sd1_get_rsp>
20021094:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021098:	2003      	movs	r0, #3
2002109a:	f7ff ff33 	bl	20020f04 <sd1_send_cmd>
2002109e:	2801      	cmp	r0, #1
200210a0:	d070      	beq.n	20021184 <sdio_emmc_init+0x188>
200210a2:	2802      	cmp	r0, #2
200210a4:	d070      	beq.n	20021188 <sdio_emmc_init+0x18c>
200210a6:	ab06      	add	r3, sp, #24
200210a8:	9500      	str	r5, [sp, #0]
200210aa:	aa05      	add	r2, sp, #20
200210ac:	a904      	add	r1, sp, #16
200210ae:	f10d 000f 	add.w	r0, sp, #15
200210b2:	f7ff ff6f 	bl	20020f94 <sd1_get_rsp>
200210b6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200210ba:	2b03      	cmp	r3, #3
200210bc:	d166      	bne.n	2002118c <sdio_emmc_init+0x190>
200210be:	4c3e      	ldr	r4, [pc, #248]	@ (200211b8 <sdio_emmc_init+0x1bc>)
200210c0:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210c4:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
200210c6:	2009      	movs	r0, #9
200210c8:	f023 0320 	bic.w	r3, r3, #32
200210cc:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210ce:	f7ff ff19 	bl	20020f04 <sd1_send_cmd>
200210d2:	2801      	cmp	r0, #1
200210d4:	d05c      	beq.n	20021190 <sdio_emmc_init+0x194>
200210d6:	2802      	cmp	r0, #2
200210d8:	d05c      	beq.n	20021194 <sdio_emmc_init+0x198>
200210da:	ab06      	add	r3, sp, #24
200210dc:	aa05      	add	r2, sp, #20
200210de:	a904      	add	r1, sp, #16
200210e0:	f10d 000f 	add.w	r0, sp, #15
200210e4:	9500      	str	r5, [sp, #0]
200210e6:	f7ff ff55 	bl	20020f94 <sd1_get_rsp>
200210ea:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
200210ee:	6323      	str	r3, [r4, #48]	@ 0x30
200210f0:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200210f2:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210f6:	f043 0302 	orr.w	r3, r3, #2
200210fa:	6323      	str	r3, [r4, #48]	@ 0x30
200210fc:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
20021100:	6223      	str	r3, [r4, #32]
20021102:	2300      	movs	r3, #0
20021104:	2007      	movs	r0, #7
20021106:	63e3      	str	r3, [r4, #60]	@ 0x3c
20021108:	f7ff fefc 	bl	20020f04 <sd1_send_cmd>
2002110c:	2801      	cmp	r0, #1
2002110e:	d043      	beq.n	20021198 <sdio_emmc_init+0x19c>
20021110:	2802      	cmp	r0, #2
20021112:	d043      	beq.n	2002119c <sdio_emmc_init+0x1a0>
20021114:	ab06      	add	r3, sp, #24
20021116:	9500      	str	r5, [sp, #0]
20021118:	aa05      	add	r2, sp, #20
2002111a:	a904      	add	r1, sp, #16
2002111c:	f10d 000f 	add.w	r0, sp, #15
20021120:	f7ff ff38 	bl	20020f94 <sd1_get_rsp>
20021124:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021128:	2b07      	cmp	r3, #7
2002112a:	d139      	bne.n	200211a0 <sdio_emmc_init+0x1a4>
2002112c:	2101      	movs	r1, #1
2002112e:	2000      	movs	r0, #0
20021130:	f7ff ff40 	bl	20020fb4 <sd1_read>
20021134:	f04f 33ff 	mov.w	r3, #4294967295
20021138:	2100      	movs	r1, #0
2002113a:	2011      	movs	r0, #17
2002113c:	6023      	str	r3, [r4, #0]
2002113e:	f7ff fee1 	bl	20020f04 <sd1_send_cmd>
20021142:	2801      	cmp	r0, #1
20021144:	d02e      	beq.n	200211a4 <sdio_emmc_init+0x1a8>
20021146:	2802      	cmp	r0, #2
20021148:	d02e      	beq.n	200211a8 <sdio_emmc_init+0x1ac>
2002114a:	ab06      	add	r3, sp, #24
2002114c:	9500      	str	r5, [sp, #0]
2002114e:	aa05      	add	r2, sp, #20
20021150:	a904      	add	r1, sp, #16
20021152:	f10d 000f 	add.w	r0, sp, #15
20021156:	f7ff ff1d 	bl	20020f94 <sd1_get_rsp>
2002115a:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002115e:	2b11      	cmp	r3, #17
20021160:	d124      	bne.n	200211ac <sdio_emmc_init+0x1b0>
20021162:	2320      	movs	r3, #32
20021164:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021166:	f7ff ff35 	bl	20020fd4 <sd1_wait_read>
2002116a:	6823      	ldr	r3, [r4, #0]
2002116c:	061a      	lsls	r2, r3, #24
2002116e:	d41f      	bmi.n	200211b0 <sdio_emmc_init+0x1b4>
20021170:	6823      	ldr	r3, [r4, #0]
20021172:	065b      	lsls	r3, r3, #25
20021174:	d41e      	bmi.n	200211b4 <sdio_emmc_init+0x1b8>
20021176:	2080      	movs	r0, #128	@ 0x80
20021178:	3801      	subs	r0, #1
2002117a:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
2002117e:	d1fb      	bne.n	20021178 <sdio_emmc_init+0x17c>
20021180:	b00d      	add	sp, #52	@ 0x34
20021182:	bd30      	pop	{r4, r5, pc}
20021184:	2003      	movs	r0, #3
20021186:	e7fb      	b.n	20021180 <sdio_emmc_init+0x184>
20021188:	2004      	movs	r0, #4
2002118a:	e7f9      	b.n	20021180 <sdio_emmc_init+0x184>
2002118c:	2005      	movs	r0, #5
2002118e:	e7f7      	b.n	20021180 <sdio_emmc_init+0x184>
20021190:	2006      	movs	r0, #6
20021192:	e7f5      	b.n	20021180 <sdio_emmc_init+0x184>
20021194:	2007      	movs	r0, #7
20021196:	e7f3      	b.n	20021180 <sdio_emmc_init+0x184>
20021198:	2008      	movs	r0, #8
2002119a:	e7f1      	b.n	20021180 <sdio_emmc_init+0x184>
2002119c:	2009      	movs	r0, #9
2002119e:	e7ef      	b.n	20021180 <sdio_emmc_init+0x184>
200211a0:	200a      	movs	r0, #10
200211a2:	e7ed      	b.n	20021180 <sdio_emmc_init+0x184>
200211a4:	2012      	movs	r0, #18
200211a6:	e7eb      	b.n	20021180 <sdio_emmc_init+0x184>
200211a8:	2013      	movs	r0, #19
200211aa:	e7e9      	b.n	20021180 <sdio_emmc_init+0x184>
200211ac:	2014      	movs	r0, #20
200211ae:	e7e7      	b.n	20021180 <sdio_emmc_init+0x184>
200211b0:	2015      	movs	r0, #21
200211b2:	e7e5      	b.n	20021180 <sdio_emmc_init+0x184>
200211b4:	2016      	movs	r0, #22
200211b6:	e7e3      	b.n	20021180 <sdio_emmc_init+0x184>
200211b8:	50045000 	.word	0x50045000
200211bc:	00016700 	.word	0x00016700
200211c0:	40000080 	.word	0x40000080
200211c4:	20042c0c 	.word	0x20042c0c

200211c8 <emmc_read_data>:
200211c8:	b570      	push	{r4, r5, r6, lr}
200211ca:	4606      	mov	r6, r0
200211cc:	460d      	mov	r5, r1
200211ce:	2000      	movs	r0, #0
200211d0:	2101      	movs	r1, #1
200211d2:	b088      	sub	sp, #32
200211d4:	4614      	mov	r4, r2
200211d6:	f7ff feed 	bl	20020fb4 <sd1_read>
200211da:	f04f 32ff 	mov.w	r2, #4294967295
200211de:	4b1c      	ldr	r3, [pc, #112]	@ (20021250 <emmc_read_data+0x88>)
200211e0:	601a      	str	r2, [r3, #0]
200211e2:	4b1c      	ldr	r3, [pc, #112]	@ (20021254 <emmc_read_data+0x8c>)
200211e4:	781b      	ldrb	r3, [r3, #0]
200211e6:	b903      	cbnz	r3, 200211ea <emmc_read_data+0x22>
200211e8:	0a76      	lsrs	r6, r6, #9
200211ea:	4631      	mov	r1, r6
200211ec:	2011      	movs	r0, #17
200211ee:	f7ff fe89 	bl	20020f04 <sd1_send_cmd>
200211f2:	3801      	subs	r0, #1
200211f4:	b2c0      	uxtb	r0, r0
200211f6:	2801      	cmp	r0, #1
200211f8:	d802      	bhi.n	20021200 <emmc_read_data+0x38>
200211fa:	2000      	movs	r0, #0
200211fc:	b008      	add	sp, #32
200211fe:	bd70      	pop	{r4, r5, r6, pc}
20021200:	ab07      	add	r3, sp, #28
20021202:	9300      	str	r3, [sp, #0]
20021204:	aa05      	add	r2, sp, #20
20021206:	ab06      	add	r3, sp, #24
20021208:	a904      	add	r1, sp, #16
2002120a:	f10d 000f 	add.w	r0, sp, #15
2002120e:	f7ff fec1 	bl	20020f94 <sd1_get_rsp>
20021212:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021216:	2b11      	cmp	r3, #17
20021218:	d1ef      	bne.n	200211fa <emmc_read_data+0x32>
2002121a:	f04f 33ff 	mov.w	r3, #4294967295
2002121e:	4e0c      	ldr	r6, [pc, #48]	@ (20021250 <emmc_read_data+0x88>)
20021220:	6033      	str	r3, [r6, #0]
20021222:	2320      	movs	r3, #32
20021224:	62f3      	str	r3, [r6, #44]	@ 0x2c
20021226:	f7ff fed5 	bl	20020fd4 <sd1_wait_read>
2002122a:	6833      	ldr	r3, [r6, #0]
2002122c:	061a      	lsls	r2, r3, #24
2002122e:	d4e4      	bmi.n	200211fa <emmc_read_data+0x32>
20021230:	6833      	ldr	r3, [r6, #0]
20021232:	065b      	lsls	r3, r3, #25
20021234:	d4e1      	bmi.n	200211fa <emmc_read_data+0x32>
20021236:	f024 0303 	bic.w	r3, r4, #3
2002123a:	442b      	add	r3, r5
2002123c:	429d      	cmp	r5, r3
2002123e:	d101      	bne.n	20021244 <emmc_read_data+0x7c>
20021240:	4620      	mov	r0, r4
20021242:	e7db      	b.n	200211fc <emmc_read_data+0x34>
20021244:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
20021248:	f845 2b04 	str.w	r2, [r5], #4
2002124c:	e7f6      	b.n	2002123c <emmc_read_data+0x74>
2002124e:	bf00      	nop
20021250:	50045000 	.word	0x50045000
20021254:	20042c0c 	.word	0x20042c0c

20021258 <sdio_sd_init>:
20021258:	b5f0      	push	{r4, r5, r6, r7, lr}
2002125a:	b08d      	sub	sp, #52	@ 0x34
2002125c:	f7ff fe26 	bl	20020eac <sd1_init>
20021260:	4c83      	ldr	r4, [pc, #524]	@ (20021470 <sdio_sd_init+0x218>)
20021262:	4b84      	ldr	r3, [pc, #528]	@ (20021474 <sdio_sd_init+0x21c>)
20021264:	2500      	movs	r5, #0
20021266:	6323      	str	r3, [r4, #48]	@ 0x30
20021268:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002126a:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
2002126e:	f043 0302 	orr.w	r3, r3, #2
20021272:	6323      	str	r3, [r4, #48]	@ 0x30
20021274:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20021278:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002127a:	6223      	str	r3, [r4, #32]
2002127c:	f000 fb99 	bl	200219b2 <HAL_Delay_us>
20021280:	4629      	mov	r1, r5
20021282:	4628      	mov	r0, r5
20021284:	f7ff fe3e 	bl	20020f04 <sd1_send_cmd>
20021288:	2301      	movs	r3, #1
2002128a:	65e3      	str	r3, [r4, #92]	@ 0x5c
2002128c:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
2002128e:	079a      	lsls	r2, r3, #30
20021290:	d5fc      	bpl.n	2002128c <sdio_sd_init+0x34>
20021292:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
20021296:	2008      	movs	r0, #8
20021298:	f7ff fe34 	bl	20020f04 <sd1_send_cmd>
2002129c:	3801      	subs	r0, #1
2002129e:	b2c0      	uxtb	r0, r0
200212a0:	2801      	cmp	r0, #1
200212a2:	d802      	bhi.n	200212aa <sdio_sd_init+0x52>
200212a4:	2038      	movs	r0, #56	@ 0x38
200212a6:	b00d      	add	sp, #52	@ 0x34
200212a8:	bdf0      	pop	{r4, r5, r6, r7, pc}
200212aa:	ac07      	add	r4, sp, #28
200212ac:	ab06      	add	r3, sp, #24
200212ae:	9400      	str	r4, [sp, #0]
200212b0:	aa05      	add	r2, sp, #20
200212b2:	a904      	add	r1, sp, #16
200212b4:	f10d 000f 	add.w	r0, sp, #15
200212b8:	f7ff fe6c 	bl	20020f94 <sd1_get_rsp>
200212bc:	f89d 300f 	ldrb.w	r3, [sp, #15]
200212c0:	2b08      	cmp	r3, #8
200212c2:	d1ef      	bne.n	200212a4 <sdio_sd_init+0x4c>
200212c4:	9b04      	ldr	r3, [sp, #16]
200212c6:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
200212ca:	d1eb      	bne.n	200212a4 <sdio_sd_init+0x4c>
200212cc:	2200      	movs	r2, #0
200212ce:	2029      	movs	r0, #41	@ 0x29
200212d0:	4969      	ldr	r1, [pc, #420]	@ (20021478 <sdio_sd_init+0x220>)
200212d2:	f7ff fe41 	bl	20020f58 <sd1_send_acmd>
200212d6:	2801      	cmp	r0, #1
200212d8:	f000 80bd 	beq.w	20021456 <sdio_sd_init+0x1fe>
200212dc:	ab06      	add	r3, sp, #24
200212de:	9400      	str	r4, [sp, #0]
200212e0:	aa05      	add	r2, sp, #20
200212e2:	a904      	add	r1, sp, #16
200212e4:	f10d 000f 	add.w	r0, sp, #15
200212e8:	f7ff fe54 	bl	20020f94 <sd1_get_rsp>
200212ec:	9b04      	ldr	r3, [sp, #16]
200212ee:	2b00      	cmp	r3, #0
200212f0:	db03      	blt.n	200212fa <sdio_sd_init+0xa2>
200212f2:	2002      	movs	r0, #2
200212f4:	f000 fb5d 	bl	200219b2 <HAL_Delay_us>
200212f8:	e7e8      	b.n	200212cc <sdio_sd_init+0x74>
200212fa:	2100      	movs	r1, #0
200212fc:	2002      	movs	r0, #2
200212fe:	f7ff fe01 	bl	20020f04 <sd1_send_cmd>
20021302:	3801      	subs	r0, #1
20021304:	b2c0      	uxtb	r0, r0
20021306:	2801      	cmp	r0, #1
20021308:	f240 80a7 	bls.w	2002145a <sdio_sd_init+0x202>
2002130c:	ab08      	add	r3, sp, #32
2002130e:	9300      	str	r3, [sp, #0]
20021310:	aa0a      	add	r2, sp, #40	@ 0x28
20021312:	ab09      	add	r3, sp, #36	@ 0x24
20021314:	a90b      	add	r1, sp, #44	@ 0x2c
20021316:	f10d 000f 	add.w	r0, sp, #15
2002131a:	f7ff fe3b 	bl	20020f94 <sd1_get_rsp>
2002131e:	2100      	movs	r1, #0
20021320:	2003      	movs	r0, #3
20021322:	f7ff fdef 	bl	20020f04 <sd1_send_cmd>
20021326:	3801      	subs	r0, #1
20021328:	b2c0      	uxtb	r0, r0
2002132a:	2801      	cmp	r0, #1
2002132c:	d801      	bhi.n	20021332 <sdio_sd_init+0xda>
2002132e:	2033      	movs	r0, #51	@ 0x33
20021330:	e7b9      	b.n	200212a6 <sdio_sd_init+0x4e>
20021332:	ab06      	add	r3, sp, #24
20021334:	9400      	str	r4, [sp, #0]
20021336:	aa05      	add	r2, sp, #20
20021338:	a904      	add	r1, sp, #16
2002133a:	f10d 000f 	add.w	r0, sp, #15
2002133e:	f7ff fe29 	bl	20020f94 <sd1_get_rsp>
20021342:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021346:	2b03      	cmp	r3, #3
20021348:	d1f1      	bne.n	2002132e <sdio_sd_init+0xd6>
2002134a:	9f04      	ldr	r7, [sp, #16]
2002134c:	2009      	movs	r0, #9
2002134e:	0c3d      	lsrs	r5, r7, #16
20021350:	042d      	lsls	r5, r5, #16
20021352:	4629      	mov	r1, r5
20021354:	f7ff fdd6 	bl	20020f04 <sd1_send_cmd>
20021358:	3801      	subs	r0, #1
2002135a:	b2c0      	uxtb	r0, r0
2002135c:	2801      	cmp	r0, #1
2002135e:	d97e      	bls.n	2002145e <sdio_sd_init+0x206>
20021360:	9400      	str	r4, [sp, #0]
20021362:	ab06      	add	r3, sp, #24
20021364:	aa05      	add	r2, sp, #20
20021366:	a904      	add	r1, sp, #16
20021368:	f10d 000f 	add.w	r0, sp, #15
2002136c:	f7ff fe12 	bl	20020f94 <sd1_get_rsp>
20021370:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021374:	9c06      	ldr	r4, [sp, #24]
20021376:	9907      	ldr	r1, [sp, #28]
20021378:	0e23      	lsrs	r3, r4, #24
2002137a:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
2002137e:	0e01      	lsrs	r1, r0, #24
20021380:	ea41 2104 	orr.w	r1, r1, r4, lsl #8
20021384:	9105      	str	r1, [sp, #20]
20021386:	0e11      	lsrs	r1, r2, #24
20021388:	9304      	str	r3, [sp, #16]
2002138a:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
2002138e:	0212      	lsls	r2, r2, #8
20021390:	0f9b      	lsrs	r3, r3, #30
20021392:	9106      	str	r1, [sp, #24]
20021394:	9207      	str	r2, [sp, #28]
20021396:	d01b      	beq.n	200213d0 <sdio_sd_init+0x178>
20021398:	2b01      	cmp	r3, #1
2002139a:	d162      	bne.n	20021462 <sdio_sd_init+0x20a>
2002139c:	2300      	movs	r3, #0
2002139e:	4a37      	ldr	r2, [pc, #220]	@ (2002147c <sdio_sd_init+0x224>)
200213a0:	4c33      	ldr	r4, [pc, #204]	@ (20021470 <sdio_sd_init+0x218>)
200213a2:	7013      	strb	r3, [r2, #0]
200213a4:	f44f 63a0 	mov.w	r3, #1280	@ 0x500
200213a8:	6323      	str	r3, [r4, #48]	@ 0x30
200213aa:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200213ac:	2600      	movs	r6, #0
200213ae:	f043 0302 	orr.w	r3, r3, #2
200213b2:	6323      	str	r3, [r4, #48]	@ 0x30
200213b4:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200213b8:	4629      	mov	r1, r5
200213ba:	6223      	str	r3, [r4, #32]
200213bc:	2007      	movs	r0, #7
200213be:	63e6      	str	r6, [r4, #60]	@ 0x3c
200213c0:	f7ff fda0 	bl	20020f04 <sd1_send_cmd>
200213c4:	3801      	subs	r0, #1
200213c6:	b2c0      	uxtb	r0, r0
200213c8:	2801      	cmp	r0, #1
200213ca:	d803      	bhi.n	200213d4 <sdio_sd_init+0x17c>
200213cc:	2037      	movs	r0, #55	@ 0x37
200213ce:	e76a      	b.n	200212a6 <sdio_sd_init+0x4e>
200213d0:	2301      	movs	r3, #1
200213d2:	e7e4      	b.n	2002139e <sdio_sd_init+0x146>
200213d4:	ad07      	add	r5, sp, #28
200213d6:	ab06      	add	r3, sp, #24
200213d8:	9500      	str	r5, [sp, #0]
200213da:	aa05      	add	r2, sp, #20
200213dc:	a904      	add	r1, sp, #16
200213de:	f10d 000f 	add.w	r0, sp, #15
200213e2:	f7ff fdd7 	bl	20020f94 <sd1_get_rsp>
200213e6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200213ea:	2b07      	cmp	r3, #7
200213ec:	d1ee      	bne.n	200213cc <sdio_sd_init+0x174>
200213ee:	4631      	mov	r1, r6
200213f0:	2006      	movs	r0, #6
200213f2:	0c3a      	lsrs	r2, r7, #16
200213f4:	f7ff fdb0 	bl	20020f58 <sd1_send_acmd>
200213f8:	3801      	subs	r0, #1
200213fa:	b2c0      	uxtb	r0, r0
200213fc:	2801      	cmp	r0, #1
200213fe:	d932      	bls.n	20021466 <sdio_sd_init+0x20e>
20021400:	2101      	movs	r1, #1
20021402:	4630      	mov	r0, r6
20021404:	f7ff fdd6 	bl	20020fb4 <sd1_read>
20021408:	4631      	mov	r1, r6
2002140a:	2011      	movs	r0, #17
2002140c:	f7ff fd7a 	bl	20020f04 <sd1_send_cmd>
20021410:	3801      	subs	r0, #1
20021412:	b2c0      	uxtb	r0, r0
20021414:	2801      	cmp	r0, #1
20021416:	d801      	bhi.n	2002141c <sdio_sd_init+0x1c4>
20021418:	2052      	movs	r0, #82	@ 0x52
2002141a:	e744      	b.n	200212a6 <sdio_sd_init+0x4e>
2002141c:	ab06      	add	r3, sp, #24
2002141e:	9500      	str	r5, [sp, #0]
20021420:	aa05      	add	r2, sp, #20
20021422:	a904      	add	r1, sp, #16
20021424:	f10d 000f 	add.w	r0, sp, #15
20021428:	f7ff fdb4 	bl	20020f94 <sd1_get_rsp>
2002142c:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021430:	2b11      	cmp	r3, #17
20021432:	d1f1      	bne.n	20021418 <sdio_sd_init+0x1c0>
20021434:	f04f 33ff 	mov.w	r3, #4294967295
20021438:	6023      	str	r3, [r4, #0]
2002143a:	2320      	movs	r3, #32
2002143c:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002143e:	f7ff fdc9 	bl	20020fd4 <sd1_wait_read>
20021442:	6823      	ldr	r3, [r4, #0]
20021444:	061b      	lsls	r3, r3, #24
20021446:	d410      	bmi.n	2002146a <sdio_sd_init+0x212>
20021448:	6823      	ldr	r3, [r4, #0]
2002144a:	f013 0f40 	tst.w	r3, #64	@ 0x40
2002144e:	bf14      	ite	ne
20021450:	2044      	movne	r0, #68	@ 0x44
20021452:	2001      	moveq	r0, #1
20021454:	e727      	b.n	200212a6 <sdio_sd_init+0x4e>
20021456:	2034      	movs	r0, #52	@ 0x34
20021458:	e725      	b.n	200212a6 <sdio_sd_init+0x4e>
2002145a:	2032      	movs	r0, #50	@ 0x32
2002145c:	e723      	b.n	200212a6 <sdio_sd_init+0x4e>
2002145e:	2039      	movs	r0, #57	@ 0x39
20021460:	e721      	b.n	200212a6 <sdio_sd_init+0x4e>
20021462:	2054      	movs	r0, #84	@ 0x54
20021464:	e71f      	b.n	200212a6 <sdio_sd_init+0x4e>
20021466:	2036      	movs	r0, #54	@ 0x36
20021468:	e71d      	b.n	200212a6 <sdio_sd_init+0x4e>
2002146a:	204f      	movs	r0, #79	@ 0x4f
2002146c:	e71b      	b.n	200212a6 <sdio_sd_init+0x4e>
2002146e:	bf00      	nop
20021470:	50045000 	.word	0x50045000
20021474:	00016700 	.word	0x00016700
20021478:	40ff8000 	.word	0x40ff8000
2002147c:	20042c0d 	.word	0x20042c0d

20021480 <sd_read_data>:
20021480:	b570      	push	{r4, r5, r6, lr}
20021482:	4606      	mov	r6, r0
20021484:	460d      	mov	r5, r1
20021486:	2000      	movs	r0, #0
20021488:	2101      	movs	r1, #1
2002148a:	b088      	sub	sp, #32
2002148c:	4614      	mov	r4, r2
2002148e:	f7ff fd91 	bl	20020fb4 <sd1_read>
20021492:	4b1b      	ldr	r3, [pc, #108]	@ (20021500 <sd_read_data+0x80>)
20021494:	781b      	ldrb	r3, [r3, #0]
20021496:	b903      	cbnz	r3, 2002149a <sd_read_data+0x1a>
20021498:	0a76      	lsrs	r6, r6, #9
2002149a:	4631      	mov	r1, r6
2002149c:	2011      	movs	r0, #17
2002149e:	f7ff fd31 	bl	20020f04 <sd1_send_cmd>
200214a2:	3801      	subs	r0, #1
200214a4:	b2c0      	uxtb	r0, r0
200214a6:	2801      	cmp	r0, #1
200214a8:	d802      	bhi.n	200214b0 <sd_read_data+0x30>
200214aa:	2000      	movs	r0, #0
200214ac:	b008      	add	sp, #32
200214ae:	bd70      	pop	{r4, r5, r6, pc}
200214b0:	ab07      	add	r3, sp, #28
200214b2:	9300      	str	r3, [sp, #0]
200214b4:	aa05      	add	r2, sp, #20
200214b6:	ab06      	add	r3, sp, #24
200214b8:	a904      	add	r1, sp, #16
200214ba:	f10d 000f 	add.w	r0, sp, #15
200214be:	f7ff fd69 	bl	20020f94 <sd1_get_rsp>
200214c2:	f89d 300f 	ldrb.w	r3, [sp, #15]
200214c6:	2b11      	cmp	r3, #17
200214c8:	d1ef      	bne.n	200214aa <sd_read_data+0x2a>
200214ca:	f04f 33ff 	mov.w	r3, #4294967295
200214ce:	4e0d      	ldr	r6, [pc, #52]	@ (20021504 <sd_read_data+0x84>)
200214d0:	6033      	str	r3, [r6, #0]
200214d2:	2320      	movs	r3, #32
200214d4:	62f3      	str	r3, [r6, #44]	@ 0x2c
200214d6:	f7ff fd7d 	bl	20020fd4 <sd1_wait_read>
200214da:	6833      	ldr	r3, [r6, #0]
200214dc:	061a      	lsls	r2, r3, #24
200214de:	d4e4      	bmi.n	200214aa <sd_read_data+0x2a>
200214e0:	6833      	ldr	r3, [r6, #0]
200214e2:	065b      	lsls	r3, r3, #25
200214e4:	d4e1      	bmi.n	200214aa <sd_read_data+0x2a>
200214e6:	f024 0303 	bic.w	r3, r4, #3
200214ea:	442b      	add	r3, r5
200214ec:	429d      	cmp	r5, r3
200214ee:	d101      	bne.n	200214f4 <sd_read_data+0x74>
200214f0:	4620      	mov	r0, r4
200214f2:	e7db      	b.n	200214ac <sd_read_data+0x2c>
200214f4:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
200214f8:	f845 2b04 	str.w	r2, [r5], #4
200214fc:	e7f6      	b.n	200214ec <sd_read_data+0x6c>
200214fe:	bf00      	nop
20021500:	20042c0d 	.word	0x20042c0d
20021504:	50045000 	.word	0x50045000

20021508 <is_addr_in_nor>:
20021508:	4b09      	ldr	r3, [pc, #36]	@ (20021530 <is_addr_in_nor+0x28>)
2002150a:	4602      	mov	r2, r0
2002150c:	681b      	ldr	r3, [r3, #0]
2002150e:	b163      	cbz	r3, 2002152a <is_addr_in_nor+0x22>
20021510:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
20021514:	b948      	cbnz	r0, 2002152a <is_addr_in_nor+0x22>
20021516:	6919      	ldr	r1, [r3, #16]
20021518:	4291      	cmp	r1, r2
2002151a:	d807      	bhi.n	2002152c <is_addr_in_nor+0x24>
2002151c:	695b      	ldr	r3, [r3, #20]
2002151e:	4419      	add	r1, r3
20021520:	4291      	cmp	r1, r2
20021522:	bf94      	ite	ls
20021524:	2000      	movls	r0, #0
20021526:	2001      	movhi	r0, #1
20021528:	4770      	bx	lr
2002152a:	2000      	movs	r0, #0
2002152c:	4770      	bx	lr
2002152e:	bf00      	nop
20021530:	20046d30 	.word	0x20046d30

20021534 <sifli_verify_img_cmac_hash>:
20021534:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20021538:	461d      	mov	r5, r3
2002153a:	4b16      	ldr	r3, [pc, #88]	@ (20021594 <sifli_verify_img_cmac_hash+0x60>)
2002153c:	460e      	mov	r6, r1
2002153e:	681b      	ldr	r3, [r3, #0]
20021540:	4617      	mov	r7, r2
20021542:	b092      	sub	sp, #72	@ 0x48
20021544:	b12b      	cbz	r3, 20021552 <sifli_verify_img_cmac_hash+0x1e>
20021546:	b920      	cbnz	r0, 20021552 <sifli_verify_img_cmac_hash+0x1e>
20021548:	2220      	movs	r2, #32
2002154a:	2002      	movs	r0, #2
2002154c:	4912      	ldr	r1, [pc, #72]	@ (20021598 <sifli_verify_img_cmac_hash+0x64>)
2002154e:	4798      	blx	r3
20021550:	4811      	ldr	r0, [pc, #68]	@ (20021598 <sifli_verify_img_cmac_hash+0x64>)
20021552:	4601      	mov	r1, r0
20021554:	2220      	movs	r2, #32
20021556:	a803      	add	r0, sp, #12
20021558:	f003 ff34 	bl	200253c4 <sf_crypto_aes_cmac_init>
2002155c:	4604      	mov	r4, r0
2002155e:	b100      	cbz	r0, 20021562 <sifli_verify_img_cmac_hash+0x2e>
20021560:	e7fe      	b.n	20021560 <sifli_verify_img_cmac_hash+0x2c>
20021562:	f8df 8038 	ldr.w	r8, [pc, #56]	@ 2002159c <sifli_verify_img_cmac_hash+0x68>
20021566:	2301      	movs	r3, #1
20021568:	463a      	mov	r2, r7
2002156a:	4631      	mov	r1, r6
2002156c:	f8cd 8000 	str.w	r8, [sp]
20021570:	a803      	add	r0, sp, #12
20021572:	f003 ff64 	bl	2002543e <sf_crypto_aes_cmac_calc>
20021576:	b950      	cbnz	r0, 2002158e <sifli_verify_img_cmac_hash+0x5a>
20021578:	2210      	movs	r2, #16
2002157a:	4629      	mov	r1, r5
2002157c:	4640      	mov	r0, r8
2002157e:	f004 fb87 	bl	20025c90 <memcmp>
20021582:	fab0 f080 	clz	r0, r0
20021586:	0940      	lsrs	r0, r0, #5
20021588:	b012      	add	sp, #72	@ 0x48
2002158a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002158e:	4620      	mov	r0, r4
20021590:	e7fa      	b.n	20021588 <sifli_verify_img_cmac_hash+0x54>
20021592:	bf00      	nop
20021594:	20047134 	.word	0x20047134
20021598:	2004c960 	.word	0x2004c960
2002159c:	2004c980 	.word	0x2004c980

200215a0 <sboot_init>:
200215a0:	b507      	push	{r0, r1, r2, lr}
200215a2:	f7ff fb7d 	bl	20020ca0 <sifli_hw_efuse_load_bank0>
200215a6:	b150      	cbz	r0, 200215be <sboot_init+0x1e>
200215a8:	2302      	movs	r3, #2
200215aa:	21ee      	movs	r1, #238	@ 0xee
200215ac:	f10d 0207 	add.w	r2, sp, #7
200215b0:	f006 fa5a 	bl	20027a68 <HAL_EFUSE_Extract>
200215b4:	2800      	cmp	r0, #0
200215b6:	dc08      	bgt.n	200215ca <sboot_init+0x2a>
200215b8:	b003      	add	sp, #12
200215ba:	f85d fb04 	ldr.w	pc, [sp], #4
200215be:	4807      	ldr	r0, [pc, #28]	@ (200215dc <sboot_init+0x3c>)
200215c0:	b003      	add	sp, #12
200215c2:	f85d eb04 	ldr.w	lr, [sp], #4
200215c6:	f004 ba85 	b.w	20025ad4 <puts>
200215ca:	f89d 3007 	ldrb.w	r3, [sp, #7]
200215ce:	2b00      	cmp	r3, #0
200215d0:	d0f2      	beq.n	200215b8 <sboot_init+0x18>
200215d2:	2201      	movs	r2, #1
200215d4:	4b02      	ldr	r3, [pc, #8]	@ (200215e0 <sboot_init+0x40>)
200215d6:	701a      	strb	r2, [r3, #0]
200215d8:	e7ee      	b.n	200215b8 <sboot_init+0x18>
200215da:	bf00      	nop
200215dc:	20026560 	.word	0x20026560
200215e0:	2004c95c 	.word	0x2004c95c

200215e4 <run_img>:
200215e4:	f8d0 d000 	ldr.w	sp, [r0]
200215e8:	f8d0 f004 	ldr.w	pc, [r0, #4]
200215ec:	4770      	bx	lr
	...

200215f0 <dfu_boot_img_in_flash>:
200215f0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200215f4:	4e27      	ldr	r6, [pc, #156]	@ (20021694 <dfu_boot_img_in_flash+0xa4>)
200215f6:	1e84      	subs	r4, r0, #2
200215f8:	eb06 1300 	add.w	r3, r6, r0, lsl #4
200215fc:	eb06 2040 	add.w	r0, r6, r0, lsl #9
20021600:	f8d0 7c00 	ldr.w	r7, [r0, #3072]	@ 0xc00
20021604:	f8d3 8004 	ldr.w	r8, [r3, #4]
20021608:	68dd      	ldr	r5, [r3, #12]
2002160a:	b177      	cbz	r7, 2002162a <dfu_boot_img_in_flash+0x3a>
2002160c:	45a8      	cmp	r8, r5
2002160e:	d00c      	beq.n	2002162a <dfu_boot_img_in_flash+0x3a>
20021610:	4628      	mov	r0, r5
20021612:	f7ff ff79 	bl	20021508 <is_addr_in_nor>
20021616:	b940      	cbnz	r0, 2002162a <dfu_boot_img_in_flash+0x3a>
20021618:	4b1f      	ldr	r3, [pc, #124]	@ (20021698 <dfu_boot_img_in_flash+0xa8>)
2002161a:	4629      	mov	r1, r5
2002161c:	781a      	ldrb	r2, [r3, #0]
2002161e:	4b1f      	ldr	r3, [pc, #124]	@ (2002169c <dfu_boot_img_in_flash+0xac>)
20021620:	4640      	mov	r0, r8
20021622:	681b      	ldr	r3, [r3, #0]
20021624:	eb07 1202 	add.w	r2, r7, r2, lsl #4
20021628:	4798      	blx	r3
2002162a:	2c07      	cmp	r4, #7
2002162c:	dc30      	bgt.n	20021690 <dfu_boot_img_in_flash+0xa0>
2002162e:	4263      	negs	r3, r4
20021630:	f003 0303 	and.w	r3, r3, #3
20021634:	f004 0703 	and.w	r7, r4, #3
20021638:	bf58      	it	pl
2002163a:	425f      	negpl	r7, r3
2002163c:	2f02      	cmp	r7, #2
2002163e:	d827      	bhi.n	20021690 <dfu_boot_img_in_flash+0xa0>
20021640:	4628      	mov	r0, r5
20021642:	f7ff ff61 	bl	20021508 <is_addr_in_nor>
20021646:	b150      	cbz	r0, 2002165e <dfu_boot_img_in_flash+0x6e>
20021648:	4815      	ldr	r0, [pc, #84]	@ (200216a0 <dfu_boot_img_in_flash+0xb0>)
2002164a:	f104 0208 	add.w	r2, r4, #8
2002164e:	0252      	lsls	r2, r2, #9
20021650:	4629      	mov	r1, r5
20021652:	58b2      	ldr	r2, [r6, r2]
20021654:	6800      	ldr	r0, [r0, #0]
20021656:	eba8 0305 	sub.w	r3, r8, r5
2002165a:	f001 fc1b 	bl	20022e94 <HAL_FLASH_ALIAS_CFG>
2002165e:	4b0e      	ldr	r3, [pc, #56]	@ (20021698 <dfu_boot_img_in_flash+0xa8>)
20021660:	781b      	ldrb	r3, [r3, #0]
20021662:	b923      	cbnz	r3, 2002166e <dfu_boot_img_in_flash+0x7e>
20021664:	4628      	mov	r0, r5
20021666:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002166a:	f7ff bfbb 	b.w	200215e4 <run_img>
2002166e:	2f01      	cmp	r7, #1
20021670:	d1f8      	bne.n	20021664 <dfu_boot_img_in_flash+0x74>
20021672:	3408      	adds	r4, #8
20021674:	0264      	lsls	r4, r4, #9
20021676:	5932      	ldr	r2, [r6, r4]
20021678:	4629      	mov	r1, r5
2002167a:	2000      	movs	r0, #0
2002167c:	1953      	adds	r3, r2, r5
2002167e:	f7ff ff59 	bl	20021534 <sifli_verify_img_cmac_hash>
20021682:	2800      	cmp	r0, #0
20021684:	d1ee      	bne.n	20021664 <dfu_boot_img_in_flash+0x74>
20021686:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002168a:	4806      	ldr	r0, [pc, #24]	@ (200216a4 <dfu_boot_img_in_flash+0xb4>)
2002168c:	f004 ba22 	b.w	20025ad4 <puts>
20021690:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021694:	20047138 	.word	0x20047138
20021698:	2004c95c 	.word	0x2004c95c
2002169c:	20046d3c 	.word	0x20046d3c
200216a0:	20046d30 	.word	0x20046d30
200216a4:	20026571 	.word	0x20026571

200216a8 <_close>:
200216a8:	f04f 30ff 	mov.w	r0, #4294967295
200216ac:	4770      	bx	lr

200216ae <_lseek>:
200216ae:	f04f 30ff 	mov.w	r0, #4294967295
200216b2:	4770      	bx	lr

200216b4 <_read>:
200216b4:	2000      	movs	r0, #0
200216b6:	4770      	bx	lr

200216b8 <_fstat>:
200216b8:	2000      	movs	r0, #0
200216ba:	4770      	bx	lr

200216bc <_isatty>:
200216bc:	2001      	movs	r0, #1
200216be:	4770      	bx	lr

200216c0 <flash_memset>:
200216c0:	4603      	mov	r3, r0
200216c2:	4402      	add	r2, r0
200216c4:	4293      	cmp	r3, r2
200216c6:	d100      	bne.n	200216ca <flash_memset+0xa>
200216c8:	4770      	bx	lr
200216ca:	f803 1b01 	strb.w	r1, [r3], #1
200216ce:	e7f9      	b.n	200216c4 <flash_memset+0x4>

200216d0 <bsp_psramc_init>:
200216d0:	b5f0      	push	{r4, r5, r6, r7, lr}
200216d2:	b087      	sub	sp, #28
200216d4:	f000 f850 	bl	20021778 <BSP_GetFlash1DIV>
200216d8:	f8ad 0000 	strh.w	r0, [sp]
200216dc:	f000 f852 	bl	20021784 <BSP_GetFlash2DIV>
200216e0:	2100      	movs	r1, #0
200216e2:	f8ad 0002 	strh.w	r0, [sp, #2]
200216e6:	2280      	movs	r2, #128	@ 0x80
200216e8:	481f      	ldr	r0, [pc, #124]	@ (20021768 <bsp_psramc_init+0x98>)
200216ea:	f7ff ffe9 	bl	200216c0 <flash_memset>
200216ee:	460e      	mov	r6, r1
200216f0:	4c1e      	ldr	r4, [pc, #120]	@ (2002176c <bsp_psramc_init+0x9c>)
200216f2:	4f1d      	ldr	r7, [pc, #116]	@ (20021768 <bsp_psramc_init+0x98>)
200216f4:	7a25      	ldrb	r5, [r4, #8]
200216f6:	b35d      	cbz	r5, 20021750 <bsp_psramc_init+0x80>
200216f8:	2214      	movs	r2, #20
200216fa:	2100      	movs	r1, #0
200216fc:	a801      	add	r0, sp, #4
200216fe:	f7ff ffdf 	bl	200216c0 <flash_memset>
20021702:	6863      	ldr	r3, [r4, #4]
20021704:	4a1a      	ldr	r2, [pc, #104]	@ (20021770 <bsp_psramc_init+0xa0>)
20021706:	9301      	str	r3, [sp, #4]
20021708:	4293      	cmp	r3, r2
2002170a:	d114      	bne.n	20021736 <bsp_psramc_init+0x66>
2002170c:	2001      	movs	r0, #1
2002170e:	f005 ff09 	bl	20027524 <bsp_psram_get_mpi_mode>
20021712:	b100      	cbz	r0, 20021716 <bsp_psramc_init+0x46>
20021714:	4605      	mov	r5, r0
20021716:	8963      	ldrh	r3, [r4, #10]
20021718:	9505      	str	r5, [sp, #20]
2002171a:	9304      	str	r3, [sp, #16]
2002171c:	68e3      	ldr	r3, [r4, #12]
2002171e:	9303      	str	r3, [sp, #12]
20021720:	f000 f88d 	bl	2002183e <SystemPowerOnModeGet>
20021724:	1e43      	subs	r3, r0, #1
20021726:	4258      	negs	r0, r3
20021728:	4158      	adcs	r0, r3
2002172a:	f887 002f 	strb.w	r0, [r7, #47]	@ 0x2f
2002172e:	6923      	ldr	r3, [r4, #16]
20021730:	4798      	blx	r3
20021732:	b138      	cbz	r0, 20021744 <bsp_psramc_init+0x74>
20021734:	e7fe      	b.n	20021734 <bsp_psramc_init+0x64>
20021736:	4a0f      	ldr	r2, [pc, #60]	@ (20021774 <bsp_psramc_init+0xa4>)
20021738:	4293      	cmp	r3, r2
2002173a:	d101      	bne.n	20021740 <bsp_psramc_init+0x70>
2002173c:	2002      	movs	r0, #2
2002173e:	e7e6      	b.n	2002170e <bsp_psramc_init+0x3e>
20021740:	4628      	mov	r0, r5
20021742:	e7e7      	b.n	20021714 <bsp_psramc_init+0x44>
20021744:	4638      	mov	r0, r7
20021746:	f83d 2016 	ldrh.w	r2, [sp, r6, lsl #1]
2002174a:	a901      	add	r1, sp, #4
2002174c:	f002 fcca 	bl	200240e4 <HAL_MPI_PSRAM_Init>
20021750:	1c73      	adds	r3, r6, #1
20021752:	2b02      	cmp	r3, #2
20021754:	f04f 0601 	mov.w	r6, #1
20021758:	f104 0414 	add.w	r4, r4, #20
2002175c:	f107 0740 	add.w	r7, r7, #64	@ 0x40
20021760:	d1c8      	bne.n	200216f4 <bsp_psramc_init+0x24>
20021762:	2000      	movs	r0, #0
20021764:	b007      	add	sp, #28
20021766:	bdf0      	pop	{r4, r5, r6, r7, pc}
20021768:	2004c994 	.word	0x2004c994
2002176c:	20026a60 	.word	0x20026a60
20021770:	50041000 	.word	0x50041000
20021774:	50042000 	.word	0x50042000

20021778 <BSP_GetFlash1DIV>:
20021778:	4b01      	ldr	r3, [pc, #4]	@ (20021780 <BSP_GetFlash1DIV+0x8>)
2002177a:	8818      	ldrh	r0, [r3, #0]
2002177c:	4770      	bx	lr
2002177e:	bf00      	nop
20021780:	20042c12 	.word	0x20042c12

20021784 <BSP_GetFlash2DIV>:
20021784:	4b01      	ldr	r3, [pc, #4]	@ (2002178c <BSP_GetFlash2DIV+0x8>)
20021786:	8818      	ldrh	r0, [r3, #0]
20021788:	4770      	bx	lr
2002178a:	bf00      	nop
2002178c:	20042c10 	.word	0x20042c10

20021790 <BSP_GetFlash3DIV>:
20021790:	4b01      	ldr	r3, [pc, #4]	@ (20021798 <BSP_GetFlash3DIV+0x8>)
20021792:	8818      	ldrh	r0, [r3, #0]
20021794:	4770      	bx	lr
20021796:	bf00      	nop
20021798:	20042c0e 	.word	0x20042c0e

2002179c <BSP_SetFlash1DIV>:
2002179c:	4b01      	ldr	r3, [pc, #4]	@ (200217a4 <BSP_SetFlash1DIV+0x8>)
2002179e:	8018      	strh	r0, [r3, #0]
200217a0:	4770      	bx	lr
200217a2:	bf00      	nop
200217a4:	20042c12 	.word	0x20042c12

200217a8 <BSP_SetFlash2DIV>:
200217a8:	4b01      	ldr	r3, [pc, #4]	@ (200217b0 <BSP_SetFlash2DIV+0x8>)
200217aa:	8018      	strh	r0, [r3, #0]
200217ac:	4770      	bx	lr
200217ae:	bf00      	nop
200217b0:	20042c10 	.word	0x20042c10

200217b4 <BSP_SetFlash3DIV>:
200217b4:	4b01      	ldr	r3, [pc, #4]	@ (200217bc <BSP_SetFlash3DIV+0x8>)
200217b6:	8018      	strh	r0, [r3, #0]
200217b8:	4770      	bx	lr
200217ba:	bf00      	nop
200217bc:	20042c0e 	.word	0x20042c0e

200217c0 <pmu_ldo_inc>:
200217c0:	2000      	movs	r0, #0
200217c2:	4770      	bx	lr

200217c4 <pmu_ldo_recover>:
200217c4:	2000      	movs	r0, #0
200217c6:	4770      	bx	lr

200217c8 <hw_preinit0>:
200217c8:	4770      	bx	lr
	...

200217cc <cache_disable>:
200217cc:	b570      	push	{r4, r5, r6, lr}
200217ce:	f3bf 8f4f 	dsb	sy
200217d2:	f3bf 8f6f 	isb	sy
200217d6:	4a18      	ldr	r2, [pc, #96]	@ (20021838 <cache_disable+0x6c>)
200217d8:	6953      	ldr	r3, [r2, #20]
200217da:	f423 3300 	bic.w	r3, r3, #131072	@ 0x20000
200217de:	6153      	str	r3, [r2, #20]
200217e0:	2300      	movs	r3, #0
200217e2:	f8c2 3250 	str.w	r3, [r2, #592]	@ 0x250
200217e6:	f3bf 8f4f 	dsb	sy
200217ea:	f3bf 8f6f 	isb	sy
200217ee:	f8c2 3084 	str.w	r3, [r2, #132]	@ 0x84
200217f2:	f3bf 8f4f 	dsb	sy
200217f6:	6953      	ldr	r3, [r2, #20]
200217f8:	f423 3380 	bic.w	r3, r3, #65536	@ 0x10000
200217fc:	6153      	str	r3, [r2, #20]
200217fe:	f3bf 8f4f 	dsb	sy
20021802:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
20021806:	f8d2 3080 	ldr.w	r3, [r2, #128]	@ 0x80
2002180a:	f3c3 00c9 	ubfx	r0, r3, #3, #10
2002180e:	f3c3 334e 	ubfx	r3, r3, #13, #15
20021812:	015b      	lsls	r3, r3, #5
20021814:	4601      	mov	r1, r0
20021816:	ea03 0604 	and.w	r6, r3, r4
2002181a:	ea46 7581 	orr.w	r5, r6, r1, lsl #30
2002181e:	3901      	subs	r1, #1
20021820:	f8c2 5274 	str.w	r5, [r2, #628]	@ 0x274
20021824:	d2f9      	bcs.n	2002181a <cache_disable+0x4e>
20021826:	3b20      	subs	r3, #32
20021828:	f113 0f20 	cmn.w	r3, #32
2002182c:	d1f2      	bne.n	20021814 <cache_disable+0x48>
2002182e:	f3bf 8f4f 	dsb	sy
20021832:	f3bf 8f6f 	isb	sy
20021836:	bd70      	pop	{r4, r5, r6, pc}
20021838:	e000ed00 	.word	0xe000ed00

2002183c <SystemPowerOnModeInit>:
2002183c:	4770      	bx	lr

2002183e <SystemPowerOnModeGet>:
2002183e:	2000      	movs	r0, #0
20021840:	4770      	bx	lr
	...

20021844 <SystemInit>:
20021844:	b508      	push	{r3, lr}
20021846:	4a0e      	ldr	r2, [pc, #56]	@ (20021880 <SystemInit+0x3c>)
20021848:	4b0e      	ldr	r3, [pc, #56]	@ (20021884 <SystemInit+0x40>)
2002184a:	609a      	str	r2, [r3, #8]
2002184c:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021850:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021854:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021858:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
2002185c:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
20021860:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021864:	f7ff ffb0 	bl	200217c8 <hw_preinit0>
20021868:	f7ff ffb0 	bl	200217cc <cache_disable>
2002186c:	f7fe fd1e 	bl	200202ac <mpu_config>
20021870:	f7fe fd1d 	bl	200202ae <cache_enable>
20021874:	f7ff ffe2 	bl	2002183c <SystemPowerOnModeInit>
20021878:	4b03      	ldr	r3, [pc, #12]	@ (20021888 <SystemInit+0x44>)
2002187a:	4a04      	ldr	r2, [pc, #16]	@ (2002188c <SystemInit+0x48>)
2002187c:	601a      	str	r2, [r3, #0]
2002187e:	bd08      	pop	{r3, pc}
20021880:	20020000 	.word	0x20020000
20021884:	e000ed00 	.word	0xe000ed00
20021888:	20042c14 	.word	0x20042c14
2002188c:	017d7840 	.word	0x017d7840

20021890 <Reset_Handler>:
20021890:	f8df d048 	ldr.w	sp, [pc, #72]	@ 200218dc <ACPU2HCPU_IRQHandler+0x2>
20021894:	4812      	ldr	r0, [pc, #72]	@ (200218e0 <ACPU2HCPU_IRQHandler+0x6>)
20021896:	f380 880a 	msr	MSPLIM, r0
2002189a:	f7ff ffd3 	bl	20021844 <SystemInit>
2002189e:	4c11      	ldr	r4, [pc, #68]	@ (200218e4 <ACPU2HCPU_IRQHandler+0xa>)
200218a0:	4d11      	ldr	r5, [pc, #68]	@ (200218e8 <ACPU2HCPU_IRQHandler+0xe>)
200218a2:	42ac      	cmp	r4, r5
200218a4:	da09      	bge.n	200218ba <Reset_Handler+0x2a>
200218a6:	6821      	ldr	r1, [r4, #0]
200218a8:	6862      	ldr	r2, [r4, #4]
200218aa:	68a3      	ldr	r3, [r4, #8]
200218ac:	3b04      	subs	r3, #4
200218ae:	bfa2      	ittt	ge
200218b0:	58c8      	ldrge	r0, [r1, r3]
200218b2:	50d0      	strge	r0, [r2, r3]
200218b4:	e7fa      	bge.n	200218ac <Reset_Handler+0x1c>
200218b6:	340c      	adds	r4, #12
200218b8:	e7f3      	b.n	200218a2 <Reset_Handler+0x12>
200218ba:	4b0c      	ldr	r3, [pc, #48]	@ (200218ec <ACPU2HCPU_IRQHandler+0x12>)
200218bc:	4c0c      	ldr	r4, [pc, #48]	@ (200218f0 <ACPU2HCPU_IRQHandler+0x16>)
200218be:	42a3      	cmp	r3, r4
200218c0:	da08      	bge.n	200218d4 <Reset_Handler+0x44>
200218c2:	6819      	ldr	r1, [r3, #0]
200218c4:	685a      	ldr	r2, [r3, #4]
200218c6:	2000      	movs	r0, #0
200218c8:	3a04      	subs	r2, #4
200218ca:	bfa4      	itt	ge
200218cc:	5088      	strge	r0, [r1, r2]
200218ce:	e7fb      	bge.n	200218c8 <Reset_Handler+0x38>
200218d0:	3308      	adds	r3, #8
200218d2:	e7f4      	b.n	200218be <Reset_Handler+0x2e>
200218d4:	f7ff fad8 	bl	20020e88 <entry>

200218d8 <HardFault_Handler>:
200218d8:	e7fe      	b.n	200218d8 <HardFault_Handler>

200218da <ACPU2HCPU_IRQHandler>:
200218da:	e7fe      	b.n	200218da <ACPU2HCPU_IRQHandler>
200218dc:	20042000 	.word	0x20042000
200218e0:	20040000 	.word	0x20040000
200218e4:	20027c30 	.word	0x20027c30
200218e8:	20027c3c 	.word	0x20027c3c
200218ec:	20027c3c 	.word	0x20027c3c
200218f0:	20027c44 	.word	0x20027c44

200218f4 <__aeabi_unwind_cpp_pr0>:
200218f4:	2000      	movs	r0, #0
200218f6:	4770      	bx	lr

200218f8 <HAL_GetTick>:
200218f8:	4b01      	ldr	r3, [pc, #4]	@ (20021900 <HAL_GetTick+0x8>)
200218fa:	6818      	ldr	r0, [r3, #0]
200218fc:	4770      	bx	lr
200218fe:	bf00      	nop
20021900:	2004ca18 	.word	0x2004ca18

20021904 <HAL_Delay_us_>:
20021904:	b538      	push	{r3, r4, r5, lr}
20021906:	4604      	mov	r4, r0
20021908:	4d16      	ldr	r5, [pc, #88]	@ (20021964 <HAL_Delay_us_+0x60>)
2002190a:	b128      	cbz	r0, 20021918 <HAL_Delay_us_+0x14>
2002190c:	682b      	ldr	r3, [r5, #0]
2002190e:	b11b      	cbz	r3, 20021918 <HAL_Delay_us_+0x14>
20021910:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
20021914:	d90a      	bls.n	2002192c <HAL_Delay_us_+0x28>
20021916:	e7fe      	b.n	20021916 <HAL_Delay_us_+0x12>
20021918:	2000      	movs	r0, #0
2002191a:	f002 fdf1 	bl	20024500 <HAL_RCC_GetHCLKFreq>
2002191e:	4b12      	ldr	r3, [pc, #72]	@ (20021968 <HAL_Delay_us_+0x64>)
20021920:	fbb0 f0f3 	udiv	r0, r0, r3
20021924:	6028      	str	r0, [r5, #0]
20021926:	2c00      	cmp	r4, #0
20021928:	d1f2      	bne.n	20021910 <HAL_Delay_us_+0xc>
2002192a:	bd38      	pop	{r3, r4, r5, pc}
2002192c:	4a0f      	ldr	r2, [pc, #60]	@ (2002196c <HAL_Delay_us_+0x68>)
2002192e:	6813      	ldr	r3, [r2, #0]
20021930:	f013 0301 	ands.w	r3, r3, #1
20021934:	d10d      	bne.n	20021952 <HAL_Delay_us_+0x4e>
20021936:	480e      	ldr	r0, [pc, #56]	@ (20021970 <HAL_Delay_us_+0x6c>)
20021938:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
2002193c:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
20021940:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
20021944:	6053      	str	r3, [r2, #4]
20021946:	6813      	ldr	r3, [r2, #0]
20021948:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
2002194c:	f043 0301 	orr.w	r3, r3, #1
20021950:	6013      	str	r3, [r2, #0]
20021952:	682b      	ldr	r3, [r5, #0]
20021954:	4a05      	ldr	r2, [pc, #20]	@ (2002196c <HAL_Delay_us_+0x68>)
20021956:	435c      	muls	r4, r3
20021958:	6851      	ldr	r1, [r2, #4]
2002195a:	6853      	ldr	r3, [r2, #4]
2002195c:	1a5b      	subs	r3, r3, r1
2002195e:	429c      	cmp	r4, r3
20021960:	d8fb      	bhi.n	2002195a <HAL_Delay_us_+0x56>
20021962:	e7e2      	b.n	2002192a <HAL_Delay_us_+0x26>
20021964:	2004ca14 	.word	0x2004ca14
20021968:	000f4240 	.word	0x000f4240
2002196c:	e0001000 	.word	0xe0001000
20021970:	e000ed00 	.word	0xe000ed00

20021974 <HAL_Delay_us2_>:
20021974:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021976:	9001      	str	r0, [sp, #4]
20021978:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
2002197c:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20021980:	6944      	ldr	r4, [r0, #20]
20021982:	9b01      	ldr	r3, [sp, #4]
20021984:	4363      	muls	r3, r4
20021986:	fbb3 f3f2 	udiv	r3, r3, r2
2002198a:	9301      	str	r3, [sp, #4]
2002198c:	2300      	movs	r3, #0
2002198e:	6981      	ldr	r1, [r0, #24]
20021990:	6982      	ldr	r2, [r0, #24]
20021992:	428a      	cmp	r2, r1
20021994:	d0fc      	beq.n	20021990 <HAL_Delay_us2_+0x1c>
20021996:	bf25      	ittet	cs
20021998:	1aa5      	subcs	r5, r4, r2
2002199a:	195b      	addcs	r3, r3, r5
2002199c:	185b      	addcc	r3, r3, r1
2002199e:	185b      	addcs	r3, r3, r1
200219a0:	9901      	ldr	r1, [sp, #4]
200219a2:	bf38      	it	cc
200219a4:	1a9b      	subcc	r3, r3, r2
200219a6:	4299      	cmp	r1, r3
200219a8:	d801      	bhi.n	200219ae <HAL_Delay_us2_+0x3a>
200219aa:	b003      	add	sp, #12
200219ac:	bd30      	pop	{r4, r5, pc}
200219ae:	4611      	mov	r1, r2
200219b0:	e7ee      	b.n	20021990 <HAL_Delay_us2_+0x1c>

200219b2 <HAL_Delay_us>:
200219b2:	4603      	mov	r3, r0
200219b4:	b570      	push	{r4, r5, r6, lr}
200219b6:	b1b8      	cbz	r0, 200219e8 <HAL_Delay_us+0x36>
200219b8:	f242 7510 	movw	r5, #10000	@ 0x2710
200219bc:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
200219c0:	42ab      	cmp	r3, r5
200219c2:	bf84      	itt	hi
200219c4:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
200219c8:	f242 7310 	movwhi	r3, #10000	@ 0x2710
200219cc:	6932      	ldr	r2, [r6, #16]
200219ce:	bf98      	it	ls
200219d0:	2400      	movls	r4, #0
200219d2:	4618      	mov	r0, r3
200219d4:	bf88      	it	hi
200219d6:	3c10      	subhi	r4, #16
200219d8:	07d3      	lsls	r3, r2, #31
200219da:	d508      	bpl.n	200219ee <HAL_Delay_us+0x3c>
200219dc:	f7ff ffca 	bl	20021974 <HAL_Delay_us2_>
200219e0:	4623      	mov	r3, r4
200219e2:	2c00      	cmp	r4, #0
200219e4:	d1ec      	bne.n	200219c0 <HAL_Delay_us+0xe>
200219e6:	e001      	b.n	200219ec <HAL_Delay_us+0x3a>
200219e8:	f7ff ff8c 	bl	20021904 <HAL_Delay_us_>
200219ec:	bd70      	pop	{r4, r5, r6, pc}
200219ee:	f7ff ff89 	bl	20021904 <HAL_Delay_us_>
200219f2:	e7f5      	b.n	200219e0 <HAL_Delay_us+0x2e>

200219f4 <WDT_IRQHandler>:
200219f4:	4770      	bx	lr

200219f6 <DBG_Trigger_IRQHandler>:
200219f6:	4770      	bx	lr

200219f8 <NMI_Handler>:
200219f8:	b508      	push	{r3, lr}
200219fa:	4b05      	ldr	r3, [pc, #20]	@ (20021a10 <NMI_Handler+0x18>)
200219fc:	6a1b      	ldr	r3, [r3, #32]
200219fe:	005b      	lsls	r3, r3, #1
20021a00:	d502      	bpl.n	20021a08 <NMI_Handler+0x10>
20021a02:	f7ff fff8 	bl	200219f6 <DBG_Trigger_IRQHandler>
20021a06:	bd08      	pop	{r3, pc}
20021a08:	f7ff fff4 	bl	200219f4 <WDT_IRQHandler>
20021a0c:	e7fb      	b.n	20021a06 <NMI_Handler+0xe>
20021a0e:	bf00      	nop
20021a10:	5000b000 	.word	0x5000b000

20021a14 <HAL_AES_run_help>:
20021a14:	b510      	push	{r4, lr}
20021a16:	f101 4470 	add.w	r4, r1, #4026531840	@ 0xf0000000
20021a1a:	f1b4 5f80 	cmp.w	r4, #268435456	@ 0x10000000
20021a1e:	4c0e      	ldr	r4, [pc, #56]	@ (20021a58 <HAL_AES_run_help+0x44>)
20021a20:	bf38      	it	cc
20021a22:	f101 41a0 	addcc.w	r1, r1, #1342177280	@ 0x50000000
20021a26:	6161      	str	r1, [r4, #20]
20021a28:	f102 4170 	add.w	r1, r2, #4026531840	@ 0xf0000000
20021a2c:	f1b1 5f80 	cmp.w	r1, #268435456	@ 0x10000000
20021a30:	f103 030f 	add.w	r3, r3, #15
20021a34:	ea4f 1323 	mov.w	r3, r3, asr #4
20021a38:	bf38      	it	cc
20021a3a:	f102 42a0 	addcc.w	r2, r2, #1342177280	@ 0x50000000
20021a3e:	61a2      	str	r2, [r4, #24]
20021a40:	61e3      	str	r3, [r4, #28]
20021a42:	6923      	ldr	r3, [r4, #16]
20021a44:	b108      	cbz	r0, 20021a4a <HAL_AES_run_help+0x36>
20021a46:	ea43 13c0 	orr.w	r3, r3, r0, lsl #7
20021a4a:	4a03      	ldr	r2, [pc, #12]	@ (20021a58 <HAL_AES_run_help+0x44>)
20021a4c:	6123      	str	r3, [r4, #16]
20021a4e:	6813      	ldr	r3, [r2, #0]
20021a50:	f043 0301 	orr.w	r3, r3, #1
20021a54:	6013      	str	r3, [r2, #0]
20021a56:	bd10      	pop	{r4, pc}
20021a58:	5000d000 	.word	0x5000d000

20021a5c <HAL_AES_reset>:
20021a5c:	2202      	movs	r2, #2
20021a5e:	2000      	movs	r0, #0
20021a60:	4b01      	ldr	r3, [pc, #4]	@ (20021a68 <HAL_AES_reset+0xc>)
20021a62:	601a      	str	r2, [r3, #0]
20021a64:	6018      	str	r0, [r3, #0]
20021a66:	4770      	bx	lr
20021a68:	5000d000 	.word	0x5000d000

20021a6c <HAL_AES_init>:
20021a6c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021a6e:	4604      	mov	r4, r0
20021a70:	200c      	movs	r0, #12
20021a72:	461e      	mov	r6, r3
20021a74:	460d      	mov	r5, r1
20021a76:	4617      	mov	r7, r2
20021a78:	f002 fe96 	bl	200247a8 <HAL_RCC_EnableModule>
20021a7c:	4b1c      	ldr	r3, [pc, #112]	@ (20021af0 <HAL_AES_init+0x84>)
20021a7e:	685b      	ldr	r3, [r3, #4]
20021a80:	07db      	lsls	r3, r3, #31
20021a82:	d501      	bpl.n	20021a88 <HAL_AES_init+0x1c>
20021a84:	f7ff ffea 	bl	20021a5c <HAL_AES_reset>
20021a88:	fab4 f184 	clz	r1, r4
20021a8c:	2d18      	cmp	r5, #24
20021a8e:	ea4f 1151 	mov.w	r1, r1, lsr #5
20021a92:	ea4f 1141 	mov.w	r1, r1, lsl #5
20021a96:	d01b      	beq.n	20021ad0 <HAL_AES_init+0x64>
20021a98:	2d20      	cmp	r5, #32
20021a9a:	d01b      	beq.n	20021ad4 <HAL_AES_init+0x68>
20021a9c:	2d10      	cmp	r5, #16
20021a9e:	d124      	bne.n	20021aea <HAL_AES_init+0x7e>
20021aa0:	2300      	movs	r3, #0
20021aa2:	b164      	cbz	r4, 20021abe <HAL_AES_init+0x52>
20021aa4:	4620      	mov	r0, r4
20021aa6:	4a13      	ldr	r2, [pc, #76]	@ (20021af4 <HAL_AES_init+0x88>)
20021aa8:	f025 0503 	bic.w	r5, r5, #3
20021aac:	4425      	add	r5, r4
20021aae:	1b12      	subs	r2, r2, r4
20021ab0:	1814      	adds	r4, r2, r0
20021ab2:	f850 cb04 	ldr.w	ip, [r0], #4
20021ab6:	4285      	cmp	r5, r0
20021ab8:	f8c4 c000 	str.w	ip, [r4]
20021abc:	d1f8      	bne.n	20021ab0 <HAL_AES_init+0x44>
20021abe:	4331      	orrs	r1, r6
20021ac0:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
20021ac4:	4b0a      	ldr	r3, [pc, #40]	@ (20021af0 <HAL_AES_init+0x84>)
20021ac6:	6119      	str	r1, [r3, #16]
20021ac8:	b106      	cbz	r6, 20021acc <HAL_AES_init+0x60>
20021aca:	b92f      	cbnz	r7, 20021ad8 <HAL_AES_init+0x6c>
20021acc:	2000      	movs	r0, #0
20021ace:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021ad0:	2301      	movs	r3, #1
20021ad2:	e7e6      	b.n	20021aa2 <HAL_AES_init+0x36>
20021ad4:	2302      	movs	r3, #2
20021ad6:	e7e4      	b.n	20021aa2 <HAL_AES_init+0x36>
20021ad8:	683a      	ldr	r2, [r7, #0]
20021ada:	621a      	str	r2, [r3, #32]
20021adc:	687a      	ldr	r2, [r7, #4]
20021ade:	625a      	str	r2, [r3, #36]	@ 0x24
20021ae0:	68ba      	ldr	r2, [r7, #8]
20021ae2:	629a      	str	r2, [r3, #40]	@ 0x28
20021ae4:	68fa      	ldr	r2, [r7, #12]
20021ae6:	62da      	str	r2, [r3, #44]	@ 0x2c
20021ae8:	e7f0      	b.n	20021acc <HAL_AES_init+0x60>
20021aea:	f04f 30ff 	mov.w	r0, #4294967295
20021aee:	e7ee      	b.n	20021ace <HAL_AES_init+0x62>
20021af0:	5000d000 	.word	0x5000d000
20021af4:	5000d030 	.word	0x5000d030

20021af8 <HAL_AES_run>:
20021af8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021afa:	2708      	movs	r7, #8
20021afc:	4e17      	ldr	r6, [pc, #92]	@ (20021b5c <HAL_AES_run+0x64>)
20021afe:	4614      	mov	r4, r2
20021b00:	461d      	mov	r5, r3
20021b02:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
20021b06:	f3bf 8f4f 	dsb	sy
20021b0a:	f3bf 8f6f 	isb	sy
20021b0e:	2700      	movs	r7, #0
20021b10:	4e13      	ldr	r6, [pc, #76]	@ (20021b60 <HAL_AES_run+0x68>)
20021b12:	60f7      	str	r7, [r6, #12]
20021b14:	f7ff ff7e 	bl	20021a14 <HAL_AES_run_help>
20021b18:	6873      	ldr	r3, [r6, #4]
20021b1a:	07db      	lsls	r3, r3, #31
20021b1c:	d4fc      	bmi.n	20021b18 <HAL_AES_run+0x20>
20021b1e:	68b0      	ldr	r0, [r6, #8]
20021b20:	f000 0006 	and.w	r0, r0, #6
20021b24:	3800      	subs	r0, #0
20021b26:	bf18      	it	ne
20021b28:	2001      	movne	r0, #1
20021b2a:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
20021b2e:	d314      	bcc.n	20021b5a <HAL_AES_run+0x62>
20021b30:	2d00      	cmp	r5, #0
20021b32:	dd12      	ble.n	20021b5a <HAL_AES_run+0x62>
20021b34:	f004 031f 	and.w	r3, r4, #31
20021b38:	442b      	add	r3, r5
20021b3a:	f024 021f 	bic.w	r2, r4, #31
20021b3e:	f3bf 8f4f 	dsb	sy
20021b42:	4c08      	ldr	r4, [pc, #32]	@ (20021b64 <HAL_AES_run+0x6c>)
20021b44:	4413      	add	r3, r2
20021b46:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
20021b4a:	3220      	adds	r2, #32
20021b4c:	1a99      	subs	r1, r3, r2
20021b4e:	2900      	cmp	r1, #0
20021b50:	dcf9      	bgt.n	20021b46 <HAL_AES_run+0x4e>
20021b52:	f3bf 8f4f 	dsb	sy
20021b56:	f3bf 8f6f 	isb	sy
20021b5a:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021b5c:	e000e100 	.word	0xe000e100
20021b60:	5000d000 	.word	0x5000d000
20021b64:	e000ed00 	.word	0xe000ed00

20021b68 <HAL_NVIC_EnableIRQ>:
20021b68:	2800      	cmp	r0, #0
20021b6a:	da00      	bge.n	20021b6e <HAL_NVIC_EnableIRQ+0x6>
20021b6c:	e7fe      	b.n	20021b6c <HAL_NVIC_EnableIRQ+0x4>
20021b6e:	2301      	movs	r3, #1
20021b70:	0941      	lsrs	r1, r0, #5
20021b72:	4a03      	ldr	r2, [pc, #12]	@ (20021b80 <HAL_NVIC_EnableIRQ+0x18>)
20021b74:	f000 001f 	and.w	r0, r0, #31
20021b78:	4083      	lsls	r3, r0
20021b7a:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20021b7e:	4770      	bx	lr
20021b80:	e000e100 	.word	0xe000e100

20021b84 <HAL_NVIC_DisableIRQ>:
20021b84:	2800      	cmp	r0, #0
20021b86:	da00      	bge.n	20021b8a <HAL_NVIC_DisableIRQ+0x6>
20021b88:	e7fe      	b.n	20021b88 <HAL_NVIC_DisableIRQ+0x4>
20021b8a:	2201      	movs	r2, #1
20021b8c:	4906      	ldr	r1, [pc, #24]	@ (20021ba8 <HAL_NVIC_DisableIRQ+0x24>)
20021b8e:	0943      	lsrs	r3, r0, #5
20021b90:	f000 001f 	and.w	r0, r0, #31
20021b94:	4082      	lsls	r2, r0
20021b96:	3320      	adds	r3, #32
20021b98:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20021b9c:	f3bf 8f4f 	dsb	sy
20021ba0:	f3bf 8f6f 	isb	sy
20021ba4:	4770      	bx	lr
20021ba6:	bf00      	nop
20021ba8:	e000e100 	.word	0xe000e100

20021bac <DMA_IsChannelOwner>:
20021bac:	b510      	push	{r4, lr}
20021bae:	4911      	ldr	r1, [pc, #68]	@ (20021bf4 <DMA_IsChannelOwner+0x48>)
20021bb0:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021bb2:	4602      	mov	r2, r0
20021bb4:	428b      	cmp	r3, r1
20021bb6:	d003      	beq.n	20021bc0 <DMA_IsChannelOwner+0x14>
20021bb8:	490f      	ldr	r1, [pc, #60]	@ (20021bf8 <DMA_IsChannelOwner+0x4c>)
20021bba:	428b      	cmp	r3, r1
20021bbc:	d007      	beq.n	20021bce <DMA_IsChannelOwner+0x22>
20021bbe:	e7fe      	b.n	20021bbe <DMA_IsChannelOwner+0x12>
20021bc0:	4b0e      	ldr	r3, [pc, #56]	@ (20021bfc <DMA_IsChannelOwner+0x50>)
20021bc2:	6d10      	ldr	r0, [r2, #80]	@ 0x50
20021bc4:	281f      	cmp	r0, #31
20021bc6:	ea4f 0190 	mov.w	r1, r0, lsr #2
20021bca:	d902      	bls.n	20021bd2 <DMA_IsChannelOwner+0x26>
20021bcc:	e7fe      	b.n	20021bcc <DMA_IsChannelOwner+0x20>
20021bce:	4b0c      	ldr	r3, [pc, #48]	@ (20021c00 <DMA_IsChannelOwner+0x54>)
20021bd0:	e7f7      	b.n	20021bc2 <DMA_IsChannelOwner+0x16>
20021bd2:	f3ef 8410 	mrs	r4, PRIMASK
20021bd6:	2001      	movs	r0, #1
20021bd8:	f380 8810 	msr	PRIMASK, r0
20021bdc:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
20021be0:	7900      	ldrb	r0, [r0, #4]
20021be2:	b120      	cbz	r0, 20021bee <DMA_IsChannelOwner+0x42>
20021be4:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
20021be8:	1a83      	subs	r3, r0, r2
20021bea:	4258      	negs	r0, r3
20021bec:	4158      	adcs	r0, r3
20021bee:	f384 8810 	msr	PRIMASK, r4
20021bf2:	bd10      	pop	{r4, pc}
20021bf4:	50081000 	.word	0x50081000
20021bf8:	40001000 	.word	0x40001000
20021bfc:	2004ca5c 	.word	0x2004ca5c
20021c00:	2004ca1c 	.word	0x2004ca1c

20021c04 <DMA_FreeChannel.isra.0>:
20021c04:	b538      	push	{r3, r4, r5, lr}
20021c06:	4a13      	ldr	r2, [pc, #76]	@ (20021c54 <DMA_FreeChannel.isra.0+0x50>)
20021c08:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021c0a:	4293      	cmp	r3, r2
20021c0c:	d003      	beq.n	20021c16 <DMA_FreeChannel.isra.0+0x12>
20021c0e:	4a12      	ldr	r2, [pc, #72]	@ (20021c58 <DMA_FreeChannel.isra.0+0x54>)
20021c10:	4293      	cmp	r3, r2
20021c12:	d008      	beq.n	20021c26 <DMA_FreeChannel.isra.0+0x22>
20021c14:	e7fe      	b.n	20021c14 <DMA_FreeChannel.isra.0+0x10>
20021c16:	2132      	movs	r1, #50	@ 0x32
20021c18:	4a10      	ldr	r2, [pc, #64]	@ (20021c5c <DMA_FreeChannel.isra.0+0x58>)
20021c1a:	6d04      	ldr	r4, [r0, #80]	@ 0x50
20021c1c:	2c1f      	cmp	r4, #31
20021c1e:	ea4f 0394 	mov.w	r3, r4, lsr #2
20021c22:	d903      	bls.n	20021c2c <DMA_FreeChannel.isra.0+0x28>
20021c24:	e7fe      	b.n	20021c24 <DMA_FreeChannel.isra.0+0x20>
20021c26:	2102      	movs	r1, #2
20021c28:	4a0d      	ldr	r2, [pc, #52]	@ (20021c60 <DMA_FreeChannel.isra.0+0x5c>)
20021c2a:	e7f6      	b.n	20021c1a <DMA_FreeChannel.isra.0+0x16>
20021c2c:	f3ef 8410 	mrs	r4, PRIMASK
20021c30:	2501      	movs	r5, #1
20021c32:	f385 8810 	msr	PRIMASK, r5
20021c36:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
20021c3a:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
20021c3e:	4290      	cmp	r0, r2
20021c40:	d105      	bne.n	20021c4e <DMA_FreeChannel.isra.0+0x4a>
20021c42:	1858      	adds	r0, r3, r1
20021c44:	b240      	sxtb	r0, r0
20021c46:	f7ff ff9d 	bl	20021b84 <HAL_NVIC_DisableIRQ>
20021c4a:	2300      	movs	r3, #0
20021c4c:	712b      	strb	r3, [r5, #4]
20021c4e:	f384 8810 	msr	PRIMASK, r4
20021c52:	bd38      	pop	{r3, r4, r5, pc}
20021c54:	50081000 	.word	0x50081000
20021c58:	40001000 	.word	0x40001000
20021c5c:	2004ca5c 	.word	0x2004ca5c
20021c60:	2004ca1c 	.word	0x2004ca1c

20021c64 <DMA_SetBurstSizeAndFix.part.0>:
20021c64:	6843      	ldr	r3, [r0, #4]
20021c66:	2b10      	cmp	r3, #16
20021c68:	d113      	bne.n	20021c92 <DMA_SetBurstSizeAndFix.part.0+0x2e>
20021c6a:	8c02      	ldrh	r2, [r0, #32]
20021c6c:	b11a      	cbz	r2, 20021c76 <DMA_SetBurstSizeAndFix.part.0+0x12>
20021c6e:	680b      	ldr	r3, [r1, #0]
20021c70:	f043 5380 	orr.w	r3, r3, #268435456	@ 0x10000000
20021c74:	600b      	str	r3, [r1, #0]
20021c76:	680b      	ldr	r3, [r1, #0]
20021c78:	f362 6319 	bfi	r3, r2, #24, #2
20021c7c:	600b      	str	r3, [r1, #0]
20021c7e:	6842      	ldr	r2, [r0, #4]
20021c80:	b94a      	cbnz	r2, 20021c96 <DMA_SetBurstSizeAndFix.part.0+0x32>
20021c82:	8c02      	ldrh	r2, [r0, #32]
20021c84:	b10a      	cbz	r2, 20021c8a <DMA_SetBurstSizeAndFix.part.0+0x26>
20021c86:	f043 5300 	orr.w	r3, r3, #536870912	@ 0x20000000
20021c8a:	f362 639b 	bfi	r3, r2, #26, #2
20021c8e:	600b      	str	r3, [r1, #0]
20021c90:	4770      	bx	lr
20021c92:	2203      	movs	r2, #3
20021c94:	e7ef      	b.n	20021c76 <DMA_SetBurstSizeAndFix.part.0+0x12>
20021c96:	2203      	movs	r2, #3
20021c98:	e7f7      	b.n	20021c8a <DMA_SetBurstSizeAndFix.part.0+0x26>

20021c9a <DMA_Init>:
20021c9a:	2302      	movs	r3, #2
20021c9c:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021c9e:	f880 3031 	strb.w	r3, [r0, #49]	@ 0x31
20021ca2:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021ca6:	4604      	mov	r4, r0
20021ca8:	2b00      	cmp	r3, #0
20021caa:	bfa2      	ittt	ge
20021cac:	6803      	ldrge	r3, [r0, #0]
20021cae:	6a42      	ldrge	r2, [r0, #36]	@ 0x24
20021cb0:	611a      	strge	r2, [r3, #16]
20021cb2:	e9d0 3102 	ldrd	r3, r1, [r0, #8]
20021cb6:	430b      	orrs	r3, r1
20021cb8:	6901      	ldr	r1, [r0, #16]
20021cba:	6805      	ldr	r5, [r0, #0]
20021cbc:	430b      	orrs	r3, r1
20021cbe:	6941      	ldr	r1, [r0, #20]
20021cc0:	682a      	ldr	r2, [r5, #0]
20021cc2:	430b      	orrs	r3, r1
20021cc4:	6981      	ldr	r1, [r0, #24]
20021cc6:	f36f 120e 	bfc	r2, #4, #11
20021cca:	430b      	orrs	r3, r1
20021ccc:	69c1      	ldr	r1, [r0, #28]
20021cce:	430b      	orrs	r3, r1
20021cd0:	6a01      	ldr	r1, [r0, #32]
20021cd2:	430b      	orrs	r3, r1
20021cd4:	4313      	orrs	r3, r2
20021cd6:	9301      	str	r3, [sp, #4]
20021cd8:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021cdc:	2b00      	cmp	r3, #0
20021cde:	da08      	bge.n	20021cf2 <DMA_Init+0x58>
20021ce0:	6d43      	ldr	r3, [r0, #84]	@ 0x54
20021ce2:	f3c3 031e 	ubfx	r3, r3, #0, #31
20021ce6:	2b01      	cmp	r3, #1
20021ce8:	d803      	bhi.n	20021cf2 <DMA_Init+0x58>
20021cea:	a901      	add	r1, sp, #4
20021cec:	3004      	adds	r0, #4
20021cee:	f7ff ffb9 	bl	20021c64 <DMA_SetBurstSizeAndFix.part.0>
20021cf2:	9b01      	ldr	r3, [sp, #4]
20021cf4:	602b      	str	r3, [r5, #0]
20021cf6:	68a3      	ldr	r3, [r4, #8]
20021cf8:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021cfc:	d01f      	beq.n	20021d3e <DMA_Init+0xa4>
20021cfe:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021d00:	f3c3 0387 	ubfx	r3, r3, #2, #8
20021d04:	f3ef 8110 	mrs	r1, PRIMASK
20021d08:	2201      	movs	r2, #1
20021d0a:	f382 8810 	msr	PRIMASK, r2
20021d0e:	0758      	lsls	r0, r3, #29
20021d10:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
20021d12:	d41d      	bmi.n	20021d50 <DMA_Init+0xb6>
20021d14:	253f      	movs	r5, #63	@ 0x3f
20021d16:	f003 0307 	and.w	r3, r3, #7
20021d1a:	f8d2 00a8 	ldr.w	r0, [r2, #168]	@ 0xa8
20021d1e:	00db      	lsls	r3, r3, #3
20021d20:	409d      	lsls	r5, r3
20021d22:	ea20 0005 	bic.w	r0, r0, r5
20021d26:	f8c2 00a8 	str.w	r0, [r2, #168]	@ 0xa8
20021d2a:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021d2c:	6862      	ldr	r2, [r4, #4]
20021d2e:	f8d0 50a8 	ldr.w	r5, [r0, #168]	@ 0xa8
20021d32:	409a      	lsls	r2, r3
20021d34:	432a      	orrs	r2, r5
20021d36:	f8c0 20a8 	str.w	r2, [r0, #168]	@ 0xa8
20021d3a:	f381 8810 	msr	PRIMASK, r1
20021d3e:	69a2      	ldr	r2, [r4, #24]
20021d40:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
20021d44:	d018      	beq.n	20021d78 <DMA_Init+0xde>
20021d46:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
20021d4a:	d01f      	beq.n	20021d8c <DMA_Init+0xf2>
20021d4c:	b1aa      	cbz	r2, 20021d7a <DMA_Init+0xe0>
20021d4e:	e7fe      	b.n	20021d4e <DMA_Init+0xb4>
20021d50:	253f      	movs	r5, #63	@ 0x3f
20021d52:	f003 0303 	and.w	r3, r3, #3
20021d56:	f8d2 00ac 	ldr.w	r0, [r2, #172]	@ 0xac
20021d5a:	00db      	lsls	r3, r3, #3
20021d5c:	409d      	lsls	r5, r3
20021d5e:	ea20 0005 	bic.w	r0, r0, r5
20021d62:	f8c2 00ac 	str.w	r0, [r2, #172]	@ 0xac
20021d66:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021d68:	6862      	ldr	r2, [r4, #4]
20021d6a:	f8d0 50ac 	ldr.w	r5, [r0, #172]	@ 0xac
20021d6e:	409a      	lsls	r2, r3
20021d70:	432a      	orrs	r2, r5
20021d72:	f8c0 20ac 	str.w	r2, [r0, #172]	@ 0xac
20021d76:	e7e0      	b.n	20021d3a <DMA_Init+0xa0>
20021d78:	2201      	movs	r2, #1
20021d7a:	6963      	ldr	r3, [r4, #20]
20021d7c:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20021d80:	d006      	beq.n	20021d90 <DMA_Init+0xf6>
20021d82:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021d86:	d02c      	beq.n	20021de2 <DMA_Init+0x148>
20021d88:	b11b      	cbz	r3, 20021d92 <DMA_Init+0xf8>
20021d8a:	e7fe      	b.n	20021d8a <DMA_Init+0xf0>
20021d8c:	2202      	movs	r2, #2
20021d8e:	e7f4      	b.n	20021d7a <DMA_Init+0xe0>
20021d90:	2301      	movs	r3, #1
20021d92:	6921      	ldr	r1, [r4, #16]
20021d94:	f1a1 0080 	sub.w	r0, r1, #128	@ 0x80
20021d98:	4241      	negs	r1, r0
20021d9a:	4141      	adcs	r1, r0
20021d9c:	68e0      	ldr	r0, [r4, #12]
20021d9e:	f1a0 0540 	sub.w	r5, r0, #64	@ 0x40
20021da2:	4268      	negs	r0, r5
20021da4:	4168      	adcs	r0, r5
20021da6:	68a5      	ldr	r5, [r4, #8]
20021da8:	2d10      	cmp	r5, #16
20021daa:	bf1f      	itttt	ne
20021dac:	f884 106d 	strbne.w	r1, [r4, #109]	@ 0x6d
20021db0:	4619      	movne	r1, r3
20021db2:	4613      	movne	r3, r2
20021db4:	460a      	movne	r2, r1
20021db6:	f884 306f 	strb.w	r3, [r4, #111]	@ 0x6f
20021dba:	f884 206e 	strb.w	r2, [r4, #110]	@ 0x6e
20021dbe:	f04f 0300 	mov.w	r3, #0
20021dc2:	f04f 0201 	mov.w	r2, #1
20021dc6:	64a3      	str	r3, [r4, #72]	@ 0x48
20021dc8:	bf06      	itte	eq
20021dca:	f884 006d 	strbeq.w	r0, [r4, #109]	@ 0x6d
20021dce:	f884 106c 	strbeq.w	r1, [r4, #108]	@ 0x6c
20021dd2:	f884 006c 	strbne.w	r0, [r4, #108]	@ 0x6c
20021dd6:	f884 2031 	strb.w	r2, [r4, #49]	@ 0x31
20021dda:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021dde:	b003      	add	sp, #12
20021de0:	bd30      	pop	{r4, r5, pc}
20021de2:	2302      	movs	r3, #2
20021de4:	e7d5      	b.n	20021d92 <DMA_Init+0xf8>
	...

20021de8 <DMA_AllocChannel>:
20021de8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021dea:	4b2f      	ldr	r3, [pc, #188]	@ (20021ea8 <DMA_AllocChannel+0xc0>)
20021dec:	6802      	ldr	r2, [r0, #0]
20021dee:	4604      	mov	r4, r0
20021df0:	4413      	add	r3, r2
20021df2:	2ba0      	cmp	r3, #160	@ 0xa0
20021df4:	d904      	bls.n	20021e00 <DMA_AllocChannel+0x18>
20021df6:	4b2d      	ldr	r3, [pc, #180]	@ (20021eac <DMA_AllocChannel+0xc4>)
20021df8:	4413      	add	r3, r2
20021dfa:	2ba0      	cmp	r3, #160	@ 0xa0
20021dfc:	d90f      	bls.n	20021e1e <DMA_AllocChannel+0x36>
20021dfe:	e7fe      	b.n	20021dfe <DMA_AllocChannel+0x16>
20021e00:	2032      	movs	r0, #50	@ 0x32
20021e02:	f8df c0b4 	ldr.w	ip, [pc, #180]	@ 20021eb8 <DMA_AllocChannel+0xd0>
20021e06:	4b2a      	ldr	r3, [pc, #168]	@ (20021eb0 <DMA_AllocChannel+0xc8>)
20021e08:	f3ef 8710 	mrs	r7, PRIMASK
20021e0c:	2201      	movs	r2, #1
20021e0e:	f382 8810 	msr	PRIMASK, r2
20021e12:	6d26      	ldr	r6, [r4, #80]	@ 0x50
20021e14:	2e1f      	cmp	r6, #31
20021e16:	ea4f 0596 	mov.w	r5, r6, lsr #2
20021e1a:	d905      	bls.n	20021e28 <DMA_AllocChannel+0x40>
20021e1c:	e7fe      	b.n	20021e1c <DMA_AllocChannel+0x34>
20021e1e:	2002      	movs	r0, #2
20021e20:	f8df c098 	ldr.w	ip, [pc, #152]	@ 20021ebc <DMA_AllocChannel+0xd4>
20021e24:	4b23      	ldr	r3, [pc, #140]	@ (20021eb4 <DMA_AllocChannel+0xcc>)
20021e26:	e7ef      	b.n	20021e08 <DMA_AllocChannel+0x20>
20021e28:	eb03 06c5 	add.w	r6, r3, r5, lsl #3
20021e2c:	f896 e004 	ldrb.w	lr, [r6, #4]
20021e30:	f1be 0f00 	cmp.w	lr, #0
20021e34:	d033      	beq.n	20021e9e <DMA_AllocChannel+0xb6>
20021e36:	f853 2035 	ldr.w	r2, [r3, r5, lsl #3]
20021e3a:	42a2      	cmp	r2, r4
20021e3c:	d103      	bne.n	20021e46 <DMA_AllocChannel+0x5e>
20021e3e:	f387 8810 	msr	PRIMASK, r7
20021e42:	2002      	movs	r0, #2
20021e44:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021e46:	2200      	movs	r2, #0
20021e48:	791d      	ldrb	r5, [r3, #4]
20021e4a:	461e      	mov	r6, r3
20021e4c:	bb0d      	cbnz	r5, 20021e92 <DMA_AllocChannel+0xaa>
20021e4e:	2301      	movs	r3, #1
20021e50:	7133      	strb	r3, [r6, #4]
20021e52:	2314      	movs	r3, #20
20021e54:	fb03 c302 	mla	r3, r3, r2, ip
20021e58:	4410      	add	r0, r2
20021e5a:	0092      	lsls	r2, r2, #2
20021e5c:	b245      	sxtb	r5, r0
20021e5e:	6023      	str	r3, [r4, #0]
20021e60:	6522      	str	r2, [r4, #80]	@ 0x50
20021e62:	f387 8810 	msr	PRIMASK, r7
20021e66:	b129      	cbz	r1, 20021e74 <DMA_AllocChannel+0x8c>
20021e68:	6833      	ldr	r3, [r6, #0]
20021e6a:	42a3      	cmp	r3, r4
20021e6c:	d002      	beq.n	20021e74 <DMA_AllocChannel+0x8c>
20021e6e:	4620      	mov	r0, r4
20021e70:	f7ff ff13 	bl	20021c9a <DMA_Init>
20021e74:	6034      	str	r4, [r6, #0]
20021e76:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
20021e78:	f105 4260 	add.w	r2, r5, #3758096384	@ 0xe0000000
20021e7c:	015b      	lsls	r3, r3, #5
20021e7e:	b2db      	uxtb	r3, r3
20021e80:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20021e84:	4628      	mov	r0, r5
20021e86:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
20021e8a:	f7ff fe6d 	bl	20021b68 <HAL_NVIC_EnableIRQ>
20021e8e:	2000      	movs	r0, #0
20021e90:	e7d8      	b.n	20021e44 <DMA_AllocChannel+0x5c>
20021e92:	3201      	adds	r2, #1
20021e94:	2a08      	cmp	r2, #8
20021e96:	f103 0308 	add.w	r3, r3, #8
20021e9a:	d1d5      	bne.n	20021e48 <DMA_AllocChannel+0x60>
20021e9c:	e7cf      	b.n	20021e3e <DMA_AllocChannel+0x56>
20021e9e:	4405      	add	r5, r0
20021ea0:	7132      	strb	r2, [r6, #4]
20021ea2:	b26d      	sxtb	r5, r5
20021ea4:	e7dd      	b.n	20021e62 <DMA_AllocChannel+0x7a>
20021ea6:	bf00      	nop
20021ea8:	aff7eff8 	.word	0xaff7eff8
20021eac:	bfffeff8 	.word	0xbfffeff8
20021eb0:	2004ca5c 	.word	0x2004ca5c
20021eb4:	2004ca1c 	.word	0x2004ca1c
20021eb8:	50081008 	.word	0x50081008
20021ebc:	40001008 	.word	0x40001008

20021ec0 <HAL_DMA_Init>:
20021ec0:	b538      	push	{r3, r4, r5, lr}
20021ec2:	4604      	mov	r4, r0
20021ec4:	2800      	cmp	r0, #0
20021ec6:	d05b      	beq.n	20021f80 <HAL_DMA_Init+0xc0>
20021ec8:	6883      	ldr	r3, [r0, #8]
20021eca:	f033 0210 	bics.w	r2, r3, #16
20021ece:	d003      	beq.n	20021ed8 <HAL_DMA_Init+0x18>
20021ed0:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021ed4:	d000      	beq.n	20021ed8 <HAL_DMA_Init+0x18>
20021ed6:	e7fe      	b.n	20021ed6 <HAL_DMA_Init+0x16>
20021ed8:	68e3      	ldr	r3, [r4, #12]
20021eda:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20021ede:	d000      	beq.n	20021ee2 <HAL_DMA_Init+0x22>
20021ee0:	e7fe      	b.n	20021ee0 <HAL_DMA_Init+0x20>
20021ee2:	6923      	ldr	r3, [r4, #16]
20021ee4:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
20021ee8:	d000      	beq.n	20021eec <HAL_DMA_Init+0x2c>
20021eea:	e7fe      	b.n	20021eea <HAL_DMA_Init+0x2a>
20021eec:	6963      	ldr	r3, [r4, #20]
20021eee:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20021ef2:	d003      	beq.n	20021efc <HAL_DMA_Init+0x3c>
20021ef4:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021ef8:	d000      	beq.n	20021efc <HAL_DMA_Init+0x3c>
20021efa:	e7fe      	b.n	20021efa <HAL_DMA_Init+0x3a>
20021efc:	69a3      	ldr	r3, [r4, #24]
20021efe:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20021f02:	d003      	beq.n	20021f0c <HAL_DMA_Init+0x4c>
20021f04:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
20021f08:	d000      	beq.n	20021f0c <HAL_DMA_Init+0x4c>
20021f0a:	e7fe      	b.n	20021f0a <HAL_DMA_Init+0x4a>
20021f0c:	69e3      	ldr	r3, [r4, #28]
20021f0e:	f033 0320 	bics.w	r3, r3, #32
20021f12:	d000      	beq.n	20021f16 <HAL_DMA_Init+0x56>
20021f14:	e7fe      	b.n	20021f14 <HAL_DMA_Init+0x54>
20021f16:	6a23      	ldr	r3, [r4, #32]
20021f18:	f433 5240 	bics.w	r2, r3, #12288	@ 0x3000
20021f1c:	d000      	beq.n	20021f20 <HAL_DMA_Init+0x60>
20021f1e:	e7fe      	b.n	20021f1e <HAL_DMA_Init+0x5e>
20021f20:	6863      	ldr	r3, [r4, #4]
20021f22:	2b51      	cmp	r3, #81	@ 0x51
20021f24:	d900      	bls.n	20021f28 <HAL_DMA_Init+0x68>
20021f26:	e7fe      	b.n	20021f26 <HAL_DMA_Init+0x66>
20021f28:	6821      	ldr	r1, [r4, #0]
20021f2a:	4b17      	ldr	r3, [pc, #92]	@ (20021f88 <HAL_DMA_Init+0xc8>)
20021f2c:	440b      	add	r3, r1
20021f2e:	2b8c      	cmp	r3, #140	@ 0x8c
20021f30:	d81a      	bhi.n	20021f68 <HAL_DMA_Init+0xa8>
20021f32:	2214      	movs	r2, #20
20021f34:	fbb3 f3f2 	udiv	r3, r3, r2
20021f38:	2201      	movs	r2, #1
20021f3a:	4914      	ldr	r1, [pc, #80]	@ (20021f8c <HAL_DMA_Init+0xcc>)
20021f3c:	0098      	lsls	r0, r3, #2
20021f3e:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021f42:	ea43 73c2 	orr.w	r3, r3, r2, lsl #31
20021f46:	e9c4 1013 	strd	r1, r0, [r4, #76]	@ 0x4c
20021f4a:	6563      	str	r3, [r4, #84]	@ 0x54
20021f4c:	2100      	movs	r1, #0
20021f4e:	4620      	mov	r0, r4
20021f50:	f7ff ff4a 	bl	20021de8 <DMA_AllocChannel>
20021f54:	4605      	mov	r5, r0
20021f56:	b9a8      	cbnz	r0, 20021f84 <HAL_DMA_Init+0xc4>
20021f58:	4620      	mov	r0, r4
20021f5a:	f7ff fe9e 	bl	20021c9a <DMA_Init>
20021f5e:	4620      	mov	r0, r4
20021f60:	f7ff fe50 	bl	20021c04 <DMA_FreeChannel.isra.0>
20021f64:	4628      	mov	r0, r5
20021f66:	bd38      	pop	{r3, r4, r5, pc}
20021f68:	4b09      	ldr	r3, [pc, #36]	@ (20021f90 <HAL_DMA_Init+0xd0>)
20021f6a:	440b      	add	r3, r1
20021f6c:	2b8c      	cmp	r3, #140	@ 0x8c
20021f6e:	d807      	bhi.n	20021f80 <HAL_DMA_Init+0xc0>
20021f70:	2114      	movs	r1, #20
20021f72:	fbb3 f3f1 	udiv	r3, r3, r1
20021f76:	4907      	ldr	r1, [pc, #28]	@ (20021f94 <HAL_DMA_Init+0xd4>)
20021f78:	0098      	lsls	r0, r3, #2
20021f7a:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021f7e:	e7e0      	b.n	20021f42 <HAL_DMA_Init+0x82>
20021f80:	2501      	movs	r5, #1
20021f82:	e7ef      	b.n	20021f64 <HAL_DMA_Init+0xa4>
20021f84:	2502      	movs	r5, #2
20021f86:	e7ed      	b.n	20021f64 <HAL_DMA_Init+0xa4>
20021f88:	aff7eff8 	.word	0xaff7eff8
20021f8c:	50081000 	.word	0x50081000
20021f90:	bfffeff8 	.word	0xbfffeff8
20021f94:	40001000 	.word	0x40001000

20021f98 <HAL_DMA_DeInit>:
20021f98:	b538      	push	{r3, r4, r5, lr}
20021f9a:	4604      	mov	r4, r0
20021f9c:	2800      	cmp	r0, #0
20021f9e:	d05e      	beq.n	2002205e <HAL_DMA_DeInit+0xc6>
20021fa0:	6802      	ldr	r2, [r0, #0]
20021fa2:	4b30      	ldr	r3, [pc, #192]	@ (20022064 <HAL_DMA_DeInit+0xcc>)
20021fa4:	4413      	add	r3, r2
20021fa6:	2b8c      	cmp	r3, #140	@ 0x8c
20021fa8:	d841      	bhi.n	2002202e <HAL_DMA_DeInit+0x96>
20021faa:	2214      	movs	r2, #20
20021fac:	fbb3 f3f2 	udiv	r3, r3, r2
20021fb0:	009b      	lsls	r3, r3, #2
20021fb2:	6503      	str	r3, [r0, #80]	@ 0x50
20021fb4:	4b2c      	ldr	r3, [pc, #176]	@ (20022068 <HAL_DMA_DeInit+0xd0>)
20021fb6:	64e3      	str	r3, [r4, #76]	@ 0x4c
20021fb8:	4620      	mov	r0, r4
20021fba:	f7ff fdf7 	bl	20021bac <DMA_IsChannelOwner>
20021fbe:	b3a0      	cbz	r0, 2002202a <HAL_DMA_DeInit+0x92>
20021fc0:	6822      	ldr	r2, [r4, #0]
20021fc2:	6813      	ldr	r3, [r2, #0]
20021fc4:	f023 0301 	bic.w	r3, r3, #1
20021fc8:	6013      	str	r3, [r2, #0]
20021fca:	2200      	movs	r2, #0
20021fcc:	6823      	ldr	r3, [r4, #0]
20021fce:	601a      	str	r2, [r3, #0]
20021fd0:	2201      	movs	r2, #1
20021fd2:	e9d4 1313 	ldrd	r1, r3, [r4, #76]	@ 0x4c
20021fd6:	f003 031c 	and.w	r3, r3, #28
20021fda:	fa02 f303 	lsl.w	r3, r2, r3
20021fde:	604b      	str	r3, [r1, #4]
20021fe0:	f3ef 8510 	mrs	r5, PRIMASK
20021fe4:	f382 8810 	msr	PRIMASK, r2
20021fe8:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021fea:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
20021fec:	2b0f      	cmp	r3, #15
20021fee:	ea4f 0293 	mov.w	r2, r3, lsr #2
20021ff2:	d827      	bhi.n	20022044 <HAL_DMA_DeInit+0xac>
20021ff4:	203f      	movs	r0, #63	@ 0x3f
20021ff6:	005b      	lsls	r3, r3, #1
20021ff8:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
20021ffc:	f003 0338 	and.w	r3, r3, #56	@ 0x38
20022000:	fa00 f303 	lsl.w	r3, r0, r3
20022004:	ea22 0303 	bic.w	r3, r2, r3
20022008:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
2002200c:	f385 8810 	msr	PRIMASK, r5
20022010:	4620      	mov	r0, r4
20022012:	f7ff fdf7 	bl	20021c04 <DMA_FreeChannel.isra.0>
20022016:	2300      	movs	r3, #0
20022018:	e9c4 330e 	strd	r3, r3, [r4, #56]	@ 0x38
2002201c:	e9c4 3310 	strd	r3, r3, [r4, #64]	@ 0x40
20022020:	64a3      	str	r3, [r4, #72]	@ 0x48
20022022:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022026:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
2002202a:	2000      	movs	r0, #0
2002202c:	bd38      	pop	{r3, r4, r5, pc}
2002202e:	4b0f      	ldr	r3, [pc, #60]	@ (2002206c <HAL_DMA_DeInit+0xd4>)
20022030:	4413      	add	r3, r2
20022032:	2b8c      	cmp	r3, #140	@ 0x8c
20022034:	d8c0      	bhi.n	20021fb8 <HAL_DMA_DeInit+0x20>
20022036:	2214      	movs	r2, #20
20022038:	fbb3 f3f2 	udiv	r3, r3, r2
2002203c:	009b      	lsls	r3, r3, #2
2002203e:	6503      	str	r3, [r0, #80]	@ 0x50
20022040:	4b0b      	ldr	r3, [pc, #44]	@ (20022070 <HAL_DMA_DeInit+0xd8>)
20022042:	e7b8      	b.n	20021fb6 <HAL_DMA_DeInit+0x1e>
20022044:	f002 0303 	and.w	r3, r2, #3
20022048:	223f      	movs	r2, #63	@ 0x3f
2002204a:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
2002204e:	00db      	lsls	r3, r3, #3
20022050:	fa02 f303 	lsl.w	r3, r2, r3
20022054:	ea20 0303 	bic.w	r3, r0, r3
20022058:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
2002205c:	e7d6      	b.n	2002200c <HAL_DMA_DeInit+0x74>
2002205e:	2001      	movs	r0, #1
20022060:	e7e4      	b.n	2002202c <HAL_DMA_DeInit+0x94>
20022062:	bf00      	nop
20022064:	aff7eff8 	.word	0xaff7eff8
20022068:	50081000 	.word	0x50081000
2002206c:	bfffeff8 	.word	0xbfffeff8
20022070:	40001000 	.word	0x40001000

20022074 <HAL_DMA_PollForTransfer>:
20022074:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
20022078:	f890 3031 	ldrb.w	r3, [r0, #49]	@ 0x31
2002207c:	4617      	mov	r7, r2
2002207e:	2b02      	cmp	r3, #2
20022080:	4604      	mov	r4, r0
20022082:	4688      	mov	r8, r1
20022084:	b2da      	uxtb	r2, r3
20022086:	d005      	beq.n	20022094 <HAL_DMA_PollForTransfer+0x20>
20022088:	2304      	movs	r3, #4
2002208a:	6483      	str	r3, [r0, #72]	@ 0x48
2002208c:	2300      	movs	r3, #0
2002208e:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022092:	e006      	b.n	200220a2 <HAL_DMA_PollForTransfer+0x2e>
20022094:	6803      	ldr	r3, [r0, #0]
20022096:	681b      	ldr	r3, [r3, #0]
20022098:	0699      	lsls	r1, r3, #26
2002209a:	d505      	bpl.n	200220a8 <HAL_DMA_PollForTransfer+0x34>
2002209c:	f44f 7380 	mov.w	r3, #256	@ 0x100
200220a0:	6483      	str	r3, [r0, #72]	@ 0x48
200220a2:	2001      	movs	r0, #1
200220a4:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
200220a8:	6d05      	ldr	r5, [r0, #80]	@ 0x50
200220aa:	f005 051c 	and.w	r5, r5, #28
200220ae:	f1b8 0f00 	cmp.w	r8, #0
200220b2:	d123      	bne.n	200220fc <HAL_DMA_PollForTransfer+0x88>
200220b4:	fa02 f505 	lsl.w	r5, r2, r5
200220b8:	f7ff fc1e 	bl	200218f8 <HAL_GetTick>
200220bc:	f04f 0a08 	mov.w	sl, #8
200220c0:	4681      	mov	r9, r0
200220c2:	e9d4 6313 	ldrd	r6, r3, [r4, #76]	@ 0x4c
200220c6:	f003 031c 	and.w	r3, r3, #28
200220ca:	fa0a f103 	lsl.w	r1, sl, r3
200220ce:	6832      	ldr	r2, [r6, #0]
200220d0:	ea12 0b05 	ands.w	fp, r2, r5
200220d4:	d016      	beq.n	20022104 <HAL_DMA_PollForTransfer+0x90>
200220d6:	f1b8 0f00 	cmp.w	r8, #0
200220da:	d136      	bne.n	2002214a <HAL_DMA_PollForTransfer+0xd6>
200220dc:	2202      	movs	r2, #2
200220de:	fa02 f303 	lsl.w	r3, r2, r3
200220e2:	6073      	str	r3, [r6, #4]
200220e4:	6da3      	ldr	r3, [r4, #88]	@ 0x58
200220e6:	b92b      	cbnz	r3, 200220f4 <HAL_DMA_PollForTransfer+0x80>
200220e8:	4620      	mov	r0, r4
200220ea:	f7ff fd8b 	bl	20021c04 <DMA_FreeChannel.isra.0>
200220ee:	2301      	movs	r3, #1
200220f0:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200220f4:	2000      	movs	r0, #0
200220f6:	f884 0030 	strb.w	r0, [r4, #48]	@ 0x30
200220fa:	e7d3      	b.n	200220a4 <HAL_DMA_PollForTransfer+0x30>
200220fc:	2304      	movs	r3, #4
200220fe:	fa03 f505 	lsl.w	r5, r3, r5
20022102:	e7d9      	b.n	200220b8 <HAL_DMA_PollForTransfer+0x44>
20022104:	6832      	ldr	r2, [r6, #0]
20022106:	4211      	tst	r1, r2
20022108:	d00c      	beq.n	20022124 <HAL_DMA_PollForTransfer+0xb0>
2002210a:	2501      	movs	r5, #1
2002210c:	fa05 f303 	lsl.w	r3, r5, r3
20022110:	6073      	str	r3, [r6, #4]
20022112:	4620      	mov	r0, r4
20022114:	64a5      	str	r5, [r4, #72]	@ 0x48
20022116:	f7ff fd75 	bl	20021c04 <DMA_FreeChannel.isra.0>
2002211a:	f884 5031 	strb.w	r5, [r4, #49]	@ 0x31
2002211e:	f884 b030 	strb.w	fp, [r4, #48]	@ 0x30
20022122:	e7be      	b.n	200220a2 <HAL_DMA_PollForTransfer+0x2e>
20022124:	1c7a      	adds	r2, r7, #1
20022126:	d0d2      	beq.n	200220ce <HAL_DMA_PollForTransfer+0x5a>
20022128:	f7ff fbe6 	bl	200218f8 <HAL_GetTick>
2002212c:	eba0 0009 	sub.w	r0, r0, r9
20022130:	42b8      	cmp	r0, r7
20022132:	d801      	bhi.n	20022138 <HAL_DMA_PollForTransfer+0xc4>
20022134:	2f00      	cmp	r7, #0
20022136:	d1c4      	bne.n	200220c2 <HAL_DMA_PollForTransfer+0x4e>
20022138:	2320      	movs	r3, #32
2002213a:	4620      	mov	r0, r4
2002213c:	64a3      	str	r3, [r4, #72]	@ 0x48
2002213e:	f7ff fd61 	bl	20021c04 <DMA_FreeChannel.isra.0>
20022142:	2301      	movs	r3, #1
20022144:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022148:	e7a0      	b.n	2002208c <HAL_DMA_PollForTransfer+0x18>
2002214a:	2204      	movs	r2, #4
2002214c:	fa02 f303 	lsl.w	r3, r2, r3
20022150:	6073      	str	r3, [r6, #4]
20022152:	e7cf      	b.n	200220f4 <HAL_DMA_PollForTransfer+0x80>

20022154 <DMA_Remap>:
20022154:	b530      	push	{r4, r5, lr}
20022156:	4b15      	ldr	r3, [pc, #84]	@ (200221ac <DMA_Remap+0x58>)
20022158:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
2002215a:	429c      	cmp	r4, r3
2002215c:	d11b      	bne.n	20022196 <DMA_Remap+0x42>
2002215e:	6883      	ldr	r3, [r0, #8]
20022160:	2b10      	cmp	r3, #16
20022162:	d002      	beq.n	2002216a <DMA_Remap+0x16>
20022164:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20022168:	d108      	bne.n	2002217c <DMA_Remap+0x28>
2002216a:	680b      	ldr	r3, [r1, #0]
2002216c:	4c10      	ldr	r4, [pc, #64]	@ (200221b0 <DMA_Remap+0x5c>)
2002216e:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
20022172:	42a5      	cmp	r5, r4
20022174:	bf98      	it	ls
20022176:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
2002217a:	600b      	str	r3, [r1, #0]
2002217c:	6883      	ldr	r3, [r0, #8]
2002217e:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
20022182:	d108      	bne.n	20022196 <DMA_Remap+0x42>
20022184:	6813      	ldr	r3, [r2, #0]
20022186:	480a      	ldr	r0, [pc, #40]	@ (200221b0 <DMA_Remap+0x5c>)
20022188:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
2002218c:	4284      	cmp	r4, r0
2002218e:	bf98      	it	ls
20022190:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
20022194:	6013      	str	r3, [r2, #0]
20022196:	680b      	ldr	r3, [r1, #0]
20022198:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
2002219c:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
200221a0:	bf3c      	itt	cc
200221a2:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
200221a6:	600b      	strcc	r3, [r1, #0]
200221a8:	bd30      	pop	{r4, r5, pc}
200221aa:	bf00      	nop
200221ac:	40001000 	.word	0x40001000
200221b0:	0007fffe 	.word	0x0007fffe

200221b4 <DMA_Start>:
200221b4:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
200221b8:	f64f 75ff 	movw	r5, #65535	@ 0xffff
200221bc:	4a2f      	ldr	r2, [pc, #188]	@ (2002227c <DMA_Start+0xc8>)
200221be:	4f30      	ldr	r7, [pc, #192]	@ (20022280 <DMA_Start+0xcc>)
200221c0:	460e      	mov	r6, r1
200221c2:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
200221c4:	6d83      	ldr	r3, [r0, #88]	@ 0x58
200221c6:	4291      	cmp	r1, r2
200221c8:	bf18      	it	ne
200221ca:	463d      	movne	r5, r7
200221cc:	429d      	cmp	r5, r3
200221ce:	bf28      	it	cs
200221d0:	461d      	movcs	r5, r3
200221d2:	6802      	ldr	r2, [r0, #0]
200221d4:	1b5b      	subs	r3, r3, r5
200221d6:	6583      	str	r3, [r0, #88]	@ 0x58
200221d8:	6605      	str	r5, [r0, #96]	@ 0x60
200221da:	6813      	ldr	r3, [r2, #0]
200221dc:	f890 706e 	ldrb.w	r7, [r0, #110]	@ 0x6e
200221e0:	f023 0301 	bic.w	r3, r3, #1
200221e4:	f890 806f 	ldrb.w	r8, [r0, #111]	@ 0x6f
200221e8:	6013      	str	r3, [r2, #0]
200221ea:	e9d0 2319 	ldrd	r2, r3, [r0, #100]	@ 0x64
200221ee:	e9cd 2300 	strd	r2, r3, [sp]
200221f2:	e9d0 2313 	ldrd	r2, r3, [r0, #76]	@ 0x4c
200221f6:	f003 011c 	and.w	r1, r3, #28
200221fa:	2301      	movs	r3, #1
200221fc:	4604      	mov	r4, r0
200221fe:	408b      	lsls	r3, r1
20022200:	6053      	str	r3, [r2, #4]
20022202:	6803      	ldr	r3, [r0, #0]
20022204:	4669      	mov	r1, sp
20022206:	605d      	str	r5, [r3, #4]
20022208:	aa01      	add	r2, sp, #4
2002220a:	f7ff ffa3 	bl	20022154 <DMA_Remap>
2002220e:	e9dd 0300 	ldrd	r0, r3, [sp]
20022212:	68a1      	ldr	r1, [r4, #8]
20022214:	6822      	ldr	r2, [r4, #0]
20022216:	2910      	cmp	r1, #16
20022218:	bf0b      	itete	eq
2002221a:	6093      	streq	r3, [r2, #8]
2002221c:	6090      	strne	r0, [r2, #8]
2002221e:	6823      	ldreq	r3, [r4, #0]
20022220:	6822      	ldrne	r2, [r4, #0]
20022222:	bf0c      	ite	eq
20022224:	60d8      	streq	r0, [r3, #12]
20022226:	60d3      	strne	r3, [r2, #12]
20022228:	f894 306c 	ldrb.w	r3, [r4, #108]	@ 0x6c
2002222c:	b123      	cbz	r3, 20022238 <DMA_Start+0x84>
2002222e:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20022230:	fa05 f707 	lsl.w	r7, r5, r7
20022234:	443b      	add	r3, r7
20022236:	6663      	str	r3, [r4, #100]	@ 0x64
20022238:	f894 306d 	ldrb.w	r3, [r4, #109]	@ 0x6d
2002223c:	b123      	cbz	r3, 20022248 <DMA_Start+0x94>
2002223e:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
20022240:	fa05 f508 	lsl.w	r5, r5, r8
20022244:	442b      	add	r3, r5
20022246:	66a3      	str	r3, [r4, #104]	@ 0x68
20022248:	b136      	cbz	r6, 20022258 <DMA_Start+0xa4>
2002224a:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
2002224c:	6823      	ldr	r3, [r4, #0]
2002224e:	b15a      	cbz	r2, 20022268 <DMA_Start+0xb4>
20022250:	681a      	ldr	r2, [r3, #0]
20022252:	f042 020e 	orr.w	r2, r2, #14
20022256:	601a      	str	r2, [r3, #0]
20022258:	6822      	ldr	r2, [r4, #0]
2002225a:	6813      	ldr	r3, [r2, #0]
2002225c:	f043 0301 	orr.w	r3, r3, #1
20022260:	6013      	str	r3, [r2, #0]
20022262:	b002      	add	sp, #8
20022264:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022268:	681a      	ldr	r2, [r3, #0]
2002226a:	f022 0204 	bic.w	r2, r2, #4
2002226e:	601a      	str	r2, [r3, #0]
20022270:	6822      	ldr	r2, [r4, #0]
20022272:	6813      	ldr	r3, [r2, #0]
20022274:	f043 030a 	orr.w	r3, r3, #10
20022278:	6013      	str	r3, [r2, #0]
2002227a:	e7ed      	b.n	20022258 <DMA_Start+0xa4>
2002227c:	40001000 	.word	0x40001000
20022280:	000fffff 	.word	0x000fffff

20022284 <HAL_DMA_Start>:
20022284:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022286:	461d      	mov	r5, r3
20022288:	69c3      	ldr	r3, [r0, #28]
2002228a:	4604      	mov	r4, r0
2002228c:	2b20      	cmp	r3, #32
2002228e:	460f      	mov	r7, r1
20022290:	4616      	mov	r6, r2
20022292:	d10b      	bne.n	200222ac <HAL_DMA_Start+0x28>
20022294:	b14d      	cbz	r5, 200222aa <HAL_DMA_Start+0x26>
20022296:	f64f 73ff 	movw	r3, #65535	@ 0xffff
2002229a:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
2002229c:	4a1b      	ldr	r2, [pc, #108]	@ (2002230c <HAL_DMA_Start+0x88>)
2002229e:	481c      	ldr	r0, [pc, #112]	@ (20022310 <HAL_DMA_Start+0x8c>)
200222a0:	4291      	cmp	r1, r2
200222a2:	bf18      	it	ne
200222a4:	4603      	movne	r3, r0
200222a6:	42ab      	cmp	r3, r5
200222a8:	d800      	bhi.n	200222ac <HAL_DMA_Start+0x28>
200222aa:	e7fe      	b.n	200222aa <HAL_DMA_Start+0x26>
200222ac:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
200222b0:	2b01      	cmp	r3, #1
200222b2:	d00e      	beq.n	200222d2 <HAL_DMA_Start+0x4e>
200222b4:	2301      	movs	r3, #1
200222b6:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200222ba:	f894 3031 	ldrb.w	r3, [r4, #49]	@ 0x31
200222be:	2b01      	cmp	r3, #1
200222c0:	b2d9      	uxtb	r1, r3
200222c2:	d103      	bne.n	200222cc <HAL_DMA_Start+0x48>
200222c4:	4620      	mov	r0, r4
200222c6:	f7ff fd8f 	bl	20021de8 <DMA_AllocChannel>
200222ca:	b120      	cbz	r0, 200222d6 <HAL_DMA_Start+0x52>
200222cc:	2300      	movs	r3, #0
200222ce:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200222d2:	2002      	movs	r0, #2
200222d4:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200222d6:	2302      	movs	r3, #2
200222d8:	e9c4 5516 	strd	r5, r5, [r4, #88]	@ 0x58
200222dc:	e9c4 7619 	strd	r7, r6, [r4, #100]	@ 0x64
200222e0:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200222e4:	64a0      	str	r0, [r4, #72]	@ 0x48
200222e6:	6da0      	ldr	r0, [r4, #88]	@ 0x58
200222e8:	2800      	cmp	r0, #0
200222ea:	d0f3      	beq.n	200222d4 <HAL_DMA_Start+0x50>
200222ec:	2100      	movs	r1, #0
200222ee:	4620      	mov	r0, r4
200222f0:	f7ff ff60 	bl	200221b4 <DMA_Start>
200222f4:	6da3      	ldr	r3, [r4, #88]	@ 0x58
200222f6:	2b00      	cmp	r3, #0
200222f8:	d0f5      	beq.n	200222e6 <HAL_DMA_Start+0x62>
200222fa:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
200222fe:	2100      	movs	r1, #0
20022300:	4620      	mov	r0, r4
20022302:	f7ff feb7 	bl	20022074 <HAL_DMA_PollForTransfer>
20022306:	2800      	cmp	r0, #0
20022308:	d0ed      	beq.n	200222e6 <HAL_DMA_Start+0x62>
2002230a:	e7e3      	b.n	200222d4 <HAL_DMA_Start+0x50>
2002230c:	40001000 	.word	0x40001000
20022310:	000fffff 	.word	0x000fffff

20022314 <HAL_EFUSE_Read>:
20022314:	2a20      	cmp	r2, #32
20022316:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
2002231a:	4607      	mov	r7, r0
2002231c:	460c      	mov	r4, r1
2002231e:	4690      	mov	r8, r2
20022320:	dc25      	bgt.n	2002236e <HAL_EFUSE_Read+0x5a>
20022322:	f3c0 09c4 	ubfx	r9, r0, #3, #5
20022326:	eb09 0302 	add.w	r3, r9, r2
2002232a:	2b20      	cmp	r3, #32
2002232c:	dc1f      	bgt.n	2002236e <HAL_EFUSE_Read+0x5a>
2002232e:	f012 0f03 	tst.w	r2, #3
20022332:	d11c      	bne.n	2002236e <HAL_EFUSE_Read+0x5a>
20022334:	f010 051f 	ands.w	r5, r0, #31
20022338:	d119      	bne.n	2002236e <HAL_EFUSE_Read+0x5a>
2002233a:	2003      	movs	r0, #3
2002233c:	f7ff fa40 	bl	200217c0 <pmu_ldo_inc>
20022340:	4629      	mov	r1, r5
20022342:	4e1d      	ldr	r6, [pc, #116]	@ (200223b8 <HAL_EFUSE_Read+0xa4>)
20022344:	0a3f      	lsrs	r7, r7, #8
20022346:	00bb      	lsls	r3, r7, #2
20022348:	6033      	str	r3, [r6, #0]
2002234a:	6833      	ldr	r3, [r6, #0]
2002234c:	4a1b      	ldr	r2, [pc, #108]	@ (200223bc <HAL_EFUSE_Read+0xa8>)
2002234e:	f043 0301 	orr.w	r3, r3, #1
20022352:	6033      	str	r3, [r6, #0]
20022354:	68b3      	ldr	r3, [r6, #8]
20022356:	07db      	lsls	r3, r3, #31
20022358:	d401      	bmi.n	2002235e <HAL_EFUSE_Read+0x4a>
2002235a:	4291      	cmp	r1, r2
2002235c:	d10c      	bne.n	20022378 <HAL_EFUSE_Read+0x64>
2002235e:	68b3      	ldr	r3, [r6, #8]
20022360:	4291      	cmp	r1, r2
20022362:	f043 0301 	orr.w	r3, r3, #1
20022366:	60b3      	str	r3, [r6, #8]
20022368:	d108      	bne.n	2002237c <HAL_EFUSE_Read+0x68>
2002236a:	f7ff fa2b 	bl	200217c4 <pmu_ldo_recover>
2002236e:	f04f 0800 	mov.w	r8, #0
20022372:	4640      	mov	r0, r8
20022374:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20022378:	3101      	adds	r1, #1
2002237a:	e7eb      	b.n	20022354 <HAL_EFUSE_Read+0x40>
2002237c:	4a10      	ldr	r2, [pc, #64]	@ (200223c0 <HAL_EFUSE_Read+0xac>)
2002237e:	f009 031c 	and.w	r3, r9, #28
20022382:	eb03 1347 	add.w	r3, r3, r7, lsl #5
20022386:	f028 0103 	bic.w	r1, r8, #3
2002238a:	441a      	add	r2, r3
2002238c:	4421      	add	r1, r4
2002238e:	428c      	cmp	r4, r1
20022390:	d102      	bne.n	20022398 <HAL_EFUSE_Read+0x84>
20022392:	f7ff fa17 	bl	200217c4 <pmu_ldo_recover>
20022396:	e7ec      	b.n	20022372 <HAL_EFUSE_Read+0x5e>
20022398:	f852 3b04 	ldr.w	r3, [r2], #4
2002239c:	3404      	adds	r4, #4
2002239e:	0a1d      	lsrs	r5, r3, #8
200223a0:	f804 3c04 	strb.w	r3, [r4, #-4]
200223a4:	f804 5c03 	strb.w	r5, [r4, #-3]
200223a8:	0c1d      	lsrs	r5, r3, #16
200223aa:	0e1b      	lsrs	r3, r3, #24
200223ac:	f804 5c02 	strb.w	r5, [r4, #-2]
200223b0:	f804 3c01 	strb.w	r3, [r4, #-1]
200223b4:	e7eb      	b.n	2002238e <HAL_EFUSE_Read+0x7a>
200223b6:	bf00      	nop
200223b8:	5000c000 	.word	0x5000c000
200223bc:	00bb8000 	.word	0x00bb8000
200223c0:	5000c030 	.word	0x5000c030

200223c4 <HAL_HPAON_EnableXT48>:
200223c4:	4b04      	ldr	r3, [pc, #16]	@ (200223d8 <HAL_HPAON_EnableXT48+0x14>)
200223c6:	689a      	ldr	r2, [r3, #8]
200223c8:	f042 0202 	orr.w	r2, r2, #2
200223cc:	609a      	str	r2, [r3, #8]
200223ce:	689a      	ldr	r2, [r3, #8]
200223d0:	2a00      	cmp	r2, #0
200223d2:	dafc      	bge.n	200223ce <HAL_HPAON_EnableXT48+0xa>
200223d4:	4770      	bx	lr
200223d6:	bf00      	nop
200223d8:	500c0000 	.word	0x500c0000

200223dc <HAL_HPAON_DisableXT48>:
200223dc:	4a02      	ldr	r2, [pc, #8]	@ (200223e8 <HAL_HPAON_DisableXT48+0xc>)
200223de:	6893      	ldr	r3, [r2, #8]
200223e0:	f023 0302 	bic.w	r3, r3, #2
200223e4:	6093      	str	r3, [r2, #8]
200223e6:	4770      	bx	lr
200223e8:	500c0000 	.word	0x500c0000

200223ec <HAL_QSPI_Init>:
200223ec:	b510      	push	{r4, lr}
200223ee:	b1e8      	cbz	r0, 2002242c <HAL_QSPI_Init+0x40>
200223f0:	b1e1      	cbz	r1, 2002242c <HAL_QSPI_Init+0x40>
200223f2:	2300      	movs	r3, #0
200223f4:	2201      	movs	r2, #1
200223f6:	6043      	str	r3, [r0, #4]
200223f8:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
200223fc:	680c      	ldr	r4, [r1, #0]
200223fe:	6004      	str	r4, [r0, #0]
20022400:	684a      	ldr	r2, [r1, #4]
20022402:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
20022406:	688a      	ldr	r2, [r1, #8]
20022408:	6102      	str	r2, [r0, #16]
2002240a:	68ca      	ldr	r2, [r1, #12]
2002240c:	0512      	lsls	r2, r2, #20
2002240e:	6142      	str	r2, [r0, #20]
20022410:	22ff      	movs	r2, #255	@ 0xff
20022412:	f8c4 208c 	str.w	r2, [r4, #140]	@ 0x8c
20022416:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
2002241a:	6801      	ldr	r1, [r0, #0]
2002241c:	f8c1 4080 	str.w	r4, [r1, #128]	@ 0x80
20022420:	6801      	ldr	r1, [r0, #0]
20022422:	620a      	str	r2, [r1, #32]
20022424:	6801      	ldr	r1, [r0, #0]
20022426:	4618      	mov	r0, r3
20022428:	644a      	str	r2, [r1, #68]	@ 0x44
2002242a:	bd10      	pop	{r4, pc}
2002242c:	2001      	movs	r0, #1
2002242e:	e7fc      	b.n	2002242a <HAL_QSPI_Init+0x3e>

20022430 <HAL_FLASH_SET_AHB_RCMD>:
20022430:	b138      	cbz	r0, 20022442 <HAL_FLASH_SET_AHB_RCMD+0x12>
20022432:	6802      	ldr	r2, [r0, #0]
20022434:	2000      	movs	r0, #0
20022436:	6c13      	ldr	r3, [r2, #64]	@ 0x40
20022438:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
2002243c:	4319      	orrs	r1, r3
2002243e:	6411      	str	r1, [r2, #64]	@ 0x40
20022440:	4770      	bx	lr
20022442:	2001      	movs	r0, #1
20022444:	4770      	bx	lr

20022446 <HAL_FLASH_CFG_AHB_RCMD>:
20022446:	b570      	push	{r4, r5, r6, lr}
20022448:	b1c8      	cbz	r0, 2002247e <HAL_FLASH_CFG_AHB_RCMD+0x38>
2002244a:	6805      	ldr	r5, [r0, #0]
2002244c:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022450:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022454:	6cac      	ldr	r4, [r5, #72]	@ 0x48
20022456:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002245a:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
2002245e:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022462:	f36f 0414 	bfc	r4, #0, #21
20022466:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
2002246a:	f99d 0014 	ldrsb.w	r0, [sp, #20]
2002246e:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022472:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
20022476:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
2002247a:	4321      	orrs	r1, r4
2002247c:	64a9      	str	r1, [r5, #72]	@ 0x48
2002247e:	bd70      	pop	{r4, r5, r6, pc}

20022480 <HAL_FLASH_SET_AHB_WCMD>:
20022480:	b140      	cbz	r0, 20022494 <HAL_FLASH_SET_AHB_WCMD+0x14>
20022482:	6802      	ldr	r2, [r0, #0]
20022484:	2000      	movs	r0, #0
20022486:	6c13      	ldr	r3, [r2, #64]	@ 0x40
20022488:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
2002248c:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
20022490:	6411      	str	r1, [r2, #64]	@ 0x40
20022492:	4770      	bx	lr
20022494:	2001      	movs	r0, #1
20022496:	4770      	bx	lr

20022498 <HAL_FLASH_CFG_AHB_WCMD>:
20022498:	b570      	push	{r4, r5, r6, lr}
2002249a:	b1c8      	cbz	r0, 200224d0 <HAL_FLASH_CFG_AHB_WCMD+0x38>
2002249c:	6805      	ldr	r5, [r0, #0]
2002249e:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200224a2:	f99d 001c 	ldrsb.w	r0, [sp, #28]
200224a6:	6d2c      	ldr	r4, [r5, #80]	@ 0x50
200224a8:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200224ac:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
200224b0:	f99d 0010 	ldrsb.w	r0, [sp, #16]
200224b4:	f36f 0414 	bfc	r4, #0, #21
200224b8:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
200224bc:	f99d 0014 	ldrsb.w	r0, [sp, #20]
200224c0:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
200224c4:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
200224c8:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
200224cc:	4321      	orrs	r1, r4
200224ce:	6529      	str	r1, [r5, #80]	@ 0x50
200224d0:	bd70      	pop	{r4, r5, r6, pc}

200224d2 <HAL_FLASH_WRITE_WORD>:
200224d2:	b118      	cbz	r0, 200224dc <HAL_FLASH_WRITE_WORD+0xa>
200224d4:	6803      	ldr	r3, [r0, #0]
200224d6:	2000      	movs	r0, #0
200224d8:	6059      	str	r1, [r3, #4]
200224da:	4770      	bx	lr
200224dc:	2001      	movs	r0, #1
200224de:	4770      	bx	lr

200224e0 <HAL_FLASH_WRITE_DLEN>:
200224e0:	b130      	cbz	r0, 200224f0 <HAL_FLASH_WRITE_DLEN+0x10>
200224e2:	6803      	ldr	r3, [r0, #0]
200224e4:	3901      	subs	r1, #1
200224e6:	f3c1 0113 	ubfx	r1, r1, #0, #20
200224ea:	2000      	movs	r0, #0
200224ec:	6259      	str	r1, [r3, #36]	@ 0x24
200224ee:	4770      	bx	lr
200224f0:	2001      	movs	r0, #1
200224f2:	4770      	bx	lr

200224f4 <HAL_FLASH_WRITE_DLEN2>:
200224f4:	b130      	cbz	r0, 20022504 <HAL_FLASH_WRITE_DLEN2+0x10>
200224f6:	6803      	ldr	r3, [r0, #0]
200224f8:	3901      	subs	r1, #1
200224fa:	f3c1 0113 	ubfx	r1, r1, #0, #20
200224fe:	2000      	movs	r0, #0
20022500:	6399      	str	r1, [r3, #56]	@ 0x38
20022502:	4770      	bx	lr
20022504:	2001      	movs	r0, #1
20022506:	4770      	bx	lr

20022508 <HAL_FLASH_WRITE_ABYTE>:
20022508:	b108      	cbz	r0, 2002250e <HAL_FLASH_WRITE_ABYTE+0x6>
2002250a:	6803      	ldr	r3, [r0, #0]
2002250c:	6219      	str	r1, [r3, #32]
2002250e:	4770      	bx	lr

20022510 <HAL_FLASH_IS_CMD_DONE>:
20022510:	b118      	cbz	r0, 2002251a <HAL_FLASH_IS_CMD_DONE+0xa>
20022512:	6803      	ldr	r3, [r0, #0]
20022514:	6918      	ldr	r0, [r3, #16]
20022516:	f000 0001 	and.w	r0, r0, #1
2002251a:	4770      	bx	lr

2002251c <HAL_FLASH_CLR_CMD_DONE>:
2002251c:	b120      	cbz	r0, 20022528 <HAL_FLASH_CLR_CMD_DONE+0xc>
2002251e:	6802      	ldr	r2, [r0, #0]
20022520:	6953      	ldr	r3, [r2, #20]
20022522:	f043 0301 	orr.w	r3, r3, #1
20022526:	6153      	str	r3, [r2, #20]
20022528:	4770      	bx	lr

2002252a <HAL_FLASH_SET_CMD>:
2002252a:	b538      	push	{r3, r4, r5, lr}
2002252c:	460d      	mov	r5, r1
2002252e:	4604      	mov	r4, r0
20022530:	b1a8      	cbz	r0, 2002255e <HAL_FLASH_SET_CMD+0x34>
20022532:	6803      	ldr	r3, [r0, #0]
20022534:	61da      	str	r2, [r3, #28]
20022536:	6b43      	ldr	r3, [r0, #52]	@ 0x34
20022538:	b10b      	cbz	r3, 2002253e <HAL_FLASH_SET_CMD+0x14>
2002253a:	2001      	movs	r0, #1
2002253c:	4798      	blx	r3
2002253e:	6823      	ldr	r3, [r4, #0]
20022540:	619d      	str	r5, [r3, #24]
20022542:	4620      	mov	r0, r4
20022544:	f7ff ffe4 	bl	20022510 <HAL_FLASH_IS_CMD_DONE>
20022548:	2800      	cmp	r0, #0
2002254a:	d0fa      	beq.n	20022542 <HAL_FLASH_SET_CMD+0x18>
2002254c:	4620      	mov	r0, r4
2002254e:	f7ff ffe5 	bl	2002251c <HAL_FLASH_CLR_CMD_DONE>
20022552:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20022554:	b10b      	cbz	r3, 2002255a <HAL_FLASH_SET_CMD+0x30>
20022556:	2000      	movs	r0, #0
20022558:	4798      	blx	r3
2002255a:	2000      	movs	r0, #0
2002255c:	bd38      	pop	{r3, r4, r5, pc}
2002255e:	2001      	movs	r0, #1
20022560:	e7fc      	b.n	2002255c <HAL_FLASH_SET_CMD+0x32>

20022562 <HAL_FLASH_CLR_STATUS>:
20022562:	b118      	cbz	r0, 2002256c <HAL_FLASH_CLR_STATUS+0xa>
20022564:	6802      	ldr	r2, [r0, #0]
20022566:	6953      	ldr	r3, [r2, #20]
20022568:	4319      	orrs	r1, r3
2002256a:	6151      	str	r1, [r2, #20]
2002256c:	4770      	bx	lr

2002256e <HAL_FLASH_STATUS_MATCH>:
2002256e:	b118      	cbz	r0, 20022578 <HAL_FLASH_STATUS_MATCH+0xa>
20022570:	6803      	ldr	r3, [r0, #0]
20022572:	6918      	ldr	r0, [r3, #16]
20022574:	f3c0 00c0 	ubfx	r0, r0, #3, #1
20022578:	4770      	bx	lr

2002257a <HAL_FLASH_IS_PROG_DONE>:
2002257a:	b128      	cbz	r0, 20022588 <HAL_FLASH_IS_PROG_DONE+0xe>
2002257c:	6803      	ldr	r3, [r0, #0]
2002257e:	6858      	ldr	r0, [r3, #4]
20022580:	43c0      	mvns	r0, r0
20022582:	f000 0001 	and.w	r0, r0, #1
20022586:	4770      	bx	lr
20022588:	2001      	movs	r0, #1
2002258a:	4770      	bx	lr

2002258c <HAL_FLASH_READ32>:
2002258c:	b108      	cbz	r0, 20022592 <HAL_FLASH_READ32+0x6>
2002258e:	6803      	ldr	r3, [r0, #0]
20022590:	6858      	ldr	r0, [r3, #4]
20022592:	4770      	bx	lr

20022594 <HAL_FLASH_SET_TXSLOT>:
20022594:	b120      	cbz	r0, 200225a0 <HAL_FLASH_SET_TXSLOT+0xc>
20022596:	6802      	ldr	r2, [r0, #0]
20022598:	6d53      	ldr	r3, [r2, #84]	@ 0x54
2002259a:	f361 238e 	bfi	r3, r1, #10, #5
2002259e:	6553      	str	r3, [r2, #84]	@ 0x54
200225a0:	4770      	bx	lr

200225a2 <HAL_FLASH_SET_CLK_rom>:
200225a2:	b108      	cbz	r0, 200225a8 <HAL_FLASH_SET_CLK_rom+0x6>
200225a4:	6803      	ldr	r3, [r0, #0]
200225a6:	60d9      	str	r1, [r3, #12]
200225a8:	4770      	bx	lr

200225aa <HAL_FLASH_GET_DIV>:
200225aa:	b110      	cbz	r0, 200225b2 <HAL_FLASH_GET_DIV+0x8>
200225ac:	6803      	ldr	r3, [r0, #0]
200225ae:	68d8      	ldr	r0, [r3, #12]
200225b0:	b2c0      	uxtb	r0, r0
200225b2:	4770      	bx	lr

200225b4 <HAL_FLASH_MANUAL_CMD>:
200225b4:	b570      	push	{r4, r5, r6, lr}
200225b6:	b1e8      	cbz	r0, 200225f4 <HAL_FLASH_MANUAL_CMD+0x40>
200225b8:	6805      	ldr	r5, [r0, #0]
200225ba:	f99d 601c 	ldrsb.w	r6, [sp, #28]
200225be:	f99d 0020 	ldrsb.w	r0, [sp, #32]
200225c2:	6aac      	ldr	r4, [r5, #40]	@ 0x28
200225c4:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200225c8:	f99d 6010 	ldrsb.w	r6, [sp, #16]
200225cc:	f36f 0415 	bfc	r4, #0, #22
200225d0:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
200225d4:	f99d 6014 	ldrsb.w	r6, [sp, #20]
200225d8:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
200225dc:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200225e0:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
200225e4:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
200225e8:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200225ec:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200225f0:	4321      	orrs	r1, r4
200225f2:	62a9      	str	r1, [r5, #40]	@ 0x28
200225f4:	bd70      	pop	{r4, r5, r6, pc}

200225f6 <HAL_FLASH_MANUAL_CMD2>:
200225f6:	b570      	push	{r4, r5, r6, lr}
200225f8:	b1e8      	cbz	r0, 20022636 <HAL_FLASH_MANUAL_CMD2+0x40>
200225fa:	6805      	ldr	r5, [r0, #0]
200225fc:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022600:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022604:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
20022606:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002260a:	f99d 6010 	ldrsb.w	r6, [sp, #16]
2002260e:	f36f 0415 	bfc	r4, #0, #22
20022612:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022616:	f99d 6014 	ldrsb.w	r6, [sp, #20]
2002261a:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
2002261e:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022622:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022626:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
2002262a:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
2002262e:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
20022632:	4321      	orrs	r1, r4
20022634:	63e9      	str	r1, [r5, #60]	@ 0x3c
20022636:	bd70      	pop	{r4, r5, r6, pc}

20022638 <HAL_FLASH_SET_ALIAS_RANGE>:
20022638:	b510      	push	{r4, lr}
2002263a:	b158      	cbz	r0, 20022654 <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
2002263c:	4b06      	ldr	r3, [pc, #24]	@ (20022658 <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
2002263e:	6804      	ldr	r4, [r0, #0]
20022640:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
20022644:	440a      	add	r2, r1
20022646:	4019      	ands	r1, r3
20022648:	6761      	str	r1, [r4, #116]	@ 0x74
2002264a:	401a      	ands	r2, r3
2002264c:	6803      	ldr	r3, [r0, #0]
2002264e:	2000      	movs	r0, #0
20022650:	679a      	str	r2, [r3, #120]	@ 0x78
20022652:	bd10      	pop	{r4, pc}
20022654:	2001      	movs	r0, #1
20022656:	e7fc      	b.n	20022652 <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
20022658:	fffffc00 	.word	0xfffffc00

2002265c <HAL_FLASH_SET_ALIAS_OFFSET>:
2002265c:	b128      	cbz	r0, 2002266a <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
2002265e:	6803      	ldr	r3, [r0, #0]
20022660:	f36f 0109 	bfc	r1, #0, #10
20022664:	2000      	movs	r0, #0
20022666:	67d9      	str	r1, [r3, #124]	@ 0x7c
20022668:	4770      	bx	lr
2002266a:	2001      	movs	r0, #1
2002266c:	4770      	bx	lr

2002266e <HAL_FLASH_ENABLE_QSPI>:
2002266e:	b150      	cbz	r0, 20022686 <HAL_FLASH_ENABLE_QSPI+0x18>
20022670:	6803      	ldr	r3, [r0, #0]
20022672:	681a      	ldr	r2, [r3, #0]
20022674:	b121      	cbz	r1, 20022680 <HAL_FLASH_ENABLE_QSPI+0x12>
20022676:	f042 0201 	orr.w	r2, r2, #1
2002267a:	2000      	movs	r0, #0
2002267c:	601a      	str	r2, [r3, #0]
2002267e:	4770      	bx	lr
20022680:	f022 0201 	bic.w	r2, r2, #1
20022684:	e7f9      	b.n	2002267a <HAL_FLASH_ENABLE_QSPI+0xc>
20022686:	2001      	movs	r0, #1
20022688:	4770      	bx	lr

2002268a <HAL_FLASH_ENABLE_OPI>:
2002268a:	b150      	cbz	r0, 200226a2 <HAL_FLASH_ENABLE_OPI+0x18>
2002268c:	6803      	ldr	r3, [r0, #0]
2002268e:	681a      	ldr	r2, [r3, #0]
20022690:	b121      	cbz	r1, 2002269c <HAL_FLASH_ENABLE_OPI+0x12>
20022692:	f442 1200 	orr.w	r2, r2, #2097152	@ 0x200000
20022696:	2000      	movs	r0, #0
20022698:	601a      	str	r2, [r3, #0]
2002269a:	4770      	bx	lr
2002269c:	f422 1200 	bic.w	r2, r2, #2097152	@ 0x200000
200226a0:	e7f9      	b.n	20022696 <HAL_FLASH_ENABLE_OPI+0xc>
200226a2:	2001      	movs	r0, #1
200226a4:	4770      	bx	lr

200226a6 <HAL_FLASH_ENABLE_HYPER>:
200226a6:	b148      	cbz	r0, 200226bc <HAL_FLASH_ENABLE_HYPER+0x16>
200226a8:	6802      	ldr	r2, [r0, #0]
200226aa:	6893      	ldr	r3, [r2, #8]
200226ac:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
200226b0:	b109      	cbz	r1, 200226b6 <HAL_FLASH_ENABLE_HYPER+0x10>
200226b2:	f043 0320 	orr.w	r3, r3, #32
200226b6:	2000      	movs	r0, #0
200226b8:	6093      	str	r3, [r2, #8]
200226ba:	4770      	bx	lr
200226bc:	2001      	movs	r0, #1
200226be:	4770      	bx	lr

200226c0 <HAL_FLASH_ENABLE_CMD2>:
200226c0:	b150      	cbz	r0, 200226d8 <HAL_FLASH_ENABLE_CMD2+0x18>
200226c2:	6803      	ldr	r3, [r0, #0]
200226c4:	681a      	ldr	r2, [r3, #0]
200226c6:	b121      	cbz	r1, 200226d2 <HAL_FLASH_ENABLE_CMD2+0x12>
200226c8:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
200226cc:	2000      	movs	r0, #0
200226ce:	601a      	str	r2, [r3, #0]
200226d0:	4770      	bx	lr
200226d2:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
200226d6:	e7f9      	b.n	200226cc <HAL_FLASH_ENABLE_CMD2+0xc>
200226d8:	2001      	movs	r0, #1
200226da:	4770      	bx	lr

200226dc <HAL_FLASH_STAUS_MATCH_CMD2>:
200226dc:	b150      	cbz	r0, 200226f4 <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
200226de:	6803      	ldr	r3, [r0, #0]
200226e0:	681a      	ldr	r2, [r3, #0]
200226e2:	b121      	cbz	r1, 200226ee <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
200226e4:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
200226e8:	2000      	movs	r0, #0
200226ea:	601a      	str	r2, [r3, #0]
200226ec:	4770      	bx	lr
200226ee:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
200226f2:	e7f9      	b.n	200226e8 <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
200226f4:	2001      	movs	r0, #1
200226f6:	4770      	bx	lr

200226f8 <HAL_FLASH_SET_CS_TIME>:
200226f8:	b530      	push	{r4, r5, lr}
200226fa:	b180      	cbz	r0, 2002271e <HAL_FLASH_SET_CS_TIME+0x26>
200226fc:	6805      	ldr	r5, [r0, #0]
200226fe:	f8bd 000c 	ldrh.w	r0, [sp, #12]
20022702:	68ac      	ldr	r4, [r5, #8]
20022704:	0680      	lsls	r0, r0, #26
20022706:	ea40 5383 	orr.w	r3, r0, r3, lsl #22
2002270a:	2000      	movs	r0, #0
2002270c:	ea43 4181 	orr.w	r1, r3, r1, lsl #18
20022710:	f36f 149e 	bfc	r4, #6, #25
20022714:	ea41 1282 	orr.w	r2, r1, r2, lsl #6
20022718:	4322      	orrs	r2, r4
2002271a:	60aa      	str	r2, [r5, #8]
2002271c:	bd30      	pop	{r4, r5, pc}
2002271e:	2001      	movs	r0, #1
20022720:	e7fc      	b.n	2002271c <HAL_FLASH_SET_CS_TIME+0x24>

20022722 <HAL_FLASH_SET_ROW_BOUNDARY>:
20022722:	b130      	cbz	r0, 20022732 <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
20022724:	6802      	ldr	r2, [r0, #0]
20022726:	2000      	movs	r0, #0
20022728:	6893      	ldr	r3, [r2, #8]
2002272a:	f361 0302 	bfi	r3, r1, #0, #3
2002272e:	6093      	str	r3, [r2, #8]
20022730:	4770      	bx	lr
20022732:	2001      	movs	r0, #1
20022734:	4770      	bx	lr

20022736 <HAL_FLASH_SET_LEGACY>:
20022736:	b148      	cbz	r0, 2002274c <HAL_FLASH_SET_LEGACY+0x16>
20022738:	6802      	ldr	r2, [r0, #0]
2002273a:	6893      	ldr	r3, [r2, #8]
2002273c:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
20022740:	b109      	cbz	r1, 20022746 <HAL_FLASH_SET_LEGACY+0x10>
20022742:	f043 0310 	orr.w	r3, r3, #16
20022746:	2000      	movs	r0, #0
20022748:	6093      	str	r3, [r2, #8]
2002274a:	4770      	bx	lr
2002274c:	2001      	movs	r0, #1
2002274e:	4770      	bx	lr

20022750 <HAL_FLASH_SET_DUAL_MODE>:
20022750:	b150      	cbz	r0, 20022768 <HAL_FLASH_SET_DUAL_MODE+0x18>
20022752:	6803      	ldr	r3, [r0, #0]
20022754:	681a      	ldr	r2, [r3, #0]
20022756:	b121      	cbz	r1, 20022762 <HAL_FLASH_SET_DUAL_MODE+0x12>
20022758:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
2002275c:	2000      	movs	r0, #0
2002275e:	601a      	str	r2, [r3, #0]
20022760:	4770      	bx	lr
20022762:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
20022766:	e7f9      	b.n	2002275c <HAL_FLASH_SET_DUAL_MODE+0xc>
20022768:	2001      	movs	r0, #1
2002276a:	4770      	bx	lr

2002276c <HAL_FLASH_SET_X16_MODE>:
2002276c:	b150      	cbz	r0, 20022784 <HAL_FLASH_SET_X16_MODE+0x18>
2002276e:	6803      	ldr	r3, [r0, #0]
20022770:	681a      	ldr	r2, [r3, #0]
20022772:	b121      	cbz	r1, 2002277e <HAL_FLASH_SET_X16_MODE+0x12>
20022774:	f442 0200 	orr.w	r2, r2, #8388608	@ 0x800000
20022778:	2000      	movs	r0, #0
2002277a:	601a      	str	r2, [r3, #0]
2002277c:	4770      	bx	lr
2002277e:	f422 0200 	bic.w	r2, r2, #8388608	@ 0x800000
20022782:	e7f9      	b.n	20022778 <HAL_FLASH_SET_X16_MODE+0xc>
20022784:	2001      	movs	r0, #1
20022786:	4770      	bx	lr

20022788 <HAL_MPI_EN_FIXLAT>:
20022788:	2000      	movs	r0, #0
2002278a:	4770      	bx	lr

2002278c <HAL_MPI_ENABLE_DQS>:
2002278c:	fab0 f080 	clz	r0, r0
20022790:	0940      	lsrs	r0, r0, #5
20022792:	4770      	bx	lr

20022794 <HAL_MPI_SET_DQS_DELAY>:
20022794:	b138      	cbz	r0, 200227a6 <HAL_MPI_SET_DQS_DELAY+0x12>
20022796:	6802      	ldr	r2, [r0, #0]
20022798:	2000      	movs	r0, #0
2002279a:	6d93      	ldr	r3, [r2, #88]	@ 0x58
2002279c:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
200227a0:	4319      	orrs	r1, r3
200227a2:	6591      	str	r1, [r2, #88]	@ 0x58
200227a4:	4770      	bx	lr
200227a6:	2001      	movs	r0, #1
200227a8:	4770      	bx	lr

200227aa <HAL_MPI_SET_SCK>:
200227aa:	b150      	cbz	r0, 200227c2 <HAL_MPI_SET_SCK+0x18>
200227ac:	6800      	ldr	r0, [r0, #0]
200227ae:	0412      	lsls	r2, r2, #16
200227b0:	6d83      	ldr	r3, [r0, #88]	@ 0x58
200227b2:	ea42 2101 	orr.w	r1, r2, r1, lsl #8
200227b6:	f36f 2310 	bfc	r3, #8, #9
200227ba:	4319      	orrs	r1, r3
200227bc:	6581      	str	r1, [r0, #88]	@ 0x58
200227be:	2000      	movs	r0, #0
200227c0:	4770      	bx	lr
200227c2:	2001      	movs	r0, #1
200227c4:	4770      	bx	lr

200227c6 <HAL_MPI_CFG_DTR>:
200227c6:	6803      	ldr	r3, [r0, #0]
200227c8:	6d9a      	ldr	r2, [r3, #88]	@ 0x58
200227ca:	b121      	cbz	r1, 200227d6 <HAL_MPI_CFG_DTR+0x10>
200227cc:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
200227d0:	2000      	movs	r0, #0
200227d2:	659a      	str	r2, [r3, #88]	@ 0x58
200227d4:	4770      	bx	lr
200227d6:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
200227da:	e7f9      	b.n	200227d0 <HAL_MPI_CFG_DTR+0xa>

200227dc <HAL_MPI_MODIFY_RCMD_DELAY>:
200227dc:	b130      	cbz	r0, 200227ec <HAL_MPI_MODIFY_RCMD_DELAY+0x10>
200227de:	6802      	ldr	r2, [r0, #0]
200227e0:	6c93      	ldr	r3, [r2, #72]	@ 0x48
200227e2:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
200227e6:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
200227ea:	6491      	str	r1, [r2, #72]	@ 0x48
200227ec:	4770      	bx	lr

200227ee <HAL_MPI_MODIFY_WCMD_DELAY>:
200227ee:	b130      	cbz	r0, 200227fe <HAL_MPI_MODIFY_WCMD_DELAY+0x10>
200227f0:	6802      	ldr	r2, [r0, #0]
200227f2:	6d13      	ldr	r3, [r2, #80]	@ 0x50
200227f4:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
200227f8:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
200227fc:	6511      	str	r1, [r2, #80]	@ 0x50
200227fe:	4770      	bx	lr

20022800 <HAL_FLASH_SET_WDT>:
20022800:	b148      	cbz	r0, 20022816 <HAL_FLASH_SET_WDT+0x16>
20022802:	6803      	ldr	r3, [r0, #0]
20022804:	f8d3 2090 	ldr.w	r2, [r3, #144]	@ 0x90
20022808:	b109      	cbz	r1, 2002280e <HAL_FLASH_SET_WDT+0xe>
2002280a:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
2002280e:	2000      	movs	r0, #0
20022810:	f8c3 1090 	str.w	r1, [r3, #144]	@ 0x90
20022814:	4770      	bx	lr
20022816:	2001      	movs	r0, #1
20022818:	4770      	bx	lr

2002281a <HAL_FLASH_CONFIG_AHB_READ>:
2002281a:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
2002281c:	4605      	mov	r5, r0
2002281e:	2800      	cmp	r0, #0
20022820:	d03d      	beq.n	2002289e <HAL_FLASH_CONFIG_AHB_READ+0x84>
20022822:	68c4      	ldr	r4, [r0, #12]
20022824:	b301      	cbz	r1, 20022868 <HAL_FLASH_CONFIG_AHB_READ+0x4e>
20022826:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
2002282a:	2b00      	cmp	r3, #0
2002282c:	d037      	beq.n	2002289e <HAL_FLASH_CONFIG_AHB_READ+0x84>
2002282e:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
20022832:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
20022836:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
2002283a:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
2002283e:	9603      	str	r6, [sp, #12]
20022840:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
20022844:	9602      	str	r6, [sp, #8]
20022846:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
2002284a:	9601      	str	r6, [sp, #4]
2002284c:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
20022850:	9400      	str	r4, [sp, #0]
20022852:	f7ff fdf8 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
20022856:	68eb      	ldr	r3, [r5, #12]
20022858:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
2002285c:	4628      	mov	r0, r5
2002285e:	f7ff fde7 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
20022862:	2000      	movs	r0, #0
20022864:	b004      	add	sp, #16
20022866:	bd70      	pop	{r4, r5, r6, pc}
20022868:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
2002286c:	b1bb      	cbz	r3, 2002289e <HAL_FLASH_CONFIG_AHB_READ+0x84>
2002286e:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
20022872:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
20022876:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
2002287a:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
2002287e:	9603      	str	r6, [sp, #12]
20022880:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
20022884:	9602      	str	r6, [sp, #8]
20022886:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
2002288a:	9601      	str	r6, [sp, #4]
2002288c:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
20022890:	9400      	str	r4, [sp, #0]
20022892:	f7ff fdd8 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
20022896:	68eb      	ldr	r3, [r5, #12]
20022898:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
2002289c:	e7de      	b.n	2002285c <HAL_FLASH_CONFIG_AHB_READ+0x42>
2002289e:	2001      	movs	r0, #1
200228a0:	e7e0      	b.n	20022864 <HAL_FLASH_CONFIG_AHB_READ+0x4a>

200228a2 <HAL_FLASH_CONFIG_FULL_AHB_READ>:
200228a2:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200228a4:	4605      	mov	r5, r0
200228a6:	2800      	cmp	r0, #0
200228a8:	d036      	beq.n	20022918 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
200228aa:	68c4      	ldr	r4, [r0, #12]
200228ac:	b1e1      	cbz	r1, 200228e8 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
200228ae:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
200228b2:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
200228b6:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
200228ba:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
200228be:	9603      	str	r6, [sp, #12]
200228c0:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
200228c4:	9602      	str	r6, [sp, #8]
200228c6:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
200228ca:	9601      	str	r6, [sp, #4]
200228cc:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
200228d0:	9400      	str	r4, [sp, #0]
200228d2:	f7ff fdb8 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
200228d6:	68eb      	ldr	r3, [r5, #12]
200228d8:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
200228dc:	4628      	mov	r0, r5
200228de:	f7ff fda7 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
200228e2:	2000      	movs	r0, #0
200228e4:	b004      	add	sp, #16
200228e6:	bd70      	pop	{r4, r5, r6, pc}
200228e8:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
200228ec:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
200228f0:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
200228f4:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
200228f8:	9603      	str	r6, [sp, #12]
200228fa:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
200228fe:	9602      	str	r6, [sp, #8]
20022900:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
20022904:	9601      	str	r6, [sp, #4]
20022906:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
2002290a:	9400      	str	r4, [sp, #0]
2002290c:	f7ff fd9b 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
20022910:	68eb      	ldr	r3, [r5, #12]
20022912:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
20022916:	e7e1      	b.n	200228dc <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
20022918:	2001      	movs	r0, #1
2002291a:	e7e3      	b.n	200228e4 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

2002291c <HAL_FLASH_PRE_CMD>:
2002291c:	b530      	push	{r4, r5, lr}
2002291e:	68c4      	ldr	r4, [r0, #12]
20022920:	b087      	sub	sp, #28
20022922:	b304      	cbz	r4, 20022966 <HAL_FLASH_PRE_CMD+0x4a>
20022924:	2938      	cmp	r1, #56	@ 0x38
20022926:	d81e      	bhi.n	20022966 <HAL_FLASH_PRE_CMD+0x4a>
20022928:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
2002292c:	440c      	add	r4, r1
2002292e:	7c23      	ldrb	r3, [r4, #16]
20022930:	b1cb      	cbz	r3, 20022966 <HAL_FLASH_PRE_CMD+0x4a>
20022932:	f994 5018 	ldrsb.w	r5, [r4, #24]
20022936:	f994 3013 	ldrsb.w	r3, [r4, #19]
2002293a:	f994 2012 	ldrsb.w	r2, [r4, #18]
2002293e:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022942:	9504      	str	r5, [sp, #16]
20022944:	f994 5017 	ldrsb.w	r5, [r4, #23]
20022948:	9503      	str	r5, [sp, #12]
2002294a:	f994 5016 	ldrsb.w	r5, [r4, #22]
2002294e:	9502      	str	r5, [sp, #8]
20022950:	f994 5015 	ldrsb.w	r5, [r4, #21]
20022954:	9501      	str	r5, [sp, #4]
20022956:	f994 4014 	ldrsb.w	r4, [r4, #20]
2002295a:	9400      	str	r4, [sp, #0]
2002295c:	f7ff fe2a 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20022960:	2000      	movs	r0, #0
20022962:	b007      	add	sp, #28
20022964:	bd30      	pop	{r4, r5, pc}
20022966:	2001      	movs	r0, #1
20022968:	e7fb      	b.n	20022962 <HAL_FLASH_PRE_CMD+0x46>

2002296a <HAL_FLASH_ISSUE_CMD>:
2002296a:	b5f0      	push	{r4, r5, r6, r7, lr}
2002296c:	68c4      	ldr	r4, [r0, #12]
2002296e:	4606      	mov	r6, r0
20022970:	4617      	mov	r7, r2
20022972:	b087      	sub	sp, #28
20022974:	b354      	cbz	r4, 200229cc <HAL_FLASH_ISSUE_CMD+0x62>
20022976:	2938      	cmp	r1, #56	@ 0x38
20022978:	d828      	bhi.n	200229cc <HAL_FLASH_ISSUE_CMD+0x62>
2002297a:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
2002297e:	442c      	add	r4, r5
20022980:	7c23      	ldrb	r3, [r4, #16]
20022982:	b31b      	cbz	r3, 200229cc <HAL_FLASH_ISSUE_CMD+0x62>
20022984:	f994 c018 	ldrsb.w	ip, [r4, #24]
20022988:	f994 3013 	ldrsb.w	r3, [r4, #19]
2002298c:	f994 2012 	ldrsb.w	r2, [r4, #18]
20022990:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022994:	f8cd c010 	str.w	ip, [sp, #16]
20022998:	f994 c017 	ldrsb.w	ip, [r4, #23]
2002299c:	f8cd c00c 	str.w	ip, [sp, #12]
200229a0:	f994 c016 	ldrsb.w	ip, [r4, #22]
200229a4:	f8cd c008 	str.w	ip, [sp, #8]
200229a8:	f994 c015 	ldrsb.w	ip, [r4, #21]
200229ac:	f8cd c004 	str.w	ip, [sp, #4]
200229b0:	f994 4014 	ldrsb.w	r4, [r4, #20]
200229b4:	9400      	str	r4, [sp, #0]
200229b6:	f7ff fdfd 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
200229ba:	68f3      	ldr	r3, [r6, #12]
200229bc:	463a      	mov	r2, r7
200229be:	442b      	add	r3, r5
200229c0:	4630      	mov	r0, r6
200229c2:	7c19      	ldrb	r1, [r3, #16]
200229c4:	f7ff fdb1 	bl	2002252a <HAL_FLASH_SET_CMD>
200229c8:	b007      	add	sp, #28
200229ca:	bdf0      	pop	{r4, r5, r6, r7, pc}
200229cc:	2001      	movs	r0, #1
200229ce:	e7fb      	b.n	200229c8 <HAL_FLASH_ISSUE_CMD+0x5e>

200229d0 <HAL_FLASH_ISSUE_CMD_SEQ>:
200229d0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200229d4:	4690      	mov	r8, r2
200229d6:	68c2      	ldr	r2, [r0, #12]
200229d8:	4604      	mov	r4, r0
200229da:	b086      	sub	sp, #24
200229dc:	2a00      	cmp	r2, #0
200229de:	d073      	beq.n	20022ac8 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229e0:	2938      	cmp	r1, #56	@ 0x38
200229e2:	d871      	bhi.n	20022ac8 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229e4:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
200229e8:	19d6      	adds	r6, r2, r7
200229ea:	7c31      	ldrb	r1, [r6, #16]
200229ec:	2900      	cmp	r1, #0
200229ee:	d06b      	beq.n	20022ac8 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229f0:	2b38      	cmp	r3, #56	@ 0x38
200229f2:	d869      	bhi.n	20022ac8 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200229f4:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
200229f8:	442a      	add	r2, r5
200229fa:	7c13      	ldrb	r3, [r2, #16]
200229fc:	2b00      	cmp	r3, #0
200229fe:	d063      	beq.n	20022ac8 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a00:	f996 c018 	ldrsb.w	ip, [r6, #24]
20022a04:	f996 3013 	ldrsb.w	r3, [r6, #19]
20022a08:	f996 2012 	ldrsb.w	r2, [r6, #18]
20022a0c:	f996 1011 	ldrsb.w	r1, [r6, #17]
20022a10:	f8cd c010 	str.w	ip, [sp, #16]
20022a14:	f996 c017 	ldrsb.w	ip, [r6, #23]
20022a18:	f8cd c00c 	str.w	ip, [sp, #12]
20022a1c:	f996 c016 	ldrsb.w	ip, [r6, #22]
20022a20:	f8cd c008 	str.w	ip, [sp, #8]
20022a24:	f996 c015 	ldrsb.w	ip, [r6, #21]
20022a28:	f8cd c004 	str.w	ip, [sp, #4]
20022a2c:	f996 6014 	ldrsb.w	r6, [r6, #20]
20022a30:	9600      	str	r6, [sp, #0]
20022a32:	f7ff fdbf 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20022a36:	68e0      	ldr	r0, [r4, #12]
20022a38:	4428      	add	r0, r5
20022a3a:	f990 6018 	ldrsb.w	r6, [r0, #24]
20022a3e:	f990 3013 	ldrsb.w	r3, [r0, #19]
20022a42:	f990 2012 	ldrsb.w	r2, [r0, #18]
20022a46:	f990 1011 	ldrsb.w	r1, [r0, #17]
20022a4a:	9604      	str	r6, [sp, #16]
20022a4c:	f990 6017 	ldrsb.w	r6, [r0, #23]
20022a50:	9603      	str	r6, [sp, #12]
20022a52:	f990 6016 	ldrsb.w	r6, [r0, #22]
20022a56:	9602      	str	r6, [sp, #8]
20022a58:	f990 6015 	ldrsb.w	r6, [r0, #21]
20022a5c:	9601      	str	r6, [sp, #4]
20022a5e:	f990 0014 	ldrsb.w	r0, [r0, #20]
20022a62:	9000      	str	r0, [sp, #0]
20022a64:	4620      	mov	r0, r4
20022a66:	f7ff fdc6 	bl	200225f6 <HAL_FLASH_MANUAL_CMD2>
20022a6a:	2200      	movs	r2, #0
20022a6c:	6823      	ldr	r3, [r4, #0]
20022a6e:	2101      	movs	r1, #1
20022a70:	f8c3 2084 	str.w	r2, [r3, #132]	@ 0x84
20022a74:	68e3      	ldr	r3, [r4, #12]
20022a76:	6822      	ldr	r2, [r4, #0]
20022a78:	442b      	add	r3, r5
20022a7a:	7c1b      	ldrb	r3, [r3, #16]
20022a7c:	4620      	mov	r0, r4
20022a7e:	62d3      	str	r3, [r2, #44]	@ 0x2c
20022a80:	6823      	ldr	r3, [r4, #0]
20022a82:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
20022a84:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20022a88:	f7ff fe1a 	bl	200226c0 <HAL_FLASH_ENABLE_CMD2>
20022a8c:	4620      	mov	r0, r4
20022a8e:	f7ff fe25 	bl	200226dc <HAL_FLASH_STAUS_MATCH_CMD2>
20022a92:	6823      	ldr	r3, [r4, #0]
20022a94:	f8c3 801c 	str.w	r8, [r3, #28]
20022a98:	68e3      	ldr	r3, [r4, #12]
20022a9a:	6822      	ldr	r2, [r4, #0]
20022a9c:	443b      	add	r3, r7
20022a9e:	7c1b      	ldrb	r3, [r3, #16]
20022aa0:	6193      	str	r3, [r2, #24]
20022aa2:	4620      	mov	r0, r4
20022aa4:	f7ff fd63 	bl	2002256e <HAL_FLASH_STATUS_MATCH>
20022aa8:	2800      	cmp	r0, #0
20022aaa:	d0fa      	beq.n	20022aa2 <HAL_FLASH_ISSUE_CMD_SEQ+0xd2>
20022aac:	2109      	movs	r1, #9
20022aae:	4620      	mov	r0, r4
20022ab0:	f7ff fd57 	bl	20022562 <HAL_FLASH_CLR_STATUS>
20022ab4:	2100      	movs	r1, #0
20022ab6:	f7ff fe03 	bl	200226c0 <HAL_FLASH_ENABLE_CMD2>
20022aba:	4620      	mov	r0, r4
20022abc:	f7ff fe0e 	bl	200226dc <HAL_FLASH_STAUS_MATCH_CMD2>
20022ac0:	4608      	mov	r0, r1
20022ac2:	b006      	add	sp, #24
20022ac4:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022ac8:	2001      	movs	r0, #1
20022aca:	e7fa      	b.n	20022ac2 <HAL_FLASH_ISSUE_CMD_SEQ+0xf2>

20022acc <nor_qspi_switch>:
20022acc:	b570      	push	{r4, r5, r6, lr}
20022ace:	4604      	mov	r4, r0
20022ad0:	b3e0      	cbz	r0, 20022b4c <nor_qspi_switch+0x80>
20022ad2:	68c3      	ldr	r3, [r0, #12]
20022ad4:	b3d3      	cbz	r3, 20022b4c <nor_qspi_switch+0x80>
20022ad6:	b3c9      	cbz	r1, 20022b4c <nor_qspi_switch+0x80>
20022ad8:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022adc:	2101      	movs	r1, #1
20022ade:	b3b5      	cbz	r5, 20022b4e <nor_qspi_switch+0x82>
20022ae0:	f7ff fcfe 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022ae4:	2200      	movs	r2, #0
20022ae6:	2114      	movs	r1, #20
20022ae8:	4620      	mov	r0, r4
20022aea:	f7ff ff3e 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022aee:	4620      	mov	r0, r4
20022af0:	f7ff fd4c 	bl	2002258c <HAL_FLASH_READ32>
20022af4:	f010 0501 	ands.w	r5, r0, #1
20022af8:	d000      	beq.n	20022afc <nor_qspi_switch+0x30>
20022afa:	e7fe      	b.n	20022afa <nor_qspi_switch+0x2e>
20022afc:	462a      	mov	r2, r5
20022afe:	2115      	movs	r1, #21
20022b00:	4620      	mov	r0, r4
20022b02:	f7ff ff32 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b06:	4606      	mov	r6, r0
20022b08:	b120      	cbz	r0, 20022b14 <nor_qspi_switch+0x48>
20022b0a:	462a      	mov	r2, r5
20022b0c:	4629      	mov	r1, r5
20022b0e:	4620      	mov	r0, r4
20022b10:	f7ff ff2b 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b14:	2102      	movs	r1, #2
20022b16:	4620      	mov	r0, r4
20022b18:	f7ff fcdb 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20022b1c:	2101      	movs	r1, #1
20022b1e:	4620      	mov	r0, r4
20022b20:	f7ff fcde 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022b24:	2200      	movs	r2, #0
20022b26:	212b      	movs	r1, #43	@ 0x2b
20022b28:	4620      	mov	r0, r4
20022b2a:	f7ff ff1e 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b2e:	b16e      	cbz	r6, 20022b4c <nor_qspi_switch+0x80>
20022b30:	2101      	movs	r1, #1
20022b32:	4620      	mov	r0, r4
20022b34:	f7ff fcd4 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022b38:	2200      	movs	r2, #0
20022b3a:	2102      	movs	r1, #2
20022b3c:	4620      	mov	r0, r4
20022b3e:	f7ff ff14 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b42:	4620      	mov	r0, r4
20022b44:	f7ff fd19 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
20022b48:	2800      	cmp	r0, #0
20022b4a:	d0f5      	beq.n	20022b38 <nor_qspi_switch+0x6c>
20022b4c:	bd70      	pop	{r4, r5, r6, pc}
20022b4e:	f7ff fcc7 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022b52:	462a      	mov	r2, r5
20022b54:	2102      	movs	r1, #2
20022b56:	4620      	mov	r0, r4
20022b58:	f7ff ff07 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b5c:	4620      	mov	r0, r4
20022b5e:	f7ff fd15 	bl	2002258c <HAL_FLASH_READ32>
20022b62:	462a      	mov	r2, r5
20022b64:	2114      	movs	r1, #20
20022b66:	4620      	mov	r0, r4
20022b68:	f7ff feff 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b6c:	b910      	cbnz	r0, 20022b74 <nor_qspi_switch+0xa8>
20022b6e:	4620      	mov	r0, r4
20022b70:	f7ff fd0c 	bl	2002258c <HAL_FLASH_READ32>
20022b74:	68e3      	ldr	r3, [r4, #12]
20022b76:	7a1b      	ldrb	r3, [r3, #8]
20022b78:	b3ab      	cbz	r3, 20022be6 <nor_qspi_switch+0x11a>
20022b7a:	2101      	movs	r1, #1
20022b7c:	f003 050f 	and.w	r5, r3, #15
20022b80:	091b      	lsrs	r3, r3, #4
20022b82:	fa01 f303 	lsl.w	r3, r1, r3
20022b86:	b2db      	uxtb	r3, r3
20022b88:	b10d      	cbz	r5, 20022b8e <nor_qspi_switch+0xc2>
20022b8a:	461d      	mov	r5, r3
20022b8c:	2300      	movs	r3, #0
20022b8e:	2200      	movs	r2, #0
20022b90:	2115      	movs	r1, #21
20022b92:	4620      	mov	r0, r4
20022b94:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
20022b98:	f7ff fee7 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022b9c:	4606      	mov	r6, r0
20022b9e:	b120      	cbz	r0, 20022baa <nor_qspi_switch+0xde>
20022ba0:	2200      	movs	r2, #0
20022ba2:	4620      	mov	r0, r4
20022ba4:	4611      	mov	r1, r2
20022ba6:	f7ff fee0 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022baa:	4629      	mov	r1, r5
20022bac:	4620      	mov	r0, r4
20022bae:	f7ff fc90 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20022bb2:	2102      	movs	r1, #2
20022bb4:	4620      	mov	r0, r4
20022bb6:	f7ff fc93 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022bba:	2200      	movs	r2, #0
20022bbc:	2103      	movs	r1, #3
20022bbe:	4620      	mov	r0, r4
20022bc0:	f7ff fed3 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022bc4:	2e00      	cmp	r6, #0
20022bc6:	d0c1      	beq.n	20022b4c <nor_qspi_switch+0x80>
20022bc8:	2101      	movs	r1, #1
20022bca:	4620      	mov	r0, r4
20022bcc:	f7ff fc88 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022bd0:	2200      	movs	r2, #0
20022bd2:	2102      	movs	r1, #2
20022bd4:	4620      	mov	r0, r4
20022bd6:	f7ff fec8 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022bda:	4620      	mov	r0, r4
20022bdc:	f7ff fccd 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
20022be0:	2800      	cmp	r0, #0
20022be2:	d0f5      	beq.n	20022bd0 <nor_qspi_switch+0x104>
20022be4:	e7b2      	b.n	20022b4c <nor_qspi_switch+0x80>
20022be6:	2502      	movs	r5, #2
20022be8:	e7d1      	b.n	20022b8e <nor_qspi_switch+0xc2>

20022bea <HAL_FLASH_SET_QUAL_SPI>:
20022bea:	b538      	push	{r3, r4, r5, lr}
20022bec:	4604      	mov	r4, r0
20022bee:	460d      	mov	r5, r1
20022bf0:	f7ff ff6c 	bl	20022acc <nor_qspi_switch>
20022bf4:	4629      	mov	r1, r5
20022bf6:	4620      	mov	r0, r4
20022bf8:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022bfc:	f7ff be0d 	b.w	2002281a <HAL_FLASH_CONFIG_AHB_READ>

20022c00 <HAL_FLASH_FADDR_SET_QSPI>:
20022c00:	b538      	push	{r3, r4, r5, lr}
20022c02:	4604      	mov	r4, r0
20022c04:	460d      	mov	r5, r1
20022c06:	f7ff ff61 	bl	20022acc <nor_qspi_switch>
20022c0a:	4629      	mov	r1, r5
20022c0c:	4620      	mov	r0, r4
20022c0e:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022c12:	f7ff be46 	b.w	200228a2 <HAL_FLASH_CONFIG_FULL_AHB_READ>

20022c16 <HAL_FLASH_GET_NOR_ID>:
20022c16:	b510      	push	{r4, lr}
20022c18:	4604      	mov	r4, r0
20022c1a:	b140      	cbz	r0, 20022c2e <HAL_FLASH_GET_NOR_ID+0x18>
20022c1c:	6802      	ldr	r2, [r0, #0]
20022c1e:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022c20:	f36f 0315 	bfc	r3, #0, #22
20022c24:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
20022c28:	f043 0301 	orr.w	r3, r3, #1
20022c2c:	6293      	str	r3, [r2, #40]	@ 0x28
20022c2e:	2103      	movs	r1, #3
20022c30:	4620      	mov	r0, r4
20022c32:	f7ff fc55 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022c36:	2200      	movs	r2, #0
20022c38:	219f      	movs	r1, #159	@ 0x9f
20022c3a:	4620      	mov	r0, r4
20022c3c:	f7ff fc75 	bl	2002252a <HAL_FLASH_SET_CMD>
20022c40:	4620      	mov	r0, r4
20022c42:	f7ff fca3 	bl	2002258c <HAL_FLASH_READ32>
20022c46:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022c4a:	bd10      	pop	{r4, pc}

20022c4c <HAL_FLASH_CLR_PROTECT>:
20022c4c:	b570      	push	{r4, r5, r6, lr}
20022c4e:	4604      	mov	r4, r0
20022c50:	2800      	cmp	r0, #0
20022c52:	d03e      	beq.n	20022cd2 <HAL_FLASH_CLR_PROTECT+0x86>
20022c54:	68c3      	ldr	r3, [r0, #12]
20022c56:	2101      	movs	r1, #1
20022c58:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022c5c:	2d00      	cmp	r5, #0
20022c5e:	d03b      	beq.n	20022cd8 <HAL_FLASH_CLR_PROTECT+0x8c>
20022c60:	f7ff fc3e 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022c64:	2200      	movs	r2, #0
20022c66:	2102      	movs	r1, #2
20022c68:	4620      	mov	r0, r4
20022c6a:	f7ff fe7e 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022c6e:	bb88      	cbnz	r0, 20022cd4 <HAL_FLASH_CLR_PROTECT+0x88>
20022c70:	4620      	mov	r0, r4
20022c72:	f7ff fc8b 	bl	2002258c <HAL_FLASH_READ32>
20022c76:	b2c0      	uxtb	r0, r0
20022c78:	68e3      	ldr	r3, [r4, #12]
20022c7a:	79dd      	ldrb	r5, [r3, #7]
20022c7c:	b10d      	cbz	r5, 20022c82 <HAL_FLASH_CLR_PROTECT+0x36>
20022c7e:	ea20 0505 	bic.w	r5, r0, r5
20022c82:	2200      	movs	r2, #0
20022c84:	2115      	movs	r1, #21
20022c86:	4620      	mov	r0, r4
20022c88:	f7ff fe6f 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022c8c:	4606      	mov	r6, r0
20022c8e:	b120      	cbz	r0, 20022c9a <HAL_FLASH_CLR_PROTECT+0x4e>
20022c90:	2200      	movs	r2, #0
20022c92:	4620      	mov	r0, r4
20022c94:	4611      	mov	r1, r2
20022c96:	f7ff fe68 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022c9a:	4629      	mov	r1, r5
20022c9c:	4620      	mov	r0, r4
20022c9e:	f7ff fc18 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20022ca2:	2101      	movs	r1, #1
20022ca4:	4620      	mov	r0, r4
20022ca6:	f7ff fc1b 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022caa:	2200      	movs	r2, #0
20022cac:	2103      	movs	r1, #3
20022cae:	4620      	mov	r0, r4
20022cb0:	f7ff fe5b 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022cb4:	b16e      	cbz	r6, 20022cd2 <HAL_FLASH_CLR_PROTECT+0x86>
20022cb6:	2101      	movs	r1, #1
20022cb8:	4620      	mov	r0, r4
20022cba:	f7ff fc11 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022cbe:	2200      	movs	r2, #0
20022cc0:	2102      	movs	r1, #2
20022cc2:	4620      	mov	r0, r4
20022cc4:	f7ff fe51 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022cc8:	4620      	mov	r0, r4
20022cca:	f7ff fc56 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
20022cce:	2800      	cmp	r0, #0
20022cd0:	d0f5      	beq.n	20022cbe <HAL_FLASH_CLR_PROTECT+0x72>
20022cd2:	bd70      	pop	{r4, r5, r6, pc}
20022cd4:	2000      	movs	r0, #0
20022cd6:	e7cf      	b.n	20022c78 <HAL_FLASH_CLR_PROTECT+0x2c>
20022cd8:	f7ff fc02 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022cdc:	462a      	mov	r2, r5
20022cde:	2102      	movs	r1, #2
20022ce0:	4620      	mov	r0, r4
20022ce2:	f7ff fe42 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022ce6:	2800      	cmp	r0, #0
20022ce8:	d13e      	bne.n	20022d68 <HAL_FLASH_CLR_PROTECT+0x11c>
20022cea:	4620      	mov	r0, r4
20022cec:	f7ff fc4e 	bl	2002258c <HAL_FLASH_READ32>
20022cf0:	b2c6      	uxtb	r6, r0
20022cf2:	2200      	movs	r2, #0
20022cf4:	2114      	movs	r1, #20
20022cf6:	4620      	mov	r0, r4
20022cf8:	f7ff fe37 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022cfc:	b918      	cbnz	r0, 20022d06 <HAL_FLASH_CLR_PROTECT+0xba>
20022cfe:	4620      	mov	r0, r4
20022d00:	f7ff fc44 	bl	2002258c <HAL_FLASH_READ32>
20022d04:	b2c5      	uxtb	r5, r0
20022d06:	68e3      	ldr	r3, [r4, #12]
20022d08:	79d9      	ldrb	r1, [r3, #7]
20022d0a:	b109      	cbz	r1, 20022d10 <HAL_FLASH_CLR_PROTECT+0xc4>
20022d0c:	ea26 0101 	bic.w	r1, r6, r1
20022d10:	2200      	movs	r2, #0
20022d12:	4620      	mov	r0, r4
20022d14:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20022d18:	2115      	movs	r1, #21
20022d1a:	f7ff fe26 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022d1e:	4606      	mov	r6, r0
20022d20:	b120      	cbz	r0, 20022d2c <HAL_FLASH_CLR_PROTECT+0xe0>
20022d22:	2200      	movs	r2, #0
20022d24:	4620      	mov	r0, r4
20022d26:	4611      	mov	r1, r2
20022d28:	f7ff fe1f 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022d2c:	4629      	mov	r1, r5
20022d2e:	4620      	mov	r0, r4
20022d30:	f7ff fbcf 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20022d34:	2102      	movs	r1, #2
20022d36:	4620      	mov	r0, r4
20022d38:	f7ff fbd2 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022d3c:	2200      	movs	r2, #0
20022d3e:	2103      	movs	r1, #3
20022d40:	4620      	mov	r0, r4
20022d42:	f7ff fe12 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022d46:	2e00      	cmp	r6, #0
20022d48:	d0c3      	beq.n	20022cd2 <HAL_FLASH_CLR_PROTECT+0x86>
20022d4a:	2101      	movs	r1, #1
20022d4c:	4620      	mov	r0, r4
20022d4e:	f7ff fbc7 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022d52:	2200      	movs	r2, #0
20022d54:	2102      	movs	r1, #2
20022d56:	4620      	mov	r0, r4
20022d58:	f7ff fe07 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022d5c:	4620      	mov	r0, r4
20022d5e:	f7ff fc0c 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
20022d62:	2800      	cmp	r0, #0
20022d64:	d0f5      	beq.n	20022d52 <HAL_FLASH_CLR_PROTECT+0x106>
20022d66:	e7b4      	b.n	20022cd2 <HAL_FLASH_CLR_PROTECT+0x86>
20022d68:	462e      	mov	r6, r5
20022d6a:	e7c2      	b.n	20022cf2 <HAL_FLASH_CLR_PROTECT+0xa6>

20022d6c <HAL_QSPI_SET_CLK_INV>:
20022d6c:	b120      	cbz	r0, 20022d78 <HAL_QSPI_SET_CLK_INV+0xc>
20022d6e:	6802      	ldr	r2, [r0, #0]
20022d70:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022d72:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20022d76:	6593      	str	r3, [r2, #88]	@ 0x58
20022d78:	4770      	bx	lr

20022d7a <HAL_FLASH_RELEASE_DPD>:
20022d7a:	b538      	push	{r3, r4, r5, lr}
20022d7c:	4604      	mov	r4, r0
20022d7e:	b1d0      	cbz	r0, 20022db6 <HAL_FLASH_RELEASE_DPD+0x3c>
20022d80:	6803      	ldr	r3, [r0, #0]
20022d82:	21ab      	movs	r1, #171	@ 0xab
20022d84:	681d      	ldr	r5, [r3, #0]
20022d86:	f015 0501 	ands.w	r5, r5, #1
20022d8a:	bf02      	ittt	eq
20022d8c:	681a      	ldreq	r2, [r3, #0]
20022d8e:	f042 0201 	orreq.w	r2, r2, #1
20022d92:	601a      	streq	r2, [r3, #0]
20022d94:	6802      	ldr	r2, [r0, #0]
20022d96:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022d98:	f36f 0315 	bfc	r3, #0, #22
20022d9c:	f043 0301 	orr.w	r3, r3, #1
20022da0:	6293      	str	r3, [r2, #40]	@ 0x28
20022da2:	2200      	movs	r2, #0
20022da4:	f7ff fbc1 	bl	2002252a <HAL_FLASH_SET_CMD>
20022da8:	b925      	cbnz	r5, 20022db4 <HAL_FLASH_RELEASE_DPD+0x3a>
20022daa:	6822      	ldr	r2, [r4, #0]
20022dac:	6813      	ldr	r3, [r2, #0]
20022dae:	f023 0301 	bic.w	r3, r3, #1
20022db2:	6013      	str	r3, [r2, #0]
20022db4:	bd38      	pop	{r3, r4, r5, pc}
20022db6:	2001      	movs	r0, #1
20022db8:	e7fc      	b.n	20022db4 <HAL_FLASH_RELEASE_DPD+0x3a>

20022dba <flash_handle_valid>:
20022dba:	b118      	cbz	r0, 20022dc4 <flash_handle_valid+0xa>
20022dbc:	68c0      	ldr	r0, [r0, #12]
20022dbe:	3800      	subs	r0, #0
20022dc0:	bf18      	it	ne
20022dc2:	2001      	movne	r0, #1
20022dc4:	4770      	bx	lr

20022dc6 <HAL_GET_FLASH_MID>:
20022dc6:	2000      	movs	r0, #0
20022dc8:	4770      	bx	lr

20022dca <HAL_FLASH_DMA_START>:
20022dca:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022dce:	4688      	mov	r8, r1
20022dd0:	4699      	mov	r9, r3
20022dd2:	4604      	mov	r4, r0
20022dd4:	2800      	cmp	r0, #0
20022dd6:	d045      	beq.n	20022e64 <HAL_FLASH_DMA_START+0x9a>
20022dd8:	6883      	ldr	r3, [r0, #8]
20022dda:	2b00      	cmp	r3, #0
20022ddc:	d042      	beq.n	20022e64 <HAL_FLASH_DMA_START+0x9a>
20022dde:	f1b9 0f00 	cmp.w	r9, #0
20022de2:	d03f      	beq.n	20022e64 <HAL_FLASH_DMA_START+0x9a>
20022de4:	6801      	ldr	r1, [r0, #0]
20022de6:	680f      	ldr	r7, [r1, #0]
20022de8:	b332      	cbz	r2, 20022e38 <HAL_FLASH_DMA_START+0x6e>
20022dea:	2210      	movs	r2, #16
20022dec:	609a      	str	r2, [r3, #8]
20022dee:	2300      	movs	r3, #0
20022df0:	6882      	ldr	r2, [r0, #8]
20022df2:	464e      	mov	r6, r9
20022df4:	6153      	str	r3, [r2, #20]
20022df6:	6882      	ldr	r2, [r0, #8]
20022df8:	6193      	str	r3, [r2, #24]
20022dfa:	6882      	ldr	r2, [r0, #8]
20022dfc:	60d3      	str	r3, [r2, #12]
20022dfe:	2280      	movs	r2, #128	@ 0x80
20022e00:	6883      	ldr	r3, [r0, #8]
20022e02:	611a      	str	r2, [r3, #16]
20022e04:	6805      	ldr	r5, [r0, #0]
20022e06:	3504      	adds	r5, #4
20022e08:	68a0      	ldr	r0, [r4, #8]
20022e0a:	f7ff f8c5 	bl	20021f98 <HAL_DMA_DeInit>
20022e0e:	bb50      	cbnz	r0, 20022e66 <HAL_FLASH_DMA_START+0x9c>
20022e10:	68a0      	ldr	r0, [r4, #8]
20022e12:	f7ff f855 	bl	20021ec0 <HAL_DMA_Init>
20022e16:	bb30      	cbnz	r0, 20022e66 <HAL_FLASH_DMA_START+0x9c>
20022e18:	6823      	ldr	r3, [r4, #0]
20022e1a:	f047 0720 	orr.w	r7, r7, #32
20022e1e:	601f      	str	r7, [r3, #0]
20022e20:	6822      	ldr	r2, [r4, #0]
20022e22:	f109 33ff 	add.w	r3, r9, #4294967295
20022e26:	6253      	str	r3, [r2, #36]	@ 0x24
20022e28:	4641      	mov	r1, r8
20022e2a:	4633      	mov	r3, r6
20022e2c:	462a      	mov	r2, r5
20022e2e:	68a0      	ldr	r0, [r4, #8]
20022e30:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022e34:	f7ff ba26 	b.w	20022284 <HAL_DMA_Start>
20022e38:	f44f 7100 	mov.w	r1, #512	@ 0x200
20022e3c:	609a      	str	r2, [r3, #8]
20022e3e:	6883      	ldr	r3, [r0, #8]
20022e40:	f109 0603 	add.w	r6, r9, #3
20022e44:	6159      	str	r1, [r3, #20]
20022e46:	f44f 6100 	mov.w	r1, #2048	@ 0x800
20022e4a:	6883      	ldr	r3, [r0, #8]
20022e4c:	4645      	mov	r5, r8
20022e4e:	6199      	str	r1, [r3, #24]
20022e50:	6883      	ldr	r3, [r0, #8]
20022e52:	08b6      	lsrs	r6, r6, #2
20022e54:	60da      	str	r2, [r3, #12]
20022e56:	2280      	movs	r2, #128	@ 0x80
20022e58:	6883      	ldr	r3, [r0, #8]
20022e5a:	611a      	str	r2, [r3, #16]
20022e5c:	6803      	ldr	r3, [r0, #0]
20022e5e:	f103 0804 	add.w	r8, r3, #4
20022e62:	e7d1      	b.n	20022e08 <HAL_FLASH_DMA_START+0x3e>
20022e64:	2001      	movs	r0, #1
20022e66:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

20022e6a <HAL_FLASH_DMA_WAIT_DONE>:
20022e6a:	b510      	push	{r4, lr}
20022e6c:	460a      	mov	r2, r1
20022e6e:	4604      	mov	r4, r0
20022e70:	b170      	cbz	r0, 20022e90 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022e72:	6880      	ldr	r0, [r0, #8]
20022e74:	b160      	cbz	r0, 20022e90 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022e76:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20022e78:	b111      	cbz	r1, 20022e80 <HAL_FLASH_DMA_WAIT_DONE+0x16>
20022e7a:	f04f 32ff 	mov.w	r2, #4294967295
20022e7e:	2100      	movs	r1, #0
20022e80:	f7ff f8f8 	bl	20022074 <HAL_DMA_PollForTransfer>
20022e84:	6822      	ldr	r2, [r4, #0]
20022e86:	6813      	ldr	r3, [r2, #0]
20022e88:	f023 0320 	bic.w	r3, r3, #32
20022e8c:	6013      	str	r3, [r2, #0]
20022e8e:	bd10      	pop	{r4, pc}
20022e90:	2001      	movs	r0, #1
20022e92:	e7fc      	b.n	20022e8e <HAL_FLASH_DMA_WAIT_DONE+0x24>

20022e94 <HAL_FLASH_ALIAS_CFG>:
20022e94:	b538      	push	{r3, r4, r5, lr}
20022e96:	461d      	mov	r5, r3
20022e98:	4604      	mov	r4, r0
20022e9a:	b158      	cbz	r0, 20022eb4 <HAL_FLASH_ALIAS_CFG+0x20>
20022e9c:	6903      	ldr	r3, [r0, #16]
20022e9e:	428b      	cmp	r3, r1
20022ea0:	bf98      	it	ls
20022ea2:	1ac9      	subls	r1, r1, r3
20022ea4:	f7ff fbc8 	bl	20022638 <HAL_FLASH_SET_ALIAS_RANGE>
20022ea8:	4629      	mov	r1, r5
20022eaa:	4620      	mov	r0, r4
20022eac:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022eb0:	f7ff bbd4 	b.w	2002265c <HAL_FLASH_SET_ALIAS_OFFSET>
20022eb4:	bd38      	pop	{r3, r4, r5, pc}

20022eb6 <nand_read_id>:
20022eb6:	b510      	push	{r4, lr}
20022eb8:	460b      	mov	r3, r1
20022eba:	4604      	mov	r4, r0
20022ebc:	b086      	sub	sp, #24
20022ebe:	b320      	cbz	r0, 20022f0a <nand_read_id+0x54>
20022ec0:	2908      	cmp	r1, #8
20022ec2:	f04f 0100 	mov.w	r1, #0
20022ec6:	f04f 0201 	mov.w	r2, #1
20022eca:	bf83      	ittte	hi
20022ecc:	460b      	movhi	r3, r1
20022ece:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
20022ed2:	e9cd 1100 	strdhi	r1, r1, [sp]
20022ed6:	e9cd 1102 	strdls	r1, r1, [sp, #8]
20022eda:	bf8e      	itee	hi
20022edc:	4619      	movhi	r1, r3
20022ede:	e9cd 1100 	strdls	r1, r1, [sp]
20022ee2:	b25b      	sxtbls	r3, r3
20022ee4:	9204      	str	r2, [sp, #16]
20022ee6:	f7ff fb65 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20022eea:	2103      	movs	r1, #3
20022eec:	4620      	mov	r0, r4
20022eee:	f7ff faf7 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022ef2:	2200      	movs	r2, #0
20022ef4:	219f      	movs	r1, #159	@ 0x9f
20022ef6:	4620      	mov	r0, r4
20022ef8:	f7ff fb17 	bl	2002252a <HAL_FLASH_SET_CMD>
20022efc:	4620      	mov	r0, r4
20022efe:	f7ff fb45 	bl	2002258c <HAL_FLASH_READ32>
20022f02:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022f06:	b006      	add	sp, #24
20022f08:	bd10      	pop	{r4, pc}
20022f0a:	20ff      	movs	r0, #255	@ 0xff
20022f0c:	e7fb      	b.n	20022f06 <nand_read_id+0x50>

20022f0e <HAL_NAND_CONF_ECC>:
20022f0e:	b538      	push	{r3, r4, r5, lr}
20022f10:	460d      	mov	r5, r1
20022f12:	4604      	mov	r4, r0
20022f14:	b398      	cbz	r0, 20022f7e <HAL_NAND_CONF_ECC+0x70>
20022f16:	68c3      	ldr	r3, [r0, #12]
20022f18:	b38b      	cbz	r3, 20022f7e <HAL_NAND_CONF_ECC+0x70>
20022f1a:	799a      	ldrb	r2, [r3, #6]
20022f1c:	b392      	cbz	r2, 20022f84 <HAL_NAND_CONF_ECC+0x76>
20022f1e:	7a9b      	ldrb	r3, [r3, #10]
20022f20:	b383      	cbz	r3, 20022f84 <HAL_NAND_CONF_ECC+0x76>
20022f22:	2101      	movs	r1, #1
20022f24:	f7ff fadc 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022f28:	68e3      	ldr	r3, [r4, #12]
20022f2a:	2102      	movs	r1, #2
20022f2c:	799a      	ldrb	r2, [r3, #6]
20022f2e:	4620      	mov	r0, r4
20022f30:	f7ff fd1b 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022f34:	4620      	mov	r0, r4
20022f36:	f7ff fb29 	bl	2002258c <HAL_FLASH_READ32>
20022f3a:	68e3      	ldr	r3, [r4, #12]
20022f3c:	7a9b      	ldrb	r3, [r3, #10]
20022f3e:	b1dd      	cbz	r5, 20022f78 <HAL_NAND_CONF_ECC+0x6a>
20022f40:	ea43 0100 	orr.w	r1, r3, r0
20022f44:	4620      	mov	r0, r4
20022f46:	f7ff fac4 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20022f4a:	2101      	movs	r1, #1
20022f4c:	4620      	mov	r0, r4
20022f4e:	f7ff fac7 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022f52:	68e3      	ldr	r3, [r4, #12]
20022f54:	2103      	movs	r1, #3
20022f56:	799a      	ldrb	r2, [r3, #6]
20022f58:	4620      	mov	r0, r4
20022f5a:	f7ff fd06 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022f5e:	68e3      	ldr	r3, [r4, #12]
20022f60:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20022f64:	2102      	movs	r1, #2
20022f66:	799a      	ldrb	r2, [r3, #6]
20022f68:	4620      	mov	r0, r4
20022f6a:	f7ff fcfe 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022f6e:	4620      	mov	r0, r4
20022f70:	f7ff fb0c 	bl	2002258c <HAL_FLASH_READ32>
20022f74:	2000      	movs	r0, #0
20022f76:	bd38      	pop	{r3, r4, r5, pc}
20022f78:	ea20 0103 	bic.w	r1, r0, r3
20022f7c:	e7e2      	b.n	20022f44 <HAL_NAND_CONF_ECC+0x36>
20022f7e:	f04f 30ff 	mov.w	r0, #4294967295
20022f82:	e7f8      	b.n	20022f76 <HAL_NAND_CONF_ECC+0x68>
20022f84:	f06f 0001 	mvn.w	r0, #1
20022f88:	e7f5      	b.n	20022f76 <HAL_NAND_CONF_ECC+0x68>

20022f8a <HAL_NAND_GET_ECC_STATUS>:
20022f8a:	b510      	push	{r4, lr}
20022f8c:	4604      	mov	r4, r0
20022f8e:	b320      	cbz	r0, 20022fda <HAL_NAND_GET_ECC_STATUS+0x50>
20022f90:	68c2      	ldr	r2, [r0, #12]
20022f92:	b31a      	cbz	r2, 20022fdc <HAL_NAND_GET_ECC_STATUS+0x52>
20022f94:	7913      	ldrb	r3, [r2, #4]
20022f96:	b31b      	cbz	r3, 20022fe0 <HAL_NAND_GET_ECC_STATUS+0x56>
20022f98:	79d3      	ldrb	r3, [r2, #7]
20022f9a:	b30b      	cbz	r3, 20022fe0 <HAL_NAND_GET_ECC_STATUS+0x56>
20022f9c:	2101      	movs	r1, #1
20022f9e:	f7ff fa9f 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20022fa2:	68e3      	ldr	r3, [r4, #12]
20022fa4:	2102      	movs	r1, #2
20022fa6:	791a      	ldrb	r2, [r3, #4]
20022fa8:	4620      	mov	r0, r4
20022faa:	f7ff fcde 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20022fae:	4620      	mov	r0, r4
20022fb0:	f7ff faec 	bl	2002258c <HAL_FLASH_READ32>
20022fb4:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
20022fb8:	2a3f      	cmp	r2, #63	@ 0x3f
20022fba:	ea4f 1312 	mov.w	r3, r2, lsr #4
20022fbe:	d804      	bhi.n	20022fca <HAL_NAND_GET_ECC_STATUS+0x40>
20022fc0:	2b01      	cmp	r3, #1
20022fc2:	d808      	bhi.n	20022fd6 <HAL_NAND_GET_ECC_STATUS+0x4c>
20022fc4:	f000 0030 	and.w	r0, r0, #48	@ 0x30
20022fc8:	e007      	b.n	20022fda <HAL_NAND_GET_ECC_STATUS+0x50>
20022fca:	3b04      	subs	r3, #4
20022fcc:	2b01      	cmp	r3, #1
20022fce:	d8f9      	bhi.n	20022fc4 <HAL_NAND_GET_ECC_STATUS+0x3a>
20022fd0:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
20022fd4:	e001      	b.n	20022fda <HAL_NAND_GET_ECC_STATUS+0x50>
20022fd6:	f000 0070 	and.w	r0, r0, #112	@ 0x70
20022fda:	bd10      	pop	{r4, pc}
20022fdc:	4610      	mov	r0, r2
20022fde:	e7fc      	b.n	20022fda <HAL_NAND_GET_ECC_STATUS+0x50>
20022fe0:	4618      	mov	r0, r3
20022fe2:	e7fa      	b.n	20022fda <HAL_NAND_GET_ECC_STATUS+0x50>

20022fe4 <HAL_NAND_CHECK_ECC>:
20022fe4:	4603      	mov	r3, r0
20022fe6:	1108      	asrs	r0, r1, #4
20022fe8:	b172      	cbz	r2, 20023008 <HAL_NAND_CHECK_ECC+0x24>
20022fea:	2b07      	cmp	r3, #7
20022fec:	d80c      	bhi.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
20022fee:	e8df f003 	tbb	[pc, r3]
20022ff2:	0d04      	.short	0x0d04
20022ff4:	3f352e18 	.word	0x3f352e18
20022ff8:	4c47      	.short	0x4c47
20022ffa:	b128      	cbz	r0, 20023008 <HAL_NAND_CHECK_ECC+0x24>
20022ffc:	2801      	cmp	r0, #1
20022ffe:	6813      	ldr	r3, [r2, #0]
20023000:	d10a      	bne.n	20023018 <HAL_NAND_CHECK_ECC+0x34>
20023002:	f043 0301 	orr.w	r3, r3, #1
20023006:	6013      	str	r3, [r2, #0]
20023008:	2000      	movs	r0, #0
2002300a:	4770      	bx	lr
2002300c:	f020 0302 	bic.w	r3, r0, #2
20023010:	2b01      	cmp	r3, #1
20023012:	d003      	beq.n	2002301c <HAL_NAND_CHECK_ECC+0x38>
20023014:	b1d0      	cbz	r0, 2002304c <HAL_NAND_CHECK_ECC+0x68>
20023016:	6813      	ldr	r3, [r2, #0]
20023018:	4303      	orrs	r3, r0
2002301a:	e016      	b.n	2002304a <HAL_NAND_CHECK_ECC+0x66>
2002301c:	6813      	ldr	r3, [r2, #0]
2002301e:	4303      	orrs	r3, r0
20023020:	e7f1      	b.n	20023006 <HAL_NAND_CHECK_ECC+0x22>
20023022:	2805      	cmp	r0, #5
20023024:	d8f7      	bhi.n	20023016 <HAL_NAND_CHECK_ECC+0x32>
20023026:	a301      	add	r3, pc, #4	@ (adr r3, 2002302c <HAL_NAND_CHECK_ECC+0x48>)
20023028:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
2002302c:	20023009 	.word	0x20023009
20023030:	2002301d 	.word	0x2002301d
20023034:	20023045 	.word	0x20023045
20023038:	2002301d 	.word	0x2002301d
2002303c:	20023017 	.word	0x20023017
20023040:	2002301d 	.word	0x2002301d
20023044:	6813      	ldr	r3, [r2, #0]
20023046:	f043 0302 	orr.w	r3, r3, #2
2002304a:	6013      	str	r3, [r2, #0]
2002304c:	4770      	bx	lr
2002304e:	2800      	cmp	r0, #0
20023050:	d0da      	beq.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
20023052:	1e43      	subs	r3, r0, #1
20023054:	2b05      	cmp	r3, #5
20023056:	6813      	ldr	r3, [r2, #0]
20023058:	d9e1      	bls.n	2002301e <HAL_NAND_CHECK_ECC+0x3a>
2002305a:	e7dd      	b.n	20023018 <HAL_NAND_CHECK_ECC+0x34>
2002305c:	07c3      	lsls	r3, r0, #31
2002305e:	f000 0103 	and.w	r1, r0, #3
20023062:	d402      	bmi.n	2002306a <HAL_NAND_CHECK_ECC+0x86>
20023064:	2900      	cmp	r1, #0
20023066:	d0cf      	beq.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
20023068:	e7d5      	b.n	20023016 <HAL_NAND_CHECK_ECC+0x32>
2002306a:	6813      	ldr	r3, [r2, #0]
2002306c:	430b      	orrs	r3, r1
2002306e:	e7ca      	b.n	20023006 <HAL_NAND_CHECK_ECC+0x22>
20023070:	2800      	cmp	r0, #0
20023072:	d0c9      	beq.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
20023074:	6813      	ldr	r3, [r2, #0]
20023076:	2808      	cmp	r0, #8
20023078:	ea43 0300 	orr.w	r3, r3, r0
2002307c:	dce5      	bgt.n	2002304a <HAL_NAND_CHECK_ECC+0x66>
2002307e:	e7c2      	b.n	20023006 <HAL_NAND_CHECK_ECC+0x22>
20023080:	2800      	cmp	r0, #0
20023082:	d0c1      	beq.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
20023084:	1e43      	subs	r3, r0, #1
20023086:	2b01      	cmp	r3, #1
20023088:	e7e5      	b.n	20023056 <HAL_NAND_CHECK_ECC+0x72>
2002308a:	2800      	cmp	r0, #0
2002308c:	d0bc      	beq.n	20023008 <HAL_NAND_CHECK_ECC+0x24>
2002308e:	1e43      	subs	r3, r0, #1
20023090:	2b02      	cmp	r3, #2
20023092:	e7e0      	b.n	20023056 <HAL_NAND_CHECK_ECC+0x72>

20023094 <HAL_NAND_GET_ECC_RESULT>:
20023094:	b510      	push	{r4, lr}
20023096:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
2002309a:	4604      	mov	r4, r0
2002309c:	b90b      	cbnz	r3, 200230a2 <HAL_NAND_GET_ECC_RESULT+0xe>
2002309e:	2000      	movs	r0, #0
200230a0:	bd10      	pop	{r4, pc}
200230a2:	f7ff ff72 	bl	20022f8a <HAL_NAND_GET_ECC_STATUS>
200230a6:	4601      	mov	r1, r0
200230a8:	2800      	cmp	r0, #0
200230aa:	d0f8      	beq.n	2002309e <HAL_NAND_GET_ECC_RESULT+0xa>
200230ac:	6862      	ldr	r2, [r4, #4]
200230ae:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
200230b0:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
200230b4:	6062      	str	r2, [r4, #4]
200230b6:	b938      	cbnz	r0, 200230c8 <HAL_NAND_GET_ECC_RESULT+0x34>
200230b8:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
200230bc:	1d22      	adds	r2, r4, #4
200230be:	0900      	lsrs	r0, r0, #4
200230c0:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200230c4:	f7ff bf8e 	b.w	20022fe4 <HAL_NAND_CHECK_ECC>
200230c8:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
200230cc:	ea4f 1321 	mov.w	r3, r1, asr #4
200230d0:	db00      	blt.n	200230d4 <HAL_NAND_GET_ECC_RESULT+0x40>
200230d2:	e7fe      	b.n	200230d2 <HAL_NAND_GET_ECC_RESULT+0x3e>
200230d4:	6801      	ldr	r1, [r0, #0]
200230d6:	40d9      	lsrs	r1, r3
200230d8:	f011 0f01 	tst.w	r1, #1
200230dc:	bf18      	it	ne
200230de:	4618      	movne	r0, r3
200230e0:	ea43 0302 	orr.w	r3, r3, r2
200230e4:	bf08      	it	eq
200230e6:	2000      	moveq	r0, #0
200230e8:	6063      	str	r3, [r4, #4]
200230ea:	e7d9      	b.n	200230a0 <HAL_NAND_GET_ECC_RESULT+0xc>

200230ec <HAL_NAND_EN_QUAL>:
200230ec:	b538      	push	{r3, r4, r5, lr}
200230ee:	460d      	mov	r5, r1
200230f0:	4604      	mov	r4, r0
200230f2:	b348      	cbz	r0, 20023148 <HAL_NAND_EN_QUAL+0x5c>
200230f4:	68c3      	ldr	r3, [r0, #12]
200230f6:	b33b      	cbz	r3, 20023148 <HAL_NAND_EN_QUAL+0x5c>
200230f8:	799a      	ldrb	r2, [r3, #6]
200230fa:	b10a      	cbz	r2, 20023100 <HAL_NAND_EN_QUAL+0x14>
200230fc:	7a1b      	ldrb	r3, [r3, #8]
200230fe:	b90b      	cbnz	r3, 20023104 <HAL_NAND_EN_QUAL+0x18>
20023100:	2000      	movs	r0, #0
20023102:	bd38      	pop	{r3, r4, r5, pc}
20023104:	2101      	movs	r1, #1
20023106:	f7ff f9eb 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
2002310a:	68e3      	ldr	r3, [r4, #12]
2002310c:	2102      	movs	r1, #2
2002310e:	799a      	ldrb	r2, [r3, #6]
20023110:	4620      	mov	r0, r4
20023112:	f7ff fc2a 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023116:	4620      	mov	r0, r4
20023118:	f7ff fa38 	bl	2002258c <HAL_FLASH_READ32>
2002311c:	68e3      	ldr	r3, [r4, #12]
2002311e:	7a1b      	ldrb	r3, [r3, #8]
20023120:	b17d      	cbz	r5, 20023142 <HAL_NAND_EN_QUAL+0x56>
20023122:	ea43 0100 	orr.w	r1, r3, r0
20023126:	4620      	mov	r0, r4
20023128:	f7ff f9d3 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
2002312c:	2101      	movs	r1, #1
2002312e:	4620      	mov	r0, r4
20023130:	f7ff f9d6 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023134:	68e3      	ldr	r3, [r4, #12]
20023136:	2103      	movs	r1, #3
20023138:	4620      	mov	r0, r4
2002313a:	799a      	ldrb	r2, [r3, #6]
2002313c:	f7ff fc15 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023140:	e7de      	b.n	20023100 <HAL_NAND_EN_QUAL+0x14>
20023142:	ea20 0103 	bic.w	r1, r0, r3
20023146:	e7ee      	b.n	20023126 <HAL_NAND_EN_QUAL+0x3a>
20023148:	f04f 30ff 	mov.w	r0, #4294967295
2002314c:	e7d9      	b.n	20023102 <HAL_NAND_EN_QUAL+0x16>

2002314e <nand_clear_status>:
2002314e:	b538      	push	{r3, r4, r5, lr}
20023150:	460d      	mov	r5, r1
20023152:	2101      	movs	r1, #1
20023154:	4604      	mov	r4, r0
20023156:	f7ff f9c3 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
2002315a:	2dc9      	cmp	r5, #201	@ 0xc9
2002315c:	d001      	beq.n	20023162 <nand_clear_status+0x14>
2002315e:	2d01      	cmp	r5, #1
20023160:	d109      	bne.n	20023176 <nand_clear_status+0x28>
20023162:	2102      	movs	r1, #2
20023164:	4620      	mov	r0, r4
20023166:	f7ff f9b4 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
2002316a:	68e3      	ldr	r3, [r4, #12]
2002316c:	2103      	movs	r1, #3
2002316e:	4620      	mov	r0, r4
20023170:	795a      	ldrb	r2, [r3, #5]
20023172:	f7ff fbfa 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023176:	2100      	movs	r1, #0
20023178:	4620      	mov	r0, r4
2002317a:	f7ff f9aa 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
2002317e:	68e3      	ldr	r3, [r4, #12]
20023180:	2103      	movs	r1, #3
20023182:	4620      	mov	r0, r4
20023184:	795a      	ldrb	r2, [r3, #5]
20023186:	f7ff fbf0 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
2002318a:	2000      	movs	r0, #0
2002318c:	bd38      	pop	{r3, r4, r5, pc}

2002318e <HAL_NAND_PAGE_SIZE>:
2002318e:	b140      	cbz	r0, 200231a2 <HAL_NAND_PAGE_SIZE+0x14>
20023190:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
20023194:	f013 0f01 	tst.w	r3, #1
20023198:	bf14      	ite	ne
2002319a:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
2002319e:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
200231a2:	4770      	bx	lr

200231a4 <HAL_NAND_READ_WITHOOB>:
200231a4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200231a8:	b085      	sub	sp, #20
200231aa:	460e      	mov	r6, r1
200231ac:	4691      	mov	r9, r2
200231ae:	461d      	mov	r5, r3
200231b0:	4604      	mov	r4, r0
200231b2:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
200231b4:	b1b0      	cbz	r0, 200231e4 <HAL_NAND_READ_WITHOOB+0x40>
200231b6:	68c3      	ldr	r3, [r0, #12]
200231b8:	b1a3      	cbz	r3, 200231e4 <HAL_NAND_READ_WITHOOB+0x40>
200231ba:	69c3      	ldr	r3, [r0, #28]
200231bc:	b193      	cbz	r3, 200231e4 <HAL_NAND_READ_WITHOOB+0x40>
200231be:	2f80      	cmp	r7, #128	@ 0x80
200231c0:	d810      	bhi.n	200231e4 <HAL_NAND_READ_WITHOOB+0x40>
200231c2:	f7ff ffe4 	bl	2002318e <HAL_NAND_PAGE_SIZE>
200231c6:	f100 3aff 	add.w	sl, r0, #4294967295
200231ca:	ea0a 0a01 	and.w	sl, sl, r1
200231ce:	eb0a 0305 	add.w	r3, sl, r5
200231d2:	4283      	cmp	r3, r0
200231d4:	4680      	mov	r8, r0
200231d6:	d907      	bls.n	200231e8 <HAL_NAND_READ_WITHOOB+0x44>
200231d8:	2002      	movs	r0, #2
200231da:	6060      	str	r0, [r4, #4]
200231dc:	2000      	movs	r0, #0
200231de:	b005      	add	sp, #20
200231e0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200231e4:	2001      	movs	r0, #1
200231e6:	e7f8      	b.n	200231da <HAL_NAND_READ_WITHOOB+0x36>
200231e8:	2300      	movs	r3, #0
200231ea:	6063      	str	r3, [r4, #4]
200231ec:	6923      	ldr	r3, [r4, #16]
200231ee:	f04f 0b00 	mov.w	fp, #0
200231f2:	428b      	cmp	r3, r1
200231f4:	bf98      	it	ls
200231f6:	1ace      	subls	r6, r1, r3
200231f8:	fbb6 f2f0 	udiv	r2, r6, r0
200231fc:	2104      	movs	r1, #4
200231fe:	4620      	mov	r0, r4
20023200:	f7ff fbb3 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023204:	2014      	movs	r0, #20
20023206:	f7fe fb7d 	bl	20021904 <HAL_Delay_us_>
2002320a:	2101      	movs	r1, #1
2002320c:	4620      	mov	r0, r4
2002320e:	f7ff f967 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023212:	2005      	movs	r0, #5
20023214:	f7fe fb76 	bl	20021904 <HAL_Delay_us_>
20023218:	68e2      	ldr	r2, [r4, #12]
2002321a:	2102      	movs	r1, #2
2002321c:	7912      	ldrb	r2, [r2, #4]
2002321e:	4620      	mov	r0, r4
20023220:	f7ff fba3 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023224:	4620      	mov	r0, r4
20023226:	f7ff f9b1 	bl	2002258c <HAL_FLASH_READ32>
2002322a:	07c1      	lsls	r1, r0, #31
2002322c:	d4f1      	bmi.n	20023212 <HAL_NAND_READ_WITHOOB+0x6e>
2002322e:	f1bb 0f00 	cmp.w	fp, #0
20023232:	d102      	bne.n	2002323a <HAL_NAND_READ_WITHOOB+0x96>
20023234:	f04f 0b01 	mov.w	fp, #1
20023238:	e7eb      	b.n	20023212 <HAL_NAND_READ_WITHOOB+0x6e>
2002323a:	4620      	mov	r0, r4
2002323c:	f7ff ff2a 	bl	20023094 <HAL_NAND_GET_ECC_RESULT>
20023240:	b110      	cbz	r0, 20023248 <HAL_NAND_READ_WITHOOB+0xa4>
20023242:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
20023246:	e7c8      	b.n	200231da <HAL_NAND_READ_WITHOOB+0x36>
20023248:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
2002324c:	68e3      	ldr	r3, [r4, #12]
2002324e:	bbb2      	cbnz	r2, 200232be <HAL_NAND_READ_WITHOOB+0x11a>
20023250:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023254:	4620      	mov	r0, r4
20023256:	f7ff f8eb 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
2002325a:	68e0      	ldr	r0, [r4, #12]
2002325c:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
20023260:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023264:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
20023268:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
2002326c:	f8cd c00c 	str.w	ip, [sp, #12]
20023270:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023274:	f8cd c008 	str.w	ip, [sp, #8]
20023278:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
2002327c:	f8cd c004 	str.w	ip, [sp, #4]
20023280:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
20023284:	9000      	str	r0, [sp, #0]
20023286:	4620      	mov	r0, r4
20023288:	f7ff f8dd 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
2002328c:	03b2      	lsls	r2, r6, #14
2002328e:	f8d4 b010 	ldr.w	fp, [r4, #16]
20023292:	d504      	bpl.n	2002329e <HAL_NAND_READ_WITHOOB+0xfa>
20023294:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
20023298:	b10a      	cbz	r2, 2002329e <HAL_NAND_READ_WITHOOB+0xfa>
2002329a:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
2002329e:	ea49 0205 	orr.w	r2, r9, r5
200232a2:	ea42 020a 	orr.w	r2, r2, sl
200232a6:	0793      	lsls	r3, r2, #30
200232a8:	d102      	bne.n	200232b0 <HAL_NAND_READ_WITHOOB+0x10c>
200232aa:	1e6a      	subs	r2, r5, #1
200232ac:	2afe      	cmp	r2, #254	@ 0xfe
200232ae:	d821      	bhi.n	200232f4 <HAL_NAND_READ_WITHOOB+0x150>
200232b0:	462a      	mov	r2, r5
200232b2:	4648      	mov	r0, r9
200232b4:	eb0b 010a 	add.w	r1, fp, sl
200232b8:	f002 fd69 	bl	20025d8e <memcpy>
200232bc:	e01d      	b.n	200232fa <HAL_NAND_READ_WITHOOB+0x156>
200232be:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
200232c2:	4620      	mov	r0, r4
200232c4:	f7ff f8b4 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
200232c8:	68e0      	ldr	r0, [r4, #12]
200232ca:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
200232ce:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
200232d2:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
200232d6:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
200232da:	f8cd c00c 	str.w	ip, [sp, #12]
200232de:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
200232e2:	f8cd c008 	str.w	ip, [sp, #8]
200232e6:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
200232ea:	f8cd c004 	str.w	ip, [sp, #4]
200232ee:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
200232f2:	e7c7      	b.n	20023284 <HAL_NAND_READ_WITHOOB+0xe0>
200232f4:	f1b9 0f00 	cmp.w	r9, #0
200232f8:	d1da      	bne.n	200232b0 <HAL_NAND_READ_WITHOOB+0x10c>
200232fa:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
200232fc:	b12b      	cbz	r3, 2002330a <HAL_NAND_READ_WITHOOB+0x166>
200232fe:	463a      	mov	r2, r7
20023300:	4618      	mov	r0, r3
20023302:	eb0b 0108 	add.w	r1, fp, r8
20023306:	f002 fd42 	bl	20025d8e <memcpy>
2002330a:	1978      	adds	r0, r7, r5
2002330c:	e767      	b.n	200231de <HAL_NAND_READ_WITHOOB+0x3a>

2002330e <HAL_NAND_BLOCK_SIZE>:
2002330e:	b508      	push	{r3, lr}
20023310:	4602      	mov	r2, r0
20023312:	f7ff ff3c 	bl	2002318e <HAL_NAND_PAGE_SIZE>
20023316:	b128      	cbz	r0, 20023324 <HAL_NAND_BLOCK_SIZE+0x16>
20023318:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
2002331c:	079b      	lsls	r3, r3, #30
2002331e:	bf4c      	ite	mi
20023320:	01c0      	lslmi	r0, r0, #7
20023322:	0180      	lslpl	r0, r0, #6
20023324:	bd08      	pop	{r3, pc}

20023326 <HAL_NAND_GET_BADBLK>:
20023326:	b51f      	push	{r0, r1, r2, r3, r4, lr}
20023328:	4604      	mov	r4, r0
2002332a:	b910      	cbnz	r0, 20023332 <HAL_NAND_GET_BADBLK+0xc>
2002332c:	2000      	movs	r0, #0
2002332e:	b004      	add	sp, #16
20023330:	bd10      	pop	{r4, pc}
20023332:	6a03      	ldr	r3, [r0, #32]
20023334:	2b00      	cmp	r3, #0
20023336:	d0f9      	beq.n	2002332c <HAL_NAND_GET_BADBLK+0x6>
20023338:	f7ff ffe9 	bl	2002330e <HAL_NAND_BLOCK_SIZE>
2002333c:	2304      	movs	r3, #4
2002333e:	9301      	str	r3, [sp, #4]
20023340:	ab03      	add	r3, sp, #12
20023342:	9300      	str	r3, [sp, #0]
20023344:	2300      	movs	r3, #0
20023346:	4341      	muls	r1, r0
20023348:	461a      	mov	r2, r3
2002334a:	4620      	mov	r0, r4
2002334c:	f7ff ff2a 	bl	200231a4 <HAL_NAND_READ_WITHOOB>
20023350:	b140      	cbz	r0, 20023364 <HAL_NAND_GET_BADBLK+0x3e>
20023352:	f89d 300c 	ldrb.w	r3, [sp, #12]
20023356:	2bff      	cmp	r3, #255	@ 0xff
20023358:	d0e8      	beq.n	2002332c <HAL_NAND_GET_BADBLK+0x6>
2002335a:	9803      	ldr	r0, [sp, #12]
2002335c:	2800      	cmp	r0, #0
2002335e:	bf08      	it	eq
20023360:	2001      	moveq	r0, #1
20023362:	e7e4      	b.n	2002332e <HAL_NAND_GET_BADBLK+0x8>
20023364:	2001      	movs	r0, #1
20023366:	e7e2      	b.n	2002332e <HAL_NAND_GET_BADBLK+0x8>

20023368 <HAL_QSPIEX_WRITE_PAGE>:
20023368:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002336c:	b099      	sub	sp, #100	@ 0x64
2002336e:	4604      	mov	r4, r0
20023370:	460e      	mov	r6, r1
20023372:	4691      	mov	r9, r2
20023374:	f7ff fd21 	bl	20022dba <flash_handle_valid>
20023378:	b318      	cbz	r0, 200233c2 <HAL_QSPIEX_WRITE_PAGE+0x5a>
2002337a:	2b00      	cmp	r3, #0
2002337c:	f000 80d7 	beq.w	2002352e <HAL_QSPIEX_WRITE_PAGE+0x1c6>
20023380:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20023384:	bf28      	it	cs
20023386:	f44f 7380 	movcs.w	r3, #256	@ 0x100
2002338a:	68a1      	ldr	r1, [r4, #8]
2002338c:	461d      	mov	r5, r3
2002338e:	6962      	ldr	r2, [r4, #20]
20023390:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023394:	2900      	cmp	r1, #0
20023396:	d03b      	beq.n	20023410 <HAL_QSPIEX_WRITE_PAGE+0xa8>
20023398:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
2002339c:	d914      	bls.n	200233c8 <HAL_QSPIEX_WRITE_PAGE+0x60>
2002339e:	2b02      	cmp	r3, #2
200233a0:	bf14      	ite	ne
200233a2:	2727      	movne	r7, #39	@ 0x27
200233a4:	2728      	moveq	r7, #40	@ 0x28
200233a6:	4639      	mov	r1, r7
200233a8:	4620      	mov	r0, r4
200233aa:	f7ff fab7 	bl	2002291c <HAL_FLASH_PRE_CMD>
200233ae:	4649      	mov	r1, r9
200233b0:	462b      	mov	r3, r5
200233b2:	2201      	movs	r2, #1
200233b4:	4620      	mov	r0, r4
200233b6:	f7ff fd08 	bl	20022dca <HAL_FLASH_DMA_START>
200233ba:	4601      	mov	r1, r0
200233bc:	b148      	cbz	r0, 200233d2 <HAL_QSPIEX_WRITE_PAGE+0x6a>
200233be:	2500      	movs	r5, #0
200233c0:	4628      	mov	r0, r5
200233c2:	b019      	add	sp, #100	@ 0x64
200233c4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200233c8:	2b02      	cmp	r3, #2
200233ca:	bf14      	ite	ne
200233cc:	2716      	movne	r7, #22
200233ce:	2717      	moveq	r7, #23
200233d0:	e7e9      	b.n	200233a6 <HAL_QSPIEX_WRITE_PAGE+0x3e>
200233d2:	4632      	mov	r2, r6
200233d4:	4620      	mov	r0, r4
200233d6:	f7ff fac8 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
200233da:	2101      	movs	r1, #1
200233dc:	4620      	mov	r0, r4
200233de:	f7ff f889 	bl	200224f4 <HAL_FLASH_WRITE_DLEN2>
200233e2:	2301      	movs	r3, #1
200233e4:	4632      	mov	r2, r6
200233e6:	9300      	str	r3, [sp, #0]
200233e8:	4639      	mov	r1, r7
200233ea:	2302      	movs	r3, #2
200233ec:	4620      	mov	r0, r4
200233ee:	f7ff faef 	bl	200229d0 <HAL_FLASH_ISSUE_CMD_SEQ>
200233f2:	2800      	cmp	r0, #0
200233f4:	d1e3      	bne.n	200233be <HAL_QSPIEX_WRITE_PAGE+0x56>
200233f6:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
200233fa:	4620      	mov	r0, r4
200233fc:	f7ff fd35 	bl	20022e6a <HAL_FLASH_DMA_WAIT_DONE>
20023400:	2800      	cmp	r0, #0
20023402:	d1dc      	bne.n	200233be <HAL_QSPIEX_WRITE_PAGE+0x56>
20023404:	6822      	ldr	r2, [r4, #0]
20023406:	6813      	ldr	r3, [r2, #0]
20023408:	f023 0320 	bic.w	r3, r3, #32
2002340c:	6013      	str	r3, [r2, #0]
2002340e:	e7d7      	b.n	200233c0 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023410:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023414:	f240 8082 	bls.w	2002351c <HAL_QSPIEX_WRITE_PAGE+0x1b4>
20023418:	2b02      	cmp	r3, #2
2002341a:	bf14      	ite	ne
2002341c:	2327      	movne	r3, #39	@ 0x27
2002341e:	2328      	moveq	r3, #40	@ 0x28
20023420:	462f      	mov	r7, r5
20023422:	f04f 0800 	mov.w	r8, #0
20023426:	9303      	str	r3, [sp, #12]
20023428:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
2002342c:	2f40      	cmp	r7, #64	@ 0x40
2002342e:	bfd4      	ite	le
20023430:	ea0a 0a07 	andle.w	sl, sl, r7
20023434:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
20023438:	f1ba 0f00 	cmp.w	sl, #0
2002343c:	d03f      	beq.n	200234be <HAL_QSPIEX_WRITE_PAGE+0x156>
2002343e:	2200      	movs	r2, #0
20023440:	4620      	mov	r0, r4
20023442:	4611      	mov	r1, r2
20023444:	f7ff fa91 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023448:	eb09 0308 	add.w	r3, r9, r8
2002344c:	f10d 0c20 	add.w	ip, sp, #32
20023450:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023454:	4662      	mov	r2, ip
20023456:	6818      	ldr	r0, [r3, #0]
20023458:	6859      	ldr	r1, [r3, #4]
2002345a:	3308      	adds	r3, #8
2002345c:	c203      	stmia	r2!, {r0, r1}
2002345e:	4573      	cmp	r3, lr
20023460:	4694      	mov	ip, r2
20023462:	d1f7      	bne.n	20023454 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023464:	f04f 0b00 	mov.w	fp, #0
20023468:	ea4f 02aa 	mov.w	r2, sl, asr #2
2002346c:	ab08      	add	r3, sp, #32
2002346e:	f853 1b04 	ldr.w	r1, [r3], #4
20023472:	4620      	mov	r0, r4
20023474:	9205      	str	r2, [sp, #20]
20023476:	9304      	str	r3, [sp, #16]
20023478:	f7ff f82b 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
2002347c:	9a05      	ldr	r2, [sp, #20]
2002347e:	f10b 0b01 	add.w	fp, fp, #1
20023482:	4593      	cmp	fp, r2
20023484:	9b04      	ldr	r3, [sp, #16]
20023486:	d1f2      	bne.n	2002346e <HAL_QSPIEX_WRITE_PAGE+0x106>
20023488:	4651      	mov	r1, sl
2002348a:	4620      	mov	r0, r4
2002348c:	f7ff f828 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023490:	4620      	mov	r0, r4
20023492:	9903      	ldr	r1, [sp, #12]
20023494:	eb06 0208 	add.w	r2, r6, r8
20023498:	f7ff fa67 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
2002349c:	2101      	movs	r1, #1
2002349e:	4620      	mov	r0, r4
200234a0:	f7ff f81e 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
200234a4:	2200      	movs	r2, #0
200234a6:	2102      	movs	r1, #2
200234a8:	4620      	mov	r0, r4
200234aa:	f7ff fa5e 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
200234ae:	4620      	mov	r0, r4
200234b0:	f7ff f863 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
200234b4:	2800      	cmp	r0, #0
200234b6:	d0f1      	beq.n	2002349c <HAL_QSPIEX_WRITE_PAGE+0x134>
200234b8:	eba7 070a 	sub.w	r7, r7, sl
200234bc:	44d0      	add	r8, sl
200234be:	1e7b      	subs	r3, r7, #1
200234c0:	2b02      	cmp	r3, #2
200234c2:	d830      	bhi.n	20023526 <HAL_QSPIEX_WRITE_PAGE+0x1be>
200234c4:	6923      	ldr	r3, [r4, #16]
200234c6:	4446      	add	r6, r8
200234c8:	4333      	orrs	r3, r6
200234ca:	681b      	ldr	r3, [r3, #0]
200234cc:	463a      	mov	r2, r7
200234ce:	eb09 0108 	add.w	r1, r9, r8
200234d2:	a807      	add	r0, sp, #28
200234d4:	9307      	str	r3, [sp, #28]
200234d6:	f002 fc5a 	bl	20025d8e <memcpy>
200234da:	2200      	movs	r2, #0
200234dc:	4620      	mov	r0, r4
200234de:	4611      	mov	r1, r2
200234e0:	f7ff fa43 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
200234e4:	9907      	ldr	r1, [sp, #28]
200234e6:	4620      	mov	r0, r4
200234e8:	f7fe fff3 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
200234ec:	2104      	movs	r1, #4
200234ee:	4620      	mov	r0, r4
200234f0:	f7fe fff6 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
200234f4:	4632      	mov	r2, r6
200234f6:	4620      	mov	r0, r4
200234f8:	9903      	ldr	r1, [sp, #12]
200234fa:	f7ff fa36 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
200234fe:	2101      	movs	r1, #1
20023500:	4620      	mov	r0, r4
20023502:	f7fe ffed 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023506:	2200      	movs	r2, #0
20023508:	2102      	movs	r1, #2
2002350a:	4620      	mov	r0, r4
2002350c:	f7ff fa2d 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023510:	4620      	mov	r0, r4
20023512:	f7ff f832 	bl	2002257a <HAL_FLASH_IS_PROG_DONE>
20023516:	2800      	cmp	r0, #0
20023518:	d0f1      	beq.n	200234fe <HAL_QSPIEX_WRITE_PAGE+0x196>
2002351a:	e751      	b.n	200233c0 <HAL_QSPIEX_WRITE_PAGE+0x58>
2002351c:	2b02      	cmp	r3, #2
2002351e:	bf14      	ite	ne
20023520:	2316      	movne	r3, #22
20023522:	2317      	moveq	r3, #23
20023524:	e77c      	b.n	20023420 <HAL_QSPIEX_WRITE_PAGE+0xb8>
20023526:	2f00      	cmp	r7, #0
20023528:	f73f af7e 	bgt.w	20023428 <HAL_QSPIEX_WRITE_PAGE+0xc0>
2002352c:	e748      	b.n	200233c0 <HAL_QSPIEX_WRITE_PAGE+0x58>
2002352e:	4618      	mov	r0, r3
20023530:	e747      	b.n	200233c2 <HAL_QSPIEX_WRITE_PAGE+0x5a>

20023532 <HAL_QSPIEX_SECT_ERASE>:
20023532:	b573      	push	{r0, r1, r4, r5, r6, lr}
20023534:	4604      	mov	r4, r0
20023536:	460d      	mov	r5, r1
20023538:	f7ff fc3f 	bl	20022dba <flash_handle_valid>
2002353c:	b1e8      	cbz	r0, 2002357a <HAL_QSPIEX_SECT_ERASE+0x48>
2002353e:	6963      	ldr	r3, [r4, #20]
20023540:	460a      	mov	r2, r1
20023542:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023546:	f04f 0100 	mov.w	r1, #0
2002354a:	4620      	mov	r0, r4
2002354c:	bf94      	ite	ls
2002354e:	261b      	movls	r6, #27
20023550:	2629      	movhi	r6, #41	@ 0x29
20023552:	f7ff fa0a 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023556:	2101      	movs	r1, #1
20023558:	4620      	mov	r0, r4
2002355a:	f7fe ffcb 	bl	200224f4 <HAL_FLASH_WRITE_DLEN2>
2002355e:	2301      	movs	r3, #1
20023560:	462a      	mov	r2, r5
20023562:	9300      	str	r3, [sp, #0]
20023564:	4631      	mov	r1, r6
20023566:	2302      	movs	r3, #2
20023568:	4620      	mov	r0, r4
2002356a:	f7ff fa31 	bl	200229d0 <HAL_FLASH_ISSUE_CMD_SEQ>
2002356e:	3800      	subs	r0, #0
20023570:	bf18      	it	ne
20023572:	2001      	movne	r0, #1
20023574:	4240      	negs	r0, r0
20023576:	b002      	add	sp, #8
20023578:	bd70      	pop	{r4, r5, r6, pc}
2002357a:	f04f 30ff 	mov.w	r0, #4294967295
2002357e:	e7fa      	b.n	20023576 <HAL_QSPIEX_SECT_ERASE+0x44>

20023580 <HAL_QSPI_GET_SRC_CLK>:
20023580:	b508      	push	{r3, lr}
20023582:	b318      	cbz	r0, 200235cc <HAL_QSPI_GET_SRC_CLK+0x4c>
20023584:	6803      	ldr	r3, [r0, #0]
20023586:	4a12      	ldr	r2, [pc, #72]	@ (200235d0 <HAL_QSPI_GET_SRC_CLK+0x50>)
20023588:	4293      	cmp	r3, r2
2002358a:	d010      	beq.n	200235ae <HAL_QSPI_GET_SRC_CLK+0x2e>
2002358c:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
20023590:	4293      	cmp	r3, r2
20023592:	d00e      	beq.n	200235b2 <HAL_QSPI_GET_SRC_CLK+0x32>
20023594:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
20023598:	4293      	cmp	r3, r2
2002359a:	d117      	bne.n	200235cc <HAL_QSPI_GET_SRC_CLK+0x4c>
2002359c:	2008      	movs	r0, #8
2002359e:	f000 ff0d 	bl	200243bc <HAL_RCC_HCPU_GetClockSrc>
200235a2:	2802      	cmp	r0, #2
200235a4:	d107      	bne.n	200235b6 <HAL_QSPI_GET_SRC_CLK+0x36>
200235a6:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200235aa:	f000 bf4b 	b.w	20024444 <HAL_RCC_HCPU_GetDLL2Freq>
200235ae:	2004      	movs	r0, #4
200235b0:	e7f5      	b.n	2002359e <HAL_QSPI_GET_SRC_CLK+0x1e>
200235b2:	2006      	movs	r0, #6
200235b4:	e7f3      	b.n	2002359e <HAL_QSPI_GET_SRC_CLK+0x1e>
200235b6:	2803      	cmp	r0, #3
200235b8:	d103      	bne.n	200235c2 <HAL_QSPI_GET_SRC_CLK+0x42>
200235ba:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200235be:	f000 bf44 	b.w	2002444a <HAL_RCC_HCPU_GetDLL3Freq>
200235c2:	2001      	movs	r0, #1
200235c4:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
200235c8:	f000 bf92 	b.w	200244f0 <HAL_RCC_GetSysCLKFreq>
200235cc:	2000      	movs	r0, #0
200235ce:	bd08      	pop	{r3, pc}
200235d0:	50041000 	.word	0x50041000

200235d4 <HAL_QSPI_GET_CLK>:
200235d4:	b538      	push	{r3, r4, r5, lr}
200235d6:	4605      	mov	r5, r0
200235d8:	b908      	cbnz	r0, 200235de <HAL_QSPI_GET_CLK+0xa>
200235da:	2000      	movs	r0, #0
200235dc:	bd38      	pop	{r3, r4, r5, pc}
200235de:	f7fe ffe4 	bl	200225aa <HAL_FLASH_GET_DIV>
200235e2:	4604      	mov	r4, r0
200235e4:	2800      	cmp	r0, #0
200235e6:	d0f8      	beq.n	200235da <HAL_QSPI_GET_CLK+0x6>
200235e8:	4628      	mov	r0, r5
200235ea:	f7ff ffc9 	bl	20023580 <HAL_QSPI_GET_SRC_CLK>
200235ee:	fbb0 f0f4 	udiv	r0, r0, r4
200235f2:	e7f3      	b.n	200235dc <HAL_QSPI_GET_CLK+0x8>

200235f4 <HAL_QSPI_READ_ID>:
200235f4:	b138      	cbz	r0, 20023606 <HAL_QSPI_READ_ID+0x12>
200235f6:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
200235fa:	b113      	cbz	r3, 20023602 <HAL_QSPI_READ_ID+0xe>
200235fc:	2100      	movs	r1, #0
200235fe:	f7ff bc5a 	b.w	20022eb6 <nand_read_id>
20023602:	f7ff bb08 	b.w	20022c16 <HAL_FLASH_GET_NOR_ID>
20023606:	20ff      	movs	r0, #255	@ 0xff
20023608:	4770      	bx	lr

2002360a <HAL_NOR_CFG_DTR>:
2002360a:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
2002360c:	4604      	mov	r4, r0
2002360e:	460a      	mov	r2, r1
20023610:	b351      	cbz	r1, 20023668 <HAL_NOR_CFG_DTR+0x5e>
20023612:	68c5      	ldr	r5, [r0, #12]
20023614:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
20023618:	2b00      	cmp	r3, #0
2002361a:	d03b      	beq.n	20023694 <HAL_NOR_CFG_DTR+0x8a>
2002361c:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
20023620:	b3c3      	cbz	r3, 20023694 <HAL_NOR_CFG_DTR+0x8a>
20023622:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
20023626:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
2002362a:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
2002362e:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
20023632:	9603      	str	r6, [sp, #12]
20023634:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
20023638:	9602      	str	r6, [sp, #8]
2002363a:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
2002363e:	9601      	str	r6, [sp, #4]
20023640:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
20023644:	9500      	str	r5, [sp, #0]
20023646:	f7fe fefe 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
2002364a:	68e3      	ldr	r3, [r4, #12]
2002364c:	4620      	mov	r0, r4
2002364e:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
20023652:	f7fe feed 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
20023656:	2101      	movs	r1, #1
20023658:	4620      	mov	r0, r4
2002365a:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
2002365e:	f7ff f8b2 	bl	200227c6 <HAL_MPI_CFG_DTR>
20023662:	2000      	movs	r0, #0
20023664:	b004      	add	sp, #16
20023666:	bd70      	pop	{r4, r5, r6, pc}
20023668:	f7ff f8ad 	bl	200227c6 <HAL_MPI_CFG_DTR>
2002366c:	6963      	ldr	r3, [r4, #20]
2002366e:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20023672:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023676:	d906      	bls.n	20023686 <HAL_NOR_CFG_DTR+0x7c>
20023678:	b919      	cbnz	r1, 20023682 <HAL_NOR_CFG_DTR+0x78>
2002367a:	4620      	mov	r0, r4
2002367c:	f7ff f911 	bl	200228a2 <HAL_FLASH_CONFIG_FULL_AHB_READ>
20023680:	e7ef      	b.n	20023662 <HAL_NOR_CFG_DTR+0x58>
20023682:	2101      	movs	r1, #1
20023684:	e7f9      	b.n	2002367a <HAL_NOR_CFG_DTR+0x70>
20023686:	b919      	cbnz	r1, 20023690 <HAL_NOR_CFG_DTR+0x86>
20023688:	4620      	mov	r0, r4
2002368a:	f7ff f8c6 	bl	2002281a <HAL_FLASH_CONFIG_AHB_READ>
2002368e:	e7e8      	b.n	20023662 <HAL_NOR_CFG_DTR+0x58>
20023690:	2101      	movs	r1, #1
20023692:	e7f9      	b.n	20023688 <HAL_NOR_CFG_DTR+0x7e>
20023694:	2001      	movs	r0, #1
20023696:	e7e5      	b.n	20023664 <HAL_NOR_CFG_DTR+0x5a>

20023698 <HAL_FLASH_Init>:
20023698:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
2002369c:	460e      	mov	r6, r1
2002369e:	4690      	mov	r8, r2
200236a0:	461f      	mov	r7, r3
200236a2:	4604      	mov	r4, r0
200236a4:	b087      	sub	sp, #28
200236a6:	2800      	cmp	r0, #0
200236a8:	f000 80e5 	beq.w	20023876 <HAL_FLASH_Init+0x1de>
200236ac:	2900      	cmp	r1, #0
200236ae:	f000 80e2 	beq.w	20023876 <HAL_FLASH_Init+0x1de>
200236b2:	f7fe fe9b 	bl	200223ec <HAL_QSPI_Init>
200236b6:	6820      	ldr	r0, [r4, #0]
200236b8:	f7ff fb85 	bl	20022dc6 <HAL_GET_FLASH_MID>
200236bc:	6933      	ldr	r3, [r6, #16]
200236be:	2100      	movs	r1, #0
200236c0:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
200236c4:	68b3      	ldr	r3, [r6, #8]
200236c6:	4605      	mov	r5, r0
200236c8:	64a3      	str	r3, [r4, #72]	@ 0x48
200236ca:	68f3      	ldr	r3, [r6, #12]
200236cc:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
200236d0:	051b      	lsls	r3, r3, #20
200236d2:	64e3      	str	r3, [r4, #76]	@ 0x4c
200236d4:	2302      	movs	r3, #2
200236d6:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
200236da:	6933      	ldr	r3, [r6, #16]
200236dc:	f8c4 8008 	str.w	r8, [r4, #8]
200236e0:	1e5a      	subs	r2, r3, #1
200236e2:	4253      	negs	r3, r2
200236e4:	4153      	adcs	r3, r2
200236e6:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
200236ea:	f1b8 0f00 	cmp.w	r8, #0
200236ee:	d058      	beq.n	200237a2 <HAL_FLASH_Init+0x10a>
200236f0:	2f00      	cmp	r7, #0
200236f2:	d056      	beq.n	200237a2 <HAL_FLASH_Init+0x10a>
200236f4:	683b      	ldr	r3, [r7, #0]
200236f6:	f8c8 3000 	str.w	r3, [r8]
200236fa:	68a3      	ldr	r3, [r4, #8]
200236fc:	68fa      	ldr	r2, [r7, #12]
200236fe:	605a      	str	r2, [r3, #4]
20023700:	2210      	movs	r2, #16
20023702:	68a3      	ldr	r3, [r4, #8]
20023704:	609a      	str	r2, [r3, #8]
20023706:	2280      	movs	r2, #128	@ 0x80
20023708:	68a3      	ldr	r3, [r4, #8]
2002370a:	60d9      	str	r1, [r3, #12]
2002370c:	68a3      	ldr	r3, [r4, #8]
2002370e:	611a      	str	r2, [r3, #16]
20023710:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20023714:	68a3      	ldr	r3, [r4, #8]
20023716:	6159      	str	r1, [r3, #20]
20023718:	68a3      	ldr	r3, [r4, #8]
2002371a:	6199      	str	r1, [r3, #24]
2002371c:	68a3      	ldr	r3, [r4, #8]
2002371e:	61d9      	str	r1, [r3, #28]
20023720:	68a3      	ldr	r3, [r4, #8]
20023722:	621a      	str	r2, [r3, #32]
20023724:	68a3      	ldr	r3, [r4, #8]
20023726:	6259      	str	r1, [r3, #36]	@ 0x24
20023728:	b1c0      	cbz	r0, 2002375c <HAL_FLASH_Init+0xc4>
2002372a:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
2002372e:	4298      	cmp	r0, r3
20023730:	d014      	beq.n	2002375c <HAL_FLASH_Init+0xc4>
20023732:	2701      	movs	r7, #1
20023734:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023738:	2b00      	cmp	r3, #0
2002373a:	d13d      	bne.n	200237b8 <HAL_FLASH_Init+0x120>
2002373c:	2f00      	cmp	r7, #0
2002373e:	d15a      	bne.n	200237f6 <HAL_FLASH_Init+0x15e>
20023740:	4620      	mov	r0, r4
20023742:	f7ff fb1a 	bl	20022d7a <HAL_FLASH_RELEASE_DPD>
20023746:	4638      	mov	r0, r7
20023748:	f7fe f933 	bl	200219b2 <HAL_Delay_us>
2002374c:	2032      	movs	r0, #50	@ 0x32
2002374e:	f7fe f930 	bl	200219b2 <HAL_Delay_us>
20023752:	4620      	mov	r0, r4
20023754:	f7ff ff4e 	bl	200235f4 <HAL_QSPI_READ_ID>
20023758:	4605      	mov	r5, r0
2002375a:	e04c      	b.n	200237f6 <HAL_FLASH_Init+0x15e>
2002375c:	2101      	movs	r1, #1
2002375e:	4620      	mov	r0, r4
20023760:	f7fe ff18 	bl	20022594 <HAL_FLASH_SET_TXSLOT>
20023764:	4baf      	ldr	r3, [pc, #700]	@ (20023a24 <HAL_FLASH_Init+0x38c>)
20023766:	69a2      	ldr	r2, [r4, #24]
20023768:	4620      	mov	r0, r4
2002376a:	429a      	cmp	r2, r3
2002376c:	f04f 0200 	mov.w	r2, #0
20023770:	bf8c      	ite	hi
20023772:	2101      	movhi	r1, #1
20023774:	4611      	movls	r1, r2
20023776:	f7ff faf9 	bl	20022d6c <HAL_QSPI_SET_CLK_INV>
2002377a:	4620      	mov	r0, r4
2002377c:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
20023780:	f7fe ff0f 	bl	200225a2 <HAL_FLASH_SET_CLK_rom>
20023784:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
20023788:	b12b      	cbz	r3, 20023796 <HAL_FLASH_Init+0xfe>
2002378a:	2b01      	cmp	r3, #1
2002378c:	d110      	bne.n	200237b0 <HAL_FLASH_Init+0x118>
2002378e:	2100      	movs	r1, #0
20023790:	4620      	mov	r0, r4
20023792:	f7fe ffdd 	bl	20022750 <HAL_FLASH_SET_DUAL_MODE>
20023796:	2101      	movs	r1, #1
20023798:	4620      	mov	r0, r4
2002379a:	f7fe ff68 	bl	2002266e <HAL_FLASH_ENABLE_QSPI>
2002379e:	2700      	movs	r7, #0
200237a0:	e7c8      	b.n	20023734 <HAL_FLASH_Init+0x9c>
200237a2:	2d00      	cmp	r5, #0
200237a4:	d0de      	beq.n	20023764 <HAL_FLASH_Init+0xcc>
200237a6:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200237aa:	429d      	cmp	r5, r3
200237ac:	d1c1      	bne.n	20023732 <HAL_FLASH_Init+0x9a>
200237ae:	e7d9      	b.n	20023764 <HAL_FLASH_Init+0xcc>
200237b0:	2b02      	cmp	r3, #2
200237b2:	d1f0      	bne.n	20023796 <HAL_FLASH_Init+0xfe>
200237b4:	2101      	movs	r1, #1
200237b6:	e7eb      	b.n	20023790 <HAL_FLASH_Init+0xf8>
200237b8:	6822      	ldr	r2, [r4, #0]
200237ba:	2600      	movs	r6, #0
200237bc:	6893      	ldr	r3, [r2, #8]
200237be:	4631      	mov	r1, r6
200237c0:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
200237c4:	6093      	str	r3, [r2, #8]
200237c6:	2301      	movs	r3, #1
200237c8:	4632      	mov	r2, r6
200237ca:	4620      	mov	r0, r4
200237cc:	e9cd 6303 	strd	r6, r3, [sp, #12]
200237d0:	e9cd 6601 	strd	r6, r6, [sp, #4]
200237d4:	4633      	mov	r3, r6
200237d6:	9600      	str	r6, [sp, #0]
200237d8:	f7fe feec 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
200237dc:	4632      	mov	r2, r6
200237de:	21ff      	movs	r1, #255	@ 0xff
200237e0:	4620      	mov	r0, r4
200237e2:	f7fe fea2 	bl	2002252a <HAL_FLASH_SET_CMD>
200237e6:	4630      	mov	r0, r6
200237e8:	f7fe f8e3 	bl	200219b2 <HAL_Delay_us>
200237ec:	20c8      	movs	r0, #200	@ 0xc8
200237ee:	f7fe f8e0 	bl	200219b2 <HAL_Delay_us>
200237f2:	2f00      	cmp	r7, #0
200237f4:	d0ad      	beq.n	20023752 <HAL_FLASH_Init+0xba>
200237f6:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200237fa:	b2ee      	uxtb	r6, r5
200237fc:	f3c5 2807 	ubfx	r8, r5, #8, #8
20023800:	6425      	str	r5, [r4, #64]	@ 0x40
20023802:	f3c5 4507 	ubfx	r5, r5, #16, #8
20023806:	4642      	mov	r2, r8
20023808:	4629      	mov	r1, r5
2002380a:	4630      	mov	r0, r6
2002380c:	b3ab      	cbz	r3, 2002387a <HAL_FLASH_Init+0x1e2>
2002380e:	f001 f891 	bl	20024934 <spi_nand_get_cmd_by_id>
20023812:	60e0      	str	r0, [r4, #12]
20023814:	bba0      	cbnz	r0, 20023880 <HAL_FLASH_Init+0x1e8>
20023816:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
2002381a:	b32b      	cbz	r3, 20023868 <HAL_FLASH_Init+0x1d0>
2002381c:	2108      	movs	r1, #8
2002381e:	4620      	mov	r0, r4
20023820:	f7ff fb49 	bl	20022eb6 <nand_read_id>
20023824:	f3c0 2807 	ubfx	r8, r0, #8, #8
20023828:	f3c0 4507 	ubfx	r5, r0, #16, #8
2002382c:	b2c6      	uxtb	r6, r0
2002382e:	6420      	str	r0, [r4, #64]	@ 0x40
20023830:	4642      	mov	r2, r8
20023832:	4629      	mov	r1, r5
20023834:	4630      	mov	r0, r6
20023836:	f001 f87d 	bl	20024934 <spi_nand_get_cmd_by_id>
2002383a:	60e0      	str	r0, [r4, #12]
2002383c:	bb00      	cbnz	r0, 20023880 <HAL_FLASH_Init+0x1e8>
2002383e:	210f      	movs	r1, #15
20023840:	4620      	mov	r0, r4
20023842:	f7ff fb38 	bl	20022eb6 <nand_read_id>
20023846:	f3c0 2807 	ubfx	r8, r0, #8, #8
2002384a:	f3c0 4507 	ubfx	r5, r0, #16, #8
2002384e:	b2c6      	uxtb	r6, r0
20023850:	6420      	str	r0, [r4, #64]	@ 0x40
20023852:	4642      	mov	r2, r8
20023854:	4629      	mov	r1, r5
20023856:	4630      	mov	r0, r6
20023858:	f001 f86c 	bl	20024934 <spi_nand_get_cmd_by_id>
2002385c:	60e0      	str	r0, [r4, #12]
2002385e:	b978      	cbnz	r0, 20023880 <HAL_FLASH_Init+0x1e8>
20023860:	f001 f880 	bl	20024964 <spi_nand_get_default_ctable>
20023864:	60e0      	str	r0, [r4, #12]
20023866:	b958      	cbnz	r0, 20023880 <HAL_FLASH_Init+0x1e8>
20023868:	2100      	movs	r1, #0
2002386a:	4620      	mov	r0, r4
2002386c:	f7fe feff 	bl	2002266e <HAL_FLASH_ENABLE_QSPI>
20023870:	2300      	movs	r3, #0
20023872:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
20023876:	2001      	movs	r0, #1
20023878:	e052      	b.n	20023920 <HAL_FLASH_Init+0x288>
2002387a:	f000 fffd 	bl	20024878 <spi_flash_get_cmd_by_id>
2002387e:	e7c8      	b.n	20023812 <HAL_FLASH_Init+0x17a>
20023880:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023884:	4642      	mov	r2, r8
20023886:	4629      	mov	r1, r5
20023888:	4630      	mov	r0, r6
2002388a:	2b00      	cmp	r3, #0
2002388c:	d04b      	beq.n	20023926 <HAL_FLASH_Init+0x28e>
2002388e:	f001 f877 	bl	20024980 <spi_nand_get_size_by_id>
20023892:	4642      	mov	r2, r8
20023894:	4629      	mov	r1, r5
20023896:	4681      	mov	r9, r0
20023898:	4630      	mov	r0, r6
2002389a:	f001 f87b 	bl	20024994 <spi_nand_get_plane_select_flag>
2002389e:	4642      	mov	r2, r8
200238a0:	4629      	mov	r1, r5
200238a2:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
200238a6:	4630      	mov	r0, r6
200238a8:	f001 f87d 	bl	200249a6 <spi_nand_get_big_page_flag>
200238ac:	4642      	mov	r2, r8
200238ae:	4629      	mov	r1, r5
200238b0:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
200238b4:	4630      	mov	r0, r6
200238b6:	f001 f87f 	bl	200249b8 <spi_nand_get_ecc_mode>
200238ba:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
200238be:	4642      	mov	r2, r8
200238c0:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
200238c4:	4629      	mov	r1, r5
200238c6:	4630      	mov	r0, r6
200238c8:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
200238cc:	f001 f844 	bl	20024958 <spi_nand_get_ext_cfg_by_id>
200238d0:	63e0      	str	r0, [r4, #60]	@ 0x3c
200238d2:	f1b9 0f00 	cmp.w	r9, #0
200238d6:	d003      	beq.n	200238e0 <HAL_FLASH_Init+0x248>
200238d8:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
200238dc:	f8c4 9014 	str.w	r9, [r4, #20]
200238e0:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200238e4:	2b00      	cmp	r3, #0
200238e6:	d17d      	bne.n	200239e4 <HAL_FLASH_Init+0x34c>
200238e8:	2f00      	cmp	r7, #0
200238ea:	d178      	bne.n	200239de <HAL_FLASH_Init+0x346>
200238ec:	4620      	mov	r0, r4
200238ee:	f7ff f9ad 	bl	20022c4c <HAL_FLASH_CLR_PROTECT>
200238f2:	6963      	ldr	r3, [r4, #20]
200238f4:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
200238f8:	d945      	bls.n	20023986 <HAL_FLASH_Init+0x2ee>
200238fa:	463a      	mov	r2, r7
200238fc:	2121      	movs	r1, #33	@ 0x21
200238fe:	4620      	mov	r0, r4
20023900:	f7ff f833 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
20023904:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023908:	bb0b      	cbnz	r3, 2002394e <HAL_FLASH_Init+0x2b6>
2002390a:	4639      	mov	r1, r7
2002390c:	4620      	mov	r0, r4
2002390e:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023912:	f7ff f975 	bl	20022c00 <HAL_FLASH_FADDR_SET_QSPI>
20023916:	2107      	movs	r1, #7
20023918:	4620      	mov	r0, r4
2002391a:	f7fe ff02 	bl	20022722 <HAL_FLASH_SET_ROW_BOUNDARY>
2002391e:	2000      	movs	r0, #0
20023920:	b007      	add	sp, #28
20023922:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20023926:	f000 ffbb 	bl	200248a0 <spi_flash_get_size_by_id>
2002392a:	4642      	mov	r2, r8
2002392c:	4629      	mov	r1, r5
2002392e:	4681      	mov	r9, r0
20023930:	4630      	mov	r0, r6
20023932:	f000 ffc9 	bl	200248c8 <spi_flash_get_otp_base>
20023936:	4642      	mov	r2, r8
20023938:	63a0      	str	r0, [r4, #56]	@ 0x38
2002393a:	4629      	mov	r1, r5
2002393c:	4630      	mov	r0, r6
2002393e:	f000 ff73 	bl	20024828 <spi_nor_get_ext_cfg_by_id>
20023942:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023944:	2800      	cmp	r0, #0
20023946:	d0c4      	beq.n	200238d2 <HAL_FLASH_Init+0x23a>
20023948:	6803      	ldr	r3, [r0, #0]
2002394a:	63a3      	str	r3, [r4, #56]	@ 0x38
2002394c:	e7c1      	b.n	200238d2 <HAL_FLASH_Init+0x23a>
2002394e:	2101      	movs	r1, #1
20023950:	4620      	mov	r0, r4
20023952:	f7ff f955 	bl	20022c00 <HAL_FLASH_FADDR_SET_QSPI>
20023956:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
2002395a:	f1b9 0f01 	cmp.w	r9, #1
2002395e:	d1da      	bne.n	20023916 <HAL_FLASH_Init+0x27e>
20023960:	4642      	mov	r2, r8
20023962:	4629      	mov	r1, r5
20023964:	4630      	mov	r0, r6
20023966:	f000 ffa5 	bl	200248b4 <spi_flash_is_support_dtr>
2002396a:	b120      	cbz	r0, 20023976 <HAL_FLASH_Init+0x2de>
2002396c:	4649      	mov	r1, r9
2002396e:	4620      	mov	r0, r4
20023970:	f7ff fe4b 	bl	2002360a <HAL_NOR_CFG_DTR>
20023974:	e7cf      	b.n	20023916 <HAL_FLASH_Init+0x27e>
20023976:	463a      	mov	r2, r7
20023978:	4639      	mov	r1, r7
2002397a:	4620      	mov	r0, r4
2002397c:	f7fe ff23 	bl	200227c6 <HAL_MPI_CFG_DTR>
20023980:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023984:	e7c7      	b.n	20023916 <HAL_FLASH_Init+0x27e>
20023986:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
2002398a:	b933      	cbnz	r3, 2002399a <HAL_FLASH_Init+0x302>
2002398c:	4639      	mov	r1, r7
2002398e:	4620      	mov	r0, r4
20023990:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023994:	f7ff f929 	bl	20022bea <HAL_FLASH_SET_QUAL_SPI>
20023998:	e7c1      	b.n	2002391e <HAL_FLASH_Init+0x286>
2002399a:	2101      	movs	r1, #1
2002399c:	4620      	mov	r0, r4
2002399e:	f7ff f924 	bl	20022bea <HAL_FLASH_SET_QUAL_SPI>
200239a2:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
200239a6:	f1b9 0f01 	cmp.w	r9, #1
200239aa:	d112      	bne.n	200239d2 <HAL_FLASH_Init+0x33a>
200239ac:	4642      	mov	r2, r8
200239ae:	4629      	mov	r1, r5
200239b0:	4630      	mov	r0, r6
200239b2:	f000 ff7f 	bl	200248b4 <spi_flash_is_support_dtr>
200239b6:	b120      	cbz	r0, 200239c2 <HAL_FLASH_Init+0x32a>
200239b8:	4649      	mov	r1, r9
200239ba:	4620      	mov	r0, r4
200239bc:	f7ff fe25 	bl	2002360a <HAL_NOR_CFG_DTR>
200239c0:	e7ad      	b.n	2002391e <HAL_FLASH_Init+0x286>
200239c2:	463a      	mov	r2, r7
200239c4:	4639      	mov	r1, r7
200239c6:	4620      	mov	r0, r4
200239c8:	f7fe fefd 	bl	200227c6 <HAL_MPI_CFG_DTR>
200239cc:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
200239d0:	e7a5      	b.n	2002391e <HAL_FLASH_Init+0x286>
200239d2:	463a      	mov	r2, r7
200239d4:	4639      	mov	r1, r7
200239d6:	4620      	mov	r0, r4
200239d8:	f7fe fef5 	bl	200227c6 <HAL_MPI_CFG_DTR>
200239dc:	e79f      	b.n	2002391e <HAL_FLASH_Init+0x286>
200239de:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
200239e2:	e79c      	b.n	2002391e <HAL_FLASH_Init+0x286>
200239e4:	2101      	movs	r1, #1
200239e6:	4620      	mov	r0, r4
200239e8:	f7fe fd7a 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
200239ec:	68e3      	ldr	r3, [r4, #12]
200239ee:	2102      	movs	r1, #2
200239f0:	791a      	ldrb	r2, [r3, #4]
200239f2:	4620      	mov	r0, r4
200239f4:	f7fe ffb9 	bl	2002296a <HAL_FLASH_ISSUE_CMD>
200239f8:	4620      	mov	r0, r4
200239fa:	f7fe fdc7 	bl	2002258c <HAL_FLASH_READ32>
200239fe:	4605      	mov	r5, r0
20023a00:	200a      	movs	r0, #10
20023a02:	f7fd ffd6 	bl	200219b2 <HAL_Delay_us>
20023a06:	07eb      	lsls	r3, r5, #31
20023a08:	d4ec      	bmi.n	200239e4 <HAL_FLASH_Init+0x34c>
20023a0a:	4631      	mov	r1, r6
20023a0c:	4620      	mov	r0, r4
20023a0e:	f7ff fb9e 	bl	2002314e <nand_clear_status>
20023a12:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023a16:	2b02      	cmp	r3, #2
20023a18:	d181      	bne.n	2002391e <HAL_FLASH_Init+0x286>
20023a1a:	2101      	movs	r1, #1
20023a1c:	4620      	mov	r0, r4
20023a1e:	f7ff fb65 	bl	200230ec <HAL_NAND_EN_QUAL>
20023a22:	e77c      	b.n	2002391e <HAL_FLASH_Init+0x286>
20023a24:	03938700 	.word	0x03938700

20023a28 <HAL_MPI_OPSRAM_CAL_DELAY>:
20023a28:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20023a2c:	4b21      	ldr	r3, [pc, #132]	@ (20023ab4 <HAL_MPI_OPSRAM_CAL_DELAY+0x8c>)
20023a2e:	4616      	mov	r6, r2
20023a30:	6982      	ldr	r2, [r0, #24]
20023a32:	4605      	mov	r5, r0
20023a34:	429a      	cmp	r2, r3
20023a36:	460f      	mov	r7, r1
20023a38:	d805      	bhi.n	20023a46 <HAL_MPI_OPSRAM_CAL_DELAY+0x1e>
20023a3a:	231f      	movs	r3, #31
20023a3c:	2000      	movs	r0, #0
20023a3e:	700b      	strb	r3, [r1, #0]
20023a40:	7033      	strb	r3, [r6, #0]
20023a42:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023a46:	f04f 4200 	mov.w	r2, #2147483648	@ 0x80000000
20023a4a:	6803      	ldr	r3, [r0, #0]
20023a4c:	2000      	movs	r0, #0
20023a4e:	65da      	str	r2, [r3, #92]	@ 0x5c
20023a50:	f7fd ffaf 	bl	200219b2 <HAL_Delay_us>
20023a54:	2400      	movs	r4, #0
20023a56:	682b      	ldr	r3, [r5, #0]
20023a58:	0222      	lsls	r2, r4, #8
20023a5a:	659a      	str	r2, [r3, #88]	@ 0x58
20023a5c:	200a      	movs	r0, #10
20023a5e:	f7fd ffa8 	bl	200219b2 <HAL_Delay_us>
20023a62:	682b      	ldr	r3, [r5, #0]
20023a64:	46a0      	mov	r8, r4
20023a66:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023a68:	3401      	adds	r4, #1
20023a6a:	03da      	lsls	r2, r3, #15
20023a6c:	d502      	bpl.n	20023a74 <HAL_MPI_OPSRAM_CAL_DELAY+0x4c>
20023a6e:	2c80      	cmp	r4, #128	@ 0x80
20023a70:	d1f1      	bne.n	20023a56 <HAL_MPI_OPSRAM_CAL_DELAY+0x2e>
20023a72:	46a0      	mov	r8, r4
20023a74:	f108 0401 	add.w	r4, r8, #1
20023a78:	2c7f      	cmp	r4, #127	@ 0x7f
20023a7a:	d905      	bls.n	20023a88 <HAL_MPI_OPSRAM_CAL_DELAY+0x60>
20023a7c:	2001      	movs	r0, #1
20023a7e:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
20023a82:	682b      	ldr	r3, [r5, #0]
20023a84:	65da      	str	r2, [r3, #92]	@ 0x5c
20023a86:	e7dc      	b.n	20023a42 <HAL_MPI_OPSRAM_CAL_DELAY+0x1a>
20023a88:	682b      	ldr	r3, [r5, #0]
20023a8a:	0222      	lsls	r2, r4, #8
20023a8c:	659a      	str	r2, [r3, #88]	@ 0x58
20023a8e:	200a      	movs	r0, #10
20023a90:	f7fd ff8f 	bl	200219b2 <HAL_Delay_us>
20023a94:	682b      	ldr	r3, [r5, #0]
20023a96:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023a98:	03db      	lsls	r3, r3, #15
20023a9a:	d401      	bmi.n	20023aa0 <HAL_MPI_OPSRAM_CAL_DELAY+0x78>
20023a9c:	3401      	adds	r4, #1
20023a9e:	e7eb      	b.n	20023a78 <HAL_MPI_OPSRAM_CAL_DELAY+0x50>
20023aa0:	eba4 0408 	sub.w	r4, r4, r8
20023aa4:	f3c4 0447 	ubfx	r4, r4, #1, #8
20023aa8:	1f63      	subs	r3, r4, #5
20023aaa:	703b      	strb	r3, [r7, #0]
20023aac:	2000      	movs	r0, #0
20023aae:	7034      	strb	r4, [r6, #0]
20023ab0:	e7e5      	b.n	20023a7e <HAL_MPI_OPSRAM_CAL_DELAY+0x56>
20023ab2:	bf00      	nop
20023ab4:	016e3600 	.word	0x016e3600

20023ab8 <HAL_SPI_PSRAM_Init>:
20023ab8:	b537      	push	{r0, r1, r2, r4, r5, lr}
20023aba:	4614      	mov	r4, r2
20023abc:	4605      	mov	r5, r0
20023abe:	2800      	cmp	r0, #0
20023ac0:	d043      	beq.n	20023b4a <HAL_SPI_PSRAM_Init+0x92>
20023ac2:	2900      	cmp	r1, #0
20023ac4:	d041      	beq.n	20023b4a <HAL_SPI_PSRAM_Init+0x92>
20023ac6:	f7fe fc91 	bl	200223ec <HAL_QSPI_Init>
20023aca:	4628      	mov	r0, r5
20023acc:	b2e1      	uxtb	r1, r4
20023ace:	f7fe fd68 	bl	200225a2 <HAL_FLASH_SET_CLK_rom>
20023ad2:	4628      	mov	r0, r5
20023ad4:	f7ff fd7e 	bl	200235d4 <HAL_QSPI_GET_CLK>
20023ad8:	4b1d      	ldr	r3, [pc, #116]	@ (20023b50 <HAL_SPI_PSRAM_Init+0x98>)
20023ada:	4298      	cmp	r0, r3
20023adc:	d930      	bls.n	20023b40 <HAL_SPI_PSRAM_Init+0x88>
20023ade:	4b1d      	ldr	r3, [pc, #116]	@ (20023b54 <HAL_SPI_PSRAM_Init+0x9c>)
20023ae0:	4298      	cmp	r0, r3
20023ae2:	d92f      	bls.n	20023b44 <HAL_SPI_PSRAM_Init+0x8c>
20023ae4:	4b1c      	ldr	r3, [pc, #112]	@ (20023b58 <HAL_SPI_PSRAM_Init+0xa0>)
20023ae6:	4298      	cmp	r0, r3
20023ae8:	d922      	bls.n	20023b30 <HAL_SPI_PSRAM_Init+0x78>
20023aea:	f240 34b6 	movw	r4, #950	@ 0x3b6
20023aee:	f240 4374 	movw	r3, #1140	@ 0x474
20023af2:	4a1a      	ldr	r2, [pc, #104]	@ (20023b5c <HAL_SPI_PSRAM_Init+0xa4>)
20023af4:	4290      	cmp	r0, r2
20023af6:	bf88      	it	hi
20023af8:	461c      	movhi	r4, r3
20023afa:	2200      	movs	r2, #0
20023afc:	2101      	movs	r1, #1
20023afe:	4628      	mov	r0, r5
20023b00:	f7ff f934 	bl	20022d6c <HAL_QSPI_SET_CLK_INV>
20023b04:	2100      	movs	r1, #0
20023b06:	4622      	mov	r2, r4
20023b08:	2302      	movs	r3, #2
20023b0a:	4628      	mov	r0, r5
20023b0c:	9100      	str	r1, [sp, #0]
20023b0e:	f7fe fdf3 	bl	200226f8 <HAL_FLASH_SET_CS_TIME>
20023b12:	4604      	mov	r4, r0
20023b14:	b948      	cbnz	r0, 20023b2a <HAL_SPI_PSRAM_Init+0x72>
20023b16:	2106      	movs	r1, #6
20023b18:	4628      	mov	r0, r5
20023b1a:	f7fe fe02 	bl	20022722 <HAL_FLASH_SET_ROW_BOUNDARY>
20023b1e:	4604      	mov	r4, r0
20023b20:	b918      	cbnz	r0, 20023b2a <HAL_SPI_PSRAM_Init+0x72>
20023b22:	2101      	movs	r1, #1
20023b24:	4628      	mov	r0, r5
20023b26:	f7fe fda2 	bl	2002266e <HAL_FLASH_ENABLE_QSPI>
20023b2a:	4620      	mov	r0, r4
20023b2c:	b003      	add	sp, #12
20023b2e:	bd30      	pop	{r4, r5, pc}
20023b30:	4b0b      	ldr	r3, [pc, #44]	@ (20023b60 <HAL_SPI_PSRAM_Init+0xa8>)
20023b32:	f44f 743e 	mov.w	r4, #760	@ 0x2f8
20023b36:	4298      	cmp	r0, r3
20023b38:	d8df      	bhi.n	20023afa <HAL_SPI_PSRAM_Init+0x42>
20023b3a:	2200      	movs	r2, #0
20023b3c:	4611      	mov	r1, r2
20023b3e:	e7de      	b.n	20023afe <HAL_SPI_PSRAM_Init+0x46>
20023b40:	24b4      	movs	r4, #180	@ 0xb4
20023b42:	e7fa      	b.n	20023b3a <HAL_SPI_PSRAM_Init+0x82>
20023b44:	f44f 74be 	mov.w	r4, #380	@ 0x17c
20023b48:	e7f7      	b.n	20023b3a <HAL_SPI_PSRAM_Init+0x82>
20023b4a:	2401      	movs	r4, #1
20023b4c:	e7ed      	b.n	20023b2a <HAL_SPI_PSRAM_Init+0x72>
20023b4e:	bf00      	nop
20023b50:	016e3600 	.word	0x016e3600
20023b54:	02dc6c00 	.word	0x02dc6c00
20023b58:	05b8d800 	.word	0x05b8d800
20023b5c:	07270e00 	.word	0x07270e00
20023b60:	03938700 	.word	0x03938700

20023b64 <HAL_MPI_MR_WRITE>:
20023b64:	b5f0      	push	{r4, r5, r6, r7, lr}
20023b66:	460e      	mov	r6, r1
20023b68:	4617      	mov	r7, r2
20023b6a:	4605      	mov	r5, r0
20023b6c:	b087      	sub	sp, #28
20023b6e:	b1d8      	cbz	r0, 20023ba8 <HAL_MPI_MR_WRITE+0x44>
20023b70:	2207      	movs	r2, #7
20023b72:	2400      	movs	r4, #0
20023b74:	2303      	movs	r3, #3
20023b76:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023b7a:	2101      	movs	r1, #1
20023b7c:	e9cd 4301 	strd	r4, r3, [sp, #4]
20023b80:	9400      	str	r4, [sp, #0]
20023b82:	4623      	mov	r3, r4
20023b84:	f7fe fd16 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20023b88:	2102      	movs	r1, #2
20023b8a:	4628      	mov	r0, r5
20023b8c:	f7fe fca8 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023b90:	4639      	mov	r1, r7
20023b92:	4628      	mov	r0, r5
20023b94:	f7fe fc9d 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20023b98:	4632      	mov	r2, r6
20023b9a:	21c0      	movs	r1, #192	@ 0xc0
20023b9c:	4628      	mov	r0, r5
20023b9e:	f7fe fcc4 	bl	2002252a <HAL_FLASH_SET_CMD>
20023ba2:	4620      	mov	r0, r4
20023ba4:	b007      	add	sp, #28
20023ba6:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023ba8:	2001      	movs	r0, #1
20023baa:	e7fb      	b.n	20023ba4 <HAL_MPI_MR_WRITE+0x40>

20023bac <HAL_MPI_SET_FIXLAT>:
20023bac:	e92d 41ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, lr}
20023bb0:	460c      	mov	r4, r1
20023bb2:	4616      	mov	r6, r2
20023bb4:	461f      	mov	r7, r3
20023bb6:	4605      	mov	r5, r0
20023bb8:	2800      	cmp	r0, #0
20023bba:	d040      	beq.n	20023c3e <HAL_MPI_SET_FIXLAT+0x92>
20023bbc:	466b      	mov	r3, sp
20023bbe:	4a21      	ldr	r2, [pc, #132]	@ (20023c44 <HAL_MPI_SET_FIXLAT+0x98>)
20023bc0:	6810      	ldr	r0, [r2, #0]
20023bc2:	6851      	ldr	r1, [r2, #4]
20023bc4:	c303      	stmia	r3!, {r0, r1}
20023bc6:	6890      	ldr	r0, [r2, #8]
20023bc8:	68d1      	ldr	r1, [r2, #12]
20023bca:	c303      	stmia	r3!, {r0, r1}
20023bcc:	4628      	mov	r0, r5
20023bce:	b2e1      	uxtb	r1, r4
20023bd0:	f7fe fdda 	bl	20022788 <HAL_MPI_EN_FIXLAT>
20023bd4:	f107 0310 	add.w	r3, r7, #16
20023bd8:	446b      	add	r3, sp
20023bda:	f813 8c08 	ldrb.w	r8, [r3, #-8]
20023bde:	ea4f 1848 	mov.w	r8, r8, lsl #5
20023be2:	fa5f f888 	uxtb.w	r8, r8
20023be6:	b30c      	cbz	r4, 20023c2c <HAL_MPI_SET_FIXLAT+0x80>
20023be8:	ab04      	add	r3, sp, #16
20023bea:	eb03 0356 	add.w	r3, r3, r6, lsr #1
20023bee:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023bf2:	00a4      	lsls	r4, r4, #2
20023bf4:	f044 0421 	orr.w	r4, r4, #33	@ 0x21
20023bf8:	b264      	sxtb	r4, r4
20023bfa:	f004 02fd 	and.w	r2, r4, #253	@ 0xfd
20023bfe:	2100      	movs	r1, #0
20023c00:	4628      	mov	r0, r5
20023c02:	f7ff ffaf 	bl	20023b64 <HAL_MPI_MR_WRITE>
20023c06:	1e71      	subs	r1, r6, #1
20023c08:	4628      	mov	r0, r5
20023c0a:	b249      	sxtb	r1, r1
20023c0c:	f7fe fde6 	bl	200227dc <HAL_MPI_MODIFY_RCMD_DELAY>
20023c10:	4642      	mov	r2, r8
20023c12:	2104      	movs	r1, #4
20023c14:	4628      	mov	r0, r5
20023c16:	f7ff ffa5 	bl	20023b64 <HAL_MPI_MR_WRITE>
20023c1a:	1e79      	subs	r1, r7, #1
20023c1c:	4628      	mov	r0, r5
20023c1e:	b249      	sxtb	r1, r1
20023c20:	f7fe fde5 	bl	200227ee <HAL_MPI_MODIFY_WCMD_DELAY>
20023c24:	2000      	movs	r0, #0
20023c26:	b004      	add	sp, #16
20023c28:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023c2c:	f106 0310 	add.w	r3, r6, #16
20023c30:	446b      	add	r3, sp
20023c32:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023c36:	00a4      	lsls	r4, r4, #2
20023c38:	f044 0401 	orr.w	r4, r4, #1
20023c3c:	e7dc      	b.n	20023bf8 <HAL_MPI_SET_FIXLAT+0x4c>
20023c3e:	2001      	movs	r0, #1
20023c40:	e7f1      	b.n	20023c26 <HAL_MPI_SET_FIXLAT+0x7a>
20023c42:	bf00      	nop
20023c44:	2002708c 	.word	0x2002708c

20023c48 <HAL_LEGACY_MR_WRITE>:
20023c48:	b5f0      	push	{r4, r5, r6, r7, lr}
20023c4a:	460e      	mov	r6, r1
20023c4c:	4617      	mov	r7, r2
20023c4e:	4604      	mov	r4, r0
20023c50:	b087      	sub	sp, #28
20023c52:	b1e0      	cbz	r0, 20023c8e <HAL_LEGACY_MR_WRITE+0x46>
20023c54:	2207      	movs	r2, #7
20023c56:	2500      	movs	r5, #0
20023c58:	2302      	movs	r3, #2
20023c5a:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023c5e:	e9cd 5301 	strd	r5, r3, [sp, #4]
20023c62:	9500      	str	r5, [sp, #0]
20023c64:	f990 302e 	ldrsb.w	r3, [r0, #46]	@ 0x2e
20023c68:	2101      	movs	r1, #1
20023c6a:	f7fe fca3 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20023c6e:	2104      	movs	r1, #4
20023c70:	4620      	mov	r0, r4
20023c72:	f7fe fc35 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20023c76:	4639      	mov	r1, r7
20023c78:	4620      	mov	r0, r4
20023c7a:	f7fe fc2a 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
20023c7e:	4632      	mov	r2, r6
20023c80:	21c0      	movs	r1, #192	@ 0xc0
20023c82:	4620      	mov	r0, r4
20023c84:	f7fe fc51 	bl	2002252a <HAL_FLASH_SET_CMD>
20023c88:	4628      	mov	r0, r5
20023c8a:	b007      	add	sp, #28
20023c8c:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023c8e:	2001      	movs	r0, #1
20023c90:	e7fb      	b.n	20023c8a <HAL_LEGACY_MR_WRITE+0x42>

20023c92 <HAL_LEGACY_CFG_READ>:
20023c92:	b530      	push	{r4, r5, lr}
20023c94:	4605      	mov	r5, r0
20023c96:	b085      	sub	sp, #20
20023c98:	b1a0      	cbz	r0, 20023cc4 <HAL_LEGACY_CFG_READ+0x32>
20023c9a:	2400      	movs	r4, #0
20023c9c:	2107      	movs	r1, #7
20023c9e:	2302      	movs	r3, #2
20023ca0:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20023ca4:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023ca8:	0052      	lsls	r2, r2, #1
20023caa:	e9cd 4300 	strd	r4, r3, [sp]
20023cae:	b252      	sxtb	r2, r2
20023cb0:	4623      	mov	r3, r4
20023cb2:	f7fe fbc8 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
20023cb6:	4621      	mov	r1, r4
20023cb8:	4628      	mov	r0, r5
20023cba:	f7fe fbb9 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
20023cbe:	4620      	mov	r0, r4
20023cc0:	b005      	add	sp, #20
20023cc2:	bd30      	pop	{r4, r5, pc}
20023cc4:	2001      	movs	r0, #1
20023cc6:	e7fb      	b.n	20023cc0 <HAL_LEGACY_CFG_READ+0x2e>

20023cc8 <HAL_LEGACY_CFG_WRITE>:
20023cc8:	b530      	push	{r4, r5, lr}
20023cca:	4605      	mov	r5, r0
20023ccc:	b085      	sub	sp, #20
20023cce:	b190      	cbz	r0, 20023cf6 <HAL_LEGACY_CFG_WRITE+0x2e>
20023cd0:	2107      	movs	r1, #7
20023cd2:	2400      	movs	r4, #0
20023cd4:	2302      	movs	r3, #2
20023cd6:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023cda:	e9cd 4300 	strd	r4, r3, [sp]
20023cde:	4623      	mov	r3, r4
20023ce0:	f990 202e 	ldrsb.w	r2, [r0, #46]	@ 0x2e
20023ce4:	f7fe fbd8 	bl	20022498 <HAL_FLASH_CFG_AHB_WCMD>
20023ce8:	2180      	movs	r1, #128	@ 0x80
20023cea:	4628      	mov	r0, r5
20023cec:	f7fe fbc8 	bl	20022480 <HAL_FLASH_SET_AHB_WCMD>
20023cf0:	4620      	mov	r0, r4
20023cf2:	b005      	add	sp, #20
20023cf4:	bd30      	pop	{r4, r5, pc}
20023cf6:	2001      	movs	r0, #1
20023cf8:	e7fb      	b.n	20023cf2 <HAL_LEGACY_CFG_WRITE+0x2a>

20023cfa <HAL_PSRAM_RESET>:
20023cfa:	b5f0      	push	{r4, r5, r6, r7, lr}
20023cfc:	4604      	mov	r4, r0
20023cfe:	b087      	sub	sp, #28
20023d00:	2800      	cmp	r0, #0
20023d02:	d03b      	beq.n	20023d7c <HAL_PSRAM_RESET+0x82>
20023d04:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
20023d08:	2b05      	cmp	r3, #5
20023d0a:	d034      	beq.n	20023d76 <HAL_PSRAM_RESET+0x7c>
20023d0c:	3b03      	subs	r3, #3
20023d0e:	2b01      	cmp	r3, #1
20023d10:	d82e      	bhi.n	20023d70 <HAL_PSRAM_RESET+0x76>
20023d12:	2601      	movs	r6, #1
20023d14:	2703      	movs	r7, #3
20023d16:	2300      	movs	r3, #0
20023d18:	2507      	movs	r5, #7
20023d1a:	b276      	sxtb	r6, r6
20023d1c:	b27f      	sxtb	r7, r7
20023d1e:	461a      	mov	r2, r3
20023d20:	2101      	movs	r1, #1
20023d22:	4620      	mov	r0, r4
20023d24:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023d28:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023d2c:	9600      	str	r6, [sp, #0]
20023d2e:	f7fe fc41 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20023d32:	2200      	movs	r2, #0
20023d34:	21ff      	movs	r1, #255	@ 0xff
20023d36:	4620      	mov	r0, r4
20023d38:	f7fe fbf7 	bl	2002252a <HAL_FLASH_SET_CMD>
20023d3c:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023d40:	2b05      	cmp	r3, #5
20023d42:	d10f      	bne.n	20023d64 <HAL_PSRAM_RESET+0x6a>
20023d44:	2300      	movs	r3, #0
20023d46:	2101      	movs	r1, #1
20023d48:	461a      	mov	r2, r3
20023d4a:	4620      	mov	r0, r4
20023d4c:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023d50:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023d54:	9600      	str	r6, [sp, #0]
20023d56:	f7fe fc2d 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20023d5a:	2200      	movs	r2, #0
20023d5c:	21ff      	movs	r1, #255	@ 0xff
20023d5e:	4620      	mov	r0, r4
20023d60:	f7fe fbe3 	bl	2002252a <HAL_FLASH_SET_CMD>
20023d64:	2000      	movs	r0, #0
20023d66:	f7fd fe24 	bl	200219b2 <HAL_Delay_us>
20023d6a:	2003      	movs	r0, #3
20023d6c:	f7fd fe21 	bl	200219b2 <HAL_Delay_us>
20023d70:	2000      	movs	r0, #0
20023d72:	b007      	add	sp, #28
20023d74:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023d76:	2603      	movs	r6, #3
20023d78:	2702      	movs	r7, #2
20023d7a:	e7cc      	b.n	20023d16 <HAL_PSRAM_RESET+0x1c>
20023d7c:	2001      	movs	r0, #1
20023d7e:	e7f8      	b.n	20023d72 <HAL_PSRAM_RESET+0x78>

20023d80 <HAL_OPI_PSRAM_Init>:
20023d80:	b530      	push	{r4, r5, lr}
20023d82:	4604      	mov	r4, r0
20023d84:	b085      	sub	sp, #20
20023d86:	2800      	cmp	r0, #0
20023d88:	d076      	beq.n	20023e78 <HAL_OPI_PSRAM_Init+0xf8>
20023d8a:	2900      	cmp	r1, #0
20023d8c:	d074      	beq.n	20023e78 <HAL_OPI_PSRAM_Init+0xf8>
20023d8e:	f7fe fb2d 	bl	200223ec <HAL_QSPI_Init>
20023d92:	6823      	ldr	r3, [r4, #0]
20023d94:	2101      	movs	r1, #1
20023d96:	4620      	mov	r0, r4
20023d98:	681d      	ldr	r5, [r3, #0]
20023d9a:	f7fe fc76 	bl	2002268a <HAL_FLASH_ENABLE_OPI>
20023d9e:	2101      	movs	r1, #1
20023da0:	4620      	mov	r0, r4
20023da2:	f7fe fbfe 	bl	200225a2 <HAL_FLASH_SET_CLK_rom>
20023da6:	4620      	mov	r0, r4
20023da8:	f7ff fc14 	bl	200235d4 <HAL_QSPI_GET_CLK>
20023dac:	0840      	lsrs	r0, r0, #1
20023dae:	61a0      	str	r0, [r4, #24]
20023db0:	f10d 020e 	add.w	r2, sp, #14
20023db4:	4620      	mov	r0, r4
20023db6:	f10d 010f 	add.w	r1, sp, #15
20023dba:	f7ff fe35 	bl	20023a28 <HAL_MPI_OPSRAM_CAL_DELAY>
20023dbe:	4603      	mov	r3, r0
20023dc0:	b100      	cbz	r0, 20023dc4 <HAL_OPI_PSRAM_Init+0x44>
20023dc2:	e7fe      	b.n	20023dc2 <HAL_OPI_PSRAM_Init+0x42>
20023dc4:	69a2      	ldr	r2, [r4, #24]
20023dc6:	492d      	ldr	r1, [pc, #180]	@ (20023e7c <HAL_OPI_PSRAM_Init+0xfc>)
20023dc8:	428a      	cmp	r2, r1
20023dca:	d93b      	bls.n	20023e44 <HAL_OPI_PSRAM_Init+0xc4>
20023dcc:	4b2c      	ldr	r3, [pc, #176]	@ (20023e80 <HAL_OPI_PSRAM_Init+0x100>)
20023dce:	429a      	cmp	r2, r3
20023dd0:	d93c      	bls.n	20023e4c <HAL_OPI_PSRAM_Init+0xcc>
20023dd2:	440b      	add	r3, r1
20023dd4:	429a      	cmp	r2, r3
20023dd6:	d93f      	bls.n	20023e58 <HAL_OPI_PSRAM_Init+0xd8>
20023dd8:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023ddc:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023de0:	429a      	cmp	r2, r3
20023de2:	d93f      	bls.n	20023e64 <HAL_OPI_PSRAM_Init+0xe4>
20023de4:	2107      	movs	r1, #7
20023de6:	2014      	movs	r0, #20
20023de8:	2308      	movs	r3, #8
20023dea:	f240 5232 	movw	r2, #1330	@ 0x532
20023dee:	f884 102d 	strb.w	r1, [r4, #45]	@ 0x2d
20023df2:	f884 102e 	strb.w	r1, [r4, #46]	@ 0x2e
20023df6:	2106      	movs	r1, #6
20023df8:	9000      	str	r0, [sp, #0]
20023dfa:	4620      	mov	r0, r4
20023dfc:	f7fe fc7c 	bl	200226f8 <HAL_FLASH_SET_CS_TIME>
20023e00:	2107      	movs	r1, #7
20023e02:	4620      	mov	r0, r4
20023e04:	f7fe fc8d 	bl	20022722 <HAL_FLASH_SET_ROW_BOUNDARY>
20023e08:	2101      	movs	r1, #1
20023e0a:	4620      	mov	r0, r4
20023e0c:	f7fe fcbe 	bl	2002278c <HAL_MPI_ENABLE_DQS>
20023e10:	f89d 100e 	ldrb.w	r1, [sp, #14]
20023e14:	4620      	mov	r0, r4
20023e16:	f7fe fcbd 	bl	20022794 <HAL_MPI_SET_DQS_DELAY>
20023e1a:	2200      	movs	r2, #0
20023e1c:	f89d 100f 	ldrb.w	r1, [sp, #15]
20023e20:	4620      	mov	r0, r4
20023e22:	f7fe fcc2 	bl	200227aa <HAL_MPI_SET_SCK>
20023e26:	2101      	movs	r1, #1
20023e28:	4620      	mov	r0, r4
20023e2a:	f7fe fc20 	bl	2002266e <HAL_FLASH_ENABLE_QSPI>
20023e2e:	07eb      	lsls	r3, r5, #31
20023e30:	d405      	bmi.n	20023e3e <HAL_OPI_PSRAM_Init+0xbe>
20023e32:	4b14      	ldr	r3, [pc, #80]	@ (20023e84 <HAL_OPI_PSRAM_Init+0x104>)
20023e34:	681b      	ldr	r3, [r3, #0]
20023e36:	f003 0303 	and.w	r3, r3, #3
20023e3a:	2b03      	cmp	r3, #3
20023e3c:	d118      	bne.n	20023e70 <HAL_OPI_PSRAM_Init+0xf0>
20023e3e:	2000      	movs	r0, #0
20023e40:	b005      	add	sp, #20
20023e42:	bd30      	pop	{r4, r5, pc}
20023e44:	2103      	movs	r1, #3
20023e46:	22b4      	movs	r2, #180	@ 0xb4
20023e48:	4608      	mov	r0, r1
20023e4a:	e7d0      	b.n	20023dee <HAL_OPI_PSRAM_Init+0x6e>
20023e4c:	2105      	movs	r1, #5
20023e4e:	200e      	movs	r0, #14
20023e50:	2303      	movs	r3, #3
20023e52:	f240 32b6 	movw	r2, #950	@ 0x3b6
20023e56:	e7ca      	b.n	20023dee <HAL_OPI_PSRAM_Init+0x6e>
20023e58:	2106      	movs	r1, #6
20023e5a:	2011      	movs	r0, #17
20023e5c:	2305      	movs	r3, #5
20023e5e:	f240 4274 	movw	r2, #1140	@ 0x474
20023e62:	e7c4      	b.n	20023dee <HAL_OPI_PSRAM_Init+0x6e>
20023e64:	2106      	movs	r1, #6
20023e66:	2013      	movs	r0, #19
20023e68:	460b      	mov	r3, r1
20023e6a:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20023e6e:	e7be      	b.n	20023dee <HAL_OPI_PSRAM_Init+0x6e>
20023e70:	4620      	mov	r0, r4
20023e72:	f7ff ff42 	bl	20023cfa <HAL_PSRAM_RESET>
20023e76:	e7e2      	b.n	20023e3e <HAL_OPI_PSRAM_Init+0xbe>
20023e78:	2001      	movs	r0, #1
20023e7a:	e7e1      	b.n	20023e40 <HAL_OPI_PSRAM_Init+0xc0>
20023e7c:	016e3600 	.word	0x016e3600
20023e80:	07270e00 	.word	0x07270e00
20023e84:	500c0000 	.word	0x500c0000

20023e88 <HAL_LEGACY_PSRAM_Init>:
20023e88:	b5f0      	push	{r4, r5, r6, r7, lr}
20023e8a:	4604      	mov	r4, r0
20023e8c:	b085      	sub	sp, #20
20023e8e:	2800      	cmp	r0, #0
20023e90:	f000 809e 	beq.w	20023fd0 <HAL_LEGACY_PSRAM_Init+0x148>
20023e94:	2900      	cmp	r1, #0
20023e96:	f000 809b 	beq.w	20023fd0 <HAL_LEGACY_PSRAM_Init+0x148>
20023e9a:	f7fe faa7 	bl	200223ec <HAL_QSPI_Init>
20023e9e:	6823      	ldr	r3, [r4, #0]
20023ea0:	2101      	movs	r1, #1
20023ea2:	4620      	mov	r0, r4
20023ea4:	681e      	ldr	r6, [r3, #0]
20023ea6:	f7fe fbf0 	bl	2002268a <HAL_FLASH_ENABLE_OPI>
20023eaa:	2101      	movs	r1, #1
20023eac:	4620      	mov	r0, r4
20023eae:	f7fe fb78 	bl	200225a2 <HAL_FLASH_SET_CLK_rom>
20023eb2:	4620      	mov	r0, r4
20023eb4:	f7ff fb8e 	bl	200235d4 <HAL_QSPI_GET_CLK>
20023eb8:	0845      	lsrs	r5, r0, #1
20023eba:	61a5      	str	r5, [r4, #24]
20023ebc:	4620      	mov	r0, r4
20023ebe:	f10d 020e 	add.w	r2, sp, #14
20023ec2:	f10d 010f 	add.w	r1, sp, #15
20023ec6:	f7ff fdaf 	bl	20023a28 <HAL_MPI_OPSRAM_CAL_DELAY>
20023eca:	4603      	mov	r3, r0
20023ecc:	b100      	cbz	r0, 20023ed0 <HAL_LEGACY_PSRAM_Init+0x48>
20023ece:	e7fe      	b.n	20023ece <HAL_LEGACY_PSRAM_Init+0x46>
20023ed0:	4a40      	ldr	r2, [pc, #256]	@ (20023fd4 <HAL_LEGACY_PSRAM_Init+0x14c>)
20023ed2:	4f41      	ldr	r7, [pc, #260]	@ (20023fd8 <HAL_LEGACY_PSRAM_Init+0x150>)
20023ed4:	4295      	cmp	r5, r2
20023ed6:	d95a      	bls.n	20023f8e <HAL_LEGACY_PSRAM_Init+0x106>
20023ed8:	42bd      	cmp	r5, r7
20023eda:	d95b      	bls.n	20023f94 <HAL_LEGACY_PSRAM_Init+0x10c>
20023edc:	4b3f      	ldr	r3, [pc, #252]	@ (20023fdc <HAL_LEGACY_PSRAM_Init+0x154>)
20023ede:	429d      	cmp	r5, r3
20023ee0:	d95d      	bls.n	20023f9e <HAL_LEGACY_PSRAM_Init+0x116>
20023ee2:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023ee6:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023eea:	429d      	cmp	r5, r3
20023eec:	d95c      	bls.n	20023fa8 <HAL_LEGACY_PSRAM_Init+0x120>
20023eee:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023ef2:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023ef6:	429d      	cmp	r5, r3
20023ef8:	d85b      	bhi.n	20023fb2 <HAL_LEGACY_PSRAM_Init+0x12a>
20023efa:	2114      	movs	r1, #20
20023efc:	2308      	movs	r3, #8
20023efe:	f240 5232 	movw	r2, #1330	@ 0x532
20023f02:	9100      	str	r1, [sp, #0]
20023f04:	4620      	mov	r0, r4
20023f06:	2106      	movs	r1, #6
20023f08:	f7fe fbf6 	bl	200226f8 <HAL_FLASH_SET_CS_TIME>
20023f0c:	2107      	movs	r1, #7
20023f0e:	4620      	mov	r0, r4
20023f10:	f7fe fc07 	bl	20022722 <HAL_FLASH_SET_ROW_BOUNDARY>
20023f14:	2101      	movs	r1, #1
20023f16:	4620      	mov	r0, r4
20023f18:	f7fe fc38 	bl	2002278c <HAL_MPI_ENABLE_DQS>
20023f1c:	f89d 100e 	ldrb.w	r1, [sp, #14]
20023f20:	4620      	mov	r0, r4
20023f22:	f7fe fc37 	bl	20022794 <HAL_MPI_SET_DQS_DELAY>
20023f26:	2200      	movs	r2, #0
20023f28:	f89d 100f 	ldrb.w	r1, [sp, #15]
20023f2c:	4620      	mov	r0, r4
20023f2e:	f7fe fc3c 	bl	200227aa <HAL_MPI_SET_SCK>
20023f32:	2101      	movs	r1, #1
20023f34:	4620      	mov	r0, r4
20023f36:	f7fe fbfe 	bl	20022736 <HAL_FLASH_SET_LEGACY>
20023f3a:	2101      	movs	r1, #1
20023f3c:	4620      	mov	r0, r4
20023f3e:	f7fe fb96 	bl	2002266e <HAL_FLASH_ENABLE_QSPI>
20023f42:	07f3      	lsls	r3, r6, #31
20023f44:	d405      	bmi.n	20023f52 <HAL_LEGACY_PSRAM_Init+0xca>
20023f46:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
20023f4a:	b913      	cbnz	r3, 20023f52 <HAL_LEGACY_PSRAM_Init+0xca>
20023f4c:	4620      	mov	r0, r4
20023f4e:	f7ff fed4 	bl	20023cfa <HAL_PSRAM_RESET>
20023f52:	42bd      	cmp	r5, r7
20023f54:	d932      	bls.n	20023fbc <HAL_LEGACY_PSRAM_Init+0x134>
20023f56:	4b22      	ldr	r3, [pc, #136]	@ (20023fe0 <HAL_LEGACY_PSRAM_Init+0x158>)
20023f58:	429d      	cmp	r5, r3
20023f5a:	d934      	bls.n	20023fc6 <HAL_LEGACY_PSRAM_Init+0x13e>
20023f5c:	2206      	movs	r2, #6
20023f5e:	2302      	movs	r3, #2
20023f60:	2588      	movs	r5, #136	@ 0x88
20023f62:	263b      	movs	r6, #59	@ 0x3b
20023f64:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023f68:	2101      	movs	r1, #1
20023f6a:	f884 202d 	strb.w	r2, [r4, #45]	@ 0x2d
20023f6e:	4620      	mov	r0, r4
20023f70:	f7fe fc0a 	bl	20022788 <HAL_MPI_EN_FIXLAT>
20023f74:	4632      	mov	r2, r6
20023f76:	2100      	movs	r1, #0
20023f78:	4620      	mov	r0, r4
20023f7a:	f7ff fe65 	bl	20023c48 <HAL_LEGACY_MR_WRITE>
20023f7e:	462a      	mov	r2, r5
20023f80:	2104      	movs	r1, #4
20023f82:	4620      	mov	r0, r4
20023f84:	f7ff fe60 	bl	20023c48 <HAL_LEGACY_MR_WRITE>
20023f88:	2000      	movs	r0, #0
20023f8a:	b005      	add	sp, #20
20023f8c:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023f8e:	2103      	movs	r1, #3
20023f90:	22b4      	movs	r2, #180	@ 0xb4
20023f92:	e7b6      	b.n	20023f02 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f94:	210e      	movs	r1, #14
20023f96:	2303      	movs	r3, #3
20023f98:	f240 32b6 	movw	r2, #950	@ 0x3b6
20023f9c:	e7b1      	b.n	20023f02 <HAL_LEGACY_PSRAM_Init+0x7a>
20023f9e:	2111      	movs	r1, #17
20023fa0:	2305      	movs	r3, #5
20023fa2:	f240 4274 	movw	r2, #1140	@ 0x474
20023fa6:	e7ac      	b.n	20023f02 <HAL_LEGACY_PSRAM_Init+0x7a>
20023fa8:	2113      	movs	r1, #19
20023faa:	2306      	movs	r3, #6
20023fac:	f240 42d3 	movw	r2, #1235	@ 0x4d3
20023fb0:	e7a7      	b.n	20023f02 <HAL_LEGACY_PSRAM_Init+0x7a>
20023fb2:	2117      	movs	r1, #23
20023fb4:	2309      	movs	r3, #9
20023fb6:	f44f 62be 	mov.w	r2, #1520	@ 0x5f0
20023fba:	e7a2      	b.n	20023f02 <HAL_LEGACY_PSRAM_Init+0x7a>
20023fbc:	2204      	movs	r2, #4
20023fbe:	2300      	movs	r3, #0
20023fc0:	2508      	movs	r5, #8
20023fc2:	2633      	movs	r6, #51	@ 0x33
20023fc4:	e7ce      	b.n	20023f64 <HAL_LEGACY_PSRAM_Init+0xdc>
20023fc6:	2205      	movs	r2, #5
20023fc8:	2300      	movs	r3, #0
20023fca:	2508      	movs	r5, #8
20023fcc:	2637      	movs	r6, #55	@ 0x37
20023fce:	e7c9      	b.n	20023f64 <HAL_LEGACY_PSRAM_Init+0xdc>
20023fd0:	2001      	movs	r0, #1
20023fd2:	e7da      	b.n	20023f8a <HAL_LEGACY_PSRAM_Init+0x102>
20023fd4:	016e3600 	.word	0x016e3600
20023fd8:	07270e00 	.word	0x07270e00
20023fdc:	08954400 	.word	0x08954400
20023fe0:	094c5f00 	.word	0x094c5f00

20023fe4 <HAL_HYPER_PSRAM_WriteCR>:
20023fe4:	b570      	push	{r4, r5, r6, lr}
20023fe6:	460e      	mov	r6, r1
20023fe8:	4615      	mov	r5, r2
20023fea:	4604      	mov	r4, r0
20023fec:	b086      	sub	sp, #24
20023fee:	b1f8      	cbz	r0, 20024030 <HAL_HYPER_PSRAM_WriteCR+0x4c>
20023ff0:	2207      	movs	r2, #7
20023ff2:	2303      	movs	r3, #3
20023ff4:	e9cd 2301 	strd	r2, r3, [sp, #4]
20023ff8:	2300      	movs	r3, #0
20023ffa:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023ffe:	9300      	str	r3, [sp, #0]
20024000:	2101      	movs	r1, #1
20024002:	f7fe fad7 	bl	200225b4 <HAL_FLASH_MANUAL_CMD>
20024006:	4631      	mov	r1, r6
20024008:	4620      	mov	r0, r4
2002400a:	f7fe fa7d 	bl	20022508 <HAL_FLASH_WRITE_ABYTE>
2002400e:	2102      	movs	r1, #2
20024010:	4620      	mov	r0, r4
20024012:	f7fe fa65 	bl	200224e0 <HAL_FLASH_WRITE_DLEN>
20024016:	4629      	mov	r1, r5
20024018:	4620      	mov	r0, r4
2002401a:	f7fe fa5a 	bl	200224d2 <HAL_FLASH_WRITE_WORD>
2002401e:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20024022:	2160      	movs	r1, #96	@ 0x60
20024024:	4620      	mov	r0, r4
20024026:	b006      	add	sp, #24
20024028:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
2002402c:	f7fe ba7d 	b.w	2002252a <HAL_FLASH_SET_CMD>
20024030:	b006      	add	sp, #24
20024032:	bd70      	pop	{r4, r5, r6, pc}

20024034 <HAL_HYPER_PSRAM_Init>:
20024034:	b538      	push	{r3, r4, r5, lr}
20024036:	4605      	mov	r5, r0
20024038:	2201      	movs	r2, #1
2002403a:	f7ff fea1 	bl	20023d80 <HAL_OPI_PSRAM_Init>
2002403e:	69ac      	ldr	r4, [r5, #24]
20024040:	4b12      	ldr	r3, [pc, #72]	@ (2002408c <HAL_HYPER_PSRAM_Init+0x58>)
20024042:	429c      	cmp	r4, r3
20024044:	d91c      	bls.n	20024080 <HAL_HYPER_PSRAM_Init+0x4c>
20024046:	4b12      	ldr	r3, [pc, #72]	@ (20024090 <HAL_HYPER_PSRAM_Init+0x5c>)
20024048:	429c      	cmp	r4, r3
2002404a:	d91b      	bls.n	20024084 <HAL_HYPER_PSRAM_Init+0x50>
2002404c:	4b11      	ldr	r3, [pc, #68]	@ (20024094 <HAL_HYPER_PSRAM_Init+0x60>)
2002404e:	429c      	cmp	r4, r3
20024050:	d91a      	bls.n	20024088 <HAL_HYPER_PSRAM_Init+0x54>
20024052:	4b11      	ldr	r3, [pc, #68]	@ (20024098 <HAL_HYPER_PSRAM_Init+0x64>)
20024054:	429c      	cmp	r4, r3
20024056:	bf8c      	ite	hi
20024058:	2402      	movhi	r4, #2
2002405a:	2401      	movls	r4, #1
2002405c:	2101      	movs	r1, #1
2002405e:	4628      	mov	r0, r5
20024060:	f7fe fb21 	bl	200226a6 <HAL_FLASH_ENABLE_HYPER>
20024064:	f240 428f 	movw	r2, #1167	@ 0x48f
20024068:	4628      	mov	r0, r5
2002406a:	ea42 3204 	orr.w	r2, r2, r4, lsl #12
2002406e:	2100      	movs	r1, #0
20024070:	f7ff ffb8 	bl	20023fe4 <HAL_HYPER_PSRAM_WriteCR>
20024074:	2101      	movs	r1, #1
20024076:	4628      	mov	r0, r5
20024078:	f7fe fb86 	bl	20022788 <HAL_MPI_EN_FIXLAT>
2002407c:	2000      	movs	r0, #0
2002407e:	bd38      	pop	{r3, r4, r5, pc}
20024080:	240e      	movs	r4, #14
20024082:	e7eb      	b.n	2002405c <HAL_HYPER_PSRAM_Init+0x28>
20024084:	240f      	movs	r4, #15
20024086:	e7e9      	b.n	2002405c <HAL_HYPER_PSRAM_Init+0x28>
20024088:	2400      	movs	r4, #0
2002408a:	e7e7      	b.n	2002405c <HAL_HYPER_PSRAM_Init+0x28>
2002408c:	0510ff40 	.word	0x0510ff40
20024090:	0632ea00 	.word	0x0632ea00
20024094:	07ed6b40 	.word	0x07ed6b40
20024098:	09e4f580 	.word	0x09e4f580

2002409c <HAL_HYPER_CFG_READ>:
2002409c:	b51f      	push	{r0, r1, r2, r3, r4, lr}
2002409e:	b160      	cbz	r0, 200240ba <HAL_HYPER_CFG_READ+0x1e>
200240a0:	2107      	movs	r1, #7
200240a2:	2303      	movs	r3, #3
200240a4:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
200240a8:	e9cd 1300 	strd	r1, r3, [sp]
200240ac:	3a01      	subs	r2, #1
200240ae:	2300      	movs	r3, #0
200240b0:	e9cd 1102 	strd	r1, r1, [sp, #8]
200240b4:	b252      	sxtb	r2, r2
200240b6:	f7fe f9c6 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
200240ba:	b005      	add	sp, #20
200240bc:	f85d fb04 	ldr.w	pc, [sp], #4

200240c0 <HAL_HYPER_CFG_WRITE>:
200240c0:	b51f      	push	{r0, r1, r2, r3, r4, lr}
200240c2:	b160      	cbz	r0, 200240de <HAL_HYPER_CFG_WRITE+0x1e>
200240c4:	2107      	movs	r1, #7
200240c6:	2303      	movs	r3, #3
200240c8:	f890 202e 	ldrb.w	r2, [r0, #46]	@ 0x2e
200240cc:	e9cd 1300 	strd	r1, r3, [sp]
200240d0:	3a01      	subs	r2, #1
200240d2:	2300      	movs	r3, #0
200240d4:	e9cd 1102 	strd	r1, r1, [sp, #8]
200240d8:	b252      	sxtb	r2, r2
200240da:	f7fe f9dd 	bl	20022498 <HAL_FLASH_CFG_AHB_WCMD>
200240de:	b005      	add	sp, #20
200240e0:	f85d fb04 	ldr.w	pc, [sp], #4

200240e4 <HAL_MPI_PSRAM_Init>:
200240e4:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
200240e8:	690b      	ldr	r3, [r1, #16]
200240ea:	4604      	mov	r4, r0
200240ec:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
200240f0:	690b      	ldr	r3, [r1, #16]
200240f2:	3b03      	subs	r3, #3
200240f4:	2b03      	cmp	r3, #3
200240f6:	f200 8085 	bhi.w	20024204 <HAL_MPI_PSRAM_Init+0x120>
200240fa:	e8df f003 	tbb	[pc, r3]
200240fe:	6302      	.short	0x6302
20024100:	7958      	.short	0x7958
20024102:	4620      	mov	r0, r4
20024104:	f7ff fe3c 	bl	20023d80 <HAL_OPI_PSRAM_Init>
20024108:	2203      	movs	r2, #3
2002410a:	4606      	mov	r6, r0
2002410c:	2108      	movs	r1, #8
2002410e:	4620      	mov	r0, r4
20024110:	f7ff fd28 	bl	20023b64 <HAL_MPI_MR_WRITE>
20024114:	4620      	mov	r0, r4
20024116:	f7ff fa5d 	bl	200235d4 <HAL_QSPI_GET_CLK>
2002411a:	4b4d      	ldr	r3, [pc, #308]	@ (20024250 <HAL_MPI_PSRAM_Init+0x16c>)
2002411c:	4298      	cmp	r0, r3
2002411e:	d95f      	bls.n	200241e0 <HAL_MPI_PSRAM_Init+0xfc>
20024120:	f103 63a4 	add.w	r3, r3, #85983232	@ 0x5200000
20024124:	f503 4383 	add.w	r3, r3, #16768	@ 0x4180
20024128:	4298      	cmp	r0, r3
2002412a:	d95b      	bls.n	200241e4 <HAL_MPI_PSRAM_Init+0x100>
2002412c:	f103 7337 	add.w	r3, r3, #47972352	@ 0x2dc0000
20024130:	f503 43d8 	add.w	r3, r3, #27648	@ 0x6c00
20024134:	4298      	cmp	r0, r3
20024136:	d957      	bls.n	200241e8 <HAL_MPI_PSRAM_Init+0x104>
20024138:	4b46      	ldr	r3, [pc, #280]	@ (20024254 <HAL_MPI_PSRAM_Init+0x170>)
2002413a:	4298      	cmp	r0, r3
2002413c:	d956      	bls.n	200241ec <HAL_MPI_PSRAM_Init+0x108>
2002413e:	4b46      	ldr	r3, [pc, #280]	@ (20024258 <HAL_MPI_PSRAM_Init+0x174>)
20024140:	4298      	cmp	r0, r3
20024142:	bf94      	ite	ls
20024144:	2507      	movls	r5, #7
20024146:	2500      	movhi	r5, #0
20024148:	f04f 0800 	mov.w	r8, #0
2002414c:	2707      	movs	r7, #7
2002414e:	f04f 0a03 	mov.w	sl, #3
20024152:	ea4f 0945 	mov.w	r9, r5, lsl #1
20024156:	4643      	mov	r3, r8
20024158:	f109 32ff 	add.w	r2, r9, #4294967295
2002415c:	4639      	mov	r1, r7
2002415e:	4620      	mov	r0, r4
20024160:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024164:	e9cd 8a00 	strd	r8, sl, [sp]
20024168:	f7fe f96d 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
2002416c:	4641      	mov	r1, r8
2002416e:	4620      	mov	r0, r4
20024170:	f7fe f95e 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
20024174:	4643      	mov	r3, r8
20024176:	1e6a      	subs	r2, r5, #1
20024178:	4639      	mov	r1, r7
2002417a:	4620      	mov	r0, r4
2002417c:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024180:	e9cd 8a00 	strd	r8, sl, [sp]
20024184:	f7fe f988 	bl	20022498 <HAL_FLASH_CFG_AHB_WCMD>
20024188:	2180      	movs	r1, #128	@ 0x80
2002418a:	4620      	mov	r0, r4
2002418c:	f7fe f978 	bl	20022480 <HAL_FLASH_SET_AHB_WCMD>
20024190:	462b      	mov	r3, r5
20024192:	464a      	mov	r2, r9
20024194:	2101      	movs	r1, #1
20024196:	4620      	mov	r0, r4
20024198:	f7ff fd08 	bl	20023bac <HAL_MPI_SET_FIXLAT>
2002419c:	f64f 71ff 	movw	r1, #65535	@ 0xffff
200241a0:	4620      	mov	r0, r4
200241a2:	f7fe fb2d 	bl	20022800 <HAL_FLASH_SET_WDT>
200241a6:	4630      	mov	r0, r6
200241a8:	b004      	add	sp, #16
200241aa:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200241ae:	4620      	mov	r0, r4
200241b0:	f7ff fe6a 	bl	20023e88 <HAL_LEGACY_PSRAM_Init>
200241b4:	4620      	mov	r0, r4
200241b6:	f7ff fd6c 	bl	20023c92 <HAL_LEGACY_CFG_READ>
200241ba:	4620      	mov	r0, r4
200241bc:	f7ff fd84 	bl	20023cc8 <HAL_LEGACY_CFG_WRITE>
200241c0:	2600      	movs	r6, #0
200241c2:	e7eb      	b.n	2002419c <HAL_MPI_PSRAM_Init+0xb8>
200241c4:	4620      	mov	r0, r4
200241c6:	f7ff fddb 	bl	20023d80 <HAL_OPI_PSRAM_Init>
200241ca:	2243      	movs	r2, #67	@ 0x43
200241cc:	4606      	mov	r6, r0
200241ce:	2108      	movs	r1, #8
200241d0:	4620      	mov	r0, r4
200241d2:	f7ff fcc7 	bl	20023b64 <HAL_MPI_MR_WRITE>
200241d6:	2101      	movs	r1, #1
200241d8:	4620      	mov	r0, r4
200241da:	f7fe fac7 	bl	2002276c <HAL_FLASH_SET_X16_MODE>
200241de:	e799      	b.n	20024114 <HAL_MPI_PSRAM_Init+0x30>
200241e0:	2503      	movs	r5, #3
200241e2:	e7b1      	b.n	20024148 <HAL_MPI_PSRAM_Init+0x64>
200241e4:	2504      	movs	r5, #4
200241e6:	e7af      	b.n	20024148 <HAL_MPI_PSRAM_Init+0x64>
200241e8:	2505      	movs	r5, #5
200241ea:	e7ad      	b.n	20024148 <HAL_MPI_PSRAM_Init+0x64>
200241ec:	2506      	movs	r5, #6
200241ee:	e7ab      	b.n	20024148 <HAL_MPI_PSRAM_Init+0x64>
200241f0:	4620      	mov	r0, r4
200241f2:	f7ff ff1f 	bl	20024034 <HAL_HYPER_PSRAM_Init>
200241f6:	4620      	mov	r0, r4
200241f8:	f7ff ff50 	bl	2002409c <HAL_HYPER_CFG_READ>
200241fc:	4620      	mov	r0, r4
200241fe:	f7ff ff5f 	bl	200240c0 <HAL_HYPER_CFG_WRITE>
20024202:	e7dd      	b.n	200241c0 <HAL_MPI_PSRAM_Init+0xdc>
20024204:	2600      	movs	r6, #0
20024206:	2503      	movs	r5, #3
20024208:	f04f 0801 	mov.w	r8, #1
2002420c:	2702      	movs	r7, #2
2002420e:	4620      	mov	r0, r4
20024210:	f7ff fc52 	bl	20023ab8 <HAL_SPI_PSRAM_Init>
20024214:	4633      	mov	r3, r6
20024216:	2206      	movs	r2, #6
20024218:	4629      	mov	r1, r5
2002421a:	4620      	mov	r0, r4
2002421c:	e9cd 6700 	strd	r6, r7, [sp]
20024220:	e9cd 5802 	strd	r5, r8, [sp, #8]
20024224:	f7fe f90f 	bl	20022446 <HAL_FLASH_CFG_AHB_RCMD>
20024228:	21eb      	movs	r1, #235	@ 0xeb
2002422a:	4620      	mov	r0, r4
2002422c:	f7fe f900 	bl	20022430 <HAL_FLASH_SET_AHB_RCMD>
20024230:	4633      	mov	r3, r6
20024232:	4632      	mov	r2, r6
20024234:	4629      	mov	r1, r5
20024236:	4620      	mov	r0, r4
20024238:	e9cd 6700 	strd	r6, r7, [sp]
2002423c:	e9cd 5802 	strd	r5, r8, [sp, #8]
20024240:	f7fe f92a 	bl	20022498 <HAL_FLASH_CFG_AHB_WCMD>
20024244:	2138      	movs	r1, #56	@ 0x38
20024246:	4620      	mov	r0, r4
20024248:	f7fe f91a 	bl	20022480 <HAL_FLASH_SET_AHB_WCMD>
2002424c:	4606      	mov	r6, r0
2002424e:	e7a5      	b.n	2002419c <HAL_MPI_PSRAM_Init+0xb8>
20024250:	07de2901 	.word	0x07de2901
20024254:	13c9eb01 	.word	0x13c9eb01
20024258:	17d78401 	.word	0x17d78401

2002425c <HAL_PIN_Set2>:
2002425c:	0a03      	lsrs	r3, r0, #8
2002425e:	1e5a      	subs	r2, r3, #1
20024260:	2a53      	cmp	r2, #83	@ 0x53
20024262:	b2c0      	uxtb	r0, r0
20024264:	d80e      	bhi.n	20024284 <HAL_PIN_Set2+0x28>
20024266:	4a09      	ldr	r2, [pc, #36]	@ (2002428c <HAL_PIN_Set2+0x30>)
20024268:	009b      	lsls	r3, r3, #2
2002426a:	441a      	add	r2, r3
2002426c:	6813      	ldr	r3, [r2, #0]
2002426e:	f401 7140 	and.w	r1, r1, #768	@ 0x300
20024272:	f36f 0309 	bfc	r3, #0, #10
20024276:	430b      	orrs	r3, r1
20024278:	4303      	orrs	r3, r0
2002427a:	f443 6380 	orr.w	r3, r3, #1024	@ 0x400
2002427e:	2000      	movs	r0, #0
20024280:	6013      	str	r3, [r2, #0]
20024282:	4770      	bx	lr
20024284:	f04f 30ff 	mov.w	r0, #4294967295
20024288:	4770      	bx	lr
2002428a:	bf00      	nop
2002428c:	50002ffc 	.word	0x50002ffc

20024290 <HAL_PIN_Set>:
20024290:	3801      	subs	r0, #1
20024292:	2853      	cmp	r0, #83	@ 0x53
20024294:	b570      	push	{r4, r5, r6, lr}
20024296:	f04f 0400 	mov.w	r4, #0
2002429a:	d824      	bhi.n	200242e6 <HAL_PIN_Set+0x56>
2002429c:	0083      	lsls	r3, r0, #2
2002429e:	f1a1 0510 	sub.w	r5, r1, #16
200242a2:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
200242a6:	2dee      	cmp	r5, #238	@ 0xee
200242a8:	f503 5340 	add.w	r3, r3, #12288	@ 0x3000
200242ac:	d80c      	bhi.n	200242c8 <HAL_PIN_Set+0x38>
200242ae:	b2cc      	uxtb	r4, r1
200242b0:	2000      	movs	r0, #0
200242b2:	6819      	ldr	r1, [r3, #0]
200242b4:	f402 7240 	and.w	r2, r2, #768	@ 0x300
200242b8:	4322      	orrs	r2, r4
200242ba:	f36f 0109 	bfc	r1, #0, #10
200242be:	430a      	orrs	r2, r1
200242c0:	f442 6280 	orr.w	r2, r2, #1024	@ 0x400
200242c4:	601a      	str	r2, [r3, #0]
200242c6:	bd70      	pop	{r4, r5, r6, pc}
200242c8:	4d08      	ldr	r5, [pc, #32]	@ (200242ec <HAL_PIN_Set+0x5c>)
200242ca:	f855 0020 	ldr.w	r0, [r5, r0, lsl #2]
200242ce:	f100 0640 	add.w	r6, r0, #64	@ 0x40
200242d2:	8845      	ldrh	r5, [r0, #2]
200242d4:	b13d      	cbz	r5, 200242e6 <HAL_PIN_Set+0x56>
200242d6:	428d      	cmp	r5, r1
200242d8:	d101      	bne.n	200242de <HAL_PIN_Set+0x4e>
200242da:	7804      	ldrb	r4, [r0, #0]
200242dc:	e7e8      	b.n	200242b0 <HAL_PIN_Set+0x20>
200242de:	3004      	adds	r0, #4
200242e0:	42b0      	cmp	r0, r6
200242e2:	d1f6      	bne.n	200242d2 <HAL_PIN_Set+0x42>
200242e4:	e7e4      	b.n	200242b0 <HAL_PIN_Set+0x20>
200242e6:	f04f 30ff 	mov.w	r0, #4294967295
200242ea:	e7ec      	b.n	200242c6 <HAL_PIN_Set+0x36>
200242ec:	20026a88 	.word	0x20026a88

200242f0 <HAL_PIN_Set_DS0>:
200242f0:	2854      	cmp	r0, #84	@ 0x54
200242f2:	dc0e      	bgt.n	20024312 <HAL_PIN_Set_DS0+0x22>
200242f4:	b168      	cbz	r0, 20024312 <HAL_PIN_Set_DS0+0x22>
200242f6:	4b08      	ldr	r3, [pc, #32]	@ (20024318 <HAL_PIN_Set_DS0+0x28>)
200242f8:	0080      	lsls	r0, r0, #2
200242fa:	4403      	add	r3, r0
200242fc:	b12a      	cbz	r2, 2002430a <HAL_PIN_Set_DS0+0x1a>
200242fe:	681a      	ldr	r2, [r3, #0]
20024300:	f442 5200 	orr.w	r2, r2, #8192	@ 0x2000
20024304:	2000      	movs	r0, #0
20024306:	601a      	str	r2, [r3, #0]
20024308:	4770      	bx	lr
2002430a:	681a      	ldr	r2, [r3, #0]
2002430c:	f422 5200 	bic.w	r2, r2, #8192	@ 0x2000
20024310:	e7f8      	b.n	20024304 <HAL_PIN_Set_DS0+0x14>
20024312:	f04f 30ff 	mov.w	r0, #4294967295
20024316:	4770      	bx	lr
20024318:	50002ffc 	.word	0x50002ffc

2002431c <HAL_PIN_Set_DS1>:
2002431c:	2854      	cmp	r0, #84	@ 0x54
2002431e:	dc0e      	bgt.n	2002433e <HAL_PIN_Set_DS1+0x22>
20024320:	b168      	cbz	r0, 2002433e <HAL_PIN_Set_DS1+0x22>
20024322:	4b08      	ldr	r3, [pc, #32]	@ (20024344 <HAL_PIN_Set_DS1+0x28>)
20024324:	0080      	lsls	r0, r0, #2
20024326:	4403      	add	r3, r0
20024328:	b12a      	cbz	r2, 20024336 <HAL_PIN_Set_DS1+0x1a>
2002432a:	681a      	ldr	r2, [r3, #0]
2002432c:	f442 4280 	orr.w	r2, r2, #16384	@ 0x4000
20024330:	2000      	movs	r0, #0
20024332:	601a      	str	r2, [r3, #0]
20024334:	4770      	bx	lr
20024336:	681a      	ldr	r2, [r3, #0]
20024338:	f422 4280 	bic.w	r2, r2, #16384	@ 0x4000
2002433c:	e7f8      	b.n	20024330 <HAL_PIN_Set_DS1+0x14>
2002433e:	f04f 30ff 	mov.w	r0, #4294967295
20024342:	4770      	bx	lr
20024344:	50002ffc 	.word	0x50002ffc

20024348 <HAL_PMU_EnableDLL>:
20024348:	4b05      	ldr	r3, [pc, #20]	@ (20024360 <HAL_PMU_EnableDLL+0x18>)
2002434a:	6eda      	ldr	r2, [r3, #108]	@ 0x6c
2002434c:	b120      	cbz	r0, 20024358 <HAL_PMU_EnableDLL+0x10>
2002434e:	f042 0220 	orr.w	r2, r2, #32
20024352:	2000      	movs	r0, #0
20024354:	66da      	str	r2, [r3, #108]	@ 0x6c
20024356:	4770      	bx	lr
20024358:	f022 0220 	bic.w	r2, r2, #32
2002435c:	e7f9      	b.n	20024352 <HAL_PMU_EnableDLL+0xa>
2002435e:	bf00      	nop
20024360:	500ca000 	.word	0x500ca000

20024364 <HAL_RCC_HCPU_ConfigSxModeVolt>:
20024364:	b507      	push	{r0, r1, r2, lr}
20024366:	4a13      	ldr	r2, [pc, #76]	@ (200243b4 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
20024368:	4913      	ldr	r1, [pc, #76]	@ (200243b8 <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
2002436a:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
2002436e:	f8d1 3098 	ldr.w	r3, [r1, #152]	@ 0x98
20024372:	7892      	ldrb	r2, [r2, #2]
20024374:	2802      	cmp	r0, #2
20024376:	f362 0304 	bfi	r3, r2, #0, #5
2002437a:	f8c1 3098 	str.w	r3, [r1, #152]	@ 0x98
2002437e:	f10d 0007 	add.w	r0, sp, #7
20024382:	d111      	bne.n	200243a8 <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
20024384:	f003 fc08 	bl	20027b98 <HAL_PMU_GetHpsysVoutRef>
20024388:	b110      	cbz	r0, 20024390 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
2002438a:	230b      	movs	r3, #11
2002438c:	f88d 3007 	strb.w	r3, [sp, #7]
20024390:	4a09      	ldr	r2, [pc, #36]	@ (200243b8 <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20024392:	f89d 1007 	ldrb.w	r1, [sp, #7]
20024396:	f8d2 3090 	ldr.w	r3, [r2, #144]	@ 0x90
2002439a:	f361 0303 	bfi	r3, r1, #0, #4
2002439e:	f8c2 3090 	str.w	r3, [r2, #144]	@ 0x90
200243a2:	b003      	add	sp, #12
200243a4:	f85d fb04 	ldr.w	pc, [sp], #4
200243a8:	f003 fc02 	bl	20027bb0 <HAL_PMU_GetHpsysVoutRef2>
200243ac:	2800      	cmp	r0, #0
200243ae:	d0ef      	beq.n	20024390 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
200243b0:	230e      	movs	r3, #14
200243b2:	e7eb      	b.n	2002438c <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
200243b4:	200270ac 	.word	0x200270ac
200243b8:	500ca000 	.word	0x500ca000

200243bc <HAL_RCC_HCPU_GetClockSrc>:
200243bc:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200243c0:	2810      	cmp	r0, #16
200243c2:	6a1a      	ldr	r2, [r3, #32]
200243c4:	d80c      	bhi.n	200243e0 <HAL_RCC_HCPU_GetClockSrc+0x24>
200243c6:	4b07      	ldr	r3, [pc, #28]	@ (200243e4 <HAL_RCC_HCPU_GetClockSrc+0x28>)
200243c8:	40c3      	lsrs	r3, r0
200243ca:	f013 0f01 	tst.w	r3, #1
200243ce:	bf0c      	ite	eq
200243d0:	2301      	moveq	r3, #1
200243d2:	2303      	movne	r3, #3
200243d4:	4083      	lsls	r3, r0
200243d6:	4013      	ands	r3, r2
200243d8:	fa23 f000 	lsr.w	r0, r3, r0
200243dc:	b2c0      	uxtb	r0, r0
200243de:	4770      	bx	lr
200243e0:	2301      	movs	r3, #1
200243e2:	e7f7      	b.n	200243d4 <HAL_RCC_HCPU_GetClockSrc+0x18>
200243e4:	00012ff1 	.word	0x00012ff1

200243e8 <HAL_RCC_HCPU_GetDLLFreq>:
200243e8:	2801      	cmp	r0, #1
200243ea:	d003      	beq.n	200243f4 <HAL_RCC_HCPU_GetDLLFreq+0xc>
200243ec:	2802      	cmp	r0, #2
200243ee:	d00e      	beq.n	2002440e <HAL_RCC_HCPU_GetDLLFreq+0x26>
200243f0:	2000      	movs	r0, #0
200243f2:	4770      	bx	lr
200243f4:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200243f8:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
200243fa:	b163      	cbz	r3, 20024416 <HAL_RCC_HCPU_GetDLLFreq+0x2e>
200243fc:	f013 0001 	ands.w	r0, r3, #1
20024400:	d00a      	beq.n	20024418 <HAL_RCC_HCPU_GetDLLFreq+0x30>
20024402:	4806      	ldr	r0, [pc, #24]	@ (2002441c <HAL_RCC_HCPU_GetDLLFreq+0x34>)
20024404:	f3c3 0383 	ubfx	r3, r3, #2, #4
20024408:	fb03 0000 	mla	r0, r3, r0, r0
2002440c:	4770      	bx	lr
2002440e:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024412:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
20024414:	e7f1      	b.n	200243fa <HAL_RCC_HCPU_GetDLLFreq+0x12>
20024416:	4618      	mov	r0, r3
20024418:	4770      	bx	lr
2002441a:	bf00      	nop
2002441c:	016e3600 	.word	0x016e3600

20024420 <HAL_RCC_HCPU_GetDLL1Freq>:
20024420:	2001      	movs	r0, #1
20024422:	f7ff bfe1 	b.w	200243e8 <HAL_RCC_HCPU_GetDLLFreq>
	...

20024428 <HAL_RCC_GetSysCLKFreq.part.0>:
20024428:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002442c:	6a1b      	ldr	r3, [r3, #32]
2002442e:	f003 0303 	and.w	r3, r3, #3
20024432:	2b03      	cmp	r3, #3
20024434:	d101      	bne.n	2002443a <HAL_RCC_GetSysCLKFreq.part.0+0x12>
20024436:	f7ff bff3 	b.w	20024420 <HAL_RCC_HCPU_GetDLL1Freq>
2002443a:	4801      	ldr	r0, [pc, #4]	@ (20024440 <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
2002443c:	4770      	bx	lr
2002443e:	bf00      	nop
20024440:	02dc6c00 	.word	0x02dc6c00

20024444 <HAL_RCC_HCPU_GetDLL2Freq>:
20024444:	2002      	movs	r0, #2
20024446:	f7ff bfcf 	b.w	200243e8 <HAL_RCC_HCPU_GetDLLFreq>

2002444a <HAL_RCC_HCPU_GetDLL3Freq>:
2002444a:	2000      	movs	r0, #0
2002444c:	4770      	bx	lr
	...

20024450 <HAL_RCC_HCPU_EnableDLL>:
20024450:	4b1a      	ldr	r3, [pc, #104]	@ (200244bc <HAL_RCC_HCPU_EnableDLL+0x6c>)
20024452:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
20024456:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
2002445a:	4299      	cmp	r1, r3
2002445c:	b510      	push	{r4, lr}
2002445e:	d82a      	bhi.n	200244b6 <HAL_RCC_HCPU_EnableDLL+0x66>
20024460:	2801      	cmp	r0, #1
20024462:	d002      	beq.n	2002446a <HAL_RCC_HCPU_EnableDLL+0x1a>
20024464:	2802      	cmp	r0, #2
20024466:	d024      	beq.n	200244b2 <HAL_RCC_HCPU_EnableDLL+0x62>
20024468:	e7fe      	b.n	20024468 <HAL_RCC_HCPU_EnableDLL+0x18>
2002446a:	4c15      	ldr	r4, [pc, #84]	@ (200244c0 <HAL_RCC_HCPU_EnableDLL+0x70>)
2002446c:	4a15      	ldr	r2, [pc, #84]	@ (200244c4 <HAL_RCC_HCPU_EnableDLL+0x74>)
2002446e:	2000      	movs	r0, #0
20024470:	6c53      	ldr	r3, [r2, #68]	@ 0x44
20024472:	f043 0301 	orr.w	r3, r3, #1
20024476:	6453      	str	r3, [r2, #68]	@ 0x44
20024478:	4a13      	ldr	r2, [pc, #76]	@ (200244c8 <HAL_RCC_HCPU_EnableDLL+0x78>)
2002447a:	6823      	ldr	r3, [r4, #0]
2002447c:	fbb1 f1f2 	udiv	r1, r1, r2
20024480:	f023 0301 	bic.w	r3, r3, #1
20024484:	6023      	str	r3, [r4, #0]
20024486:	6823      	ldr	r3, [r4, #0]
20024488:	f423 4380 	bic.w	r3, r3, #16384	@ 0x4000
2002448c:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
20024490:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
20024494:	f443 5300 	orr.w	r3, r3, #8192	@ 0x2000
20024498:	f043 0301 	orr.w	r3, r3, #1
2002449c:	6023      	str	r3, [r4, #0]
2002449e:	f7fd fa88 	bl	200219b2 <HAL_Delay_us>
200244a2:	200a      	movs	r0, #10
200244a4:	f7fd fa85 	bl	200219b2 <HAL_Delay_us>
200244a8:	6823      	ldr	r3, [r4, #0]
200244aa:	2b00      	cmp	r3, #0
200244ac:	dafc      	bge.n	200244a8 <HAL_RCC_HCPU_EnableDLL+0x58>
200244ae:	2000      	movs	r0, #0
200244b0:	bd10      	pop	{r4, pc}
200244b2:	4c06      	ldr	r4, [pc, #24]	@ (200244cc <HAL_RCC_HCPU_EnableDLL+0x7c>)
200244b4:	e7da      	b.n	2002446c <HAL_RCC_HCPU_EnableDLL+0x1c>
200244b6:	2001      	movs	r0, #1
200244b8:	e7fa      	b.n	200244b0 <HAL_RCC_HCPU_EnableDLL+0x60>
200244ba:	bf00      	nop
200244bc:	15752a00 	.word	0x15752a00
200244c0:	5000002c 	.word	0x5000002c
200244c4:	5000b000 	.word	0x5000b000
200244c8:	016e3600 	.word	0x016e3600
200244cc:	50000030 	.word	0x50000030

200244d0 <HAL_RCC_HCPU_EnableDLL1>:
200244d0:	4601      	mov	r1, r0
200244d2:	2001      	movs	r0, #1
200244d4:	f7ff bfbc 	b.w	20024450 <HAL_RCC_HCPU_EnableDLL>

200244d8 <HAL_RCC_HCPU_EnableDLL2>:
200244d8:	4601      	mov	r1, r0
200244da:	2002      	movs	r0, #2
200244dc:	f7ff bfb8 	b.w	20024450 <HAL_RCC_HCPU_EnableDLL>

200244e0 <HAL_RCC_HCPU_DisableDLL1>:
200244e0:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
200244e4:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
200244e6:	2000      	movs	r0, #0
200244e8:	f023 0301 	bic.w	r3, r3, #1
200244ec:	62d3      	str	r3, [r2, #44]	@ 0x2c
200244ee:	4770      	bx	lr

200244f0 <HAL_RCC_GetSysCLKFreq>:
200244f0:	2801      	cmp	r0, #1
200244f2:	d101      	bne.n	200244f8 <HAL_RCC_GetSysCLKFreq+0x8>
200244f4:	f7ff bf98 	b.w	20024428 <HAL_RCC_GetSysCLKFreq.part.0>
200244f8:	4800      	ldr	r0, [pc, #0]	@ (200244fc <HAL_RCC_GetSysCLKFreq+0xc>)
200244fa:	4770      	bx	lr
200244fc:	02dc6c00 	.word	0x02dc6c00

20024500 <HAL_RCC_GetHCLKFreq>:
20024500:	1e02      	subs	r2, r0, #0
20024502:	bf08      	it	eq
20024504:	2201      	moveq	r2, #1
20024506:	b508      	push	{r3, lr}
20024508:	4610      	mov	r0, r2
2002450a:	f7ff fff1 	bl	200244f0 <HAL_RCC_GetSysCLKFreq>
2002450e:	2a01      	cmp	r2, #1
20024510:	d002      	beq.n	20024518 <HAL_RCC_GetHCLKFreq+0x18>
20024512:	2a02      	cmp	r2, #2
20024514:	d00a      	beq.n	2002452c <HAL_RCC_GetHCLKFreq+0x2c>
20024516:	e7fe      	b.n	20024516 <HAL_RCC_GetHCLKFreq+0x16>
20024518:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002451c:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
2002451e:	b2db      	uxtb	r3, r3
20024520:	2b01      	cmp	r3, #1
20024522:	bfb8      	it	lt
20024524:	2301      	movlt	r3, #1
20024526:	fbb0 f0f3 	udiv	r0, r0, r3
2002452a:	bd08      	pop	{r3, pc}
2002452c:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
20024530:	695b      	ldr	r3, [r3, #20]
20024532:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
20024536:	e7f3      	b.n	20024520 <HAL_RCC_GetHCLKFreq+0x20>

20024538 <HAL_RCC_HCPU_ClockSelect>:
20024538:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002453c:	b510      	push	{r4, lr}
2002453e:	2810      	cmp	r0, #16
20024540:	6a1b      	ldr	r3, [r3, #32]
20024542:	d817      	bhi.n	20024574 <HAL_RCC_HCPU_ClockSelect+0x3c>
20024544:	4a0c      	ldr	r2, [pc, #48]	@ (20024578 <HAL_RCC_HCPU_ClockSelect+0x40>)
20024546:	40c2      	lsrs	r2, r0
20024548:	f012 0f01 	tst.w	r2, #1
2002454c:	bf0c      	ite	eq
2002454e:	2201      	moveq	r2, #1
20024550:	2203      	movne	r2, #3
20024552:	fa02 f400 	lsl.w	r4, r2, r0
20024556:	4011      	ands	r1, r2
20024558:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
2002455c:	ea23 0304 	bic.w	r3, r3, r4
20024560:	4081      	lsls	r1, r0
20024562:	430b      	orrs	r3, r1
20024564:	6213      	str	r3, [r2, #32]
20024566:	b920      	cbnz	r0, 20024572 <HAL_RCC_HCPU_ClockSelect+0x3a>
20024568:	2001      	movs	r0, #1
2002456a:	f7ff ffc9 	bl	20024500 <HAL_RCC_GetHCLKFreq>
2002456e:	4b03      	ldr	r3, [pc, #12]	@ (2002457c <HAL_RCC_HCPU_ClockSelect+0x44>)
20024570:	6018      	str	r0, [r3, #0]
20024572:	bd10      	pop	{r4, pc}
20024574:	2201      	movs	r2, #1
20024576:	e7ec      	b.n	20024552 <HAL_RCC_HCPU_ClockSelect+0x1a>
20024578:	00012ff1 	.word	0x00012ff1
2002457c:	20042c14 	.word	0x20042c14

20024580 <HAL_RCC_HCPU_SetDiv>:
20024580:	2800      	cmp	r0, #0
20024582:	bfd8      	it	le
20024584:	2000      	movle	r0, #0
20024586:	b508      	push	{r3, lr}
20024588:	bfcc      	ite	gt
2002458a:	23ff      	movgt	r3, #255	@ 0xff
2002458c:	4603      	movle	r3, r0
2002458e:	2900      	cmp	r1, #0
20024590:	db12      	blt.n	200245b8 <HAL_RCC_HCPU_SetDiv+0x38>
20024592:	2a00      	cmp	r2, #0
20024594:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
20024598:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
2002459c:	da0e      	bge.n	200245bc <HAL_RCC_HCPU_SetDiv+0x3c>
2002459e:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
200245a2:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
200245a4:	ea22 0303 	bic.w	r3, r2, r3
200245a8:	4303      	orrs	r3, r0
200245aa:	624b      	str	r3, [r1, #36]	@ 0x24
200245ac:	2001      	movs	r0, #1
200245ae:	f7ff ffa7 	bl	20024500 <HAL_RCC_GetHCLKFreq>
200245b2:	4b07      	ldr	r3, [pc, #28]	@ (200245d0 <HAL_RCC_HCPU_SetDiv+0x50>)
200245b4:	6018      	str	r0, [r3, #0]
200245b6:	bd08      	pop	{r3, pc}
200245b8:	2a00      	cmp	r2, #0
200245ba:	db04      	blt.n	200245c6 <HAL_RCC_HCPU_SetDiv+0x46>
200245bc:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
200245c0:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
200245c4:	e7eb      	b.n	2002459e <HAL_RCC_HCPU_SetDiv+0x1e>
200245c6:	2b00      	cmp	r3, #0
200245c8:	d0f0      	beq.n	200245ac <HAL_RCC_HCPU_SetDiv+0x2c>
200245ca:	23ff      	movs	r3, #255	@ 0xff
200245cc:	e7e7      	b.n	2002459e <HAL_RCC_HCPU_SetDiv+0x1e>
200245ce:	bf00      	nop
200245d0:	20042c14 	.word	0x20042c14

200245d4 <HAL_RCC_HCPU_SwitchDvfsD2S>:
200245d4:	b570      	push	{r4, r5, r6, lr}
200245d6:	460c      	mov	r4, r1
200245d8:	4d19      	ldr	r5, [pc, #100]	@ (20024640 <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
200245da:	4606      	mov	r6, r0
200245dc:	f7ff fec2 	bl	20024364 <HAL_RCC_HCPU_ConfigSxModeVolt>
200245e0:	692b      	ldr	r3, [r5, #16]
200245e2:	20fa      	movs	r0, #250	@ 0xfa
200245e4:	f023 0301 	bic.w	r3, r3, #1
200245e8:	612b      	str	r3, [r5, #16]
200245ea:	f7fd f9e2 	bl	200219b2 <HAL_Delay_us>
200245ee:	2c30      	cmp	r4, #48	@ 0x30
200245f0:	d80d      	bhi.n	2002460e <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
200245f2:	2100      	movs	r1, #0
200245f4:	4608      	mov	r0, r1
200245f6:	f7ff ff9f 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
200245fa:	2030      	movs	r0, #48	@ 0x30
200245fc:	2204      	movs	r2, #4
200245fe:	2100      	movs	r1, #0
20024600:	fbb0 f0f4 	udiv	r0, r0, r4
20024604:	f7ff ffbc 	bl	20024580 <HAL_RCC_HCPU_SetDiv>
20024608:	2400      	movs	r4, #0
2002460a:	4620      	mov	r0, r4
2002460c:	bd70      	pop	{r4, r5, r6, pc}
2002460e:	f7fd fed9 	bl	200223c4 <HAL_HPAON_EnableXT48>
20024612:	480c      	ldr	r0, [pc, #48]	@ (20024644 <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
20024614:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
20024618:	6843      	ldr	r3, [r0, #4]
2002461a:	480b      	ldr	r0, [pc, #44]	@ (20024648 <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
2002461c:	61eb      	str	r3, [r5, #28]
2002461e:	4360      	muls	r0, r4
20024620:	f7ff ff56 	bl	200244d0 <HAL_RCC_HCPU_EnableDLL1>
20024624:	4604      	mov	r4, r0
20024626:	2800      	cmp	r0, #0
20024628:	d1ef      	bne.n	2002460a <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
2002462a:	2101      	movs	r1, #1
2002462c:	2206      	movs	r2, #6
2002462e:	4608      	mov	r0, r1
20024630:	f7ff ffa6 	bl	20024580 <HAL_RCC_HCPU_SetDiv>
20024634:	2103      	movs	r1, #3
20024636:	4620      	mov	r0, r4
20024638:	f7ff ff7e 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
2002463c:	e7e4      	b.n	20024608 <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
2002463e:	bf00      	nop
20024640:	5000b000 	.word	0x5000b000
20024644:	200270ac 	.word	0x200270ac
20024648:	000f4240 	.word	0x000f4240

2002464c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
2002464c:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20024650:	4c1d      	ldr	r4, [pc, #116]	@ (200246c8 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
20024652:	4f1e      	ldr	r7, [pc, #120]	@ (200246cc <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
20024654:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
20024658:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
2002465a:	7892      	ldrb	r2, [r2, #2]
2002465c:	4605      	mov	r5, r0
2002465e:	f362 4396 	bfi	r3, r2, #18, #5
20024662:	ea4f 08c0 	mov.w	r8, r0, lsl #3
20024666:	633b      	str	r3, [r7, #48]	@ 0x30
20024668:	f10d 0007 	add.w	r0, sp, #7
2002466c:	460e      	mov	r6, r1
2002466e:	f003 fa93 	bl	20027b98 <HAL_PMU_GetHpsysVoutRef>
20024672:	b110      	cbz	r0, 2002467a <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
20024674:	230b      	movs	r3, #11
20024676:	f88d 3007 	strb.w	r3, [sp, #7]
2002467a:	f89d 1007 	ldrb.w	r1, [sp, #7]
2002467e:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
20024682:	6d3b      	ldr	r3, [r7, #80]	@ 0x50
20024684:	440a      	add	r2, r1
20024686:	2100      	movs	r1, #0
20024688:	f362 0385 	bfi	r3, r2, #2, #4
2002468c:	4608      	mov	r0, r1
2002468e:	653b      	str	r3, [r7, #80]	@ 0x50
20024690:	f7ff ff52 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20024694:	2e30      	cmp	r6, #48	@ 0x30
20024696:	d900      	bls.n	2002469a <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
20024698:	e7fe      	b.n	20024698 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
2002469a:	2030      	movs	r0, #48	@ 0x30
2002469c:	2204      	movs	r2, #4
2002469e:	2100      	movs	r1, #0
200246a0:	fbb0 f0f6 	udiv	r0, r0, r6
200246a4:	f7ff ff6c 	bl	20024580 <HAL_RCC_HCPU_SetDiv>
200246a8:	f7ff ff1a 	bl	200244e0 <HAL_RCC_HCPU_DisableDLL1>
200246ac:	f7fd fe96 	bl	200223dc <HAL_HPAON_DisableXT48>
200246b0:	4444      	add	r4, r8
200246b2:	4b07      	ldr	r3, [pc, #28]	@ (200246d0 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
200246b4:	6862      	ldr	r2, [r4, #4]
200246b6:	61da      	str	r2, [r3, #28]
200246b8:	691a      	ldr	r2, [r3, #16]
200246ba:	f042 0201 	orr.w	r2, r2, #1
200246be:	611a      	str	r2, [r3, #16]
200246c0:	b002      	add	sp, #8
200246c2:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200246c6:	bf00      	nop
200246c8:	200270ac 	.word	0x200270ac
200246cc:	500ca000 	.word	0x500ca000
200246d0:	5000b000 	.word	0x5000b000

200246d4 <HAL_RCC_HCPU_ConfigDvfs>:
200246d4:	b570      	push	{r4, r5, r6, lr}
200246d6:	4e31      	ldr	r6, [pc, #196]	@ (2002479c <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
200246d8:	4605      	mov	r5, r0
200246da:	7833      	ldrb	r3, [r6, #0]
200246dc:	460c      	mov	r4, r1
200246de:	2b01      	cmp	r3, #1
200246e0:	d943      	bls.n	2002476a <HAL_RCC_HCPU_ConfigDvfs+0x96>
200246e2:	3b02      	subs	r3, #2
200246e4:	2b01      	cmp	r3, #1
200246e6:	d902      	bls.n	200246ee <HAL_RCC_HCPU_ConfigDvfs+0x1a>
200246e8:	2501      	movs	r5, #1
200246ea:	4628      	mov	r0, r5
200246ec:	bd70      	pop	{r4, r5, r6, pc}
200246ee:	4b2c      	ldr	r3, [pc, #176]	@ (200247a0 <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
200246f0:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
200246f4:	f7ff fea6 	bl	20024444 <HAL_RCC_HCPU_GetDLL2Freq>
200246f8:	4290      	cmp	r0, r2
200246fa:	d8f5      	bhi.n	200246e8 <HAL_RCC_HCPU_ConfigDvfs+0x14>
200246fc:	2901      	cmp	r1, #1
200246fe:	d805      	bhi.n	2002470c <HAL_RCC_HCPU_ConfigDvfs+0x38>
20024700:	4629      	mov	r1, r5
20024702:	4620      	mov	r0, r4
20024704:	f7ff ffa2 	bl	2002464c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
20024708:	2500      	movs	r5, #0
2002470a:	e035      	b.n	20024778 <HAL_RCC_HCPU_ConfigDvfs+0xa4>
2002470c:	2100      	movs	r1, #0
2002470e:	4608      	mov	r0, r1
20024710:	f7ff ff12 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20024714:	4620      	mov	r0, r4
20024716:	f7ff fe25 	bl	20024364 <HAL_RCC_HCPU_ConfigSxModeVolt>
2002471a:	20fa      	movs	r0, #250	@ 0xfa
2002471c:	f7fd f949 	bl	200219b2 <HAL_Delay_us>
20024720:	f7ff fede 	bl	200244e0 <HAL_RCC_HCPU_DisableDLL1>
20024724:	2d30      	cmp	r5, #48	@ 0x30
20024726:	d80d      	bhi.n	20024744 <HAL_RCC_HCPU_ConfigDvfs+0x70>
20024728:	f7fd fe58 	bl	200223dc <HAL_HPAON_DisableXT48>
2002472c:	2100      	movs	r1, #0
2002472e:	4608      	mov	r0, r1
20024730:	f7ff ff02 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20024734:	2204      	movs	r2, #4
20024736:	2100      	movs	r1, #0
20024738:	2030      	movs	r0, #48	@ 0x30
2002473a:	fbb0 f0f5 	udiv	r0, r0, r5
2002473e:	f7ff ff1f 	bl	20024580 <HAL_RCC_HCPU_SetDiv>
20024742:	e7e1      	b.n	20024708 <HAL_RCC_HCPU_ConfigDvfs+0x34>
20024744:	f7fd fe3e 	bl	200223c4 <HAL_HPAON_EnableXT48>
20024748:	4816      	ldr	r0, [pc, #88]	@ (200247a4 <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
2002474a:	4368      	muls	r0, r5
2002474c:	f7ff fec0 	bl	200244d0 <HAL_RCC_HCPU_EnableDLL1>
20024750:	4605      	mov	r5, r0
20024752:	2800      	cmp	r0, #0
20024754:	d1c8      	bne.n	200246e8 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20024756:	2101      	movs	r1, #1
20024758:	2206      	movs	r2, #6
2002475a:	4608      	mov	r0, r1
2002475c:	f7ff ff10 	bl	20024580 <HAL_RCC_HCPU_SetDiv>
20024760:	2103      	movs	r1, #3
20024762:	4628      	mov	r0, r5
20024764:	f7ff fee8 	bl	20024538 <HAL_RCC_HCPU_ClockSelect>
20024768:	e7ce      	b.n	20024708 <HAL_RCC_HCPU_ConfigDvfs+0x34>
2002476a:	2901      	cmp	r1, #1
2002476c:	d909      	bls.n	20024782 <HAL_RCC_HCPU_ConfigDvfs+0xae>
2002476e:	4601      	mov	r1, r0
20024770:	4620      	mov	r0, r4
20024772:	f7ff ff2f 	bl	200245d4 <HAL_RCC_HCPU_SwitchDvfsD2S>
20024776:	4605      	mov	r5, r0
20024778:	2000      	movs	r0, #0
2002477a:	7034      	strb	r4, [r6, #0]
2002477c:	f7fd f919 	bl	200219b2 <HAL_Delay_us>
20024780:	e7b3      	b.n	200246ea <HAL_RCC_HCPU_ConfigDvfs+0x16>
20024782:	428b      	cmp	r3, r1
20024784:	d103      	bne.n	2002478e <HAL_RCC_HCPU_ConfigDvfs+0xba>
20024786:	f04f 32ff 	mov.w	r2, #4294967295
2002478a:	4611      	mov	r1, r2
2002478c:	e7d4      	b.n	20024738 <HAL_RCC_HCPU_ConfigDvfs+0x64>
2002478e:	2190      	movs	r1, #144	@ 0x90
20024790:	2002      	movs	r0, #2
20024792:	f7ff ff1f 	bl	200245d4 <HAL_RCC_HCPU_SwitchDvfsD2S>
20024796:	2800      	cmp	r0, #0
20024798:	d1a6      	bne.n	200246e8 <HAL_RCC_HCPU_ConfigDvfs+0x14>
2002479a:	e7b1      	b.n	20024700 <HAL_RCC_HCPU_ConfigDvfs+0x2c>
2002479c:	20042c18 	.word	0x20042c18
200247a0:	2002709c 	.word	0x2002709c
200247a4:	000f4240 	.word	0x000f4240

200247a8 <HAL_RCC_EnableModule>:
200247a8:	1c43      	adds	r3, r0, #1
200247aa:	d014      	beq.n	200247d6 <HAL_RCC_EnableModule+0x2e>
200247ac:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
200247b0:	b282      	uxth	r2, r0
200247b2:	d000      	beq.n	200247b6 <HAL_RCC_EnableModule+0xe>
200247b4:	e7fe      	b.n	200247b4 <HAL_RCC_EnableModule+0xc>
200247b6:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
200247ba:	f3c0 2181 	ubfx	r1, r0, #10, #2
200247be:	f3c0 2301 	ubfx	r3, r0, #8, #2
200247c2:	b2d2      	uxtb	r2, r2
200247c4:	d108      	bne.n	200247d8 <HAL_RCC_EnableModule+0x30>
200247c6:	009b      	lsls	r3, r3, #2
200247c8:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
200247cc:	3310      	adds	r3, #16
200247ce:	2101      	movs	r1, #1
200247d0:	fa01 f202 	lsl.w	r2, r1, r2
200247d4:	601a      	str	r2, [r3, #0]
200247d6:	4770      	bx	lr
200247d8:	2901      	cmp	r1, #1
200247da:	d104      	bne.n	200247e6 <HAL_RCC_EnableModule+0x3e>
200247dc:	009b      	lsls	r3, r3, #2
200247de:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
200247e2:	3308      	adds	r3, #8
200247e4:	e7f3      	b.n	200247ce <HAL_RCC_EnableModule+0x26>
200247e6:	2902      	cmp	r1, #2
200247e8:	d108      	bne.n	200247fc <HAL_RCC_EnableModule+0x54>
200247ea:	2301      	movs	r3, #1
200247ec:	4904      	ldr	r1, [pc, #16]	@ (20024800 <HAL_RCC_EnableModule+0x58>)
200247ee:	4093      	lsls	r3, r2
200247f0:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
200247f4:	4303      	orrs	r3, r0
200247f6:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
200247fa:	4770      	bx	lr
200247fc:	e7fe      	b.n	200247fc <HAL_RCC_EnableModule+0x54>
200247fe:	bf00      	nop
20024800:	50002000 	.word	0x50002000

20024804 <HAL_RCC_HCPU_ConfigHCLK>:
20024804:	28f0      	cmp	r0, #240	@ 0xf0
20024806:	d80d      	bhi.n	20024824 <HAL_RCC_HCPU_ConfigHCLK+0x20>
20024808:	2890      	cmp	r0, #144	@ 0x90
2002480a:	d807      	bhi.n	2002481c <HAL_RCC_HCPU_ConfigHCLK+0x18>
2002480c:	2830      	cmp	r0, #48	@ 0x30
2002480e:	d807      	bhi.n	20024820 <HAL_RCC_HCPU_ConfigHCLK+0x1c>
20024810:	2818      	cmp	r0, #24
20024812:	bf94      	ite	ls
20024814:	2100      	movls	r1, #0
20024816:	2101      	movhi	r1, #1
20024818:	f7ff bf5c 	b.w	200246d4 <HAL_RCC_HCPU_ConfigDvfs>
2002481c:	2103      	movs	r1, #3
2002481e:	e7fb      	b.n	20024818 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024820:	2102      	movs	r1, #2
20024822:	e7f9      	b.n	20024818 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024824:	2001      	movs	r0, #1
20024826:	4770      	bx	lr

20024828 <spi_nor_get_ext_cfg_by_id>:
20024828:	2000      	movs	r0, #0
2002482a:	4770      	bx	lr

2002482c <spi_nor_get_user_flash_cfg>:
2002482c:	2000      	movs	r0, #0
2002482e:	4770      	bx	lr

20024830 <spi_flash_get_rdid>:
20024830:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024832:	4604      	mov	r4, r0
20024834:	3801      	subs	r0, #1
20024836:	b2c0      	uxtb	r0, r0
20024838:	28fd      	cmp	r0, #253	@ 0xfd
2002483a:	d816      	bhi.n	2002486a <spi_flash_get_rdid+0x3a>
2002483c:	2500      	movs	r5, #0
2002483e:	4e0d      	ldr	r6, [pc, #52]	@ (20024874 <spi_flash_get_rdid+0x44>)
20024840:	f856 0b04 	ldr.w	r0, [r6], #4
20024844:	7807      	ldrb	r7, [r0, #0]
20024846:	b937      	cbnz	r7, 20024856 <spi_flash_get_rdid+0x26>
20024848:	3501      	adds	r5, #1
2002484a:	2d06      	cmp	r5, #6
2002484c:	d1f8      	bne.n	20024840 <spi_flash_get_rdid+0x10>
2002484e:	4620      	mov	r0, r4
20024850:	f7ff ffec 	bl	2002482c <spi_nor_get_user_flash_cfg>
20024854:	e00d      	b.n	20024872 <spi_flash_get_rdid+0x42>
20024856:	42a7      	cmp	r7, r4
20024858:	d105      	bne.n	20024866 <spi_flash_get_rdid+0x36>
2002485a:	7847      	ldrb	r7, [r0, #1]
2002485c:	4297      	cmp	r7, r2
2002485e:	d102      	bne.n	20024866 <spi_flash_get_rdid+0x36>
20024860:	7887      	ldrb	r7, [r0, #2]
20024862:	428f      	cmp	r7, r1
20024864:	d003      	beq.n	2002486e <spi_flash_get_rdid+0x3e>
20024866:	3008      	adds	r0, #8
20024868:	e7ec      	b.n	20024844 <spi_flash_get_rdid+0x14>
2002486a:	2000      	movs	r0, #0
2002486c:	e001      	b.n	20024872 <spi_flash_get_rdid+0x42>
2002486e:	b103      	cbz	r3, 20024872 <spi_flash_get_rdid+0x42>
20024870:	701d      	strb	r5, [r3, #0]
20024872:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024874:	20042c1c 	.word	0x20042c1c

20024878 <spi_flash_get_cmd_by_id>:
20024878:	b507      	push	{r0, r1, r2, lr}
2002487a:	f10d 0307 	add.w	r3, sp, #7
2002487e:	f7ff ffd7 	bl	20024830 <spi_flash_get_rdid>
20024882:	4b06      	ldr	r3, [pc, #24]	@ (2002489c <spi_flash_get_cmd_by_id+0x24>)
20024884:	b140      	cbz	r0, 20024898 <spi_flash_get_cmd_by_id+0x20>
20024886:	f44f 7105 	mov.w	r1, #532	@ 0x214
2002488a:	f89d 2007 	ldrb.w	r2, [sp, #7]
2002488e:	fb01 3002 	mla	r0, r1, r2, r3
20024892:	b003      	add	sp, #12
20024894:	f85d fb04 	ldr.w	pc, [sp], #4
20024898:	4618      	mov	r0, r3
2002489a:	e7fa      	b.n	20024892 <spi_flash_get_cmd_by_id+0x1a>
2002489c:	20042e64 	.word	0x20042e64

200248a0 <spi_flash_get_size_by_id>:
200248a0:	b508      	push	{r3, lr}
200248a2:	2300      	movs	r3, #0
200248a4:	f7ff ffc4 	bl	20024830 <spi_flash_get_rdid>
200248a8:	b108      	cbz	r0, 200248ae <spi_flash_get_size_by_id+0xe>
200248aa:	6840      	ldr	r0, [r0, #4]
200248ac:	bd08      	pop	{r3, pc}
200248ae:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
200248b2:	e7fb      	b.n	200248ac <spi_flash_get_size_by_id+0xc>

200248b4 <spi_flash_is_support_dtr>:
200248b4:	b508      	push	{r3, lr}
200248b6:	2300      	movs	r3, #0
200248b8:	f7ff ffba 	bl	20024830 <spi_flash_get_rdid>
200248bc:	b110      	cbz	r0, 200248c4 <spi_flash_is_support_dtr+0x10>
200248be:	78c0      	ldrb	r0, [r0, #3]
200248c0:	f000 0001 	and.w	r0, r0, #1
200248c4:	bd08      	pop	{r3, pc}
	...

200248c8 <spi_flash_get_otp_base>:
200248c8:	b508      	push	{r3, lr}
200248ca:	2300      	movs	r3, #0
200248cc:	f7ff ffb0 	bl	20024830 <spi_flash_get_rdid>
200248d0:	b130      	cbz	r0, 200248e0 <spi_flash_get_otp_base+0x18>
200248d2:	78c3      	ldrb	r3, [r0, #3]
200248d4:	4803      	ldr	r0, [pc, #12]	@ (200248e4 <spi_flash_get_otp_base+0x1c>)
200248d6:	f003 0306 	and.w	r3, r3, #6
200248da:	2b02      	cmp	r3, #2
200248dc:	bf18      	it	ne
200248de:	2000      	movne	r0, #0
200248e0:	bd08      	pop	{r3, pc}
200248e2:	bf00      	nop
200248e4:	00ffc000 	.word	0x00ffc000

200248e8 <spi_nand_get_user_flash_cfg>:
200248e8:	2000      	movs	r0, #0
200248ea:	4770      	bx	lr

200248ec <spi_nand_get_rdid>:
200248ec:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200248ee:	4604      	mov	r4, r0
200248f0:	3801      	subs	r0, #1
200248f2:	b2c0      	uxtb	r0, r0
200248f4:	28fd      	cmp	r0, #253	@ 0xfd
200248f6:	d816      	bhi.n	20024926 <spi_nand_get_rdid+0x3a>
200248f8:	2500      	movs	r5, #0
200248fa:	4e0d      	ldr	r6, [pc, #52]	@ (20024930 <spi_nand_get_rdid+0x44>)
200248fc:	f856 0b04 	ldr.w	r0, [r6], #4
20024900:	7807      	ldrb	r7, [r0, #0]
20024902:	b937      	cbnz	r7, 20024912 <spi_nand_get_rdid+0x26>
20024904:	3501      	adds	r5, #1
20024906:	2d06      	cmp	r5, #6
20024908:	d1f8      	bne.n	200248fc <spi_nand_get_rdid+0x10>
2002490a:	4620      	mov	r0, r4
2002490c:	f7ff ffec 	bl	200248e8 <spi_nand_get_user_flash_cfg>
20024910:	e00d      	b.n	2002492e <spi_nand_get_rdid+0x42>
20024912:	42a7      	cmp	r7, r4
20024914:	d105      	bne.n	20024922 <spi_nand_get_rdid+0x36>
20024916:	7847      	ldrb	r7, [r0, #1]
20024918:	4297      	cmp	r7, r2
2002491a:	d102      	bne.n	20024922 <spi_nand_get_rdid+0x36>
2002491c:	7887      	ldrb	r7, [r0, #2]
2002491e:	428f      	cmp	r7, r1
20024920:	d003      	beq.n	2002492a <spi_nand_get_rdid+0x3e>
20024922:	3008      	adds	r0, #8
20024924:	e7ec      	b.n	20024900 <spi_nand_get_rdid+0x14>
20024926:	2000      	movs	r0, #0
20024928:	e001      	b.n	2002492e <spi_nand_get_rdid+0x42>
2002492a:	b103      	cbz	r3, 2002492e <spi_nand_get_rdid+0x42>
2002492c:	701d      	strb	r5, [r3, #0]
2002492e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024930:	20043adc 	.word	0x20043adc

20024934 <spi_nand_get_cmd_by_id>:
20024934:	b507      	push	{r0, r1, r2, lr}
20024936:	f10d 0307 	add.w	r3, sp, #7
2002493a:	f7ff ffd7 	bl	200248ec <spi_nand_get_rdid>
2002493e:	b130      	cbz	r0, 2002494e <spi_nand_get_cmd_by_id+0x1a>
20024940:	f44f 7205 	mov.w	r2, #532	@ 0x214
20024944:	f89d 3007 	ldrb.w	r3, [sp, #7]
20024948:	4802      	ldr	r0, [pc, #8]	@ (20024954 <spi_nand_get_cmd_by_id+0x20>)
2002494a:	fb02 0003 	mla	r0, r2, r3, r0
2002494e:	b003      	add	sp, #12
20024950:	f85d fb04 	ldr.w	pc, [sp], #4
20024954:	20043d24 	.word	0x20043d24

20024958 <spi_nand_get_ext_cfg_by_id>:
20024958:	2000      	movs	r0, #0
2002495a:	4770      	bx	lr

2002495c <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
2002495c:	f04f 30ff 	mov.w	r0, #4294967295
20024960:	4770      	bx	lr
	...

20024964 <spi_nand_get_default_ctable>:
20024964:	b508      	push	{r3, lr}
20024966:	f7ff fff9 	bl	2002495c <HAL_GET_NAND_FLASH_DEFAUT_IDX>
2002496a:	1e03      	subs	r3, r0, #0
2002496c:	bfa5      	ittet	ge
2002496e:	f44f 7205 	movge.w	r2, #532	@ 0x214
20024972:	4802      	ldrge	r0, [pc, #8]	@ (2002497c <spi_nand_get_default_ctable+0x18>)
20024974:	2000      	movlt	r0, #0
20024976:	fb02 0003 	mlage	r0, r2, r3, r0
2002497a:	bd08      	pop	{r3, pc}
2002497c:	20043d24 	.word	0x20043d24

20024980 <spi_nand_get_size_by_id>:
20024980:	b508      	push	{r3, lr}
20024982:	2300      	movs	r3, #0
20024984:	f7ff ffb2 	bl	200248ec <spi_nand_get_rdid>
20024988:	b108      	cbz	r0, 2002498e <spi_nand_get_size_by_id+0xe>
2002498a:	6840      	ldr	r0, [r0, #4]
2002498c:	bd08      	pop	{r3, pc}
2002498e:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20024992:	e7fb      	b.n	2002498c <spi_nand_get_size_by_id+0xc>

20024994 <spi_nand_get_plane_select_flag>:
20024994:	b508      	push	{r3, lr}
20024996:	2300      	movs	r3, #0
20024998:	f7ff ffa8 	bl	200248ec <spi_nand_get_rdid>
2002499c:	b110      	cbz	r0, 200249a4 <spi_nand_get_plane_select_flag+0x10>
2002499e:	78c0      	ldrb	r0, [r0, #3]
200249a0:	f3c0 0040 	ubfx	r0, r0, #1, #1
200249a4:	bd08      	pop	{r3, pc}

200249a6 <spi_nand_get_big_page_flag>:
200249a6:	b508      	push	{r3, lr}
200249a8:	2300      	movs	r3, #0
200249aa:	f7ff ff9f 	bl	200248ec <spi_nand_get_rdid>
200249ae:	b110      	cbz	r0, 200249b6 <spi_nand_get_big_page_flag+0x10>
200249b0:	78c0      	ldrb	r0, [r0, #3]
200249b2:	f3c0 0081 	ubfx	r0, r0, #2, #2
200249b6:	bd08      	pop	{r3, pc}

200249b8 <spi_nand_get_ecc_mode>:
200249b8:	b508      	push	{r3, lr}
200249ba:	2300      	movs	r3, #0
200249bc:	f7ff ff96 	bl	200248ec <spi_nand_get_rdid>
200249c0:	b108      	cbz	r0, 200249c6 <spi_nand_get_ecc_mode+0xe>
200249c2:	78c0      	ldrb	r0, [r0, #3]
200249c4:	0900      	lsrs	r0, r0, #4
200249c6:	bd08      	pop	{r3, pc}

200249c8 <bbm_map_check.part.0>:
200249c8:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
200249ca:	4b21      	ldr	r3, [pc, #132]	@ (20024a50 <bbm_map_check.part.0+0x88>)
200249cc:	4606      	mov	r6, r0
200249ce:	681d      	ldr	r5, [r3, #0]
200249d0:	4b20      	ldr	r3, [pc, #128]	@ (20024a54 <bbm_map_check.part.0+0x8c>)
200249d2:	3d04      	subs	r5, #4
200249d4:	681f      	ldr	r7, [r3, #0]
200249d6:	2300      	movs	r3, #0
200249d8:	f100 0e1a 	add.w	lr, r0, #26
200249dc:	42ab      	cmp	r3, r5
200249de:	db02      	blt.n	200249e6 <bbm_map_check.part.0+0x1e>
200249e0:	2000      	movs	r0, #0
200249e2:	b003      	add	sp, #12
200249e4:	bdf0      	pop	{r4, r5, r6, r7, pc}
200249e6:	8b31      	ldrh	r1, [r6, #24]
200249e8:	b321      	cbz	r1, 20024a34 <bbm_map_check.part.0+0x6c>
200249ea:	8b72      	ldrh	r2, [r6, #26]
200249ec:	b33a      	cbz	r2, 20024a3e <bbm_map_check.part.0+0x76>
200249ee:	42b9      	cmp	r1, r7
200249f0:	d201      	bcs.n	200249f6 <bbm_map_check.part.0+0x2e>
200249f2:	4297      	cmp	r7, r2
200249f4:	d905      	bls.n	20024a02 <bbm_map_check.part.0+0x3a>
200249f6:	4b18      	ldr	r3, [pc, #96]	@ (20024a58 <bbm_map_check.part.0+0x90>)
200249f8:	681b      	ldr	r3, [r3, #0]
200249fa:	b10b      	cbz	r3, 20024a00 <bbm_map_check.part.0+0x38>
200249fc:	4817      	ldr	r0, [pc, #92]	@ (20024a5c <bbm_map_check.part.0+0x94>)
200249fe:	4798      	blx	r3
20024a00:	e7fe      	b.n	20024a00 <bbm_map_check.part.0+0x38>
20024a02:	3301      	adds	r3, #1
20024a04:	461c      	mov	r4, r3
20024a06:	42ac      	cmp	r4, r5
20024a08:	db01      	blt.n	20024a0e <bbm_map_check.part.0+0x46>
20024a0a:	3604      	adds	r6, #4
20024a0c:	e7e6      	b.n	200249dc <bbm_map_check.part.0+0x14>
20024a0e:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
20024a12:	f1bc 0f00 	cmp.w	ip, #0
20024a16:	d0f8      	beq.n	20024a0a <bbm_map_check.part.0+0x42>
20024a18:	4562      	cmp	r2, ip
20024a1a:	d109      	bne.n	20024a30 <bbm_map_check.part.0+0x68>
20024a1c:	4b0e      	ldr	r3, [pc, #56]	@ (20024a58 <bbm_map_check.part.0+0x90>)
20024a1e:	681d      	ldr	r5, [r3, #0]
20024a20:	b12d      	cbz	r5, 20024a2e <bbm_map_check.part.0+0x66>
20024a22:	3406      	adds	r4, #6
20024a24:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
20024a28:	480d      	ldr	r0, [pc, #52]	@ (20024a60 <bbm_map_check.part.0+0x98>)
20024a2a:	9200      	str	r2, [sp, #0]
20024a2c:	47a8      	blx	r5
20024a2e:	e7fe      	b.n	20024a2e <bbm_map_check.part.0+0x66>
20024a30:	3401      	adds	r4, #1
20024a32:	e7e8      	b.n	20024a06 <bbm_map_check.part.0+0x3e>
20024a34:	eb00 0283 	add.w	r2, r0, r3, lsl #2
20024a38:	8b52      	ldrh	r2, [r2, #26]
20024a3a:	2a00      	cmp	r2, #0
20024a3c:	d0d0      	beq.n	200249e0 <bbm_map_check.part.0+0x18>
20024a3e:	4a06      	ldr	r2, [pc, #24]	@ (20024a58 <bbm_map_check.part.0+0x90>)
20024a40:	6814      	ldr	r4, [r2, #0]
20024a42:	b124      	cbz	r4, 20024a4e <bbm_map_check.part.0+0x86>
20024a44:	eb00 0383 	add.w	r3, r0, r3, lsl #2
20024a48:	8b5a      	ldrh	r2, [r3, #26]
20024a4a:	4806      	ldr	r0, [pc, #24]	@ (20024a64 <bbm_map_check.part.0+0x9c>)
20024a4c:	47a0      	blx	r4
20024a4e:	e7fe      	b.n	20024a4e <bbm_map_check.part.0+0x86>
20024a50:	2004cabc 	.word	0x2004cabc
20024a54:	2004cac0 	.word	0x2004cac0
20024a58:	2004caac 	.word	0x2004caac
20024a5c:	200265a2 	.word	0x200265a2
20024a60:	200265bf 	.word	0x200265bf
20024a64:	2002660c 	.word	0x2002660c

20024a68 <bbm_crc_check>:
20024a68:	f04f 32ff 	mov.w	r2, #4294967295
20024a6c:	b510      	push	{r4, lr}
20024a6e:	4c07      	ldr	r4, [pc, #28]	@ (20024a8c <bbm_crc_check+0x24>)
20024a70:	4401      	add	r1, r0
20024a72:	4288      	cmp	r0, r1
20024a74:	d101      	bne.n	20024a7a <bbm_crc_check+0x12>
20024a76:	43d0      	mvns	r0, r2
20024a78:	bd10      	pop	{r4, pc}
20024a7a:	f810 3b01 	ldrb.w	r3, [r0], #1
20024a7e:	4053      	eors	r3, r2
20024a80:	b2db      	uxtb	r3, r3
20024a82:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
20024a86:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
20024a8a:	e7f2      	b.n	20024a72 <bbm_crc_check+0xa>
20024a8c:	200270cc 	.word	0x200270cc

20024a90 <bbm_get_phy_blk>:
20024a90:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024a92:	4b14      	ldr	r3, [pc, #80]	@ (20024ae4 <bbm_get_phy_blk+0x54>)
20024a94:	4601      	mov	r1, r0
20024a96:	681e      	ldr	r6, [r3, #0]
20024a98:	42b0      	cmp	r0, r6
20024a9a:	d21e      	bcs.n	20024ada <bbm_get_phy_blk+0x4a>
20024a9c:	b138      	cbz	r0, 20024aae <bbm_get_phy_blk+0x1e>
20024a9e:	4b12      	ldr	r3, [pc, #72]	@ (20024ae8 <bbm_get_phy_blk+0x58>)
20024aa0:	2200      	movs	r2, #0
20024aa2:	681c      	ldr	r4, [r3, #0]
20024aa4:	4b11      	ldr	r3, [pc, #68]	@ (20024aec <bbm_get_phy_blk+0x5c>)
20024aa6:	3c04      	subs	r4, #4
20024aa8:	461d      	mov	r5, r3
20024aaa:	4294      	cmp	r4, r2
20024aac:	dc00      	bgt.n	20024ab0 <bbm_get_phy_blk+0x20>
20024aae:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024ab0:	8b1f      	ldrh	r7, [r3, #24]
20024ab2:	428f      	cmp	r7, r1
20024ab4:	d10a      	bne.n	20024acc <bbm_get_phy_blk+0x3c>
20024ab6:	eb05 0582 	add.w	r5, r5, r2, lsl #2
20024aba:	8b6a      	ldrh	r2, [r5, #26]
20024abc:	4296      	cmp	r6, r2
20024abe:	dd0f      	ble.n	20024ae0 <bbm_get_phy_blk+0x50>
20024ac0:	4b0b      	ldr	r3, [pc, #44]	@ (20024af0 <bbm_get_phy_blk+0x60>)
20024ac2:	681b      	ldr	r3, [r3, #0]
20024ac4:	b10b      	cbz	r3, 20024aca <bbm_get_phy_blk+0x3a>
20024ac6:	480b      	ldr	r0, [pc, #44]	@ (20024af4 <bbm_get_phy_blk+0x64>)
20024ac8:	4798      	blx	r3
20024aca:	e7fe      	b.n	20024aca <bbm_get_phy_blk+0x3a>
20024acc:	b917      	cbnz	r7, 20024ad4 <bbm_get_phy_blk+0x44>
20024ace:	8b5f      	ldrh	r7, [r3, #26]
20024ad0:	2f00      	cmp	r7, #0
20024ad2:	d0ec      	beq.n	20024aae <bbm_get_phy_blk+0x1e>
20024ad4:	3201      	adds	r2, #1
20024ad6:	3304      	adds	r3, #4
20024ad8:	e7e7      	b.n	20024aaa <bbm_get_phy_blk+0x1a>
20024ada:	f04f 30ff 	mov.w	r0, #4294967295
20024ade:	e7e6      	b.n	20024aae <bbm_get_phy_blk+0x1e>
20024ae0:	4610      	mov	r0, r2
20024ae2:	e7e4      	b.n	20024aae <bbm_get_phy_blk+0x1e>
20024ae4:	2004cac0 	.word	0x2004cac0
20024ae8:	2004cabc 	.word	0x2004cabc
20024aec:	2004cac4 	.word	0x2004cac4
20024af0:	2004caac 	.word	0x2004caac
20024af4:	2002662a 	.word	0x2002662a

20024af8 <bbm_get_version_inblk>:
20024af8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024afc:	4607      	mov	r7, r0
20024afe:	4688      	mov	r8, r1
20024b00:	b087      	sub	sp, #28
20024b02:	2900      	cmp	r1, #0
20024b04:	d14b      	bne.n	20024b9e <bbm_get_version_inblk+0xa6>
20024b06:	2500      	movs	r5, #0
20024b08:	4628      	mov	r0, r5
20024b0a:	b007      	add	sp, #28
20024b0c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024b10:	2200      	movs	r2, #0
20024b12:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024b16:	4e26      	ldr	r6, [pc, #152]	@ (20024bb0 <bbm_get_version_inblk+0xb8>)
20024b18:	9100      	str	r1, [sp, #0]
20024b1a:	4638      	mov	r0, r7
20024b1c:	4621      	mov	r1, r4
20024b1e:	6833      	ldr	r3, [r6, #0]
20024b20:	f7fb fe58 	bl	200207d4 <port_read_page>
20024b24:	2800      	cmp	r0, #0
20024b26:	dd32      	ble.n	20024b8e <bbm_get_version_inblk+0x96>
20024b28:	6832      	ldr	r2, [r6, #0]
20024b2a:	6813      	ldr	r3, [r2, #0]
20024b2c:	455b      	cmp	r3, fp
20024b2e:	d123      	bne.n	20024b78 <bbm_get_version_inblk+0x80>
20024b30:	6856      	ldr	r6, [r2, #4]
20024b32:	f3c6 061e 	ubfx	r6, r6, #0, #31
20024b36:	42ae      	cmp	r6, r5
20024b38:	dd15      	ble.n	20024b66 <bbm_get_version_inblk+0x6e>
20024b3a:	4610      	mov	r0, r2
20024b3c:	2110      	movs	r1, #16
20024b3e:	9205      	str	r2, [sp, #20]
20024b40:	f7ff ff92 	bl	20024a68 <bbm_crc_check>
20024b44:	9a05      	ldr	r2, [sp, #20]
20024b46:	6913      	ldr	r3, [r2, #16]
20024b48:	4283      	cmp	r3, r0
20024b4a:	d113      	bne.n	20024b74 <bbm_get_version_inblk+0x7c>
20024b4c:	f8c8 4000 	str.w	r4, [r8]
20024b50:	4635      	mov	r5, r6
20024b52:	3401      	adds	r4, #1
20024b54:	f8da 1000 	ldr.w	r1, [sl]
20024b58:	f8d9 3000 	ldr.w	r3, [r9]
20024b5c:	fbb3 f3f1 	udiv	r3, r3, r1
20024b60:	42a3      	cmp	r3, r4
20024b62:	d8d5      	bhi.n	20024b10 <bbm_get_version_inblk+0x18>
20024b64:	e7d0      	b.n	20024b08 <bbm_get_version_inblk+0x10>
20024b66:	4b13      	ldr	r3, [pc, #76]	@ (20024bb4 <bbm_get_version_inblk+0xbc>)
20024b68:	681b      	ldr	r3, [r3, #0]
20024b6a:	b11b      	cbz	r3, 20024b74 <bbm_get_version_inblk+0x7c>
20024b6c:	4632      	mov	r2, r6
20024b6e:	4629      	mov	r1, r5
20024b70:	4811      	ldr	r0, [pc, #68]	@ (20024bb8 <bbm_get_version_inblk+0xc0>)
20024b72:	4798      	blx	r3
20024b74:	462e      	mov	r6, r5
20024b76:	e7eb      	b.n	20024b50 <bbm_get_version_inblk+0x58>
20024b78:	1c5a      	adds	r2, r3, #1
20024b7a:	d0c5      	beq.n	20024b08 <bbm_get_version_inblk+0x10>
20024b7c:	4a0d      	ldr	r2, [pc, #52]	@ (20024bb4 <bbm_get_version_inblk+0xbc>)
20024b7e:	6815      	ldr	r5, [r2, #0]
20024b80:	2d00      	cmp	r5, #0
20024b82:	d0c0      	beq.n	20024b06 <bbm_get_version_inblk+0xe>
20024b84:	4622      	mov	r2, r4
20024b86:	4639      	mov	r1, r7
20024b88:	480c      	ldr	r0, [pc, #48]	@ (20024bbc <bbm_get_version_inblk+0xc4>)
20024b8a:	47a8      	blx	r5
20024b8c:	e7bb      	b.n	20024b06 <bbm_get_version_inblk+0xe>
20024b8e:	4b09      	ldr	r3, [pc, #36]	@ (20024bb4 <bbm_get_version_inblk+0xbc>)
20024b90:	681b      	ldr	r3, [r3, #0]
20024b92:	2b00      	cmp	r3, #0
20024b94:	d0ee      	beq.n	20024b74 <bbm_get_version_inblk+0x7c>
20024b96:	4622      	mov	r2, r4
20024b98:	4639      	mov	r1, r7
20024b9a:	4809      	ldr	r0, [pc, #36]	@ (20024bc0 <bbm_get_version_inblk+0xc8>)
20024b9c:	e7e9      	b.n	20024b72 <bbm_get_version_inblk+0x7a>
20024b9e:	2400      	movs	r4, #0
20024ba0:	f8df a020 	ldr.w	sl, [pc, #32]	@ 20024bc4 <bbm_get_version_inblk+0xcc>
20024ba4:	4625      	mov	r5, r4
20024ba6:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 20024bc8 <bbm_get_version_inblk+0xd0>
20024baa:	f8df b020 	ldr.w	fp, [pc, #32]	@ 20024bcc <bbm_get_version_inblk+0xd4>
20024bae:	e7d1      	b.n	20024b54 <bbm_get_version_inblk+0x5c>
20024bb0:	2004cab0 	.word	0x2004cab0
20024bb4:	2004caac 	.word	0x2004caac
20024bb8:	20026649 	.word	0x20026649
20024bbc:	20026676 	.word	0x20026676
20024bc0:	200266a7 	.word	0x200266a7
20024bc4:	2004499c 	.word	0x2004499c
20024bc8:	200449a0 	.word	0x200449a0
20024bcc:	5366424d 	.word	0x5366424d

20024bd0 <bbm_get_map_table>:
20024bd0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024bd4:	2801      	cmp	r0, #1
20024bd6:	4607      	mov	r7, r0
20024bd8:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 20024d38 <bbm_get_map_table+0x168>
20024bdc:	b087      	sub	sp, #28
20024bde:	dd0a      	ble.n	20024bf6 <bbm_get_map_table+0x26>
20024be0:	f8db 3000 	ldr.w	r3, [fp]
20024be4:	b91b      	cbnz	r3, 20024bee <bbm_get_map_table+0x1e>
20024be6:	2000      	movs	r0, #0
20024be8:	b007      	add	sp, #28
20024bea:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024bee:	4601      	mov	r1, r0
20024bf0:	4847      	ldr	r0, [pc, #284]	@ (20024d10 <bbm_get_map_table+0x140>)
20024bf2:	4798      	blx	r3
20024bf4:	e7f7      	b.n	20024be6 <bbm_get_map_table+0x16>
20024bf6:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 20024d3c <bbm_get_map_table+0x16c>
20024bfa:	2800      	cmp	r0, #0
20024bfc:	d163      	bne.n	20024cc6 <bbm_get_map_table+0xf6>
20024bfe:	f8b8 6000 	ldrh.w	r6, [r8]
20024c02:	f8b8 5002 	ldrh.w	r5, [r8, #2]
20024c06:	2e00      	cmp	r6, #0
20024c08:	d062      	beq.n	20024cd0 <bbm_get_map_table+0x100>
20024c0a:	4630      	mov	r0, r6
20024c0c:	a904      	add	r1, sp, #16
20024c0e:	f7ff ff73 	bl	20024af8 <bbm_get_version_inblk>
20024c12:	4681      	mov	r9, r0
20024c14:	2d00      	cmp	r5, #0
20024c16:	d05d      	beq.n	20024cd4 <bbm_get_map_table+0x104>
20024c18:	4628      	mov	r0, r5
20024c1a:	a905      	add	r1, sp, #20
20024c1c:	f7ff ff6c 	bl	20024af8 <bbm_get_version_inblk>
20024c20:	4604      	mov	r4, r0
20024c22:	f8db a000 	ldr.w	sl, [fp]
20024c26:	f1ba 0f00 	cmp.w	sl, #0
20024c2a:	d005      	beq.n	20024c38 <bbm_get_map_table+0x68>
20024c2c:	4623      	mov	r3, r4
20024c2e:	4632      	mov	r2, r6
20024c30:	4649      	mov	r1, r9
20024c32:	4838      	ldr	r0, [pc, #224]	@ (20024d14 <bbm_get_map_table+0x144>)
20024c34:	9500      	str	r5, [sp, #0]
20024c36:	47d0      	blx	sl
20024c38:	45a1      	cmp	r9, r4
20024c3a:	d0d4      	beq.n	20024be6 <bbm_get_map_table+0x16>
20024c3c:	f04f 0200 	mov.w	r2, #0
20024c40:	bf98      	it	ls
20024c42:	462e      	movls	r6, r5
20024c44:	f107 0308 	add.w	r3, r7, #8
20024c48:	bf94      	ite	ls
20024c4a:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
20024c4e:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
20024c52:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024c56:	4b30      	ldr	r3, [pc, #192]	@ (20024d18 <bbm_get_map_table+0x148>)
20024c58:	bf88      	it	hi
20024c5a:	f8dd a010 	ldrhi.w	sl, [sp, #16]
20024c5e:	681b      	ldr	r3, [r3, #0]
20024c60:	bf98      	it	ls
20024c62:	f8dd a014 	ldrls.w	sl, [sp, #20]
20024c66:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 20024d40 <bbm_get_map_table+0x170>
20024c6a:	9300      	str	r3, [sp, #0]
20024c6c:	4651      	mov	r1, sl
20024c6e:	4630      	mov	r0, r6
20024c70:	f8d8 3000 	ldr.w	r3, [r8]
20024c74:	bf88      	it	hi
20024c76:	464c      	movhi	r4, r9
20024c78:	f7fb fdac 	bl	200207d4 <port_read_page>
20024c7c:	2800      	cmp	r0, #0
20024c7e:	f8db 5000 	ldr.w	r5, [fp]
20024c82:	dd38      	ble.n	20024cf6 <bbm_get_map_table+0x126>
20024c84:	f8d8 8000 	ldr.w	r8, [r8]
20024c88:	4b24      	ldr	r3, [pc, #144]	@ (20024d1c <bbm_get_map_table+0x14c>)
20024c8a:	f8d8 2000 	ldr.w	r2, [r8]
20024c8e:	429a      	cmp	r2, r3
20024c90:	d12b      	bne.n	20024cea <bbm_get_map_table+0x11a>
20024c92:	2110      	movs	r1, #16
20024c94:	4640      	mov	r0, r8
20024c96:	f7ff fee7 	bl	20024a68 <bbm_crc_check>
20024c9a:	f8d8 2010 	ldr.w	r2, [r8, #16]
20024c9e:	4601      	mov	r1, r0
20024ca0:	4282      	cmp	r2, r0
20024ca2:	d11e      	bne.n	20024ce2 <bbm_get_map_table+0x112>
20024ca4:	f8d8 1004 	ldr.w	r1, [r8, #4]
20024ca8:	f3c1 011e 	ubfx	r1, r1, #0, #31
20024cac:	42a1      	cmp	r1, r4
20024cae:	d113      	bne.n	20024cd8 <bbm_get_map_table+0x108>
20024cb0:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024cb4:	481a      	ldr	r0, [pc, #104]	@ (20024d20 <bbm_get_map_table+0x150>)
20024cb6:	4641      	mov	r1, r8
20024cb8:	fb02 0007 	mla	r0, r2, r7, r0
20024cbc:	f001 f867 	bl	20025d8e <memcpy>
20024cc0:	bb0d      	cbnz	r5, 20024d06 <bbm_get_map_table+0x136>
20024cc2:	4620      	mov	r0, r4
20024cc4:	e790      	b.n	20024be8 <bbm_get_map_table+0x18>
20024cc6:	f8b8 6004 	ldrh.w	r6, [r8, #4]
20024cca:	f8b8 5006 	ldrh.w	r5, [r8, #6]
20024cce:	e79a      	b.n	20024c06 <bbm_get_map_table+0x36>
20024cd0:	46b1      	mov	r9, r6
20024cd2:	e79f      	b.n	20024c14 <bbm_get_map_table+0x44>
20024cd4:	462c      	mov	r4, r5
20024cd6:	e7a4      	b.n	20024c22 <bbm_get_map_table+0x52>
20024cd8:	b115      	cbz	r5, 20024ce0 <bbm_get_map_table+0x110>
20024cda:	4622      	mov	r2, r4
20024cdc:	4811      	ldr	r0, [pc, #68]	@ (20024d24 <bbm_get_map_table+0x154>)
20024cde:	47a8      	blx	r5
20024ce0:	e7fe      	b.n	20024ce0 <bbm_get_map_table+0x110>
20024ce2:	b10d      	cbz	r5, 20024ce8 <bbm_get_map_table+0x118>
20024ce4:	4810      	ldr	r0, [pc, #64]	@ (20024d28 <bbm_get_map_table+0x158>)
20024ce6:	47a8      	blx	r5
20024ce8:	e7fe      	b.n	20024ce8 <bbm_get_map_table+0x118>
20024cea:	b11d      	cbz	r5, 20024cf4 <bbm_get_map_table+0x124>
20024cec:	4652      	mov	r2, sl
20024cee:	4631      	mov	r1, r6
20024cf0:	480e      	ldr	r0, [pc, #56]	@ (20024d2c <bbm_get_map_table+0x15c>)
20024cf2:	47a8      	blx	r5
20024cf4:	e7fe      	b.n	20024cf4 <bbm_get_map_table+0x124>
20024cf6:	2d00      	cmp	r5, #0
20024cf8:	f43f af75 	beq.w	20024be6 <bbm_get_map_table+0x16>
20024cfc:	4652      	mov	r2, sl
20024cfe:	4631      	mov	r1, r6
20024d00:	480b      	ldr	r0, [pc, #44]	@ (20024d30 <bbm_get_map_table+0x160>)
20024d02:	47a8      	blx	r5
20024d04:	e76f      	b.n	20024be6 <bbm_get_map_table+0x16>
20024d06:	4621      	mov	r1, r4
20024d08:	480a      	ldr	r0, [pc, #40]	@ (20024d34 <bbm_get_map_table+0x164>)
20024d0a:	47a8      	blx	r5
20024d0c:	e7d9      	b.n	20024cc2 <bbm_get_map_table+0xf2>
20024d0e:	bf00      	nop
20024d10:	200266c5 	.word	0x200266c5
20024d14:	200266d9 	.word	0x200266d9
20024d18:	2004499c 	.word	0x2004499c
20024d1c:	5366424d 	.word	0x5366424d
20024d20:	2004cac4 	.word	0x2004cac4
20024d24:	200266ff 	.word	0x200266ff
20024d28:	20026749 	.word	0x20026749
20024d2c:	2002675b 	.word	0x2002675b
20024d30:	20026790 	.word	0x20026790
20024d34:	200267bc 	.word	0x200267bc
20024d38:	2004caac 	.word	0x2004caac
20024d3c:	2004ced4 	.word	0x2004ced4
20024d40:	2004cab0 	.word	0x2004cab0

20024d44 <bbm_get_page_num>:
20024d44:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20024d48:	4605      	mov	r5, r0
20024d4a:	2400      	movs	r4, #0
20024d4c:	4f13      	ldr	r7, [pc, #76]	@ (20024d9c <bbm_get_page_num+0x58>)
20024d4e:	4e14      	ldr	r6, [pc, #80]	@ (20024da0 <bbm_get_page_num+0x5c>)
20024d50:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 20024da4 <bbm_get_page_num+0x60>
20024d54:	b085      	sub	sp, #20
20024d56:	6839      	ldr	r1, [r7, #0]
20024d58:	6833      	ldr	r3, [r6, #0]
20024d5a:	fbb3 f3f1 	udiv	r3, r3, r1
20024d5e:	42a3      	cmp	r3, r4
20024d60:	d802      	bhi.n	20024d68 <bbm_get_page_num+0x24>
20024d62:	f04f 34ff 	mov.w	r4, #4294967295
20024d66:	e015      	b.n	20024d94 <bbm_get_page_num+0x50>
20024d68:	2200      	movs	r2, #0
20024d6a:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024d6e:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 20024da8 <bbm_get_page_num+0x64>
20024d72:	9100      	str	r1, [sp, #0]
20024d74:	4628      	mov	r0, r5
20024d76:	4621      	mov	r1, r4
20024d78:	f8d9 3000 	ldr.w	r3, [r9]
20024d7c:	f7fb fd2a 	bl	200207d4 <port_read_page>
20024d80:	b120      	cbz	r0, 20024d8c <bbm_get_page_num+0x48>
20024d82:	f8d9 3000 	ldr.w	r3, [r9]
20024d86:	681b      	ldr	r3, [r3, #0]
20024d88:	4543      	cmp	r3, r8
20024d8a:	d101      	bne.n	20024d90 <bbm_get_page_num+0x4c>
20024d8c:	3401      	adds	r4, #1
20024d8e:	e7e2      	b.n	20024d56 <bbm_get_page_num+0x12>
20024d90:	3301      	adds	r3, #1
20024d92:	d1fb      	bne.n	20024d8c <bbm_get_page_num+0x48>
20024d94:	4620      	mov	r0, r4
20024d96:	b005      	add	sp, #20
20024d98:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20024d9c:	2004499c 	.word	0x2004499c
20024da0:	200449a0 	.word	0x200449a0
20024da4:	5366424d 	.word	0x5366424d
20024da8:	2004cab0 	.word	0x2004cab0

20024dac <bbm_read_page>:
20024dac:	b5f0      	push	{r4, r5, r6, r7, lr}
20024dae:	4604      	mov	r4, r0
20024db0:	b085      	sub	sp, #20
20024db2:	b280      	uxth	r0, r0
20024db4:	461f      	mov	r7, r3
20024db6:	460d      	mov	r5, r1
20024db8:	4616      	mov	r6, r2
20024dba:	f7ff fe69 	bl	20024a90 <bbm_get_phy_blk>
20024dbe:	1c43      	adds	r3, r0, #1
20024dc0:	d108      	bne.n	20024dd4 <bbm_read_page+0x28>
20024dc2:	4b0a      	ldr	r3, [pc, #40]	@ (20024dec <bbm_read_page+0x40>)
20024dc4:	681b      	ldr	r3, [r3, #0]
20024dc6:	b113      	cbz	r3, 20024dce <bbm_read_page+0x22>
20024dc8:	4621      	mov	r1, r4
20024dca:	4809      	ldr	r0, [pc, #36]	@ (20024df0 <bbm_read_page+0x44>)
20024dcc:	4798      	blx	r3
20024dce:	2000      	movs	r0, #0
20024dd0:	b005      	add	sp, #20
20024dd2:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024dd4:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
20024dd6:	4632      	mov	r2, r6
20024dd8:	9302      	str	r3, [sp, #8]
20024dda:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
20024ddc:	4629      	mov	r1, r5
20024dde:	9301      	str	r3, [sp, #4]
20024de0:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20024de2:	9300      	str	r3, [sp, #0]
20024de4:	463b      	mov	r3, r7
20024de6:	f7fb fcf5 	bl	200207d4 <port_read_page>
20024dea:	e7f1      	b.n	20024dd0 <bbm_read_page+0x24>
20024dec:	2004caac 	.word	0x2004caac
20024df0:	200267cf 	.word	0x200267cf

20024df4 <port_write_page>:
20024df4:	4b01      	ldr	r3, [pc, #4]	@ (20024dfc <port_write_page+0x8>)
20024df6:	6818      	ldr	r0, [r3, #0]
20024df8:	4770      	bx	lr
20024dfa:	bf00      	nop
20024dfc:	2004499c 	.word	0x2004499c

20024e00 <bbm_write_talbe.isra.0>:
20024e00:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024e02:	4604      	mov	r4, r0
20024e04:	4608      	mov	r0, r1
20024e06:	460e      	mov	r6, r1
20024e08:	f7ff ff9c 	bl	20024d44 <bbm_get_page_num>
20024e0c:	1e05      	subs	r5, r0, #0
20024e0e:	db25      	blt.n	20024e5c <bbm_write_talbe.isra.0+0x5c>
20024e10:	4b13      	ldr	r3, [pc, #76]	@ (20024e60 <bbm_write_talbe.isra.0+0x60>)
20024e12:	681a      	ldr	r2, [r3, #0]
20024e14:	4b13      	ldr	r3, [pc, #76]	@ (20024e64 <bbm_write_talbe.isra.0+0x64>)
20024e16:	681b      	ldr	r3, [r3, #0]
20024e18:	fbb3 f3f2 	udiv	r3, r3, r2
20024e1c:	429d      	cmp	r5, r3
20024e1e:	da1d      	bge.n	20024e5c <bbm_write_talbe.isra.0+0x5c>
20024e20:	4f11      	ldr	r7, [pc, #68]	@ (20024e68 <bbm_write_talbe.isra.0+0x68>)
20024e22:	21ff      	movs	r1, #255	@ 0xff
20024e24:	6838      	ldr	r0, [r7, #0]
20024e26:	f000 ff43 	bl	20025cb0 <memset>
20024e2a:	4264      	negs	r4, r4
20024e2c:	490f      	ldr	r1, [pc, #60]	@ (20024e6c <bbm_write_talbe.isra.0+0x6c>)
20024e2e:	f404 7402 	and.w	r4, r4, #520	@ 0x208
20024e32:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024e36:	6838      	ldr	r0, [r7, #0]
20024e38:	4421      	add	r1, r4
20024e3a:	f000 ffa8 	bl	20025d8e <memcpy>
20024e3e:	6838      	ldr	r0, [r7, #0]
20024e40:	b160      	cbz	r0, 20024e5c <bbm_write_talbe.isra.0+0x5c>
20024e42:	6802      	ldr	r2, [r0, #0]
20024e44:	4b0a      	ldr	r3, [pc, #40]	@ (20024e70 <bbm_write_talbe.isra.0+0x70>)
20024e46:	429a      	cmp	r2, r3
20024e48:	d108      	bne.n	20024e5c <bbm_write_talbe.isra.0+0x5c>
20024e4a:	f7ff fdbd 	bl	200249c8 <bbm_map_check.part.0>
20024e4e:	2300      	movs	r3, #0
20024e50:	9300      	str	r3, [sp, #0]
20024e52:	4629      	mov	r1, r5
20024e54:	4630      	mov	r0, r6
20024e56:	683a      	ldr	r2, [r7, #0]
20024e58:	f7ff ffcc 	bl	20024df4 <port_write_page>
20024e5c:	b003      	add	sp, #12
20024e5e:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024e60:	2004499c 	.word	0x2004499c
20024e64:	200449a0 	.word	0x200449a0
20024e68:	2004cab0 	.word	0x2004cab0
20024e6c:	2004cac4 	.word	0x2004cac4
20024e70:	5366424d 	.word	0x5366424d

20024e74 <port_erase_block>:
20024e74:	2000      	movs	r0, #0
20024e76:	4770      	bx	lr

20024e78 <bbm_init_table>:
20024e78:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024e7c:	4c7c      	ldr	r4, [pc, #496]	@ (20025070 <bbm_init_table+0x1f8>)
20024e7e:	4b7d      	ldr	r3, [pc, #500]	@ (20025074 <bbm_init_table+0x1fc>)
20024e80:	6822      	ldr	r2, [r4, #0]
20024e82:	b085      	sub	sp, #20
20024e84:	429a      	cmp	r2, r3
20024e86:	f000 80ed 	beq.w	20025064 <bbm_init_table+0x1ec>
20024e8a:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
20024e8e:	429a      	cmp	r2, r3
20024e90:	f000 80e8 	beq.w	20025064 <bbm_init_table+0x1ec>
20024e94:	6023      	str	r3, [r4, #0]
20024e96:	2301      	movs	r3, #1
20024e98:	6063      	str	r3, [r4, #4]
20024e9a:	2300      	movs	r3, #0
20024e9c:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 200250a8 <bbm_init_table+0x230>
20024ea0:	8123      	strh	r3, [r4, #8]
20024ea2:	f8d9 3000 	ldr.w	r3, [r9]
20024ea6:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 200250ac <bbm_init_table+0x234>
20024eaa:	3b04      	subs	r3, #4
20024eac:	f8df a200 	ldr.w	sl, [pc, #512]	@ 200250b0 <bbm_init_table+0x238>
20024eb0:	8163      	strh	r3, [r4, #10]
20024eb2:	f8d8 3000 	ldr.w	r3, [r8]
20024eb6:	f8da 5000 	ldr.w	r5, [sl]
20024eba:	3b01      	subs	r3, #1
20024ebc:	4e6e      	ldr	r6, [pc, #440]	@ (20025078 <bbm_init_table+0x200>)
20024ebe:	81a3      	strh	r3, [r4, #12]
20024ec0:	81e5      	strh	r5, [r4, #14]
20024ec2:	f8d8 3000 	ldr.w	r3, [r8]
20024ec6:	429d      	cmp	r5, r3
20024ec8:	db10      	blt.n	20024eec <bbm_init_table+0x74>
20024eca:	2500      	movs	r5, #0
20024ecc:	462f      	mov	r7, r5
20024ece:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 20025078 <bbm_init_table+0x200>
20024ed2:	f8da 6000 	ldr.w	r6, [sl]
20024ed6:	42b5      	cmp	r5, r6
20024ed8:	db1d      	blt.n	20024f16 <bbm_init_table+0x9e>
20024eda:	8963      	ldrh	r3, [r4, #10]
20024edc:	2b00      	cmp	r3, #0
20024ede:	d148      	bne.n	20024f72 <bbm_init_table+0xfa>
20024ee0:	4b65      	ldr	r3, [pc, #404]	@ (20025078 <bbm_init_table+0x200>)
20024ee2:	681b      	ldr	r3, [r3, #0]
20024ee4:	b10b      	cbz	r3, 20024eea <bbm_init_table+0x72>
20024ee6:	4865      	ldr	r0, [pc, #404]	@ (2002507c <bbm_init_table+0x204>)
20024ee8:	4798      	blx	r3
20024eea:	e7fe      	b.n	20024eea <bbm_init_table+0x72>
20024eec:	4628      	mov	r0, r5
20024eee:	f7fb fcd7 	bl	200208a0 <bbm_get_bb>
20024ef2:	b950      	cbnz	r0, 20024f0a <bbm_init_table+0x92>
20024ef4:	4628      	mov	r0, r5
20024ef6:	f7ff ffbd 	bl	20024e74 <port_erase_block>
20024efa:	b120      	cbz	r0, 20024f06 <bbm_init_table+0x8e>
20024efc:	6833      	ldr	r3, [r6, #0]
20024efe:	b113      	cbz	r3, 20024f06 <bbm_init_table+0x8e>
20024f00:	4629      	mov	r1, r5
20024f02:	485f      	ldr	r0, [pc, #380]	@ (20025080 <bbm_init_table+0x208>)
20024f04:	4798      	blx	r3
20024f06:	3501      	adds	r5, #1
20024f08:	e7db      	b.n	20024ec2 <bbm_init_table+0x4a>
20024f0a:	6833      	ldr	r3, [r6, #0]
20024f0c:	2b00      	cmp	r3, #0
20024f0e:	d0fa      	beq.n	20024f06 <bbm_init_table+0x8e>
20024f10:	4629      	mov	r1, r5
20024f12:	485c      	ldr	r0, [pc, #368]	@ (20025084 <bbm_init_table+0x20c>)
20024f14:	e7f6      	b.n	20024f04 <bbm_init_table+0x8c>
20024f16:	4628      	mov	r0, r5
20024f18:	f7fb fcc2 	bl	200208a0 <bbm_get_bb>
20024f1c:	b338      	cbz	r0, 20024f6e <bbm_init_table+0xf6>
20024f1e:	f8db 3000 	ldr.w	r3, [fp]
20024f22:	b113      	cbz	r3, 20024f2a <bbm_init_table+0xb2>
20024f24:	4629      	mov	r1, r5
20024f26:	4858      	ldr	r0, [pc, #352]	@ (20025088 <bbm_init_table+0x210>)
20024f28:	4798      	blx	r3
20024f2a:	89a0      	ldrh	r0, [r4, #12]
20024f2c:	f7fb fcb8 	bl	200208a0 <bbm_get_bb>
20024f30:	89a3      	ldrh	r3, [r4, #12]
20024f32:	4606      	mov	r6, r0
20024f34:	3b01      	subs	r3, #1
20024f36:	81a3      	strh	r3, [r4, #12]
20024f38:	8963      	ldrh	r3, [r4, #10]
20024f3a:	3b01      	subs	r3, #1
20024f3c:	b29b      	uxth	r3, r3
20024f3e:	8163      	strh	r3, [r4, #10]
20024f40:	b108      	cbz	r0, 20024f46 <bbm_init_table+0xce>
20024f42:	2b00      	cmp	r3, #0
20024f44:	d1f1      	bne.n	20024f2a <bbm_init_table+0xb2>
20024f46:	f8db 3000 	ldr.w	r3, [fp]
20024f4a:	b11b      	cbz	r3, 20024f54 <bbm_init_table+0xdc>
20024f4c:	463a      	mov	r2, r7
20024f4e:	4629      	mov	r1, r5
20024f50:	484e      	ldr	r0, [pc, #312]	@ (2002508c <bbm_init_table+0x214>)
20024f52:	4798      	blx	r3
20024f54:	b93e      	cbnz	r6, 20024f66 <bbm_init_table+0xee>
20024f56:	89a2      	ldrh	r2, [r4, #12]
20024f58:	1dbb      	adds	r3, r7, #6
20024f5a:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
20024f5e:	3201      	adds	r2, #1
20024f60:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20024f64:	805a      	strh	r2, [r3, #2]
20024f66:	8923      	ldrh	r3, [r4, #8]
20024f68:	3701      	adds	r7, #1
20024f6a:	3301      	adds	r3, #1
20024f6c:	8123      	strh	r3, [r4, #8]
20024f6e:	3501      	adds	r5, #1
20024f70:	e7af      	b.n	20024ed2 <bbm_init_table+0x5a>
20024f72:	2110      	movs	r1, #16
20024f74:	483e      	ldr	r0, [pc, #248]	@ (20025070 <bbm_init_table+0x1f8>)
20024f76:	f7ff fd77 	bl	20024a68 <bbm_crc_check>
20024f7a:	f8d9 1000 	ldr.w	r1, [r9]
20024f7e:	6120      	str	r0, [r4, #16]
20024f80:	3904      	subs	r1, #4
20024f82:	0089      	lsls	r1, r1, #2
20024f84:	4842      	ldr	r0, [pc, #264]	@ (20025090 <bbm_init_table+0x218>)
20024f86:	f7ff fd6f 	bl	20024a68 <bbm_crc_check>
20024f8a:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024f8e:	4938      	ldr	r1, [pc, #224]	@ (20025070 <bbm_init_table+0x1f8>)
20024f90:	6160      	str	r0, [r4, #20]
20024f92:	1888      	adds	r0, r1, r2
20024f94:	f000 fefb 	bl	20025d8e <memcpy>
20024f98:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20024f9c:	2110      	movs	r1, #16
20024f9e:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20024fa2:	483c      	ldr	r0, [pc, #240]	@ (20025094 <bbm_init_table+0x21c>)
20024fa4:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20024fa8:	f7ff fd5e 	bl	20024a68 <bbm_crc_check>
20024fac:	2700      	movs	r7, #0
20024fae:	f8df a104 	ldr.w	sl, [pc, #260]	@ 200250b4 <bbm_init_table+0x23c>
20024fb2:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 200250b8 <bbm_init_table+0x240>
20024fb6:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20024fba:	f8d8 3000 	ldr.w	r3, [r8]
20024fbe:	429e      	cmp	r6, r3
20024fc0:	db08      	blt.n	20024fd4 <bbm_init_table+0x15c>
20024fc2:	2f03      	cmp	r7, #3
20024fc4:	dc2f      	bgt.n	20025026 <bbm_init_table+0x1ae>
20024fc6:	4b2c      	ldr	r3, [pc, #176]	@ (20025078 <bbm_init_table+0x200>)
20024fc8:	681b      	ldr	r3, [r3, #0]
20024fca:	b113      	cbz	r3, 20024fd2 <bbm_init_table+0x15a>
20024fcc:	4639      	mov	r1, r7
20024fce:	4832      	ldr	r0, [pc, #200]	@ (20025098 <bbm_init_table+0x220>)
20024fd0:	4798      	blx	r3
20024fd2:	e7fe      	b.n	20024fd2 <bbm_init_table+0x15a>
20024fd4:	4630      	mov	r0, r6
20024fd6:	f7fb fc63 	bl	200208a0 <bbm_get_bb>
20024fda:	4604      	mov	r4, r0
20024fdc:	bb08      	cbnz	r0, 20025022 <bbm_init_table+0x1aa>
20024fde:	f8da 5000 	ldr.w	r5, [sl]
20024fe2:	21ff      	movs	r1, #255	@ 0xff
20024fe4:	462a      	mov	r2, r5
20024fe6:	f8d9 0000 	ldr.w	r0, [r9]
20024fea:	f000 fe61 	bl	20025cb0 <memset>
20024fee:	e9cd 4401 	strd	r4, r4, [sp, #4]
20024ff2:	9500      	str	r5, [sp, #0]
20024ff4:	f8d9 3000 	ldr.w	r3, [r9]
20024ff8:	4622      	mov	r2, r4
20024ffa:	4621      	mov	r1, r4
20024ffc:	4630      	mov	r0, r6
20024ffe:	f7fb fbe9 	bl	200207d4 <port_read_page>
20025002:	f8da 3000 	ldr.w	r3, [sl]
20025006:	4298      	cmp	r0, r3
20025008:	d109      	bne.n	2002501e <bbm_init_table+0x1a6>
2002500a:	f8d9 3000 	ldr.w	r3, [r9]
2002500e:	681b      	ldr	r3, [r3, #0]
20025010:	3301      	adds	r3, #1
20025012:	bf01      	itttt	eq
20025014:	4b21      	ldreq	r3, [pc, #132]	@ (2002509c <bbm_init_table+0x224>)
20025016:	1d3a      	addeq	r2, r7, #4
20025018:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
2002501c:	3701      	addeq	r7, #1
2002501e:	2f03      	cmp	r7, #3
20025020:	dc01      	bgt.n	20025026 <bbm_init_table+0x1ae>
20025022:	3601      	adds	r6, #1
20025024:	e7c9      	b.n	20024fba <bbm_init_table+0x142>
20025026:	2500      	movs	r5, #0
20025028:	4c1c      	ldr	r4, [pc, #112]	@ (2002509c <bbm_init_table+0x224>)
2002502a:	2000      	movs	r0, #0
2002502c:	8921      	ldrh	r1, [r4, #8]
2002502e:	f7ff fee7 	bl	20024e00 <bbm_write_talbe.isra.0>
20025032:	8923      	ldrh	r3, [r4, #8]
20025034:	2001      	movs	r0, #1
20025036:	8961      	ldrh	r1, [r4, #10]
20025038:	8023      	strh	r3, [r4, #0]
2002503a:	8223      	strh	r3, [r4, #16]
2002503c:	8125      	strh	r5, [r4, #8]
2002503e:	f7ff fedf 	bl	20024e00 <bbm_write_talbe.isra.0>
20025042:	8963      	ldrh	r3, [r4, #10]
20025044:	8165      	strh	r5, [r4, #10]
20025046:	80a3      	strh	r3, [r4, #4]
20025048:	8263      	strh	r3, [r4, #18]
2002504a:	89a3      	ldrh	r3, [r4, #12]
2002504c:	8063      	strh	r3, [r4, #2]
2002504e:	89e3      	ldrh	r3, [r4, #14]
20025050:	80e3      	strh	r3, [r4, #6]
20025052:	4b09      	ldr	r3, [pc, #36]	@ (20025078 <bbm_init_table+0x200>)
20025054:	681b      	ldr	r3, [r3, #0]
20025056:	b10b      	cbz	r3, 2002505c <bbm_init_table+0x1e4>
20025058:	4811      	ldr	r0, [pc, #68]	@ (200250a0 <bbm_init_table+0x228>)
2002505a:	4798      	blx	r3
2002505c:	2000      	movs	r0, #0
2002505e:	b005      	add	sp, #20
20025060:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025064:	4b04      	ldr	r3, [pc, #16]	@ (20025078 <bbm_init_table+0x200>)
20025066:	681b      	ldr	r3, [r3, #0]
20025068:	b10b      	cbz	r3, 2002506e <bbm_init_table+0x1f6>
2002506a:	480e      	ldr	r0, [pc, #56]	@ (200250a4 <bbm_init_table+0x22c>)
2002506c:	4798      	blx	r3
2002506e:	e7fe      	b.n	2002506e <bbm_init_table+0x1f6>
20025070:	2004cac4 	.word	0x2004cac4
20025074:	5366424d 	.word	0x5366424d
20025078:	2004caac 	.word	0x2004caac
2002507c:	20026864 	.word	0x20026864
20025080:	200267f2 	.word	0x200267f2
20025084:	20026814 	.word	0x20026814
20025088:	20026831 	.word	0x20026831
2002508c:	20026850 	.word	0x20026850
20025090:	2004cadc 	.word	0x2004cadc
20025094:	2004cccc 	.word	0x2004cccc
20025098:	2002687e 	.word	0x2002687e
2002509c:	2004ced4 	.word	0x2004ced4
200250a0:	200268a5 	.word	0x200268a5
200250a4:	200268c1 	.word	0x200268c1
200250a8:	2004cabc 	.word	0x2004cabc
200250ac:	2004cab8 	.word	0x2004cab8
200250b0:	2004cac0 	.word	0x2004cac0
200250b4:	2004499c 	.word	0x2004499c
200250b8:	2004cab0 	.word	0x2004cab0

200250bc <sif_bbm_init>:
200250bc:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200250c0:	b087      	sub	sp, #28
200250c2:	2900      	cmp	r1, #0
200250c4:	f000 8129 	beq.w	2002531a <sif_bbm_init+0x25e>
200250c8:	4b95      	ldr	r3, [pc, #596]	@ (20025320 <sif_bbm_init+0x264>)
200250ca:	681a      	ldr	r2, [r3, #0]
200250cc:	2a01      	cmp	r2, #1
200250ce:	d108      	bne.n	200250e2 <sif_bbm_init+0x26>
200250d0:	4b94      	ldr	r3, [pc, #592]	@ (20025324 <sif_bbm_init+0x268>)
200250d2:	681b      	ldr	r3, [r3, #0]
200250d4:	b10b      	cbz	r3, 200250da <sif_bbm_init+0x1e>
200250d6:	4894      	ldr	r0, [pc, #592]	@ (20025328 <sif_bbm_init+0x26c>)
200250d8:	4798      	blx	r3
200250da:	2000      	movs	r0, #0
200250dc:	b007      	add	sp, #28
200250de:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200250e2:	2201      	movs	r2, #1
200250e4:	601a      	str	r2, [r3, #0]
200250e6:	4b91      	ldr	r3, [pc, #580]	@ (2002532c <sif_bbm_init+0x270>)
200250e8:	681c      	ldr	r4, [r3, #0]
200250ea:	b904      	cbnz	r4, 200250ee <sif_bbm_init+0x32>
200250ec:	e7fe      	b.n	200250ec <sif_bbm_init+0x30>
200250ee:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 2002536c <sif_bbm_init+0x2b0>
200250f2:	f8da 2000 	ldr.w	r2, [sl]
200250f6:	b902      	cbnz	r2, 200250fa <sif_bbm_init+0x3e>
200250f8:	e7fe      	b.n	200250f8 <sif_bbm_init+0x3c>
200250fa:	fbb0 f4f4 	udiv	r4, r0, r4
200250fe:	f04f 0800 	mov.w	r8, #0
20025102:	4a8b      	ldr	r2, [pc, #556]	@ (20025330 <sif_bbm_init+0x274>)
20025104:	f8df b268 	ldr.w	fp, [pc, #616]	@ 20025370 <sif_bbm_init+0x2b4>
20025108:	0963      	lsrs	r3, r4, #5
2002510a:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20025374 <sif_bbm_init+0x2b8>
2002510e:	6013      	str	r3, [r2, #0]
20025110:	f8cb 4000 	str.w	r4, [fp]
20025114:	1ae4      	subs	r4, r4, r3
20025116:	4b87      	ldr	r3, [pc, #540]	@ (20025334 <sif_bbm_init+0x278>)
20025118:	2218      	movs	r2, #24
2002511a:	f8c9 1000 	str.w	r1, [r9]
2002511e:	4886      	ldr	r0, [pc, #536]	@ (20025338 <sif_bbm_init+0x27c>)
20025120:	2100      	movs	r1, #0
20025122:	601c      	str	r4, [r3, #0]
20025124:	f000 fdc4 	bl	20025cb0 <memset>
20025128:	f44f 6282 	mov.w	r2, #1040	@ 0x410
2002512c:	2100      	movs	r1, #0
2002512e:	4883      	ldr	r0, [pc, #524]	@ (2002533c <sif_bbm_init+0x280>)
20025130:	f000 fdbe 	bl	20025cb0 <memset>
20025134:	4647      	mov	r7, r8
20025136:	4646      	mov	r6, r8
20025138:	f8db 3000 	ldr.w	r3, [fp]
2002513c:	429c      	cmp	r4, r3
2002513e:	db02      	blt.n	20025146 <sif_bbm_init+0x8a>
20025140:	f04f 35ff 	mov.w	r5, #4294967295
20025144:	e064      	b.n	20025210 <sif_bbm_init+0x154>
20025146:	4620      	mov	r0, r4
20025148:	f7fb fbaa 	bl	200208a0 <bbm_get_bb>
2002514c:	4605      	mov	r5, r0
2002514e:	b138      	cbz	r0, 20025160 <sif_bbm_init+0xa4>
20025150:	4b74      	ldr	r3, [pc, #464]	@ (20025324 <sif_bbm_init+0x268>)
20025152:	681b      	ldr	r3, [r3, #0]
20025154:	b113      	cbz	r3, 2002515c <sif_bbm_init+0xa0>
20025156:	4621      	mov	r1, r4
20025158:	4879      	ldr	r0, [pc, #484]	@ (20025340 <sif_bbm_init+0x284>)
2002515a:	4798      	blx	r3
2002515c:	3401      	adds	r4, #1
2002515e:	e7eb      	b.n	20025138 <sif_bbm_init+0x7c>
20025160:	f8da 2000 	ldr.w	r2, [sl]
20025164:	21ff      	movs	r1, #255	@ 0xff
20025166:	f8d9 0000 	ldr.w	r0, [r9]
2002516a:	9205      	str	r2, [sp, #20]
2002516c:	f000 fda0 	bl	20025cb0 <memset>
20025170:	9a05      	ldr	r2, [sp, #20]
20025172:	e9cd 5501 	strd	r5, r5, [sp, #4]
20025176:	9200      	str	r2, [sp, #0]
20025178:	f8d9 3000 	ldr.w	r3, [r9]
2002517c:	462a      	mov	r2, r5
2002517e:	4629      	mov	r1, r5
20025180:	4620      	mov	r0, r4
20025182:	f7fb fb27 	bl	200207d4 <port_read_page>
20025186:	f8da 3000 	ldr.w	r3, [sl]
2002518a:	4298      	cmp	r0, r3
2002518c:	d12e      	bne.n	200251ec <sif_bbm_init+0x130>
2002518e:	f8d9 1000 	ldr.w	r1, [r9]
20025192:	486c      	ldr	r0, [pc, #432]	@ (20025344 <sif_bbm_init+0x288>)
20025194:	680b      	ldr	r3, [r1, #0]
20025196:	b2a2      	uxth	r2, r4
20025198:	4283      	cmp	r3, r0
2002519a:	4b67      	ldr	r3, [pc, #412]	@ (20025338 <sif_bbm_init+0x27c>)
2002519c:	d11f      	bne.n	200251de <sif_bbm_init+0x122>
2002519e:	f991 1007 	ldrsb.w	r1, [r1, #7]
200251a2:	2900      	cmp	r1, #0
200251a4:	bfb5      	itete	lt
200251a6:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
200251aa:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
200251ae:	808a      	strhlt	r2, [r1, #4]
200251b0:	3601      	addge	r6, #1
200251b2:	bfb8      	it	lt
200251b4:	3701      	addlt	r7, #1
200251b6:	eb06 0208 	add.w	r2, r6, r8
200251ba:	443a      	add	r2, r7
200251bc:	2a03      	cmp	r2, #3
200251be:	ddcd      	ble.n	2002515c <sif_bbm_init+0xa0>
200251c0:	2e00      	cmp	r6, #0
200251c2:	f000 8081 	beq.w	200252c8 <sif_bbm_init+0x20c>
200251c6:	2f00      	cmp	r7, #0
200251c8:	d07e      	beq.n	200252c8 <sif_bbm_init+0x20c>
200251ca:	2e01      	cmp	r6, #1
200251cc:	d001      	beq.n	200251d2 <sif_bbm_init+0x116>
200251ce:	2f01      	cmp	r7, #1
200251d0:	d11e      	bne.n	20025210 <sif_bbm_init+0x154>
200251d2:	8819      	ldrh	r1, [r3, #0]
200251d4:	891a      	ldrh	r2, [r3, #8]
200251d6:	b981      	cbnz	r1, 200251fa <sif_bbm_init+0x13e>
200251d8:	801a      	strh	r2, [r3, #0]
200251da:	895a      	ldrh	r2, [r3, #10]
200251dc:	e013      	b.n	20025206 <sif_bbm_init+0x14a>
200251de:	f108 0104 	add.w	r1, r8, #4
200251e2:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
200251e6:	f108 0801 	add.w	r8, r8, #1
200251ea:	e7e4      	b.n	200251b6 <sif_bbm_init+0xfa>
200251ec:	4b4d      	ldr	r3, [pc, #308]	@ (20025324 <sif_bbm_init+0x268>)
200251ee:	681b      	ldr	r3, [r3, #0]
200251f0:	2b00      	cmp	r3, #0
200251f2:	d0b3      	beq.n	2002515c <sif_bbm_init+0xa0>
200251f4:	4854      	ldr	r0, [pc, #336]	@ (20025348 <sif_bbm_init+0x28c>)
200251f6:	1c61      	adds	r1, r4, #1
200251f8:	e7af      	b.n	2002515a <sif_bbm_init+0x9e>
200251fa:	8859      	ldrh	r1, [r3, #2]
200251fc:	b909      	cbnz	r1, 20025202 <sif_bbm_init+0x146>
200251fe:	805a      	strh	r2, [r3, #2]
20025200:	e7eb      	b.n	200251da <sif_bbm_init+0x11e>
20025202:	2a00      	cmp	r2, #0
20025204:	d0e9      	beq.n	200251da <sif_bbm_init+0x11e>
20025206:	8899      	ldrh	r1, [r3, #4]
20025208:	2900      	cmp	r1, #0
2002520a:	d158      	bne.n	200252be <sif_bbm_init+0x202>
2002520c:	809a      	strh	r2, [r3, #4]
2002520e:	2502      	movs	r5, #2
20025210:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 20025324 <sif_bbm_init+0x268>
20025214:	f8d9 4000 	ldr.w	r4, [r9]
20025218:	b124      	cbz	r4, 20025224 <sif_bbm_init+0x168>
2002521a:	4643      	mov	r3, r8
2002521c:	463a      	mov	r2, r7
2002521e:	4631      	mov	r1, r6
20025220:	484a      	ldr	r0, [pc, #296]	@ (2002534c <sif_bbm_init+0x290>)
20025222:	47a0      	blx	r4
20025224:	f8d9 3000 	ldr.w	r3, [r9]
20025228:	b113      	cbz	r3, 20025230 <sif_bbm_init+0x174>
2002522a:	4629      	mov	r1, r5
2002522c:	4848      	ldr	r0, [pc, #288]	@ (20025350 <sif_bbm_init+0x294>)
2002522e:	4798      	blx	r3
20025230:	f035 0002 	bics.w	r0, r5, #2
20025234:	d164      	bne.n	20025300 <sif_bbm_init+0x244>
20025236:	f7ff fccb 	bl	20024bd0 <bbm_get_map_table>
2002523a:	4605      	mov	r5, r0
2002523c:	2001      	movs	r0, #1
2002523e:	f7ff fcc7 	bl	20024bd0 <bbm_get_map_table>
20025242:	f8d9 6000 	ldr.w	r6, [r9]
20025246:	4604      	mov	r4, r0
20025248:	b13e      	cbz	r6, 2002525a <sif_bbm_init+0x19e>
2002524a:	4a3b      	ldr	r2, [pc, #236]	@ (20025338 <sif_bbm_init+0x27c>)
2002524c:	4629      	mov	r1, r5
2002524e:	8a53      	ldrh	r3, [r2, #18]
20025250:	9300      	str	r3, [sp, #0]
20025252:	8a12      	ldrh	r2, [r2, #16]
20025254:	4603      	mov	r3, r0
20025256:	483f      	ldr	r0, [pc, #252]	@ (20025354 <sif_bbm_init+0x298>)
20025258:	47b0      	blx	r6
2002525a:	42a5      	cmp	r5, r4
2002525c:	4c37      	ldr	r4, [pc, #220]	@ (2002533c <sif_bbm_init+0x280>)
2002525e:	dd35      	ble.n	200252cc <sif_bbm_init+0x210>
20025260:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025264:	4621      	mov	r1, r4
20025266:	18a0      	adds	r0, r4, r2
20025268:	f000 fd91 	bl	20025d8e <memcpy>
2002526c:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025270:	2110      	movs	r1, #16
20025272:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025276:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
2002527a:	f504 7002 	add.w	r0, r4, #520	@ 0x208
2002527e:	f7ff fbf3 	bl	20024a68 <bbm_crc_check>
20025282:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20025286:	2001      	movs	r0, #1
20025288:	4b2b      	ldr	r3, [pc, #172]	@ (20025338 <sif_bbm_init+0x27c>)
2002528a:	8a59      	ldrh	r1, [r3, #18]
2002528c:	f7ff fdb8 	bl	20024e00 <bbm_write_talbe.isra.0>
20025290:	6822      	ldr	r2, [r4, #0]
20025292:	4b2c      	ldr	r3, [pc, #176]	@ (20025344 <sif_bbm_init+0x288>)
20025294:	429a      	cmp	r2, r3
20025296:	d12d      	bne.n	200252f4 <sif_bbm_init+0x238>
20025298:	4828      	ldr	r0, [pc, #160]	@ (2002533c <sif_bbm_init+0x280>)
2002529a:	f7ff fb95 	bl	200249c8 <bbm_map_check.part.0>
2002529e:	f8d9 4000 	ldr.w	r4, [r9]
200252a2:	b12c      	cbz	r4, 200252b0 <sif_bbm_init+0x1f4>
200252a4:	4b2c      	ldr	r3, [pc, #176]	@ (20025358 <sif_bbm_init+0x29c>)
200252a6:	4924      	ldr	r1, [pc, #144]	@ (20025338 <sif_bbm_init+0x27c>)
200252a8:	482c      	ldr	r0, [pc, #176]	@ (2002535c <sif_bbm_init+0x2a0>)
200252aa:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
200252ae:	47a0      	blx	r4
200252b0:	f8d9 3000 	ldr.w	r3, [r9]
200252b4:	2b00      	cmp	r3, #0
200252b6:	f43f af10 	beq.w	200250da <sif_bbm_init+0x1e>
200252ba:	4829      	ldr	r0, [pc, #164]	@ (20025360 <sif_bbm_init+0x2a4>)
200252bc:	e70c      	b.n	200250d8 <sif_bbm_init+0x1c>
200252be:	88d9      	ldrh	r1, [r3, #6]
200252c0:	2900      	cmp	r1, #0
200252c2:	d1a4      	bne.n	2002520e <sif_bbm_init+0x152>
200252c4:	80da      	strh	r2, [r3, #6]
200252c6:	e7a2      	b.n	2002520e <sif_bbm_init+0x152>
200252c8:	2501      	movs	r5, #1
200252ca:	e7a1      	b.n	20025210 <sif_bbm_init+0x154>
200252cc:	dae0      	bge.n	20025290 <sif_bbm_init+0x1d4>
200252ce:	f44f 7202 	mov.w	r2, #520	@ 0x208
200252d2:	4620      	mov	r0, r4
200252d4:	18a1      	adds	r1, r4, r2
200252d6:	f000 fd5a 	bl	20025d8e <memcpy>
200252da:	79e3      	ldrb	r3, [r4, #7]
200252dc:	2110      	movs	r1, #16
200252de:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
200252e2:	71e3      	strb	r3, [r4, #7]
200252e4:	4620      	mov	r0, r4
200252e6:	f7ff fbbf 	bl	20024a68 <bbm_crc_check>
200252ea:	4b13      	ldr	r3, [pc, #76]	@ (20025338 <sif_bbm_init+0x27c>)
200252ec:	6120      	str	r0, [r4, #16]
200252ee:	8a19      	ldrh	r1, [r3, #16]
200252f0:	2000      	movs	r0, #0
200252f2:	e7cb      	b.n	2002528c <sif_bbm_init+0x1d0>
200252f4:	f8d9 3000 	ldr.w	r3, [r9]
200252f8:	b10b      	cbz	r3, 200252fe <sif_bbm_init+0x242>
200252fa:	481a      	ldr	r0, [pc, #104]	@ (20025364 <sif_bbm_init+0x2a8>)
200252fc:	4798      	blx	r3
200252fe:	e7fe      	b.n	200252fe <sif_bbm_init+0x242>
20025300:	2d01      	cmp	r5, #1
20025302:	d102      	bne.n	2002530a <sif_bbm_init+0x24e>
20025304:	f7ff fdb8 	bl	20024e78 <bbm_init_table>
20025308:	e7c9      	b.n	2002529e <sif_bbm_init+0x1e2>
2002530a:	f8d9 3000 	ldr.w	r3, [r9]
2002530e:	b11b      	cbz	r3, 20025318 <sif_bbm_init+0x25c>
20025310:	f04f 31ff 	mov.w	r1, #4294967295
20025314:	4814      	ldr	r0, [pc, #80]	@ (20025368 <sif_bbm_init+0x2ac>)
20025316:	4798      	blx	r3
20025318:	e7fe      	b.n	20025318 <sif_bbm_init+0x25c>
2002531a:	f04f 30ff 	mov.w	r0, #4294967295
2002531e:	e6dd      	b.n	200250dc <sif_bbm_init+0x20>
20025320:	2004cab4 	.word	0x2004cab4
20025324:	2004caac 	.word	0x2004caac
20025328:	200268d5 	.word	0x200268d5
2002532c:	200449a0 	.word	0x200449a0
20025330:	2004cabc 	.word	0x2004cabc
20025334:	2004cac0 	.word	0x2004cac0
20025338:	2004ced4 	.word	0x2004ced4
2002533c:	2004cac4 	.word	0x2004cac4
20025340:	20026903 	.word	0x20026903
20025344:	5366424d 	.word	0x5366424d
20025348:	2002690f 	.word	0x2002690f
2002534c:	2002692e 	.word	0x2002692e
20025350:	2002694d 	.word	0x2002694d
20025354:	2002695f 	.word	0x2002695f
20025358:	2004cccc 	.word	0x2004cccc
2002535c:	200269ba 	.word	0x200269ba
20025360:	200269de 	.word	0x200269de
20025364:	20026983 	.word	0x20026983
20025368:	20026999 	.word	0x20026999
2002536c:	2004499c 	.word	0x2004499c
20025370:	2004cab8 	.word	0x2004cab8
20025374:	2004cab0 	.word	0x2004cab0

20025378 <bbm_set_page_size>:
20025378:	4b01      	ldr	r3, [pc, #4]	@ (20025380 <bbm_set_page_size+0x8>)
2002537a:	6018      	str	r0, [r3, #0]
2002537c:	4770      	bx	lr
2002537e:	bf00      	nop
20025380:	2004499c 	.word	0x2004499c

20025384 <bbm_set_blk_size>:
20025384:	4b01      	ldr	r3, [pc, #4]	@ (2002538c <bbm_set_blk_size+0x8>)
20025386:	6018      	str	r0, [r3, #0]
20025388:	4770      	bx	lr
2002538a:	bf00      	nop
2002538c:	200449a0 	.word	0x200449a0

20025390 <sf_crypto_cmac_gen_subkey>:
20025390:	2300      	movs	r3, #0
20025392:	b530      	push	{r4, r5, lr}
20025394:	f100 0210 	add.w	r2, r0, #16
20025398:	f101 0410 	add.w	r4, r1, #16
2002539c:	f812 5d01 	ldrb.w	r5, [r2, #-1]!
200253a0:	ea43 0345 	orr.w	r3, r3, r5, lsl #1
200253a4:	f804 3d01 	strb.w	r3, [r4, #-1]!
200253a8:	7813      	ldrb	r3, [r2, #0]
200253aa:	4282      	cmp	r2, r0
200253ac:	ea4f 13d3 	mov.w	r3, r3, lsr #7
200253b0:	d1f4      	bne.n	2002539c <sf_crypto_cmac_gen_subkey+0xc>
200253b2:	f992 3000 	ldrsb.w	r3, [r2]
200253b6:	2b00      	cmp	r3, #0
200253b8:	bfbe      	ittt	lt
200253ba:	7bcb      	ldrblt	r3, [r1, #15]
200253bc:	f083 0387 	eorlt.w	r3, r3, #135	@ 0x87
200253c0:	73cb      	strblt	r3, [r1, #15]
200253c2:	bd30      	pop	{r4, r5, pc}

200253c4 <sf_crypto_aes_cmac_init>:
200253c4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200253c8:	2a20      	cmp	r2, #32
200253ca:	4604      	mov	r4, r0
200253cc:	460e      	mov	r6, r1
200253ce:	4615      	mov	r5, r2
200253d0:	b08c      	sub	sp, #48	@ 0x30
200253d2:	d12e      	bne.n	20025432 <sf_crypto_aes_cmac_init+0x6e>
200253d4:	b380      	cbz	r0, 20025438 <sf_crypto_aes_cmac_init+0x74>
200253d6:	2710      	movs	r7, #16
200253d8:	ab04      	add	r3, sp, #16
200253da:	6001      	str	r1, [r0, #0]
200253dc:	8082      	strh	r2, [r0, #4]
200253de:	2100      	movs	r1, #0
200253e0:	463a      	mov	r2, r7
200253e2:	4618      	mov	r0, r3
200253e4:	f000 fc64 	bl	20025cb0 <memset>
200253e8:	2300      	movs	r3, #0
200253ea:	f10d 0820 	add.w	r8, sp, #32
200253ee:	4629      	mov	r1, r5
200253f0:	9000      	str	r0, [sp, #0]
200253f2:	461a      	mov	r2, r3
200253f4:	4630      	mov	r0, r6
200253f6:	e9cd 7801 	strd	r7, r8, [sp, #4]
200253fa:	f000 f8da 	bl	200255b2 <sf_crypto_aes_enc_sync>
200253fe:	4605      	mov	r5, r0
20025400:	b100      	cbz	r0, 20025404 <sf_crypto_aes_cmac_init+0x40>
20025402:	e7fe      	b.n	20025402 <sf_crypto_aes_cmac_init+0x3e>
20025404:	1da6      	adds	r6, r4, #6
20025406:	4631      	mov	r1, r6
20025408:	4640      	mov	r0, r8
2002540a:	f7ff ffc1 	bl	20025390 <sf_crypto_cmac_gen_subkey>
2002540e:	4630      	mov	r0, r6
20025410:	f104 0116 	add.w	r1, r4, #22
20025414:	f7ff ffbc 	bl	20025390 <sf_crypto_cmac_gen_subkey>
20025418:	463a      	mov	r2, r7
2002541a:	4629      	mov	r1, r5
2002541c:	f104 0028 	add.w	r0, r4, #40	@ 0x28
20025420:	f000 fc46 	bl	20025cb0 <memset>
20025424:	f240 1301 	movw	r3, #257	@ 0x101
20025428:	8723      	strh	r3, [r4, #56]	@ 0x38
2002542a:	4628      	mov	r0, r5
2002542c:	b00c      	add	sp, #48	@ 0x30
2002542e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025432:	f06f 0502 	mvn.w	r5, #2
20025436:	e7f8      	b.n	2002542a <sf_crypto_aes_cmac_init+0x66>
20025438:	f04f 35ff 	mov.w	r5, #4294967295
2002543c:	e7f5      	b.n	2002542a <sf_crypto_aes_cmac_init+0x66>

2002543e <sf_crypto_aes_cmac_calc>:
2002543e:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20025442:	b089      	sub	sp, #36	@ 0x24
20025444:	460f      	mov	r7, r1
20025446:	4604      	mov	r4, r0
20025448:	9e10      	ldr	r6, [sp, #64]	@ 0x40
2002544a:	b138      	cbz	r0, 2002545c <sf_crypto_aes_cmac_calc+0x1e>
2002544c:	b136      	cbz	r6, 2002545c <sf_crypto_aes_cmac_calc+0x1e>
2002544e:	f890 1039 	ldrb.w	r1, [r0, #57]	@ 0x39
20025452:	2900      	cmp	r1, #0
20025454:	f000 80aa 	beq.w	200255ac <sf_crypto_aes_cmac_calc+0x16e>
20025458:	b11a      	cbz	r2, 20025462 <sf_crypto_aes_cmac_calc+0x24>
2002545a:	b957      	cbnz	r7, 20025472 <sf_crypto_aes_cmac_calc+0x34>
2002545c:	f04f 30ff 	mov.w	r0, #4294967295
20025460:	e0a1      	b.n	200255a6 <sf_crypto_aes_cmac_calc+0x168>
20025462:	f890 1038 	ldrb.w	r1, [r0, #56]	@ 0x38
20025466:	b109      	cbz	r1, 2002546c <sf_crypto_aes_cmac_calc+0x2e>
20025468:	2b00      	cmp	r3, #0
2002546a:	d16e      	bne.n	2002554a <sf_crypto_aes_cmac_calc+0x10c>
2002546c:	f06f 0003 	mvn.w	r0, #3
20025470:	e099      	b.n	200255a6 <sf_crypto_aes_cmac_calc+0x168>
20025472:	f002 000f 	and.w	r0, r2, #15
20025476:	b973      	cbnz	r3, 20025496 <sf_crypto_aes_cmac_calc+0x58>
20025478:	2800      	cmp	r0, #0
2002547a:	d1f7      	bne.n	2002546c <sf_crypto_aes_cmac_calc+0x2e>
2002547c:	e9cd 2601 	strd	r2, r6, [sp, #4]
20025480:	9700      	str	r7, [sp, #0]
20025482:	2303      	movs	r3, #3
20025484:	88a1      	ldrh	r1, [r4, #4]
20025486:	6820      	ldr	r0, [r4, #0]
20025488:	f104 0228 	add.w	r2, r4, #40	@ 0x28
2002548c:	f000 f891 	bl	200255b2 <sf_crypto_aes_enc_sync>
20025490:	2800      	cmp	r0, #0
20025492:	d07b      	beq.n	2002558c <sf_crypto_aes_cmac_calc+0x14e>
20025494:	e7fe      	b.n	20025494 <sf_crypto_aes_cmac_calc+0x56>
20025496:	320f      	adds	r2, #15
20025498:	ea4f 1812 	mov.w	r8, r2, lsr #4
2002549c:	f108 31ff 	add.w	r1, r8, #4294967295
200254a0:	eb07 1101 	add.w	r1, r7, r1, lsl #4
200254a4:	b3c0      	cbz	r0, 20025518 <sf_crypto_aes_cmac_calc+0xda>
200254a6:	f1c0 0910 	rsb	r9, r0, #16
200254aa:	fa1f f989 	uxth.w	r9, r9
200254ae:	f1c9 0510 	rsb	r5, r9, #16
200254b2:	462a      	mov	r2, r5
200254b4:	a804      	add	r0, sp, #16
200254b6:	f000 fc6a 	bl	20025d8e <memcpy>
200254ba:	f105 0320 	add.w	r3, r5, #32
200254be:	eb0d 0203 	add.w	r2, sp, r3
200254c2:	2380      	movs	r3, #128	@ 0x80
200254c4:	f802 3c10 	strb.w	r3, [r2, #-16]
200254c8:	ab08      	add	r3, sp, #32
200254ca:	eba3 0209 	sub.w	r2, r3, r9
200254ce:	2100      	movs	r1, #0
200254d0:	2301      	movs	r3, #1
200254d2:	454b      	cmp	r3, r9
200254d4:	d33f      	bcc.n	20025556 <sf_crypto_aes_cmac_calc+0x118>
200254d6:	aa04      	add	r2, sp, #16
200254d8:	f104 0315 	add.w	r3, r4, #21
200254dc:	f104 0025 	add.w	r0, r4, #37	@ 0x25
200254e0:	7811      	ldrb	r1, [r2, #0]
200254e2:	f813 5f01 	ldrb.w	r5, [r3, #1]!
200254e6:	4069      	eors	r1, r5
200254e8:	4283      	cmp	r3, r0
200254ea:	f802 1b01 	strb.w	r1, [r2], #1
200254ee:	d1f7      	bne.n	200254e0 <sf_crypto_aes_cmac_calc+0xa2>
200254f0:	f1b8 0f01 	cmp.w	r8, #1
200254f4:	f104 0528 	add.w	r5, r4, #40	@ 0x28
200254f8:	d93b      	bls.n	20025572 <sf_crypto_aes_cmac_calc+0x134>
200254fa:	f108 38ff 	add.w	r8, r8, #4294967295
200254fe:	ea4f 1308 	mov.w	r3, r8, lsl #4
20025502:	e9cd 7300 	strd	r7, r3, [sp]
20025506:	9602      	str	r6, [sp, #8]
20025508:	2303      	movs	r3, #3
2002550a:	462a      	mov	r2, r5
2002550c:	88a1      	ldrh	r1, [r4, #4]
2002550e:	6820      	ldr	r0, [r4, #0]
20025510:	f000 f84f 	bl	200255b2 <sf_crypto_aes_enc_sync>
20025514:	b318      	cbz	r0, 2002555e <sf_crypto_aes_cmac_calc+0x120>
20025516:	e7fe      	b.n	20025516 <sf_crypto_aes_cmac_calc+0xd8>
20025518:	460b      	mov	r3, r1
2002551a:	ad04      	add	r5, sp, #16
2002551c:	f101 0c10 	add.w	ip, r1, #16
20025520:	462a      	mov	r2, r5
20025522:	6818      	ldr	r0, [r3, #0]
20025524:	6859      	ldr	r1, [r3, #4]
20025526:	3308      	adds	r3, #8
20025528:	c203      	stmia	r2!, {r0, r1}
2002552a:	4563      	cmp	r3, ip
2002552c:	4615      	mov	r5, r2
2002552e:	d1f7      	bne.n	20025520 <sf_crypto_aes_cmac_calc+0xe2>
20025530:	ab04      	add	r3, sp, #16
20025532:	1d62      	adds	r2, r4, #5
20025534:	f104 0015 	add.w	r0, r4, #21
20025538:	7819      	ldrb	r1, [r3, #0]
2002553a:	f812 5f01 	ldrb.w	r5, [r2, #1]!
2002553e:	4069      	eors	r1, r5
20025540:	4282      	cmp	r2, r0
20025542:	f803 1b01 	strb.w	r1, [r3], #1
20025546:	d1f7      	bne.n	20025538 <sf_crypto_aes_cmac_calc+0xfa>
20025548:	e7d2      	b.n	200254f0 <sf_crypto_aes_cmac_calc+0xb2>
2002554a:	4615      	mov	r5, r2
2002554c:	f04f 0910 	mov.w	r9, #16
20025550:	f04f 0801 	mov.w	r8, #1
20025554:	e7b1      	b.n	200254ba <sf_crypto_aes_cmac_calc+0x7c>
20025556:	f802 1f01 	strb.w	r1, [r2, #1]!
2002555a:	3301      	adds	r3, #1
2002555c:	e7b9      	b.n	200254d2 <sf_crypto_aes_cmac_calc+0x94>
2002555e:	4633      	mov	r3, r6
20025560:	462a      	mov	r2, r5
20025562:	f106 0110 	add.w	r1, r6, #16
20025566:	f853 0b04 	ldr.w	r0, [r3], #4
2002556a:	428b      	cmp	r3, r1
2002556c:	f842 0b04 	str.w	r0, [r2], #4
20025570:	d1f9      	bne.n	20025566 <sf_crypto_aes_cmac_calc+0x128>
20025572:	2310      	movs	r3, #16
20025574:	9301      	str	r3, [sp, #4]
20025576:	446b      	add	r3, sp
20025578:	9300      	str	r3, [sp, #0]
2002557a:	9602      	str	r6, [sp, #8]
2002557c:	2303      	movs	r3, #3
2002557e:	462a      	mov	r2, r5
20025580:	88a1      	ldrh	r1, [r4, #4]
20025582:	6820      	ldr	r0, [r4, #0]
20025584:	f000 f815 	bl	200255b2 <sf_crypto_aes_enc_sync>
20025588:	b100      	cbz	r0, 2002558c <sf_crypto_aes_cmac_calc+0x14e>
2002558a:	e7fe      	b.n	2002558a <sf_crypto_aes_cmac_calc+0x14c>
2002558c:	f104 0328 	add.w	r3, r4, #40	@ 0x28
20025590:	f106 0210 	add.w	r2, r6, #16
20025594:	f856 1b04 	ldr.w	r1, [r6], #4
20025598:	4296      	cmp	r6, r2
2002559a:	f843 1b04 	str.w	r1, [r3], #4
2002559e:	d1f9      	bne.n	20025594 <sf_crypto_aes_cmac_calc+0x156>
200255a0:	2000      	movs	r0, #0
200255a2:	f884 0038 	strb.w	r0, [r4, #56]	@ 0x38
200255a6:	b009      	add	sp, #36	@ 0x24
200255a8:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200255ac:	f06f 0001 	mvn.w	r0, #1
200255b0:	e7f9      	b.n	200255a6 <sf_crypto_aes_cmac_calc+0x168>

200255b2 <sf_crypto_aes_enc_sync>:
200255b2:	b508      	push	{r3, lr}
200255b4:	f7fc fa5a 	bl	20021a6c <HAL_AES_init>
200255b8:	b100      	cbz	r0, 200255bc <sf_crypto_aes_enc_sync+0xa>
200255ba:	e7fe      	b.n	200255ba <sf_crypto_aes_enc_sync+0x8>
200255bc:	2001      	movs	r0, #1
200255be:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
200255c2:	9902      	ldr	r1, [sp, #8]
200255c4:	f7fc fa98 	bl	20021af8 <HAL_AES_run>
200255c8:	b100      	cbz	r0, 200255cc <sf_crypto_aes_enc_sync+0x1a>
200255ca:	e7fe      	b.n	200255ca <sf_crypto_aes_enc_sync+0x18>
200255cc:	bd08      	pop	{r3, pc}
	...

200255d0 <sbrk_aligned>:
200255d0:	b570      	push	{r4, r5, r6, lr}
200255d2:	4e0f      	ldr	r6, [pc, #60]	@ (20025610 <sbrk_aligned+0x40>)
200255d4:	460c      	mov	r4, r1
200255d6:	4605      	mov	r5, r0
200255d8:	6831      	ldr	r1, [r6, #0]
200255da:	b911      	cbnz	r1, 200255e2 <sbrk_aligned+0x12>
200255dc:	f000 fba4 	bl	20025d28 <_sbrk_r>
200255e0:	6030      	str	r0, [r6, #0]
200255e2:	4621      	mov	r1, r4
200255e4:	4628      	mov	r0, r5
200255e6:	f000 fb9f 	bl	20025d28 <_sbrk_r>
200255ea:	1c43      	adds	r3, r0, #1
200255ec:	d103      	bne.n	200255f6 <sbrk_aligned+0x26>
200255ee:	f04f 34ff 	mov.w	r4, #4294967295
200255f2:	4620      	mov	r0, r4
200255f4:	bd70      	pop	{r4, r5, r6, pc}
200255f6:	1cc4      	adds	r4, r0, #3
200255f8:	f024 0403 	bic.w	r4, r4, #3
200255fc:	42a0      	cmp	r0, r4
200255fe:	d0f8      	beq.n	200255f2 <sbrk_aligned+0x22>
20025600:	1a21      	subs	r1, r4, r0
20025602:	4628      	mov	r0, r5
20025604:	f000 fb90 	bl	20025d28 <_sbrk_r>
20025608:	3001      	adds	r0, #1
2002560a:	d1f2      	bne.n	200255f2 <sbrk_aligned+0x22>
2002560c:	e7ef      	b.n	200255ee <sbrk_aligned+0x1e>
2002560e:	bf00      	nop
20025610:	2004ceec 	.word	0x2004ceec

20025614 <_malloc_r>:
20025614:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025618:	1ccd      	adds	r5, r1, #3
2002561a:	4606      	mov	r6, r0
2002561c:	f025 0503 	bic.w	r5, r5, #3
20025620:	3508      	adds	r5, #8
20025622:	2d0c      	cmp	r5, #12
20025624:	bf38      	it	cc
20025626:	250c      	movcc	r5, #12
20025628:	2d00      	cmp	r5, #0
2002562a:	db01      	blt.n	20025630 <_malloc_r+0x1c>
2002562c:	42a9      	cmp	r1, r5
2002562e:	d904      	bls.n	2002563a <_malloc_r+0x26>
20025630:	230c      	movs	r3, #12
20025632:	6033      	str	r3, [r6, #0]
20025634:	2000      	movs	r0, #0
20025636:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002563a:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 20025710 <_malloc_r+0xfc>
2002563e:	f000 f869 	bl	20025714 <__malloc_lock>
20025642:	f8d8 3000 	ldr.w	r3, [r8]
20025646:	461c      	mov	r4, r3
20025648:	bb44      	cbnz	r4, 2002569c <_malloc_r+0x88>
2002564a:	4629      	mov	r1, r5
2002564c:	4630      	mov	r0, r6
2002564e:	f7ff ffbf 	bl	200255d0 <sbrk_aligned>
20025652:	1c43      	adds	r3, r0, #1
20025654:	4604      	mov	r4, r0
20025656:	d158      	bne.n	2002570a <_malloc_r+0xf6>
20025658:	f8d8 4000 	ldr.w	r4, [r8]
2002565c:	4627      	mov	r7, r4
2002565e:	2f00      	cmp	r7, #0
20025660:	d143      	bne.n	200256ea <_malloc_r+0xd6>
20025662:	2c00      	cmp	r4, #0
20025664:	d04b      	beq.n	200256fe <_malloc_r+0xea>
20025666:	6823      	ldr	r3, [r4, #0]
20025668:	4639      	mov	r1, r7
2002566a:	4630      	mov	r0, r6
2002566c:	eb04 0903 	add.w	r9, r4, r3
20025670:	f000 fb5a 	bl	20025d28 <_sbrk_r>
20025674:	4581      	cmp	r9, r0
20025676:	d142      	bne.n	200256fe <_malloc_r+0xea>
20025678:	6821      	ldr	r1, [r4, #0]
2002567a:	4630      	mov	r0, r6
2002567c:	1a6d      	subs	r5, r5, r1
2002567e:	4629      	mov	r1, r5
20025680:	f7ff ffa6 	bl	200255d0 <sbrk_aligned>
20025684:	3001      	adds	r0, #1
20025686:	d03a      	beq.n	200256fe <_malloc_r+0xea>
20025688:	6823      	ldr	r3, [r4, #0]
2002568a:	442b      	add	r3, r5
2002568c:	6023      	str	r3, [r4, #0]
2002568e:	f8d8 3000 	ldr.w	r3, [r8]
20025692:	685a      	ldr	r2, [r3, #4]
20025694:	bb62      	cbnz	r2, 200256f0 <_malloc_r+0xdc>
20025696:	f8c8 7000 	str.w	r7, [r8]
2002569a:	e00f      	b.n	200256bc <_malloc_r+0xa8>
2002569c:	6822      	ldr	r2, [r4, #0]
2002569e:	1b52      	subs	r2, r2, r5
200256a0:	d420      	bmi.n	200256e4 <_malloc_r+0xd0>
200256a2:	2a0b      	cmp	r2, #11
200256a4:	d917      	bls.n	200256d6 <_malloc_r+0xc2>
200256a6:	1961      	adds	r1, r4, r5
200256a8:	42a3      	cmp	r3, r4
200256aa:	6025      	str	r5, [r4, #0]
200256ac:	bf18      	it	ne
200256ae:	6059      	strne	r1, [r3, #4]
200256b0:	6863      	ldr	r3, [r4, #4]
200256b2:	bf08      	it	eq
200256b4:	f8c8 1000 	streq.w	r1, [r8]
200256b8:	5162      	str	r2, [r4, r5]
200256ba:	604b      	str	r3, [r1, #4]
200256bc:	4630      	mov	r0, r6
200256be:	f000 f82f 	bl	20025720 <__malloc_unlock>
200256c2:	f104 000b 	add.w	r0, r4, #11
200256c6:	1d23      	adds	r3, r4, #4
200256c8:	f020 0007 	bic.w	r0, r0, #7
200256cc:	1ac2      	subs	r2, r0, r3
200256ce:	bf1c      	itt	ne
200256d0:	1a1b      	subne	r3, r3, r0
200256d2:	50a3      	strne	r3, [r4, r2]
200256d4:	e7af      	b.n	20025636 <_malloc_r+0x22>
200256d6:	6862      	ldr	r2, [r4, #4]
200256d8:	42a3      	cmp	r3, r4
200256da:	bf0c      	ite	eq
200256dc:	f8c8 2000 	streq.w	r2, [r8]
200256e0:	605a      	strne	r2, [r3, #4]
200256e2:	e7eb      	b.n	200256bc <_malloc_r+0xa8>
200256e4:	4623      	mov	r3, r4
200256e6:	6864      	ldr	r4, [r4, #4]
200256e8:	e7ae      	b.n	20025648 <_malloc_r+0x34>
200256ea:	463c      	mov	r4, r7
200256ec:	687f      	ldr	r7, [r7, #4]
200256ee:	e7b6      	b.n	2002565e <_malloc_r+0x4a>
200256f0:	461a      	mov	r2, r3
200256f2:	685b      	ldr	r3, [r3, #4]
200256f4:	42a3      	cmp	r3, r4
200256f6:	d1fb      	bne.n	200256f0 <_malloc_r+0xdc>
200256f8:	2300      	movs	r3, #0
200256fa:	6053      	str	r3, [r2, #4]
200256fc:	e7de      	b.n	200256bc <_malloc_r+0xa8>
200256fe:	230c      	movs	r3, #12
20025700:	4630      	mov	r0, r6
20025702:	6033      	str	r3, [r6, #0]
20025704:	f000 f80c 	bl	20025720 <__malloc_unlock>
20025708:	e794      	b.n	20025634 <_malloc_r+0x20>
2002570a:	6005      	str	r5, [r0, #0]
2002570c:	e7d6      	b.n	200256bc <_malloc_r+0xa8>
2002570e:	bf00      	nop
20025710:	2004cef0 	.word	0x2004cef0

20025714 <__malloc_lock>:
20025714:	4801      	ldr	r0, [pc, #4]	@ (2002571c <__malloc_lock+0x8>)
20025716:	f000 bb2a 	b.w	20025d6e <__retarget_lock_acquire_recursive>
2002571a:	bf00      	nop
2002571c:	2004d034 	.word	0x2004d034

20025720 <__malloc_unlock>:
20025720:	4801      	ldr	r0, [pc, #4]	@ (20025728 <__malloc_unlock+0x8>)
20025722:	f000 bb25 	b.w	20025d70 <__retarget_lock_release_recursive>
20025726:	bf00      	nop
20025728:	2004d034 	.word	0x2004d034

2002572c <__sflush_r>:
2002572c:	f9b1 200c 	ldrsh.w	r2, [r1, #12]
20025730:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025734:	0716      	lsls	r6, r2, #28
20025736:	4605      	mov	r5, r0
20025738:	460c      	mov	r4, r1
2002573a:	d451      	bmi.n	200257e0 <__sflush_r+0xb4>
2002573c:	684b      	ldr	r3, [r1, #4]
2002573e:	2b00      	cmp	r3, #0
20025740:	dc02      	bgt.n	20025748 <__sflush_r+0x1c>
20025742:	6c0b      	ldr	r3, [r1, #64]	@ 0x40
20025744:	2b00      	cmp	r3, #0
20025746:	dd49      	ble.n	200257dc <__sflush_r+0xb0>
20025748:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
2002574a:	2e00      	cmp	r6, #0
2002574c:	d046      	beq.n	200257dc <__sflush_r+0xb0>
2002574e:	2300      	movs	r3, #0
20025750:	f412 5280 	ands.w	r2, r2, #4096	@ 0x1000
20025754:	682f      	ldr	r7, [r5, #0]
20025756:	602b      	str	r3, [r5, #0]
20025758:	d031      	beq.n	200257be <__sflush_r+0x92>
2002575a:	6d62      	ldr	r2, [r4, #84]	@ 0x54
2002575c:	89a3      	ldrh	r3, [r4, #12]
2002575e:	0759      	lsls	r1, r3, #29
20025760:	d505      	bpl.n	2002576e <__sflush_r+0x42>
20025762:	6863      	ldr	r3, [r4, #4]
20025764:	1ad2      	subs	r2, r2, r3
20025766:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20025768:	b10b      	cbz	r3, 2002576e <__sflush_r+0x42>
2002576a:	6c23      	ldr	r3, [r4, #64]	@ 0x40
2002576c:	1ad2      	subs	r2, r2, r3
2002576e:	2300      	movs	r3, #0
20025770:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025772:	6a21      	ldr	r1, [r4, #32]
20025774:	4628      	mov	r0, r5
20025776:	47b0      	blx	r6
20025778:	1c42      	adds	r2, r0, #1
2002577a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002577e:	d106      	bne.n	2002578e <__sflush_r+0x62>
20025780:	6829      	ldr	r1, [r5, #0]
20025782:	291d      	cmp	r1, #29
20025784:	d845      	bhi.n	20025812 <__sflush_r+0xe6>
20025786:	4a28      	ldr	r2, [pc, #160]	@ (20025828 <__sflush_r+0xfc>)
20025788:	40ca      	lsrs	r2, r1
2002578a:	07d6      	lsls	r6, r2, #31
2002578c:	d541      	bpl.n	20025812 <__sflush_r+0xe6>
2002578e:	2200      	movs	r2, #0
20025790:	04d9      	lsls	r1, r3, #19
20025792:	6062      	str	r2, [r4, #4]
20025794:	6922      	ldr	r2, [r4, #16]
20025796:	6022      	str	r2, [r4, #0]
20025798:	d504      	bpl.n	200257a4 <__sflush_r+0x78>
2002579a:	1c42      	adds	r2, r0, #1
2002579c:	d101      	bne.n	200257a2 <__sflush_r+0x76>
2002579e:	682b      	ldr	r3, [r5, #0]
200257a0:	b903      	cbnz	r3, 200257a4 <__sflush_r+0x78>
200257a2:	6560      	str	r0, [r4, #84]	@ 0x54
200257a4:	6b61      	ldr	r1, [r4, #52]	@ 0x34
200257a6:	602f      	str	r7, [r5, #0]
200257a8:	b1c1      	cbz	r1, 200257dc <__sflush_r+0xb0>
200257aa:	f104 0344 	add.w	r3, r4, #68	@ 0x44
200257ae:	4299      	cmp	r1, r3
200257b0:	d002      	beq.n	200257b8 <__sflush_r+0x8c>
200257b2:	4628      	mov	r0, r5
200257b4:	f000 faf8 	bl	20025da8 <_free_r>
200257b8:	2300      	movs	r3, #0
200257ba:	6363      	str	r3, [r4, #52]	@ 0x34
200257bc:	e00e      	b.n	200257dc <__sflush_r+0xb0>
200257be:	2301      	movs	r3, #1
200257c0:	6a21      	ldr	r1, [r4, #32]
200257c2:	4628      	mov	r0, r5
200257c4:	47b0      	blx	r6
200257c6:	4602      	mov	r2, r0
200257c8:	1c50      	adds	r0, r2, #1
200257ca:	d1c7      	bne.n	2002575c <__sflush_r+0x30>
200257cc:	682b      	ldr	r3, [r5, #0]
200257ce:	2b00      	cmp	r3, #0
200257d0:	d0c4      	beq.n	2002575c <__sflush_r+0x30>
200257d2:	2b1d      	cmp	r3, #29
200257d4:	d001      	beq.n	200257da <__sflush_r+0xae>
200257d6:	2b16      	cmp	r3, #22
200257d8:	d119      	bne.n	2002580e <__sflush_r+0xe2>
200257da:	602f      	str	r7, [r5, #0]
200257dc:	2000      	movs	r0, #0
200257de:	e01d      	b.n	2002581c <__sflush_r+0xf0>
200257e0:	690f      	ldr	r7, [r1, #16]
200257e2:	2f00      	cmp	r7, #0
200257e4:	d0fa      	beq.n	200257dc <__sflush_r+0xb0>
200257e6:	0793      	lsls	r3, r2, #30
200257e8:	680e      	ldr	r6, [r1, #0]
200257ea:	600f      	str	r7, [r1, #0]
200257ec:	bf0c      	ite	eq
200257ee:	694b      	ldreq	r3, [r1, #20]
200257f0:	2300      	movne	r3, #0
200257f2:	eba6 0807 	sub.w	r8, r6, r7
200257f6:	608b      	str	r3, [r1, #8]
200257f8:	f1b8 0f00 	cmp.w	r8, #0
200257fc:	ddee      	ble.n	200257dc <__sflush_r+0xb0>
200257fe:	4643      	mov	r3, r8
20025800:	463a      	mov	r2, r7
20025802:	6a21      	ldr	r1, [r4, #32]
20025804:	4628      	mov	r0, r5
20025806:	6aa6      	ldr	r6, [r4, #40]	@ 0x28
20025808:	47b0      	blx	r6
2002580a:	2800      	cmp	r0, #0
2002580c:	dc08      	bgt.n	20025820 <__sflush_r+0xf4>
2002580e:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025812:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
20025816:	f04f 30ff 	mov.w	r0, #4294967295
2002581a:	81a3      	strh	r3, [r4, #12]
2002581c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025820:	4407      	add	r7, r0
20025822:	eba8 0800 	sub.w	r8, r8, r0
20025826:	e7e7      	b.n	200257f8 <__sflush_r+0xcc>
20025828:	20400001 	.word	0x20400001

2002582c <_fflush_r>:
2002582c:	b538      	push	{r3, r4, r5, lr}
2002582e:	690b      	ldr	r3, [r1, #16]
20025830:	4605      	mov	r5, r0
20025832:	460c      	mov	r4, r1
20025834:	b913      	cbnz	r3, 2002583c <_fflush_r+0x10>
20025836:	2500      	movs	r5, #0
20025838:	4628      	mov	r0, r5
2002583a:	bd38      	pop	{r3, r4, r5, pc}
2002583c:	b118      	cbz	r0, 20025846 <_fflush_r+0x1a>
2002583e:	6a03      	ldr	r3, [r0, #32]
20025840:	b90b      	cbnz	r3, 20025846 <_fflush_r+0x1a>
20025842:	f000 f8a9 	bl	20025998 <__sinit>
20025846:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002584a:	2b00      	cmp	r3, #0
2002584c:	d0f3      	beq.n	20025836 <_fflush_r+0xa>
2002584e:	6e62      	ldr	r2, [r4, #100]	@ 0x64
20025850:	07d0      	lsls	r0, r2, #31
20025852:	d404      	bmi.n	2002585e <_fflush_r+0x32>
20025854:	0599      	lsls	r1, r3, #22
20025856:	d402      	bmi.n	2002585e <_fflush_r+0x32>
20025858:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002585a:	f000 fa88 	bl	20025d6e <__retarget_lock_acquire_recursive>
2002585e:	4628      	mov	r0, r5
20025860:	4621      	mov	r1, r4
20025862:	f7ff ff63 	bl	2002572c <__sflush_r>
20025866:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025868:	4605      	mov	r5, r0
2002586a:	07da      	lsls	r2, r3, #31
2002586c:	d4e4      	bmi.n	20025838 <_fflush_r+0xc>
2002586e:	89a3      	ldrh	r3, [r4, #12]
20025870:	059b      	lsls	r3, r3, #22
20025872:	d4e1      	bmi.n	20025838 <_fflush_r+0xc>
20025874:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025876:	f000 fa7b 	bl	20025d70 <__retarget_lock_release_recursive>
2002587a:	e7dd      	b.n	20025838 <_fflush_r+0xc>

2002587c <std>:
2002587c:	2300      	movs	r3, #0
2002587e:	b510      	push	{r4, lr}
20025880:	4604      	mov	r4, r0
20025882:	6083      	str	r3, [r0, #8]
20025884:	8181      	strh	r1, [r0, #12]
20025886:	4619      	mov	r1, r3
20025888:	6643      	str	r3, [r0, #100]	@ 0x64
2002588a:	81c2      	strh	r2, [r0, #14]
2002588c:	2208      	movs	r2, #8
2002588e:	6183      	str	r3, [r0, #24]
20025890:	e9c0 3300 	strd	r3, r3, [r0]
20025894:	e9c0 3304 	strd	r3, r3, [r0, #16]
20025898:	305c      	adds	r0, #92	@ 0x5c
2002589a:	f000 fa09 	bl	20025cb0 <memset>
2002589e:	4b0d      	ldr	r3, [pc, #52]	@ (200258d4 <std+0x58>)
200258a0:	6224      	str	r4, [r4, #32]
200258a2:	6263      	str	r3, [r4, #36]	@ 0x24
200258a4:	4b0c      	ldr	r3, [pc, #48]	@ (200258d8 <std+0x5c>)
200258a6:	62a3      	str	r3, [r4, #40]	@ 0x28
200258a8:	4b0c      	ldr	r3, [pc, #48]	@ (200258dc <std+0x60>)
200258aa:	62e3      	str	r3, [r4, #44]	@ 0x2c
200258ac:	4b0c      	ldr	r3, [pc, #48]	@ (200258e0 <std+0x64>)
200258ae:	6323      	str	r3, [r4, #48]	@ 0x30
200258b0:	4b0c      	ldr	r3, [pc, #48]	@ (200258e4 <std+0x68>)
200258b2:	429c      	cmp	r4, r3
200258b4:	d006      	beq.n	200258c4 <std+0x48>
200258b6:	f103 0268 	add.w	r2, r3, #104	@ 0x68
200258ba:	4294      	cmp	r4, r2
200258bc:	d002      	beq.n	200258c4 <std+0x48>
200258be:	33d0      	adds	r3, #208	@ 0xd0
200258c0:	429c      	cmp	r4, r3
200258c2:	d105      	bne.n	200258d0 <std+0x54>
200258c4:	f104 0058 	add.w	r0, r4, #88	@ 0x58
200258c8:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200258cc:	f000 ba4e 	b.w	20025d6c <__retarget_lock_init_recursive>
200258d0:	bd10      	pop	{r4, pc}
200258d2:	bf00      	nop
200258d4:	20025ae5 	.word	0x20025ae5
200258d8:	20025b07 	.word	0x20025b07
200258dc:	20025b3f 	.word	0x20025b3f
200258e0:	20025b65 	.word	0x20025b65
200258e4:	2004cef4 	.word	0x2004cef4

200258e8 <stdio_exit_handler>:
200258e8:	4a02      	ldr	r2, [pc, #8]	@ (200258f4 <stdio_exit_handler+0xc>)
200258ea:	4903      	ldr	r1, [pc, #12]	@ (200258f8 <stdio_exit_handler+0x10>)
200258ec:	4803      	ldr	r0, [pc, #12]	@ (200258fc <stdio_exit_handler+0x14>)
200258ee:	f000 b86b 	b.w	200259c8 <_fwalk_sglue>
200258f2:	bf00      	nop
200258f4:	200449a4 	.word	0x200449a4
200258f8:	2002582d 	.word	0x2002582d
200258fc:	200449b4 	.word	0x200449b4

20025900 <cleanup_stdio>:
20025900:	6841      	ldr	r1, [r0, #4]
20025902:	4b0c      	ldr	r3, [pc, #48]	@ (20025934 <cleanup_stdio+0x34>)
20025904:	4299      	cmp	r1, r3
20025906:	b510      	push	{r4, lr}
20025908:	4604      	mov	r4, r0
2002590a:	d001      	beq.n	20025910 <cleanup_stdio+0x10>
2002590c:	f7ff ff8e 	bl	2002582c <_fflush_r>
20025910:	68a1      	ldr	r1, [r4, #8]
20025912:	4b09      	ldr	r3, [pc, #36]	@ (20025938 <cleanup_stdio+0x38>)
20025914:	4299      	cmp	r1, r3
20025916:	d002      	beq.n	2002591e <cleanup_stdio+0x1e>
20025918:	4620      	mov	r0, r4
2002591a:	f7ff ff87 	bl	2002582c <_fflush_r>
2002591e:	68e1      	ldr	r1, [r4, #12]
20025920:	4b06      	ldr	r3, [pc, #24]	@ (2002593c <cleanup_stdio+0x3c>)
20025922:	4299      	cmp	r1, r3
20025924:	d004      	beq.n	20025930 <cleanup_stdio+0x30>
20025926:	4620      	mov	r0, r4
20025928:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002592c:	f7ff bf7e 	b.w	2002582c <_fflush_r>
20025930:	bd10      	pop	{r4, pc}
20025932:	bf00      	nop
20025934:	2004cef4 	.word	0x2004cef4
20025938:	2004cf5c 	.word	0x2004cf5c
2002593c:	2004cfc4 	.word	0x2004cfc4

20025940 <global_stdio_init.part.0>:
20025940:	4b0c      	ldr	r3, [pc, #48]	@ (20025974 <global_stdio_init.part.0+0x34>)
20025942:	2104      	movs	r1, #4
20025944:	4a0c      	ldr	r2, [pc, #48]	@ (20025978 <global_stdio_init.part.0+0x38>)
20025946:	480d      	ldr	r0, [pc, #52]	@ (2002597c <global_stdio_init.part.0+0x3c>)
20025948:	b510      	push	{r4, lr}
2002594a:	601a      	str	r2, [r3, #0]
2002594c:	2200      	movs	r2, #0
2002594e:	f7ff ff95 	bl	2002587c <std>
20025952:	4b0a      	ldr	r3, [pc, #40]	@ (2002597c <global_stdio_init.part.0+0x3c>)
20025954:	2201      	movs	r2, #1
20025956:	2109      	movs	r1, #9
20025958:	461c      	mov	r4, r3
2002595a:	f103 0068 	add.w	r0, r3, #104	@ 0x68
2002595e:	f7ff ff8d 	bl	2002587c <std>
20025962:	2202      	movs	r2, #2
20025964:	f104 00d0 	add.w	r0, r4, #208	@ 0xd0
20025968:	2112      	movs	r1, #18
2002596a:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002596e:	f7ff bf85 	b.w	2002587c <std>
20025972:	bf00      	nop
20025974:	2004d02c 	.word	0x2004d02c
20025978:	200258e9 	.word	0x200258e9
2002597c:	2004cef4 	.word	0x2004cef4

20025980 <__sfp_lock_acquire>:
20025980:	4801      	ldr	r0, [pc, #4]	@ (20025988 <__sfp_lock_acquire+0x8>)
20025982:	f000 b9f4 	b.w	20025d6e <__retarget_lock_acquire_recursive>
20025986:	bf00      	nop
20025988:	2004d035 	.word	0x2004d035

2002598c <__sfp_lock_release>:
2002598c:	4801      	ldr	r0, [pc, #4]	@ (20025994 <__sfp_lock_release+0x8>)
2002598e:	f000 b9ef 	b.w	20025d70 <__retarget_lock_release_recursive>
20025992:	bf00      	nop
20025994:	2004d035 	.word	0x2004d035

20025998 <__sinit>:
20025998:	b510      	push	{r4, lr}
2002599a:	4604      	mov	r4, r0
2002599c:	f7ff fff0 	bl	20025980 <__sfp_lock_acquire>
200259a0:	6a23      	ldr	r3, [r4, #32]
200259a2:	b11b      	cbz	r3, 200259ac <__sinit+0x14>
200259a4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200259a8:	f7ff bff0 	b.w	2002598c <__sfp_lock_release>
200259ac:	4b04      	ldr	r3, [pc, #16]	@ (200259c0 <__sinit+0x28>)
200259ae:	6223      	str	r3, [r4, #32]
200259b0:	4b04      	ldr	r3, [pc, #16]	@ (200259c4 <__sinit+0x2c>)
200259b2:	681b      	ldr	r3, [r3, #0]
200259b4:	2b00      	cmp	r3, #0
200259b6:	d1f5      	bne.n	200259a4 <__sinit+0xc>
200259b8:	f7ff ffc2 	bl	20025940 <global_stdio_init.part.0>
200259bc:	e7f2      	b.n	200259a4 <__sinit+0xc>
200259be:	bf00      	nop
200259c0:	20025901 	.word	0x20025901
200259c4:	2004d02c 	.word	0x2004d02c

200259c8 <_fwalk_sglue>:
200259c8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200259cc:	4607      	mov	r7, r0
200259ce:	4688      	mov	r8, r1
200259d0:	4614      	mov	r4, r2
200259d2:	2600      	movs	r6, #0
200259d4:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
200259d8:	f1b9 0901 	subs.w	r9, r9, #1
200259dc:	d505      	bpl.n	200259ea <_fwalk_sglue+0x22>
200259de:	6824      	ldr	r4, [r4, #0]
200259e0:	2c00      	cmp	r4, #0
200259e2:	d1f7      	bne.n	200259d4 <_fwalk_sglue+0xc>
200259e4:	4630      	mov	r0, r6
200259e6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200259ea:	89ab      	ldrh	r3, [r5, #12]
200259ec:	2b01      	cmp	r3, #1
200259ee:	d907      	bls.n	20025a00 <_fwalk_sglue+0x38>
200259f0:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
200259f4:	3301      	adds	r3, #1
200259f6:	d003      	beq.n	20025a00 <_fwalk_sglue+0x38>
200259f8:	4629      	mov	r1, r5
200259fa:	4638      	mov	r0, r7
200259fc:	47c0      	blx	r8
200259fe:	4306      	orrs	r6, r0
20025a00:	3568      	adds	r5, #104	@ 0x68
20025a02:	e7e9      	b.n	200259d8 <_fwalk_sglue+0x10>

20025a04 <iprintf>:
20025a04:	b40f      	push	{r0, r1, r2, r3}
20025a06:	b507      	push	{r0, r1, r2, lr}
20025a08:	4906      	ldr	r1, [pc, #24]	@ (20025a24 <iprintf+0x20>)
20025a0a:	ab04      	add	r3, sp, #16
20025a0c:	6808      	ldr	r0, [r1, #0]
20025a0e:	f853 2b04 	ldr.w	r2, [r3], #4
20025a12:	6881      	ldr	r1, [r0, #8]
20025a14:	9301      	str	r3, [sp, #4]
20025a16:	f000 fa3b 	bl	20025e90 <_vfiprintf_r>
20025a1a:	b003      	add	sp, #12
20025a1c:	f85d eb04 	ldr.w	lr, [sp], #4
20025a20:	b004      	add	sp, #16
20025a22:	4770      	bx	lr
20025a24:	200449b0 	.word	0x200449b0

20025a28 <_puts_r>:
20025a28:	6a03      	ldr	r3, [r0, #32]
20025a2a:	b570      	push	{r4, r5, r6, lr}
20025a2c:	4605      	mov	r5, r0
20025a2e:	460e      	mov	r6, r1
20025a30:	6884      	ldr	r4, [r0, #8]
20025a32:	b90b      	cbnz	r3, 20025a38 <_puts_r+0x10>
20025a34:	f7ff ffb0 	bl	20025998 <__sinit>
20025a38:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025a3a:	07db      	lsls	r3, r3, #31
20025a3c:	d405      	bmi.n	20025a4a <_puts_r+0x22>
20025a3e:	89a3      	ldrh	r3, [r4, #12]
20025a40:	0598      	lsls	r0, r3, #22
20025a42:	d402      	bmi.n	20025a4a <_puts_r+0x22>
20025a44:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025a46:	f000 f992 	bl	20025d6e <__retarget_lock_acquire_recursive>
20025a4a:	89a3      	ldrh	r3, [r4, #12]
20025a4c:	0719      	lsls	r1, r3, #28
20025a4e:	d502      	bpl.n	20025a56 <_puts_r+0x2e>
20025a50:	6923      	ldr	r3, [r4, #16]
20025a52:	2b00      	cmp	r3, #0
20025a54:	d135      	bne.n	20025ac2 <_puts_r+0x9a>
20025a56:	4621      	mov	r1, r4
20025a58:	4628      	mov	r0, r5
20025a5a:	f000 f8c5 	bl	20025be8 <__swsetup_r>
20025a5e:	b380      	cbz	r0, 20025ac2 <_puts_r+0x9a>
20025a60:	f04f 35ff 	mov.w	r5, #4294967295
20025a64:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025a66:	07da      	lsls	r2, r3, #31
20025a68:	d405      	bmi.n	20025a76 <_puts_r+0x4e>
20025a6a:	89a3      	ldrh	r3, [r4, #12]
20025a6c:	059b      	lsls	r3, r3, #22
20025a6e:	d402      	bmi.n	20025a76 <_puts_r+0x4e>
20025a70:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025a72:	f000 f97d 	bl	20025d70 <__retarget_lock_release_recursive>
20025a76:	4628      	mov	r0, r5
20025a78:	bd70      	pop	{r4, r5, r6, pc}
20025a7a:	2b00      	cmp	r3, #0
20025a7c:	da04      	bge.n	20025a88 <_puts_r+0x60>
20025a7e:	69a2      	ldr	r2, [r4, #24]
20025a80:	4293      	cmp	r3, r2
20025a82:	db17      	blt.n	20025ab4 <_puts_r+0x8c>
20025a84:	290a      	cmp	r1, #10
20025a86:	d015      	beq.n	20025ab4 <_puts_r+0x8c>
20025a88:	6823      	ldr	r3, [r4, #0]
20025a8a:	1c5a      	adds	r2, r3, #1
20025a8c:	6022      	str	r2, [r4, #0]
20025a8e:	7019      	strb	r1, [r3, #0]
20025a90:	68a3      	ldr	r3, [r4, #8]
20025a92:	f816 1f01 	ldrb.w	r1, [r6, #1]!
20025a96:	3b01      	subs	r3, #1
20025a98:	60a3      	str	r3, [r4, #8]
20025a9a:	2900      	cmp	r1, #0
20025a9c:	d1ed      	bne.n	20025a7a <_puts_r+0x52>
20025a9e:	2b00      	cmp	r3, #0
20025aa0:	da11      	bge.n	20025ac6 <_puts_r+0x9e>
20025aa2:	4622      	mov	r2, r4
20025aa4:	210a      	movs	r1, #10
20025aa6:	4628      	mov	r0, r5
20025aa8:	f000 f860 	bl	20025b6c <__swbuf_r>
20025aac:	3001      	adds	r0, #1
20025aae:	d0d7      	beq.n	20025a60 <_puts_r+0x38>
20025ab0:	250a      	movs	r5, #10
20025ab2:	e7d7      	b.n	20025a64 <_puts_r+0x3c>
20025ab4:	4622      	mov	r2, r4
20025ab6:	4628      	mov	r0, r5
20025ab8:	f000 f858 	bl	20025b6c <__swbuf_r>
20025abc:	3001      	adds	r0, #1
20025abe:	d1e7      	bne.n	20025a90 <_puts_r+0x68>
20025ac0:	e7ce      	b.n	20025a60 <_puts_r+0x38>
20025ac2:	3e01      	subs	r6, #1
20025ac4:	e7e4      	b.n	20025a90 <_puts_r+0x68>
20025ac6:	6823      	ldr	r3, [r4, #0]
20025ac8:	1c5a      	adds	r2, r3, #1
20025aca:	6022      	str	r2, [r4, #0]
20025acc:	220a      	movs	r2, #10
20025ace:	701a      	strb	r2, [r3, #0]
20025ad0:	e7ee      	b.n	20025ab0 <_puts_r+0x88>
	...

20025ad4 <puts>:
20025ad4:	4b02      	ldr	r3, [pc, #8]	@ (20025ae0 <puts+0xc>)
20025ad6:	4601      	mov	r1, r0
20025ad8:	6818      	ldr	r0, [r3, #0]
20025ada:	f7ff bfa5 	b.w	20025a28 <_puts_r>
20025ade:	bf00      	nop
20025ae0:	200449b0 	.word	0x200449b0

20025ae4 <__sread>:
20025ae4:	b510      	push	{r4, lr}
20025ae6:	460c      	mov	r4, r1
20025ae8:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025aec:	f000 f90a 	bl	20025d04 <_read_r>
20025af0:	2800      	cmp	r0, #0
20025af2:	bfab      	itete	ge
20025af4:	6d63      	ldrge	r3, [r4, #84]	@ 0x54
20025af6:	89a3      	ldrhlt	r3, [r4, #12]
20025af8:	181b      	addge	r3, r3, r0
20025afa:	f423 5380 	biclt.w	r3, r3, #4096	@ 0x1000
20025afe:	bfac      	ite	ge
20025b00:	6563      	strge	r3, [r4, #84]	@ 0x54
20025b02:	81a3      	strhlt	r3, [r4, #12]
20025b04:	bd10      	pop	{r4, pc}

20025b06 <__swrite>:
20025b06:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025b0a:	461f      	mov	r7, r3
20025b0c:	898b      	ldrh	r3, [r1, #12]
20025b0e:	4605      	mov	r5, r0
20025b10:	460c      	mov	r4, r1
20025b12:	05db      	lsls	r3, r3, #23
20025b14:	4616      	mov	r6, r2
20025b16:	d505      	bpl.n	20025b24 <__swrite+0x1e>
20025b18:	2302      	movs	r3, #2
20025b1a:	2200      	movs	r2, #0
20025b1c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025b20:	f000 f8de 	bl	20025ce0 <_lseek_r>
20025b24:	89a3      	ldrh	r3, [r4, #12]
20025b26:	4632      	mov	r2, r6
20025b28:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20025b2c:	4628      	mov	r0, r5
20025b2e:	f423 5380 	bic.w	r3, r3, #4096	@ 0x1000
20025b32:	81a3      	strh	r3, [r4, #12]
20025b34:	463b      	mov	r3, r7
20025b36:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
20025b3a:	f000 b905 	b.w	20025d48 <_write_r>

20025b3e <__sseek>:
20025b3e:	b510      	push	{r4, lr}
20025b40:	460c      	mov	r4, r1
20025b42:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025b46:	f000 f8cb 	bl	20025ce0 <_lseek_r>
20025b4a:	1c42      	adds	r2, r0, #1
20025b4c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025b50:	bf15      	itete	ne
20025b52:	6560      	strne	r0, [r4, #84]	@ 0x54
20025b54:	f423 5380 	biceq.w	r3, r3, #4096	@ 0x1000
20025b58:	f443 5380 	orrne.w	r3, r3, #4096	@ 0x1000
20025b5c:	81a3      	strheq	r3, [r4, #12]
20025b5e:	bf18      	it	ne
20025b60:	81a3      	strhne	r3, [r4, #12]
20025b62:	bd10      	pop	{r4, pc}

20025b64 <__sclose>:
20025b64:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025b68:	f000 b8aa 	b.w	20025cc0 <_close_r>

20025b6c <__swbuf_r>:
20025b6c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025b6e:	460e      	mov	r6, r1
20025b70:	4614      	mov	r4, r2
20025b72:	4605      	mov	r5, r0
20025b74:	b118      	cbz	r0, 20025b7e <__swbuf_r+0x12>
20025b76:	6a03      	ldr	r3, [r0, #32]
20025b78:	b90b      	cbnz	r3, 20025b7e <__swbuf_r+0x12>
20025b7a:	f7ff ff0d 	bl	20025998 <__sinit>
20025b7e:	69a3      	ldr	r3, [r4, #24]
20025b80:	60a3      	str	r3, [r4, #8]
20025b82:	89a3      	ldrh	r3, [r4, #12]
20025b84:	071a      	lsls	r2, r3, #28
20025b86:	d501      	bpl.n	20025b8c <__swbuf_r+0x20>
20025b88:	6923      	ldr	r3, [r4, #16]
20025b8a:	b943      	cbnz	r3, 20025b9e <__swbuf_r+0x32>
20025b8c:	4621      	mov	r1, r4
20025b8e:	4628      	mov	r0, r5
20025b90:	f000 f82a 	bl	20025be8 <__swsetup_r>
20025b94:	b118      	cbz	r0, 20025b9e <__swbuf_r+0x32>
20025b96:	f04f 37ff 	mov.w	r7, #4294967295
20025b9a:	4638      	mov	r0, r7
20025b9c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20025b9e:	6823      	ldr	r3, [r4, #0]
20025ba0:	b2f6      	uxtb	r6, r6
20025ba2:	6922      	ldr	r2, [r4, #16]
20025ba4:	4637      	mov	r7, r6
20025ba6:	1a98      	subs	r0, r3, r2
20025ba8:	6963      	ldr	r3, [r4, #20]
20025baa:	4283      	cmp	r3, r0
20025bac:	dc05      	bgt.n	20025bba <__swbuf_r+0x4e>
20025bae:	4621      	mov	r1, r4
20025bb0:	4628      	mov	r0, r5
20025bb2:	f7ff fe3b 	bl	2002582c <_fflush_r>
20025bb6:	2800      	cmp	r0, #0
20025bb8:	d1ed      	bne.n	20025b96 <__swbuf_r+0x2a>
20025bba:	68a3      	ldr	r3, [r4, #8]
20025bbc:	3b01      	subs	r3, #1
20025bbe:	60a3      	str	r3, [r4, #8]
20025bc0:	6823      	ldr	r3, [r4, #0]
20025bc2:	1c5a      	adds	r2, r3, #1
20025bc4:	6022      	str	r2, [r4, #0]
20025bc6:	701e      	strb	r6, [r3, #0]
20025bc8:	1c43      	adds	r3, r0, #1
20025bca:	6962      	ldr	r2, [r4, #20]
20025bcc:	429a      	cmp	r2, r3
20025bce:	d004      	beq.n	20025bda <__swbuf_r+0x6e>
20025bd0:	89a3      	ldrh	r3, [r4, #12]
20025bd2:	07db      	lsls	r3, r3, #31
20025bd4:	d5e1      	bpl.n	20025b9a <__swbuf_r+0x2e>
20025bd6:	2e0a      	cmp	r6, #10
20025bd8:	d1df      	bne.n	20025b9a <__swbuf_r+0x2e>
20025bda:	4621      	mov	r1, r4
20025bdc:	4628      	mov	r0, r5
20025bde:	f7ff fe25 	bl	2002582c <_fflush_r>
20025be2:	2800      	cmp	r0, #0
20025be4:	d0d9      	beq.n	20025b9a <__swbuf_r+0x2e>
20025be6:	e7d6      	b.n	20025b96 <__swbuf_r+0x2a>

20025be8 <__swsetup_r>:
20025be8:	b538      	push	{r3, r4, r5, lr}
20025bea:	4b28      	ldr	r3, [pc, #160]	@ (20025c8c <__swsetup_r+0xa4>)
20025bec:	4605      	mov	r5, r0
20025bee:	460c      	mov	r4, r1
20025bf0:	6818      	ldr	r0, [r3, #0]
20025bf2:	b118      	cbz	r0, 20025bfc <__swsetup_r+0x14>
20025bf4:	6a03      	ldr	r3, [r0, #32]
20025bf6:	b90b      	cbnz	r3, 20025bfc <__swsetup_r+0x14>
20025bf8:	f7ff fece 	bl	20025998 <__sinit>
20025bfc:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025c00:	071a      	lsls	r2, r3, #28
20025c02:	d421      	bmi.n	20025c48 <__swsetup_r+0x60>
20025c04:	06d8      	lsls	r0, r3, #27
20025c06:	d407      	bmi.n	20025c18 <__swsetup_r+0x30>
20025c08:	2209      	movs	r2, #9
20025c0a:	602a      	str	r2, [r5, #0]
20025c0c:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
20025c10:	f04f 30ff 	mov.w	r0, #4294967295
20025c14:	81a3      	strh	r3, [r4, #12]
20025c16:	e030      	b.n	20025c7a <__swsetup_r+0x92>
20025c18:	0759      	lsls	r1, r3, #29
20025c1a:	d512      	bpl.n	20025c42 <__swsetup_r+0x5a>
20025c1c:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20025c1e:	b141      	cbz	r1, 20025c32 <__swsetup_r+0x4a>
20025c20:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025c24:	4299      	cmp	r1, r3
20025c26:	d002      	beq.n	20025c2e <__swsetup_r+0x46>
20025c28:	4628      	mov	r0, r5
20025c2a:	f000 f8bd 	bl	20025da8 <_free_r>
20025c2e:	2300      	movs	r3, #0
20025c30:	6363      	str	r3, [r4, #52]	@ 0x34
20025c32:	2200      	movs	r2, #0
20025c34:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025c38:	6062      	str	r2, [r4, #4]
20025c3a:	f023 0324 	bic.w	r3, r3, #36	@ 0x24
20025c3e:	6922      	ldr	r2, [r4, #16]
20025c40:	6022      	str	r2, [r4, #0]
20025c42:	f043 0308 	orr.w	r3, r3, #8
20025c46:	81a3      	strh	r3, [r4, #12]
20025c48:	6922      	ldr	r2, [r4, #16]
20025c4a:	b93a      	cbnz	r2, 20025c5c <__swsetup_r+0x74>
20025c4c:	059a      	lsls	r2, r3, #22
20025c4e:	d501      	bpl.n	20025c54 <__swsetup_r+0x6c>
20025c50:	0618      	lsls	r0, r3, #24
20025c52:	d503      	bpl.n	20025c5c <__swsetup_r+0x74>
20025c54:	4621      	mov	r1, r4
20025c56:	4628      	mov	r0, r5
20025c58:	f000 fbe8 	bl	2002642c <__smakebuf_r>
20025c5c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025c60:	f013 0201 	ands.w	r2, r3, #1
20025c64:	d00a      	beq.n	20025c7c <__swsetup_r+0x94>
20025c66:	2200      	movs	r2, #0
20025c68:	60a2      	str	r2, [r4, #8]
20025c6a:	6962      	ldr	r2, [r4, #20]
20025c6c:	4252      	negs	r2, r2
20025c6e:	61a2      	str	r2, [r4, #24]
20025c70:	6922      	ldr	r2, [r4, #16]
20025c72:	b942      	cbnz	r2, 20025c86 <__swsetup_r+0x9e>
20025c74:	f013 0080 	ands.w	r0, r3, #128	@ 0x80
20025c78:	d1c8      	bne.n	20025c0c <__swsetup_r+0x24>
20025c7a:	bd38      	pop	{r3, r4, r5, pc}
20025c7c:	0799      	lsls	r1, r3, #30
20025c7e:	bf58      	it	pl
20025c80:	6962      	ldrpl	r2, [r4, #20]
20025c82:	60a2      	str	r2, [r4, #8]
20025c84:	e7f4      	b.n	20025c70 <__swsetup_r+0x88>
20025c86:	2000      	movs	r0, #0
20025c88:	e7f7      	b.n	20025c7a <__swsetup_r+0x92>
20025c8a:	bf00      	nop
20025c8c:	200449b0 	.word	0x200449b0

20025c90 <memcmp>:
20025c90:	3901      	subs	r1, #1
20025c92:	4402      	add	r2, r0
20025c94:	b510      	push	{r4, lr}
20025c96:	4290      	cmp	r0, r2
20025c98:	d101      	bne.n	20025c9e <memcmp+0xe>
20025c9a:	2000      	movs	r0, #0
20025c9c:	e005      	b.n	20025caa <memcmp+0x1a>
20025c9e:	7803      	ldrb	r3, [r0, #0]
20025ca0:	f811 4f01 	ldrb.w	r4, [r1, #1]!
20025ca4:	42a3      	cmp	r3, r4
20025ca6:	d001      	beq.n	20025cac <memcmp+0x1c>
20025ca8:	1b18      	subs	r0, r3, r4
20025caa:	bd10      	pop	{r4, pc}
20025cac:	3001      	adds	r0, #1
20025cae:	e7f2      	b.n	20025c96 <memcmp+0x6>

20025cb0 <memset>:
20025cb0:	4402      	add	r2, r0
20025cb2:	4603      	mov	r3, r0
20025cb4:	4293      	cmp	r3, r2
20025cb6:	d100      	bne.n	20025cba <memset+0xa>
20025cb8:	4770      	bx	lr
20025cba:	f803 1b01 	strb.w	r1, [r3], #1
20025cbe:	e7f9      	b.n	20025cb4 <memset+0x4>

20025cc0 <_close_r>:
20025cc0:	b538      	push	{r3, r4, r5, lr}
20025cc2:	2300      	movs	r3, #0
20025cc4:	4d05      	ldr	r5, [pc, #20]	@ (20025cdc <_close_r+0x1c>)
20025cc6:	4604      	mov	r4, r0
20025cc8:	4608      	mov	r0, r1
20025cca:	602b      	str	r3, [r5, #0]
20025ccc:	f7fb fcec 	bl	200216a8 <_close>
20025cd0:	1c43      	adds	r3, r0, #1
20025cd2:	d102      	bne.n	20025cda <_close_r+0x1a>
20025cd4:	682b      	ldr	r3, [r5, #0]
20025cd6:	b103      	cbz	r3, 20025cda <_close_r+0x1a>
20025cd8:	6023      	str	r3, [r4, #0]
20025cda:	bd38      	pop	{r3, r4, r5, pc}
20025cdc:	2004d030 	.word	0x2004d030

20025ce0 <_lseek_r>:
20025ce0:	b538      	push	{r3, r4, r5, lr}
20025ce2:	4604      	mov	r4, r0
20025ce4:	4d06      	ldr	r5, [pc, #24]	@ (20025d00 <_lseek_r+0x20>)
20025ce6:	4608      	mov	r0, r1
20025ce8:	4611      	mov	r1, r2
20025cea:	2200      	movs	r2, #0
20025cec:	602a      	str	r2, [r5, #0]
20025cee:	461a      	mov	r2, r3
20025cf0:	f7fb fcdd 	bl	200216ae <_lseek>
20025cf4:	1c43      	adds	r3, r0, #1
20025cf6:	d102      	bne.n	20025cfe <_lseek_r+0x1e>
20025cf8:	682b      	ldr	r3, [r5, #0]
20025cfa:	b103      	cbz	r3, 20025cfe <_lseek_r+0x1e>
20025cfc:	6023      	str	r3, [r4, #0]
20025cfe:	bd38      	pop	{r3, r4, r5, pc}
20025d00:	2004d030 	.word	0x2004d030

20025d04 <_read_r>:
20025d04:	b538      	push	{r3, r4, r5, lr}
20025d06:	4604      	mov	r4, r0
20025d08:	4d06      	ldr	r5, [pc, #24]	@ (20025d24 <_read_r+0x20>)
20025d0a:	4608      	mov	r0, r1
20025d0c:	4611      	mov	r1, r2
20025d0e:	2200      	movs	r2, #0
20025d10:	602a      	str	r2, [r5, #0]
20025d12:	461a      	mov	r2, r3
20025d14:	f7fb fcce 	bl	200216b4 <_read>
20025d18:	1c43      	adds	r3, r0, #1
20025d1a:	d102      	bne.n	20025d22 <_read_r+0x1e>
20025d1c:	682b      	ldr	r3, [r5, #0]
20025d1e:	b103      	cbz	r3, 20025d22 <_read_r+0x1e>
20025d20:	6023      	str	r3, [r4, #0]
20025d22:	bd38      	pop	{r3, r4, r5, pc}
20025d24:	2004d030 	.word	0x2004d030

20025d28 <_sbrk_r>:
20025d28:	b538      	push	{r3, r4, r5, lr}
20025d2a:	2300      	movs	r3, #0
20025d2c:	4d05      	ldr	r5, [pc, #20]	@ (20025d44 <_sbrk_r+0x1c>)
20025d2e:	4604      	mov	r4, r0
20025d30:	4608      	mov	r0, r1
20025d32:	602b      	str	r3, [r5, #0]
20025d34:	f000 fbd6 	bl	200264e4 <_sbrk>
20025d38:	1c43      	adds	r3, r0, #1
20025d3a:	d102      	bne.n	20025d42 <_sbrk_r+0x1a>
20025d3c:	682b      	ldr	r3, [r5, #0]
20025d3e:	b103      	cbz	r3, 20025d42 <_sbrk_r+0x1a>
20025d40:	6023      	str	r3, [r4, #0]
20025d42:	bd38      	pop	{r3, r4, r5, pc}
20025d44:	2004d030 	.word	0x2004d030

20025d48 <_write_r>:
20025d48:	b538      	push	{r3, r4, r5, lr}
20025d4a:	4604      	mov	r4, r0
20025d4c:	4d06      	ldr	r5, [pc, #24]	@ (20025d68 <_write_r+0x20>)
20025d4e:	4608      	mov	r0, r1
20025d50:	4611      	mov	r1, r2
20025d52:	2200      	movs	r2, #0
20025d54:	602a      	str	r2, [r5, #0]
20025d56:	461a      	mov	r2, r3
20025d58:	f7fb f888 	bl	20020e6c <_write>
20025d5c:	1c43      	adds	r3, r0, #1
20025d5e:	d102      	bne.n	20025d66 <_write_r+0x1e>
20025d60:	682b      	ldr	r3, [r5, #0]
20025d62:	b103      	cbz	r3, 20025d66 <_write_r+0x1e>
20025d64:	6023      	str	r3, [r4, #0]
20025d66:	bd38      	pop	{r3, r4, r5, pc}
20025d68:	2004d030 	.word	0x2004d030

20025d6c <__retarget_lock_init_recursive>:
20025d6c:	4770      	bx	lr

20025d6e <__retarget_lock_acquire_recursive>:
20025d6e:	4770      	bx	lr

20025d70 <__retarget_lock_release_recursive>:
20025d70:	4770      	bx	lr

20025d72 <memchr>:
20025d72:	b2c9      	uxtb	r1, r1
20025d74:	4603      	mov	r3, r0
20025d76:	4402      	add	r2, r0
20025d78:	b510      	push	{r4, lr}
20025d7a:	4293      	cmp	r3, r2
20025d7c:	4618      	mov	r0, r3
20025d7e:	d101      	bne.n	20025d84 <memchr+0x12>
20025d80:	2000      	movs	r0, #0
20025d82:	e003      	b.n	20025d8c <memchr+0x1a>
20025d84:	7804      	ldrb	r4, [r0, #0]
20025d86:	3301      	adds	r3, #1
20025d88:	428c      	cmp	r4, r1
20025d8a:	d1f6      	bne.n	20025d7a <memchr+0x8>
20025d8c:	bd10      	pop	{r4, pc}

20025d8e <memcpy>:
20025d8e:	440a      	add	r2, r1
20025d90:	1e43      	subs	r3, r0, #1
20025d92:	4291      	cmp	r1, r2
20025d94:	d100      	bne.n	20025d98 <memcpy+0xa>
20025d96:	4770      	bx	lr
20025d98:	b510      	push	{r4, lr}
20025d9a:	f811 4b01 	ldrb.w	r4, [r1], #1
20025d9e:	4291      	cmp	r1, r2
20025da0:	f803 4f01 	strb.w	r4, [r3, #1]!
20025da4:	d1f9      	bne.n	20025d9a <memcpy+0xc>
20025da6:	bd10      	pop	{r4, pc}

20025da8 <_free_r>:
20025da8:	b538      	push	{r3, r4, r5, lr}
20025daa:	4605      	mov	r5, r0
20025dac:	2900      	cmp	r1, #0
20025dae:	d041      	beq.n	20025e34 <_free_r+0x8c>
20025db0:	f851 3c04 	ldr.w	r3, [r1, #-4]
20025db4:	1f0c      	subs	r4, r1, #4
20025db6:	2b00      	cmp	r3, #0
20025db8:	bfb8      	it	lt
20025dba:	18e4      	addlt	r4, r4, r3
20025dbc:	f7ff fcaa 	bl	20025714 <__malloc_lock>
20025dc0:	4a1d      	ldr	r2, [pc, #116]	@ (20025e38 <_free_r+0x90>)
20025dc2:	6813      	ldr	r3, [r2, #0]
20025dc4:	b933      	cbnz	r3, 20025dd4 <_free_r+0x2c>
20025dc6:	6063      	str	r3, [r4, #4]
20025dc8:	6014      	str	r4, [r2, #0]
20025dca:	4628      	mov	r0, r5
20025dcc:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20025dd0:	f7ff bca6 	b.w	20025720 <__malloc_unlock>
20025dd4:	42a3      	cmp	r3, r4
20025dd6:	d908      	bls.n	20025dea <_free_r+0x42>
20025dd8:	6820      	ldr	r0, [r4, #0]
20025dda:	1821      	adds	r1, r4, r0
20025ddc:	428b      	cmp	r3, r1
20025dde:	bf01      	itttt	eq
20025de0:	6819      	ldreq	r1, [r3, #0]
20025de2:	685b      	ldreq	r3, [r3, #4]
20025de4:	1809      	addeq	r1, r1, r0
20025de6:	6021      	streq	r1, [r4, #0]
20025de8:	e7ed      	b.n	20025dc6 <_free_r+0x1e>
20025dea:	461a      	mov	r2, r3
20025dec:	685b      	ldr	r3, [r3, #4]
20025dee:	b10b      	cbz	r3, 20025df4 <_free_r+0x4c>
20025df0:	42a3      	cmp	r3, r4
20025df2:	d9fa      	bls.n	20025dea <_free_r+0x42>
20025df4:	6811      	ldr	r1, [r2, #0]
20025df6:	1850      	adds	r0, r2, r1
20025df8:	42a0      	cmp	r0, r4
20025dfa:	d10b      	bne.n	20025e14 <_free_r+0x6c>
20025dfc:	6820      	ldr	r0, [r4, #0]
20025dfe:	4401      	add	r1, r0
20025e00:	1850      	adds	r0, r2, r1
20025e02:	6011      	str	r1, [r2, #0]
20025e04:	4283      	cmp	r3, r0
20025e06:	d1e0      	bne.n	20025dca <_free_r+0x22>
20025e08:	6818      	ldr	r0, [r3, #0]
20025e0a:	685b      	ldr	r3, [r3, #4]
20025e0c:	4408      	add	r0, r1
20025e0e:	6053      	str	r3, [r2, #4]
20025e10:	6010      	str	r0, [r2, #0]
20025e12:	e7da      	b.n	20025dca <_free_r+0x22>
20025e14:	d902      	bls.n	20025e1c <_free_r+0x74>
20025e16:	230c      	movs	r3, #12
20025e18:	602b      	str	r3, [r5, #0]
20025e1a:	e7d6      	b.n	20025dca <_free_r+0x22>
20025e1c:	6820      	ldr	r0, [r4, #0]
20025e1e:	1821      	adds	r1, r4, r0
20025e20:	428b      	cmp	r3, r1
20025e22:	bf02      	ittt	eq
20025e24:	6819      	ldreq	r1, [r3, #0]
20025e26:	685b      	ldreq	r3, [r3, #4]
20025e28:	1809      	addeq	r1, r1, r0
20025e2a:	6063      	str	r3, [r4, #4]
20025e2c:	bf08      	it	eq
20025e2e:	6021      	streq	r1, [r4, #0]
20025e30:	6054      	str	r4, [r2, #4]
20025e32:	e7ca      	b.n	20025dca <_free_r+0x22>
20025e34:	bd38      	pop	{r3, r4, r5, pc}
20025e36:	bf00      	nop
20025e38:	2004cef0 	.word	0x2004cef0

20025e3c <__sfputc_r>:
20025e3c:	6893      	ldr	r3, [r2, #8]
20025e3e:	3b01      	subs	r3, #1
20025e40:	2b00      	cmp	r3, #0
20025e42:	b410      	push	{r4}
20025e44:	6093      	str	r3, [r2, #8]
20025e46:	da08      	bge.n	20025e5a <__sfputc_r+0x1e>
20025e48:	6994      	ldr	r4, [r2, #24]
20025e4a:	42a3      	cmp	r3, r4
20025e4c:	db01      	blt.n	20025e52 <__sfputc_r+0x16>
20025e4e:	290a      	cmp	r1, #10
20025e50:	d103      	bne.n	20025e5a <__sfputc_r+0x1e>
20025e52:	f85d 4b04 	ldr.w	r4, [sp], #4
20025e56:	f7ff be89 	b.w	20025b6c <__swbuf_r>
20025e5a:	6813      	ldr	r3, [r2, #0]
20025e5c:	1c58      	adds	r0, r3, #1
20025e5e:	6010      	str	r0, [r2, #0]
20025e60:	4608      	mov	r0, r1
20025e62:	7019      	strb	r1, [r3, #0]
20025e64:	f85d 4b04 	ldr.w	r4, [sp], #4
20025e68:	4770      	bx	lr

20025e6a <__sfputs_r>:
20025e6a:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025e6c:	4606      	mov	r6, r0
20025e6e:	460f      	mov	r7, r1
20025e70:	4614      	mov	r4, r2
20025e72:	18d5      	adds	r5, r2, r3
20025e74:	42ac      	cmp	r4, r5
20025e76:	d101      	bne.n	20025e7c <__sfputs_r+0x12>
20025e78:	2000      	movs	r0, #0
20025e7a:	e007      	b.n	20025e8c <__sfputs_r+0x22>
20025e7c:	463a      	mov	r2, r7
20025e7e:	f814 1b01 	ldrb.w	r1, [r4], #1
20025e82:	4630      	mov	r0, r6
20025e84:	f7ff ffda 	bl	20025e3c <__sfputc_r>
20025e88:	1c43      	adds	r3, r0, #1
20025e8a:	d1f3      	bne.n	20025e74 <__sfputs_r+0xa>
20025e8c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

20025e90 <_vfiprintf_r>:
20025e90:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025e94:	460d      	mov	r5, r1
20025e96:	b09d      	sub	sp, #116	@ 0x74
20025e98:	4614      	mov	r4, r2
20025e9a:	4698      	mov	r8, r3
20025e9c:	4606      	mov	r6, r0
20025e9e:	b118      	cbz	r0, 20025ea8 <_vfiprintf_r+0x18>
20025ea0:	6a03      	ldr	r3, [r0, #32]
20025ea2:	b90b      	cbnz	r3, 20025ea8 <_vfiprintf_r+0x18>
20025ea4:	f7ff fd78 	bl	20025998 <__sinit>
20025ea8:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20025eaa:	07d9      	lsls	r1, r3, #31
20025eac:	d405      	bmi.n	20025eba <_vfiprintf_r+0x2a>
20025eae:	89ab      	ldrh	r3, [r5, #12]
20025eb0:	059a      	lsls	r2, r3, #22
20025eb2:	d402      	bmi.n	20025eba <_vfiprintf_r+0x2a>
20025eb4:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025eb6:	f7ff ff5a 	bl	20025d6e <__retarget_lock_acquire_recursive>
20025eba:	89ab      	ldrh	r3, [r5, #12]
20025ebc:	071b      	lsls	r3, r3, #28
20025ebe:	d501      	bpl.n	20025ec4 <_vfiprintf_r+0x34>
20025ec0:	692b      	ldr	r3, [r5, #16]
20025ec2:	b99b      	cbnz	r3, 20025eec <_vfiprintf_r+0x5c>
20025ec4:	4629      	mov	r1, r5
20025ec6:	4630      	mov	r0, r6
20025ec8:	f7ff fe8e 	bl	20025be8 <__swsetup_r>
20025ecc:	b170      	cbz	r0, 20025eec <_vfiprintf_r+0x5c>
20025ece:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20025ed0:	07dc      	lsls	r4, r3, #31
20025ed2:	d504      	bpl.n	20025ede <_vfiprintf_r+0x4e>
20025ed4:	f04f 30ff 	mov.w	r0, #4294967295
20025ed8:	b01d      	add	sp, #116	@ 0x74
20025eda:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025ede:	89ab      	ldrh	r3, [r5, #12]
20025ee0:	0598      	lsls	r0, r3, #22
20025ee2:	d4f7      	bmi.n	20025ed4 <_vfiprintf_r+0x44>
20025ee4:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025ee6:	f7ff ff43 	bl	20025d70 <__retarget_lock_release_recursive>
20025eea:	e7f3      	b.n	20025ed4 <_vfiprintf_r+0x44>
20025eec:	2300      	movs	r3, #0
20025eee:	f8cd 800c 	str.w	r8, [sp, #12]
20025ef2:	f04f 0901 	mov.w	r9, #1
20025ef6:	f8df 81b4 	ldr.w	r8, [pc, #436]	@ 200260ac <_vfiprintf_r+0x21c>
20025efa:	9309      	str	r3, [sp, #36]	@ 0x24
20025efc:	2320      	movs	r3, #32
20025efe:	f88d 3029 	strb.w	r3, [sp, #41]	@ 0x29
20025f02:	2330      	movs	r3, #48	@ 0x30
20025f04:	f88d 302a 	strb.w	r3, [sp, #42]	@ 0x2a
20025f08:	4623      	mov	r3, r4
20025f0a:	469a      	mov	sl, r3
20025f0c:	f813 2b01 	ldrb.w	r2, [r3], #1
20025f10:	b10a      	cbz	r2, 20025f16 <_vfiprintf_r+0x86>
20025f12:	2a25      	cmp	r2, #37	@ 0x25
20025f14:	d1f9      	bne.n	20025f0a <_vfiprintf_r+0x7a>
20025f16:	ebba 0b04 	subs.w	fp, sl, r4
20025f1a:	d00b      	beq.n	20025f34 <_vfiprintf_r+0xa4>
20025f1c:	465b      	mov	r3, fp
20025f1e:	4622      	mov	r2, r4
20025f20:	4629      	mov	r1, r5
20025f22:	4630      	mov	r0, r6
20025f24:	f7ff ffa1 	bl	20025e6a <__sfputs_r>
20025f28:	3001      	adds	r0, #1
20025f2a:	f000 80a7 	beq.w	2002607c <_vfiprintf_r+0x1ec>
20025f2e:	9a09      	ldr	r2, [sp, #36]	@ 0x24
20025f30:	445a      	add	r2, fp
20025f32:	9209      	str	r2, [sp, #36]	@ 0x24
20025f34:	f89a 3000 	ldrb.w	r3, [sl]
20025f38:	2b00      	cmp	r3, #0
20025f3a:	f000 809f 	beq.w	2002607c <_vfiprintf_r+0x1ec>
20025f3e:	2300      	movs	r3, #0
20025f40:	f04f 32ff 	mov.w	r2, #4294967295
20025f44:	f10a 0a01 	add.w	sl, sl, #1
20025f48:	9304      	str	r3, [sp, #16]
20025f4a:	9307      	str	r3, [sp, #28]
20025f4c:	f88d 3053 	strb.w	r3, [sp, #83]	@ 0x53
20025f50:	931a      	str	r3, [sp, #104]	@ 0x68
20025f52:	e9cd 2305 	strd	r2, r3, [sp, #20]
20025f56:	4654      	mov	r4, sl
20025f58:	2205      	movs	r2, #5
20025f5a:	4854      	ldr	r0, [pc, #336]	@ (200260ac <_vfiprintf_r+0x21c>)
20025f5c:	f814 1b01 	ldrb.w	r1, [r4], #1
20025f60:	f7ff ff07 	bl	20025d72 <memchr>
20025f64:	9a04      	ldr	r2, [sp, #16]
20025f66:	b9d8      	cbnz	r0, 20025fa0 <_vfiprintf_r+0x110>
20025f68:	06d1      	lsls	r1, r2, #27
20025f6a:	bf44      	itt	mi
20025f6c:	2320      	movmi	r3, #32
20025f6e:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20025f72:	0713      	lsls	r3, r2, #28
20025f74:	bf44      	itt	mi
20025f76:	232b      	movmi	r3, #43	@ 0x2b
20025f78:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20025f7c:	f89a 3000 	ldrb.w	r3, [sl]
20025f80:	2b2a      	cmp	r3, #42	@ 0x2a
20025f82:	d015      	beq.n	20025fb0 <_vfiprintf_r+0x120>
20025f84:	9a07      	ldr	r2, [sp, #28]
20025f86:	4654      	mov	r4, sl
20025f88:	2000      	movs	r0, #0
20025f8a:	f04f 0c0a 	mov.w	ip, #10
20025f8e:	4621      	mov	r1, r4
20025f90:	f811 3b01 	ldrb.w	r3, [r1], #1
20025f94:	3b30      	subs	r3, #48	@ 0x30
20025f96:	2b09      	cmp	r3, #9
20025f98:	d94b      	bls.n	20026032 <_vfiprintf_r+0x1a2>
20025f9a:	b1b0      	cbz	r0, 20025fca <_vfiprintf_r+0x13a>
20025f9c:	9207      	str	r2, [sp, #28]
20025f9e:	e014      	b.n	20025fca <_vfiprintf_r+0x13a>
20025fa0:	eba0 0308 	sub.w	r3, r0, r8
20025fa4:	46a2      	mov	sl, r4
20025fa6:	fa09 f303 	lsl.w	r3, r9, r3
20025faa:	4313      	orrs	r3, r2
20025fac:	9304      	str	r3, [sp, #16]
20025fae:	e7d2      	b.n	20025f56 <_vfiprintf_r+0xc6>
20025fb0:	9b03      	ldr	r3, [sp, #12]
20025fb2:	1d19      	adds	r1, r3, #4
20025fb4:	681b      	ldr	r3, [r3, #0]
20025fb6:	2b00      	cmp	r3, #0
20025fb8:	9103      	str	r1, [sp, #12]
20025fba:	bfbb      	ittet	lt
20025fbc:	425b      	neglt	r3, r3
20025fbe:	f042 0202 	orrlt.w	r2, r2, #2
20025fc2:	9307      	strge	r3, [sp, #28]
20025fc4:	9307      	strlt	r3, [sp, #28]
20025fc6:	bfb8      	it	lt
20025fc8:	9204      	strlt	r2, [sp, #16]
20025fca:	7823      	ldrb	r3, [r4, #0]
20025fcc:	2b2e      	cmp	r3, #46	@ 0x2e
20025fce:	d10a      	bne.n	20025fe6 <_vfiprintf_r+0x156>
20025fd0:	7863      	ldrb	r3, [r4, #1]
20025fd2:	2b2a      	cmp	r3, #42	@ 0x2a
20025fd4:	d132      	bne.n	2002603c <_vfiprintf_r+0x1ac>
20025fd6:	9b03      	ldr	r3, [sp, #12]
20025fd8:	3402      	adds	r4, #2
20025fda:	1d1a      	adds	r2, r3, #4
20025fdc:	681b      	ldr	r3, [r3, #0]
20025fde:	ea43 73e3 	orr.w	r3, r3, r3, asr #31
20025fe2:	9203      	str	r2, [sp, #12]
20025fe4:	9305      	str	r3, [sp, #20]
20025fe6:	f8df a0d4 	ldr.w	sl, [pc, #212]	@ 200260bc <_vfiprintf_r+0x22c>
20025fea:	2203      	movs	r2, #3
20025fec:	7821      	ldrb	r1, [r4, #0]
20025fee:	4650      	mov	r0, sl
20025ff0:	f7ff febf 	bl	20025d72 <memchr>
20025ff4:	b138      	cbz	r0, 20026006 <_vfiprintf_r+0x176>
20025ff6:	eba0 000a 	sub.w	r0, r0, sl
20025ffa:	2240      	movs	r2, #64	@ 0x40
20025ffc:	9b04      	ldr	r3, [sp, #16]
20025ffe:	3401      	adds	r4, #1
20026000:	4082      	lsls	r2, r0
20026002:	4313      	orrs	r3, r2
20026004:	9304      	str	r3, [sp, #16]
20026006:	f814 1b01 	ldrb.w	r1, [r4], #1
2002600a:	2206      	movs	r2, #6
2002600c:	4828      	ldr	r0, [pc, #160]	@ (200260b0 <_vfiprintf_r+0x220>)
2002600e:	f88d 1028 	strb.w	r1, [sp, #40]	@ 0x28
20026012:	f7ff feae 	bl	20025d72 <memchr>
20026016:	2800      	cmp	r0, #0
20026018:	d03f      	beq.n	2002609a <_vfiprintf_r+0x20a>
2002601a:	4b26      	ldr	r3, [pc, #152]	@ (200260b4 <_vfiprintf_r+0x224>)
2002601c:	bb1b      	cbnz	r3, 20026066 <_vfiprintf_r+0x1d6>
2002601e:	9b03      	ldr	r3, [sp, #12]
20026020:	3307      	adds	r3, #7
20026022:	f023 0307 	bic.w	r3, r3, #7
20026026:	3308      	adds	r3, #8
20026028:	9303      	str	r3, [sp, #12]
2002602a:	9b09      	ldr	r3, [sp, #36]	@ 0x24
2002602c:	443b      	add	r3, r7
2002602e:	9309      	str	r3, [sp, #36]	@ 0x24
20026030:	e76a      	b.n	20025f08 <_vfiprintf_r+0x78>
20026032:	fb0c 3202 	mla	r2, ip, r2, r3
20026036:	460c      	mov	r4, r1
20026038:	2001      	movs	r0, #1
2002603a:	e7a8      	b.n	20025f8e <_vfiprintf_r+0xfe>
2002603c:	2300      	movs	r3, #0
2002603e:	3401      	adds	r4, #1
20026040:	f04f 0c0a 	mov.w	ip, #10
20026044:	4619      	mov	r1, r3
20026046:	9305      	str	r3, [sp, #20]
20026048:	4620      	mov	r0, r4
2002604a:	f810 2b01 	ldrb.w	r2, [r0], #1
2002604e:	3a30      	subs	r2, #48	@ 0x30
20026050:	2a09      	cmp	r2, #9
20026052:	d903      	bls.n	2002605c <_vfiprintf_r+0x1cc>
20026054:	2b00      	cmp	r3, #0
20026056:	d0c6      	beq.n	20025fe6 <_vfiprintf_r+0x156>
20026058:	9105      	str	r1, [sp, #20]
2002605a:	e7c4      	b.n	20025fe6 <_vfiprintf_r+0x156>
2002605c:	fb0c 2101 	mla	r1, ip, r1, r2
20026060:	4604      	mov	r4, r0
20026062:	2301      	movs	r3, #1
20026064:	e7f0      	b.n	20026048 <_vfiprintf_r+0x1b8>
20026066:	ab03      	add	r3, sp, #12
20026068:	462a      	mov	r2, r5
2002606a:	a904      	add	r1, sp, #16
2002606c:	4630      	mov	r0, r6
2002606e:	9300      	str	r3, [sp, #0]
20026070:	4b11      	ldr	r3, [pc, #68]	@ (200260b8 <_vfiprintf_r+0x228>)
20026072:	f3af 8000 	nop.w
20026076:	4607      	mov	r7, r0
20026078:	1c78      	adds	r0, r7, #1
2002607a:	d1d6      	bne.n	2002602a <_vfiprintf_r+0x19a>
2002607c:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
2002607e:	07d9      	lsls	r1, r3, #31
20026080:	d405      	bmi.n	2002608e <_vfiprintf_r+0x1fe>
20026082:	89ab      	ldrh	r3, [r5, #12]
20026084:	059a      	lsls	r2, r3, #22
20026086:	d402      	bmi.n	2002608e <_vfiprintf_r+0x1fe>
20026088:	6da8      	ldr	r0, [r5, #88]	@ 0x58
2002608a:	f7ff fe71 	bl	20025d70 <__retarget_lock_release_recursive>
2002608e:	89ab      	ldrh	r3, [r5, #12]
20026090:	065b      	lsls	r3, r3, #25
20026092:	f53f af1f 	bmi.w	20025ed4 <_vfiprintf_r+0x44>
20026096:	9809      	ldr	r0, [sp, #36]	@ 0x24
20026098:	e71e      	b.n	20025ed8 <_vfiprintf_r+0x48>
2002609a:	ab03      	add	r3, sp, #12
2002609c:	462a      	mov	r2, r5
2002609e:	a904      	add	r1, sp, #16
200260a0:	4630      	mov	r0, r6
200260a2:	9300      	str	r3, [sp, #0]
200260a4:	4b04      	ldr	r3, [pc, #16]	@ (200260b8 <_vfiprintf_r+0x228>)
200260a6:	f000 f87d 	bl	200261a4 <_printf_i>
200260aa:	e7e4      	b.n	20026076 <_vfiprintf_r+0x1e6>
200260ac:	200269f1 	.word	0x200269f1
200260b0:	200269fb 	.word	0x200269fb
200260b4:	00000000 	.word	0x00000000
200260b8:	20025e6b 	.word	0x20025e6b
200260bc:	200269f7 	.word	0x200269f7

200260c0 <_printf_common>:
200260c0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200260c4:	4616      	mov	r6, r2
200260c6:	4698      	mov	r8, r3
200260c8:	688a      	ldr	r2, [r1, #8]
200260ca:	4607      	mov	r7, r0
200260cc:	690b      	ldr	r3, [r1, #16]
200260ce:	460c      	mov	r4, r1
200260d0:	f8dd 9020 	ldr.w	r9, [sp, #32]
200260d4:	4293      	cmp	r3, r2
200260d6:	bfb8      	it	lt
200260d8:	4613      	movlt	r3, r2
200260da:	6033      	str	r3, [r6, #0]
200260dc:	f891 2043 	ldrb.w	r2, [r1, #67]	@ 0x43
200260e0:	b10a      	cbz	r2, 200260e6 <_printf_common+0x26>
200260e2:	3301      	adds	r3, #1
200260e4:	6033      	str	r3, [r6, #0]
200260e6:	6823      	ldr	r3, [r4, #0]
200260e8:	0699      	lsls	r1, r3, #26
200260ea:	bf42      	ittt	mi
200260ec:	6833      	ldrmi	r3, [r6, #0]
200260ee:	3302      	addmi	r3, #2
200260f0:	6033      	strmi	r3, [r6, #0]
200260f2:	6825      	ldr	r5, [r4, #0]
200260f4:	f015 0506 	ands.w	r5, r5, #6
200260f8:	d106      	bne.n	20026108 <_printf_common+0x48>
200260fa:	f104 0a19 	add.w	sl, r4, #25
200260fe:	68e3      	ldr	r3, [r4, #12]
20026100:	6832      	ldr	r2, [r6, #0]
20026102:	1a9b      	subs	r3, r3, r2
20026104:	42ab      	cmp	r3, r5
20026106:	dc2b      	bgt.n	20026160 <_printf_common+0xa0>
20026108:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
2002610c:	6822      	ldr	r2, [r4, #0]
2002610e:	3b00      	subs	r3, #0
20026110:	bf18      	it	ne
20026112:	2301      	movne	r3, #1
20026114:	0692      	lsls	r2, r2, #26
20026116:	d430      	bmi.n	2002617a <_printf_common+0xba>
20026118:	f104 0243 	add.w	r2, r4, #67	@ 0x43
2002611c:	4641      	mov	r1, r8
2002611e:	4638      	mov	r0, r7
20026120:	47c8      	blx	r9
20026122:	3001      	adds	r0, #1
20026124:	d023      	beq.n	2002616e <_printf_common+0xae>
20026126:	6823      	ldr	r3, [r4, #0]
20026128:	341a      	adds	r4, #26
2002612a:	f854 2c0a 	ldr.w	r2, [r4, #-10]
2002612e:	f003 0306 	and.w	r3, r3, #6
20026132:	2b04      	cmp	r3, #4
20026134:	bf0a      	itet	eq
20026136:	f854 5c0e 	ldreq.w	r5, [r4, #-14]
2002613a:	2500      	movne	r5, #0
2002613c:	6833      	ldreq	r3, [r6, #0]
2002613e:	f04f 0600 	mov.w	r6, #0
20026142:	bf08      	it	eq
20026144:	1aed      	subeq	r5, r5, r3
20026146:	f854 3c12 	ldr.w	r3, [r4, #-18]
2002614a:	bf08      	it	eq
2002614c:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
20026150:	4293      	cmp	r3, r2
20026152:	bfc4      	itt	gt
20026154:	1a9b      	subgt	r3, r3, r2
20026156:	18ed      	addgt	r5, r5, r3
20026158:	42b5      	cmp	r5, r6
2002615a:	d11a      	bne.n	20026192 <_printf_common+0xd2>
2002615c:	2000      	movs	r0, #0
2002615e:	e008      	b.n	20026172 <_printf_common+0xb2>
20026160:	2301      	movs	r3, #1
20026162:	4652      	mov	r2, sl
20026164:	4641      	mov	r1, r8
20026166:	4638      	mov	r0, r7
20026168:	47c8      	blx	r9
2002616a:	3001      	adds	r0, #1
2002616c:	d103      	bne.n	20026176 <_printf_common+0xb6>
2002616e:	f04f 30ff 	mov.w	r0, #4294967295
20026172:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20026176:	3501      	adds	r5, #1
20026178:	e7c1      	b.n	200260fe <_printf_common+0x3e>
2002617a:	18e1      	adds	r1, r4, r3
2002617c:	1c5a      	adds	r2, r3, #1
2002617e:	2030      	movs	r0, #48	@ 0x30
20026180:	3302      	adds	r3, #2
20026182:	4422      	add	r2, r4
20026184:	f881 0043 	strb.w	r0, [r1, #67]	@ 0x43
20026188:	f894 1045 	ldrb.w	r1, [r4, #69]	@ 0x45
2002618c:	f882 1043 	strb.w	r1, [r2, #67]	@ 0x43
20026190:	e7c2      	b.n	20026118 <_printf_common+0x58>
20026192:	2301      	movs	r3, #1
20026194:	4622      	mov	r2, r4
20026196:	4641      	mov	r1, r8
20026198:	4638      	mov	r0, r7
2002619a:	47c8      	blx	r9
2002619c:	3001      	adds	r0, #1
2002619e:	d0e6      	beq.n	2002616e <_printf_common+0xae>
200261a0:	3601      	adds	r6, #1
200261a2:	e7d9      	b.n	20026158 <_printf_common+0x98>

200261a4 <_printf_i>:
200261a4:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
200261a8:	7e0f      	ldrb	r7, [r1, #24]
200261aa:	4691      	mov	r9, r2
200261ac:	4680      	mov	r8, r0
200261ae:	460c      	mov	r4, r1
200261b0:	2f78      	cmp	r7, #120	@ 0x78
200261b2:	469a      	mov	sl, r3
200261b4:	9e0c      	ldr	r6, [sp, #48]	@ 0x30
200261b6:	f101 0243 	add.w	r2, r1, #67	@ 0x43
200261ba:	d807      	bhi.n	200261cc <_printf_i+0x28>
200261bc:	2f62      	cmp	r7, #98	@ 0x62
200261be:	d80a      	bhi.n	200261d6 <_printf_i+0x32>
200261c0:	2f00      	cmp	r7, #0
200261c2:	f000 80d2 	beq.w	2002636a <_printf_i+0x1c6>
200261c6:	2f58      	cmp	r7, #88	@ 0x58
200261c8:	f000 80b7 	beq.w	2002633a <_printf_i+0x196>
200261cc:	f104 0642 	add.w	r6, r4, #66	@ 0x42
200261d0:	f884 7042 	strb.w	r7, [r4, #66]	@ 0x42
200261d4:	e03a      	b.n	2002624c <_printf_i+0xa8>
200261d6:	f1a7 0363 	sub.w	r3, r7, #99	@ 0x63
200261da:	2b15      	cmp	r3, #21
200261dc:	d8f6      	bhi.n	200261cc <_printf_i+0x28>
200261de:	a101      	add	r1, pc, #4	@ (adr r1, 200261e4 <_printf_i+0x40>)
200261e0:	f851 f023 	ldr.w	pc, [r1, r3, lsl #2]
200261e4:	2002623d 	.word	0x2002623d
200261e8:	20026251 	.word	0x20026251
200261ec:	200261cd 	.word	0x200261cd
200261f0:	200261cd 	.word	0x200261cd
200261f4:	200261cd 	.word	0x200261cd
200261f8:	200261cd 	.word	0x200261cd
200261fc:	20026251 	.word	0x20026251
20026200:	200261cd 	.word	0x200261cd
20026204:	200261cd 	.word	0x200261cd
20026208:	200261cd 	.word	0x200261cd
2002620c:	200261cd 	.word	0x200261cd
20026210:	20026351 	.word	0x20026351
20026214:	2002627b 	.word	0x2002627b
20026218:	20026307 	.word	0x20026307
2002621c:	200261cd 	.word	0x200261cd
20026220:	200261cd 	.word	0x200261cd
20026224:	20026373 	.word	0x20026373
20026228:	200261cd 	.word	0x200261cd
2002622c:	2002627b 	.word	0x2002627b
20026230:	200261cd 	.word	0x200261cd
20026234:	200261cd 	.word	0x200261cd
20026238:	2002630f 	.word	0x2002630f
2002623c:	6833      	ldr	r3, [r6, #0]
2002623e:	1d1a      	adds	r2, r3, #4
20026240:	681b      	ldr	r3, [r3, #0]
20026242:	6032      	str	r2, [r6, #0]
20026244:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20026248:	f884 3042 	strb.w	r3, [r4, #66]	@ 0x42
2002624c:	2301      	movs	r3, #1
2002624e:	e09d      	b.n	2002638c <_printf_i+0x1e8>
20026250:	6833      	ldr	r3, [r6, #0]
20026252:	6820      	ldr	r0, [r4, #0]
20026254:	1d19      	adds	r1, r3, #4
20026256:	6031      	str	r1, [r6, #0]
20026258:	0606      	lsls	r6, r0, #24
2002625a:	d501      	bpl.n	20026260 <_printf_i+0xbc>
2002625c:	681d      	ldr	r5, [r3, #0]
2002625e:	e003      	b.n	20026268 <_printf_i+0xc4>
20026260:	0645      	lsls	r5, r0, #25
20026262:	d5fb      	bpl.n	2002625c <_printf_i+0xb8>
20026264:	f9b3 5000 	ldrsh.w	r5, [r3]
20026268:	2d00      	cmp	r5, #0
2002626a:	da03      	bge.n	20026274 <_printf_i+0xd0>
2002626c:	232d      	movs	r3, #45	@ 0x2d
2002626e:	426d      	negs	r5, r5
20026270:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026274:	4859      	ldr	r0, [pc, #356]	@ (200263dc <_printf_i+0x238>)
20026276:	230a      	movs	r3, #10
20026278:	e010      	b.n	2002629c <_printf_i+0xf8>
2002627a:	6821      	ldr	r1, [r4, #0]
2002627c:	6833      	ldr	r3, [r6, #0]
2002627e:	0608      	lsls	r0, r1, #24
20026280:	f853 5b04 	ldr.w	r5, [r3], #4
20026284:	d402      	bmi.n	2002628c <_printf_i+0xe8>
20026286:	0649      	lsls	r1, r1, #25
20026288:	bf48      	it	mi
2002628a:	b2ad      	uxthmi	r5, r5
2002628c:	2f6f      	cmp	r7, #111	@ 0x6f
2002628e:	4853      	ldr	r0, [pc, #332]	@ (200263dc <_printf_i+0x238>)
20026290:	6033      	str	r3, [r6, #0]
20026292:	d159      	bne.n	20026348 <_printf_i+0x1a4>
20026294:	2308      	movs	r3, #8
20026296:	2100      	movs	r1, #0
20026298:	f884 1043 	strb.w	r1, [r4, #67]	@ 0x43
2002629c:	6866      	ldr	r6, [r4, #4]
2002629e:	2e00      	cmp	r6, #0
200262a0:	60a6      	str	r6, [r4, #8]
200262a2:	db05      	blt.n	200262b0 <_printf_i+0x10c>
200262a4:	6821      	ldr	r1, [r4, #0]
200262a6:	432e      	orrs	r6, r5
200262a8:	f021 0104 	bic.w	r1, r1, #4
200262ac:	6021      	str	r1, [r4, #0]
200262ae:	d04d      	beq.n	2002634c <_printf_i+0x1a8>
200262b0:	4616      	mov	r6, r2
200262b2:	fbb5 f1f3 	udiv	r1, r5, r3
200262b6:	fb03 5711 	mls	r7, r3, r1, r5
200262ba:	5dc7      	ldrb	r7, [r0, r7]
200262bc:	f806 7d01 	strb.w	r7, [r6, #-1]!
200262c0:	462f      	mov	r7, r5
200262c2:	460d      	mov	r5, r1
200262c4:	42bb      	cmp	r3, r7
200262c6:	d9f4      	bls.n	200262b2 <_printf_i+0x10e>
200262c8:	2b08      	cmp	r3, #8
200262ca:	d10b      	bne.n	200262e4 <_printf_i+0x140>
200262cc:	6823      	ldr	r3, [r4, #0]
200262ce:	07df      	lsls	r7, r3, #31
200262d0:	d508      	bpl.n	200262e4 <_printf_i+0x140>
200262d2:	6923      	ldr	r3, [r4, #16]
200262d4:	6861      	ldr	r1, [r4, #4]
200262d6:	4299      	cmp	r1, r3
200262d8:	bfde      	ittt	le
200262da:	2330      	movle	r3, #48	@ 0x30
200262dc:	f806 3c01 	strble.w	r3, [r6, #-1]
200262e0:	f106 36ff 	addle.w	r6, r6, #4294967295
200262e4:	1b92      	subs	r2, r2, r6
200262e6:	6122      	str	r2, [r4, #16]
200262e8:	464b      	mov	r3, r9
200262ea:	aa03      	add	r2, sp, #12
200262ec:	4621      	mov	r1, r4
200262ee:	4640      	mov	r0, r8
200262f0:	f8cd a000 	str.w	sl, [sp]
200262f4:	f7ff fee4 	bl	200260c0 <_printf_common>
200262f8:	3001      	adds	r0, #1
200262fa:	d14c      	bne.n	20026396 <_printf_i+0x1f2>
200262fc:	f04f 30ff 	mov.w	r0, #4294967295
20026300:	b004      	add	sp, #16
20026302:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20026306:	6823      	ldr	r3, [r4, #0]
20026308:	f043 0320 	orr.w	r3, r3, #32
2002630c:	6023      	str	r3, [r4, #0]
2002630e:	2778      	movs	r7, #120	@ 0x78
20026310:	4833      	ldr	r0, [pc, #204]	@ (200263e0 <_printf_i+0x23c>)
20026312:	6823      	ldr	r3, [r4, #0]
20026314:	f884 7045 	strb.w	r7, [r4, #69]	@ 0x45
20026318:	061f      	lsls	r7, r3, #24
2002631a:	6831      	ldr	r1, [r6, #0]
2002631c:	f851 5b04 	ldr.w	r5, [r1], #4
20026320:	d402      	bmi.n	20026328 <_printf_i+0x184>
20026322:	065f      	lsls	r7, r3, #25
20026324:	bf48      	it	mi
20026326:	b2ad      	uxthmi	r5, r5
20026328:	6031      	str	r1, [r6, #0]
2002632a:	07d9      	lsls	r1, r3, #31
2002632c:	bf44      	itt	mi
2002632e:	f043 0320 	orrmi.w	r3, r3, #32
20026332:	6023      	strmi	r3, [r4, #0]
20026334:	b11d      	cbz	r5, 2002633e <_printf_i+0x19a>
20026336:	2310      	movs	r3, #16
20026338:	e7ad      	b.n	20026296 <_printf_i+0xf2>
2002633a:	4828      	ldr	r0, [pc, #160]	@ (200263dc <_printf_i+0x238>)
2002633c:	e7e9      	b.n	20026312 <_printf_i+0x16e>
2002633e:	6823      	ldr	r3, [r4, #0]
20026340:	f023 0320 	bic.w	r3, r3, #32
20026344:	6023      	str	r3, [r4, #0]
20026346:	e7f6      	b.n	20026336 <_printf_i+0x192>
20026348:	230a      	movs	r3, #10
2002634a:	e7a4      	b.n	20026296 <_printf_i+0xf2>
2002634c:	4616      	mov	r6, r2
2002634e:	e7bb      	b.n	200262c8 <_printf_i+0x124>
20026350:	6833      	ldr	r3, [r6, #0]
20026352:	6825      	ldr	r5, [r4, #0]
20026354:	1d18      	adds	r0, r3, #4
20026356:	6961      	ldr	r1, [r4, #20]
20026358:	6030      	str	r0, [r6, #0]
2002635a:	062e      	lsls	r6, r5, #24
2002635c:	681b      	ldr	r3, [r3, #0]
2002635e:	d501      	bpl.n	20026364 <_printf_i+0x1c0>
20026360:	6019      	str	r1, [r3, #0]
20026362:	e002      	b.n	2002636a <_printf_i+0x1c6>
20026364:	0668      	lsls	r0, r5, #25
20026366:	d5fb      	bpl.n	20026360 <_printf_i+0x1bc>
20026368:	8019      	strh	r1, [r3, #0]
2002636a:	2300      	movs	r3, #0
2002636c:	4616      	mov	r6, r2
2002636e:	6123      	str	r3, [r4, #16]
20026370:	e7ba      	b.n	200262e8 <_printf_i+0x144>
20026372:	6833      	ldr	r3, [r6, #0]
20026374:	2100      	movs	r1, #0
20026376:	1d1a      	adds	r2, r3, #4
20026378:	6032      	str	r2, [r6, #0]
2002637a:	681e      	ldr	r6, [r3, #0]
2002637c:	6862      	ldr	r2, [r4, #4]
2002637e:	4630      	mov	r0, r6
20026380:	f7ff fcf7 	bl	20025d72 <memchr>
20026384:	b108      	cbz	r0, 2002638a <_printf_i+0x1e6>
20026386:	1b80      	subs	r0, r0, r6
20026388:	6060      	str	r0, [r4, #4]
2002638a:	6863      	ldr	r3, [r4, #4]
2002638c:	6123      	str	r3, [r4, #16]
2002638e:	2300      	movs	r3, #0
20026390:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026394:	e7a8      	b.n	200262e8 <_printf_i+0x144>
20026396:	6923      	ldr	r3, [r4, #16]
20026398:	4632      	mov	r2, r6
2002639a:	4649      	mov	r1, r9
2002639c:	4640      	mov	r0, r8
2002639e:	47d0      	blx	sl
200263a0:	3001      	adds	r0, #1
200263a2:	d0ab      	beq.n	200262fc <_printf_i+0x158>
200263a4:	6823      	ldr	r3, [r4, #0]
200263a6:	079b      	lsls	r3, r3, #30
200263a8:	d413      	bmi.n	200263d2 <_printf_i+0x22e>
200263aa:	68e0      	ldr	r0, [r4, #12]
200263ac:	9b03      	ldr	r3, [sp, #12]
200263ae:	4298      	cmp	r0, r3
200263b0:	bfb8      	it	lt
200263b2:	4618      	movlt	r0, r3
200263b4:	e7a4      	b.n	20026300 <_printf_i+0x15c>
200263b6:	2301      	movs	r3, #1
200263b8:	4632      	mov	r2, r6
200263ba:	4649      	mov	r1, r9
200263bc:	4640      	mov	r0, r8
200263be:	47d0      	blx	sl
200263c0:	3001      	adds	r0, #1
200263c2:	d09b      	beq.n	200262fc <_printf_i+0x158>
200263c4:	3501      	adds	r5, #1
200263c6:	68e3      	ldr	r3, [r4, #12]
200263c8:	9903      	ldr	r1, [sp, #12]
200263ca:	1a5b      	subs	r3, r3, r1
200263cc:	42ab      	cmp	r3, r5
200263ce:	dcf2      	bgt.n	200263b6 <_printf_i+0x212>
200263d0:	e7eb      	b.n	200263aa <_printf_i+0x206>
200263d2:	2500      	movs	r5, #0
200263d4:	f104 0619 	add.w	r6, r4, #25
200263d8:	e7f5      	b.n	200263c6 <_printf_i+0x222>
200263da:	bf00      	nop
200263dc:	20026a02 	.word	0x20026a02
200263e0:	20026a13 	.word	0x20026a13

200263e4 <__swhatbuf_r>:
200263e4:	b570      	push	{r4, r5, r6, lr}
200263e6:	460c      	mov	r4, r1
200263e8:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200263ec:	b096      	sub	sp, #88	@ 0x58
200263ee:	4615      	mov	r5, r2
200263f0:	2900      	cmp	r1, #0
200263f2:	461e      	mov	r6, r3
200263f4:	da0a      	bge.n	2002640c <__swhatbuf_r+0x28>
200263f6:	89a1      	ldrh	r1, [r4, #12]
200263f8:	f011 0180 	ands.w	r1, r1, #128	@ 0x80
200263fc:	d113      	bne.n	20026426 <__swhatbuf_r+0x42>
200263fe:	f44f 6280 	mov.w	r2, #1024	@ 0x400
20026402:	2000      	movs	r0, #0
20026404:	6031      	str	r1, [r6, #0]
20026406:	602a      	str	r2, [r5, #0]
20026408:	b016      	add	sp, #88	@ 0x58
2002640a:	bd70      	pop	{r4, r5, r6, pc}
2002640c:	466a      	mov	r2, sp
2002640e:	f000 f847 	bl	200264a0 <_fstat_r>
20026412:	2800      	cmp	r0, #0
20026414:	dbef      	blt.n	200263f6 <__swhatbuf_r+0x12>
20026416:	9901      	ldr	r1, [sp, #4]
20026418:	f401 4170 	and.w	r1, r1, #61440	@ 0xf000
2002641c:	f5a1 5300 	sub.w	r3, r1, #8192	@ 0x2000
20026420:	4259      	negs	r1, r3
20026422:	4159      	adcs	r1, r3
20026424:	e7eb      	b.n	200263fe <__swhatbuf_r+0x1a>
20026426:	2100      	movs	r1, #0
20026428:	2240      	movs	r2, #64	@ 0x40
2002642a:	e7ea      	b.n	20026402 <__swhatbuf_r+0x1e>

2002642c <__smakebuf_r>:
2002642c:	898b      	ldrh	r3, [r1, #12]
2002642e:	b573      	push	{r0, r1, r4, r5, r6, lr}
20026430:	079e      	lsls	r6, r3, #30
20026432:	4605      	mov	r5, r0
20026434:	460c      	mov	r4, r1
20026436:	d507      	bpl.n	20026448 <__smakebuf_r+0x1c>
20026438:	f104 0347 	add.w	r3, r4, #71	@ 0x47
2002643c:	6023      	str	r3, [r4, #0]
2002643e:	6123      	str	r3, [r4, #16]
20026440:	2301      	movs	r3, #1
20026442:	6163      	str	r3, [r4, #20]
20026444:	b002      	add	sp, #8
20026446:	bd70      	pop	{r4, r5, r6, pc}
20026448:	ab01      	add	r3, sp, #4
2002644a:	466a      	mov	r2, sp
2002644c:	f7ff ffca 	bl	200263e4 <__swhatbuf_r>
20026450:	9e00      	ldr	r6, [sp, #0]
20026452:	4628      	mov	r0, r5
20026454:	4631      	mov	r1, r6
20026456:	f7ff f8dd 	bl	20025614 <_malloc_r>
2002645a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002645e:	b938      	cbnz	r0, 20026470 <__smakebuf_r+0x44>
20026460:	059a      	lsls	r2, r3, #22
20026462:	d4ef      	bmi.n	20026444 <__smakebuf_r+0x18>
20026464:	f023 0303 	bic.w	r3, r3, #3
20026468:	f043 0302 	orr.w	r3, r3, #2
2002646c:	81a3      	strh	r3, [r4, #12]
2002646e:	e7e3      	b.n	20026438 <__smakebuf_r+0xc>
20026470:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20026474:	6020      	str	r0, [r4, #0]
20026476:	81a3      	strh	r3, [r4, #12]
20026478:	9b01      	ldr	r3, [sp, #4]
2002647a:	e9c4 0604 	strd	r0, r6, [r4, #16]
2002647e:	2b00      	cmp	r3, #0
20026480:	d0e0      	beq.n	20026444 <__smakebuf_r+0x18>
20026482:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20026486:	4628      	mov	r0, r5
20026488:	f000 f81c 	bl	200264c4 <_isatty_r>
2002648c:	2800      	cmp	r0, #0
2002648e:	d0d9      	beq.n	20026444 <__smakebuf_r+0x18>
20026490:	89a3      	ldrh	r3, [r4, #12]
20026492:	f023 0303 	bic.w	r3, r3, #3
20026496:	f043 0301 	orr.w	r3, r3, #1
2002649a:	81a3      	strh	r3, [r4, #12]
2002649c:	e7d2      	b.n	20026444 <__smakebuf_r+0x18>
	...

200264a0 <_fstat_r>:
200264a0:	b538      	push	{r3, r4, r5, lr}
200264a2:	2300      	movs	r3, #0
200264a4:	4d06      	ldr	r5, [pc, #24]	@ (200264c0 <_fstat_r+0x20>)
200264a6:	4604      	mov	r4, r0
200264a8:	4608      	mov	r0, r1
200264aa:	4611      	mov	r1, r2
200264ac:	602b      	str	r3, [r5, #0]
200264ae:	f7fb f903 	bl	200216b8 <_fstat>
200264b2:	1c43      	adds	r3, r0, #1
200264b4:	d102      	bne.n	200264bc <_fstat_r+0x1c>
200264b6:	682b      	ldr	r3, [r5, #0]
200264b8:	b103      	cbz	r3, 200264bc <_fstat_r+0x1c>
200264ba:	6023      	str	r3, [r4, #0]
200264bc:	bd38      	pop	{r3, r4, r5, pc}
200264be:	bf00      	nop
200264c0:	2004d030 	.word	0x2004d030

200264c4 <_isatty_r>:
200264c4:	b538      	push	{r3, r4, r5, lr}
200264c6:	2300      	movs	r3, #0
200264c8:	4d05      	ldr	r5, [pc, #20]	@ (200264e0 <_isatty_r+0x1c>)
200264ca:	4604      	mov	r4, r0
200264cc:	4608      	mov	r0, r1
200264ce:	602b      	str	r3, [r5, #0]
200264d0:	f7fb f8f4 	bl	200216bc <_isatty>
200264d4:	1c43      	adds	r3, r0, #1
200264d6:	d102      	bne.n	200264de <_isatty_r+0x1a>
200264d8:	682b      	ldr	r3, [r5, #0]
200264da:	b103      	cbz	r3, 200264de <_isatty_r+0x1a>
200264dc:	6023      	str	r3, [r4, #0]
200264de:	bd38      	pop	{r3, r4, r5, pc}
200264e0:	2004d030 	.word	0x2004d030

200264e4 <_sbrk>:
200264e4:	4a05      	ldr	r2, [pc, #20]	@ (200264fc <_sbrk+0x18>)
200264e6:	4603      	mov	r3, r0
200264e8:	6810      	ldr	r0, [r2, #0]
200264ea:	b110      	cbz	r0, 200264f2 <_sbrk+0xe>
200264ec:	4403      	add	r3, r0
200264ee:	6013      	str	r3, [r2, #0]
200264f0:	4770      	bx	lr
200264f2:	4803      	ldr	r0, [pc, #12]	@ (20026500 <_sbrk+0x1c>)
200264f4:	4403      	add	r3, r0
200264f6:	6013      	str	r3, [r2, #0]
200264f8:	4770      	bx	lr
200264fa:	bf00      	nop
200264fc:	2004d038 	.word	0x2004d038
20026500:	20042000 	.word	0x20042000
20026504:	61766e69 	.word	0x61766e69
20026508:	2064696c 	.word	0x2064696c
2002650c:	746f6f62 	.word	0x746f6f62
20026510:	76656420 	.word	0x76656420
20026514:	00656369 	.word	0x00656369
20026518:	693a4c42 	.word	0x693a4c42
2002651c:	6c61766e 	.word	0x6c61766e
20026520:	66206469 	.word	0x66206469
20026524:	20626174 	.word	0x20626174
20026528:	6967616d 	.word	0x6967616d
2002652c:	72662063 	.word	0x72662063
20026530:	64206d6f 	.word	0x64206d6f
20026534:	63697665 	.word	0x63697665
20026538:	64253a65 	.word	0x64253a65
2002653c:	4c42000a 	.word	0x4c42000a
20026540:	6f6f623a 	.word	0x6f6f623a
20026544:	65642074 	.word	0x65642074
20026548:	65636976 	.word	0x65636976
2002654c:	696e6920 	.word	0x696e6920
20026550:	61662074 	.word	0x61662074
20026554:	66206c69 	.word	0x66206c69
20026558:	3a6d6f72 	.word	0x3a6d6f72
2002655c:	000a6425 	.word	0x000a6425
20026560:	64616f6c 	.word	0x64616f6c
20026564:	6e616220 	.word	0x6e616220
20026568:	6620306b 	.word	0x6620306b
2002656c:	736c6961 	.word	0x736c6961
20026570:	616d6900 	.word	0x616d6900
20026574:	73206567 	.word	0x73206567
20026578:	616e6769 	.word	0x616e6769
2002657c:	65727574 	.word	0x65727574
20026580:	72657620 	.word	0x72657620
20026584:	63696669 	.word	0x63696669
20026588:	6f697461 	.word	0x6f697461
2002658c:	6166206e 	.word	0x6166206e
20026590:	00736c69 	.word	0x00736c69
20026594:	61727370 	.word	0x61727370
20026598:	7000316d 	.word	0x7000316d
2002659c:	6d617273 	.word	0x6d617273
200265a0:	614d0032 	.word	0x614d0032
200265a4:	72652070 	.word	0x72652070
200265a8:	3a726f72 	.word	0x3a726f72
200265ac:	676f6c20 	.word	0x676f6c20
200265b0:	25206369 	.word	0x25206369
200265b4:	70202c64 	.word	0x70202c64
200265b8:	25207968 	.word	0x25207968
200265bc:	45000a64 	.word	0x45000a64
200265c0:	203a5252 	.word	0x203a5252
200265c4:	6f6c2032 	.word	0x6f6c2032
200265c8:	20636967 	.word	0x20636967
200265cc:	636f6c62 	.word	0x636f6c62
200265d0:	6d20736b 	.word	0x6d20736b
200265d4:	74207061 	.word	0x74207061
200265d8:	6173206f 	.word	0x6173206f
200265dc:	6220656d 	.word	0x6220656d
200265e0:	203a6b6c 	.word	0x203a6b6c
200265e4:	69676f6c 	.word	0x69676f6c
200265e8:	25203063 	.word	0x25203063
200265ec:	70202c64 	.word	0x70202c64
200265f0:	20307968 	.word	0x20307968
200265f4:	202c6425 	.word	0x202c6425
200265f8:	69676f6c 	.word	0x69676f6c
200265fc:	25203163 	.word	0x25203163
20026600:	70202c64 	.word	0x70202c64
20026604:	20317968 	.word	0x20317968
20026608:	000a6425 	.word	0x000a6425
2002660c:	2070614d 	.word	0x2070614d
20026610:	6f727265 	.word	0x6f727265
20026614:	203a3072 	.word	0x203a3072
20026618:	69676f6c 	.word	0x69676f6c
2002661c:	64252063 	.word	0x64252063
20026620:	6870202c 	.word	0x6870202c
20026624:	64252079 	.word	0x64252079
20026628:	6547000a 	.word	0x6547000a
2002662c:	616d2074 	.word	0x616d2074
20026630:	6c622070 	.word	0x6c622070
20026634:	206b636f 	.word	0x206b636f
20026638:	6f727265 	.word	0x6f727265
2002663c:	64252072 	.word	0x64252072
20026640:	3e2d2d20 	.word	0x3e2d2d20
20026644:	0a642520 	.word	0x0a642520
20026648:	4d424200 	.word	0x4d424200
2002664c:	72657620 	.word	0x72657620
20026650:	6e6f6973 	.word	0x6e6f6973
20026654:	746f6e20 	.word	0x746f6e20
20026658:	636e6920 	.word	0x636e6920
2002665c:	73616572 	.word	0x73616572
20026660:	203a6465 	.word	0x203a6465
20026664:	76657270 	.word	0x76657270
20026668:	2c642520 	.word	0x2c642520
2002666c:	72756320 	.word	0x72756320
20026670:	64252072 	.word	0x64252072
20026674:	4144000a 	.word	0x4144000a
20026678:	6e204154 	.word	0x6e204154
2002667c:	7220746f 	.word	0x7220746f
20026680:	6f736165 	.word	0x6f736165
20026684:	6c62616e 	.word	0x6c62616e
20026688:	6e692065 	.word	0x6e692065
2002668c:	4d424220 	.word	0x4d424220
20026690:	6b6c6220 	.word	0x6b6c6220
20026694:	20642520 	.word	0x20642520
20026698:	65676170 	.word	0x65676170
2002669c:	3a642520 	.word	0x3a642520
200266a0:	25783020 	.word	0x25783020
200266a4:	52000a78 	.word	0x52000a78
200266a8:	20646165 	.word	0x20646165
200266ac:	206d6262 	.word	0x206d6262
200266b0:	206b6c62 	.word	0x206b6c62
200266b4:	70206425 	.word	0x70206425
200266b8:	20656761 	.word	0x20656761
200266bc:	66206425 	.word	0x66206425
200266c0:	0a6c6961 	.word	0x0a6c6961
200266c4:	766e4900 	.word	0x766e4900
200266c8:	64696c61 	.word	0x64696c61
200266cc:	4d424220 	.word	0x4d424220
200266d0:	58444920 	.word	0x58444920
200266d4:	0a642520 	.word	0x0a642520
200266d8:	20315600 	.word	0x20315600
200266dc:	69206425 	.word	0x69206425
200266e0:	6c62206e 	.word	0x6c62206e
200266e4:	206b636f 	.word	0x206b636f
200266e8:	202c6425 	.word	0x202c6425
200266ec:	25203256 	.word	0x25203256
200266f0:	6e692064 	.word	0x6e692064
200266f4:	6f6c6220 	.word	0x6f6c6220
200266f8:	25206b63 	.word	0x25206b63
200266fc:	53000a64 	.word	0x53000a64
20026700:	74656d61 	.word	0x74656d61
20026704:	676e6968 	.word	0x676e6968
20026708:	73756d20 	.word	0x73756d20
2002670c:	65622074 	.word	0x65622074
20026710:	6f727720 	.word	0x6f727720
20026714:	202c676e 	.word	0x202c676e
20026718:	20746567 	.word	0x20746567
2002671c:	2077656e 	.word	0x2077656e
20026720:	73726576 	.word	0x73726576
20026724:	206e6f69 	.word	0x206e6f69
20026728:	64206425 	.word	0x64206425
2002672c:	6f6e206f 	.word	0x6f6e206f
20026730:	61732074 	.word	0x61732074
20026734:	7420656d 	.word	0x7420656d
20026738:	7270206f 	.word	0x7270206f
2002673c:	63207665 	.word	0x63207665
20026740:	6b636568 	.word	0x6b636568
20026744:	0a642520 	.word	0x0a642520
20026748:	43524300 	.word	0x43524300
2002674c:	65686320 	.word	0x65686320
20026750:	65206b63 	.word	0x65206b63
20026754:	726f7272 	.word	0x726f7272
20026758:	52000a20 	.word	0x52000a20
2002675c:	20646165 	.word	0x20646165
20026760:	206d6262 	.word	0x206d6262
20026764:	206b6c62 	.word	0x206b6c62
20026768:	70206425 	.word	0x70206425
2002676c:	20656761 	.word	0x20656761
20026770:	64206425 	.word	0x64206425
20026774:	20617461 	.word	0x20617461
20026778:	20746f6e 	.word	0x20746f6e
2002677c:	74697277 	.word	0x74697277
20026780:	6f662065 	.word	0x6f662065
20026784:	6e322072 	.word	0x6e322072
20026788:	69742064 	.word	0x69742064
2002678c:	000a656d 	.word	0x000a656d
20026790:	64616552 	.word	0x64616552
20026794:	6d626220 	.word	0x6d626220
20026798:	6b6c6220 	.word	0x6b6c6220
2002679c:	20642520 	.word	0x20642520
200267a0:	65676170 	.word	0x65676170
200267a4:	20642520 	.word	0x20642520
200267a8:	6c696166 	.word	0x6c696166
200267ac:	726f6620 	.word	0x726f6620
200267b0:	646e3220 	.word	0x646e3220
200267b4:	6d697420 	.word	0x6d697420
200267b8:	000a3f65 	.word	0x000a3f65
200267bc:	6574614c 	.word	0x6574614c
200267c0:	76207473 	.word	0x76207473
200267c4:	69737265 	.word	0x69737265
200267c8:	25206e6f 	.word	0x25206e6f
200267cc:	47000a64 	.word	0x47000a64
200267d0:	70207465 	.word	0x70207465
200267d4:	62207968 	.word	0x62207968
200267d8:	66206b6c 	.word	0x66206b6c
200267dc:	2520726f 	.word	0x2520726f
200267e0:	61662064 	.word	0x61662064
200267e4:	77206c69 	.word	0x77206c69
200267e8:	206e6568 	.word	0x206e6568
200267ec:	64616572 	.word	0x64616572
200267f0:	6c42000a 	.word	0x6c42000a
200267f4:	206b636f 	.word	0x206b636f
200267f8:	65206425 	.word	0x65206425
200267fc:	65736172 	.word	0x65736172
20026800:	69616620 	.word	0x69616620
20026804:	6d202c6c 	.word	0x6d202c6c
20026808:	206b7261 	.word	0x206b7261
2002680c:	62207361 	.word	0x62207361
20026810:	000a6461 	.word	0x000a6461
20026814:	636f6c42 	.word	0x636f6c42
20026818:	6425206b 	.word	0x6425206b
2002681c:	65686320 	.word	0x65686320
20026820:	61206b63 	.word	0x61206b63
20026824:	61622073 	.word	0x61622073
20026828:	6c622064 	.word	0x6c622064
2002682c:	0a6b636f 	.word	0x0a6b636f
20026830:	6f6c4200 	.word	0x6f6c4200
20026834:	25206b63 	.word	0x25206b63
20026838:	73692064 	.word	0x73692064
2002683c:	64616220 	.word	0x64616220
20026840:	206e6920 	.word	0x206e6920
20026844:	72657375 	.word	0x72657375
20026848:	6f6c6220 	.word	0x6f6c6220
2002684c:	000a6b63 	.word	0x000a6b63
20026850:	20646162 	.word	0x20646162
20026854:	202c6425 	.word	0x202c6425
20026858:	6c706572 	.word	0x6c706572
2002685c:	20656361 	.word	0x20656361
20026860:	000a6425 	.word	0x000a6425
20026864:	62206f4e 	.word	0x62206f4e
20026868:	756b6361 	.word	0x756b6361
2002686c:	6c622070 	.word	0x6c622070
20026870:	206b636f 	.word	0x206b636f
20026874:	20796e61 	.word	0x20796e61
20026878:	65726f6d 	.word	0x65726f6d
2002687c:	6d65000a 	.word	0x6d65000a
20026880:	20797470 	.word	0x20797470
20026884:	6c626174 	.word	0x6c626174
20026888:	64252065 	.word	0x64252065
2002688c:	746f6e20 	.word	0x746f6e20
20026890:	6f6e6520 	.word	0x6f6e6520
20026894:	20686775 	.word	0x20686775
20026898:	20726f66 	.word	0x20726f66
2002689c:	74696e69 	.word	0x74696e69
200268a0:	0a6c6169 	.word	0x0a6c6169
200268a4:	64705500 	.word	0x64705500
200268a8:	20657461 	.word	0x20657461
200268ac:	6c626174 	.word	0x6c626174
200268b0:	6f742065 	.word	0x6f742065
200268b4:	616c6620 	.word	0x616c6620
200268b8:	64206873 	.word	0x64206873
200268bc:	0a656e6f 	.word	0x0a656e6f
200268c0:	696e4900 	.word	0x696e4900
200268c4:	6c616974 	.word	0x6c616974
200268c8:	62617420 	.word	0x62617420
200268cc:	6620656c 	.word	0x6620656c
200268d0:	0a6c6961 	.word	0x0a6c6961
200268d4:	4d424200 	.word	0x4d424200
200268d8:	696e6920 	.word	0x696e6920
200268dc:	6c616974 	.word	0x6c616974
200268e0:	64657a69 	.word	0x64657a69
200268e4:	66656220 	.word	0x66656220
200268e8:	2c65726f 	.word	0x2c65726f
200268ec:	206f6420 	.word	0x206f6420
200268f0:	20746f6e 	.word	0x20746f6e
200268f4:	74696e69 	.word	0x74696e69
200268f8:	796e6120 	.word	0x796e6120
200268fc:	726f6d20 	.word	0x726f6d20
20026900:	44000a65 	.word	0x44000a65
20026904:	25205445 	.word	0x25205445
20026908:	61622064 	.word	0x61622064
2002690c:	42000a64 	.word	0x42000a64
20026910:	25204b4c 	.word	0x25204b4c
20026914:	65722064 	.word	0x65722064
20026918:	66206461 	.word	0x66206461
2002691c:	2c6c6961 	.word	0x2c6c6961
20026920:	72616d20 	.word	0x72616d20
20026924:	7361206b 	.word	0x7361206b
20026928:	64616220 	.word	0x64616220
2002692c:	6564000a 	.word	0x6564000a
20026930:	62622074 	.word	0x62622074
20026934:	6174206d 	.word	0x6174206d
20026938:	20656c62 	.word	0x20656c62
2002693c:	68746977 	.word	0x68746977
20026940:	2c642520 	.word	0x2c642520
20026944:	2c642520 	.word	0x2c642520
20026948:	0a642520 	.word	0x0a642520
2002694c:	74656400 	.word	0x74656400
20026950:	20746365 	.word	0x20746365
20026954:	75736572 	.word	0x75736572
20026958:	2520746c 	.word	0x2520746c
2002695c:	76000a64 	.word	0x76000a64
20026960:	64252031 	.word	0x64252031
20026964:	206e6920 	.word	0x206e6920
20026968:	206b6c62 	.word	0x206b6c62
2002696c:	202c6425 	.word	0x202c6425
20026970:	25203276 	.word	0x25203276
20026974:	6e692064 	.word	0x6e692064
20026978:	6f6c6220 	.word	0x6f6c6220
2002697c:	25206b63 	.word	0x25206b63
20026980:	43000a64 	.word	0x43000a64
20026984:	6b636568 	.word	0x6b636568
20026988:	6d626220 	.word	0x6d626220
2002698c:	62617420 	.word	0x62617420
20026990:	6620656c 	.word	0x6620656c
20026994:	0a6c6961 	.word	0x0a6c6961
20026998:	74656400 	.word	0x74656400
2002699c:	20746365 	.word	0x20746365
200269a0:	75736572 	.word	0x75736572
200269a4:	2520746c 	.word	0x2520746c
200269a8:	6f6e2064 	.word	0x6f6e2064
200269ac:	65722074 	.word	0x65722074
200269b0:	6e6f7361 	.word	0x6e6f7361
200269b4:	656c6261 	.word	0x656c6261
200269b8:	4242000a 	.word	0x4242000a
200269bc:	454d204d 	.word	0x454d204d
200269c0:	63203a4d 	.word	0x63203a4d
200269c4:	25207874 	.word	0x25207874
200269c8:	6d202c70 	.word	0x6d202c70
200269cc:	20317061 	.word	0x20317061
200269d0:	202c7025 	.word	0x202c7025
200269d4:	3270616d 	.word	0x3270616d
200269d8:	20702520 	.word	0x20702520
200269dc:	6973000a 	.word	0x6973000a
200269e0:	62625f66 	.word	0x62625f66
200269e4:	6e695f6d 	.word	0x6e695f6d
200269e8:	64207469 	.word	0x64207469
200269ec:	0a656e6f 	.word	0x0a656e6f
200269f0:	302d2300 	.word	0x302d2300
200269f4:	6800202b 	.word	0x6800202b
200269f8:	65004c6c 	.word	0x65004c6c
200269fc:	46456766 	.word	0x46456766
20026a00:	31300047 	.word	0x31300047
20026a04:	35343332 	.word	0x35343332
20026a08:	39383736 	.word	0x39383736
20026a0c:	44434241 	.word	0x44434241
20026a10:	30004645 	.word	0x30004645
20026a14:	34333231 	.word	0x34333231
20026a18:	38373635 	.word	0x38373635
20026a1c:	63626139 	.word	0x63626139
20026a20:	00666564 	.word	0x00666564
20026a24:	50042000 	.word	0x50042000
20026a28:	00000002 	.word	0x00000002
20026a2c:	12000000 	.word	0x12000000
20026a30:	00000004 	.word	0x00000004
20026a34:	00000000 	.word	0x00000000
20026a38:	50041000 	.word	0x50041000
20026a3c:	00000002 	.word	0x00000002
20026a40:	10000000 	.word	0x10000000
20026a44:	00000004 	.word	0x00000004
20026a48:	00000000 	.word	0x00000000
20026a4c:	50043000 	.word	0x50043000
20026a50:	00000002 	.word	0x00000002
20026a54:	14000000 	.word	0x14000000
20026a58:	00000004 	.word	0x00000004
20026a5c:	00000000 	.word	0x00000000

20026a60 <bf0_psram_cfg>:
20026a60:	20026594 50041000 00040005 10000000     .e. ...P........
20026a70:	20027571 2002659b 50042000 00040005     qu. .e. . .P....
20026a80:	12000000 200277ed                       .....w. 

20026a88 <pad_fsel_func_tbls>:
20026a88:	20027080 20027074 20027068 2002705c     .p. tp. hp. \p. 
20026a98:	20027050 20027044 20027038 2002702c     Pp. Dp. 8p. ,p. 
20026aa8:	20027020 20027010 20027004 20026ff4      p. .p. .p. .o. 
20026ab8:	20026fe0 20026fd8 20026fcc 20026fc0     .o. .o. .o. .o. 
20026ac8:	20026fb4 20026fa8 20026f9c 20026f8c     .o. .o. .o. .o. 
20026ad8:	20026f7c 20026f6c 20026f5c 20026f4c     |o. lo. \o. Lo. 
20026ae8:	20026f3c 20026f28 20026f18 20026f0c     <o. (o. .o. .o. 
20026af8:	20026ef8 20026ee4 20026ed0 20026ebc     .n. .n. .n. .n. 
20026b08:	20026ea8 20026e94 20026e80 20026e70     .n. .n. .n. pn. 
20026b18:	20026e64 20026e50 20026e40 20026e30     dn. Pn. @n. 0n. 
20026b28:	20026e20 20026e10 20026e00 20026df0      n. .n. .n. .m. 
20026b38:	20026de0 20026dd0 20026dc0 20026db8     .m. .m. .m. .m. 
20026b48:	20026da8 20026d98 20026d84 20026d70     .m. .m. .m. pm. 
20026b58:	20026d60 20026d50 20026d40 20026d30     `m. Pm. @m. 0m. 
20026b68:	20026d24 20026d14 20026d08 20026cfc     $m. .m. .m. .l. 
20026b78:	20026cf4 20026cec 20026ce4 20026cd0     .l. .l. .l. .l. 
20026b88:	20026cc0 20026cac 20026c98 20026c88     .l. .l. .l. .l. 
20026b98:	20026c78 20026c68 20026c58 20026c4c     xl. hl. Xl. Ll. 
20026ba8:	20026c40 20026c34 20026c28 20026c1c     @l. 4l. (l. .l. 
20026bb8:	20026c10 20026c08 20026c00 20026bf8     .l. .l. .l. .k. 
20026bc8:	20026bf0 20026be8 20026be0 20026bd8     .k. .k. .k. .k. 

20026bd8 <pad_pa57_fsel_func_tbl>:
20026bd8:	01670000 00000000                       ..g.....

20026be0 <pad_pa56_fsel_func_tbl>:
20026be0:	01660000 00000000                       ..f.....

20026be8 <pad_pa55_fsel_func_tbl>:
20026be8:	01650000 00000000                       ..e.....

20026bf0 <pad_pa54_fsel_func_tbl>:
20026bf0:	01640000 00000000                       ..d.....

20026bf8 <pad_pa53_fsel_func_tbl>:
20026bf8:	01630000 00000000                       ..c.....

20026c00 <pad_pa52_fsel_func_tbl>:
20026c00:	01620000 00000000                       ..b.....

20026c08 <pad_pa51_fsel_func_tbl>:
20026c08:	01610000 00000000                       ..a.....

20026c10 <pad_pa50_fsel_func_tbl>:
20026c10:	01600000 01870003 00000000              ..`.........

20026c1c <pad_pa49_fsel_func_tbl>:
20026c1c:	015f0000 01860003 00000000              .._.........

20026c28 <pad_pa48_fsel_func_tbl>:
20026c28:	015e0000 01850003 00000000              ..^.........

20026c34 <pad_pa47_fsel_func_tbl>:
20026c34:	015d0000 01830003 00000000              ..].........

20026c40 <pad_pa46_fsel_func_tbl>:
20026c40:	015c0000 01890003 00000000              ..\.........

20026c4c <pad_pa45_fsel_func_tbl>:
20026c4c:	015b0000 01880003 00000000              ..[.........

20026c58 <pad_pa44_fsel_func_tbl>:
20026c58:	015a0000 018c0001 01b70007 00000000     ..Z.............

20026c68 <pad_pa43_fsel_func_tbl>:
20026c68:	01590000 018b0001 01b60007 00000000     ..Y.............

20026c78 <pad_pa42_fsel_func_tbl>:
20026c78:	01580000 017c0002 01b50007 00000000     ..X...|.........

20026c88 <pad_pa41_fsel_func_tbl>:
20026c88:	01570000 017b0002 01b40007 00000000     ..W...{.........

20026c98 <pad_pa40_fsel_func_tbl>:
20026c98:	01560000 01750001 017a0002 01b30007     ..V...u...z.....
20026ca8:	00000000                                ....

20026cac <pad_pa39_fsel_func_tbl>:
20026cac:	01550000 01740001 01780002 01b20007     ..U...t...x.....
20026cbc:	00000000                                ....

20026cc0 <pad_pa38_fsel_func_tbl>:
20026cc0:	01540000 01760001 017e0002 00000000     ..T...v...~.....

20026cd0 <pad_pa37_fsel_func_tbl>:
20026cd0:	01530000 01770001 017d0002 01b10007     ..S...w...}.....
20026ce0:	00000000                                ....

20026ce4 <pad_pa36_fsel_func_tbl>:
20026ce4:	01520000 00000000                       ..R.....

20026cec <pad_pa35_fsel_func_tbl>:
20026cec:	01510000 00000000                       ..Q.....

20026cf4 <pad_pa34_fsel_func_tbl>:
20026cf4:	01500000 00000000                       ..P.....

20026cfc <pad_pa33_fsel_func_tbl>:
20026cfc:	014f0000 01870003 00000000              ..O.........

20026d08 <pad_pa32_fsel_func_tbl>:
20026d08:	014e0000 01860003 00000000              ..N.........

20026d14 <pad_pa31_fsel_func_tbl>:
20026d14:	014d0000 01850003 01b00007 00000000     ..M.............

20026d24 <pad_pa30_fsel_func_tbl>:
20026d24:	014c0000 01830003 00000000              ..L.........

20026d30 <pad_pa29_fsel_func_tbl>:
20026d30:	014b0000 01710001 01890003 00000000     ..K...q.........

20026d40 <pad_pa28_fsel_func_tbl>:
20026d40:	014a0000 01700001 01880003 00000000     ..J...p.........

20026d50 <pad_pa27_fsel_func_tbl>:
20026d50:	01490000 017c0002 01870003 00000000     ..I...|.........

20026d60 <pad_pa26_fsel_func_tbl>:
20026d60:	01480000 017b0002 01860003 00000000     ..H...{.........

20026d70 <pad_pa25_fsel_func_tbl>:
20026d70:	01470000 01720001 017a0002 01850003     ..G...r...z.....
20026d80:	00000000                                ....

20026d84 <pad_pa24_fsel_func_tbl>:
20026d84:	01460000 01730001 01780002 01830003     ..F...s...x.....
20026d94:	00000000                                ....

20026d98 <pad_pa23_fsel_func_tbl>:
20026d98:	01450000 017e0002 01890003 00000000     ..E...~.........

20026da8 <pad_pa22_fsel_func_tbl>:
20026da8:	01440000 017d0002 01880003 00000000     ..D...}.........

20026db8 <pad_pa21_fsel_func_tbl>:
20026db8:	01430000 00000000                       ..C.....

20026dc0 <pad_pa20_fsel_func_tbl>:
20026dc0:	01420000 018d0001 01b80007 00000000     ..B.............

20026dd0 <pad_pa19_fsel_func_tbl>:
20026dd0:	01410000 00200001 018c0002 00000000     ..A... .........

20026de0 <pad_pa18_fsel_func_tbl>:
20026de0:	01400000 00210001 018b0002 00000000     ..@...!.........

20026df0 <pad_pa17_fsel_func_tbl>:
20026df0:	013f0000 012d0001 017c0002 00000000     ..?...-...|.....

20026e00 <pad_pa16_fsel_func_tbl>:
20026e00:	013e0000 01260001 017b0002 00000000     ..>...&...{.....

20026e10 <pad_pa15_fsel_func_tbl>:
20026e10:	013d0000 012a0001 017a0002 00000000     ..=...*...z.....

20026e20 <pad_pa14_fsel_func_tbl>:
20026e20:	013c0000 012c0001 01780002 00000000     ..<...,...x.....

20026e30 <pad_pa13_fsel_func_tbl>:
20026e30:	013b0000 012b0001 017e0002 00000000     ..;...+...~.....

20026e40 <pad_pa12_fsel_func_tbl>:
20026e40:	013a0000 01270001 017d0002 00000000     ..:...'...}.....

20026e50 <pad_pa11_fsel_func_tbl>:
20026e50:	01390000 01280001 017c0002 018a0007     ..9...(...|.....
20026e60:	00000000                                ....

20026e64 <pad_pa10_fsel_func_tbl>:
20026e64:	01380000 017b0002 00000000              ..8...{.....

20026e70 <pad_pa09_fsel_func_tbl>:
20026e70:	01370000 017a0002 01af0007 00000000     ..7...z.........

20026e80 <pad_pa08_fsel_func_tbl>:
20026e80:	01360000 016d0001 01780002 01ae0007     ..6...m...x.....
20026e90:	00000000                                ....

20026e94 <pad_pa07_fsel_func_tbl>:
20026e94:	01350000 016c0001 017e0002 01ad0007     ..5...l...~.....
20026ea4:	00000000                                ....

20026ea8 <pad_pa06_fsel_func_tbl>:
20026ea8:	01340000 016b0001 017d0002 01ac0007     ..4...k...}.....
20026eb8:	00000000                                ....

20026ebc <pad_pa05_fsel_func_tbl>:
20026ebc:	01330000 016a0001 01870003 01ab0007     ..3...j.........
20026ecc:	00000000                                ....

20026ed0 <pad_pa04_fsel_func_tbl>:
20026ed0:	01320000 01690001 01860003 01aa0007     ..2...i.........
20026ee0:	00000000                                ....

20026ee4 <pad_pa03_fsel_func_tbl>:
20026ee4:	01310000 01680001 01850003 01a90007     ..1...h.........
20026ef4:	00000000                                ....

20026ef8 <pad_pa02_fsel_func_tbl>:
20026ef8:	01300000 016f0001 01830003 01a80007     ..0...o.........
20026f08:	00000000                                ....

20026f0c <pad_pa01_fsel_func_tbl>:
20026f0c:	012f0000 01890003 00000000              ../.........

20026f18 <pad_pa00_fsel_func_tbl>:
20026f18:	012e0000 016e0001 01880003 00000000     ......n.........

20026f28 <pad_sb12_fsel_func_tbl>:
20026f28:	011a0001 011b0002 01180003 01160004     ................
20026f38:	00000000                                ....

20026f3c <pad_sb11_fsel_func_tbl>:
20026f3c:	01250001 01160003 01210004 00000000     ..%.......!.....

20026f4c <pad_sb10_fsel_func_tbl>:
20026f4c:	01240001 011b0003 011e0004 00000000     ..$.............

20026f5c <pad_sb09_fsel_func_tbl>:
20026f5c:	01230001 01250003 01260004 00000000     ..#...%...&.....

20026f6c <pad_sb08_fsel_func_tbl>:
20026f6c:	01220001 01240003 012d0004 00000000     .."...$...-.....

20026f7c <pad_sb07_fsel_func_tbl>:
20026f7c:	01160001 01230003 012a0004 00000000     ......#...*.....

20026f8c <pad_sb06_fsel_func_tbl>:
20026f8c:	01170001 01220003 01180004 00000000     ......".........

20026f9c <pad_sb05_fsel_func_tbl>:
20026f9c:	01180001 011f0004 00000000              ............

20026fa8 <pad_sb04_fsel_func_tbl>:
20026fa8:	01210001 01200004 00000000              ..!... .....

20026fb4 <pad_sb03_fsel_func_tbl>:
20026fb4:	01200001 01270004 00000000              .. ...'.....

20026fc0 <pad_sb02_fsel_func_tbl>:
20026fc0:	011f0001 012b0004 00000000              ......+.....

20026fcc <pad_sb01_fsel_func_tbl>:
20026fcc:	011e0001 012c0004 00000000              ......,.....

20026fd8 <pad_sb00_fsel_func_tbl>:
20026fd8:	01190001 00000000                       ........

20026fe0 <pad_sa12_fsel_func_tbl>:
20026fe0:	010a0001 010b0002 01080003 01020004     ................
20026ff0:	00000000                                ....

20026ff4 <pad_sa11_fsel_func_tbl>:
20026ff4:	01150001 01060003 01050004 00000000     ................

20027004 <pad_sa10_fsel_func_tbl>:
20027004:	01140001 01000004 00000000              ............

20027010 <pad_sa09_fsel_func_tbl>:
20027010:	01130001 010b0003 01050004 00000000     ................

20027020 <pad_sa08_fsel_func_tbl>:
20027020:	01120001 01150003 00000000              ............

2002702c <pad_sa07_fsel_func_tbl>:
2002702c:	01060001 01140003 00000000              ............

20027038 <pad_sa06_fsel_func_tbl>:
20027038:	01070001 01130003 00000000              ............

20027044 <pad_sa05_fsel_func_tbl>:
20027044:	01080001 01120003 00000000              ............

20027050 <pad_sa04_fsel_func_tbl>:
20027050:	01110001 01040004 00000000              ............

2002705c <pad_sa03_fsel_func_tbl>:
2002705c:	01100001 01010004 00000000              ............

20027068 <pad_sa02_fsel_func_tbl>:
20027068:	010f0001 01030004 00000000              ............

20027074 <pad_sa01_fsel_func_tbl>:
20027074:	010e0001 01040004 00000000              ............

20027080 <pad_sa00_fsel_func_tbl>:
20027080:	01090001 01010004 00000000 00000000     ................
20027090:	04030201 00000000 01060204              ............

2002709c <hpsys_dll2_limit>:
	...
200270a4:	112a8800 112a8800                       ..*...*.

200270ac <hpsys_dvfs_config>:
200270ac:	000906fb 00100330 000a08fd 00110331     ....0.......1...
200270bc:	000d0b00 00130213 000f0e02 00130213     ................

200270cc <crc32tab>:
200270cc:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
200270dc:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
200270ec:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
200270fc:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
2002710c:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
2002711c:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
2002712c:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
2002713c:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
2002714c:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
2002715c:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
2002716c:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
2002717c:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
2002718c:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
2002719c:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
200271ac:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
200271bc:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
200271cc:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
200271dc:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
200271ec:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
200271fc:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
2002720c:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
2002721c:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
2002722c:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
2002723c:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
2002724c:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
2002725c:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
2002726c:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
2002727c:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
2002728c:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
2002729c:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
200272ac:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
200272bc:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
200272cc:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
200272dc:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
200272ec:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
200272fc:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
2002730c:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
2002731c:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
2002732c:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
2002733c:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
2002734c:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
2002735c:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
2002736c:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
2002737c:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
2002738c:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
2002739c:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
200273ac:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
200273bc:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
200273cc:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
200273dc:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
200273ec:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
200273fc:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
2002740c:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
2002741c:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
2002742c:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
2002743c:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
2002744c:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
2002745c:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
2002746c:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
2002747c:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
2002748c:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
2002749c:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
200274ac:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
200274bc:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

200274cc <_init>:
200274cc:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200274ce:	bf00      	nop
200274d0:	bcf8      	pop	{r3, r4, r5, r6, r7}
200274d2:	bc08      	pop	{r3}
200274d4:	469e      	mov	lr, r3
200274d6:	4770      	bx	lr

200274d8 <_fini>:
200274d8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200274da:	bf00      	nop
200274dc:	bcf8      	pop	{r3, r4, r5, r6, r7}
200274de:	bc08      	pop	{r3}
200274e0:	469e      	mov	lr, r3
200274e2:	4770      	bx	lr

200274e4 <__EH_FRAME_BEGIN__>:
200274e4:	0000 0000                                   ....

Disassembly of section .l1_ret_text_bsp_psram_init_info:

200274e8 <bsp_psram_init_info>:
200274e8:	b507      	push	{r0, r1, r2, lr}
200274ea:	2208      	movs	r2, #8
200274ec:	20e4      	movs	r0, #228	@ 0xe4
200274ee:	f10d 0107 	add.w	r1, sp, #7
200274f2:	f000 fb01 	bl	20027af8 <HAL_EFUSE_Read2>
200274f6:	2807      	cmp	r0, #7
200274f8:	dd0e      	ble.n	20027518 <bsp_psram_init_info+0x30>
200274fa:	f89d 2007 	ldrb.w	r2, [sp, #7]
200274fe:	4b08      	ldr	r3, [pc, #32]	@ (20027520 <bsp_psram_init_info+0x38>)
20027500:	f3c2 1101 	ubfx	r1, r2, #4, #2
20027504:	7059      	strb	r1, [r3, #1]
20027506:	2101      	movs	r1, #1
20027508:	2000      	movs	r0, #0
2002750a:	0992      	lsrs	r2, r2, #6
2002750c:	7019      	strb	r1, [r3, #0]
2002750e:	70da      	strb	r2, [r3, #3]
20027510:	7099      	strb	r1, [r3, #2]
20027512:	b003      	add	sp, #12
20027514:	f85d fb04 	ldr.w	pc, [sp], #4
20027518:	f06f 0001 	mvn.w	r0, #1
2002751c:	e7f9      	b.n	20027512 <bsp_psram_init_info+0x2a>
2002751e:	bf00      	nop
20027520:	2004c990 	.word	0x2004c990

Disassembly of section .l1_ret_text_bsp_psram_get_mpi_mode:

20027524 <bsp_psram_get_mpi_mode>:
20027524:	2801      	cmp	r0, #1
20027526:	b510      	push	{r4, lr}
20027528:	d10e      	bne.n	20027548 <bsp_psram_get_mpi_mode+0x24>
2002752a:	4c0e      	ldr	r4, [pc, #56]	@ (20027564 <bsp_psram_get_mpi_mode+0x40>)
2002752c:	7823      	ldrb	r3, [r4, #0]
2002752e:	b12b      	cbz	r3, 2002753c <bsp_psram_get_mpi_mode+0x18>
20027530:	7863      	ldrb	r3, [r4, #1]
20027532:	4a0d      	ldr	r2, [pc, #52]	@ (20027568 <bsp_psram_get_mpi_mode+0x44>)
20027534:	5cd0      	ldrb	r0, [r2, r3]
20027536:	f000 000f 	and.w	r0, r0, #15
2002753a:	e004      	b.n	20027546 <bsp_psram_get_mpi_mode+0x22>
2002753c:	f7ff ffd4 	bl	200274e8 <bsp_psram_init_info>
20027540:	2800      	cmp	r0, #0
20027542:	d0f5      	beq.n	20027530 <bsp_psram_get_mpi_mode+0xc>
20027544:	2000      	movs	r0, #0
20027546:	bd10      	pop	{r4, pc}
20027548:	2802      	cmp	r0, #2
2002754a:	d1fb      	bne.n	20027544 <bsp_psram_get_mpi_mode+0x20>
2002754c:	4c05      	ldr	r4, [pc, #20]	@ (20027564 <bsp_psram_get_mpi_mode+0x40>)
2002754e:	78a3      	ldrb	r3, [r4, #2]
20027550:	b113      	cbz	r3, 20027558 <bsp_psram_get_mpi_mode+0x34>
20027552:	78e3      	ldrb	r3, [r4, #3]
20027554:	4a05      	ldr	r2, [pc, #20]	@ (2002756c <bsp_psram_get_mpi_mode+0x48>)
20027556:	e7ed      	b.n	20027534 <bsp_psram_get_mpi_mode+0x10>
20027558:	f7ff ffc6 	bl	200274e8 <bsp_psram_init_info>
2002755c:	2800      	cmp	r0, #0
2002755e:	d0f8      	beq.n	20027552 <bsp_psram_get_mpi_mode+0x2e>
20027560:	e7f0      	b.n	20027544 <bsp_psram_get_mpi_mode+0x20>
20027562:	bf00      	nop
20027564:	2004c990 	.word	0x2004c990
20027568:	20027c1c 	.word	0x20027c1c
2002756c:	20027c18 	.word	0x20027c18

Disassembly of section .l1_ret_text_bsp_psram1_pinmux_init:

20027570 <bsp_psram1_pinmux_init>:
20027570:	b538      	push	{r3, r4, r5, lr}
20027572:	4c9c      	ldr	r4, [pc, #624]	@ (200277e4 <bsp_psram1_pinmux_init+0x274>)
20027574:	7823      	ldrb	r3, [r4, #0]
20027576:	2b00      	cmp	r3, #0
20027578:	d07b      	beq.n	20027672 <bsp_psram1_pinmux_init+0x102>
2002757a:	7863      	ldrb	r3, [r4, #1]
2002757c:	4a9a      	ldr	r2, [pc, #616]	@ (200277e8 <bsp_psram1_pinmux_init+0x278>)
2002757e:	5cd4      	ldrb	r4, [r2, r3]
20027580:	0924      	lsrs	r4, r4, #4
20027582:	2c01      	cmp	r4, #1
20027584:	d17d      	bne.n	20027682 <bsp_psram1_pinmux_init+0x112>
20027586:	4623      	mov	r3, r4
20027588:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002758c:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027590:	2002      	movs	r0, #2
20027592:	f7fc fe7d 	bl	20024290 <HAL_PIN_Set>
20027596:	4623      	mov	r3, r4
20027598:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002759c:	f240 110f 	movw	r1, #271	@ 0x10f
200275a0:	2003      	movs	r0, #3
200275a2:	f7fc fe75 	bl	20024290 <HAL_PIN_Set>
200275a6:	4623      	mov	r3, r4
200275a8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275ac:	f44f 7188 	mov.w	r1, #272	@ 0x110
200275b0:	2004      	movs	r0, #4
200275b2:	f7fc fe6d 	bl	20024290 <HAL_PIN_Set>
200275b6:	4623      	mov	r3, r4
200275b8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275bc:	f240 1111 	movw	r1, #273	@ 0x111
200275c0:	2005      	movs	r0, #5
200275c2:	f7fc fe65 	bl	20024290 <HAL_PIN_Set>
200275c6:	4623      	mov	r3, r4
200275c8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275cc:	f44f 7189 	mov.w	r1, #274	@ 0x112
200275d0:	2009      	movs	r0, #9
200275d2:	f7fc fe5d 	bl	20024290 <HAL_PIN_Set>
200275d6:	4623      	mov	r3, r4
200275d8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275dc:	f240 1113 	movw	r1, #275	@ 0x113
200275e0:	200a      	movs	r0, #10
200275e2:	f7fc fe55 	bl	20024290 <HAL_PIN_Set>
200275e6:	4623      	mov	r3, r4
200275e8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275ec:	f44f 718a 	mov.w	r1, #276	@ 0x114
200275f0:	200b      	movs	r0, #11
200275f2:	f7fc fe4d 	bl	20024290 <HAL_PIN_Set>
200275f6:	4623      	mov	r3, r4
200275f8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200275fc:	f240 1115 	movw	r1, #277	@ 0x115
20027600:	200c      	movs	r0, #12
20027602:	f7fc fe45 	bl	20024290 <HAL_PIN_Set>
20027606:	4623      	mov	r3, r4
20027608:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002760c:	f240 1109 	movw	r1, #265	@ 0x109
20027610:	4620      	mov	r0, r4
20027612:	f7fc fe3d 	bl	20024290 <HAL_PIN_Set>
20027616:	4623      	mov	r3, r4
20027618:	2200      	movs	r2, #0
2002761a:	f44f 7184 	mov.w	r1, #264	@ 0x108
2002761e:	2006      	movs	r0, #6
20027620:	f7fc fe36 	bl	20024290 <HAL_PIN_Set>
20027624:	4623      	mov	r3, r4
20027626:	2200      	movs	r2, #0
20027628:	f240 1107 	movw	r1, #263	@ 0x107
2002762c:	2007      	movs	r0, #7
2002762e:	f7fc fe2f 	bl	20024290 <HAL_PIN_Set>
20027632:	4623      	mov	r3, r4
20027634:	2200      	movs	r2, #0
20027636:	f44f 7183 	mov.w	r1, #262	@ 0x106
2002763a:	2008      	movs	r0, #8
2002763c:	f7fc fe28 	bl	20024290 <HAL_PIN_Set>
20027640:	4623      	mov	r3, r4
20027642:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027646:	f44f 7185 	mov.w	r1, #266	@ 0x10a
2002764a:	200d      	movs	r0, #13
2002764c:	f7fc fe20 	bl	20024290 <HAL_PIN_Set>
20027650:	2500      	movs	r5, #0
20027652:	2400      	movs	r4, #0
20027654:	2201      	movs	r2, #1
20027656:	3401      	adds	r4, #1
20027658:	4611      	mov	r1, r2
2002765a:	4620      	mov	r0, r4
2002765c:	f7fc fe48 	bl	200242f0 <HAL_PIN_Set_DS0>
20027660:	2200      	movs	r2, #0
20027662:	2101      	movs	r1, #1
20027664:	4620      	mov	r0, r4
20027666:	f7fc fe59 	bl	2002431c <HAL_PIN_Set_DS1>
2002766a:	2c0d      	cmp	r4, #13
2002766c:	d1f2      	bne.n	20027654 <bsp_psram1_pinmux_init+0xe4>
2002766e:	4628      	mov	r0, r5
20027670:	bd38      	pop	{r3, r4, r5, pc}
20027672:	f7ff ff39 	bl	200274e8 <bsp_psram_init_info>
20027676:	2800      	cmp	r0, #0
20027678:	f43f af7f 	beq.w	2002757a <bsp_psram1_pinmux_init+0xa>
2002767c:	f06f 0501 	mvn.w	r5, #1
20027680:	e7f5      	b.n	2002766e <bsp_psram1_pinmux_init+0xfe>
20027682:	2c02      	cmp	r4, #2
20027684:	d153      	bne.n	2002772e <bsp_psram1_pinmux_init+0x1be>
20027686:	2301      	movs	r3, #1
20027688:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002768c:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027690:	4620      	mov	r0, r4
20027692:	f7fc fdfd 	bl	20024290 <HAL_PIN_Set>
20027696:	2301      	movs	r3, #1
20027698:	f44f 7280 	mov.w	r2, #256	@ 0x100
2002769c:	f240 110f 	movw	r1, #271	@ 0x10f
200276a0:	2003      	movs	r0, #3
200276a2:	f7fc fdf5 	bl	20024290 <HAL_PIN_Set>
200276a6:	2301      	movs	r3, #1
200276a8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276ac:	f44f 7188 	mov.w	r1, #272	@ 0x110
200276b0:	2004      	movs	r0, #4
200276b2:	f7fc fded 	bl	20024290 <HAL_PIN_Set>
200276b6:	2301      	movs	r3, #1
200276b8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276bc:	f240 1111 	movw	r1, #273	@ 0x111
200276c0:	2005      	movs	r0, #5
200276c2:	f7fc fde5 	bl	20024290 <HAL_PIN_Set>
200276c6:	2301      	movs	r3, #1
200276c8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276cc:	f44f 7189 	mov.w	r1, #274	@ 0x112
200276d0:	2009      	movs	r0, #9
200276d2:	f7fc fddd 	bl	20024290 <HAL_PIN_Set>
200276d6:	2301      	movs	r3, #1
200276d8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276dc:	f240 1113 	movw	r1, #275	@ 0x113
200276e0:	200a      	movs	r0, #10
200276e2:	f7fc fdd5 	bl	20024290 <HAL_PIN_Set>
200276e6:	2301      	movs	r3, #1
200276e8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276ec:	f44f 718a 	mov.w	r1, #276	@ 0x114
200276f0:	200b      	movs	r0, #11
200276f2:	f7fc fdcd 	bl	20024290 <HAL_PIN_Set>
200276f6:	2301      	movs	r3, #1
200276f8:	f44f 7280 	mov.w	r2, #256	@ 0x100
200276fc:	f240 1115 	movw	r1, #277	@ 0x115
20027700:	200c      	movs	r0, #12
20027702:	f7fc fdc5 	bl	20024290 <HAL_PIN_Set>
20027706:	2301      	movs	r3, #1
20027708:	2200      	movs	r2, #0
2002770a:	f44f 7184 	mov.w	r1, #264	@ 0x108
2002770e:	2006      	movs	r0, #6
20027710:	f7fc fdbe 	bl	20024290 <HAL_PIN_Set>
20027714:	2301      	movs	r3, #1
20027716:	2200      	movs	r2, #0
20027718:	f44f 7183 	mov.w	r1, #262	@ 0x106
2002771c:	2008      	movs	r0, #8
2002771e:	f7fc fdb7 	bl	20024290 <HAL_PIN_Set>
20027722:	2301      	movs	r3, #1
20027724:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027728:	f240 110b 	movw	r1, #267	@ 0x10b
2002772c:	e78d      	b.n	2002764a <bsp_psram1_pinmux_init+0xda>
2002772e:	2c03      	cmp	r4, #3
20027730:	d154      	bne.n	200277dc <bsp_psram1_pinmux_init+0x26c>
20027732:	2301      	movs	r3, #1
20027734:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027738:	f44f 7187 	mov.w	r1, #270	@ 0x10e
2002773c:	2002      	movs	r0, #2
2002773e:	f7fc fda7 	bl	20024290 <HAL_PIN_Set>
20027742:	2301      	movs	r3, #1
20027744:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027748:	f240 110f 	movw	r1, #271	@ 0x10f
2002774c:	4620      	mov	r0, r4
2002774e:	f7fc fd9f 	bl	20024290 <HAL_PIN_Set>
20027752:	2301      	movs	r3, #1
20027754:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027758:	f44f 7188 	mov.w	r1, #272	@ 0x110
2002775c:	2004      	movs	r0, #4
2002775e:	f7fc fd97 	bl	20024290 <HAL_PIN_Set>
20027762:	2301      	movs	r3, #1
20027764:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027768:	f240 1111 	movw	r1, #273	@ 0x111
2002776c:	2005      	movs	r0, #5
2002776e:	f7fc fd8f 	bl	20024290 <HAL_PIN_Set>
20027772:	2301      	movs	r3, #1
20027774:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027778:	f44f 7189 	mov.w	r1, #274	@ 0x112
2002777c:	2006      	movs	r0, #6
2002777e:	f7fc fd87 	bl	20024290 <HAL_PIN_Set>
20027782:	2301      	movs	r3, #1
20027784:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027788:	f240 1113 	movw	r1, #275	@ 0x113
2002778c:	2007      	movs	r0, #7
2002778e:	f7fc fd7f 	bl	20024290 <HAL_PIN_Set>
20027792:	2301      	movs	r3, #1
20027794:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027798:	f44f 718a 	mov.w	r1, #276	@ 0x114
2002779c:	2008      	movs	r0, #8
2002779e:	f7fc fd77 	bl	20024290 <HAL_PIN_Set>
200277a2:	2301      	movs	r3, #1
200277a4:	f44f 7280 	mov.w	r2, #256	@ 0x100
200277a8:	f240 1115 	movw	r1, #277	@ 0x115
200277ac:	2009      	movs	r0, #9
200277ae:	f7fc fd6f 	bl	20024290 <HAL_PIN_Set>
200277b2:	2301      	movs	r3, #1
200277b4:	2200      	movs	r2, #0
200277b6:	f44f 7184 	mov.w	r1, #264	@ 0x108
200277ba:	200d      	movs	r0, #13
200277bc:	f7fc fd68 	bl	20024290 <HAL_PIN_Set>
200277c0:	2301      	movs	r3, #1
200277c2:	2200      	movs	r2, #0
200277c4:	f44f 7183 	mov.w	r1, #262	@ 0x106
200277c8:	200c      	movs	r0, #12
200277ca:	f7fc fd61 	bl	20024290 <HAL_PIN_Set>
200277ce:	2301      	movs	r3, #1
200277d0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200277d4:	f240 110b 	movw	r1, #267	@ 0x10b
200277d8:	200a      	movs	r0, #10
200277da:	e737      	b.n	2002764c <bsp_psram1_pinmux_init+0xdc>
200277dc:	f04f 35ff 	mov.w	r5, #4294967295
200277e0:	e737      	b.n	20027652 <bsp_psram1_pinmux_init+0xe2>
200277e2:	bf00      	nop
200277e4:	2004c990 	.word	0x2004c990
200277e8:	20027c1c 	.word	0x20027c1c

Disassembly of section .l1_ret_text_bsp_psram2_pinmux_init:

200277ec <bsp_psram2_pinmux_init>:
200277ec:	b538      	push	{r3, r4, r5, lr}
200277ee:	4c9c      	ldr	r4, [pc, #624]	@ (20027a60 <bsp_psram2_pinmux_init+0x274>)
200277f0:	78a3      	ldrb	r3, [r4, #2]
200277f2:	2b00      	cmp	r3, #0
200277f4:	d07b      	beq.n	200278ee <bsp_psram2_pinmux_init+0x102>
200277f6:	78e3      	ldrb	r3, [r4, #3]
200277f8:	4a9a      	ldr	r2, [pc, #616]	@ (20027a64 <bsp_psram2_pinmux_init+0x278>)
200277fa:	5cd4      	ldrb	r4, [r2, r3]
200277fc:	0924      	lsrs	r4, r4, #4
200277fe:	2c01      	cmp	r4, #1
20027800:	d17d      	bne.n	200278fe <bsp_psram2_pinmux_init+0x112>
20027802:	4623      	mov	r3, r4
20027804:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027808:	f44f 718f 	mov.w	r1, #286	@ 0x11e
2002780c:	200f      	movs	r0, #15
2002780e:	f7fc fd3f 	bl	20024290 <HAL_PIN_Set>
20027812:	4623      	mov	r3, r4
20027814:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027818:	f240 111f 	movw	r1, #287	@ 0x11f
2002781c:	2010      	movs	r0, #16
2002781e:	f7fc fd37 	bl	20024290 <HAL_PIN_Set>
20027822:	4623      	mov	r3, r4
20027824:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027828:	f44f 7190 	mov.w	r1, #288	@ 0x120
2002782c:	2011      	movs	r0, #17
2002782e:	f7fc fd2f 	bl	20024290 <HAL_PIN_Set>
20027832:	4623      	mov	r3, r4
20027834:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027838:	f240 1121 	movw	r1, #289	@ 0x121
2002783c:	2012      	movs	r0, #18
2002783e:	f7fc fd27 	bl	20024290 <HAL_PIN_Set>
20027842:	4623      	mov	r3, r4
20027844:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027848:	f44f 7191 	mov.w	r1, #290	@ 0x122
2002784c:	2016      	movs	r0, #22
2002784e:	f7fc fd1f 	bl	20024290 <HAL_PIN_Set>
20027852:	4623      	mov	r3, r4
20027854:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027858:	f240 1123 	movw	r1, #291	@ 0x123
2002785c:	2017      	movs	r0, #23
2002785e:	f7fc fd17 	bl	20024290 <HAL_PIN_Set>
20027862:	4623      	mov	r3, r4
20027864:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027868:	f44f 7192 	mov.w	r1, #292	@ 0x124
2002786c:	2018      	movs	r0, #24
2002786e:	f7fc fd0f 	bl	20024290 <HAL_PIN_Set>
20027872:	4623      	mov	r3, r4
20027874:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027878:	f240 1125 	movw	r1, #293	@ 0x125
2002787c:	2019      	movs	r0, #25
2002787e:	f7fc fd07 	bl	20024290 <HAL_PIN_Set>
20027882:	4623      	mov	r3, r4
20027884:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027888:	f240 1119 	movw	r1, #281	@ 0x119
2002788c:	200e      	movs	r0, #14
2002788e:	f7fc fcff 	bl	20024290 <HAL_PIN_Set>
20027892:	4623      	mov	r3, r4
20027894:	2200      	movs	r2, #0
20027896:	f44f 718c 	mov.w	r1, #280	@ 0x118
2002789a:	2013      	movs	r0, #19
2002789c:	f7fc fcf8 	bl	20024290 <HAL_PIN_Set>
200278a0:	4623      	mov	r3, r4
200278a2:	2200      	movs	r2, #0
200278a4:	f240 1117 	movw	r1, #279	@ 0x117
200278a8:	2014      	movs	r0, #20
200278aa:	f7fc fcf1 	bl	20024290 <HAL_PIN_Set>
200278ae:	4623      	mov	r3, r4
200278b0:	2200      	movs	r2, #0
200278b2:	f44f 718b 	mov.w	r1, #278	@ 0x116
200278b6:	2015      	movs	r0, #21
200278b8:	f7fc fcea 	bl	20024290 <HAL_PIN_Set>
200278bc:	4623      	mov	r3, r4
200278be:	f44f 7280 	mov.w	r2, #256	@ 0x100
200278c2:	f44f 718d 	mov.w	r1, #282	@ 0x11a
200278c6:	201a      	movs	r0, #26
200278c8:	f7fc fce2 	bl	20024290 <HAL_PIN_Set>
200278cc:	2500      	movs	r5, #0
200278ce:	240e      	movs	r4, #14
200278d0:	2201      	movs	r2, #1
200278d2:	4620      	mov	r0, r4
200278d4:	4611      	mov	r1, r2
200278d6:	f7fc fd0b 	bl	200242f0 <HAL_PIN_Set_DS0>
200278da:	4620      	mov	r0, r4
200278dc:	2200      	movs	r2, #0
200278de:	2101      	movs	r1, #1
200278e0:	3401      	adds	r4, #1
200278e2:	f7fc fd1b 	bl	2002431c <HAL_PIN_Set_DS1>
200278e6:	2c1b      	cmp	r4, #27
200278e8:	d1f2      	bne.n	200278d0 <bsp_psram2_pinmux_init+0xe4>
200278ea:	4628      	mov	r0, r5
200278ec:	bd38      	pop	{r3, r4, r5, pc}
200278ee:	f7ff fdfb 	bl	200274e8 <bsp_psram_init_info>
200278f2:	2800      	cmp	r0, #0
200278f4:	f43f af7f 	beq.w	200277f6 <bsp_psram2_pinmux_init+0xa>
200278f8:	f06f 0501 	mvn.w	r5, #1
200278fc:	e7f5      	b.n	200278ea <bsp_psram2_pinmux_init+0xfe>
200278fe:	2c02      	cmp	r4, #2
20027900:	d153      	bne.n	200279aa <bsp_psram2_pinmux_init+0x1be>
20027902:	2301      	movs	r3, #1
20027904:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027908:	f44f 718f 	mov.w	r1, #286	@ 0x11e
2002790c:	200f      	movs	r0, #15
2002790e:	f7fc fcbf 	bl	20024290 <HAL_PIN_Set>
20027912:	2301      	movs	r3, #1
20027914:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027918:	f240 111f 	movw	r1, #287	@ 0x11f
2002791c:	2010      	movs	r0, #16
2002791e:	f7fc fcb7 	bl	20024290 <HAL_PIN_Set>
20027922:	2301      	movs	r3, #1
20027924:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027928:	f44f 7190 	mov.w	r1, #288	@ 0x120
2002792c:	2011      	movs	r0, #17
2002792e:	f7fc fcaf 	bl	20024290 <HAL_PIN_Set>
20027932:	2301      	movs	r3, #1
20027934:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027938:	f240 1121 	movw	r1, #289	@ 0x121
2002793c:	2012      	movs	r0, #18
2002793e:	f7fc fca7 	bl	20024290 <HAL_PIN_Set>
20027942:	2301      	movs	r3, #1
20027944:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027948:	f44f 7191 	mov.w	r1, #290	@ 0x122
2002794c:	2016      	movs	r0, #22
2002794e:	f7fc fc9f 	bl	20024290 <HAL_PIN_Set>
20027952:	2301      	movs	r3, #1
20027954:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027958:	f240 1123 	movw	r1, #291	@ 0x123
2002795c:	2017      	movs	r0, #23
2002795e:	f7fc fc97 	bl	20024290 <HAL_PIN_Set>
20027962:	2301      	movs	r3, #1
20027964:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027968:	f44f 7192 	mov.w	r1, #292	@ 0x124
2002796c:	2018      	movs	r0, #24
2002796e:	f7fc fc8f 	bl	20024290 <HAL_PIN_Set>
20027972:	2301      	movs	r3, #1
20027974:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027978:	f240 1125 	movw	r1, #293	@ 0x125
2002797c:	2019      	movs	r0, #25
2002797e:	f7fc fc87 	bl	20024290 <HAL_PIN_Set>
20027982:	2301      	movs	r3, #1
20027984:	2200      	movs	r2, #0
20027986:	f44f 718c 	mov.w	r1, #280	@ 0x118
2002798a:	2013      	movs	r0, #19
2002798c:	f7fc fc80 	bl	20024290 <HAL_PIN_Set>
20027990:	2301      	movs	r3, #1
20027992:	2200      	movs	r2, #0
20027994:	f44f 718b 	mov.w	r1, #278	@ 0x116
20027998:	2015      	movs	r0, #21
2002799a:	f7fc fc79 	bl	20024290 <HAL_PIN_Set>
2002799e:	2301      	movs	r3, #1
200279a0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279a4:	f240 111b 	movw	r1, #283	@ 0x11b
200279a8:	e78d      	b.n	200278c6 <bsp_psram2_pinmux_init+0xda>
200279aa:	2c03      	cmp	r4, #3
200279ac:	d154      	bne.n	20027a58 <bsp_psram2_pinmux_init+0x26c>
200279ae:	2301      	movs	r3, #1
200279b0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279b4:	f44f 718f 	mov.w	r1, #286	@ 0x11e
200279b8:	200f      	movs	r0, #15
200279ba:	f7fc fc69 	bl	20024290 <HAL_PIN_Set>
200279be:	2301      	movs	r3, #1
200279c0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279c4:	f240 111f 	movw	r1, #287	@ 0x11f
200279c8:	2010      	movs	r0, #16
200279ca:	f7fc fc61 	bl	20024290 <HAL_PIN_Set>
200279ce:	2301      	movs	r3, #1
200279d0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279d4:	f44f 7190 	mov.w	r1, #288	@ 0x120
200279d8:	2011      	movs	r0, #17
200279da:	f7fc fc59 	bl	20024290 <HAL_PIN_Set>
200279de:	2301      	movs	r3, #1
200279e0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279e4:	f240 1121 	movw	r1, #289	@ 0x121
200279e8:	2012      	movs	r0, #18
200279ea:	f7fc fc51 	bl	20024290 <HAL_PIN_Set>
200279ee:	2301      	movs	r3, #1
200279f0:	f44f 7280 	mov.w	r2, #256	@ 0x100
200279f4:	f44f 7191 	mov.w	r1, #290	@ 0x122
200279f8:	2014      	movs	r0, #20
200279fa:	f7fc fc49 	bl	20024290 <HAL_PIN_Set>
200279fe:	2301      	movs	r3, #1
20027a00:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027a04:	f240 1123 	movw	r1, #291	@ 0x123
20027a08:	2015      	movs	r0, #21
20027a0a:	f7fc fc41 	bl	20024290 <HAL_PIN_Set>
20027a0e:	2301      	movs	r3, #1
20027a10:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027a14:	f44f 7192 	mov.w	r1, #292	@ 0x124
20027a18:	2016      	movs	r0, #22
20027a1a:	f7fc fc39 	bl	20024290 <HAL_PIN_Set>
20027a1e:	2301      	movs	r3, #1
20027a20:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027a24:	f240 1125 	movw	r1, #293	@ 0x125
20027a28:	2017      	movs	r0, #23
20027a2a:	f7fc fc31 	bl	20024290 <HAL_PIN_Set>
20027a2e:	2301      	movs	r3, #1
20027a30:	2200      	movs	r2, #0
20027a32:	f44f 718c 	mov.w	r1, #280	@ 0x118
20027a36:	201a      	movs	r0, #26
20027a38:	f7fc fc2a 	bl	20024290 <HAL_PIN_Set>
20027a3c:	2301      	movs	r3, #1
20027a3e:	2200      	movs	r2, #0
20027a40:	f44f 718b 	mov.w	r1, #278	@ 0x116
20027a44:	2019      	movs	r0, #25
20027a46:	f7fc fc23 	bl	20024290 <HAL_PIN_Set>
20027a4a:	2301      	movs	r3, #1
20027a4c:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027a50:	f240 111b 	movw	r1, #283	@ 0x11b
20027a54:	2018      	movs	r0, #24
20027a56:	e737      	b.n	200278c8 <bsp_psram2_pinmux_init+0xdc>
20027a58:	f04f 35ff 	mov.w	r5, #4294967295
20027a5c:	e737      	b.n	200278ce <bsp_psram2_pinmux_init+0xe2>
20027a5e:	bf00      	nop
20027a60:	2004c990 	.word	0x2004c990
20027a64:	20027c18 	.word	0x20027c18

Disassembly of section .l1_ret_text_HAL_EFUSE_Extract:

20027a68 <HAL_EFUSE_Extract>:
20027a68:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20027a6c:	2800      	cmp	r0, #0
20027a6e:	d041      	beq.n	20027af4 <HAL_EFUSE_Extract+0x8c>
20027a70:	2a00      	cmp	r2, #0
20027a72:	d03f      	beq.n	20027af4 <HAL_EFUSE_Extract+0x8c>
20027a74:	18cc      	adds	r4, r1, r3
20027a76:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20027a7a:	dc3b      	bgt.n	20027af4 <HAL_EFUSE_Extract+0x8c>
20027a7c:	2400      	movs	r4, #0
20027a7e:	46a4      	mov	ip, r4
20027a80:	094e      	lsrs	r6, r1, #5
20027a82:	1ddd      	adds	r5, r3, #7
20027a84:	f850 7026 	ldr.w	r7, [r0, r6, lsl #2]
20027a88:	f001 011f 	and.w	r1, r1, #31
20027a8c:	f3c5 05cf 	ubfx	r5, r5, #3, #16
20027a90:	42a5      	cmp	r5, r4
20027a92:	d807      	bhi.n	20027aa4 <HAL_EFUSE_Extract+0x3c>
20027a94:	2400      	movs	r4, #0
20027a96:	46a6      	mov	lr, r4
20027a98:	46a4      	mov	ip, r4
20027a9a:	459c      	cmp	ip, r3
20027a9c:	d106      	bne.n	20027aac <HAL_EFUSE_Extract+0x44>
20027a9e:	4618      	mov	r0, r3
20027aa0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027aa4:	f802 c004 	strb.w	ip, [r2, r4]
20027aa8:	3401      	adds	r4, #1
20027aaa:	e7f1      	b.n	20027a90 <HAL_EFUSE_Extract+0x28>
20027aac:	fa27 f501 	lsr.w	r5, r7, r1
20027ab0:	3101      	adds	r1, #1
20027ab2:	f812 800e 	ldrb.w	r8, [r2, lr]
20027ab6:	b289      	uxth	r1, r1
20027ab8:	f005 0501 	and.w	r5, r5, #1
20027abc:	2920      	cmp	r1, #32
20027abe:	fa05 f504 	lsl.w	r5, r5, r4
20027ac2:	bf08      	it	eq
20027ac4:	3601      	addeq	r6, #1
20027ac6:	ea45 0508 	orr.w	r5, r5, r8
20027aca:	f104 0401 	add.w	r4, r4, #1
20027ace:	b2a4      	uxth	r4, r4
20027ad0:	f802 500e 	strb.w	r5, [r2, lr]
20027ad4:	bf02      	ittt	eq
20027ad6:	b2b6      	uxtheq	r6, r6
20027ad8:	2100      	moveq	r1, #0
20027ada:	f850 7026 	ldreq.w	r7, [r0, r6, lsl #2]
20027ade:	2c08      	cmp	r4, #8
20027ae0:	bf04      	itt	eq
20027ae2:	f10e 0401 	addeq.w	r4, lr, #1
20027ae6:	fa1f fe84 	uxtheq.w	lr, r4
20027aea:	f10c 0c01 	add.w	ip, ip, #1
20027aee:	bf08      	it	eq
20027af0:	2400      	moveq	r4, #0
20027af2:	e7d2      	b.n	20027a9a <HAL_EFUSE_Extract+0x32>
20027af4:	2300      	movs	r3, #0
20027af6:	e7d2      	b.n	20027a9e <HAL_EFUSE_Extract+0x36>

Disassembly of section .l1_ret_text_HAL_EFUSE_Read2:

20027af8 <HAL_EFUSE_Read2>:
20027af8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20027afc:	fa52 f380 	uxtab	r3, r2, r0
20027b00:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20027b04:	4605      	mov	r5, r0
20027b06:	4688      	mov	r8, r1
20027b08:	4617      	mov	r7, r2
20027b0a:	fa5f f980 	uxtb.w	r9, r0
20027b0e:	dc1e      	bgt.n	20027b4e <HAL_EFUSE_Read2+0x56>
20027b10:	f5b0 7f40 	cmp.w	r0, #768	@ 0x300
20027b14:	d21b      	bcs.n	20027b4e <HAL_EFUSE_Read2+0x56>
20027b16:	2003      	movs	r0, #3
20027b18:	f7f9 fe52 	bl	200217c0 <pmu_ldo_inc>
20027b1c:	4c15      	ldr	r4, [pc, #84]	@ (20027b74 <HAL_EFUSE_Read2+0x7c>)
20027b1e:	0a2d      	lsrs	r5, r5, #8
20027b20:	00ab      	lsls	r3, r5, #2
20027b22:	6023      	str	r3, [r4, #0]
20027b24:	6823      	ldr	r3, [r4, #0]
20027b26:	4606      	mov	r6, r0
20027b28:	f043 0301 	orr.w	r3, r3, #1
20027b2c:	6023      	str	r3, [r4, #0]
20027b2e:	2300      	movs	r3, #0
20027b30:	4911      	ldr	r1, [pc, #68]	@ (20027b78 <HAL_EFUSE_Read2+0x80>)
20027b32:	68a2      	ldr	r2, [r4, #8]
20027b34:	07d2      	lsls	r2, r2, #31
20027b36:	d401      	bmi.n	20027b3c <HAL_EFUSE_Read2+0x44>
20027b38:	428b      	cmp	r3, r1
20027b3a:	d10c      	bne.n	20027b56 <HAL_EFUSE_Read2+0x5e>
20027b3c:	68a2      	ldr	r2, [r4, #8]
20027b3e:	428b      	cmp	r3, r1
20027b40:	f042 0201 	orr.w	r2, r2, #1
20027b44:	60a2      	str	r2, [r4, #8]
20027b46:	d108      	bne.n	20027b5a <HAL_EFUSE_Read2+0x62>
20027b48:	4630      	mov	r0, r6
20027b4a:	f7f9 fe3b 	bl	200217c4 <pmu_ldo_recover>
20027b4e:	2400      	movs	r4, #0
20027b50:	4620      	mov	r0, r4
20027b52:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20027b56:	3301      	adds	r3, #1
20027b58:	e7eb      	b.n	20027b32 <HAL_EFUSE_Read2+0x3a>
20027b5a:	4808      	ldr	r0, [pc, #32]	@ (20027b7c <HAL_EFUSE_Read2+0x84>)
20027b5c:	463b      	mov	r3, r7
20027b5e:	4642      	mov	r2, r8
20027b60:	4649      	mov	r1, r9
20027b62:	eb00 1045 	add.w	r0, r0, r5, lsl #5
20027b66:	f7ff ff7f 	bl	20027a68 <HAL_EFUSE_Extract>
20027b6a:	4604      	mov	r4, r0
20027b6c:	4630      	mov	r0, r6
20027b6e:	f7f9 fe29 	bl	200217c4 <pmu_ldo_recover>
20027b72:	e7ed      	b.n	20027b50 <HAL_EFUSE_Read2+0x58>
20027b74:	5000c000 	.word	0x5000c000
20027b78:	00bb8000 	.word	0x00bb8000
20027b7c:	5000c030 	.word	0x5000c030

Disassembly of section .l1_ret_text_HAL_Set_backup:

20027b80 <HAL_Set_backup>:
20027b80:	4b01      	ldr	r3, [pc, #4]	@ (20027b88 <HAL_Set_backup+0x8>)
20027b82:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
20027b86:	4770      	bx	lr
20027b88:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

20027b8c <HAL_Get_backup>:
20027b8c:	4b01      	ldr	r3, [pc, #4]	@ (20027b94 <HAL_Get_backup+0x8>)
20027b8e:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
20027b92:	4770      	bx	lr
20027b94:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

20027b98 <HAL_PMU_GetHpsysVoutRef>:
20027b98:	4b04      	ldr	r3, [pc, #16]	@ (20027bac <HAL_PMU_GetHpsysVoutRef+0x14>)
20027b9a:	781a      	ldrb	r2, [r3, #0]
20027b9c:	b122      	cbz	r2, 20027ba8 <HAL_PMU_GetHpsysVoutRef+0x10>
20027b9e:	b118      	cbz	r0, 20027ba8 <HAL_PMU_GetHpsysVoutRef+0x10>
20027ba0:	78db      	ldrb	r3, [r3, #3]
20027ba2:	7003      	strb	r3, [r0, #0]
20027ba4:	2000      	movs	r0, #0
20027ba6:	4770      	bx	lr
20027ba8:	2001      	movs	r0, #1
20027baa:	4770      	bx	lr
20027bac:	2004ca9c 	.word	0x2004ca9c

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

20027bb0 <HAL_PMU_GetHpsysVoutRef2>:
20027bb0:	4b04      	ldr	r3, [pc, #16]	@ (20027bc4 <HAL_PMU_GetHpsysVoutRef2+0x14>)
20027bb2:	781a      	ldrb	r2, [r3, #0]
20027bb4:	b122      	cbz	r2, 20027bc0 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027bb6:	b118      	cbz	r0, 20027bc0 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027bb8:	7b5b      	ldrb	r3, [r3, #13]
20027bba:	7003      	strb	r3, [r0, #0]
20027bbc:	2000      	movs	r0, #0
20027bbe:	4770      	bx	lr
20027bc0:	2001      	movs	r0, #1
20027bc2:	4770      	bx	lr
20027bc4:	2004ca9c 	.word	0x2004ca9c

Disassembly of section .l1_ret_text_HAL_PMU_ConfigPeriLdo:

20027bc8 <HAL_PMU_ConfigPeriLdo>:
20027bc8:	2810      	cmp	r0, #16
20027bca:	b510      	push	{r4, lr}
20027bcc:	d81e      	bhi.n	20027c0c <HAL_PMU_ConfigPeriLdo+0x44>
20027bce:	4b10      	ldr	r3, [pc, #64]	@ (20027c10 <HAL_PMU_ConfigPeriLdo+0x48>)
20027bd0:	40c3      	lsrs	r3, r0
20027bd2:	07db      	lsls	r3, r3, #31
20027bd4:	d51a      	bpl.n	20027c0c <HAL_PMU_ConfigPeriLdo+0x44>
20027bd6:	2900      	cmp	r1, #0
20027bd8:	bf0c      	ite	eq
20027bda:	2104      	moveq	r1, #4
20027bdc:	2101      	movne	r1, #1
20027bde:	4081      	lsls	r1, r0
20027be0:	b158      	cbz	r0, 20027bfa <HAL_PMU_ConfigPeriLdo+0x32>
20027be2:	2305      	movs	r3, #5
20027be4:	fa03 f000 	lsl.w	r0, r3, r0
20027be8:	4c0a      	ldr	r4, [pc, #40]	@ (20027c14 <HAL_PMU_ConfigPeriLdo+0x4c>)
20027bea:	6e23      	ldr	r3, [r4, #96]	@ 0x60
20027bec:	ea23 0300 	bic.w	r3, r3, r0
20027bf0:	430b      	orrs	r3, r1
20027bf2:	6623      	str	r3, [r4, #96]	@ 0x60
20027bf4:	b92a      	cbnz	r2, 20027c02 <HAL_PMU_ConfigPeriLdo+0x3a>
20027bf6:	2000      	movs	r0, #0
20027bf8:	bd10      	pop	{r4, pc}
20027bfa:	207d      	movs	r0, #125	@ 0x7d
20027bfc:	f041 0170 	orr.w	r1, r1, #112	@ 0x70
20027c00:	e7f2      	b.n	20027be8 <HAL_PMU_ConfigPeriLdo+0x20>
20027c02:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
20027c06:	f7f9 fed4 	bl	200219b2 <HAL_Delay_us>
20027c0a:	e7f4      	b.n	20027bf6 <HAL_PMU_ConfigPeriLdo+0x2e>
20027c0c:	2001      	movs	r0, #1
20027c0e:	e7f3      	b.n	20027bf8 <HAL_PMU_ConfigPeriLdo+0x30>
20027c10:	00010101 	.word	0x00010101
20027c14:	500ca000 	.word	0x500ca000
