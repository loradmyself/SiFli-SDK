
build_spi-hdk_lb57bun3n6_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020204 <deregister_tm_clones>:
20020204:	4803      	ldr	r0, [pc, #12]	@ (20020214 <deregister_tm_clones+0x10>)
20020206:	4b04      	ldr	r3, [pc, #16]	@ (20020218 <deregister_tm_clones+0x14>)
20020208:	4283      	cmp	r3, r0
2002020a:	d002      	beq.n	20020212 <deregister_tm_clones+0xe>
2002020c:	4b03      	ldr	r3, [pc, #12]	@ (2002021c <deregister_tm_clones+0x18>)
2002020e:	b103      	cbz	r3, 20020212 <deregister_tm_clones+0xe>
20020210:	4718      	bx	r3
20020212:	4770      	bx	lr
20020214:	20044a08 	.word	0x20044a08
20020218:	20044a08 	.word	0x20044a08
2002021c:	00000000 	.word	0x00000000

20020220 <register_tm_clones>:
20020220:	4b06      	ldr	r3, [pc, #24]	@ (2002023c <register_tm_clones+0x1c>)
20020222:	4907      	ldr	r1, [pc, #28]	@ (20020240 <register_tm_clones+0x20>)
20020224:	1ac9      	subs	r1, r1, r3
20020226:	1089      	asrs	r1, r1, #2
20020228:	bf48      	it	mi
2002022a:	3101      	addmi	r1, #1
2002022c:	1049      	asrs	r1, r1, #1
2002022e:	d003      	beq.n	20020238 <register_tm_clones+0x18>
20020230:	4b04      	ldr	r3, [pc, #16]	@ (20020244 <register_tm_clones+0x24>)
20020232:	b10b      	cbz	r3, 20020238 <register_tm_clones+0x18>
20020234:	4801      	ldr	r0, [pc, #4]	@ (2002023c <register_tm_clones+0x1c>)
20020236:	4718      	bx	r3
20020238:	4770      	bx	lr
2002023a:	bf00      	nop
2002023c:	20044a08 	.word	0x20044a08
20020240:	20044a08 	.word	0x20044a08
20020244:	00000000 	.word	0x00000000

20020248 <__do_global_dtors_aux>:
20020248:	b510      	push	{r4, lr}
2002024a:	4c06      	ldr	r4, [pc, #24]	@ (20020264 <__do_global_dtors_aux+0x1c>)
2002024c:	7823      	ldrb	r3, [r4, #0]
2002024e:	b943      	cbnz	r3, 20020262 <__do_global_dtors_aux+0x1a>
20020250:	f7ff ffd8 	bl	20020204 <deregister_tm_clones>
20020254:	4b04      	ldr	r3, [pc, #16]	@ (20020268 <__do_global_dtors_aux+0x20>)
20020256:	b113      	cbz	r3, 2002025e <__do_global_dtors_aux+0x16>
20020258:	4804      	ldr	r0, [pc, #16]	@ (2002026c <__do_global_dtors_aux+0x24>)
2002025a:	f3af 8000 	nop.w
2002025e:	2301      	movs	r3, #1
20020260:	7023      	strb	r3, [r4, #0]
20020262:	bd10      	pop	{r4, pc}
20020264:	20044a08 	.word	0x20044a08
20020268:	00000000 	.word	0x00000000
2002026c:	2002687c 	.word	0x2002687c

20020270 <frame_dummy>:
20020270:	b508      	push	{r3, lr}
20020272:	4b05      	ldr	r3, [pc, #20]	@ (20020288 <frame_dummy+0x18>)
20020274:	b11b      	cbz	r3, 2002027e <frame_dummy+0xe>
20020276:	4905      	ldr	r1, [pc, #20]	@ (2002028c <frame_dummy+0x1c>)
20020278:	4805      	ldr	r0, [pc, #20]	@ (20020290 <frame_dummy+0x20>)
2002027a:	f3af 8000 	nop.w
2002027e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020282:	f7ff bfcd 	b.w	20020220 <register_tm_clones>
20020286:	bf00      	nop
20020288:	00000000 	.word	0x00000000
2002028c:	20044a0c 	.word	0x20044a0c
20020290:	2002687c 	.word	0x2002687c

20020294 <boot_uart_tx>:
20020294:	2300      	movs	r3, #0
20020296:	b510      	push	{r4, lr}
20020298:	4293      	cmp	r3, r2
2002029a:	db00      	blt.n	2002029e <boot_uart_tx+0xa>
2002029c:	bd10      	pop	{r4, pc}
2002029e:	69c4      	ldr	r4, [r0, #28]
200202a0:	0624      	lsls	r4, r4, #24
200202a2:	d5fc      	bpl.n	2002029e <boot_uart_tx+0xa>
200202a4:	5ccc      	ldrb	r4, [r1, r3]
200202a6:	3301      	adds	r3, #1
200202a8:	6284      	str	r4, [r0, #40]	@ 0x28
200202aa:	e7f5      	b.n	20020298 <boot_uart_tx+0x4>

200202ac <mpu_config>:
200202ac:	4770      	bx	lr

200202ae <cache_enable>:
200202ae:	4770      	bx	lr

200202b0 <board_pinmux_mpi1_type1>:
200202b0:	b510      	push	{r4, lr}
200202b2:	2100      	movs	r1, #0
200202b4:	f640 3004 	movw	r0, #2820	@ 0xb04
200202b8:	f003 fafe 	bl	200238b8 <HAL_PIN_Set2>
200202bc:	2100      	movs	r1, #0
200202be:	f44f 7082 	mov.w	r0, #260	@ 0x104
200202c2:	f003 faf9 	bl	200238b8 <HAL_PIN_Set2>
200202c6:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202ca:	f640 5004 	movw	r0, #3332	@ 0xd04
200202ce:	f003 faf3 	bl	200238b8 <HAL_PIN_Set2>
200202d2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202d6:	f44f 7041 	mov.w	r0, #772	@ 0x304
200202da:	f003 faed 	bl	200238b8 <HAL_PIN_Set2>
200202de:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202e2:	f240 5004 	movw	r0, #1284	@ 0x504
200202e6:	f003 fae7 	bl	200238b8 <HAL_PIN_Set2>
200202ea:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202ee:	f640 4004 	movw	r0, #3076	@ 0xc04
200202f2:	f003 fae1 	bl	200238b8 <HAL_PIN_Set2>
200202f6:	2400      	movs	r4, #0
200202f8:	2201      	movs	r2, #1
200202fa:	3401      	adds	r4, #1
200202fc:	4611      	mov	r1, r2
200202fe:	4620      	mov	r0, r4
20020300:	f003 faf4 	bl	200238ec <HAL_PIN_Set_DS0>
20020304:	2200      	movs	r2, #0
20020306:	2101      	movs	r1, #1
20020308:	4620      	mov	r0, r4
2002030a:	f003 fb05 	bl	20023918 <HAL_PIN_Set_DS1>
2002030e:	2c0d      	cmp	r4, #13
20020310:	d1f2      	bne.n	200202f8 <board_pinmux_mpi1_type1+0x48>
20020312:	bd10      	pop	{r4, pc}

20020314 <board_pinmux_mpi1_type2>:
20020314:	b510      	push	{r4, lr}
20020316:	2100      	movs	r1, #0
20020318:	f640 3004 	movw	r0, #2820	@ 0xb04
2002031c:	f003 facc 	bl	200238b8 <HAL_PIN_Set2>
20020320:	2100      	movs	r1, #0
20020322:	f240 4004 	movw	r0, #1028	@ 0x404
20020326:	f003 fac7 	bl	200238b8 <HAL_PIN_Set2>
2002032a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002032e:	f640 5004 	movw	r0, #3332	@ 0xd04
20020332:	f003 fac1 	bl	200238b8 <HAL_PIN_Set2>
20020336:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002033a:	f44f 7041 	mov.w	r0, #772	@ 0x304
2002033e:	f003 fabb 	bl	200238b8 <HAL_PIN_Set2>
20020342:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020346:	f44f 7001 	mov.w	r0, #516	@ 0x204
2002034a:	f003 fab5 	bl	200238b8 <HAL_PIN_Set2>
2002034e:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020352:	f640 2004 	movw	r0, #2564	@ 0xa04
20020356:	f003 faaf 	bl	200238b8 <HAL_PIN_Set2>
2002035a:	2400      	movs	r4, #0
2002035c:	2201      	movs	r2, #1
2002035e:	3401      	adds	r4, #1
20020360:	4611      	mov	r1, r2
20020362:	4620      	mov	r0, r4
20020364:	f003 fac2 	bl	200238ec <HAL_PIN_Set_DS0>
20020368:	2200      	movs	r2, #0
2002036a:	2101      	movs	r1, #1
2002036c:	4620      	mov	r0, r4
2002036e:	f003 fad3 	bl	20023918 <HAL_PIN_Set_DS1>
20020372:	2c0d      	cmp	r4, #13
20020374:	d1f2      	bne.n	2002035c <board_pinmux_mpi1_type2+0x48>
20020376:	bd10      	pop	{r4, pc}

20020378 <board_pinmux_mpi2>:
20020378:	b510      	push	{r4, lr}
2002037a:	2100      	movs	r1, #0
2002037c:	f641 2004 	movw	r0, #6660	@ 0x1a04
20020380:	f003 fa9a 	bl	200238b8 <HAL_PIN_Set2>
20020384:	2100      	movs	r1, #0
20020386:	f241 4004 	movw	r0, #5124	@ 0x1404
2002038a:	f003 fa95 	bl	200238b8 <HAL_PIN_Set2>
2002038e:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020392:	f641 0004 	movw	r0, #6148	@ 0x1804
20020396:	f003 fa8f 	bl	200238b8 <HAL_PIN_Set2>
2002039a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002039e:	f241 3004 	movw	r0, #4868	@ 0x1304
200203a2:	f003 fa89 	bl	200238b8 <HAL_PIN_Set2>
200203a6:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203aa:	f241 2004 	movw	r0, #4612	@ 0x1204
200203ae:	f003 fa83 	bl	200238b8 <HAL_PIN_Set2>
200203b2:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203b6:	f641 1004 	movw	r0, #6404	@ 0x1904
200203ba:	f003 fa7d 	bl	200238b8 <HAL_PIN_Set2>
200203be:	240e      	movs	r4, #14
200203c0:	2201      	movs	r2, #1
200203c2:	4620      	mov	r0, r4
200203c4:	4611      	mov	r1, r2
200203c6:	f003 fa91 	bl	200238ec <HAL_PIN_Set_DS0>
200203ca:	4620      	mov	r0, r4
200203cc:	2200      	movs	r2, #0
200203ce:	2101      	movs	r1, #1
200203d0:	3401      	adds	r4, #1
200203d2:	f003 faa1 	bl	20023918 <HAL_PIN_Set_DS1>
200203d6:	2c1b      	cmp	r4, #27
200203d8:	d1f2      	bne.n	200203c0 <board_pinmux_mpi2+0x48>
200203da:	bd10      	pop	{r4, pc}

200203dc <board_pinmux_mpi3>:
200203dc:	b510      	push	{r4, lr}
200203de:	2100      	movs	r1, #0
200203e0:	f642 3001 	movw	r0, #11009	@ 0x2b01
200203e4:	f003 fa68 	bl	200238b8 <HAL_PIN_Set2>
200203e8:	2100      	movs	r1, #0
200203ea:	f242 7001 	movw	r0, #9985	@ 0x2701
200203ee:	f003 fa63 	bl	200238b8 <HAL_PIN_Set2>
200203f2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200203f6:	f642 2001 	movw	r0, #10753	@ 0x2a01
200203fa:	f003 fa5d 	bl	200238b8 <HAL_PIN_Set2>
200203fe:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020402:	f642 0001 	movw	r0, #10241	@ 0x2801
20020406:	f003 fa57 	bl	200238b8 <HAL_PIN_Set2>
2002040a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002040e:	f642 1001 	movw	r0, #10497	@ 0x2901
20020412:	f003 fa51 	bl	200238b8 <HAL_PIN_Set2>
20020416:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002041a:	f642 4001 	movw	r0, #11265	@ 0x2c01
2002041e:	f003 fa4b 	bl	200238b8 <HAL_PIN_Set2>
20020422:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20020426:	4b13      	ldr	r3, [pc, #76]	@ (20020474 <board_pinmux_mpi3+0x98>)
20020428:	2427      	movs	r4, #39	@ 0x27
2002042a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002042e:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20020432:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020436:	f44f 4200 	mov.w	r2, #32768	@ 0x8000
2002043a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002043e:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020442:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020446:	f44f 4280 	mov.w	r2, #16384	@ 0x4000
2002044a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002044e:	f44f 3200 	mov.w	r2, #131072	@ 0x20000
20020452:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020456:	2201      	movs	r2, #1
20020458:	4620      	mov	r0, r4
2002045a:	4611      	mov	r1, r2
2002045c:	f003 fa46 	bl	200238ec <HAL_PIN_Set_DS0>
20020460:	4620      	mov	r0, r4
20020462:	2200      	movs	r2, #0
20020464:	2101      	movs	r1, #1
20020466:	3401      	adds	r4, #1
20020468:	f003 fa56 	bl	20023918 <HAL_PIN_Set_DS1>
2002046c:	2c2d      	cmp	r4, #45	@ 0x2d
2002046e:	d1f2      	bne.n	20020456 <board_pinmux_mpi3+0x7a>
20020470:	bd10      	pop	{r4, pc}
20020472:	bf00      	nop
20020474:	500ca000 	.word	0x500ca000

20020478 <board_pinmux_sd>:
20020478:	b510      	push	{r4, lr}
2002047a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002047e:	f642 2002 	movw	r0, #10754	@ 0x2a02
20020482:	f003 fa19 	bl	200238b8 <HAL_PIN_Set2>
20020486:	f44f 4300 	mov.w	r3, #32768	@ 0x8000
2002048a:	4c1c      	ldr	r4, [pc, #112]	@ (200204fc <board_pinmux_sd+0x84>)
2002048c:	2014      	movs	r0, #20
2002048e:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
20020492:	f001 fa1c 	bl	200218ce <HAL_Delay_us>
20020496:	2100      	movs	r1, #0
20020498:	f642 1002 	movw	r0, #10498	@ 0x2902
2002049c:	f003 fa0c 	bl	200238b8 <HAL_PIN_Set2>
200204a0:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204a4:	f642 3002 	movw	r0, #11010	@ 0x2b02
200204a8:	f003 fa06 	bl	200238b8 <HAL_PIN_Set2>
200204ac:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204b0:	f642 4002 	movw	r0, #11266	@ 0x2c02
200204b4:	f003 fa00 	bl	200238b8 <HAL_PIN_Set2>
200204b8:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204bc:	f242 7002 	movw	r0, #9986	@ 0x2702
200204c0:	f003 f9fa 	bl	200238b8 <HAL_PIN_Set2>
200204c4:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204c8:	f642 0002 	movw	r0, #10242	@ 0x2802
200204cc:	f003 f9f4 	bl	200238b8 <HAL_PIN_Set2>
200204d0:	f44f 4380 	mov.w	r3, #16384	@ 0x4000
200204d4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204d8:	f44f 3380 	mov.w	r3, #65536	@ 0x10000
200204dc:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e0:	f44f 3300 	mov.w	r3, #131072	@ 0x20000
200204e4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e8:	f44f 5380 	mov.w	r3, #4096	@ 0x1000
200204ec:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f0:	f44f 5300 	mov.w	r3, #8192	@ 0x2000
200204f4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f8:	bd10      	pop	{r4, pc}
200204fa:	bf00      	nop
200204fc:	500ca000 	.word	0x500ca000

20020500 <board_boot_from>:
20020500:	b508      	push	{r3, lr}
20020502:	2000      	movs	r0, #0
20020504:	f006 fa0a 	bl	2002691c <HAL_Get_backup>
20020508:	f000 000f 	and.w	r0, r0, #15
2002050c:	bd08      	pop	{r3, pc}

2002050e <board_init>:
2002050e:	f003 bd55 	b.w	20023fbc <BSP_System_Config>

20020512 <board_init_psram>:
20020512:	2002      	movs	r0, #2
20020514:	f001 b8ce 	b.w	200216b4 <BSP_SetFlash1DIV>

20020518 <erase_nor>:
20020518:	b570      	push	{r4, r5, r6, lr}
2002051a:	4b13      	ldr	r3, [pc, #76]	@ (20020568 <erase_nor+0x50>)
2002051c:	460c      	mov	r4, r1
2002051e:	681e      	ldr	r6, [r3, #0]
20020520:	6933      	ldr	r3, [r6, #16]
20020522:	4283      	cmp	r3, r0
20020524:	d901      	bls.n	2002052a <erase_nor+0x12>
20020526:	2001      	movs	r0, #1
20020528:	bd70      	pop	{r4, r5, r6, pc}
2002052a:	6972      	ldr	r2, [r6, #20]
2002052c:	441a      	add	r2, r3
2002052e:	4282      	cmp	r2, r0
20020530:	d3f9      	bcc.n	20020526 <erase_nor+0xe>
20020532:	1ac0      	subs	r0, r0, r3
20020534:	f3c0 030b 	ubfx	r3, r0, #0, #12
20020538:	b97b      	cbnz	r3, 2002055a <erase_nor+0x42>
2002053a:	f3c1 030b 	ubfx	r3, r1, #0, #12
2002053e:	b97b      	cbnz	r3, 20020560 <erase_nor+0x48>
20020540:	1845      	adds	r5, r0, r1
20020542:	1b29      	subs	r1, r5, r4
20020544:	b90c      	cbnz	r4, 2002054a <erase_nor+0x32>
20020546:	4620      	mov	r0, r4
20020548:	e7ee      	b.n	20020528 <erase_nor+0x10>
2002054a:	4630      	mov	r0, r6
2002054c:	f002 ff73 	bl	20023436 <HAL_QSPIEX_SECT_ERASE>
20020550:	2800      	cmp	r0, #0
20020552:	d1e8      	bne.n	20020526 <erase_nor+0xe>
20020554:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
20020558:	e7f3      	b.n	20020542 <erase_nor+0x2a>
2002055a:	f04f 30ff 	mov.w	r0, #4294967295
2002055e:	e7e3      	b.n	20020528 <erase_nor+0x10>
20020560:	f06f 0001 	mvn.w	r0, #1
20020564:	e7e0      	b.n	20020528 <erase_nor+0x10>
20020566:	bf00      	nop
20020568:	20046d30 	.word	0x20046d30

2002056c <write_nor>:
2002056c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020570:	4b1e      	ldr	r3, [pc, #120]	@ (200205ec <write_nor+0x80>)
20020572:	460f      	mov	r7, r1
20020574:	f8d3 8000 	ldr.w	r8, [r3]
20020578:	4616      	mov	r6, r2
2002057a:	f8d8 5010 	ldr.w	r5, [r8, #16]
2002057e:	4285      	cmp	r5, r0
20020580:	d902      	bls.n	20020588 <write_nor+0x1c>
20020582:	2000      	movs	r0, #0
20020584:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20020588:	f8d8 2014 	ldr.w	r2, [r8, #20]
2002058c:	442a      	add	r2, r5
2002058e:	4282      	cmp	r2, r0
20020590:	d3f7      	bcc.n	20020582 <write_nor+0x16>
20020592:	1b45      	subs	r5, r0, r5
20020594:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
20020598:	d012      	beq.n	200205c0 <write_nor+0x54>
2002059a:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
2002059e:	42b4      	cmp	r4, r6
200205a0:	bf28      	it	cs
200205a2:	4634      	movcs	r4, r6
200205a4:	460a      	mov	r2, r1
200205a6:	4623      	mov	r3, r4
200205a8:	4629      	mov	r1, r5
200205aa:	4640      	mov	r0, r8
200205ac:	f002 fe5e 	bl	2002326c <HAL_QSPIEX_WRITE_PAGE>
200205b0:	4284      	cmp	r4, r0
200205b2:	d1e6      	bne.n	20020582 <write_nor+0x16>
200205b4:	4425      	add	r5, r4
200205b6:	4427      	add	r7, r4
200205b8:	1b34      	subs	r4, r6, r4
200205ba:	b91c      	cbnz	r4, 200205c4 <write_nor+0x58>
200205bc:	4630      	mov	r0, r6
200205be:	e7e1      	b.n	20020584 <write_nor+0x18>
200205c0:	4634      	mov	r4, r6
200205c2:	e7fa      	b.n	200205ba <write_nor+0x4e>
200205c4:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
200205c8:	46a1      	mov	r9, r4
200205ca:	bf28      	it	cs
200205cc:	f44f 7980 	movcs.w	r9, #256	@ 0x100
200205d0:	463a      	mov	r2, r7
200205d2:	464b      	mov	r3, r9
200205d4:	4629      	mov	r1, r5
200205d6:	4640      	mov	r0, r8
200205d8:	f002 fe48 	bl	2002326c <HAL_QSPIEX_WRITE_PAGE>
200205dc:	4581      	cmp	r9, r0
200205de:	d1d0      	bne.n	20020582 <write_nor+0x16>
200205e0:	444d      	add	r5, r9
200205e2:	444f      	add	r7, r9
200205e4:	eba4 0409 	sub.w	r4, r4, r9
200205e8:	e7e7      	b.n	200205ba <write_nor+0x4e>
200205ea:	bf00      	nop
200205ec:	20046d30 	.word	0x20046d30

200205f0 <read_nor>:
200205f0:	460b      	mov	r3, r1
200205f2:	b510      	push	{r4, lr}
200205f4:	4614      	mov	r4, r2
200205f6:	4601      	mov	r1, r0
200205f8:	4618      	mov	r0, r3
200205fa:	f005 f8b8 	bl	2002576e <memcpy>
200205fe:	4620      	mov	r0, r4
20020600:	bd10      	pop	{r4, pc}
	...

20020604 <read_nand>:
20020604:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020608:	2600      	movs	r6, #0
2002060a:	460f      	mov	r7, r1
2002060c:	4615      	mov	r5, r2
2002060e:	46b0      	mov	r8, r6
20020610:	4b19      	ldr	r3, [pc, #100]	@ (20020678 <read_nand+0x74>)
20020612:	f8df a068 	ldr.w	sl, [pc, #104]	@ 2002067c <read_nand+0x78>
20020616:	681b      	ldr	r3, [r3, #0]
20020618:	f8df b064 	ldr.w	fp, [pc, #100]	@ 20020680 <read_nand+0x7c>
2002061c:	691b      	ldr	r3, [r3, #16]
2002061e:	4604      	mov	r4, r0
20020620:	4283      	cmp	r3, r0
20020622:	b085      	sub	sp, #20
20020624:	bf98      	it	ls
20020626:	1ac4      	subls	r4, r0, r3
20020628:	b91d      	cbnz	r5, 20020632 <read_nand+0x2e>
2002062a:	4630      	mov	r0, r6
2002062c:	b005      	add	sp, #20
2002062e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020632:	f8da 1000 	ldr.w	r1, [sl]
20020636:	f8db 0000 	ldr.w	r0, [fp]
2002063a:	42a9      	cmp	r1, r5
2002063c:	fbb0 fcf1 	udiv	ip, r0, r1
20020640:	4689      	mov	r9, r1
20020642:	f101 32ff 	add.w	r2, r1, #4294967295
20020646:	bf28      	it	cs
20020648:	46a9      	movcs	r9, r5
2002064a:	fbb4 f1f1 	udiv	r1, r4, r1
2002064e:	f10c 3cff 	add.w	ip, ip, #4294967295
20020652:	fbb4 f0f0 	udiv	r0, r4, r0
20020656:	e9cd 8801 	strd	r8, r8, [sp, #4]
2002065a:	f8cd 9000 	str.w	r9, [sp]
2002065e:	19bb      	adds	r3, r7, r6
20020660:	4022      	ands	r2, r4
20020662:	ea0c 0101 	and.w	r1, ip, r1
20020666:	f004 f891 	bl	2002478c <bbm_read_page>
2002066a:	4548      	cmp	r0, r9
2002066c:	d1dd      	bne.n	2002062a <read_nand+0x26>
2002066e:	4406      	add	r6, r0
20020670:	1a2d      	subs	r5, r5, r0
20020672:	4404      	add	r4, r0
20020674:	e7d8      	b.n	20020628 <read_nand+0x24>
20020676:	bf00      	nop
20020678:	20046d30 	.word	0x20046d30
2002067c:	20042c04 	.word	0x20042c04
20020680:	20042c00 	.word	0x20042c00

20020684 <read_sdnand>:
20020684:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020688:	f3c0 0408 	ubfx	r4, r0, #0, #9
2002068c:	460e      	mov	r6, r1
2002068e:	4615      	mov	r5, r2
20020690:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020694:	b38c      	cbz	r4, 200206fa <read_sdnand+0x76>
20020696:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 20020710 <read_sdnand+0x8c>
2002069a:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
2002069e:	eba8 0004 	sub.w	r0, r8, r4
200206a2:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206a6:	4649      	mov	r1, r9
200206a8:	f000 fed2 	bl	20021450 <sd_read_data>
200206ac:	42af      	cmp	r7, r5
200206ae:	bf28      	it	cs
200206b0:	462f      	movcs	r7, r5
200206b2:	4630      	mov	r0, r6
200206b4:	eb09 0104 	add.w	r1, r9, r4
200206b8:	463a      	mov	r2, r7
200206ba:	f005 f858 	bl	2002576e <memcpy>
200206be:	1bec      	subs	r4, r5, r7
200206c0:	44b8      	add	r8, r7
200206c2:	443e      	add	r6, r7
200206c4:	2700      	movs	r7, #0
200206c6:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
200206ca:	f02a 0a01 	bic.w	sl, sl, #1
200206ce:	4557      	cmp	r7, sl
200206d0:	eb07 0906 	add.w	r9, r7, r6
200206d4:	eb08 0007 	add.w	r0, r8, r7
200206d8:	d111      	bne.n	200206fe <read_sdnand+0x7a>
200206da:	f3c4 0408 	ubfx	r4, r4, #0, #9
200206de:	b14c      	cbz	r4, 200206f4 <read_sdnand+0x70>
200206e0:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206e4:	490a      	ldr	r1, [pc, #40]	@ (20020710 <read_sdnand+0x8c>)
200206e6:	f000 feb3 	bl	20021450 <sd_read_data>
200206ea:	4622      	mov	r2, r4
200206ec:	4648      	mov	r0, r9
200206ee:	4908      	ldr	r1, [pc, #32]	@ (20020710 <read_sdnand+0x8c>)
200206f0:	f005 f83d 	bl	2002576e <memcpy>
200206f4:	4628      	mov	r0, r5
200206f6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200206fa:	4614      	mov	r4, r2
200206fc:	e7e2      	b.n	200206c4 <read_sdnand+0x40>
200206fe:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020702:	4649      	mov	r1, r9
20020704:	f000 fea4 	bl	20021450 <sd_read_data>
20020708:	f507 7700 	add.w	r7, r7, #512	@ 0x200
2002070c:	e7df      	b.n	200206ce <read_sdnand+0x4a>
2002070e:	bf00      	nop
20020710:	20046b2c 	.word	0x20046b2c

20020714 <read_sdemmc>:
20020714:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020718:	f3c0 0408 	ubfx	r4, r0, #0, #9
2002071c:	460e      	mov	r6, r1
2002071e:	4615      	mov	r5, r2
20020720:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020724:	b38c      	cbz	r4, 2002078a <read_sdemmc+0x76>
20020726:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 200207a0 <read_sdemmc+0x8c>
2002072a:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
2002072e:	eba8 0004 	sub.w	r0, r8, r4
20020732:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020736:	4649      	mov	r1, r9
20020738:	f000 fd2e 	bl	20021198 <emmc_read_data>
2002073c:	42af      	cmp	r7, r5
2002073e:	bf28      	it	cs
20020740:	462f      	movcs	r7, r5
20020742:	4630      	mov	r0, r6
20020744:	eb09 0104 	add.w	r1, r9, r4
20020748:	463a      	mov	r2, r7
2002074a:	f005 f810 	bl	2002576e <memcpy>
2002074e:	1bec      	subs	r4, r5, r7
20020750:	44b8      	add	r8, r7
20020752:	443e      	add	r6, r7
20020754:	2700      	movs	r7, #0
20020756:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
2002075a:	f02a 0a01 	bic.w	sl, sl, #1
2002075e:	4557      	cmp	r7, sl
20020760:	eb07 0906 	add.w	r9, r7, r6
20020764:	eb08 0007 	add.w	r0, r8, r7
20020768:	d111      	bne.n	2002078e <read_sdemmc+0x7a>
2002076a:	f3c4 0408 	ubfx	r4, r4, #0, #9
2002076e:	b14c      	cbz	r4, 20020784 <read_sdemmc+0x70>
20020770:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020774:	490a      	ldr	r1, [pc, #40]	@ (200207a0 <read_sdemmc+0x8c>)
20020776:	f000 fd0f 	bl	20021198 <emmc_read_data>
2002077a:	4622      	mov	r2, r4
2002077c:	4648      	mov	r0, r9
2002077e:	4908      	ldr	r1, [pc, #32]	@ (200207a0 <read_sdemmc+0x8c>)
20020780:	f004 fff5 	bl	2002576e <memcpy>
20020784:	4628      	mov	r0, r5
20020786:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002078a:	4614      	mov	r4, r2
2002078c:	e7e2      	b.n	20020754 <read_sdemmc+0x40>
2002078e:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020792:	4649      	mov	r1, r9
20020794:	f000 fd00 	bl	20021198 <emmc_read_data>
20020798:	f507 7700 	add.w	r7, r7, #512	@ 0x200
2002079c:	e7df      	b.n	2002075e <read_sdemmc+0x4a>
2002079e:	bf00      	nop
200207a0:	20046b2c 	.word	0x20046b2c

200207a4 <port_read_page>:
200207a4:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200207a8:	4615      	mov	r5, r2
200207aa:	460e      	mov	r6, r1
200207ac:	492b      	ldr	r1, [pc, #172]	@ (2002085c <port_read_page+0xb8>)
200207ae:	461a      	mov	r2, r3
200207b0:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
200207b4:	680f      	ldr	r7, [r1, #0]
200207b6:	18e9      	adds	r1, r5, r3
200207b8:	428f      	cmp	r7, r1
200207ba:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
200207be:	d200      	bcs.n	200207c2 <port_read_page+0x1e>
200207c0:	e7fe      	b.n	200207c0 <port_read_page+0x1c>
200207c2:	4927      	ldr	r1, [pc, #156]	@ (20020860 <port_read_page+0xbc>)
200207c4:	f107 0980 	add.w	r9, r7, #128	@ 0x80
200207c8:	f1b9 0f00 	cmp.w	r9, #0
200207cc:	6809      	ldr	r1, [r1, #0]
200207ce:	dd18      	ble.n	20020802 <port_read_page+0x5e>
200207d0:	4c24      	ldr	r4, [pc, #144]	@ (20020864 <port_read_page+0xc0>)
200207d2:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
200207d6:	f004 081f 	and.w	r8, r4, #31
200207da:	44c8      	add	r8, r9
200207dc:	f024 041f 	bic.w	r4, r4, #31
200207e0:	f3bf 8f4f 	dsb	sy
200207e4:	f8df a084 	ldr.w	sl, [pc, #132]	@ 2002086c <port_read_page+0xc8>
200207e8:	44a0      	add	r8, r4
200207ea:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
200207ee:	3420      	adds	r4, #32
200207f0:	eba8 0904 	sub.w	r9, r8, r4
200207f4:	f1b9 0f00 	cmp.w	r9, #0
200207f8:	dcf7      	bgt.n	200207ea <port_read_page+0x46>
200207fa:	f3bf 8f4f 	dsb	sy
200207fe:	f3bf 8f6f 	isb	sy
20020802:	07c4      	lsls	r4, r0, #31
20020804:	d51e      	bpl.n	20020844 <port_read_page+0xa0>
20020806:	4c17      	ldr	r4, [pc, #92]	@ (20020864 <port_read_page+0xc0>)
20020808:	f894 80d7 	ldrb.w	r8, [r4, #215]	@ 0xd7
2002080c:	f1b8 0f00 	cmp.w	r8, #0
20020810:	d018      	beq.n	20020844 <port_read_page+0xa0>
20020812:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
20020816:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
2002081a:	f004 041f 	and.w	r4, r4, #31
2002081e:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020822:	f028 081f 	bic.w	r8, r8, #31
20020826:	f3bf 8f4f 	dsb	sy
2002082a:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 2002086c <port_read_page+0xc8>
2002082e:	3c20      	subs	r4, #32
20020830:	2c00      	cmp	r4, #0
20020832:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
20020836:	f108 0820 	add.w	r8, r8, #32
2002083a:	dcf8      	bgt.n	2002082e <port_read_page+0x8a>
2002083c:	f3bf 8f4f 	dsb	sy
20020840:	f3bf 8f6f 	isb	sy
20020844:	fb07 5506 	mla	r5, r7, r6, r5
20020848:	e9cd ce08 	strd	ip, lr, [sp, #32]
2002084c:	fb01 5100 	mla	r1, r1, r0, r5
20020850:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020854:	4804      	ldr	r0, [pc, #16]	@ (20020868 <port_read_page+0xc4>)
20020856:	f002 bc27 	b.w	200230a8 <HAL_NAND_READ_WITHOOB>
2002085a:	bf00      	nop
2002085c:	20042c04 	.word	0x20042c04
20020860:	20042c00 	.word	0x20042c00
20020864:	20046f70 	.word	0x20046f70
20020868:	20047018 	.word	0x20047018
2002086c:	e000ed00 	.word	0xe000ed00

20020870 <bbm_get_bb>:
20020870:	b410      	push	{r4}
20020872:	4b1e      	ldr	r3, [pc, #120]	@ (200208ec <bbm_get_bb+0x7c>)
20020874:	4601      	mov	r1, r0
20020876:	6818      	ldr	r0, [r3, #0]
20020878:	3080      	adds	r0, #128	@ 0x80
2002087a:	2800      	cmp	r0, #0
2002087c:	dd14      	ble.n	200208a8 <bbm_get_bb+0x38>
2002087e:	4b1c      	ldr	r3, [pc, #112]	@ (200208f0 <bbm_get_bb+0x80>)
20020880:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
20020882:	f003 021f 	and.w	r2, r3, #31
20020886:	4402      	add	r2, r0
20020888:	f023 031f 	bic.w	r3, r3, #31
2002088c:	f3bf 8f4f 	dsb	sy
20020890:	4c18      	ldr	r4, [pc, #96]	@ (200208f4 <bbm_get_bb+0x84>)
20020892:	441a      	add	r2, r3
20020894:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
20020898:	3320      	adds	r3, #32
2002089a:	1ad0      	subs	r0, r2, r3
2002089c:	2800      	cmp	r0, #0
2002089e:	dcf9      	bgt.n	20020894 <bbm_get_bb+0x24>
200208a0:	f3bf 8f4f 	dsb	sy
200208a4:	f3bf 8f6f 	isb	sy
200208a8:	07cb      	lsls	r3, r1, #31
200208aa:	d51a      	bpl.n	200208e2 <bbm_get_bb+0x72>
200208ac:	4b10      	ldr	r3, [pc, #64]	@ (200208f0 <bbm_get_bb+0x80>)
200208ae:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
200208b2:	b1b2      	cbz	r2, 200208e2 <bbm_get_bb+0x72>
200208b4:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208b6:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
200208ba:	f003 031f 	and.w	r3, r3, #31
200208be:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
200208c2:	f022 021f 	bic.w	r2, r2, #31
200208c6:	f3bf 8f4f 	dsb	sy
200208ca:	480a      	ldr	r0, [pc, #40]	@ (200208f4 <bbm_get_bb+0x84>)
200208cc:	3b20      	subs	r3, #32
200208ce:	2b00      	cmp	r3, #0
200208d0:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
200208d4:	f102 0220 	add.w	r2, r2, #32
200208d8:	dcf8      	bgt.n	200208cc <bbm_get_bb+0x5c>
200208da:	f3bf 8f4f 	dsb	sy
200208de:	f3bf 8f6f 	isb	sy
200208e2:	4805      	ldr	r0, [pc, #20]	@ (200208f8 <bbm_get_bb+0x88>)
200208e4:	f85d 4b04 	ldr.w	r4, [sp], #4
200208e8:	f002 bc9f 	b.w	2002322a <HAL_NAND_GET_BADBLK>
200208ec:	20042c04 	.word	0x20042c04
200208f0:	20046f70 	.word	0x20046f70
200208f4:	e000ed00 	.word	0xe000ed00
200208f8:	20046fc4 	.word	0x20046fc4

200208fc <boot_device_init>:
200208fc:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020900:	b08c      	sub	sp, #48	@ 0x30
20020902:	f001 fcf3 	bl	200222ec <HAL_HPAON_EnableXT48>
20020906:	2101      	movs	r1, #1
20020908:	2000      	movs	r0, #0
2002090a:	f003 f96d 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
2002090e:	2101      	movs	r1, #1
20020910:	200c      	movs	r0, #12
20020912:	f003 f969 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20020916:	2001      	movs	r0, #1
20020918:	f003 f814 	bl	20023944 <HAL_PMU_EnableDLL>
2002091c:	4fa3      	ldr	r7, [pc, #652]	@ (20020bac <boot_device_init+0x2b0>)
2002091e:	2090      	movs	r0, #144	@ 0x90
20020920:	f003 fac8 	bl	20023eb4 <HAL_RCC_HCPU_ConfigHCLK>
20020924:	48a2      	ldr	r0, [pc, #648]	@ (20020bb0 <boot_device_init+0x2b4>)
20020926:	f003 f927 	bl	20023b78 <HAL_RCC_HCPU_EnableDLL2>
2002092a:	783b      	ldrb	r3, [r7, #0]
2002092c:	4ca1      	ldr	r4, [pc, #644]	@ (20020bb4 <boot_device_init+0x2b8>)
2002092e:	2b06      	cmp	r3, #6
20020930:	f200 8137 	bhi.w	20020ba2 <boot_device_init+0x2a6>
20020934:	e8df f013 	tbh	[pc, r3, lsl #1]
20020938:	00440007 	.word	0x00440007
2002093c:	009f0044 	.word	0x009f0044
20020940:	011b009f 	.word	0x011b009f
20020944:	012a      	.short	0x012a
20020946:	2006      	movs	r0, #6
20020948:	4e9b      	ldr	r6, [pc, #620]	@ (20020bb8 <boot_device_init+0x2bc>)
2002094a:	f000 feb9 	bl	200216c0 <BSP_SetFlash2DIV>
2002094e:	ad02      	add	r5, sp, #8
20020950:	2102      	movs	r1, #2
20020952:	2006      	movs	r0, #6
20020954:	f003 f948 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20020958:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002095a:	c50f      	stmia	r5!, {r0, r1, r2, r3}
2002095c:	6833      	ldr	r3, [r6, #0]
2002095e:	2210      	movs	r2, #16
20020960:	2100      	movs	r1, #0
20020962:	602b      	str	r3, [r5, #0]
20020964:	a808      	add	r0, sp, #32
20020966:	f004 fe93 	bl	20025690 <memset>
2002096a:	4b94      	ldr	r3, [pc, #592]	@ (20020bbc <boot_device_init+0x2c0>)
2002096c:	2601      	movs	r6, #1
2002096e:	9307      	str	r3, [sp, #28]
20020970:	2333      	movs	r3, #51	@ 0x33
20020972:	960a      	str	r6, [sp, #40]	@ 0x28
20020974:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020978:	f7ff fcfe 	bl	20020378 <board_pinmux_mpi2>
2002097c:	2302      	movs	r3, #2
2002097e:	4d90      	ldr	r5, [pc, #576]	@ (20020bc0 <boot_device_init+0x2c4>)
20020980:	9303      	str	r3, [sp, #12]
20020982:	4b90      	ldr	r3, [pc, #576]	@ (20020bc4 <boot_device_init+0x2c8>)
20020984:	2000      	movs	r0, #0
20020986:	6023      	str	r3, [r4, #0]
20020988:	f000 ffa1 	bl	200218ce <HAL_Delay_us>
2002098c:	f885 6099 	strb.w	r6, [r5, #153]	@ 0x99
20020990:	f000 fe84 	bl	2002169c <BSP_GetFlash2DIV>
20020994:	f105 0654 	add.w	r6, r5, #84	@ 0x54
20020998:	4a8b      	ldr	r2, [pc, #556]	@ (20020bc8 <boot_device_init+0x2cc>)
2002099a:	9000      	str	r0, [sp, #0]
2002099c:	ab07      	add	r3, sp, #28
2002099e:	4630      	mov	r0, r6
200209a0:	a902      	add	r1, sp, #8
200209a2:	f002 fdc1 	bl	20023528 <HAL_FLASH_Init>
200209a6:	4b89      	ldr	r3, [pc, #548]	@ (20020bcc <boot_device_init+0x2d0>)
200209a8:	4a89      	ldr	r2, [pc, #548]	@ (20020bd0 <boot_device_init+0x2d4>)
200209aa:	601a      	str	r2, [r3, #0]
200209ac:	4a89      	ldr	r2, [pc, #548]	@ (20020bd4 <boot_device_init+0x2d8>)
200209ae:	4b8a      	ldr	r3, [pc, #552]	@ (20020bd8 <boot_device_init+0x2dc>)
200209b0:	601a      	str	r2, [r3, #0]
200209b2:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
200209b6:	4b89      	ldr	r3, [pc, #548]	@ (20020bdc <boot_device_init+0x2e0>)
200209b8:	601a      	str	r2, [r3, #0]
200209ba:	4b89      	ldr	r3, [pc, #548]	@ (20020be0 <boot_device_init+0x2e4>)
200209bc:	601e      	str	r6, [r3, #0]
200209be:	e037      	b.n	20020a30 <boot_device_init+0x134>
200209c0:	2006      	movs	r0, #6
200209c2:	4e88      	ldr	r6, [pc, #544]	@ (20020be4 <boot_device_init+0x2e8>)
200209c4:	f000 fe76 	bl	200216b4 <BSP_SetFlash1DIV>
200209c8:	ad02      	add	r5, sp, #8
200209ca:	2102      	movs	r1, #2
200209cc:	2004      	movs	r0, #4
200209ce:	f003 f90b 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
200209d2:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
200209d4:	c50f      	stmia	r5!, {r0, r1, r2, r3}
200209d6:	6833      	ldr	r3, [r6, #0]
200209d8:	2210      	movs	r2, #16
200209da:	602b      	str	r3, [r5, #0]
200209dc:	2100      	movs	r1, #0
200209de:	a808      	add	r0, sp, #32
200209e0:	f004 fe56 	bl	20025690 <memset>
200209e4:	4b80      	ldr	r3, [pc, #512]	@ (20020be8 <boot_device_init+0x2ec>)
200209e6:	4d76      	ldr	r5, [pc, #472]	@ (20020bc0 <boot_device_init+0x2c4>)
200209e8:	9307      	str	r3, [sp, #28]
200209ea:	2332      	movs	r3, #50	@ 0x32
200209ec:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
200209f0:	2301      	movs	r3, #1
200209f2:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
200209f6:	783b      	ldrb	r3, [r7, #0]
200209f8:	2b01      	cmp	r3, #1
200209fa:	d139      	bne.n	20020a70 <boot_device_init+0x174>
200209fc:	f7ff fc58 	bl	200202b0 <board_pinmux_mpi1_type1>
20020a00:	2302      	movs	r3, #2
20020a02:	9303      	str	r3, [sp, #12]
20020a04:	f000 fe44 	bl	20021690 <BSP_GetFlash1DIV>
20020a08:	4a78      	ldr	r2, [pc, #480]	@ (20020bec <boot_device_init+0x2f0>)
20020a0a:	9000      	str	r0, [sp, #0]
20020a0c:	ab07      	add	r3, sp, #28
20020a0e:	486c      	ldr	r0, [pc, #432]	@ (20020bc0 <boot_device_init+0x2c4>)
20020a10:	a902      	add	r1, sp, #8
20020a12:	f002 fd89 	bl	20023528 <HAL_FLASH_Init>
20020a16:	4b6b      	ldr	r3, [pc, #428]	@ (20020bc4 <boot_device_init+0x2c8>)
20020a18:	4a6d      	ldr	r2, [pc, #436]	@ (20020bd0 <boot_device_init+0x2d4>)
20020a1a:	6023      	str	r3, [r4, #0]
20020a1c:	4b6b      	ldr	r3, [pc, #428]	@ (20020bcc <boot_device_init+0x2d0>)
20020a1e:	601a      	str	r2, [r3, #0]
20020a20:	4b6d      	ldr	r3, [pc, #436]	@ (20020bd8 <boot_device_init+0x2dc>)
20020a22:	4a6c      	ldr	r2, [pc, #432]	@ (20020bd4 <boot_device_init+0x2d8>)
20020a24:	601a      	str	r2, [r3, #0]
20020a26:	4b6d      	ldr	r3, [pc, #436]	@ (20020bdc <boot_device_init+0x2e0>)
20020a28:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020a2a:	601a      	str	r2, [r3, #0]
20020a2c:	4b6c      	ldr	r3, [pc, #432]	@ (20020be0 <boot_device_init+0x2e4>)
20020a2e:	601d      	str	r5, [r3, #0]
20020a30:	6823      	ldr	r3, [r4, #0]
20020a32:	2b00      	cmp	r3, #0
20020a34:	f000 8110 	beq.w	20020c58 <boot_device_init+0x35c>
20020a38:	4e68      	ldr	r6, [pc, #416]	@ (20020bdc <boot_device_init+0x2e0>)
20020a3a:	6830      	ldr	r0, [r6, #0]
20020a3c:	2800      	cmp	r0, #0
20020a3e:	f000 810b 	beq.w	20020c58 <boot_device_init+0x35c>
20020a42:	4d6b      	ldr	r5, [pc, #428]	@ (20020bf0 <boot_device_init+0x2f4>)
20020a44:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020a48:	4629      	mov	r1, r5
20020a4a:	4798      	blx	r3
20020a4c:	682a      	ldr	r2, [r5, #0]
20020a4e:	4b69      	ldr	r3, [pc, #420]	@ (20020bf4 <boot_device_init+0x2f8>)
20020a50:	7839      	ldrb	r1, [r7, #0]
20020a52:	429a      	cmp	r2, r3
20020a54:	f040 80fb 	bne.w	20020c4e <boot_device_init+0x352>
20020a58:	2904      	cmp	r1, #4
20020a5a:	d105      	bne.n	20020a68 <boot_device_init+0x16c>
20020a5c:	f8d5 30a4 	ldr.w	r3, [r5, #164]	@ 0xa4
20020a60:	1e5a      	subs	r2, r3, #1
20020a62:	3203      	adds	r2, #3
20020a64:	f240 80e2 	bls.w	20020c2c <boot_device_init+0x330>
20020a68:	2001      	movs	r0, #1
20020a6a:	b00c      	add	sp, #48	@ 0x30
20020a6c:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020a70:	f7ff fc50 	bl	20020314 <board_pinmux_mpi1_type2>
20020a74:	e7c4      	b.n	20020a00 <boot_device_init+0x104>
20020a76:	2006      	movs	r0, #6
20020a78:	4e5f      	ldr	r6, [pc, #380]	@ (20020bf8 <boot_device_init+0x2fc>)
20020a7a:	f000 fe27 	bl	200216cc <BSP_SetFlash3DIV>
20020a7e:	ad02      	add	r5, sp, #8
20020a80:	2102      	movs	r1, #2
20020a82:	2008      	movs	r0, #8
20020a84:	f003 f8b0 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20020a88:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020a8a:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020a8c:	f897 8000 	ldrb.w	r8, [r7]
20020a90:	6833      	ldr	r3, [r6, #0]
20020a92:	f1b8 0a03 	subs.w	sl, r8, #3
20020a96:	602b      	str	r3, [r5, #0]
20020a98:	f04f 0210 	mov.w	r2, #16
20020a9c:	f04f 0100 	mov.w	r1, #0
20020aa0:	a808      	add	r0, sp, #32
20020aa2:	bf18      	it	ne
20020aa4:	f04f 0a01 	movne.w	sl, #1
20020aa8:	f004 fdf2 	bl	20025690 <memset>
20020aac:	4b4e      	ldr	r3, [pc, #312]	@ (20020be8 <boot_device_init+0x2ec>)
20020aae:	2502      	movs	r5, #2
20020ab0:	9307      	str	r3, [sp, #28]
20020ab2:	2332      	movs	r3, #50	@ 0x32
20020ab4:	950a      	str	r5, [sp, #40]	@ 0x28
20020ab6:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020aba:	f7ff fc8f 	bl	200203dc <board_pinmux_mpi3>
20020abe:	f1b8 0f03 	cmp.w	r8, #3
20020ac2:	9503      	str	r5, [sp, #12]
20020ac4:	4d3e      	ldr	r5, [pc, #248]	@ (20020bc0 <boot_device_init+0x2c4>)
20020ac6:	d045      	beq.n	20020b54 <boot_device_init+0x258>
20020ac8:	4b4c      	ldr	r3, [pc, #304]	@ (20020bfc <boot_device_init+0x300>)
20020aca:	6023      	str	r3, [r4, #0]
20020acc:	9b04      	ldr	r3, [sp, #16]
20020ace:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020ad2:	9304      	str	r3, [sp, #16]
20020ad4:	2301      	movs	r3, #1
20020ad6:	9306      	str	r3, [sp, #24]
20020ad8:	4b49      	ldr	r3, [pc, #292]	@ (20020c00 <boot_device_init+0x304>)
20020ada:	f8c5 30c4 	str.w	r3, [r5, #196]	@ 0xc4
20020ade:	f04f 0901 	mov.w	r9, #1
20020ae2:	2000      	movs	r0, #0
20020ae4:	f000 fef3 	bl	200218ce <HAL_Delay_us>
20020ae8:	f885 90ed 	strb.w	r9, [r5, #237]	@ 0xed
20020aec:	f885 a0ec 	strb.w	sl, [r5, #236]	@ 0xec
20020af0:	f000 fdda 	bl	200216a8 <BSP_GetFlash3DIV>
20020af4:	4a43      	ldr	r2, [pc, #268]	@ (20020c04 <boot_device_init+0x308>)
20020af6:	9000      	str	r0, [sp, #0]
20020af8:	ab07      	add	r3, sp, #28
20020afa:	4843      	ldr	r0, [pc, #268]	@ (20020c08 <boot_device_init+0x30c>)
20020afc:	a902      	add	r1, sp, #8
20020afe:	f002 fd13 	bl	20023528 <HAL_FLASH_Init>
20020b02:	4e41      	ldr	r6, [pc, #260]	@ (20020c08 <boot_device_init+0x30c>)
20020b04:	bb48      	cbnz	r0, 20020b5a <boot_device_init+0x25e>
20020b06:	f1b8 0f03 	cmp.w	r8, #3
20020b0a:	d029      	beq.n	20020b60 <boot_device_init+0x264>
20020b0c:	4630      	mov	r0, r6
20020b0e:	f002 fac0 	bl	20023092 <HAL_NAND_PAGE_SIZE>
20020b12:	f8df a110 	ldr.w	sl, [pc, #272]	@ 20020c24 <boot_device_init+0x328>
20020b16:	f8df 8110 	ldr.w	r8, [pc, #272]	@ 20020c28 <boot_device_init+0x32c>
20020b1a:	f8ca 0000 	str.w	r0, [sl]
20020b1e:	4630      	mov	r0, r6
20020b20:	f002 fb77 	bl	20023212 <HAL_NAND_BLOCK_SIZE>
20020b24:	4649      	mov	r1, r9
20020b26:	f8c8 0000 	str.w	r0, [r8]
20020b2a:	4630      	mov	r0, r6
20020b2c:	f885 90d6 	strb.w	r9, [r5, #214]	@ 0xd6
20020b30:	f002 f96e 	bl	20022e10 <HAL_NAND_CONF_ECC>
20020b34:	f8da 0000 	ldr.w	r0, [sl]
20020b38:	f004 f90e 	bl	20024d58 <bbm_set_page_size>
20020b3c:	f8d8 0000 	ldr.w	r0, [r8]
20020b40:	f004 f910 	bl	20024d64 <bbm_set_blk_size>
20020b44:	4931      	ldr	r1, [pc, #196]	@ (20020c0c <boot_device_init+0x310>)
20020b46:	f8d5 00f4 	ldr.w	r0, [r5, #244]	@ 0xf4
20020b4a:	f003 ffa7 	bl	20024a9c <sif_bbm_init>
20020b4e:	f8d5 20f0 	ldr.w	r2, [r5, #240]	@ 0xf0
20020b52:	e730      	b.n	200209b6 <boot_device_init+0xba>
20020b54:	4b1b      	ldr	r3, [pc, #108]	@ (20020bc4 <boot_device_init+0x2c8>)
20020b56:	6023      	str	r3, [r4, #0]
20020b58:	e7c1      	b.n	20020ade <boot_device_init+0x1e2>
20020b5a:	f1b8 0f03 	cmp.w	r8, #3
20020b5e:	d1f6      	bne.n	20020b4e <boot_device_init+0x252>
20020b60:	4b1a      	ldr	r3, [pc, #104]	@ (20020bcc <boot_device_init+0x2d0>)
20020b62:	4a1b      	ldr	r2, [pc, #108]	@ (20020bd0 <boot_device_init+0x2d4>)
20020b64:	601a      	str	r2, [r3, #0]
20020b66:	4b1c      	ldr	r3, [pc, #112]	@ (20020bd8 <boot_device_init+0x2dc>)
20020b68:	4a1a      	ldr	r2, [pc, #104]	@ (20020bd4 <boot_device_init+0x2d8>)
20020b6a:	601a      	str	r2, [r3, #0]
20020b6c:	e7ef      	b.n	20020b4e <boot_device_init+0x252>
20020b6e:	f7ff fc83 	bl	20020478 <board_pinmux_sd>
20020b72:	f000 fb59 	bl	20021228 <sdio_sd_init>
20020b76:	2801      	cmp	r0, #1
20020b78:	d111      	bne.n	20020b9e <boot_device_init+0x2a2>
20020b7a:	4b25      	ldr	r3, [pc, #148]	@ (20020c10 <boot_device_init+0x314>)
20020b7c:	6023      	str	r3, [r4, #0]
20020b7e:	4b25      	ldr	r3, [pc, #148]	@ (20020c14 <boot_device_init+0x318>)
20020b80:	4a16      	ldr	r2, [pc, #88]	@ (20020bdc <boot_device_init+0x2e0>)
20020b82:	6013      	str	r3, [r2, #0]
20020b84:	2200      	movs	r2, #0
20020b86:	4b16      	ldr	r3, [pc, #88]	@ (20020be0 <boot_device_init+0x2e4>)
20020b88:	601a      	str	r2, [r3, #0]
20020b8a:	e751      	b.n	20020a30 <boot_device_init+0x134>
20020b8c:	f7ff fc74 	bl	20020478 <board_pinmux_sd>
20020b90:	f000 fa1c 	bl	20020fcc <sdio_emmc_init>
20020b94:	4b20      	ldr	r3, [pc, #128]	@ (20020c18 <boot_device_init+0x31c>)
20020b96:	6018      	str	r0, [r3, #0]
20020b98:	b908      	cbnz	r0, 20020b9e <boot_device_init+0x2a2>
20020b9a:	4b20      	ldr	r3, [pc, #128]	@ (20020c1c <boot_device_init+0x320>)
20020b9c:	e7ee      	b.n	20020b7c <boot_device_init+0x280>
20020b9e:	2300      	movs	r3, #0
20020ba0:	e7ee      	b.n	20020b80 <boot_device_init+0x284>
20020ba2:	481f      	ldr	r0, [pc, #124]	@ (20020c20 <boot_device_init+0x324>)
20020ba4:	f004 fc1e 	bl	200253e4 <iprintf>
20020ba8:	e742      	b.n	20020a30 <boot_device_init+0x134>
20020baa:	bf00      	nop
20020bac:	20044a24 	.word	0x20044a24
20020bb0:	112a8800 	.word	0x112a8800
20020bb4:	20046d3c 	.word	0x20046d3c
20020bb8:	200263f8 	.word	0x200263f8
20020bbc:	5008101c 	.word	0x5008101c
20020bc0:	20046f70 	.word	0x20046f70
20020bc4:	200205f1 	.word	0x200205f1
20020bc8:	20046db0 	.word	0x20046db0
20020bcc:	20046d38 	.word	0x20046d38
20020bd0:	2002056d 	.word	0x2002056d
20020bd4:	20020519 	.word	0x20020519
20020bd8:	20046d34 	.word	0x20046d34
20020bdc:	20046d2c 	.word	0x20046d2c
20020be0:	20046d30 	.word	0x20046d30
20020be4:	2002640c 	.word	0x2002640c
20020be8:	50081008 	.word	0x50081008
20020bec:	20046d40 	.word	0x20046d40
20020bf0:	20047138 	.word	0x20047138
20020bf4:	53454346 	.word	0x53454346
20020bf8:	20026420 	.word	0x20026420
20020bfc:	20020605 	.word	0x20020605
20020c00:	20045aac 	.word	0x20045aac
20020c04:	20046e20 	.word	0x20046e20
20020c08:	20047018 	.word	0x20047018
20020c0c:	20044a2c 	.word	0x20044a2c
20020c10:	20020685 	.word	0x20020685
20020c14:	64001000 	.word	0x64001000
20020c18:	20044a28 	.word	0x20044a28
20020c1c:	20020715 	.word	0x20020715
20020c20:	20025ee4 	.word	0x20025ee4
20020c24:	20042c04 	.word	0x20042c04
20020c28:	20042c00 	.word	0x20042c00
20020c2c:	4a0c      	ldr	r2, [pc, #48]	@ (20020c60 <boot_device_init+0x364>)
20020c2e:	4629      	mov	r1, r5
20020c30:	6013      	str	r3, [r2, #0]
20020c32:	4b0c      	ldr	r3, [pc, #48]	@ (20020c64 <boot_device_init+0x368>)
20020c34:	6830      	ldr	r0, [r6, #0]
20020c36:	681a      	ldr	r2, [r3, #0]
20020c38:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20020c3c:	f043 0301 	orr.w	r3, r3, #1
20020c40:	f882 302c 	strb.w	r3, [r2, #44]	@ 0x2c
20020c44:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020c48:	6823      	ldr	r3, [r4, #0]
20020c4a:	4798      	blx	r3
20020c4c:	e70c      	b.n	20020a68 <boot_device_init+0x16c>
20020c4e:	4806      	ldr	r0, [pc, #24]	@ (20020c68 <boot_device_init+0x36c>)
20020c50:	f004 fbc8 	bl	200253e4 <iprintf>
20020c54:	2000      	movs	r0, #0
20020c56:	e708      	b.n	20020a6a <boot_device_init+0x16e>
20020c58:	7839      	ldrb	r1, [r7, #0]
20020c5a:	4804      	ldr	r0, [pc, #16]	@ (20020c6c <boot_device_init+0x370>)
20020c5c:	e7f8      	b.n	20020c50 <boot_device_init+0x354>
20020c5e:	bf00      	nop
20020c60:	20042c04 	.word	0x20042c04
20020c64:	20046d30 	.word	0x20046d30
20020c68:	20025ef8 	.word	0x20025ef8
20020c6c:	20025f1e 	.word	0x20025f1e

20020c70 <sifli_hw_efuse_load_bank0>:
20020c70:	2220      	movs	r2, #32
20020c72:	b508      	push	{r3, lr}
20020c74:	4904      	ldr	r1, [pc, #16]	@ (20020c88 <sifli_hw_efuse_load_bank0+0x18>)
20020c76:	2000      	movs	r0, #0
20020c78:	f001 fae0 	bl	2002223c <HAL_EFUSE_Read>
20020c7c:	2800      	cmp	r0, #0
20020c7e:	4802      	ldr	r0, [pc, #8]	@ (20020c88 <sifli_hw_efuse_load_bank0+0x18>)
20020c80:	bf08      	it	eq
20020c82:	2000      	moveq	r0, #0
20020c84:	bd08      	pop	{r3, pc}
20020c86:	bf00      	nop
20020c88:	20047114 	.word	0x20047114

20020c8c <update_sec_flash>:
20020c8c:	b570      	push	{r4, r5, r6, lr}
20020c8e:	4604      	mov	r4, r0
20020c90:	4b08      	ldr	r3, [pc, #32]	@ (20020cb4 <update_sec_flash+0x28>)
20020c92:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20020c96:	681d      	ldr	r5, [r3, #0]
20020c98:	4b07      	ldr	r3, [pc, #28]	@ (20020cb8 <update_sec_flash+0x2c>)
20020c9a:	4628      	mov	r0, r5
20020c9c:	681b      	ldr	r3, [r3, #0]
20020c9e:	4798      	blx	r3
20020ca0:	4b06      	ldr	r3, [pc, #24]	@ (20020cbc <update_sec_flash+0x30>)
20020ca2:	4621      	mov	r1, r4
20020ca4:	4628      	mov	r0, r5
20020ca6:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20020caa:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020cae:	681b      	ldr	r3, [r3, #0]
20020cb0:	4718      	bx	r3
20020cb2:	bf00      	nop
20020cb4:	20046d2c 	.word	0x20046d2c
20020cb8:	20046d34 	.word	0x20046d34
20020cbc:	20046d3c 	.word	0x20046d3c

20020cc0 <boot_images_help>:
20020cc0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020cc4:	4e55      	ldr	r6, [pc, #340]	@ (20020e1c <boot_images_help+0x15c>)
20020cc6:	f8df a164 	ldr.w	sl, [pc, #356]	@ 20020e2c <boot_images_help+0x16c>
20020cca:	6833      	ldr	r3, [r6, #0]
20020ccc:	b085      	sub	sp, #20
20020cce:	4553      	cmp	r3, sl
20020cd0:	d156      	bne.n	20020d80 <boot_images_help+0xc0>
20020cd2:	2208      	movs	r2, #8
20020cd4:	2300      	movs	r3, #0
20020cd6:	f8df b158 	ldr.w	fp, [pc, #344]	@ 20020e30 <boot_images_help+0x170>
20020cda:	eb0d 0102 	add.w	r1, sp, r2
20020cde:	e9cd 3302 	strd	r3, r3, [sp, #8]
20020ce2:	484f      	ldr	r0, [pc, #316]	@ (20020e20 <boot_images_help+0x160>)
20020ce4:	f8db 3000 	ldr.w	r3, [fp]
20020ce8:	4798      	blx	r3
20020cea:	2008      	movs	r0, #8
20020cec:	f005 fe16 	bl	2002691c <HAL_Get_backup>
20020cf0:	4605      	mov	r5, r0
20020cf2:	2005      	movs	r0, #5
20020cf4:	f005 fe12 	bl	2002691c <HAL_Get_backup>
20020cf8:	f8df 9138 	ldr.w	r9, [pc, #312]	@ 20020e34 <boot_images_help+0x174>
20020cfc:	4949      	ldr	r1, [pc, #292]	@ (20020e24 <boot_images_help+0x164>)
20020cfe:	f8d9 4000 	ldr.w	r4, [r9]
20020d02:	f8df 8134 	ldr.w	r8, [pc, #308]	@ 20020e38 <boot_images_help+0x178>
20020d06:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d0a:	f8db 3000 	ldr.w	r3, [fp]
20020d0e:	4607      	mov	r7, r0
20020d10:	f8c8 1000 	str.w	r1, [r8]
20020d14:	4620      	mov	r0, r4
20020d16:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
20020d1a:	4798      	blx	r3
20020d1c:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
20020d20:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
20020d24:	4593      	cmp	fp, r2
20020d26:	d154      	bne.n	20020dd2 <boot_images_help+0x112>
20020d28:	b2eb      	uxtb	r3, r5
20020d2a:	2b04      	cmp	r3, #4
20020d2c:	d02b      	beq.n	20020d86 <boot_images_help+0xc6>
20020d2e:	2b06      	cmp	r3, #6
20020d30:	d03f      	beq.n	20020db2 <boot_images_help+0xf2>
20020d32:	2b01      	cmp	r3, #1
20020d34:	d148      	bne.n	20020dc8 <boot_images_help+0x108>
20020d36:	2005      	movs	r0, #5
20020d38:	f005 fdf0 	bl	2002691c <HAL_Get_backup>
20020d3c:	2802      	cmp	r0, #2
20020d3e:	d006      	beq.n	20020d4e <boot_images_help+0x8e>
20020d40:	9b02      	ldr	r3, [sp, #8]
20020d42:	4553      	cmp	r3, sl
20020d44:	d106      	bne.n	20020d54 <boot_images_help+0x94>
20020d46:	f89d 300d 	ldrb.w	r3, [sp, #13]
20020d4a:	2b7f      	cmp	r3, #127	@ 0x7f
20020d4c:	d102      	bne.n	20020d54 <boot_images_help+0x94>
20020d4e:	4b36      	ldr	r3, [pc, #216]	@ (20020e28 <boot_images_help+0x168>)
20020d50:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
20020d54:	f7ff fbdd 	bl	20020512 <board_init_psram>
20020d58:	f8d6 3200 	ldr.w	r3, [r6, #512]	@ 0x200
20020d5c:	3301      	adds	r3, #1
20020d5e:	d002      	beq.n	20020d66 <boot_images_help+0xa6>
20020d60:	200b      	movs	r0, #11
20020d62:	f000 fc2d 	bl	200215c0 <dfu_boot_img_in_flash>
20020d66:	f8d6 0c08 	ldr.w	r0, [r6, #3080]	@ 0xc08
20020d6a:	1c43      	adds	r3, r0, #1
20020d6c:	d008      	beq.n	20020d80 <boot_images_help+0xc0>
20020d6e:	f8d9 3000 	ldr.w	r3, [r9]
20020d72:	1ac0      	subs	r0, r0, r3
20020d74:	f5a0 5080 	sub.w	r0, r0, #4096	@ 0x1000
20020d78:	0a40      	lsrs	r0, r0, #9
20020d7a:	3002      	adds	r0, #2
20020d7c:	f000 fc20 	bl	200215c0 <dfu_boot_img_in_flash>
20020d80:	b005      	add	sp, #20
20020d82:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020d86:	2008      	movs	r0, #8
20020d88:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020d8c:	2106      	movs	r1, #6
20020d8e:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20020d92:	f005 fdbd 	bl	20026910 <HAL_Set_backup>
20020d96:	f8d8 0000 	ldr.w	r0, [r8]
20020d9a:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020d9e:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20020da2:	b11f      	cbz	r7, 20020dac <boot_images_help+0xec>
20020da4:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020da8:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20020dac:	f7ff ff6e 	bl	20020c8c <update_sec_flash>
20020db0:	e7c1      	b.n	20020d36 <boot_images_help+0x76>
20020db2:	2101      	movs	r1, #1
20020db4:	2008      	movs	r0, #8
20020db6:	f005 fdab 	bl	20026910 <HAL_Set_backup>
20020dba:	f8d8 0000 	ldr.w	r0, [r8]
20020dbe:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020dc2:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
20020dc6:	e7f1      	b.n	20020dac <boot_images_help+0xec>
20020dc8:	2101      	movs	r1, #1
20020dca:	2008      	movs	r0, #8
20020dcc:	f005 fda0 	bl	20026910 <HAL_Set_backup>
20020dd0:	e7b1      	b.n	20020d36 <boot_images_help+0x76>
20020dd2:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020dd6:	45a3      	cmp	fp, r4
20020dd8:	d1ad      	bne.n	20020d36 <boot_images_help+0x76>
20020dda:	b2eb      	uxtb	r3, r5
20020ddc:	2b03      	cmp	r3, #3
20020dde:	d005      	beq.n	20020dec <boot_images_help+0x12c>
20020de0:	2b05      	cmp	r3, #5
20020de2:	d018      	beq.n	20020e16 <boot_images_help+0x156>
20020de4:	2b02      	cmp	r3, #2
20020de6:	d0a6      	beq.n	20020d36 <boot_images_help+0x76>
20020de8:	2102      	movs	r1, #2
20020dea:	e7ee      	b.n	20020dca <boot_images_help+0x10a>
20020dec:	2008      	movs	r0, #8
20020dee:	2105      	movs	r1, #5
20020df0:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20020df4:	9201      	str	r2, [sp, #4]
20020df6:	f005 fd8b 	bl	20026910 <HAL_Set_backup>
20020dfa:	f8d8 0000 	ldr.w	r0, [r8]
20020dfe:	9a01      	ldr	r2, [sp, #4]
20020e00:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020e04:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
20020e08:	2f00      	cmp	r7, #0
20020e0a:	d0cf      	beq.n	20020dac <boot_images_help+0xec>
20020e0c:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020e10:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20020e14:	e7ca      	b.n	20020dac <boot_images_help+0xec>
20020e16:	2102      	movs	r1, #2
20020e18:	e7cc      	b.n	20020db4 <boot_images_help+0xf4>
20020e1a:	bf00      	nop
20020e1c:	20047138 	.word	0x20047138
20020e20:	120c0000 	.word	0x120c0000
20020e24:	20049d4c 	.word	0x20049d4c
20020e28:	12001000 	.word	0x12001000
20020e2c:	53454346 	.word	0x53454346
20020e30:	20046d3c 	.word	0x20046d3c
20020e34:	20046d2c 	.word	0x20046d2c
20020e38:	20049d48 	.word	0x20049d48

20020e3c <_write>:
20020e3c:	2802      	cmp	r0, #2
20020e3e:	b510      	push	{r4, lr}
20020e40:	4614      	mov	r4, r2
20020e42:	dc04      	bgt.n	20020e4e <_write+0x12>
20020e44:	4803      	ldr	r0, [pc, #12]	@ (20020e54 <_write+0x18>)
20020e46:	f7ff fa25 	bl	20020294 <boot_uart_tx>
20020e4a:	4620      	mov	r0, r4
20020e4c:	bd10      	pop	{r4, pc}
20020e4e:	f04f 34ff 	mov.w	r4, #4294967295
20020e52:	e7fa      	b.n	20020e4a <_write+0xe>
20020e54:	50084000 	.word	0x50084000

20020e58 <entry>:
20020e58:	b508      	push	{r3, lr}
20020e5a:	f000 fb89 	bl	20021570 <sboot_init>
20020e5e:	f7ff fb56 	bl	2002050e <board_init>
20020e62:	f7ff fb4d 	bl	20020500 <board_boot_from>
20020e66:	4b04      	ldr	r3, [pc, #16]	@ (20020e78 <entry+0x20>)
20020e68:	7018      	strb	r0, [r3, #0]
20020e6a:	f7ff fd47 	bl	200208fc <boot_device_init>
20020e6e:	b108      	cbz	r0, 20020e74 <entry+0x1c>
20020e70:	f7ff ff26 	bl	20020cc0 <boot_images_help>
20020e74:	e7fe      	b.n	20020e74 <entry+0x1c>
20020e76:	bf00      	nop
20020e78:	20044a24 	.word	0x20044a24

20020e7c <sd1_init>:
20020e7c:	b510      	push	{r4, lr}
20020e7e:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20020e82:	68e3      	ldr	r3, [r4, #12]
20020e84:	2064      	movs	r0, #100	@ 0x64
20020e86:	f023 0310 	bic.w	r3, r3, #16
20020e8a:	60e3      	str	r3, [r4, #12]
20020e8c:	f000 fd1f 	bl	200218ce <HAL_Delay_us>
20020e90:	f44f 7280 	mov.w	r2, #256	@ 0x100
20020e94:	68e3      	ldr	r3, [r4, #12]
20020e96:	f043 0310 	orr.w	r3, r3, #16
20020e9a:	60e3      	str	r3, [r4, #12]
20020e9c:	4b02      	ldr	r3, [pc, #8]	@ (20020ea8 <sd1_init+0x2c>)
20020e9e:	631a      	str	r2, [r3, #48]	@ 0x30
20020ea0:	2200      	movs	r2, #0
20020ea2:	63da      	str	r2, [r3, #60]	@ 0x3c
20020ea4:	bd10      	pop	{r4, pc}
20020ea6:	bf00      	nop
20020ea8:	50045000 	.word	0x50045000

20020eac <sd1_wait_cmd>:
20020eac:	4b08      	ldr	r3, [pc, #32]	@ (20020ed0 <sd1_wait_cmd+0x24>)
20020eae:	681a      	ldr	r2, [r3, #0]
20020eb0:	f012 0f0a 	tst.w	r2, #10
20020eb4:	d0fb      	beq.n	20020eae <sd1_wait_cmd+0x2>
20020eb6:	2202      	movs	r2, #2
20020eb8:	601a      	str	r2, [r3, #0]
20020eba:	681a      	ldr	r2, [r3, #0]
20020ebc:	0712      	lsls	r2, r2, #28
20020ebe:	bf5f      	itttt	pl
20020ec0:	6818      	ldrpl	r0, [r3, #0]
20020ec2:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20020ec6:	0040      	lslpl	r0, r0, #1
20020ec8:	b2c0      	uxtbpl	r0, r0
20020eca:	bf48      	it	mi
20020ecc:	2001      	movmi	r0, #1
20020ece:	4770      	bx	lr
20020ed0:	50045000 	.word	0x50045000

20020ed4 <sd1_send_cmd>:
20020ed4:	b538      	push	{r3, r4, r5, lr}
20020ed6:	4604      	mov	r4, r0
20020ed8:	460d      	mov	r5, r1
20020eda:	4b11      	ldr	r3, [pc, #68]	@ (20020f20 <sd1_send_cmd+0x4c>)
20020edc:	6818      	ldr	r0, [r3, #0]
20020ede:	f000 fcf6 	bl	200218ce <HAL_Delay_us>
20020ee2:	4b10      	ldr	r3, [pc, #64]	@ (20020f24 <sd1_send_cmd+0x50>)
20020ee4:	2c0f      	cmp	r4, #15
20020ee6:	609d      	str	r5, [r3, #8]
20020ee8:	ea4f 4384 	mov.w	r3, r4, lsl #18
20020eec:	d815      	bhi.n	20020f1a <sd1_send_cmd+0x46>
20020eee:	2201      	movs	r2, #1
20020ef0:	f248 0111 	movw	r1, #32785	@ 0x8011
20020ef4:	40a2      	lsls	r2, r4
20020ef6:	420a      	tst	r2, r1
20020ef8:	d105      	bne.n	20020f06 <sd1_send_cmd+0x32>
20020efa:	f240 6104 	movw	r1, #1540	@ 0x604
20020efe:	420a      	tst	r2, r1
20020f00:	d00b      	beq.n	20020f1a <sd1_send_cmd+0x46>
20020f02:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
20020f06:	4a07      	ldr	r2, [pc, #28]	@ (20020f24 <sd1_send_cmd+0x50>)
20020f08:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
20020f0c:	f043 0301 	orr.w	r3, r3, #1
20020f10:	6053      	str	r3, [r2, #4]
20020f12:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20020f16:	f7ff bfc9 	b.w	20020eac <sd1_wait_cmd>
20020f1a:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20020f1e:	e7f2      	b.n	20020f06 <sd1_send_cmd+0x32>
20020f20:	20042c08 	.word	0x20042c08
20020f24:	50045000 	.word	0x50045000

20020f28 <sd1_send_acmd>:
20020f28:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20020f2a:	4605      	mov	r5, r0
20020f2c:	460f      	mov	r7, r1
20020f2e:	2037      	movs	r0, #55	@ 0x37
20020f30:	0411      	lsls	r1, r2, #16
20020f32:	f7ff ffcf 	bl	20020ed4 <sd1_send_cmd>
20020f36:	4604      	mov	r4, r0
20020f38:	b968      	cbnz	r0, 20020f56 <sd1_send_acmd+0x2e>
20020f3a:	4b08      	ldr	r3, [pc, #32]	@ (20020f5c <sd1_send_acmd+0x34>)
20020f3c:	4e08      	ldr	r6, [pc, #32]	@ (20020f60 <sd1_send_acmd+0x38>)
20020f3e:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
20020f42:	60b7      	str	r7, [r6, #8]
20020f44:	6073      	str	r3, [r6, #4]
20020f46:	f7ff ffb1 	bl	20020eac <sd1_wait_cmd>
20020f4a:	2802      	cmp	r0, #2
20020f4c:	d104      	bne.n	20020f58 <sd1_send_acmd+0x30>
20020f4e:	2d29      	cmp	r5, #41	@ 0x29
20020f50:	d102      	bne.n	20020f58 <sd1_send_acmd+0x30>
20020f52:	2304      	movs	r3, #4
20020f54:	6033      	str	r3, [r6, #0]
20020f56:	4620      	mov	r0, r4
20020f58:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20020f5a:	bf00      	nop
20020f5c:	00010101 	.word	0x00010101
20020f60:	50045000 	.word	0x50045000

20020f64 <sd1_get_rsp>:
20020f64:	b530      	push	{r4, r5, lr}
20020f66:	4c06      	ldr	r4, [pc, #24]	@ (20020f80 <sd1_get_rsp+0x1c>)
20020f68:	68e5      	ldr	r5, [r4, #12]
20020f6a:	7005      	strb	r5, [r0, #0]
20020f6c:	6920      	ldr	r0, [r4, #16]
20020f6e:	6008      	str	r0, [r1, #0]
20020f70:	6961      	ldr	r1, [r4, #20]
20020f72:	6011      	str	r1, [r2, #0]
20020f74:	69a2      	ldr	r2, [r4, #24]
20020f76:	601a      	str	r2, [r3, #0]
20020f78:	69e2      	ldr	r2, [r4, #28]
20020f7a:	9b03      	ldr	r3, [sp, #12]
20020f7c:	601a      	str	r2, [r3, #0]
20020f7e:	bd30      	pop	{r4, r5, pc}
20020f80:	50045000 	.word	0x50045000

20020f84 <sd1_read>:
20020f84:	f04f 33ff 	mov.w	r3, #4294967295
20020f88:	4a04      	ldr	r2, [pc, #16]	@ (20020f9c <sd1_read+0x18>)
20020f8a:	eb03 2341 	add.w	r3, r3, r1, lsl #9
20020f8e:	6293      	str	r3, [r2, #40]	@ 0x28
20020f90:	4b03      	ldr	r3, [pc, #12]	@ (20020fa0 <sd1_read+0x1c>)
20020f92:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20020f96:	6253      	str	r3, [r2, #36]	@ 0x24
20020f98:	4770      	bx	lr
20020f9a:	bf00      	nop
20020f9c:	50045000 	.word	0x50045000
20020fa0:	01ff0301 	.word	0x01ff0301

20020fa4 <sd1_wait_read>:
20020fa4:	4b08      	ldr	r3, [pc, #32]	@ (20020fc8 <sd1_wait_read+0x24>)
20020fa6:	681a      	ldr	r2, [r3, #0]
20020fa8:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20020fac:	d0fb      	beq.n	20020fa6 <sd1_wait_read+0x2>
20020fae:	2220      	movs	r2, #32
20020fb0:	601a      	str	r2, [r3, #0]
20020fb2:	681a      	ldr	r2, [r3, #0]
20020fb4:	0612      	lsls	r2, r2, #24
20020fb6:	bf5f      	itttt	pl
20020fb8:	6818      	ldrpl	r0, [r3, #0]
20020fba:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
20020fbe:	0040      	lslpl	r0, r0, #1
20020fc0:	b2c0      	uxtbpl	r0, r0
20020fc2:	bf48      	it	mi
20020fc4:	2001      	movmi	r0, #1
20020fc6:	4770      	bx	lr
20020fc8:	50045000 	.word	0x50045000

20020fcc <sdio_emmc_init>:
20020fcc:	b530      	push	{r4, r5, lr}
20020fce:	b08d      	sub	sp, #52	@ 0x34
20020fd0:	f7ff ff54 	bl	20020e7c <sd1_init>
20020fd4:	4c6c      	ldr	r4, [pc, #432]	@ (20021188 <sdio_emmc_init+0x1bc>)
20020fd6:	4b6d      	ldr	r3, [pc, #436]	@ (2002118c <sdio_emmc_init+0x1c0>)
20020fd8:	2500      	movs	r5, #0
20020fda:	6323      	str	r3, [r4, #48]	@ 0x30
20020fdc:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20020fde:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20020fe2:	f043 0302 	orr.w	r3, r3, #2
20020fe6:	6323      	str	r3, [r4, #48]	@ 0x30
20020fe8:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20020fec:	62e5      	str	r5, [r4, #44]	@ 0x2c
20020fee:	6223      	str	r3, [r4, #32]
20020ff0:	f000 fc6d 	bl	200218ce <HAL_Delay_us>
20020ff4:	4629      	mov	r1, r5
20020ff6:	4628      	mov	r0, r5
20020ff8:	f7ff ff6c 	bl	20020ed4 <sd1_send_cmd>
20020ffc:	2301      	movs	r3, #1
20020ffe:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021000:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021002:	0799      	lsls	r1, r3, #30
20021004:	d5fc      	bpl.n	20021000 <sdio_emmc_init+0x34>
20021006:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021008:	f043 0320 	orr.w	r3, r3, #32
2002100c:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002100e:	4960      	ldr	r1, [pc, #384]	@ (20021190 <sdio_emmc_init+0x1c4>)
20021010:	2001      	movs	r0, #1
20021012:	ad07      	add	r5, sp, #28
20021014:	f7ff ff5e 	bl	20020ed4 <sd1_send_cmd>
20021018:	ab06      	add	r3, sp, #24
2002101a:	aa05      	add	r2, sp, #20
2002101c:	a904      	add	r1, sp, #16
2002101e:	f10d 000f 	add.w	r0, sp, #15
20021022:	9500      	str	r5, [sp, #0]
20021024:	f7ff ff9e 	bl	20020f64 <sd1_get_rsp>
20021028:	2014      	movs	r0, #20
2002102a:	f000 fc50 	bl	200218ce <HAL_Delay_us>
2002102e:	9b04      	ldr	r3, [sp, #16]
20021030:	2b00      	cmp	r3, #0
20021032:	daec      	bge.n	2002100e <sdio_emmc_init+0x42>
20021034:	4a57      	ldr	r2, [pc, #348]	@ (20021194 <sdio_emmc_init+0x1c8>)
20021036:	f3c3 7380 	ubfx	r3, r3, #30, #1
2002103a:	f083 0301 	eor.w	r3, r3, #1
2002103e:	2100      	movs	r1, #0
20021040:	2002      	movs	r0, #2
20021042:	7013      	strb	r3, [r2, #0]
20021044:	f7ff ff46 	bl	20020ed4 <sd1_send_cmd>
20021048:	2801      	cmp	r0, #1
2002104a:	f000 8081 	beq.w	20021150 <sdio_emmc_init+0x184>
2002104e:	2802      	cmp	r0, #2
20021050:	d07e      	beq.n	20021150 <sdio_emmc_init+0x184>
20021052:	ab08      	add	r3, sp, #32
20021054:	9300      	str	r3, [sp, #0]
20021056:	aa0a      	add	r2, sp, #40	@ 0x28
20021058:	ab09      	add	r3, sp, #36	@ 0x24
2002105a:	a90b      	add	r1, sp, #44	@ 0x2c
2002105c:	f10d 000f 	add.w	r0, sp, #15
20021060:	f7ff ff80 	bl	20020f64 <sd1_get_rsp>
20021064:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021068:	2003      	movs	r0, #3
2002106a:	f7ff ff33 	bl	20020ed4 <sd1_send_cmd>
2002106e:	2801      	cmp	r0, #1
20021070:	d070      	beq.n	20021154 <sdio_emmc_init+0x188>
20021072:	2802      	cmp	r0, #2
20021074:	d070      	beq.n	20021158 <sdio_emmc_init+0x18c>
20021076:	ab06      	add	r3, sp, #24
20021078:	9500      	str	r5, [sp, #0]
2002107a:	aa05      	add	r2, sp, #20
2002107c:	a904      	add	r1, sp, #16
2002107e:	f10d 000f 	add.w	r0, sp, #15
20021082:	f7ff ff6f 	bl	20020f64 <sd1_get_rsp>
20021086:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002108a:	2b03      	cmp	r3, #3
2002108c:	d166      	bne.n	2002115c <sdio_emmc_init+0x190>
2002108e:	4c3e      	ldr	r4, [pc, #248]	@ (20021188 <sdio_emmc_init+0x1bc>)
20021090:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
20021094:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
20021096:	2009      	movs	r0, #9
20021098:	f023 0320 	bic.w	r3, r3, #32
2002109c:	63e3      	str	r3, [r4, #60]	@ 0x3c
2002109e:	f7ff ff19 	bl	20020ed4 <sd1_send_cmd>
200210a2:	2801      	cmp	r0, #1
200210a4:	d05c      	beq.n	20021160 <sdio_emmc_init+0x194>
200210a6:	2802      	cmp	r0, #2
200210a8:	d05c      	beq.n	20021164 <sdio_emmc_init+0x198>
200210aa:	ab06      	add	r3, sp, #24
200210ac:	aa05      	add	r2, sp, #20
200210ae:	a904      	add	r1, sp, #16
200210b0:	f10d 000f 	add.w	r0, sp, #15
200210b4:	9500      	str	r5, [sp, #0]
200210b6:	f7ff ff55 	bl	20020f64 <sd1_get_rsp>
200210ba:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
200210be:	6323      	str	r3, [r4, #48]	@ 0x30
200210c0:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200210c2:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210c6:	f043 0302 	orr.w	r3, r3, #2
200210ca:	6323      	str	r3, [r4, #48]	@ 0x30
200210cc:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200210d0:	6223      	str	r3, [r4, #32]
200210d2:	2300      	movs	r3, #0
200210d4:	2007      	movs	r0, #7
200210d6:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210d8:	f7ff fefc 	bl	20020ed4 <sd1_send_cmd>
200210dc:	2801      	cmp	r0, #1
200210de:	d043      	beq.n	20021168 <sdio_emmc_init+0x19c>
200210e0:	2802      	cmp	r0, #2
200210e2:	d043      	beq.n	2002116c <sdio_emmc_init+0x1a0>
200210e4:	ab06      	add	r3, sp, #24
200210e6:	9500      	str	r5, [sp, #0]
200210e8:	aa05      	add	r2, sp, #20
200210ea:	a904      	add	r1, sp, #16
200210ec:	f10d 000f 	add.w	r0, sp, #15
200210f0:	f7ff ff38 	bl	20020f64 <sd1_get_rsp>
200210f4:	f89d 300f 	ldrb.w	r3, [sp, #15]
200210f8:	2b07      	cmp	r3, #7
200210fa:	d139      	bne.n	20021170 <sdio_emmc_init+0x1a4>
200210fc:	2101      	movs	r1, #1
200210fe:	2000      	movs	r0, #0
20021100:	f7ff ff40 	bl	20020f84 <sd1_read>
20021104:	f04f 33ff 	mov.w	r3, #4294967295
20021108:	2100      	movs	r1, #0
2002110a:	2011      	movs	r0, #17
2002110c:	6023      	str	r3, [r4, #0]
2002110e:	f7ff fee1 	bl	20020ed4 <sd1_send_cmd>
20021112:	2801      	cmp	r0, #1
20021114:	d02e      	beq.n	20021174 <sdio_emmc_init+0x1a8>
20021116:	2802      	cmp	r0, #2
20021118:	d02e      	beq.n	20021178 <sdio_emmc_init+0x1ac>
2002111a:	ab06      	add	r3, sp, #24
2002111c:	9500      	str	r5, [sp, #0]
2002111e:	aa05      	add	r2, sp, #20
20021120:	a904      	add	r1, sp, #16
20021122:	f10d 000f 	add.w	r0, sp, #15
20021126:	f7ff ff1d 	bl	20020f64 <sd1_get_rsp>
2002112a:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002112e:	2b11      	cmp	r3, #17
20021130:	d124      	bne.n	2002117c <sdio_emmc_init+0x1b0>
20021132:	2320      	movs	r3, #32
20021134:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021136:	f7ff ff35 	bl	20020fa4 <sd1_wait_read>
2002113a:	6823      	ldr	r3, [r4, #0]
2002113c:	061a      	lsls	r2, r3, #24
2002113e:	d41f      	bmi.n	20021180 <sdio_emmc_init+0x1b4>
20021140:	6823      	ldr	r3, [r4, #0]
20021142:	065b      	lsls	r3, r3, #25
20021144:	d41e      	bmi.n	20021184 <sdio_emmc_init+0x1b8>
20021146:	2080      	movs	r0, #128	@ 0x80
20021148:	3801      	subs	r0, #1
2002114a:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
2002114e:	d1fb      	bne.n	20021148 <sdio_emmc_init+0x17c>
20021150:	b00d      	add	sp, #52	@ 0x34
20021152:	bd30      	pop	{r4, r5, pc}
20021154:	2003      	movs	r0, #3
20021156:	e7fb      	b.n	20021150 <sdio_emmc_init+0x184>
20021158:	2004      	movs	r0, #4
2002115a:	e7f9      	b.n	20021150 <sdio_emmc_init+0x184>
2002115c:	2005      	movs	r0, #5
2002115e:	e7f7      	b.n	20021150 <sdio_emmc_init+0x184>
20021160:	2006      	movs	r0, #6
20021162:	e7f5      	b.n	20021150 <sdio_emmc_init+0x184>
20021164:	2007      	movs	r0, #7
20021166:	e7f3      	b.n	20021150 <sdio_emmc_init+0x184>
20021168:	2008      	movs	r0, #8
2002116a:	e7f1      	b.n	20021150 <sdio_emmc_init+0x184>
2002116c:	2009      	movs	r0, #9
2002116e:	e7ef      	b.n	20021150 <sdio_emmc_init+0x184>
20021170:	200a      	movs	r0, #10
20021172:	e7ed      	b.n	20021150 <sdio_emmc_init+0x184>
20021174:	2012      	movs	r0, #18
20021176:	e7eb      	b.n	20021150 <sdio_emmc_init+0x184>
20021178:	2013      	movs	r0, #19
2002117a:	e7e9      	b.n	20021150 <sdio_emmc_init+0x184>
2002117c:	2014      	movs	r0, #20
2002117e:	e7e7      	b.n	20021150 <sdio_emmc_init+0x184>
20021180:	2015      	movs	r0, #21
20021182:	e7e5      	b.n	20021150 <sdio_emmc_init+0x184>
20021184:	2016      	movs	r0, #22
20021186:	e7e3      	b.n	20021150 <sdio_emmc_init+0x184>
20021188:	50045000 	.word	0x50045000
2002118c:	00016700 	.word	0x00016700
20021190:	40000080 	.word	0x40000080
20021194:	20042c0c 	.word	0x20042c0c

20021198 <emmc_read_data>:
20021198:	b570      	push	{r4, r5, r6, lr}
2002119a:	4606      	mov	r6, r0
2002119c:	460d      	mov	r5, r1
2002119e:	2000      	movs	r0, #0
200211a0:	2101      	movs	r1, #1
200211a2:	b088      	sub	sp, #32
200211a4:	4614      	mov	r4, r2
200211a6:	f7ff feed 	bl	20020f84 <sd1_read>
200211aa:	f04f 32ff 	mov.w	r2, #4294967295
200211ae:	4b1c      	ldr	r3, [pc, #112]	@ (20021220 <emmc_read_data+0x88>)
200211b0:	601a      	str	r2, [r3, #0]
200211b2:	4b1c      	ldr	r3, [pc, #112]	@ (20021224 <emmc_read_data+0x8c>)
200211b4:	781b      	ldrb	r3, [r3, #0]
200211b6:	b903      	cbnz	r3, 200211ba <emmc_read_data+0x22>
200211b8:	0a76      	lsrs	r6, r6, #9
200211ba:	4631      	mov	r1, r6
200211bc:	2011      	movs	r0, #17
200211be:	f7ff fe89 	bl	20020ed4 <sd1_send_cmd>
200211c2:	3801      	subs	r0, #1
200211c4:	b2c0      	uxtb	r0, r0
200211c6:	2801      	cmp	r0, #1
200211c8:	d802      	bhi.n	200211d0 <emmc_read_data+0x38>
200211ca:	2000      	movs	r0, #0
200211cc:	b008      	add	sp, #32
200211ce:	bd70      	pop	{r4, r5, r6, pc}
200211d0:	ab07      	add	r3, sp, #28
200211d2:	9300      	str	r3, [sp, #0]
200211d4:	aa05      	add	r2, sp, #20
200211d6:	ab06      	add	r3, sp, #24
200211d8:	a904      	add	r1, sp, #16
200211da:	f10d 000f 	add.w	r0, sp, #15
200211de:	f7ff fec1 	bl	20020f64 <sd1_get_rsp>
200211e2:	f89d 300f 	ldrb.w	r3, [sp, #15]
200211e6:	2b11      	cmp	r3, #17
200211e8:	d1ef      	bne.n	200211ca <emmc_read_data+0x32>
200211ea:	f04f 33ff 	mov.w	r3, #4294967295
200211ee:	4e0c      	ldr	r6, [pc, #48]	@ (20021220 <emmc_read_data+0x88>)
200211f0:	6033      	str	r3, [r6, #0]
200211f2:	2320      	movs	r3, #32
200211f4:	62f3      	str	r3, [r6, #44]	@ 0x2c
200211f6:	f7ff fed5 	bl	20020fa4 <sd1_wait_read>
200211fa:	6833      	ldr	r3, [r6, #0]
200211fc:	061a      	lsls	r2, r3, #24
200211fe:	d4e4      	bmi.n	200211ca <emmc_read_data+0x32>
20021200:	6833      	ldr	r3, [r6, #0]
20021202:	065b      	lsls	r3, r3, #25
20021204:	d4e1      	bmi.n	200211ca <emmc_read_data+0x32>
20021206:	f024 0303 	bic.w	r3, r4, #3
2002120a:	442b      	add	r3, r5
2002120c:	429d      	cmp	r5, r3
2002120e:	d101      	bne.n	20021214 <emmc_read_data+0x7c>
20021210:	4620      	mov	r0, r4
20021212:	e7db      	b.n	200211cc <emmc_read_data+0x34>
20021214:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
20021218:	f845 2b04 	str.w	r2, [r5], #4
2002121c:	e7f6      	b.n	2002120c <emmc_read_data+0x74>
2002121e:	bf00      	nop
20021220:	50045000 	.word	0x50045000
20021224:	20042c0c 	.word	0x20042c0c

20021228 <sdio_sd_init>:
20021228:	b5f0      	push	{r4, r5, r6, r7, lr}
2002122a:	b08d      	sub	sp, #52	@ 0x34
2002122c:	f7ff fe26 	bl	20020e7c <sd1_init>
20021230:	4c83      	ldr	r4, [pc, #524]	@ (20021440 <sdio_sd_init+0x218>)
20021232:	4b84      	ldr	r3, [pc, #528]	@ (20021444 <sdio_sd_init+0x21c>)
20021234:	2500      	movs	r5, #0
20021236:	6323      	str	r3, [r4, #48]	@ 0x30
20021238:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002123a:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
2002123e:	f043 0302 	orr.w	r3, r3, #2
20021242:	6323      	str	r3, [r4, #48]	@ 0x30
20021244:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20021248:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002124a:	6223      	str	r3, [r4, #32]
2002124c:	f000 fb3f 	bl	200218ce <HAL_Delay_us>
20021250:	4629      	mov	r1, r5
20021252:	4628      	mov	r0, r5
20021254:	f7ff fe3e 	bl	20020ed4 <sd1_send_cmd>
20021258:	2301      	movs	r3, #1
2002125a:	65e3      	str	r3, [r4, #92]	@ 0x5c
2002125c:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
2002125e:	079a      	lsls	r2, r3, #30
20021260:	d5fc      	bpl.n	2002125c <sdio_sd_init+0x34>
20021262:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
20021266:	2008      	movs	r0, #8
20021268:	f7ff fe34 	bl	20020ed4 <sd1_send_cmd>
2002126c:	3801      	subs	r0, #1
2002126e:	b2c0      	uxtb	r0, r0
20021270:	2801      	cmp	r0, #1
20021272:	d802      	bhi.n	2002127a <sdio_sd_init+0x52>
20021274:	2038      	movs	r0, #56	@ 0x38
20021276:	b00d      	add	sp, #52	@ 0x34
20021278:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002127a:	ac07      	add	r4, sp, #28
2002127c:	ab06      	add	r3, sp, #24
2002127e:	9400      	str	r4, [sp, #0]
20021280:	aa05      	add	r2, sp, #20
20021282:	a904      	add	r1, sp, #16
20021284:	f10d 000f 	add.w	r0, sp, #15
20021288:	f7ff fe6c 	bl	20020f64 <sd1_get_rsp>
2002128c:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021290:	2b08      	cmp	r3, #8
20021292:	d1ef      	bne.n	20021274 <sdio_sd_init+0x4c>
20021294:	9b04      	ldr	r3, [sp, #16]
20021296:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
2002129a:	d1eb      	bne.n	20021274 <sdio_sd_init+0x4c>
2002129c:	2200      	movs	r2, #0
2002129e:	2029      	movs	r0, #41	@ 0x29
200212a0:	4969      	ldr	r1, [pc, #420]	@ (20021448 <sdio_sd_init+0x220>)
200212a2:	f7ff fe41 	bl	20020f28 <sd1_send_acmd>
200212a6:	2801      	cmp	r0, #1
200212a8:	f000 80bd 	beq.w	20021426 <sdio_sd_init+0x1fe>
200212ac:	ab06      	add	r3, sp, #24
200212ae:	9400      	str	r4, [sp, #0]
200212b0:	aa05      	add	r2, sp, #20
200212b2:	a904      	add	r1, sp, #16
200212b4:	f10d 000f 	add.w	r0, sp, #15
200212b8:	f7ff fe54 	bl	20020f64 <sd1_get_rsp>
200212bc:	9b04      	ldr	r3, [sp, #16]
200212be:	2b00      	cmp	r3, #0
200212c0:	db03      	blt.n	200212ca <sdio_sd_init+0xa2>
200212c2:	2002      	movs	r0, #2
200212c4:	f000 fb03 	bl	200218ce <HAL_Delay_us>
200212c8:	e7e8      	b.n	2002129c <sdio_sd_init+0x74>
200212ca:	2100      	movs	r1, #0
200212cc:	2002      	movs	r0, #2
200212ce:	f7ff fe01 	bl	20020ed4 <sd1_send_cmd>
200212d2:	3801      	subs	r0, #1
200212d4:	b2c0      	uxtb	r0, r0
200212d6:	2801      	cmp	r0, #1
200212d8:	f240 80a7 	bls.w	2002142a <sdio_sd_init+0x202>
200212dc:	ab08      	add	r3, sp, #32
200212de:	9300      	str	r3, [sp, #0]
200212e0:	aa0a      	add	r2, sp, #40	@ 0x28
200212e2:	ab09      	add	r3, sp, #36	@ 0x24
200212e4:	a90b      	add	r1, sp, #44	@ 0x2c
200212e6:	f10d 000f 	add.w	r0, sp, #15
200212ea:	f7ff fe3b 	bl	20020f64 <sd1_get_rsp>
200212ee:	2100      	movs	r1, #0
200212f0:	2003      	movs	r0, #3
200212f2:	f7ff fdef 	bl	20020ed4 <sd1_send_cmd>
200212f6:	3801      	subs	r0, #1
200212f8:	b2c0      	uxtb	r0, r0
200212fa:	2801      	cmp	r0, #1
200212fc:	d801      	bhi.n	20021302 <sdio_sd_init+0xda>
200212fe:	2033      	movs	r0, #51	@ 0x33
20021300:	e7b9      	b.n	20021276 <sdio_sd_init+0x4e>
20021302:	ab06      	add	r3, sp, #24
20021304:	9400      	str	r4, [sp, #0]
20021306:	aa05      	add	r2, sp, #20
20021308:	a904      	add	r1, sp, #16
2002130a:	f10d 000f 	add.w	r0, sp, #15
2002130e:	f7ff fe29 	bl	20020f64 <sd1_get_rsp>
20021312:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021316:	2b03      	cmp	r3, #3
20021318:	d1f1      	bne.n	200212fe <sdio_sd_init+0xd6>
2002131a:	9f04      	ldr	r7, [sp, #16]
2002131c:	2009      	movs	r0, #9
2002131e:	0c3d      	lsrs	r5, r7, #16
20021320:	042d      	lsls	r5, r5, #16
20021322:	4629      	mov	r1, r5
20021324:	f7ff fdd6 	bl	20020ed4 <sd1_send_cmd>
20021328:	3801      	subs	r0, #1
2002132a:	b2c0      	uxtb	r0, r0
2002132c:	2801      	cmp	r0, #1
2002132e:	d97e      	bls.n	2002142e <sdio_sd_init+0x206>
20021330:	9400      	str	r4, [sp, #0]
20021332:	ab06      	add	r3, sp, #24
20021334:	aa05      	add	r2, sp, #20
20021336:	a904      	add	r1, sp, #16
20021338:	f10d 000f 	add.w	r0, sp, #15
2002133c:	f7ff fe12 	bl	20020f64 <sd1_get_rsp>
20021340:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021344:	9c06      	ldr	r4, [sp, #24]
20021346:	9907      	ldr	r1, [sp, #28]
20021348:	0e23      	lsrs	r3, r4, #24
2002134a:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
2002134e:	0e01      	lsrs	r1, r0, #24
20021350:	ea41 2104 	orr.w	r1, r1, r4, lsl #8
20021354:	9105      	str	r1, [sp, #20]
20021356:	0e11      	lsrs	r1, r2, #24
20021358:	9304      	str	r3, [sp, #16]
2002135a:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
2002135e:	0212      	lsls	r2, r2, #8
20021360:	0f9b      	lsrs	r3, r3, #30
20021362:	9106      	str	r1, [sp, #24]
20021364:	9207      	str	r2, [sp, #28]
20021366:	d01b      	beq.n	200213a0 <sdio_sd_init+0x178>
20021368:	2b01      	cmp	r3, #1
2002136a:	d162      	bne.n	20021432 <sdio_sd_init+0x20a>
2002136c:	2300      	movs	r3, #0
2002136e:	4a37      	ldr	r2, [pc, #220]	@ (2002144c <sdio_sd_init+0x224>)
20021370:	4c33      	ldr	r4, [pc, #204]	@ (20021440 <sdio_sd_init+0x218>)
20021372:	7013      	strb	r3, [r2, #0]
20021374:	f44f 63a0 	mov.w	r3, #1280	@ 0x500
20021378:	6323      	str	r3, [r4, #48]	@ 0x30
2002137a:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002137c:	2600      	movs	r6, #0
2002137e:	f043 0302 	orr.w	r3, r3, #2
20021382:	6323      	str	r3, [r4, #48]	@ 0x30
20021384:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
20021388:	4629      	mov	r1, r5
2002138a:	6223      	str	r3, [r4, #32]
2002138c:	2007      	movs	r0, #7
2002138e:	63e6      	str	r6, [r4, #60]	@ 0x3c
20021390:	f7ff fda0 	bl	20020ed4 <sd1_send_cmd>
20021394:	3801      	subs	r0, #1
20021396:	b2c0      	uxtb	r0, r0
20021398:	2801      	cmp	r0, #1
2002139a:	d803      	bhi.n	200213a4 <sdio_sd_init+0x17c>
2002139c:	2037      	movs	r0, #55	@ 0x37
2002139e:	e76a      	b.n	20021276 <sdio_sd_init+0x4e>
200213a0:	2301      	movs	r3, #1
200213a2:	e7e4      	b.n	2002136e <sdio_sd_init+0x146>
200213a4:	ad07      	add	r5, sp, #28
200213a6:	ab06      	add	r3, sp, #24
200213a8:	9500      	str	r5, [sp, #0]
200213aa:	aa05      	add	r2, sp, #20
200213ac:	a904      	add	r1, sp, #16
200213ae:	f10d 000f 	add.w	r0, sp, #15
200213b2:	f7ff fdd7 	bl	20020f64 <sd1_get_rsp>
200213b6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200213ba:	2b07      	cmp	r3, #7
200213bc:	d1ee      	bne.n	2002139c <sdio_sd_init+0x174>
200213be:	4631      	mov	r1, r6
200213c0:	2006      	movs	r0, #6
200213c2:	0c3a      	lsrs	r2, r7, #16
200213c4:	f7ff fdb0 	bl	20020f28 <sd1_send_acmd>
200213c8:	3801      	subs	r0, #1
200213ca:	b2c0      	uxtb	r0, r0
200213cc:	2801      	cmp	r0, #1
200213ce:	d932      	bls.n	20021436 <sdio_sd_init+0x20e>
200213d0:	2101      	movs	r1, #1
200213d2:	4630      	mov	r0, r6
200213d4:	f7ff fdd6 	bl	20020f84 <sd1_read>
200213d8:	4631      	mov	r1, r6
200213da:	2011      	movs	r0, #17
200213dc:	f7ff fd7a 	bl	20020ed4 <sd1_send_cmd>
200213e0:	3801      	subs	r0, #1
200213e2:	b2c0      	uxtb	r0, r0
200213e4:	2801      	cmp	r0, #1
200213e6:	d801      	bhi.n	200213ec <sdio_sd_init+0x1c4>
200213e8:	2052      	movs	r0, #82	@ 0x52
200213ea:	e744      	b.n	20021276 <sdio_sd_init+0x4e>
200213ec:	ab06      	add	r3, sp, #24
200213ee:	9500      	str	r5, [sp, #0]
200213f0:	aa05      	add	r2, sp, #20
200213f2:	a904      	add	r1, sp, #16
200213f4:	f10d 000f 	add.w	r0, sp, #15
200213f8:	f7ff fdb4 	bl	20020f64 <sd1_get_rsp>
200213fc:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021400:	2b11      	cmp	r3, #17
20021402:	d1f1      	bne.n	200213e8 <sdio_sd_init+0x1c0>
20021404:	f04f 33ff 	mov.w	r3, #4294967295
20021408:	6023      	str	r3, [r4, #0]
2002140a:	2320      	movs	r3, #32
2002140c:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002140e:	f7ff fdc9 	bl	20020fa4 <sd1_wait_read>
20021412:	6823      	ldr	r3, [r4, #0]
20021414:	061b      	lsls	r3, r3, #24
20021416:	d410      	bmi.n	2002143a <sdio_sd_init+0x212>
20021418:	6823      	ldr	r3, [r4, #0]
2002141a:	f013 0f40 	tst.w	r3, #64	@ 0x40
2002141e:	bf14      	ite	ne
20021420:	2044      	movne	r0, #68	@ 0x44
20021422:	2001      	moveq	r0, #1
20021424:	e727      	b.n	20021276 <sdio_sd_init+0x4e>
20021426:	2034      	movs	r0, #52	@ 0x34
20021428:	e725      	b.n	20021276 <sdio_sd_init+0x4e>
2002142a:	2032      	movs	r0, #50	@ 0x32
2002142c:	e723      	b.n	20021276 <sdio_sd_init+0x4e>
2002142e:	2039      	movs	r0, #57	@ 0x39
20021430:	e721      	b.n	20021276 <sdio_sd_init+0x4e>
20021432:	2054      	movs	r0, #84	@ 0x54
20021434:	e71f      	b.n	20021276 <sdio_sd_init+0x4e>
20021436:	2036      	movs	r0, #54	@ 0x36
20021438:	e71d      	b.n	20021276 <sdio_sd_init+0x4e>
2002143a:	204f      	movs	r0, #79	@ 0x4f
2002143c:	e71b      	b.n	20021276 <sdio_sd_init+0x4e>
2002143e:	bf00      	nop
20021440:	50045000 	.word	0x50045000
20021444:	00016700 	.word	0x00016700
20021448:	40ff8000 	.word	0x40ff8000
2002144c:	20042c0d 	.word	0x20042c0d

20021450 <sd_read_data>:
20021450:	b570      	push	{r4, r5, r6, lr}
20021452:	4606      	mov	r6, r0
20021454:	460d      	mov	r5, r1
20021456:	2000      	movs	r0, #0
20021458:	2101      	movs	r1, #1
2002145a:	b088      	sub	sp, #32
2002145c:	4614      	mov	r4, r2
2002145e:	f7ff fd91 	bl	20020f84 <sd1_read>
20021462:	4b1b      	ldr	r3, [pc, #108]	@ (200214d0 <sd_read_data+0x80>)
20021464:	781b      	ldrb	r3, [r3, #0]
20021466:	b903      	cbnz	r3, 2002146a <sd_read_data+0x1a>
20021468:	0a76      	lsrs	r6, r6, #9
2002146a:	4631      	mov	r1, r6
2002146c:	2011      	movs	r0, #17
2002146e:	f7ff fd31 	bl	20020ed4 <sd1_send_cmd>
20021472:	3801      	subs	r0, #1
20021474:	b2c0      	uxtb	r0, r0
20021476:	2801      	cmp	r0, #1
20021478:	d802      	bhi.n	20021480 <sd_read_data+0x30>
2002147a:	2000      	movs	r0, #0
2002147c:	b008      	add	sp, #32
2002147e:	bd70      	pop	{r4, r5, r6, pc}
20021480:	ab07      	add	r3, sp, #28
20021482:	9300      	str	r3, [sp, #0]
20021484:	aa05      	add	r2, sp, #20
20021486:	ab06      	add	r3, sp, #24
20021488:	a904      	add	r1, sp, #16
2002148a:	f10d 000f 	add.w	r0, sp, #15
2002148e:	f7ff fd69 	bl	20020f64 <sd1_get_rsp>
20021492:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021496:	2b11      	cmp	r3, #17
20021498:	d1ef      	bne.n	2002147a <sd_read_data+0x2a>
2002149a:	f04f 33ff 	mov.w	r3, #4294967295
2002149e:	4e0d      	ldr	r6, [pc, #52]	@ (200214d4 <sd_read_data+0x84>)
200214a0:	6033      	str	r3, [r6, #0]
200214a2:	2320      	movs	r3, #32
200214a4:	62f3      	str	r3, [r6, #44]	@ 0x2c
200214a6:	f7ff fd7d 	bl	20020fa4 <sd1_wait_read>
200214aa:	6833      	ldr	r3, [r6, #0]
200214ac:	061a      	lsls	r2, r3, #24
200214ae:	d4e4      	bmi.n	2002147a <sd_read_data+0x2a>
200214b0:	6833      	ldr	r3, [r6, #0]
200214b2:	065b      	lsls	r3, r3, #25
200214b4:	d4e1      	bmi.n	2002147a <sd_read_data+0x2a>
200214b6:	f024 0303 	bic.w	r3, r4, #3
200214ba:	442b      	add	r3, r5
200214bc:	429d      	cmp	r5, r3
200214be:	d101      	bne.n	200214c4 <sd_read_data+0x74>
200214c0:	4620      	mov	r0, r4
200214c2:	e7db      	b.n	2002147c <sd_read_data+0x2c>
200214c4:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
200214c8:	f845 2b04 	str.w	r2, [r5], #4
200214cc:	e7f6      	b.n	200214bc <sd_read_data+0x6c>
200214ce:	bf00      	nop
200214d0:	20042c0d 	.word	0x20042c0d
200214d4:	50045000 	.word	0x50045000

200214d8 <is_addr_in_nor>:
200214d8:	4b09      	ldr	r3, [pc, #36]	@ (20021500 <is_addr_in_nor+0x28>)
200214da:	4602      	mov	r2, r0
200214dc:	681b      	ldr	r3, [r3, #0]
200214de:	b163      	cbz	r3, 200214fa <is_addr_in_nor+0x22>
200214e0:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
200214e4:	b948      	cbnz	r0, 200214fa <is_addr_in_nor+0x22>
200214e6:	6919      	ldr	r1, [r3, #16]
200214e8:	4291      	cmp	r1, r2
200214ea:	d807      	bhi.n	200214fc <is_addr_in_nor+0x24>
200214ec:	695b      	ldr	r3, [r3, #20]
200214ee:	4419      	add	r1, r3
200214f0:	4291      	cmp	r1, r2
200214f2:	bf94      	ite	ls
200214f4:	2000      	movls	r0, #0
200214f6:	2001      	movhi	r0, #1
200214f8:	4770      	bx	lr
200214fa:	2000      	movs	r0, #0
200214fc:	4770      	bx	lr
200214fe:	bf00      	nop
20021500:	20046d30 	.word	0x20046d30

20021504 <sifli_verify_img_cmac_hash>:
20021504:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20021508:	461d      	mov	r5, r3
2002150a:	4b16      	ldr	r3, [pc, #88]	@ (20021564 <sifli_verify_img_cmac_hash+0x60>)
2002150c:	460e      	mov	r6, r1
2002150e:	681b      	ldr	r3, [r3, #0]
20021510:	4617      	mov	r7, r2
20021512:	b092      	sub	sp, #72	@ 0x48
20021514:	b12b      	cbz	r3, 20021522 <sifli_verify_img_cmac_hash+0x1e>
20021516:	b920      	cbnz	r0, 20021522 <sifli_verify_img_cmac_hash+0x1e>
20021518:	2220      	movs	r2, #32
2002151a:	2002      	movs	r0, #2
2002151c:	4912      	ldr	r1, [pc, #72]	@ (20021568 <sifli_verify_img_cmac_hash+0x64>)
2002151e:	4798      	blx	r3
20021520:	4811      	ldr	r0, [pc, #68]	@ (20021568 <sifli_verify_img_cmac_hash+0x64>)
20021522:	4601      	mov	r1, r0
20021524:	2220      	movs	r2, #32
20021526:	a803      	add	r0, sp, #12
20021528:	f003 fc3c 	bl	20024da4 <sf_crypto_aes_cmac_init>
2002152c:	4604      	mov	r4, r0
2002152e:	b100      	cbz	r0, 20021532 <sifli_verify_img_cmac_hash+0x2e>
20021530:	e7fe      	b.n	20021530 <sifli_verify_img_cmac_hash+0x2c>
20021532:	f8df 8038 	ldr.w	r8, [pc, #56]	@ 2002156c <sifli_verify_img_cmac_hash+0x68>
20021536:	2301      	movs	r3, #1
20021538:	463a      	mov	r2, r7
2002153a:	4631      	mov	r1, r6
2002153c:	f8cd 8000 	str.w	r8, [sp]
20021540:	a803      	add	r0, sp, #12
20021542:	f003 fc6c 	bl	20024e1e <sf_crypto_aes_cmac_calc>
20021546:	b950      	cbnz	r0, 2002155e <sifli_verify_img_cmac_hash+0x5a>
20021548:	2210      	movs	r2, #16
2002154a:	4629      	mov	r1, r5
2002154c:	4640      	mov	r0, r8
2002154e:	f004 f88f 	bl	20025670 <memcmp>
20021552:	fab0 f080 	clz	r0, r0
20021556:	0940      	lsrs	r0, r0, #5
20021558:	b012      	add	sp, #72	@ 0x48
2002155a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002155e:	4620      	mov	r0, r4
20021560:	e7fa      	b.n	20021558 <sifli_verify_img_cmac_hash+0x54>
20021562:	bf00      	nop
20021564:	20047134 	.word	0x20047134
20021568:	2004c960 	.word	0x2004c960
2002156c:	2004c980 	.word	0x2004c980

20021570 <sboot_init>:
20021570:	b507      	push	{r0, r1, r2, lr}
20021572:	f7ff fb7d 	bl	20020c70 <sifli_hw_efuse_load_bank0>
20021576:	b150      	cbz	r0, 2002158e <sboot_init+0x1e>
20021578:	2302      	movs	r3, #2
2002157a:	21ee      	movs	r1, #238	@ 0xee
2002157c:	f10d 0207 	add.w	r2, sp, #7
20021580:	f005 f97e 	bl	20026880 <HAL_EFUSE_Extract>
20021584:	2800      	cmp	r0, #0
20021586:	dc08      	bgt.n	2002159a <sboot_init+0x2a>
20021588:	b003      	add	sp, #12
2002158a:	f85d fb04 	ldr.w	pc, [sp], #4
2002158e:	4807      	ldr	r0, [pc, #28]	@ (200215ac <sboot_init+0x3c>)
20021590:	b003      	add	sp, #12
20021592:	f85d eb04 	ldr.w	lr, [sp], #4
20021596:	f003 bf8d 	b.w	200254b4 <puts>
2002159a:	f89d 3007 	ldrb.w	r3, [sp, #7]
2002159e:	2b00      	cmp	r3, #0
200215a0:	d0f2      	beq.n	20021588 <sboot_init+0x18>
200215a2:	2201      	movs	r2, #1
200215a4:	4b02      	ldr	r3, [pc, #8]	@ (200215b0 <sboot_init+0x40>)
200215a6:	701a      	strb	r2, [r3, #0]
200215a8:	e7ee      	b.n	20021588 <sboot_init+0x18>
200215aa:	bf00      	nop
200215ac:	20025f40 	.word	0x20025f40
200215b0:	2004c95c 	.word	0x2004c95c

200215b4 <run_img>:
200215b4:	f8d0 d000 	ldr.w	sp, [r0]
200215b8:	f8d0 f004 	ldr.w	pc, [r0, #4]
200215bc:	4770      	bx	lr
	...

200215c0 <dfu_boot_img_in_flash>:
200215c0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200215c4:	4e27      	ldr	r6, [pc, #156]	@ (20021664 <dfu_boot_img_in_flash+0xa4>)
200215c6:	1e84      	subs	r4, r0, #2
200215c8:	eb06 1300 	add.w	r3, r6, r0, lsl #4
200215cc:	eb06 2040 	add.w	r0, r6, r0, lsl #9
200215d0:	f8d0 7c00 	ldr.w	r7, [r0, #3072]	@ 0xc00
200215d4:	f8d3 8004 	ldr.w	r8, [r3, #4]
200215d8:	68dd      	ldr	r5, [r3, #12]
200215da:	b177      	cbz	r7, 200215fa <dfu_boot_img_in_flash+0x3a>
200215dc:	45a8      	cmp	r8, r5
200215de:	d00c      	beq.n	200215fa <dfu_boot_img_in_flash+0x3a>
200215e0:	4628      	mov	r0, r5
200215e2:	f7ff ff79 	bl	200214d8 <is_addr_in_nor>
200215e6:	b940      	cbnz	r0, 200215fa <dfu_boot_img_in_flash+0x3a>
200215e8:	4b1f      	ldr	r3, [pc, #124]	@ (20021668 <dfu_boot_img_in_flash+0xa8>)
200215ea:	4629      	mov	r1, r5
200215ec:	781a      	ldrb	r2, [r3, #0]
200215ee:	4b1f      	ldr	r3, [pc, #124]	@ (2002166c <dfu_boot_img_in_flash+0xac>)
200215f0:	4640      	mov	r0, r8
200215f2:	681b      	ldr	r3, [r3, #0]
200215f4:	eb07 1202 	add.w	r2, r7, r2, lsl #4
200215f8:	4798      	blx	r3
200215fa:	2c07      	cmp	r4, #7
200215fc:	dc30      	bgt.n	20021660 <dfu_boot_img_in_flash+0xa0>
200215fe:	4263      	negs	r3, r4
20021600:	f003 0303 	and.w	r3, r3, #3
20021604:	f004 0703 	and.w	r7, r4, #3
20021608:	bf58      	it	pl
2002160a:	425f      	negpl	r7, r3
2002160c:	2f02      	cmp	r7, #2
2002160e:	d827      	bhi.n	20021660 <dfu_boot_img_in_flash+0xa0>
20021610:	4628      	mov	r0, r5
20021612:	f7ff ff61 	bl	200214d8 <is_addr_in_nor>
20021616:	b150      	cbz	r0, 2002162e <dfu_boot_img_in_flash+0x6e>
20021618:	4815      	ldr	r0, [pc, #84]	@ (20021670 <dfu_boot_img_in_flash+0xb0>)
2002161a:	f104 0208 	add.w	r2, r4, #8
2002161e:	0252      	lsls	r2, r2, #9
20021620:	4629      	mov	r1, r5
20021622:	58b2      	ldr	r2, [r6, r2]
20021624:	6800      	ldr	r0, [r0, #0]
20021626:	eba8 0305 	sub.w	r3, r8, r5
2002162a:	f001 fbb4 	bl	20022d96 <HAL_FLASH_ALIAS_CFG>
2002162e:	4b0e      	ldr	r3, [pc, #56]	@ (20021668 <dfu_boot_img_in_flash+0xa8>)
20021630:	781b      	ldrb	r3, [r3, #0]
20021632:	b923      	cbnz	r3, 2002163e <dfu_boot_img_in_flash+0x7e>
20021634:	4628      	mov	r0, r5
20021636:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002163a:	f7ff bfbb 	b.w	200215b4 <run_img>
2002163e:	2f01      	cmp	r7, #1
20021640:	d1f8      	bne.n	20021634 <dfu_boot_img_in_flash+0x74>
20021642:	3408      	adds	r4, #8
20021644:	0264      	lsls	r4, r4, #9
20021646:	5932      	ldr	r2, [r6, r4]
20021648:	4629      	mov	r1, r5
2002164a:	2000      	movs	r0, #0
2002164c:	1953      	adds	r3, r2, r5
2002164e:	f7ff ff59 	bl	20021504 <sifli_verify_img_cmac_hash>
20021652:	2800      	cmp	r0, #0
20021654:	d1ee      	bne.n	20021634 <dfu_boot_img_in_flash+0x74>
20021656:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002165a:	4806      	ldr	r0, [pc, #24]	@ (20021674 <dfu_boot_img_in_flash+0xb4>)
2002165c:	f003 bf2a 	b.w	200254b4 <puts>
20021660:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021664:	20047138 	.word	0x20047138
20021668:	2004c95c 	.word	0x2004c95c
2002166c:	20046d3c 	.word	0x20046d3c
20021670:	20046d30 	.word	0x20046d30
20021674:	20025f51 	.word	0x20025f51

20021678 <_close>:
20021678:	f04f 30ff 	mov.w	r0, #4294967295
2002167c:	4770      	bx	lr

2002167e <_lseek>:
2002167e:	f04f 30ff 	mov.w	r0, #4294967295
20021682:	4770      	bx	lr

20021684 <_read>:
20021684:	2000      	movs	r0, #0
20021686:	4770      	bx	lr

20021688 <_fstat>:
20021688:	2000      	movs	r0, #0
2002168a:	4770      	bx	lr

2002168c <_isatty>:
2002168c:	2001      	movs	r0, #1
2002168e:	4770      	bx	lr

20021690 <BSP_GetFlash1DIV>:
20021690:	4b01      	ldr	r3, [pc, #4]	@ (20021698 <BSP_GetFlash1DIV+0x8>)
20021692:	8818      	ldrh	r0, [r3, #0]
20021694:	4770      	bx	lr
20021696:	bf00      	nop
20021698:	20042c12 	.word	0x20042c12

2002169c <BSP_GetFlash2DIV>:
2002169c:	4b01      	ldr	r3, [pc, #4]	@ (200216a4 <BSP_GetFlash2DIV+0x8>)
2002169e:	8818      	ldrh	r0, [r3, #0]
200216a0:	4770      	bx	lr
200216a2:	bf00      	nop
200216a4:	20042c10 	.word	0x20042c10

200216a8 <BSP_GetFlash3DIV>:
200216a8:	4b01      	ldr	r3, [pc, #4]	@ (200216b0 <BSP_GetFlash3DIV+0x8>)
200216aa:	8818      	ldrh	r0, [r3, #0]
200216ac:	4770      	bx	lr
200216ae:	bf00      	nop
200216b0:	20042c0e 	.word	0x20042c0e

200216b4 <BSP_SetFlash1DIV>:
200216b4:	4b01      	ldr	r3, [pc, #4]	@ (200216bc <BSP_SetFlash1DIV+0x8>)
200216b6:	8018      	strh	r0, [r3, #0]
200216b8:	4770      	bx	lr
200216ba:	bf00      	nop
200216bc:	20042c12 	.word	0x20042c12

200216c0 <BSP_SetFlash2DIV>:
200216c0:	4b01      	ldr	r3, [pc, #4]	@ (200216c8 <BSP_SetFlash2DIV+0x8>)
200216c2:	8018      	strh	r0, [r3, #0]
200216c4:	4770      	bx	lr
200216c6:	bf00      	nop
200216c8:	20042c10 	.word	0x20042c10

200216cc <BSP_SetFlash3DIV>:
200216cc:	4b01      	ldr	r3, [pc, #4]	@ (200216d4 <BSP_SetFlash3DIV+0x8>)
200216ce:	8018      	strh	r0, [r3, #0]
200216d0:	4770      	bx	lr
200216d2:	bf00      	nop
200216d4:	20042c0e 	.word	0x20042c0e

200216d8 <BSP_GetOtpBase>:
200216d8:	4800      	ldr	r0, [pc, #0]	@ (200216dc <BSP_GetOtpBase+0x4>)
200216da:	4770      	bx	lr
200216dc:	1200e000 	.word	0x1200e000

200216e0 <pmu_ldo_inc>:
200216e0:	2000      	movs	r0, #0
200216e2:	4770      	bx	lr

200216e4 <pmu_ldo_recover>:
200216e4:	2000      	movs	r0, #0
200216e6:	4770      	bx	lr

200216e8 <hw_preinit0>:
200216e8:	4770      	bx	lr
	...

200216ec <cache_disable>:
200216ec:	b570      	push	{r4, r5, r6, lr}
200216ee:	f3bf 8f4f 	dsb	sy
200216f2:	f3bf 8f6f 	isb	sy
200216f6:	4a18      	ldr	r2, [pc, #96]	@ (20021758 <cache_disable+0x6c>)
200216f8:	6953      	ldr	r3, [r2, #20]
200216fa:	f423 3300 	bic.w	r3, r3, #131072	@ 0x20000
200216fe:	6153      	str	r3, [r2, #20]
20021700:	2300      	movs	r3, #0
20021702:	f8c2 3250 	str.w	r3, [r2, #592]	@ 0x250
20021706:	f3bf 8f4f 	dsb	sy
2002170a:	f3bf 8f6f 	isb	sy
2002170e:	f8c2 3084 	str.w	r3, [r2, #132]	@ 0x84
20021712:	f3bf 8f4f 	dsb	sy
20021716:	6953      	ldr	r3, [r2, #20]
20021718:	f423 3380 	bic.w	r3, r3, #65536	@ 0x10000
2002171c:	6153      	str	r3, [r2, #20]
2002171e:	f3bf 8f4f 	dsb	sy
20021722:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
20021726:	f8d2 3080 	ldr.w	r3, [r2, #128]	@ 0x80
2002172a:	f3c3 00c9 	ubfx	r0, r3, #3, #10
2002172e:	f3c3 334e 	ubfx	r3, r3, #13, #15
20021732:	015b      	lsls	r3, r3, #5
20021734:	4601      	mov	r1, r0
20021736:	ea03 0604 	and.w	r6, r3, r4
2002173a:	ea46 7581 	orr.w	r5, r6, r1, lsl #30
2002173e:	3901      	subs	r1, #1
20021740:	f8c2 5274 	str.w	r5, [r2, #628]	@ 0x274
20021744:	d2f9      	bcs.n	2002173a <cache_disable+0x4e>
20021746:	3b20      	subs	r3, #32
20021748:	f113 0f20 	cmn.w	r3, #32
2002174c:	d1f2      	bne.n	20021734 <cache_disable+0x48>
2002174e:	f3bf 8f4f 	dsb	sy
20021752:	f3bf 8f6f 	isb	sy
20021756:	bd70      	pop	{r4, r5, r6, pc}
20021758:	e000ed00 	.word	0xe000ed00

2002175c <SystemPowerOnModeInit>:
2002175c:	4770      	bx	lr
	...

20021760 <SystemInit>:
20021760:	b508      	push	{r3, lr}
20021762:	4a0e      	ldr	r2, [pc, #56]	@ (2002179c <SystemInit+0x3c>)
20021764:	4b0e      	ldr	r3, [pc, #56]	@ (200217a0 <SystemInit+0x40>)
20021766:	609a      	str	r2, [r3, #8]
20021768:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
2002176c:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021770:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021774:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021778:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
2002177c:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021780:	f7ff ffb2 	bl	200216e8 <hw_preinit0>
20021784:	f7ff ffb2 	bl	200216ec <cache_disable>
20021788:	f7fe fd90 	bl	200202ac <mpu_config>
2002178c:	f7fe fd8f 	bl	200202ae <cache_enable>
20021790:	f7ff ffe4 	bl	2002175c <SystemPowerOnModeInit>
20021794:	4b03      	ldr	r3, [pc, #12]	@ (200217a4 <SystemInit+0x44>)
20021796:	4a04      	ldr	r2, [pc, #16]	@ (200217a8 <SystemInit+0x48>)
20021798:	601a      	str	r2, [r3, #0]
2002179a:	bd08      	pop	{r3, pc}
2002179c:	20020000 	.word	0x20020000
200217a0:	e000ed00 	.word	0xe000ed00
200217a4:	20042c14 	.word	0x20042c14
200217a8:	017d7840 	.word	0x017d7840

200217ac <Reset_Handler>:
200217ac:	f8df d048 	ldr.w	sp, [pc, #72]	@ 200217f8 <ACPU2HCPU_IRQHandler+0x2>
200217b0:	4812      	ldr	r0, [pc, #72]	@ (200217fc <ACPU2HCPU_IRQHandler+0x6>)
200217b2:	f380 880a 	msr	MSPLIM, r0
200217b6:	f7ff ffd3 	bl	20021760 <SystemInit>
200217ba:	4c11      	ldr	r4, [pc, #68]	@ (20021800 <ACPU2HCPU_IRQHandler+0xa>)
200217bc:	4d11      	ldr	r5, [pc, #68]	@ (20021804 <ACPU2HCPU_IRQHandler+0xe>)
200217be:	42ac      	cmp	r4, r5
200217c0:	da09      	bge.n	200217d6 <Reset_Handler+0x2a>
200217c2:	6821      	ldr	r1, [r4, #0]
200217c4:	6862      	ldr	r2, [r4, #4]
200217c6:	68a3      	ldr	r3, [r4, #8]
200217c8:	3b04      	subs	r3, #4
200217ca:	bfa2      	ittt	ge
200217cc:	58c8      	ldrge	r0, [r1, r3]
200217ce:	50d0      	strge	r0, [r2, r3]
200217d0:	e7fa      	bge.n	200217c8 <Reset_Handler+0x1c>
200217d2:	340c      	adds	r4, #12
200217d4:	e7f3      	b.n	200217be <Reset_Handler+0x12>
200217d6:	4b0c      	ldr	r3, [pc, #48]	@ (20021808 <ACPU2HCPU_IRQHandler+0x12>)
200217d8:	4c0c      	ldr	r4, [pc, #48]	@ (2002180c <ACPU2HCPU_IRQHandler+0x16>)
200217da:	42a3      	cmp	r3, r4
200217dc:	da08      	bge.n	200217f0 <Reset_Handler+0x44>
200217de:	6819      	ldr	r1, [r3, #0]
200217e0:	685a      	ldr	r2, [r3, #4]
200217e2:	2000      	movs	r0, #0
200217e4:	3a04      	subs	r2, #4
200217e6:	bfa4      	itt	ge
200217e8:	5088      	strge	r0, [r1, r2]
200217ea:	e7fb      	bge.n	200217e4 <Reset_Handler+0x38>
200217ec:	3308      	adds	r3, #8
200217ee:	e7f4      	b.n	200217da <Reset_Handler+0x2e>
200217f0:	f7ff fb32 	bl	20020e58 <entry>

200217f4 <HardFault_Handler>:
200217f4:	e7fe      	b.n	200217f4 <HardFault_Handler>

200217f6 <ACPU2HCPU_IRQHandler>:
200217f6:	e7fe      	b.n	200217f6 <ACPU2HCPU_IRQHandler>
200217f8:	20042000 	.word	0x20042000
200217fc:	20040000 	.word	0x20040000
20021800:	200269d0 	.word	0x200269d0
20021804:	200269dc 	.word	0x200269dc
20021808:	200269dc 	.word	0x200269dc
2002180c:	200269e4 	.word	0x200269e4

20021810 <__aeabi_unwind_cpp_pr0>:
20021810:	2000      	movs	r0, #0
20021812:	4770      	bx	lr

20021814 <HAL_GetTick>:
20021814:	4b01      	ldr	r3, [pc, #4]	@ (2002181c <HAL_GetTick+0x8>)
20021816:	6818      	ldr	r0, [r3, #0]
20021818:	4770      	bx	lr
2002181a:	bf00      	nop
2002181c:	2004c994 	.word	0x2004c994

20021820 <HAL_Delay_us_>:
20021820:	b538      	push	{r3, r4, r5, lr}
20021822:	4604      	mov	r4, r0
20021824:	4d16      	ldr	r5, [pc, #88]	@ (20021880 <HAL_Delay_us_+0x60>)
20021826:	b128      	cbz	r0, 20021834 <HAL_Delay_us_+0x14>
20021828:	682b      	ldr	r3, [r5, #0]
2002182a:	b11b      	cbz	r3, 20021834 <HAL_Delay_us_+0x14>
2002182c:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
20021830:	d90a      	bls.n	20021848 <HAL_Delay_us_+0x28>
20021832:	e7fe      	b.n	20021832 <HAL_Delay_us_+0x12>
20021834:	2000      	movs	r0, #0
20021836:	f002 f9bb 	bl	20023bb0 <HAL_RCC_GetHCLKFreq>
2002183a:	4b12      	ldr	r3, [pc, #72]	@ (20021884 <HAL_Delay_us_+0x64>)
2002183c:	fbb0 f0f3 	udiv	r0, r0, r3
20021840:	6028      	str	r0, [r5, #0]
20021842:	2c00      	cmp	r4, #0
20021844:	d1f2      	bne.n	2002182c <HAL_Delay_us_+0xc>
20021846:	bd38      	pop	{r3, r4, r5, pc}
20021848:	4a0f      	ldr	r2, [pc, #60]	@ (20021888 <HAL_Delay_us_+0x68>)
2002184a:	6813      	ldr	r3, [r2, #0]
2002184c:	f013 0301 	ands.w	r3, r3, #1
20021850:	d10d      	bne.n	2002186e <HAL_Delay_us_+0x4e>
20021852:	480e      	ldr	r0, [pc, #56]	@ (2002188c <HAL_Delay_us_+0x6c>)
20021854:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
20021858:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
2002185c:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
20021860:	6053      	str	r3, [r2, #4]
20021862:	6813      	ldr	r3, [r2, #0]
20021864:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
20021868:	f043 0301 	orr.w	r3, r3, #1
2002186c:	6013      	str	r3, [r2, #0]
2002186e:	682b      	ldr	r3, [r5, #0]
20021870:	4a05      	ldr	r2, [pc, #20]	@ (20021888 <HAL_Delay_us_+0x68>)
20021872:	435c      	muls	r4, r3
20021874:	6851      	ldr	r1, [r2, #4]
20021876:	6853      	ldr	r3, [r2, #4]
20021878:	1a5b      	subs	r3, r3, r1
2002187a:	429c      	cmp	r4, r3
2002187c:	d8fb      	bhi.n	20021876 <HAL_Delay_us_+0x56>
2002187e:	e7e2      	b.n	20021846 <HAL_Delay_us_+0x26>
20021880:	2004c990 	.word	0x2004c990
20021884:	000f4240 	.word	0x000f4240
20021888:	e0001000 	.word	0xe0001000
2002188c:	e000ed00 	.word	0xe000ed00

20021890 <HAL_Delay_us2_>:
20021890:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021892:	9001      	str	r0, [sp, #4]
20021894:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
20021898:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
2002189c:	6944      	ldr	r4, [r0, #20]
2002189e:	9b01      	ldr	r3, [sp, #4]
200218a0:	4363      	muls	r3, r4
200218a2:	fbb3 f3f2 	udiv	r3, r3, r2
200218a6:	9301      	str	r3, [sp, #4]
200218a8:	2300      	movs	r3, #0
200218aa:	6981      	ldr	r1, [r0, #24]
200218ac:	6982      	ldr	r2, [r0, #24]
200218ae:	428a      	cmp	r2, r1
200218b0:	d0fc      	beq.n	200218ac <HAL_Delay_us2_+0x1c>
200218b2:	bf25      	ittet	cs
200218b4:	1aa5      	subcs	r5, r4, r2
200218b6:	195b      	addcs	r3, r3, r5
200218b8:	185b      	addcc	r3, r3, r1
200218ba:	185b      	addcs	r3, r3, r1
200218bc:	9901      	ldr	r1, [sp, #4]
200218be:	bf38      	it	cc
200218c0:	1a9b      	subcc	r3, r3, r2
200218c2:	4299      	cmp	r1, r3
200218c4:	d801      	bhi.n	200218ca <HAL_Delay_us2_+0x3a>
200218c6:	b003      	add	sp, #12
200218c8:	bd30      	pop	{r4, r5, pc}
200218ca:	4611      	mov	r1, r2
200218cc:	e7ee      	b.n	200218ac <HAL_Delay_us2_+0x1c>

200218ce <HAL_Delay_us>:
200218ce:	4603      	mov	r3, r0
200218d0:	b570      	push	{r4, r5, r6, lr}
200218d2:	b1b8      	cbz	r0, 20021904 <HAL_Delay_us+0x36>
200218d4:	f242 7510 	movw	r5, #10000	@ 0x2710
200218d8:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
200218dc:	42ab      	cmp	r3, r5
200218de:	bf84      	itt	hi
200218e0:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
200218e4:	f242 7310 	movwhi	r3, #10000	@ 0x2710
200218e8:	6932      	ldr	r2, [r6, #16]
200218ea:	bf98      	it	ls
200218ec:	2400      	movls	r4, #0
200218ee:	4618      	mov	r0, r3
200218f0:	bf88      	it	hi
200218f2:	3c10      	subhi	r4, #16
200218f4:	07d3      	lsls	r3, r2, #31
200218f6:	d508      	bpl.n	2002190a <HAL_Delay_us+0x3c>
200218f8:	f7ff ffca 	bl	20021890 <HAL_Delay_us2_>
200218fc:	4623      	mov	r3, r4
200218fe:	2c00      	cmp	r4, #0
20021900:	d1ec      	bne.n	200218dc <HAL_Delay_us+0xe>
20021902:	e001      	b.n	20021908 <HAL_Delay_us+0x3a>
20021904:	f7ff ff8c 	bl	20021820 <HAL_Delay_us_>
20021908:	bd70      	pop	{r4, r5, r6, pc}
2002190a:	f7ff ff89 	bl	20021820 <HAL_Delay_us_>
2002190e:	e7f5      	b.n	200218fc <HAL_Delay_us+0x2e>

20021910 <WDT_IRQHandler>:
20021910:	4770      	bx	lr

20021912 <DBG_Trigger_IRQHandler>:
20021912:	4770      	bx	lr

20021914 <NMI_Handler>:
20021914:	b508      	push	{r3, lr}
20021916:	4b05      	ldr	r3, [pc, #20]	@ (2002192c <NMI_Handler+0x18>)
20021918:	6a1b      	ldr	r3, [r3, #32]
2002191a:	005b      	lsls	r3, r3, #1
2002191c:	d502      	bpl.n	20021924 <NMI_Handler+0x10>
2002191e:	f7ff fff8 	bl	20021912 <DBG_Trigger_IRQHandler>
20021922:	bd08      	pop	{r3, pc}
20021924:	f7ff fff4 	bl	20021910 <WDT_IRQHandler>
20021928:	e7fb      	b.n	20021922 <NMI_Handler+0xe>
2002192a:	bf00      	nop
2002192c:	5000b000 	.word	0x5000b000

20021930 <HAL_AES_run_help>:
20021930:	b510      	push	{r4, lr}
20021932:	f101 4470 	add.w	r4, r1, #4026531840	@ 0xf0000000
20021936:	f1b4 5f80 	cmp.w	r4, #268435456	@ 0x10000000
2002193a:	4c0e      	ldr	r4, [pc, #56]	@ (20021974 <HAL_AES_run_help+0x44>)
2002193c:	bf38      	it	cc
2002193e:	f101 41a0 	addcc.w	r1, r1, #1342177280	@ 0x50000000
20021942:	6161      	str	r1, [r4, #20]
20021944:	f102 4170 	add.w	r1, r2, #4026531840	@ 0xf0000000
20021948:	f1b1 5f80 	cmp.w	r1, #268435456	@ 0x10000000
2002194c:	f103 030f 	add.w	r3, r3, #15
20021950:	ea4f 1323 	mov.w	r3, r3, asr #4
20021954:	bf38      	it	cc
20021956:	f102 42a0 	addcc.w	r2, r2, #1342177280	@ 0x50000000
2002195a:	61a2      	str	r2, [r4, #24]
2002195c:	61e3      	str	r3, [r4, #28]
2002195e:	6923      	ldr	r3, [r4, #16]
20021960:	b108      	cbz	r0, 20021966 <HAL_AES_run_help+0x36>
20021962:	ea43 13c0 	orr.w	r3, r3, r0, lsl #7
20021966:	4a03      	ldr	r2, [pc, #12]	@ (20021974 <HAL_AES_run_help+0x44>)
20021968:	6123      	str	r3, [r4, #16]
2002196a:	6813      	ldr	r3, [r2, #0]
2002196c:	f043 0301 	orr.w	r3, r3, #1
20021970:	6013      	str	r3, [r2, #0]
20021972:	bd10      	pop	{r4, pc}
20021974:	5000d000 	.word	0x5000d000

20021978 <HAL_AES_reset>:
20021978:	2202      	movs	r2, #2
2002197a:	2000      	movs	r0, #0
2002197c:	4b01      	ldr	r3, [pc, #4]	@ (20021984 <HAL_AES_reset+0xc>)
2002197e:	601a      	str	r2, [r3, #0]
20021980:	6018      	str	r0, [r3, #0]
20021982:	4770      	bx	lr
20021984:	5000d000 	.word	0x5000d000

20021988 <HAL_AES_init>:
20021988:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002198a:	4604      	mov	r4, r0
2002198c:	200c      	movs	r0, #12
2002198e:	461e      	mov	r6, r3
20021990:	460d      	mov	r5, r1
20021992:	4617      	mov	r7, r2
20021994:	f002 fa60 	bl	20023e58 <HAL_RCC_EnableModule>
20021998:	4b1c      	ldr	r3, [pc, #112]	@ (20021a0c <HAL_AES_init+0x84>)
2002199a:	685b      	ldr	r3, [r3, #4]
2002199c:	07db      	lsls	r3, r3, #31
2002199e:	d501      	bpl.n	200219a4 <HAL_AES_init+0x1c>
200219a0:	f7ff ffea 	bl	20021978 <HAL_AES_reset>
200219a4:	fab4 f184 	clz	r1, r4
200219a8:	2d18      	cmp	r5, #24
200219aa:	ea4f 1151 	mov.w	r1, r1, lsr #5
200219ae:	ea4f 1141 	mov.w	r1, r1, lsl #5
200219b2:	d01b      	beq.n	200219ec <HAL_AES_init+0x64>
200219b4:	2d20      	cmp	r5, #32
200219b6:	d01b      	beq.n	200219f0 <HAL_AES_init+0x68>
200219b8:	2d10      	cmp	r5, #16
200219ba:	d124      	bne.n	20021a06 <HAL_AES_init+0x7e>
200219bc:	2300      	movs	r3, #0
200219be:	b164      	cbz	r4, 200219da <HAL_AES_init+0x52>
200219c0:	4620      	mov	r0, r4
200219c2:	4a13      	ldr	r2, [pc, #76]	@ (20021a10 <HAL_AES_init+0x88>)
200219c4:	f025 0503 	bic.w	r5, r5, #3
200219c8:	4425      	add	r5, r4
200219ca:	1b12      	subs	r2, r2, r4
200219cc:	1814      	adds	r4, r2, r0
200219ce:	f850 cb04 	ldr.w	ip, [r0], #4
200219d2:	4285      	cmp	r5, r0
200219d4:	f8c4 c000 	str.w	ip, [r4]
200219d8:	d1f8      	bne.n	200219cc <HAL_AES_init+0x44>
200219da:	4331      	orrs	r1, r6
200219dc:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
200219e0:	4b0a      	ldr	r3, [pc, #40]	@ (20021a0c <HAL_AES_init+0x84>)
200219e2:	6119      	str	r1, [r3, #16]
200219e4:	b106      	cbz	r6, 200219e8 <HAL_AES_init+0x60>
200219e6:	b92f      	cbnz	r7, 200219f4 <HAL_AES_init+0x6c>
200219e8:	2000      	movs	r0, #0
200219ea:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200219ec:	2301      	movs	r3, #1
200219ee:	e7e6      	b.n	200219be <HAL_AES_init+0x36>
200219f0:	2302      	movs	r3, #2
200219f2:	e7e4      	b.n	200219be <HAL_AES_init+0x36>
200219f4:	683a      	ldr	r2, [r7, #0]
200219f6:	621a      	str	r2, [r3, #32]
200219f8:	687a      	ldr	r2, [r7, #4]
200219fa:	625a      	str	r2, [r3, #36]	@ 0x24
200219fc:	68ba      	ldr	r2, [r7, #8]
200219fe:	629a      	str	r2, [r3, #40]	@ 0x28
20021a00:	68fa      	ldr	r2, [r7, #12]
20021a02:	62da      	str	r2, [r3, #44]	@ 0x2c
20021a04:	e7f0      	b.n	200219e8 <HAL_AES_init+0x60>
20021a06:	f04f 30ff 	mov.w	r0, #4294967295
20021a0a:	e7ee      	b.n	200219ea <HAL_AES_init+0x62>
20021a0c:	5000d000 	.word	0x5000d000
20021a10:	5000d030 	.word	0x5000d030

20021a14 <HAL_AES_run>:
20021a14:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021a16:	2708      	movs	r7, #8
20021a18:	4e17      	ldr	r6, [pc, #92]	@ (20021a78 <HAL_AES_run+0x64>)
20021a1a:	4614      	mov	r4, r2
20021a1c:	461d      	mov	r5, r3
20021a1e:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
20021a22:	f3bf 8f4f 	dsb	sy
20021a26:	f3bf 8f6f 	isb	sy
20021a2a:	2700      	movs	r7, #0
20021a2c:	4e13      	ldr	r6, [pc, #76]	@ (20021a7c <HAL_AES_run+0x68>)
20021a2e:	60f7      	str	r7, [r6, #12]
20021a30:	f7ff ff7e 	bl	20021930 <HAL_AES_run_help>
20021a34:	6873      	ldr	r3, [r6, #4]
20021a36:	07db      	lsls	r3, r3, #31
20021a38:	d4fc      	bmi.n	20021a34 <HAL_AES_run+0x20>
20021a3a:	68b0      	ldr	r0, [r6, #8]
20021a3c:	f000 0006 	and.w	r0, r0, #6
20021a40:	3800      	subs	r0, #0
20021a42:	bf18      	it	ne
20021a44:	2001      	movne	r0, #1
20021a46:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
20021a4a:	d314      	bcc.n	20021a76 <HAL_AES_run+0x62>
20021a4c:	2d00      	cmp	r5, #0
20021a4e:	dd12      	ble.n	20021a76 <HAL_AES_run+0x62>
20021a50:	f004 031f 	and.w	r3, r4, #31
20021a54:	442b      	add	r3, r5
20021a56:	f024 021f 	bic.w	r2, r4, #31
20021a5a:	f3bf 8f4f 	dsb	sy
20021a5e:	4c08      	ldr	r4, [pc, #32]	@ (20021a80 <HAL_AES_run+0x6c>)
20021a60:	4413      	add	r3, r2
20021a62:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
20021a66:	3220      	adds	r2, #32
20021a68:	1a99      	subs	r1, r3, r2
20021a6a:	2900      	cmp	r1, #0
20021a6c:	dcf9      	bgt.n	20021a62 <HAL_AES_run+0x4e>
20021a6e:	f3bf 8f4f 	dsb	sy
20021a72:	f3bf 8f6f 	isb	sy
20021a76:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021a78:	e000e100 	.word	0xe000e100
20021a7c:	5000d000 	.word	0x5000d000
20021a80:	e000ed00 	.word	0xe000ed00

20021a84 <HAL_NVIC_EnableIRQ>:
20021a84:	2800      	cmp	r0, #0
20021a86:	da00      	bge.n	20021a8a <HAL_NVIC_EnableIRQ+0x6>
20021a88:	e7fe      	b.n	20021a88 <HAL_NVIC_EnableIRQ+0x4>
20021a8a:	2301      	movs	r3, #1
20021a8c:	0941      	lsrs	r1, r0, #5
20021a8e:	4a03      	ldr	r2, [pc, #12]	@ (20021a9c <HAL_NVIC_EnableIRQ+0x18>)
20021a90:	f000 001f 	and.w	r0, r0, #31
20021a94:	4083      	lsls	r3, r0
20021a96:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20021a9a:	4770      	bx	lr
20021a9c:	e000e100 	.word	0xe000e100

20021aa0 <HAL_NVIC_DisableIRQ>:
20021aa0:	2800      	cmp	r0, #0
20021aa2:	da00      	bge.n	20021aa6 <HAL_NVIC_DisableIRQ+0x6>
20021aa4:	e7fe      	b.n	20021aa4 <HAL_NVIC_DisableIRQ+0x4>
20021aa6:	2201      	movs	r2, #1
20021aa8:	4906      	ldr	r1, [pc, #24]	@ (20021ac4 <HAL_NVIC_DisableIRQ+0x24>)
20021aaa:	0943      	lsrs	r3, r0, #5
20021aac:	f000 001f 	and.w	r0, r0, #31
20021ab0:	4082      	lsls	r2, r0
20021ab2:	3320      	adds	r3, #32
20021ab4:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20021ab8:	f3bf 8f4f 	dsb	sy
20021abc:	f3bf 8f6f 	isb	sy
20021ac0:	4770      	bx	lr
20021ac2:	bf00      	nop
20021ac4:	e000e100 	.word	0xe000e100

20021ac8 <DMA_IsChannelOwner>:
20021ac8:	b510      	push	{r4, lr}
20021aca:	4911      	ldr	r1, [pc, #68]	@ (20021b10 <DMA_IsChannelOwner+0x48>)
20021acc:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021ace:	4602      	mov	r2, r0
20021ad0:	428b      	cmp	r3, r1
20021ad2:	d003      	beq.n	20021adc <DMA_IsChannelOwner+0x14>
20021ad4:	490f      	ldr	r1, [pc, #60]	@ (20021b14 <DMA_IsChannelOwner+0x4c>)
20021ad6:	428b      	cmp	r3, r1
20021ad8:	d007      	beq.n	20021aea <DMA_IsChannelOwner+0x22>
20021ada:	e7fe      	b.n	20021ada <DMA_IsChannelOwner+0x12>
20021adc:	4b0e      	ldr	r3, [pc, #56]	@ (20021b18 <DMA_IsChannelOwner+0x50>)
20021ade:	6d10      	ldr	r0, [r2, #80]	@ 0x50
20021ae0:	281f      	cmp	r0, #31
20021ae2:	ea4f 0190 	mov.w	r1, r0, lsr #2
20021ae6:	d902      	bls.n	20021aee <DMA_IsChannelOwner+0x26>
20021ae8:	e7fe      	b.n	20021ae8 <DMA_IsChannelOwner+0x20>
20021aea:	4b0c      	ldr	r3, [pc, #48]	@ (20021b1c <DMA_IsChannelOwner+0x54>)
20021aec:	e7f7      	b.n	20021ade <DMA_IsChannelOwner+0x16>
20021aee:	f3ef 8410 	mrs	r4, PRIMASK
20021af2:	2001      	movs	r0, #1
20021af4:	f380 8810 	msr	PRIMASK, r0
20021af8:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
20021afc:	7900      	ldrb	r0, [r0, #4]
20021afe:	b120      	cbz	r0, 20021b0a <DMA_IsChannelOwner+0x42>
20021b00:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
20021b04:	1a83      	subs	r3, r0, r2
20021b06:	4258      	negs	r0, r3
20021b08:	4158      	adcs	r0, r3
20021b0a:	f384 8810 	msr	PRIMASK, r4
20021b0e:	bd10      	pop	{r4, pc}
20021b10:	50081000 	.word	0x50081000
20021b14:	40001000 	.word	0x40001000
20021b18:	2004c9d8 	.word	0x2004c9d8
20021b1c:	2004c998 	.word	0x2004c998

20021b20 <DMA_FreeChannel.isra.0>:
20021b20:	b538      	push	{r3, r4, r5, lr}
20021b22:	4a13      	ldr	r2, [pc, #76]	@ (20021b70 <DMA_FreeChannel.isra.0+0x50>)
20021b24:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021b26:	4293      	cmp	r3, r2
20021b28:	d003      	beq.n	20021b32 <DMA_FreeChannel.isra.0+0x12>
20021b2a:	4a12      	ldr	r2, [pc, #72]	@ (20021b74 <DMA_FreeChannel.isra.0+0x54>)
20021b2c:	4293      	cmp	r3, r2
20021b2e:	d008      	beq.n	20021b42 <DMA_FreeChannel.isra.0+0x22>
20021b30:	e7fe      	b.n	20021b30 <DMA_FreeChannel.isra.0+0x10>
20021b32:	2132      	movs	r1, #50	@ 0x32
20021b34:	4a10      	ldr	r2, [pc, #64]	@ (20021b78 <DMA_FreeChannel.isra.0+0x58>)
20021b36:	6d04      	ldr	r4, [r0, #80]	@ 0x50
20021b38:	2c1f      	cmp	r4, #31
20021b3a:	ea4f 0394 	mov.w	r3, r4, lsr #2
20021b3e:	d903      	bls.n	20021b48 <DMA_FreeChannel.isra.0+0x28>
20021b40:	e7fe      	b.n	20021b40 <DMA_FreeChannel.isra.0+0x20>
20021b42:	2102      	movs	r1, #2
20021b44:	4a0d      	ldr	r2, [pc, #52]	@ (20021b7c <DMA_FreeChannel.isra.0+0x5c>)
20021b46:	e7f6      	b.n	20021b36 <DMA_FreeChannel.isra.0+0x16>
20021b48:	f3ef 8410 	mrs	r4, PRIMASK
20021b4c:	2501      	movs	r5, #1
20021b4e:	f385 8810 	msr	PRIMASK, r5
20021b52:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
20021b56:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
20021b5a:	4290      	cmp	r0, r2
20021b5c:	d105      	bne.n	20021b6a <DMA_FreeChannel.isra.0+0x4a>
20021b5e:	1858      	adds	r0, r3, r1
20021b60:	b240      	sxtb	r0, r0
20021b62:	f7ff ff9d 	bl	20021aa0 <HAL_NVIC_DisableIRQ>
20021b66:	2300      	movs	r3, #0
20021b68:	712b      	strb	r3, [r5, #4]
20021b6a:	f384 8810 	msr	PRIMASK, r4
20021b6e:	bd38      	pop	{r3, r4, r5, pc}
20021b70:	50081000 	.word	0x50081000
20021b74:	40001000 	.word	0x40001000
20021b78:	2004c9d8 	.word	0x2004c9d8
20021b7c:	2004c998 	.word	0x2004c998

20021b80 <DMA_SetBurstSizeAndFix.part.0>:
20021b80:	6843      	ldr	r3, [r0, #4]
20021b82:	2b10      	cmp	r3, #16
20021b84:	d113      	bne.n	20021bae <DMA_SetBurstSizeAndFix.part.0+0x2e>
20021b86:	8c02      	ldrh	r2, [r0, #32]
20021b88:	b11a      	cbz	r2, 20021b92 <DMA_SetBurstSizeAndFix.part.0+0x12>
20021b8a:	680b      	ldr	r3, [r1, #0]
20021b8c:	f043 5380 	orr.w	r3, r3, #268435456	@ 0x10000000
20021b90:	600b      	str	r3, [r1, #0]
20021b92:	680b      	ldr	r3, [r1, #0]
20021b94:	f362 6319 	bfi	r3, r2, #24, #2
20021b98:	600b      	str	r3, [r1, #0]
20021b9a:	6842      	ldr	r2, [r0, #4]
20021b9c:	b94a      	cbnz	r2, 20021bb2 <DMA_SetBurstSizeAndFix.part.0+0x32>
20021b9e:	8c02      	ldrh	r2, [r0, #32]
20021ba0:	b10a      	cbz	r2, 20021ba6 <DMA_SetBurstSizeAndFix.part.0+0x26>
20021ba2:	f043 5300 	orr.w	r3, r3, #536870912	@ 0x20000000
20021ba6:	f362 639b 	bfi	r3, r2, #26, #2
20021baa:	600b      	str	r3, [r1, #0]
20021bac:	4770      	bx	lr
20021bae:	2203      	movs	r2, #3
20021bb0:	e7ef      	b.n	20021b92 <DMA_SetBurstSizeAndFix.part.0+0x12>
20021bb2:	2203      	movs	r2, #3
20021bb4:	e7f7      	b.n	20021ba6 <DMA_SetBurstSizeAndFix.part.0+0x26>

20021bb6 <DMA_Init>:
20021bb6:	2302      	movs	r3, #2
20021bb8:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021bba:	f880 3031 	strb.w	r3, [r0, #49]	@ 0x31
20021bbe:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021bc2:	4604      	mov	r4, r0
20021bc4:	2b00      	cmp	r3, #0
20021bc6:	bfa2      	ittt	ge
20021bc8:	6803      	ldrge	r3, [r0, #0]
20021bca:	6a42      	ldrge	r2, [r0, #36]	@ 0x24
20021bcc:	611a      	strge	r2, [r3, #16]
20021bce:	e9d0 3102 	ldrd	r3, r1, [r0, #8]
20021bd2:	430b      	orrs	r3, r1
20021bd4:	6901      	ldr	r1, [r0, #16]
20021bd6:	6805      	ldr	r5, [r0, #0]
20021bd8:	430b      	orrs	r3, r1
20021bda:	6941      	ldr	r1, [r0, #20]
20021bdc:	682a      	ldr	r2, [r5, #0]
20021bde:	430b      	orrs	r3, r1
20021be0:	6981      	ldr	r1, [r0, #24]
20021be2:	f36f 120e 	bfc	r2, #4, #11
20021be6:	430b      	orrs	r3, r1
20021be8:	69c1      	ldr	r1, [r0, #28]
20021bea:	430b      	orrs	r3, r1
20021bec:	6a01      	ldr	r1, [r0, #32]
20021bee:	430b      	orrs	r3, r1
20021bf0:	4313      	orrs	r3, r2
20021bf2:	9301      	str	r3, [sp, #4]
20021bf4:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021bf8:	2b00      	cmp	r3, #0
20021bfa:	da08      	bge.n	20021c0e <DMA_Init+0x58>
20021bfc:	6d43      	ldr	r3, [r0, #84]	@ 0x54
20021bfe:	f3c3 031e 	ubfx	r3, r3, #0, #31
20021c02:	2b01      	cmp	r3, #1
20021c04:	d803      	bhi.n	20021c0e <DMA_Init+0x58>
20021c06:	a901      	add	r1, sp, #4
20021c08:	3004      	adds	r0, #4
20021c0a:	f7ff ffb9 	bl	20021b80 <DMA_SetBurstSizeAndFix.part.0>
20021c0e:	9b01      	ldr	r3, [sp, #4]
20021c10:	602b      	str	r3, [r5, #0]
20021c12:	68a3      	ldr	r3, [r4, #8]
20021c14:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021c18:	d01f      	beq.n	20021c5a <DMA_Init+0xa4>
20021c1a:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021c1c:	f3c3 0387 	ubfx	r3, r3, #2, #8
20021c20:	f3ef 8110 	mrs	r1, PRIMASK
20021c24:	2201      	movs	r2, #1
20021c26:	f382 8810 	msr	PRIMASK, r2
20021c2a:	0758      	lsls	r0, r3, #29
20021c2c:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
20021c2e:	d41d      	bmi.n	20021c6c <DMA_Init+0xb6>
20021c30:	253f      	movs	r5, #63	@ 0x3f
20021c32:	f003 0307 	and.w	r3, r3, #7
20021c36:	f8d2 00a8 	ldr.w	r0, [r2, #168]	@ 0xa8
20021c3a:	00db      	lsls	r3, r3, #3
20021c3c:	409d      	lsls	r5, r3
20021c3e:	ea20 0005 	bic.w	r0, r0, r5
20021c42:	f8c2 00a8 	str.w	r0, [r2, #168]	@ 0xa8
20021c46:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021c48:	6862      	ldr	r2, [r4, #4]
20021c4a:	f8d0 50a8 	ldr.w	r5, [r0, #168]	@ 0xa8
20021c4e:	409a      	lsls	r2, r3
20021c50:	432a      	orrs	r2, r5
20021c52:	f8c0 20a8 	str.w	r2, [r0, #168]	@ 0xa8
20021c56:	f381 8810 	msr	PRIMASK, r1
20021c5a:	69a2      	ldr	r2, [r4, #24]
20021c5c:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
20021c60:	d018      	beq.n	20021c94 <DMA_Init+0xde>
20021c62:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
20021c66:	d01f      	beq.n	20021ca8 <DMA_Init+0xf2>
20021c68:	b1aa      	cbz	r2, 20021c96 <DMA_Init+0xe0>
20021c6a:	e7fe      	b.n	20021c6a <DMA_Init+0xb4>
20021c6c:	253f      	movs	r5, #63	@ 0x3f
20021c6e:	f003 0303 	and.w	r3, r3, #3
20021c72:	f8d2 00ac 	ldr.w	r0, [r2, #172]	@ 0xac
20021c76:	00db      	lsls	r3, r3, #3
20021c78:	409d      	lsls	r5, r3
20021c7a:	ea20 0005 	bic.w	r0, r0, r5
20021c7e:	f8c2 00ac 	str.w	r0, [r2, #172]	@ 0xac
20021c82:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021c84:	6862      	ldr	r2, [r4, #4]
20021c86:	f8d0 50ac 	ldr.w	r5, [r0, #172]	@ 0xac
20021c8a:	409a      	lsls	r2, r3
20021c8c:	432a      	orrs	r2, r5
20021c8e:	f8c0 20ac 	str.w	r2, [r0, #172]	@ 0xac
20021c92:	e7e0      	b.n	20021c56 <DMA_Init+0xa0>
20021c94:	2201      	movs	r2, #1
20021c96:	6963      	ldr	r3, [r4, #20]
20021c98:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20021c9c:	d006      	beq.n	20021cac <DMA_Init+0xf6>
20021c9e:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021ca2:	d02c      	beq.n	20021cfe <DMA_Init+0x148>
20021ca4:	b11b      	cbz	r3, 20021cae <DMA_Init+0xf8>
20021ca6:	e7fe      	b.n	20021ca6 <DMA_Init+0xf0>
20021ca8:	2202      	movs	r2, #2
20021caa:	e7f4      	b.n	20021c96 <DMA_Init+0xe0>
20021cac:	2301      	movs	r3, #1
20021cae:	6921      	ldr	r1, [r4, #16]
20021cb0:	f1a1 0080 	sub.w	r0, r1, #128	@ 0x80
20021cb4:	4241      	negs	r1, r0
20021cb6:	4141      	adcs	r1, r0
20021cb8:	68e0      	ldr	r0, [r4, #12]
20021cba:	f1a0 0540 	sub.w	r5, r0, #64	@ 0x40
20021cbe:	4268      	negs	r0, r5
20021cc0:	4168      	adcs	r0, r5
20021cc2:	68a5      	ldr	r5, [r4, #8]
20021cc4:	2d10      	cmp	r5, #16
20021cc6:	bf1f      	itttt	ne
20021cc8:	f884 106d 	strbne.w	r1, [r4, #109]	@ 0x6d
20021ccc:	4619      	movne	r1, r3
20021cce:	4613      	movne	r3, r2
20021cd0:	460a      	movne	r2, r1
20021cd2:	f884 306f 	strb.w	r3, [r4, #111]	@ 0x6f
20021cd6:	f884 206e 	strb.w	r2, [r4, #110]	@ 0x6e
20021cda:	f04f 0300 	mov.w	r3, #0
20021cde:	f04f 0201 	mov.w	r2, #1
20021ce2:	64a3      	str	r3, [r4, #72]	@ 0x48
20021ce4:	bf06      	itte	eq
20021ce6:	f884 006d 	strbeq.w	r0, [r4, #109]	@ 0x6d
20021cea:	f884 106c 	strbeq.w	r1, [r4, #108]	@ 0x6c
20021cee:	f884 006c 	strbne.w	r0, [r4, #108]	@ 0x6c
20021cf2:	f884 2031 	strb.w	r2, [r4, #49]	@ 0x31
20021cf6:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021cfa:	b003      	add	sp, #12
20021cfc:	bd30      	pop	{r4, r5, pc}
20021cfe:	2302      	movs	r3, #2
20021d00:	e7d5      	b.n	20021cae <DMA_Init+0xf8>
	...

20021d04 <DMA_AllocChannel>:
20021d04:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021d06:	4b31      	ldr	r3, [pc, #196]	@ (20021dcc <DMA_AllocChannel+0xc8>)
20021d08:	6802      	ldr	r2, [r0, #0]
20021d0a:	4604      	mov	r4, r0
20021d0c:	4413      	add	r3, r2
20021d0e:	2ba0      	cmp	r3, #160	@ 0xa0
20021d10:	d904      	bls.n	20021d1c <DMA_AllocChannel+0x18>
20021d12:	4b2f      	ldr	r3, [pc, #188]	@ (20021dd0 <DMA_AllocChannel+0xcc>)
20021d14:	4413      	add	r3, r2
20021d16:	2ba0      	cmp	r3, #160	@ 0xa0
20021d18:	d90f      	bls.n	20021d3a <DMA_AllocChannel+0x36>
20021d1a:	e7fe      	b.n	20021d1a <DMA_AllocChannel+0x16>
20021d1c:	2032      	movs	r0, #50	@ 0x32
20021d1e:	f8df c0bc 	ldr.w	ip, [pc, #188]	@ 20021ddc <DMA_AllocChannel+0xd8>
20021d22:	4b2c      	ldr	r3, [pc, #176]	@ (20021dd4 <DMA_AllocChannel+0xd0>)
20021d24:	f3ef 8710 	mrs	r7, PRIMASK
20021d28:	2201      	movs	r2, #1
20021d2a:	f382 8810 	msr	PRIMASK, r2
20021d2e:	6d26      	ldr	r6, [r4, #80]	@ 0x50
20021d30:	2e1f      	cmp	r6, #31
20021d32:	ea4f 0596 	mov.w	r5, r6, lsr #2
20021d36:	d905      	bls.n	20021d44 <DMA_AllocChannel+0x40>
20021d38:	e7fe      	b.n	20021d38 <DMA_AllocChannel+0x34>
20021d3a:	2002      	movs	r0, #2
20021d3c:	f8df c0a0 	ldr.w	ip, [pc, #160]	@ 20021de0 <DMA_AllocChannel+0xdc>
20021d40:	4b25      	ldr	r3, [pc, #148]	@ (20021dd8 <DMA_AllocChannel+0xd4>)
20021d42:	e7ef      	b.n	20021d24 <DMA_AllocChannel+0x20>
20021d44:	eb03 06c5 	add.w	r6, r3, r5, lsl #3
20021d48:	f896 e004 	ldrb.w	lr, [r6, #4]
20021d4c:	f1be 0f00 	cmp.w	lr, #0
20021d50:	d037      	beq.n	20021dc2 <DMA_AllocChannel+0xbe>
20021d52:	f853 2035 	ldr.w	r2, [r3, r5, lsl #3]
20021d56:	42a2      	cmp	r2, r4
20021d58:	d103      	bne.n	20021d62 <DMA_AllocChannel+0x5e>
20021d5a:	f387 8810 	msr	PRIMASK, r7
20021d5e:	2002      	movs	r0, #2
20021d60:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021d62:	2200      	movs	r2, #0
20021d64:	791d      	ldrb	r5, [r3, #4]
20021d66:	461e      	mov	r6, r3
20021d68:	bb2d      	cbnz	r5, 20021db6 <DMA_AllocChannel+0xb2>
20021d6a:	2301      	movs	r3, #1
20021d6c:	7133      	strb	r3, [r6, #4]
20021d6e:	2314      	movs	r3, #20
20021d70:	fb03 c302 	mla	r3, r3, r2, ip
20021d74:	6023      	str	r3, [r4, #0]
20021d76:	0093      	lsls	r3, r2, #2
20021d78:	6523      	str	r3, [r4, #80]	@ 0x50
20021d7a:	6d63      	ldr	r3, [r4, #84]	@ 0x54
20021d7c:	4410      	add	r0, r2
20021d7e:	f362 031e 	bfi	r3, r2, #0, #31
20021d82:	b245      	sxtb	r5, r0
20021d84:	6563      	str	r3, [r4, #84]	@ 0x54
20021d86:	f387 8810 	msr	PRIMASK, r7
20021d8a:	b129      	cbz	r1, 20021d98 <DMA_AllocChannel+0x94>
20021d8c:	6833      	ldr	r3, [r6, #0]
20021d8e:	42a3      	cmp	r3, r4
20021d90:	d002      	beq.n	20021d98 <DMA_AllocChannel+0x94>
20021d92:	4620      	mov	r0, r4
20021d94:	f7ff ff0f 	bl	20021bb6 <DMA_Init>
20021d98:	6034      	str	r4, [r6, #0]
20021d9a:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
20021d9c:	f105 4260 	add.w	r2, r5, #3758096384	@ 0xe0000000
20021da0:	015b      	lsls	r3, r3, #5
20021da2:	b2db      	uxtb	r3, r3
20021da4:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20021da8:	4628      	mov	r0, r5
20021daa:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
20021dae:	f7ff fe69 	bl	20021a84 <HAL_NVIC_EnableIRQ>
20021db2:	2000      	movs	r0, #0
20021db4:	e7d4      	b.n	20021d60 <DMA_AllocChannel+0x5c>
20021db6:	3201      	adds	r2, #1
20021db8:	2a08      	cmp	r2, #8
20021dba:	f103 0308 	add.w	r3, r3, #8
20021dbe:	d1d1      	bne.n	20021d64 <DMA_AllocChannel+0x60>
20021dc0:	e7cb      	b.n	20021d5a <DMA_AllocChannel+0x56>
20021dc2:	4405      	add	r5, r0
20021dc4:	7132      	strb	r2, [r6, #4]
20021dc6:	b26d      	sxtb	r5, r5
20021dc8:	e7dd      	b.n	20021d86 <DMA_AllocChannel+0x82>
20021dca:	bf00      	nop
20021dcc:	aff7eff8 	.word	0xaff7eff8
20021dd0:	bfffeff8 	.word	0xbfffeff8
20021dd4:	2004c9d8 	.word	0x2004c9d8
20021dd8:	2004c998 	.word	0x2004c998
20021ddc:	50081008 	.word	0x50081008
20021de0:	40001008 	.word	0x40001008

20021de4 <HAL_DMA_Init>:
20021de4:	b538      	push	{r3, r4, r5, lr}
20021de6:	4604      	mov	r4, r0
20021de8:	2800      	cmp	r0, #0
20021dea:	d05b      	beq.n	20021ea4 <HAL_DMA_Init+0xc0>
20021dec:	6883      	ldr	r3, [r0, #8]
20021dee:	f033 0210 	bics.w	r2, r3, #16
20021df2:	d003      	beq.n	20021dfc <HAL_DMA_Init+0x18>
20021df4:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021df8:	d000      	beq.n	20021dfc <HAL_DMA_Init+0x18>
20021dfa:	e7fe      	b.n	20021dfa <HAL_DMA_Init+0x16>
20021dfc:	68e3      	ldr	r3, [r4, #12]
20021dfe:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20021e02:	d000      	beq.n	20021e06 <HAL_DMA_Init+0x22>
20021e04:	e7fe      	b.n	20021e04 <HAL_DMA_Init+0x20>
20021e06:	6923      	ldr	r3, [r4, #16]
20021e08:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
20021e0c:	d000      	beq.n	20021e10 <HAL_DMA_Init+0x2c>
20021e0e:	e7fe      	b.n	20021e0e <HAL_DMA_Init+0x2a>
20021e10:	6963      	ldr	r3, [r4, #20]
20021e12:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20021e16:	d003      	beq.n	20021e20 <HAL_DMA_Init+0x3c>
20021e18:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021e1c:	d000      	beq.n	20021e20 <HAL_DMA_Init+0x3c>
20021e1e:	e7fe      	b.n	20021e1e <HAL_DMA_Init+0x3a>
20021e20:	69a3      	ldr	r3, [r4, #24]
20021e22:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20021e26:	d003      	beq.n	20021e30 <HAL_DMA_Init+0x4c>
20021e28:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
20021e2c:	d000      	beq.n	20021e30 <HAL_DMA_Init+0x4c>
20021e2e:	e7fe      	b.n	20021e2e <HAL_DMA_Init+0x4a>
20021e30:	69e3      	ldr	r3, [r4, #28]
20021e32:	f033 0320 	bics.w	r3, r3, #32
20021e36:	d000      	beq.n	20021e3a <HAL_DMA_Init+0x56>
20021e38:	e7fe      	b.n	20021e38 <HAL_DMA_Init+0x54>
20021e3a:	6a23      	ldr	r3, [r4, #32]
20021e3c:	f433 5240 	bics.w	r2, r3, #12288	@ 0x3000
20021e40:	d000      	beq.n	20021e44 <HAL_DMA_Init+0x60>
20021e42:	e7fe      	b.n	20021e42 <HAL_DMA_Init+0x5e>
20021e44:	6863      	ldr	r3, [r4, #4]
20021e46:	2b51      	cmp	r3, #81	@ 0x51
20021e48:	d900      	bls.n	20021e4c <HAL_DMA_Init+0x68>
20021e4a:	e7fe      	b.n	20021e4a <HAL_DMA_Init+0x66>
20021e4c:	6821      	ldr	r1, [r4, #0]
20021e4e:	4b17      	ldr	r3, [pc, #92]	@ (20021eac <HAL_DMA_Init+0xc8>)
20021e50:	440b      	add	r3, r1
20021e52:	2b8c      	cmp	r3, #140	@ 0x8c
20021e54:	d81a      	bhi.n	20021e8c <HAL_DMA_Init+0xa8>
20021e56:	2214      	movs	r2, #20
20021e58:	fbb3 f3f2 	udiv	r3, r3, r2
20021e5c:	2201      	movs	r2, #1
20021e5e:	4914      	ldr	r1, [pc, #80]	@ (20021eb0 <HAL_DMA_Init+0xcc>)
20021e60:	0098      	lsls	r0, r3, #2
20021e62:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021e66:	ea43 73c2 	orr.w	r3, r3, r2, lsl #31
20021e6a:	e9c4 1013 	strd	r1, r0, [r4, #76]	@ 0x4c
20021e6e:	6563      	str	r3, [r4, #84]	@ 0x54
20021e70:	2100      	movs	r1, #0
20021e72:	4620      	mov	r0, r4
20021e74:	f7ff ff46 	bl	20021d04 <DMA_AllocChannel>
20021e78:	4605      	mov	r5, r0
20021e7a:	b9a8      	cbnz	r0, 20021ea8 <HAL_DMA_Init+0xc4>
20021e7c:	4620      	mov	r0, r4
20021e7e:	f7ff fe9a 	bl	20021bb6 <DMA_Init>
20021e82:	4620      	mov	r0, r4
20021e84:	f7ff fe4c 	bl	20021b20 <DMA_FreeChannel.isra.0>
20021e88:	4628      	mov	r0, r5
20021e8a:	bd38      	pop	{r3, r4, r5, pc}
20021e8c:	4b09      	ldr	r3, [pc, #36]	@ (20021eb4 <HAL_DMA_Init+0xd0>)
20021e8e:	440b      	add	r3, r1
20021e90:	2b8c      	cmp	r3, #140	@ 0x8c
20021e92:	d807      	bhi.n	20021ea4 <HAL_DMA_Init+0xc0>
20021e94:	2114      	movs	r1, #20
20021e96:	fbb3 f3f1 	udiv	r3, r3, r1
20021e9a:	4907      	ldr	r1, [pc, #28]	@ (20021eb8 <HAL_DMA_Init+0xd4>)
20021e9c:	0098      	lsls	r0, r3, #2
20021e9e:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021ea2:	e7e0      	b.n	20021e66 <HAL_DMA_Init+0x82>
20021ea4:	2501      	movs	r5, #1
20021ea6:	e7ef      	b.n	20021e88 <HAL_DMA_Init+0xa4>
20021ea8:	2502      	movs	r5, #2
20021eaa:	e7ed      	b.n	20021e88 <HAL_DMA_Init+0xa4>
20021eac:	aff7eff8 	.word	0xaff7eff8
20021eb0:	50081000 	.word	0x50081000
20021eb4:	bfffeff8 	.word	0xbfffeff8
20021eb8:	40001000 	.word	0x40001000

20021ebc <HAL_DMA_DeInit>:
20021ebc:	b538      	push	{r3, r4, r5, lr}
20021ebe:	4604      	mov	r4, r0
20021ec0:	2800      	cmp	r0, #0
20021ec2:	d05e      	beq.n	20021f82 <HAL_DMA_DeInit+0xc6>
20021ec4:	6802      	ldr	r2, [r0, #0]
20021ec6:	4b30      	ldr	r3, [pc, #192]	@ (20021f88 <HAL_DMA_DeInit+0xcc>)
20021ec8:	4413      	add	r3, r2
20021eca:	2b8c      	cmp	r3, #140	@ 0x8c
20021ecc:	d841      	bhi.n	20021f52 <HAL_DMA_DeInit+0x96>
20021ece:	2214      	movs	r2, #20
20021ed0:	fbb3 f3f2 	udiv	r3, r3, r2
20021ed4:	009b      	lsls	r3, r3, #2
20021ed6:	6503      	str	r3, [r0, #80]	@ 0x50
20021ed8:	4b2c      	ldr	r3, [pc, #176]	@ (20021f8c <HAL_DMA_DeInit+0xd0>)
20021eda:	64e3      	str	r3, [r4, #76]	@ 0x4c
20021edc:	4620      	mov	r0, r4
20021ede:	f7ff fdf3 	bl	20021ac8 <DMA_IsChannelOwner>
20021ee2:	b3a0      	cbz	r0, 20021f4e <HAL_DMA_DeInit+0x92>
20021ee4:	6822      	ldr	r2, [r4, #0]
20021ee6:	6813      	ldr	r3, [r2, #0]
20021ee8:	f023 0301 	bic.w	r3, r3, #1
20021eec:	6013      	str	r3, [r2, #0]
20021eee:	2200      	movs	r2, #0
20021ef0:	6823      	ldr	r3, [r4, #0]
20021ef2:	601a      	str	r2, [r3, #0]
20021ef4:	2201      	movs	r2, #1
20021ef6:	e9d4 1313 	ldrd	r1, r3, [r4, #76]	@ 0x4c
20021efa:	f003 031c 	and.w	r3, r3, #28
20021efe:	fa02 f303 	lsl.w	r3, r2, r3
20021f02:	604b      	str	r3, [r1, #4]
20021f04:	f3ef 8510 	mrs	r5, PRIMASK
20021f08:	f382 8810 	msr	PRIMASK, r2
20021f0c:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021f0e:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
20021f10:	2b0f      	cmp	r3, #15
20021f12:	ea4f 0293 	mov.w	r2, r3, lsr #2
20021f16:	d827      	bhi.n	20021f68 <HAL_DMA_DeInit+0xac>
20021f18:	203f      	movs	r0, #63	@ 0x3f
20021f1a:	005b      	lsls	r3, r3, #1
20021f1c:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
20021f20:	f003 0338 	and.w	r3, r3, #56	@ 0x38
20021f24:	fa00 f303 	lsl.w	r3, r0, r3
20021f28:	ea22 0303 	bic.w	r3, r2, r3
20021f2c:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
20021f30:	f385 8810 	msr	PRIMASK, r5
20021f34:	4620      	mov	r0, r4
20021f36:	f7ff fdf3 	bl	20021b20 <DMA_FreeChannel.isra.0>
20021f3a:	2300      	movs	r3, #0
20021f3c:	e9c4 330e 	strd	r3, r3, [r4, #56]	@ 0x38
20021f40:	e9c4 3310 	strd	r3, r3, [r4, #64]	@ 0x40
20021f44:	64a3      	str	r3, [r4, #72]	@ 0x48
20021f46:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021f4a:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20021f4e:	2000      	movs	r0, #0
20021f50:	bd38      	pop	{r3, r4, r5, pc}
20021f52:	4b0f      	ldr	r3, [pc, #60]	@ (20021f90 <HAL_DMA_DeInit+0xd4>)
20021f54:	4413      	add	r3, r2
20021f56:	2b8c      	cmp	r3, #140	@ 0x8c
20021f58:	d8c0      	bhi.n	20021edc <HAL_DMA_DeInit+0x20>
20021f5a:	2214      	movs	r2, #20
20021f5c:	fbb3 f3f2 	udiv	r3, r3, r2
20021f60:	009b      	lsls	r3, r3, #2
20021f62:	6503      	str	r3, [r0, #80]	@ 0x50
20021f64:	4b0b      	ldr	r3, [pc, #44]	@ (20021f94 <HAL_DMA_DeInit+0xd8>)
20021f66:	e7b8      	b.n	20021eda <HAL_DMA_DeInit+0x1e>
20021f68:	f002 0303 	and.w	r3, r2, #3
20021f6c:	223f      	movs	r2, #63	@ 0x3f
20021f6e:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20021f72:	00db      	lsls	r3, r3, #3
20021f74:	fa02 f303 	lsl.w	r3, r2, r3
20021f78:	ea20 0303 	bic.w	r3, r0, r3
20021f7c:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
20021f80:	e7d6      	b.n	20021f30 <HAL_DMA_DeInit+0x74>
20021f82:	2001      	movs	r0, #1
20021f84:	e7e4      	b.n	20021f50 <HAL_DMA_DeInit+0x94>
20021f86:	bf00      	nop
20021f88:	aff7eff8 	.word	0xaff7eff8
20021f8c:	50081000 	.word	0x50081000
20021f90:	bfffeff8 	.word	0xbfffeff8
20021f94:	40001000 	.word	0x40001000

20021f98 <HAL_DMA_PollForTransfer>:
20021f98:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
20021f9c:	f890 3031 	ldrb.w	r3, [r0, #49]	@ 0x31
20021fa0:	4617      	mov	r7, r2
20021fa2:	2b02      	cmp	r3, #2
20021fa4:	4604      	mov	r4, r0
20021fa6:	4688      	mov	r8, r1
20021fa8:	b2da      	uxtb	r2, r3
20021faa:	d005      	beq.n	20021fb8 <HAL_DMA_PollForTransfer+0x20>
20021fac:	2304      	movs	r3, #4
20021fae:	6483      	str	r3, [r0, #72]	@ 0x48
20021fb0:	2300      	movs	r3, #0
20021fb2:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021fb6:	e006      	b.n	20021fc6 <HAL_DMA_PollForTransfer+0x2e>
20021fb8:	6803      	ldr	r3, [r0, #0]
20021fba:	681b      	ldr	r3, [r3, #0]
20021fbc:	0699      	lsls	r1, r3, #26
20021fbe:	d505      	bpl.n	20021fcc <HAL_DMA_PollForTransfer+0x34>
20021fc0:	f44f 7380 	mov.w	r3, #256	@ 0x100
20021fc4:	6483      	str	r3, [r0, #72]	@ 0x48
20021fc6:	2001      	movs	r0, #1
20021fc8:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
20021fcc:	6d05      	ldr	r5, [r0, #80]	@ 0x50
20021fce:	f005 051c 	and.w	r5, r5, #28
20021fd2:	f1b8 0f00 	cmp.w	r8, #0
20021fd6:	d123      	bne.n	20022020 <HAL_DMA_PollForTransfer+0x88>
20021fd8:	fa02 f505 	lsl.w	r5, r2, r5
20021fdc:	f7ff fc1a 	bl	20021814 <HAL_GetTick>
20021fe0:	f04f 0a08 	mov.w	sl, #8
20021fe4:	4681      	mov	r9, r0
20021fe6:	e9d4 6313 	ldrd	r6, r3, [r4, #76]	@ 0x4c
20021fea:	f003 031c 	and.w	r3, r3, #28
20021fee:	fa0a f103 	lsl.w	r1, sl, r3
20021ff2:	6832      	ldr	r2, [r6, #0]
20021ff4:	ea12 0b05 	ands.w	fp, r2, r5
20021ff8:	d016      	beq.n	20022028 <HAL_DMA_PollForTransfer+0x90>
20021ffa:	f1b8 0f00 	cmp.w	r8, #0
20021ffe:	d136      	bne.n	2002206e <HAL_DMA_PollForTransfer+0xd6>
20022000:	2202      	movs	r2, #2
20022002:	fa02 f303 	lsl.w	r3, r2, r3
20022006:	6073      	str	r3, [r6, #4]
20022008:	6da3      	ldr	r3, [r4, #88]	@ 0x58
2002200a:	b92b      	cbnz	r3, 20022018 <HAL_DMA_PollForTransfer+0x80>
2002200c:	4620      	mov	r0, r4
2002200e:	f7ff fd87 	bl	20021b20 <DMA_FreeChannel.isra.0>
20022012:	2301      	movs	r3, #1
20022014:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022018:	2000      	movs	r0, #0
2002201a:	f884 0030 	strb.w	r0, [r4, #48]	@ 0x30
2002201e:	e7d3      	b.n	20021fc8 <HAL_DMA_PollForTransfer+0x30>
20022020:	2304      	movs	r3, #4
20022022:	fa03 f505 	lsl.w	r5, r3, r5
20022026:	e7d9      	b.n	20021fdc <HAL_DMA_PollForTransfer+0x44>
20022028:	6832      	ldr	r2, [r6, #0]
2002202a:	4211      	tst	r1, r2
2002202c:	d00c      	beq.n	20022048 <HAL_DMA_PollForTransfer+0xb0>
2002202e:	2501      	movs	r5, #1
20022030:	fa05 f303 	lsl.w	r3, r5, r3
20022034:	6073      	str	r3, [r6, #4]
20022036:	4620      	mov	r0, r4
20022038:	64a5      	str	r5, [r4, #72]	@ 0x48
2002203a:	f7ff fd71 	bl	20021b20 <DMA_FreeChannel.isra.0>
2002203e:	f884 5031 	strb.w	r5, [r4, #49]	@ 0x31
20022042:	f884 b030 	strb.w	fp, [r4, #48]	@ 0x30
20022046:	e7be      	b.n	20021fc6 <HAL_DMA_PollForTransfer+0x2e>
20022048:	1c7a      	adds	r2, r7, #1
2002204a:	d0d2      	beq.n	20021ff2 <HAL_DMA_PollForTransfer+0x5a>
2002204c:	f7ff fbe2 	bl	20021814 <HAL_GetTick>
20022050:	eba0 0009 	sub.w	r0, r0, r9
20022054:	42b8      	cmp	r0, r7
20022056:	d801      	bhi.n	2002205c <HAL_DMA_PollForTransfer+0xc4>
20022058:	2f00      	cmp	r7, #0
2002205a:	d1c4      	bne.n	20021fe6 <HAL_DMA_PollForTransfer+0x4e>
2002205c:	2320      	movs	r3, #32
2002205e:	4620      	mov	r0, r4
20022060:	64a3      	str	r3, [r4, #72]	@ 0x48
20022062:	f7ff fd5d 	bl	20021b20 <DMA_FreeChannel.isra.0>
20022066:	2301      	movs	r3, #1
20022068:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
2002206c:	e7a0      	b.n	20021fb0 <HAL_DMA_PollForTransfer+0x18>
2002206e:	2204      	movs	r2, #4
20022070:	fa02 f303 	lsl.w	r3, r2, r3
20022074:	6073      	str	r3, [r6, #4]
20022076:	e7cf      	b.n	20022018 <HAL_DMA_PollForTransfer+0x80>

20022078 <DMA_Remap>:
20022078:	b530      	push	{r4, r5, lr}
2002207a:	4b15      	ldr	r3, [pc, #84]	@ (200220d0 <DMA_Remap+0x58>)
2002207c:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
2002207e:	429c      	cmp	r4, r3
20022080:	d11b      	bne.n	200220ba <DMA_Remap+0x42>
20022082:	6883      	ldr	r3, [r0, #8]
20022084:	2b10      	cmp	r3, #16
20022086:	d002      	beq.n	2002208e <DMA_Remap+0x16>
20022088:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
2002208c:	d108      	bne.n	200220a0 <DMA_Remap+0x28>
2002208e:	680b      	ldr	r3, [r1, #0]
20022090:	4c10      	ldr	r4, [pc, #64]	@ (200220d4 <DMA_Remap+0x5c>)
20022092:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
20022096:	42a5      	cmp	r5, r4
20022098:	bf98      	it	ls
2002209a:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
2002209e:	600b      	str	r3, [r1, #0]
200220a0:	6883      	ldr	r3, [r0, #8]
200220a2:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
200220a6:	d108      	bne.n	200220ba <DMA_Remap+0x42>
200220a8:	6813      	ldr	r3, [r2, #0]
200220aa:	480a      	ldr	r0, [pc, #40]	@ (200220d4 <DMA_Remap+0x5c>)
200220ac:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
200220b0:	4284      	cmp	r4, r0
200220b2:	bf98      	it	ls
200220b4:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
200220b8:	6013      	str	r3, [r2, #0]
200220ba:	680b      	ldr	r3, [r1, #0]
200220bc:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
200220c0:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
200220c4:	bf3c      	itt	cc
200220c6:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
200220ca:	600b      	strcc	r3, [r1, #0]
200220cc:	bd30      	pop	{r4, r5, pc}
200220ce:	bf00      	nop
200220d0:	40001000 	.word	0x40001000
200220d4:	0007fffe 	.word	0x0007fffe

200220d8 <DMA_Start>:
200220d8:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
200220dc:	f64f 75ff 	movw	r5, #65535	@ 0xffff
200220e0:	4a2f      	ldr	r2, [pc, #188]	@ (200221a0 <DMA_Start+0xc8>)
200220e2:	4f30      	ldr	r7, [pc, #192]	@ (200221a4 <DMA_Start+0xcc>)
200220e4:	460e      	mov	r6, r1
200220e6:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
200220e8:	6d83      	ldr	r3, [r0, #88]	@ 0x58
200220ea:	4291      	cmp	r1, r2
200220ec:	bf18      	it	ne
200220ee:	463d      	movne	r5, r7
200220f0:	429d      	cmp	r5, r3
200220f2:	bf28      	it	cs
200220f4:	461d      	movcs	r5, r3
200220f6:	6802      	ldr	r2, [r0, #0]
200220f8:	1b5b      	subs	r3, r3, r5
200220fa:	6583      	str	r3, [r0, #88]	@ 0x58
200220fc:	6605      	str	r5, [r0, #96]	@ 0x60
200220fe:	6813      	ldr	r3, [r2, #0]
20022100:	f890 706e 	ldrb.w	r7, [r0, #110]	@ 0x6e
20022104:	f023 0301 	bic.w	r3, r3, #1
20022108:	f890 806f 	ldrb.w	r8, [r0, #111]	@ 0x6f
2002210c:	6013      	str	r3, [r2, #0]
2002210e:	e9d0 2319 	ldrd	r2, r3, [r0, #100]	@ 0x64
20022112:	e9cd 2300 	strd	r2, r3, [sp]
20022116:	e9d0 2313 	ldrd	r2, r3, [r0, #76]	@ 0x4c
2002211a:	f003 011c 	and.w	r1, r3, #28
2002211e:	2301      	movs	r3, #1
20022120:	4604      	mov	r4, r0
20022122:	408b      	lsls	r3, r1
20022124:	6053      	str	r3, [r2, #4]
20022126:	6803      	ldr	r3, [r0, #0]
20022128:	4669      	mov	r1, sp
2002212a:	605d      	str	r5, [r3, #4]
2002212c:	aa01      	add	r2, sp, #4
2002212e:	f7ff ffa3 	bl	20022078 <DMA_Remap>
20022132:	e9dd 0300 	ldrd	r0, r3, [sp]
20022136:	68a1      	ldr	r1, [r4, #8]
20022138:	6822      	ldr	r2, [r4, #0]
2002213a:	2910      	cmp	r1, #16
2002213c:	bf0b      	itete	eq
2002213e:	6093      	streq	r3, [r2, #8]
20022140:	6090      	strne	r0, [r2, #8]
20022142:	6823      	ldreq	r3, [r4, #0]
20022144:	6822      	ldrne	r2, [r4, #0]
20022146:	bf0c      	ite	eq
20022148:	60d8      	streq	r0, [r3, #12]
2002214a:	60d3      	strne	r3, [r2, #12]
2002214c:	f894 306c 	ldrb.w	r3, [r4, #108]	@ 0x6c
20022150:	b123      	cbz	r3, 2002215c <DMA_Start+0x84>
20022152:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20022154:	fa05 f707 	lsl.w	r7, r5, r7
20022158:	443b      	add	r3, r7
2002215a:	6663      	str	r3, [r4, #100]	@ 0x64
2002215c:	f894 306d 	ldrb.w	r3, [r4, #109]	@ 0x6d
20022160:	b123      	cbz	r3, 2002216c <DMA_Start+0x94>
20022162:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
20022164:	fa05 f508 	lsl.w	r5, r5, r8
20022168:	442b      	add	r3, r5
2002216a:	66a3      	str	r3, [r4, #104]	@ 0x68
2002216c:	b136      	cbz	r6, 2002217c <DMA_Start+0xa4>
2002216e:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
20022170:	6823      	ldr	r3, [r4, #0]
20022172:	b15a      	cbz	r2, 2002218c <DMA_Start+0xb4>
20022174:	681a      	ldr	r2, [r3, #0]
20022176:	f042 020e 	orr.w	r2, r2, #14
2002217a:	601a      	str	r2, [r3, #0]
2002217c:	6822      	ldr	r2, [r4, #0]
2002217e:	6813      	ldr	r3, [r2, #0]
20022180:	f043 0301 	orr.w	r3, r3, #1
20022184:	6013      	str	r3, [r2, #0]
20022186:	b002      	add	sp, #8
20022188:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002218c:	681a      	ldr	r2, [r3, #0]
2002218e:	f022 0204 	bic.w	r2, r2, #4
20022192:	601a      	str	r2, [r3, #0]
20022194:	6822      	ldr	r2, [r4, #0]
20022196:	6813      	ldr	r3, [r2, #0]
20022198:	f043 030a 	orr.w	r3, r3, #10
2002219c:	6013      	str	r3, [r2, #0]
2002219e:	e7ed      	b.n	2002217c <DMA_Start+0xa4>
200221a0:	40001000 	.word	0x40001000
200221a4:	000fffff 	.word	0x000fffff

200221a8 <HAL_DMA_Start>:
200221a8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200221aa:	461d      	mov	r5, r3
200221ac:	69c3      	ldr	r3, [r0, #28]
200221ae:	4604      	mov	r4, r0
200221b0:	2b20      	cmp	r3, #32
200221b2:	460f      	mov	r7, r1
200221b4:	4616      	mov	r6, r2
200221b6:	d10b      	bne.n	200221d0 <HAL_DMA_Start+0x28>
200221b8:	b14d      	cbz	r5, 200221ce <HAL_DMA_Start+0x26>
200221ba:	f64f 73ff 	movw	r3, #65535	@ 0xffff
200221be:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
200221c0:	4a1b      	ldr	r2, [pc, #108]	@ (20022230 <HAL_DMA_Start+0x88>)
200221c2:	481c      	ldr	r0, [pc, #112]	@ (20022234 <HAL_DMA_Start+0x8c>)
200221c4:	4291      	cmp	r1, r2
200221c6:	bf18      	it	ne
200221c8:	4603      	movne	r3, r0
200221ca:	42ab      	cmp	r3, r5
200221cc:	d800      	bhi.n	200221d0 <HAL_DMA_Start+0x28>
200221ce:	e7fe      	b.n	200221ce <HAL_DMA_Start+0x26>
200221d0:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
200221d4:	2b01      	cmp	r3, #1
200221d6:	d00e      	beq.n	200221f6 <HAL_DMA_Start+0x4e>
200221d8:	2301      	movs	r3, #1
200221da:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200221de:	f894 3031 	ldrb.w	r3, [r4, #49]	@ 0x31
200221e2:	2b01      	cmp	r3, #1
200221e4:	b2d9      	uxtb	r1, r3
200221e6:	d103      	bne.n	200221f0 <HAL_DMA_Start+0x48>
200221e8:	4620      	mov	r0, r4
200221ea:	f7ff fd8b 	bl	20021d04 <DMA_AllocChannel>
200221ee:	b120      	cbz	r0, 200221fa <HAL_DMA_Start+0x52>
200221f0:	2300      	movs	r3, #0
200221f2:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200221f6:	2002      	movs	r0, #2
200221f8:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
200221fa:	2302      	movs	r3, #2
200221fc:	e9c4 5516 	strd	r5, r5, [r4, #88]	@ 0x58
20022200:	e9c4 7619 	strd	r7, r6, [r4, #100]	@ 0x64
20022204:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022208:	64a0      	str	r0, [r4, #72]	@ 0x48
2002220a:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002220c:	2800      	cmp	r0, #0
2002220e:	d0f3      	beq.n	200221f8 <HAL_DMA_Start+0x50>
20022210:	2100      	movs	r1, #0
20022212:	4620      	mov	r0, r4
20022214:	f7ff ff60 	bl	200220d8 <DMA_Start>
20022218:	6da3      	ldr	r3, [r4, #88]	@ 0x58
2002221a:	2b00      	cmp	r3, #0
2002221c:	d0f5      	beq.n	2002220a <HAL_DMA_Start+0x62>
2002221e:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20022222:	2100      	movs	r1, #0
20022224:	4620      	mov	r0, r4
20022226:	f7ff feb7 	bl	20021f98 <HAL_DMA_PollForTransfer>
2002222a:	2800      	cmp	r0, #0
2002222c:	d0ed      	beq.n	2002220a <HAL_DMA_Start+0x62>
2002222e:	e7e3      	b.n	200221f8 <HAL_DMA_Start+0x50>
20022230:	40001000 	.word	0x40001000
20022234:	000fffff 	.word	0x000fffff

20022238 <HAL_EFUSE_Init>:
20022238:	2000      	movs	r0, #0
2002223a:	4770      	bx	lr

2002223c <HAL_EFUSE_Read>:
2002223c:	2a20      	cmp	r2, #32
2002223e:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20022242:	4607      	mov	r7, r0
20022244:	460c      	mov	r4, r1
20022246:	4690      	mov	r8, r2
20022248:	dc25      	bgt.n	20022296 <HAL_EFUSE_Read+0x5a>
2002224a:	f3c0 09c4 	ubfx	r9, r0, #3, #5
2002224e:	eb09 0302 	add.w	r3, r9, r2
20022252:	2b20      	cmp	r3, #32
20022254:	dc1f      	bgt.n	20022296 <HAL_EFUSE_Read+0x5a>
20022256:	f012 0f03 	tst.w	r2, #3
2002225a:	d11c      	bne.n	20022296 <HAL_EFUSE_Read+0x5a>
2002225c:	f010 051f 	ands.w	r5, r0, #31
20022260:	d119      	bne.n	20022296 <HAL_EFUSE_Read+0x5a>
20022262:	2003      	movs	r0, #3
20022264:	f7ff fa3c 	bl	200216e0 <pmu_ldo_inc>
20022268:	4629      	mov	r1, r5
2002226a:	4e1d      	ldr	r6, [pc, #116]	@ (200222e0 <HAL_EFUSE_Read+0xa4>)
2002226c:	0a3f      	lsrs	r7, r7, #8
2002226e:	00bb      	lsls	r3, r7, #2
20022270:	6033      	str	r3, [r6, #0]
20022272:	6833      	ldr	r3, [r6, #0]
20022274:	4a1b      	ldr	r2, [pc, #108]	@ (200222e4 <HAL_EFUSE_Read+0xa8>)
20022276:	f043 0301 	orr.w	r3, r3, #1
2002227a:	6033      	str	r3, [r6, #0]
2002227c:	68b3      	ldr	r3, [r6, #8]
2002227e:	07db      	lsls	r3, r3, #31
20022280:	d401      	bmi.n	20022286 <HAL_EFUSE_Read+0x4a>
20022282:	4291      	cmp	r1, r2
20022284:	d10c      	bne.n	200222a0 <HAL_EFUSE_Read+0x64>
20022286:	68b3      	ldr	r3, [r6, #8]
20022288:	4291      	cmp	r1, r2
2002228a:	f043 0301 	orr.w	r3, r3, #1
2002228e:	60b3      	str	r3, [r6, #8]
20022290:	d108      	bne.n	200222a4 <HAL_EFUSE_Read+0x68>
20022292:	f7ff fa27 	bl	200216e4 <pmu_ldo_recover>
20022296:	f04f 0800 	mov.w	r8, #0
2002229a:	4640      	mov	r0, r8
2002229c:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200222a0:	3101      	adds	r1, #1
200222a2:	e7eb      	b.n	2002227c <HAL_EFUSE_Read+0x40>
200222a4:	4a10      	ldr	r2, [pc, #64]	@ (200222e8 <HAL_EFUSE_Read+0xac>)
200222a6:	f009 031c 	and.w	r3, r9, #28
200222aa:	eb03 1347 	add.w	r3, r3, r7, lsl #5
200222ae:	f028 0103 	bic.w	r1, r8, #3
200222b2:	441a      	add	r2, r3
200222b4:	4421      	add	r1, r4
200222b6:	428c      	cmp	r4, r1
200222b8:	d102      	bne.n	200222c0 <HAL_EFUSE_Read+0x84>
200222ba:	f7ff fa13 	bl	200216e4 <pmu_ldo_recover>
200222be:	e7ec      	b.n	2002229a <HAL_EFUSE_Read+0x5e>
200222c0:	f852 3b04 	ldr.w	r3, [r2], #4
200222c4:	3404      	adds	r4, #4
200222c6:	0a1d      	lsrs	r5, r3, #8
200222c8:	f804 3c04 	strb.w	r3, [r4, #-4]
200222cc:	f804 5c03 	strb.w	r5, [r4, #-3]
200222d0:	0c1d      	lsrs	r5, r3, #16
200222d2:	0e1b      	lsrs	r3, r3, #24
200222d4:	f804 5c02 	strb.w	r5, [r4, #-2]
200222d8:	f804 3c01 	strb.w	r3, [r4, #-1]
200222dc:	e7eb      	b.n	200222b6 <HAL_EFUSE_Read+0x7a>
200222de:	bf00      	nop
200222e0:	5000c000 	.word	0x5000c000
200222e4:	00bb8000 	.word	0x00bb8000
200222e8:	5000c030 	.word	0x5000c030

200222ec <HAL_HPAON_EnableXT48>:
200222ec:	4b04      	ldr	r3, [pc, #16]	@ (20022300 <HAL_HPAON_EnableXT48+0x14>)
200222ee:	689a      	ldr	r2, [r3, #8]
200222f0:	f042 0202 	orr.w	r2, r2, #2
200222f4:	609a      	str	r2, [r3, #8]
200222f6:	689a      	ldr	r2, [r3, #8]
200222f8:	2a00      	cmp	r2, #0
200222fa:	dafc      	bge.n	200222f6 <HAL_HPAON_EnableXT48+0xa>
200222fc:	4770      	bx	lr
200222fe:	bf00      	nop
20022300:	500c0000 	.word	0x500c0000

20022304 <HAL_HPAON_DisableXT48>:
20022304:	4a02      	ldr	r2, [pc, #8]	@ (20022310 <HAL_HPAON_DisableXT48+0xc>)
20022306:	6893      	ldr	r3, [r2, #8]
20022308:	f023 0302 	bic.w	r3, r3, #2
2002230c:	6093      	str	r3, [r2, #8]
2002230e:	4770      	bx	lr
20022310:	500c0000 	.word	0x500c0000

20022314 <HAL_QSPI_Init>:
20022314:	b510      	push	{r4, lr}
20022316:	b1e8      	cbz	r0, 20022354 <HAL_QSPI_Init+0x40>
20022318:	b1e1      	cbz	r1, 20022354 <HAL_QSPI_Init+0x40>
2002231a:	2300      	movs	r3, #0
2002231c:	2201      	movs	r2, #1
2002231e:	6043      	str	r3, [r0, #4]
20022320:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
20022324:	680c      	ldr	r4, [r1, #0]
20022326:	6004      	str	r4, [r0, #0]
20022328:	684a      	ldr	r2, [r1, #4]
2002232a:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
2002232e:	688a      	ldr	r2, [r1, #8]
20022330:	6102      	str	r2, [r0, #16]
20022332:	68ca      	ldr	r2, [r1, #12]
20022334:	0512      	lsls	r2, r2, #20
20022336:	6142      	str	r2, [r0, #20]
20022338:	22ff      	movs	r2, #255	@ 0xff
2002233a:	f8c4 208c 	str.w	r2, [r4, #140]	@ 0x8c
2002233e:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
20022342:	6801      	ldr	r1, [r0, #0]
20022344:	f8c1 4080 	str.w	r4, [r1, #128]	@ 0x80
20022348:	6801      	ldr	r1, [r0, #0]
2002234a:	620a      	str	r2, [r1, #32]
2002234c:	6801      	ldr	r1, [r0, #0]
2002234e:	4618      	mov	r0, r3
20022350:	644a      	str	r2, [r1, #68]	@ 0x44
20022352:	bd10      	pop	{r4, pc}
20022354:	2001      	movs	r0, #1
20022356:	e7fc      	b.n	20022352 <HAL_QSPI_Init+0x3e>

20022358 <HAL_FLASH_SET_AHB_RCMD>:
20022358:	b138      	cbz	r0, 2002236a <HAL_FLASH_SET_AHB_RCMD+0x12>
2002235a:	6802      	ldr	r2, [r0, #0]
2002235c:	2000      	movs	r0, #0
2002235e:	6c13      	ldr	r3, [r2, #64]	@ 0x40
20022360:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
20022364:	4319      	orrs	r1, r3
20022366:	6411      	str	r1, [r2, #64]	@ 0x40
20022368:	4770      	bx	lr
2002236a:	2001      	movs	r0, #1
2002236c:	4770      	bx	lr

2002236e <HAL_FLASH_CFG_AHB_RCMD>:
2002236e:	b570      	push	{r4, r5, r6, lr}
20022370:	b1c8      	cbz	r0, 200223a6 <HAL_FLASH_CFG_AHB_RCMD+0x38>
20022372:	6805      	ldr	r5, [r0, #0]
20022374:	f99d 6018 	ldrsb.w	r6, [sp, #24]
20022378:	f99d 001c 	ldrsb.w	r0, [sp, #28]
2002237c:	6cac      	ldr	r4, [r5, #72]	@ 0x48
2002237e:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022382:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
20022386:	f99d 0010 	ldrsb.w	r0, [sp, #16]
2002238a:	f36f 0414 	bfc	r4, #0, #21
2002238e:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022392:	f99d 0014 	ldrsb.w	r0, [sp, #20]
20022396:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
2002239a:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
2002239e:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
200223a2:	4321      	orrs	r1, r4
200223a4:	64a9      	str	r1, [r5, #72]	@ 0x48
200223a6:	bd70      	pop	{r4, r5, r6, pc}

200223a8 <HAL_FLASH_WRITE_WORD>:
200223a8:	b118      	cbz	r0, 200223b2 <HAL_FLASH_WRITE_WORD+0xa>
200223aa:	6803      	ldr	r3, [r0, #0]
200223ac:	2000      	movs	r0, #0
200223ae:	6059      	str	r1, [r3, #4]
200223b0:	4770      	bx	lr
200223b2:	2001      	movs	r0, #1
200223b4:	4770      	bx	lr

200223b6 <HAL_FLASH_WRITE_DLEN>:
200223b6:	b130      	cbz	r0, 200223c6 <HAL_FLASH_WRITE_DLEN+0x10>
200223b8:	6803      	ldr	r3, [r0, #0]
200223ba:	3901      	subs	r1, #1
200223bc:	f3c1 0113 	ubfx	r1, r1, #0, #20
200223c0:	2000      	movs	r0, #0
200223c2:	6259      	str	r1, [r3, #36]	@ 0x24
200223c4:	4770      	bx	lr
200223c6:	2001      	movs	r0, #1
200223c8:	4770      	bx	lr

200223ca <HAL_FLASH_WRITE_DLEN2>:
200223ca:	b130      	cbz	r0, 200223da <HAL_FLASH_WRITE_DLEN2+0x10>
200223cc:	6803      	ldr	r3, [r0, #0]
200223ce:	3901      	subs	r1, #1
200223d0:	f3c1 0113 	ubfx	r1, r1, #0, #20
200223d4:	2000      	movs	r0, #0
200223d6:	6399      	str	r1, [r3, #56]	@ 0x38
200223d8:	4770      	bx	lr
200223da:	2001      	movs	r0, #1
200223dc:	4770      	bx	lr

200223de <HAL_FLASH_IS_CMD_DONE>:
200223de:	b118      	cbz	r0, 200223e8 <HAL_FLASH_IS_CMD_DONE+0xa>
200223e0:	6803      	ldr	r3, [r0, #0]
200223e2:	6918      	ldr	r0, [r3, #16]
200223e4:	f000 0001 	and.w	r0, r0, #1
200223e8:	4770      	bx	lr

200223ea <HAL_FLASH_CLR_CMD_DONE>:
200223ea:	b120      	cbz	r0, 200223f6 <HAL_FLASH_CLR_CMD_DONE+0xc>
200223ec:	6802      	ldr	r2, [r0, #0]
200223ee:	6953      	ldr	r3, [r2, #20]
200223f0:	f043 0301 	orr.w	r3, r3, #1
200223f4:	6153      	str	r3, [r2, #20]
200223f6:	4770      	bx	lr

200223f8 <HAL_FLASH_SET_CMD>:
200223f8:	b538      	push	{r3, r4, r5, lr}
200223fa:	460d      	mov	r5, r1
200223fc:	4604      	mov	r4, r0
200223fe:	b1a8      	cbz	r0, 2002242c <HAL_FLASH_SET_CMD+0x34>
20022400:	6803      	ldr	r3, [r0, #0]
20022402:	61da      	str	r2, [r3, #28]
20022404:	6b43      	ldr	r3, [r0, #52]	@ 0x34
20022406:	b10b      	cbz	r3, 2002240c <HAL_FLASH_SET_CMD+0x14>
20022408:	2001      	movs	r0, #1
2002240a:	4798      	blx	r3
2002240c:	6823      	ldr	r3, [r4, #0]
2002240e:	619d      	str	r5, [r3, #24]
20022410:	4620      	mov	r0, r4
20022412:	f7ff ffe4 	bl	200223de <HAL_FLASH_IS_CMD_DONE>
20022416:	2800      	cmp	r0, #0
20022418:	d0fa      	beq.n	20022410 <HAL_FLASH_SET_CMD+0x18>
2002241a:	4620      	mov	r0, r4
2002241c:	f7ff ffe5 	bl	200223ea <HAL_FLASH_CLR_CMD_DONE>
20022420:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20022422:	b10b      	cbz	r3, 20022428 <HAL_FLASH_SET_CMD+0x30>
20022424:	2000      	movs	r0, #0
20022426:	4798      	blx	r3
20022428:	2000      	movs	r0, #0
2002242a:	bd38      	pop	{r3, r4, r5, pc}
2002242c:	2001      	movs	r0, #1
2002242e:	e7fc      	b.n	2002242a <HAL_FLASH_SET_CMD+0x32>

20022430 <HAL_FLASH_CLR_STATUS>:
20022430:	b118      	cbz	r0, 2002243a <HAL_FLASH_CLR_STATUS+0xa>
20022432:	6802      	ldr	r2, [r0, #0]
20022434:	6953      	ldr	r3, [r2, #20]
20022436:	4319      	orrs	r1, r3
20022438:	6151      	str	r1, [r2, #20]
2002243a:	4770      	bx	lr

2002243c <HAL_FLASH_STATUS_MATCH>:
2002243c:	b118      	cbz	r0, 20022446 <HAL_FLASH_STATUS_MATCH+0xa>
2002243e:	6803      	ldr	r3, [r0, #0]
20022440:	6918      	ldr	r0, [r3, #16]
20022442:	f3c0 00c0 	ubfx	r0, r0, #3, #1
20022446:	4770      	bx	lr

20022448 <HAL_FLASH_IS_PROG_DONE>:
20022448:	b128      	cbz	r0, 20022456 <HAL_FLASH_IS_PROG_DONE+0xe>
2002244a:	6803      	ldr	r3, [r0, #0]
2002244c:	6858      	ldr	r0, [r3, #4]
2002244e:	43c0      	mvns	r0, r0
20022450:	f000 0001 	and.w	r0, r0, #1
20022454:	4770      	bx	lr
20022456:	2001      	movs	r0, #1
20022458:	4770      	bx	lr

2002245a <HAL_FLASH_READ32>:
2002245a:	b108      	cbz	r0, 20022460 <HAL_FLASH_READ32+0x6>
2002245c:	6803      	ldr	r3, [r0, #0]
2002245e:	6858      	ldr	r0, [r3, #4]
20022460:	4770      	bx	lr

20022462 <HAL_FLASH_SET_TXSLOT>:
20022462:	b120      	cbz	r0, 2002246e <HAL_FLASH_SET_TXSLOT+0xc>
20022464:	6802      	ldr	r2, [r0, #0]
20022466:	6d53      	ldr	r3, [r2, #84]	@ 0x54
20022468:	f361 238e 	bfi	r3, r1, #10, #5
2002246c:	6553      	str	r3, [r2, #84]	@ 0x54
2002246e:	4770      	bx	lr

20022470 <HAL_FLASH_SET_CLK_rom>:
20022470:	b108      	cbz	r0, 20022476 <HAL_FLASH_SET_CLK_rom+0x6>
20022472:	6803      	ldr	r3, [r0, #0]
20022474:	60d9      	str	r1, [r3, #12]
20022476:	4770      	bx	lr

20022478 <HAL_FLASH_MANUAL_CMD>:
20022478:	b570      	push	{r4, r5, r6, lr}
2002247a:	b1e8      	cbz	r0, 200224b8 <HAL_FLASH_MANUAL_CMD+0x40>
2002247c:	6805      	ldr	r5, [r0, #0]
2002247e:	f99d 601c 	ldrsb.w	r6, [sp, #28]
20022482:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022486:	6aac      	ldr	r4, [r5, #40]	@ 0x28
20022488:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
2002248c:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022490:	f36f 0415 	bfc	r4, #0, #22
20022494:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022498:	f99d 6014 	ldrsb.w	r6, [sp, #20]
2002249c:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
200224a0:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200224a4:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
200224a8:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
200224ac:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200224b0:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200224b4:	4321      	orrs	r1, r4
200224b6:	62a9      	str	r1, [r5, #40]	@ 0x28
200224b8:	bd70      	pop	{r4, r5, r6, pc}

200224ba <HAL_FLASH_MANUAL_CMD2>:
200224ba:	b570      	push	{r4, r5, r6, lr}
200224bc:	b1e8      	cbz	r0, 200224fa <HAL_FLASH_MANUAL_CMD2+0x40>
200224be:	6805      	ldr	r5, [r0, #0]
200224c0:	f99d 601c 	ldrsb.w	r6, [sp, #28]
200224c4:	f99d 0020 	ldrsb.w	r0, [sp, #32]
200224c8:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
200224ca:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200224ce:	f99d 6010 	ldrsb.w	r6, [sp, #16]
200224d2:	f36f 0415 	bfc	r4, #0, #22
200224d6:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
200224da:	f99d 6014 	ldrsb.w	r6, [sp, #20]
200224de:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
200224e2:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200224e6:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
200224ea:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
200224ee:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
200224f2:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
200224f6:	4321      	orrs	r1, r4
200224f8:	63e9      	str	r1, [r5, #60]	@ 0x3c
200224fa:	bd70      	pop	{r4, r5, r6, pc}

200224fc <HAL_FLASH_SET_ALIAS_RANGE>:
200224fc:	b510      	push	{r4, lr}
200224fe:	b158      	cbz	r0, 20022518 <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
20022500:	4b06      	ldr	r3, [pc, #24]	@ (2002251c <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
20022502:	6804      	ldr	r4, [r0, #0]
20022504:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
20022508:	440a      	add	r2, r1
2002250a:	4019      	ands	r1, r3
2002250c:	6761      	str	r1, [r4, #116]	@ 0x74
2002250e:	401a      	ands	r2, r3
20022510:	6803      	ldr	r3, [r0, #0]
20022512:	2000      	movs	r0, #0
20022514:	679a      	str	r2, [r3, #120]	@ 0x78
20022516:	bd10      	pop	{r4, pc}
20022518:	2001      	movs	r0, #1
2002251a:	e7fc      	b.n	20022516 <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
2002251c:	fffffc00 	.word	0xfffffc00

20022520 <HAL_FLASH_SET_ALIAS_OFFSET>:
20022520:	b128      	cbz	r0, 2002252e <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
20022522:	6803      	ldr	r3, [r0, #0]
20022524:	f36f 0109 	bfc	r1, #0, #10
20022528:	2000      	movs	r0, #0
2002252a:	67d9      	str	r1, [r3, #124]	@ 0x7c
2002252c:	4770      	bx	lr
2002252e:	2001      	movs	r0, #1
20022530:	4770      	bx	lr

20022532 <HAL_FLASH_ENABLE_QSPI>:
20022532:	b150      	cbz	r0, 2002254a <HAL_FLASH_ENABLE_QSPI+0x18>
20022534:	6803      	ldr	r3, [r0, #0]
20022536:	681a      	ldr	r2, [r3, #0]
20022538:	b121      	cbz	r1, 20022544 <HAL_FLASH_ENABLE_QSPI+0x12>
2002253a:	f042 0201 	orr.w	r2, r2, #1
2002253e:	2000      	movs	r0, #0
20022540:	601a      	str	r2, [r3, #0]
20022542:	4770      	bx	lr
20022544:	f022 0201 	bic.w	r2, r2, #1
20022548:	e7f9      	b.n	2002253e <HAL_FLASH_ENABLE_QSPI+0xc>
2002254a:	2001      	movs	r0, #1
2002254c:	4770      	bx	lr

2002254e <HAL_FLASH_ENABLE_CMD2>:
2002254e:	b150      	cbz	r0, 20022566 <HAL_FLASH_ENABLE_CMD2+0x18>
20022550:	6803      	ldr	r3, [r0, #0]
20022552:	681a      	ldr	r2, [r3, #0]
20022554:	b121      	cbz	r1, 20022560 <HAL_FLASH_ENABLE_CMD2+0x12>
20022556:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
2002255a:	2000      	movs	r0, #0
2002255c:	601a      	str	r2, [r3, #0]
2002255e:	4770      	bx	lr
20022560:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
20022564:	e7f9      	b.n	2002255a <HAL_FLASH_ENABLE_CMD2+0xc>
20022566:	2001      	movs	r0, #1
20022568:	4770      	bx	lr

2002256a <HAL_FLASH_STAUS_MATCH_CMD2>:
2002256a:	b150      	cbz	r0, 20022582 <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
2002256c:	6803      	ldr	r3, [r0, #0]
2002256e:	681a      	ldr	r2, [r3, #0]
20022570:	b121      	cbz	r1, 2002257c <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
20022572:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
20022576:	2000      	movs	r0, #0
20022578:	601a      	str	r2, [r3, #0]
2002257a:	4770      	bx	lr
2002257c:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
20022580:	e7f9      	b.n	20022576 <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
20022582:	2001      	movs	r0, #1
20022584:	4770      	bx	lr

20022586 <HAL_FLASH_SET_ROW_BOUNDARY>:
20022586:	b130      	cbz	r0, 20022596 <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
20022588:	6802      	ldr	r2, [r0, #0]
2002258a:	2000      	movs	r0, #0
2002258c:	6893      	ldr	r3, [r2, #8]
2002258e:	f361 0302 	bfi	r3, r1, #0, #3
20022592:	6093      	str	r3, [r2, #8]
20022594:	4770      	bx	lr
20022596:	2001      	movs	r0, #1
20022598:	4770      	bx	lr

2002259a <HAL_FLASH_SET_DUAL_MODE>:
2002259a:	b150      	cbz	r0, 200225b2 <HAL_FLASH_SET_DUAL_MODE+0x18>
2002259c:	6803      	ldr	r3, [r0, #0]
2002259e:	681a      	ldr	r2, [r3, #0]
200225a0:	b121      	cbz	r1, 200225ac <HAL_FLASH_SET_DUAL_MODE+0x12>
200225a2:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
200225a6:	2000      	movs	r0, #0
200225a8:	601a      	str	r2, [r3, #0]
200225aa:	4770      	bx	lr
200225ac:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
200225b0:	e7f9      	b.n	200225a6 <HAL_FLASH_SET_DUAL_MODE+0xc>
200225b2:	2001      	movs	r0, #1
200225b4:	4770      	bx	lr

200225b6 <HAL_MPI_CFG_DTR>:
200225b6:	6803      	ldr	r3, [r0, #0]
200225b8:	6d9a      	ldr	r2, [r3, #88]	@ 0x58
200225ba:	b121      	cbz	r1, 200225c6 <HAL_MPI_CFG_DTR+0x10>
200225bc:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
200225c0:	2000      	movs	r0, #0
200225c2:	659a      	str	r2, [r3, #88]	@ 0x58
200225c4:	4770      	bx	lr
200225c6:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
200225ca:	e7f9      	b.n	200225c0 <HAL_MPI_CFG_DTR+0xa>

200225cc <HAL_FLASH_CONFIG_AHB_READ>:
200225cc:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200225ce:	4605      	mov	r5, r0
200225d0:	2800      	cmp	r0, #0
200225d2:	d03d      	beq.n	20022650 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200225d4:	68c4      	ldr	r4, [r0, #12]
200225d6:	b301      	cbz	r1, 2002261a <HAL_FLASH_CONFIG_AHB_READ+0x4e>
200225d8:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
200225dc:	2b00      	cmp	r3, #0
200225de:	d037      	beq.n	20022650 <HAL_FLASH_CONFIG_AHB_READ+0x84>
200225e0:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
200225e4:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
200225e8:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
200225ec:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
200225f0:	9603      	str	r6, [sp, #12]
200225f2:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
200225f6:	9602      	str	r6, [sp, #8]
200225f8:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
200225fc:	9601      	str	r6, [sp, #4]
200225fe:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
20022602:	9400      	str	r4, [sp, #0]
20022604:	f7ff feb3 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
20022608:	68eb      	ldr	r3, [r5, #12]
2002260a:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
2002260e:	4628      	mov	r0, r5
20022610:	f7ff fea2 	bl	20022358 <HAL_FLASH_SET_AHB_RCMD>
20022614:	2000      	movs	r0, #0
20022616:	b004      	add	sp, #16
20022618:	bd70      	pop	{r4, r5, r6, pc}
2002261a:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
2002261e:	b1bb      	cbz	r3, 20022650 <HAL_FLASH_CONFIG_AHB_READ+0x84>
20022620:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
20022624:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
20022628:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
2002262c:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
20022630:	9603      	str	r6, [sp, #12]
20022632:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
20022636:	9602      	str	r6, [sp, #8]
20022638:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
2002263c:	9601      	str	r6, [sp, #4]
2002263e:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
20022642:	9400      	str	r4, [sp, #0]
20022644:	f7ff fe93 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
20022648:	68eb      	ldr	r3, [r5, #12]
2002264a:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
2002264e:	e7de      	b.n	2002260e <HAL_FLASH_CONFIG_AHB_READ+0x42>
20022650:	2001      	movs	r0, #1
20022652:	e7e0      	b.n	20022616 <HAL_FLASH_CONFIG_AHB_READ+0x4a>

20022654 <HAL_FLASH_CONFIG_FULL_AHB_READ>:
20022654:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20022656:	4605      	mov	r5, r0
20022658:	2800      	cmp	r0, #0
2002265a:	d036      	beq.n	200226ca <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
2002265c:	68c4      	ldr	r4, [r0, #12]
2002265e:	b1e1      	cbz	r1, 2002269a <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
20022660:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
20022664:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
20022668:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
2002266c:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
20022670:	9603      	str	r6, [sp, #12]
20022672:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
20022676:	9602      	str	r6, [sp, #8]
20022678:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
2002267c:	9601      	str	r6, [sp, #4]
2002267e:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
20022682:	9400      	str	r4, [sp, #0]
20022684:	f7ff fe73 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
20022688:	68eb      	ldr	r3, [r5, #12]
2002268a:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
2002268e:	4628      	mov	r0, r5
20022690:	f7ff fe62 	bl	20022358 <HAL_FLASH_SET_AHB_RCMD>
20022694:	2000      	movs	r0, #0
20022696:	b004      	add	sp, #16
20022698:	bd70      	pop	{r4, r5, r6, pc}
2002269a:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
2002269e:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
200226a2:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
200226a6:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
200226aa:	9603      	str	r6, [sp, #12]
200226ac:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
200226b0:	9602      	str	r6, [sp, #8]
200226b2:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
200226b6:	9601      	str	r6, [sp, #4]
200226b8:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
200226bc:	9400      	str	r4, [sp, #0]
200226be:	f7ff fe56 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
200226c2:	68eb      	ldr	r3, [r5, #12]
200226c4:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
200226c8:	e7e1      	b.n	2002268e <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
200226ca:	2001      	movs	r0, #1
200226cc:	e7e3      	b.n	20022696 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

200226ce <HAL_FLASH_PRE_CMD>:
200226ce:	b530      	push	{r4, r5, lr}
200226d0:	68c4      	ldr	r4, [r0, #12]
200226d2:	b087      	sub	sp, #28
200226d4:	b304      	cbz	r4, 20022718 <HAL_FLASH_PRE_CMD+0x4a>
200226d6:	2938      	cmp	r1, #56	@ 0x38
200226d8:	d81e      	bhi.n	20022718 <HAL_FLASH_PRE_CMD+0x4a>
200226da:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
200226de:	440c      	add	r4, r1
200226e0:	7c23      	ldrb	r3, [r4, #16]
200226e2:	b1cb      	cbz	r3, 20022718 <HAL_FLASH_PRE_CMD+0x4a>
200226e4:	f994 5018 	ldrsb.w	r5, [r4, #24]
200226e8:	f994 3013 	ldrsb.w	r3, [r4, #19]
200226ec:	f994 2012 	ldrsb.w	r2, [r4, #18]
200226f0:	f994 1011 	ldrsb.w	r1, [r4, #17]
200226f4:	9504      	str	r5, [sp, #16]
200226f6:	f994 5017 	ldrsb.w	r5, [r4, #23]
200226fa:	9503      	str	r5, [sp, #12]
200226fc:	f994 5016 	ldrsb.w	r5, [r4, #22]
20022700:	9502      	str	r5, [sp, #8]
20022702:	f994 5015 	ldrsb.w	r5, [r4, #21]
20022706:	9501      	str	r5, [sp, #4]
20022708:	f994 4014 	ldrsb.w	r4, [r4, #20]
2002270c:	9400      	str	r4, [sp, #0]
2002270e:	f7ff feb3 	bl	20022478 <HAL_FLASH_MANUAL_CMD>
20022712:	2000      	movs	r0, #0
20022714:	b007      	add	sp, #28
20022716:	bd30      	pop	{r4, r5, pc}
20022718:	2001      	movs	r0, #1
2002271a:	e7fb      	b.n	20022714 <HAL_FLASH_PRE_CMD+0x46>

2002271c <HAL_FLASH_ISSUE_CMD>:
2002271c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002271e:	68c4      	ldr	r4, [r0, #12]
20022720:	4606      	mov	r6, r0
20022722:	4617      	mov	r7, r2
20022724:	b087      	sub	sp, #28
20022726:	b354      	cbz	r4, 2002277e <HAL_FLASH_ISSUE_CMD+0x62>
20022728:	2938      	cmp	r1, #56	@ 0x38
2002272a:	d828      	bhi.n	2002277e <HAL_FLASH_ISSUE_CMD+0x62>
2002272c:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
20022730:	442c      	add	r4, r5
20022732:	7c23      	ldrb	r3, [r4, #16]
20022734:	b31b      	cbz	r3, 2002277e <HAL_FLASH_ISSUE_CMD+0x62>
20022736:	f994 c018 	ldrsb.w	ip, [r4, #24]
2002273a:	f994 3013 	ldrsb.w	r3, [r4, #19]
2002273e:	f994 2012 	ldrsb.w	r2, [r4, #18]
20022742:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022746:	f8cd c010 	str.w	ip, [sp, #16]
2002274a:	f994 c017 	ldrsb.w	ip, [r4, #23]
2002274e:	f8cd c00c 	str.w	ip, [sp, #12]
20022752:	f994 c016 	ldrsb.w	ip, [r4, #22]
20022756:	f8cd c008 	str.w	ip, [sp, #8]
2002275a:	f994 c015 	ldrsb.w	ip, [r4, #21]
2002275e:	f8cd c004 	str.w	ip, [sp, #4]
20022762:	f994 4014 	ldrsb.w	r4, [r4, #20]
20022766:	9400      	str	r4, [sp, #0]
20022768:	f7ff fe86 	bl	20022478 <HAL_FLASH_MANUAL_CMD>
2002276c:	68f3      	ldr	r3, [r6, #12]
2002276e:	463a      	mov	r2, r7
20022770:	442b      	add	r3, r5
20022772:	4630      	mov	r0, r6
20022774:	7c19      	ldrb	r1, [r3, #16]
20022776:	f7ff fe3f 	bl	200223f8 <HAL_FLASH_SET_CMD>
2002277a:	b007      	add	sp, #28
2002277c:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002277e:	2001      	movs	r0, #1
20022780:	e7fb      	b.n	2002277a <HAL_FLASH_ISSUE_CMD+0x5e>

20022782 <HAL_FLASH_ISSUE_CMD_SEQ>:
20022782:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20022786:	4690      	mov	r8, r2
20022788:	68c2      	ldr	r2, [r0, #12]
2002278a:	4604      	mov	r4, r0
2002278c:	b086      	sub	sp, #24
2002278e:	2a00      	cmp	r2, #0
20022790:	d073      	beq.n	2002287a <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022792:	2938      	cmp	r1, #56	@ 0x38
20022794:	d871      	bhi.n	2002287a <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022796:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
2002279a:	19d6      	adds	r6, r2, r7
2002279c:	7c31      	ldrb	r1, [r6, #16]
2002279e:	2900      	cmp	r1, #0
200227a0:	d06b      	beq.n	2002287a <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200227a2:	2b38      	cmp	r3, #56	@ 0x38
200227a4:	d869      	bhi.n	2002287a <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200227a6:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
200227aa:	442a      	add	r2, r5
200227ac:	7c13      	ldrb	r3, [r2, #16]
200227ae:	2b00      	cmp	r3, #0
200227b0:	d063      	beq.n	2002287a <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
200227b2:	f996 c018 	ldrsb.w	ip, [r6, #24]
200227b6:	f996 3013 	ldrsb.w	r3, [r6, #19]
200227ba:	f996 2012 	ldrsb.w	r2, [r6, #18]
200227be:	f996 1011 	ldrsb.w	r1, [r6, #17]
200227c2:	f8cd c010 	str.w	ip, [sp, #16]
200227c6:	f996 c017 	ldrsb.w	ip, [r6, #23]
200227ca:	f8cd c00c 	str.w	ip, [sp, #12]
200227ce:	f996 c016 	ldrsb.w	ip, [r6, #22]
200227d2:	f8cd c008 	str.w	ip, [sp, #8]
200227d6:	f996 c015 	ldrsb.w	ip, [r6, #21]
200227da:	f8cd c004 	str.w	ip, [sp, #4]
200227de:	f996 6014 	ldrsb.w	r6, [r6, #20]
200227e2:	9600      	str	r6, [sp, #0]
200227e4:	f7ff fe48 	bl	20022478 <HAL_FLASH_MANUAL_CMD>
200227e8:	68e0      	ldr	r0, [r4, #12]
200227ea:	4428      	add	r0, r5
200227ec:	f990 6018 	ldrsb.w	r6, [r0, #24]
200227f0:	f990 3013 	ldrsb.w	r3, [r0, #19]
200227f4:	f990 2012 	ldrsb.w	r2, [r0, #18]
200227f8:	f990 1011 	ldrsb.w	r1, [r0, #17]
200227fc:	9604      	str	r6, [sp, #16]
200227fe:	f990 6017 	ldrsb.w	r6, [r0, #23]
20022802:	9603      	str	r6, [sp, #12]
20022804:	f990 6016 	ldrsb.w	r6, [r0, #22]
20022808:	9602      	str	r6, [sp, #8]
2002280a:	f990 6015 	ldrsb.w	r6, [r0, #21]
2002280e:	9601      	str	r6, [sp, #4]
20022810:	f990 0014 	ldrsb.w	r0, [r0, #20]
20022814:	9000      	str	r0, [sp, #0]
20022816:	4620      	mov	r0, r4
20022818:	f7ff fe4f 	bl	200224ba <HAL_FLASH_MANUAL_CMD2>
2002281c:	2200      	movs	r2, #0
2002281e:	6823      	ldr	r3, [r4, #0]
20022820:	2101      	movs	r1, #1
20022822:	f8c3 2084 	str.w	r2, [r3, #132]	@ 0x84
20022826:	68e3      	ldr	r3, [r4, #12]
20022828:	6822      	ldr	r2, [r4, #0]
2002282a:	442b      	add	r3, r5
2002282c:	7c1b      	ldrb	r3, [r3, #16]
2002282e:	4620      	mov	r0, r4
20022830:	62d3      	str	r3, [r2, #44]	@ 0x2c
20022832:	6823      	ldr	r3, [r4, #0]
20022834:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
20022836:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
2002283a:	f7ff fe88 	bl	2002254e <HAL_FLASH_ENABLE_CMD2>
2002283e:	4620      	mov	r0, r4
20022840:	f7ff fe93 	bl	2002256a <HAL_FLASH_STAUS_MATCH_CMD2>
20022844:	6823      	ldr	r3, [r4, #0]
20022846:	f8c3 801c 	str.w	r8, [r3, #28]
2002284a:	68e3      	ldr	r3, [r4, #12]
2002284c:	6822      	ldr	r2, [r4, #0]
2002284e:	443b      	add	r3, r7
20022850:	7c1b      	ldrb	r3, [r3, #16]
20022852:	6193      	str	r3, [r2, #24]
20022854:	4620      	mov	r0, r4
20022856:	f7ff fdf1 	bl	2002243c <HAL_FLASH_STATUS_MATCH>
2002285a:	2800      	cmp	r0, #0
2002285c:	d0fa      	beq.n	20022854 <HAL_FLASH_ISSUE_CMD_SEQ+0xd2>
2002285e:	2109      	movs	r1, #9
20022860:	4620      	mov	r0, r4
20022862:	f7ff fde5 	bl	20022430 <HAL_FLASH_CLR_STATUS>
20022866:	2100      	movs	r1, #0
20022868:	f7ff fe71 	bl	2002254e <HAL_FLASH_ENABLE_CMD2>
2002286c:	4620      	mov	r0, r4
2002286e:	f7ff fe7c 	bl	2002256a <HAL_FLASH_STAUS_MATCH_CMD2>
20022872:	4608      	mov	r0, r1
20022874:	b006      	add	sp, #24
20022876:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002287a:	2001      	movs	r0, #1
2002287c:	e7fa      	b.n	20022874 <HAL_FLASH_ISSUE_CMD_SEQ+0xf2>

2002287e <nor_qspi_switch>:
2002287e:	b570      	push	{r4, r5, r6, lr}
20022880:	4604      	mov	r4, r0
20022882:	b3e0      	cbz	r0, 200228fe <nor_qspi_switch+0x80>
20022884:	68c3      	ldr	r3, [r0, #12]
20022886:	b3d3      	cbz	r3, 200228fe <nor_qspi_switch+0x80>
20022888:	b3c9      	cbz	r1, 200228fe <nor_qspi_switch+0x80>
2002288a:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
2002288e:	2101      	movs	r1, #1
20022890:	b3b5      	cbz	r5, 20022900 <nor_qspi_switch+0x82>
20022892:	f7ff fd90 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022896:	2200      	movs	r2, #0
20022898:	2114      	movs	r1, #20
2002289a:	4620      	mov	r0, r4
2002289c:	f7ff ff3e 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200228a0:	4620      	mov	r0, r4
200228a2:	f7ff fdda 	bl	2002245a <HAL_FLASH_READ32>
200228a6:	f010 0501 	ands.w	r5, r0, #1
200228aa:	d000      	beq.n	200228ae <nor_qspi_switch+0x30>
200228ac:	e7fe      	b.n	200228ac <nor_qspi_switch+0x2e>
200228ae:	462a      	mov	r2, r5
200228b0:	2115      	movs	r1, #21
200228b2:	4620      	mov	r0, r4
200228b4:	f7ff ff32 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200228b8:	4606      	mov	r6, r0
200228ba:	b120      	cbz	r0, 200228c6 <nor_qspi_switch+0x48>
200228bc:	462a      	mov	r2, r5
200228be:	4629      	mov	r1, r5
200228c0:	4620      	mov	r0, r4
200228c2:	f7ff ff2b 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200228c6:	2102      	movs	r1, #2
200228c8:	4620      	mov	r0, r4
200228ca:	f7ff fd6d 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
200228ce:	2101      	movs	r1, #1
200228d0:	4620      	mov	r0, r4
200228d2:	f7ff fd70 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
200228d6:	2200      	movs	r2, #0
200228d8:	212b      	movs	r1, #43	@ 0x2b
200228da:	4620      	mov	r0, r4
200228dc:	f7ff ff1e 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200228e0:	b16e      	cbz	r6, 200228fe <nor_qspi_switch+0x80>
200228e2:	2101      	movs	r1, #1
200228e4:	4620      	mov	r0, r4
200228e6:	f7ff fd66 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
200228ea:	2200      	movs	r2, #0
200228ec:	2102      	movs	r1, #2
200228ee:	4620      	mov	r0, r4
200228f0:	f7ff ff14 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200228f4:	4620      	mov	r0, r4
200228f6:	f7ff fda7 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
200228fa:	2800      	cmp	r0, #0
200228fc:	d0f5      	beq.n	200228ea <nor_qspi_switch+0x6c>
200228fe:	bd70      	pop	{r4, r5, r6, pc}
20022900:	f7ff fd59 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022904:	462a      	mov	r2, r5
20022906:	2102      	movs	r1, #2
20022908:	4620      	mov	r0, r4
2002290a:	f7ff ff07 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002290e:	4620      	mov	r0, r4
20022910:	f7ff fda3 	bl	2002245a <HAL_FLASH_READ32>
20022914:	462a      	mov	r2, r5
20022916:	2114      	movs	r1, #20
20022918:	4620      	mov	r0, r4
2002291a:	f7ff feff 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002291e:	b910      	cbnz	r0, 20022926 <nor_qspi_switch+0xa8>
20022920:	4620      	mov	r0, r4
20022922:	f7ff fd9a 	bl	2002245a <HAL_FLASH_READ32>
20022926:	68e3      	ldr	r3, [r4, #12]
20022928:	7a1b      	ldrb	r3, [r3, #8]
2002292a:	b3ab      	cbz	r3, 20022998 <nor_qspi_switch+0x11a>
2002292c:	2101      	movs	r1, #1
2002292e:	f003 050f 	and.w	r5, r3, #15
20022932:	091b      	lsrs	r3, r3, #4
20022934:	fa01 f303 	lsl.w	r3, r1, r3
20022938:	b2db      	uxtb	r3, r3
2002293a:	b10d      	cbz	r5, 20022940 <nor_qspi_switch+0xc2>
2002293c:	461d      	mov	r5, r3
2002293e:	2300      	movs	r3, #0
20022940:	2200      	movs	r2, #0
20022942:	2115      	movs	r1, #21
20022944:	4620      	mov	r0, r4
20022946:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
2002294a:	f7ff fee7 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002294e:	4606      	mov	r6, r0
20022950:	b120      	cbz	r0, 2002295c <nor_qspi_switch+0xde>
20022952:	2200      	movs	r2, #0
20022954:	4620      	mov	r0, r4
20022956:	4611      	mov	r1, r2
20022958:	f7ff fee0 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002295c:	4629      	mov	r1, r5
2002295e:	4620      	mov	r0, r4
20022960:	f7ff fd22 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20022964:	2102      	movs	r1, #2
20022966:	4620      	mov	r0, r4
20022968:	f7ff fd25 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
2002296c:	2200      	movs	r2, #0
2002296e:	2103      	movs	r1, #3
20022970:	4620      	mov	r0, r4
20022972:	f7ff fed3 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022976:	2e00      	cmp	r6, #0
20022978:	d0c1      	beq.n	200228fe <nor_qspi_switch+0x80>
2002297a:	2101      	movs	r1, #1
2002297c:	4620      	mov	r0, r4
2002297e:	f7ff fd1a 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022982:	2200      	movs	r2, #0
20022984:	2102      	movs	r1, #2
20022986:	4620      	mov	r0, r4
20022988:	f7ff fec8 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002298c:	4620      	mov	r0, r4
2002298e:	f7ff fd5b 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
20022992:	2800      	cmp	r0, #0
20022994:	d0f5      	beq.n	20022982 <nor_qspi_switch+0x104>
20022996:	e7b2      	b.n	200228fe <nor_qspi_switch+0x80>
20022998:	2502      	movs	r5, #2
2002299a:	e7d1      	b.n	20022940 <nor_qspi_switch+0xc2>

2002299c <HAL_FLASH_SET_QUAL_SPI>:
2002299c:	b538      	push	{r3, r4, r5, lr}
2002299e:	4604      	mov	r4, r0
200229a0:	460d      	mov	r5, r1
200229a2:	f7ff ff6c 	bl	2002287e <nor_qspi_switch>
200229a6:	4629      	mov	r1, r5
200229a8:	4620      	mov	r0, r4
200229aa:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200229ae:	f7ff be0d 	b.w	200225cc <HAL_FLASH_CONFIG_AHB_READ>

200229b2 <HAL_FLASH_FADDR_SET_QSPI>:
200229b2:	b538      	push	{r3, r4, r5, lr}
200229b4:	4604      	mov	r4, r0
200229b6:	460d      	mov	r5, r1
200229b8:	f7ff ff61 	bl	2002287e <nor_qspi_switch>
200229bc:	4629      	mov	r1, r5
200229be:	4620      	mov	r0, r4
200229c0:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200229c4:	f7ff be46 	b.w	20022654 <HAL_FLASH_CONFIG_FULL_AHB_READ>

200229c8 <HAL_FLASH_GET_NOR_ID>:
200229c8:	b510      	push	{r4, lr}
200229ca:	4604      	mov	r4, r0
200229cc:	b140      	cbz	r0, 200229e0 <HAL_FLASH_GET_NOR_ID+0x18>
200229ce:	6802      	ldr	r2, [r0, #0]
200229d0:	6a93      	ldr	r3, [r2, #40]	@ 0x28
200229d2:	f36f 0315 	bfc	r3, #0, #22
200229d6:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
200229da:	f043 0301 	orr.w	r3, r3, #1
200229de:	6293      	str	r3, [r2, #40]	@ 0x28
200229e0:	2103      	movs	r1, #3
200229e2:	4620      	mov	r0, r4
200229e4:	f7ff fce7 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
200229e8:	2200      	movs	r2, #0
200229ea:	219f      	movs	r1, #159	@ 0x9f
200229ec:	4620      	mov	r0, r4
200229ee:	f7ff fd03 	bl	200223f8 <HAL_FLASH_SET_CMD>
200229f2:	4620      	mov	r0, r4
200229f4:	f7ff fd31 	bl	2002245a <HAL_FLASH_READ32>
200229f8:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
200229fc:	bd10      	pop	{r4, pc}

200229fe <HAL_FLASH_CLR_PROTECT>:
200229fe:	b570      	push	{r4, r5, r6, lr}
20022a00:	4604      	mov	r4, r0
20022a02:	2800      	cmp	r0, #0
20022a04:	d03e      	beq.n	20022a84 <HAL_FLASH_CLR_PROTECT+0x86>
20022a06:	68c3      	ldr	r3, [r0, #12]
20022a08:	2101      	movs	r1, #1
20022a0a:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022a0e:	2d00      	cmp	r5, #0
20022a10:	d03b      	beq.n	20022a8a <HAL_FLASH_CLR_PROTECT+0x8c>
20022a12:	f7ff fcd0 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022a16:	2200      	movs	r2, #0
20022a18:	2102      	movs	r1, #2
20022a1a:	4620      	mov	r0, r4
20022a1c:	f7ff fe7e 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a20:	bb88      	cbnz	r0, 20022a86 <HAL_FLASH_CLR_PROTECT+0x88>
20022a22:	4620      	mov	r0, r4
20022a24:	f7ff fd19 	bl	2002245a <HAL_FLASH_READ32>
20022a28:	b2c0      	uxtb	r0, r0
20022a2a:	68e3      	ldr	r3, [r4, #12]
20022a2c:	79dd      	ldrb	r5, [r3, #7]
20022a2e:	b10d      	cbz	r5, 20022a34 <HAL_FLASH_CLR_PROTECT+0x36>
20022a30:	ea20 0505 	bic.w	r5, r0, r5
20022a34:	2200      	movs	r2, #0
20022a36:	2115      	movs	r1, #21
20022a38:	4620      	mov	r0, r4
20022a3a:	f7ff fe6f 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a3e:	4606      	mov	r6, r0
20022a40:	b120      	cbz	r0, 20022a4c <HAL_FLASH_CLR_PROTECT+0x4e>
20022a42:	2200      	movs	r2, #0
20022a44:	4620      	mov	r0, r4
20022a46:	4611      	mov	r1, r2
20022a48:	f7ff fe68 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a4c:	4629      	mov	r1, r5
20022a4e:	4620      	mov	r0, r4
20022a50:	f7ff fcaa 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20022a54:	2101      	movs	r1, #1
20022a56:	4620      	mov	r0, r4
20022a58:	f7ff fcad 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022a5c:	2200      	movs	r2, #0
20022a5e:	2103      	movs	r1, #3
20022a60:	4620      	mov	r0, r4
20022a62:	f7ff fe5b 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a66:	b16e      	cbz	r6, 20022a84 <HAL_FLASH_CLR_PROTECT+0x86>
20022a68:	2101      	movs	r1, #1
20022a6a:	4620      	mov	r0, r4
20022a6c:	f7ff fca3 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022a70:	2200      	movs	r2, #0
20022a72:	2102      	movs	r1, #2
20022a74:	4620      	mov	r0, r4
20022a76:	f7ff fe51 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a7a:	4620      	mov	r0, r4
20022a7c:	f7ff fce4 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
20022a80:	2800      	cmp	r0, #0
20022a82:	d0f5      	beq.n	20022a70 <HAL_FLASH_CLR_PROTECT+0x72>
20022a84:	bd70      	pop	{r4, r5, r6, pc}
20022a86:	2000      	movs	r0, #0
20022a88:	e7cf      	b.n	20022a2a <HAL_FLASH_CLR_PROTECT+0x2c>
20022a8a:	f7ff fc94 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022a8e:	462a      	mov	r2, r5
20022a90:	2102      	movs	r1, #2
20022a92:	4620      	mov	r0, r4
20022a94:	f7ff fe42 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022a98:	2800      	cmp	r0, #0
20022a9a:	d13e      	bne.n	20022b1a <HAL_FLASH_CLR_PROTECT+0x11c>
20022a9c:	4620      	mov	r0, r4
20022a9e:	f7ff fcdc 	bl	2002245a <HAL_FLASH_READ32>
20022aa2:	b2c6      	uxtb	r6, r0
20022aa4:	2200      	movs	r2, #0
20022aa6:	2114      	movs	r1, #20
20022aa8:	4620      	mov	r0, r4
20022aaa:	f7ff fe37 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022aae:	b918      	cbnz	r0, 20022ab8 <HAL_FLASH_CLR_PROTECT+0xba>
20022ab0:	4620      	mov	r0, r4
20022ab2:	f7ff fcd2 	bl	2002245a <HAL_FLASH_READ32>
20022ab6:	b2c5      	uxtb	r5, r0
20022ab8:	68e3      	ldr	r3, [r4, #12]
20022aba:	79d9      	ldrb	r1, [r3, #7]
20022abc:	b109      	cbz	r1, 20022ac2 <HAL_FLASH_CLR_PROTECT+0xc4>
20022abe:	ea26 0101 	bic.w	r1, r6, r1
20022ac2:	2200      	movs	r2, #0
20022ac4:	4620      	mov	r0, r4
20022ac6:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20022aca:	2115      	movs	r1, #21
20022acc:	f7ff fe26 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022ad0:	4606      	mov	r6, r0
20022ad2:	b120      	cbz	r0, 20022ade <HAL_FLASH_CLR_PROTECT+0xe0>
20022ad4:	2200      	movs	r2, #0
20022ad6:	4620      	mov	r0, r4
20022ad8:	4611      	mov	r1, r2
20022ada:	f7ff fe1f 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022ade:	4629      	mov	r1, r5
20022ae0:	4620      	mov	r0, r4
20022ae2:	f7ff fc61 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20022ae6:	2102      	movs	r1, #2
20022ae8:	4620      	mov	r0, r4
20022aea:	f7ff fc64 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022aee:	2200      	movs	r2, #0
20022af0:	2103      	movs	r1, #3
20022af2:	4620      	mov	r0, r4
20022af4:	f7ff fe12 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022af8:	2e00      	cmp	r6, #0
20022afa:	d0c3      	beq.n	20022a84 <HAL_FLASH_CLR_PROTECT+0x86>
20022afc:	2101      	movs	r1, #1
20022afe:	4620      	mov	r0, r4
20022b00:	f7ff fc59 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022b04:	2200      	movs	r2, #0
20022b06:	2102      	movs	r1, #2
20022b08:	4620      	mov	r0, r4
20022b0a:	f7ff fe07 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022b0e:	4620      	mov	r0, r4
20022b10:	f7ff fc9a 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
20022b14:	2800      	cmp	r0, #0
20022b16:	d0f5      	beq.n	20022b04 <HAL_FLASH_CLR_PROTECT+0x106>
20022b18:	e7b4      	b.n	20022a84 <HAL_FLASH_CLR_PROTECT+0x86>
20022b1a:	462e      	mov	r6, r5
20022b1c:	e7c2      	b.n	20022aa4 <HAL_FLASH_CLR_PROTECT+0xa6>

20022b1e <HAL_FLASH_PreInit>:
20022b1e:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022b20:	4604      	mov	r4, r0
20022b22:	b358      	cbz	r0, 20022b7c <HAL_FLASH_PreInit+0x5e>
20022b24:	2300      	movs	r3, #0
20022b26:	22ff      	movs	r2, #255	@ 0xff
20022b28:	2101      	movs	r1, #1
20022b2a:	f04f 2650 	mov.w	r6, #1342197760	@ 0x50005000
20022b2e:	6805      	ldr	r5, [r0, #0]
20022b30:	6043      	str	r3, [r0, #4]
20022b32:	f880 102a 	strb.w	r1, [r0, #42]	@ 0x2a
20022b36:	f880 3028 	strb.w	r3, [r0, #40]	@ 0x28
20022b3a:	f8c5 208c 	str.w	r2, [r5, #140]	@ 0x8c
20022b3e:	6805      	ldr	r5, [r0, #0]
20022b40:	f8c5 6080 	str.w	r6, [r5, #128]	@ 0x80
20022b44:	6805      	ldr	r5, [r0, #0]
20022b46:	622a      	str	r2, [r5, #32]
20022b48:	6805      	ldr	r5, [r0, #0]
20022b4a:	646a      	str	r2, [r5, #68]	@ 0x44
20022b4c:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
20022b50:	6083      	str	r3, [r0, #8]
20022b52:	f7ff fcee 	bl	20022532 <HAL_FLASH_ENABLE_QSPI>
20022b56:	4620      	mov	r0, r4
20022b58:	f7ff ff36 	bl	200229c8 <HAL_FLASH_GET_NOR_ID>
20022b5c:	f3c0 2707 	ubfx	r7, r0, #8, #8
20022b60:	f3c0 4507 	ubfx	r5, r0, #16, #8
20022b64:	b2c6      	uxtb	r6, r0
20022b66:	4629      	mov	r1, r5
20022b68:	463a      	mov	r2, r7
20022b6a:	4630      	mov	r0, r6
20022b6c:	f001 fb74 	bl	20024258 <spi_flash_get_cmd_by_id>
20022b70:	4601      	mov	r1, r0
20022b72:	60e0      	str	r0, [r4, #12]
20022b74:	b920      	cbnz	r0, 20022b80 <HAL_FLASH_PreInit+0x62>
20022b76:	4620      	mov	r0, r4
20022b78:	f7ff fcdb 	bl	20022532 <HAL_FLASH_ENABLE_QSPI>
20022b7c:	2001      	movs	r0, #1
20022b7e:	e00a      	b.n	20022b96 <HAL_FLASH_PreInit+0x78>
20022b80:	463a      	mov	r2, r7
20022b82:	4629      	mov	r1, r5
20022b84:	4630      	mov	r0, r6
20022b86:	f001 fb7b 	bl	20024280 <spi_flash_get_size_by_id>
20022b8a:	b100      	cbz	r0, 20022b8e <HAL_FLASH_PreInit+0x70>
20022b8c:	6160      	str	r0, [r4, #20]
20022b8e:	f894 502b 	ldrb.w	r5, [r4, #43]	@ 0x2b
20022b92:	b10d      	cbz	r5, 20022b98 <HAL_FLASH_PreInit+0x7a>
20022b94:	2000      	movs	r0, #0
20022b96:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20022b98:	4620      	mov	r0, r4
20022b9a:	f7ff ff30 	bl	200229fe <HAL_FLASH_CLR_PROTECT>
20022b9e:	6963      	ldr	r3, [r4, #20]
20022ba0:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20022ba4:	d90d      	bls.n	20022bc2 <HAL_FLASH_PreInit+0xa4>
20022ba6:	2121      	movs	r1, #33	@ 0x21
20022ba8:	462a      	mov	r2, r5
20022baa:	4620      	mov	r0, r4
20022bac:	f7ff fdb6 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022bb0:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022bb4:	b919      	cbnz	r1, 20022bbe <HAL_FLASH_PreInit+0xa0>
20022bb6:	4620      	mov	r0, r4
20022bb8:	f7ff fefb 	bl	200229b2 <HAL_FLASH_FADDR_SET_QSPI>
20022bbc:	e7ea      	b.n	20022b94 <HAL_FLASH_PreInit+0x76>
20022bbe:	2101      	movs	r1, #1
20022bc0:	e7f9      	b.n	20022bb6 <HAL_FLASH_PreInit+0x98>
20022bc2:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022bc6:	b919      	cbnz	r1, 20022bd0 <HAL_FLASH_PreInit+0xb2>
20022bc8:	4620      	mov	r0, r4
20022bca:	f7ff fee7 	bl	2002299c <HAL_FLASH_SET_QUAL_SPI>
20022bce:	e7e1      	b.n	20022b94 <HAL_FLASH_PreInit+0x76>
20022bd0:	2101      	movs	r1, #1
20022bd2:	e7f9      	b.n	20022bc8 <HAL_FLASH_PreInit+0xaa>

20022bd4 <HAL_QSPI_SET_CLK_INV>:
20022bd4:	b120      	cbz	r0, 20022be0 <HAL_QSPI_SET_CLK_INV+0xc>
20022bd6:	6802      	ldr	r2, [r0, #0]
20022bd8:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022bda:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20022bde:	6593      	str	r3, [r2, #88]	@ 0x58
20022be0:	4770      	bx	lr

20022be2 <HAL_QSPI_READ_OTP>:
20022be2:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022be6:	4691      	mov	r9, r2
20022be8:	4605      	mov	r5, r0
20022bea:	2800      	cmp	r0, #0
20022bec:	d044      	beq.n	20022c78 <HAL_QSPI_READ_OTP+0x96>
20022bee:	68c4      	ldr	r4, [r0, #12]
20022bf0:	b1b4      	cbz	r4, 20022c20 <HAL_QSPI_READ_OTP+0x3e>
20022bf2:	f5b1 5f80 	cmp.w	r1, #4096	@ 0x1000
20022bf6:	d33f      	bcc.n	20022c78 <HAL_QSPI_READ_OTP+0x96>
20022bf8:	79a2      	ldrb	r2, [r4, #6]
20022bfa:	3201      	adds	r2, #1
20022bfc:	ebb1 3f02 	cmp.w	r1, r2, lsl #12
20022c00:	d23a      	bcs.n	20022c78 <HAL_QSPI_READ_OTP+0x96>
20022c02:	7ae0      	ldrb	r0, [r4, #11]
20022c04:	f3c1 0209 	ubfx	r2, r1, #0, #10
20022c08:	441a      	add	r2, r3
20022c0a:	ebb2 2f00 	cmp.w	r2, r0, lsl #8
20022c0e:	d833      	bhi.n	20022c78 <HAL_QSPI_READ_OTP+0x96>
20022c10:	461c      	mov	r4, r3
20022c12:	2700      	movs	r7, #0
20022c14:	46a2      	mov	sl, r4
20022c16:	6bab      	ldr	r3, [r5, #56]	@ 0x38
20022c18:	18ce      	adds	r6, r1, r3
20022c1a:	f1ba 0f00 	cmp.w	sl, #0
20022c1e:	dc02      	bgt.n	20022c26 <HAL_QSPI_READ_OTP+0x44>
20022c20:	4620      	mov	r0, r4
20022c22:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20022c26:	f1ba 0f40 	cmp.w	sl, #64	@ 0x40
20022c2a:	46d0      	mov	r8, sl
20022c2c:	bfa8      	it	ge
20022c2e:	f04f 0840 	movge.w	r8, #64	@ 0x40
20022c32:	4628      	mov	r0, r5
20022c34:	4641      	mov	r1, r8
20022c36:	f7ff fbbe 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022c3a:	4632      	mov	r2, r6
20022c3c:	2132      	movs	r1, #50	@ 0x32
20022c3e:	4628      	mov	r0, r5
20022c40:	f7ff fd6c 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022c44:	463b      	mov	r3, r7
20022c46:	2f00      	cmp	r7, #0
20022c48:	bfb8      	it	lt
20022c4a:	1cfb      	addlt	r3, r7, #3
20022c4c:	ea4f 01a8 	mov.w	r1, r8, asr #2
20022c50:	f023 0203 	bic.w	r2, r3, #3
20022c54:	eb01 01a3 	add.w	r1, r1, r3, asr #2
20022c58:	444a      	add	r2, r9
20022c5a:	eb09 0181 	add.w	r1, r9, r1, lsl #2
20022c5e:	428a      	cmp	r2, r1
20022c60:	d104      	bne.n	20022c6c <HAL_QSPI_READ_OTP+0x8a>
20022c62:	4447      	add	r7, r8
20022c64:	4446      	add	r6, r8
20022c66:	ebaa 0a08 	sub.w	sl, sl, r8
20022c6a:	e7d6      	b.n	20022c1a <HAL_QSPI_READ_OTP+0x38>
20022c6c:	4628      	mov	r0, r5
20022c6e:	f7ff fbf4 	bl	2002245a <HAL_FLASH_READ32>
20022c72:	f842 0b04 	str.w	r0, [r2], #4
20022c76:	e7f2      	b.n	20022c5e <HAL_QSPI_READ_OTP+0x7c>
20022c78:	2400      	movs	r4, #0
20022c7a:	e7d1      	b.n	20022c20 <HAL_QSPI_READ_OTP+0x3e>

20022c7c <HAL_FLASH_RELEASE_DPD>:
20022c7c:	b538      	push	{r3, r4, r5, lr}
20022c7e:	4604      	mov	r4, r0
20022c80:	b1d0      	cbz	r0, 20022cb8 <HAL_FLASH_RELEASE_DPD+0x3c>
20022c82:	6803      	ldr	r3, [r0, #0]
20022c84:	21ab      	movs	r1, #171	@ 0xab
20022c86:	681d      	ldr	r5, [r3, #0]
20022c88:	f015 0501 	ands.w	r5, r5, #1
20022c8c:	bf02      	ittt	eq
20022c8e:	681a      	ldreq	r2, [r3, #0]
20022c90:	f042 0201 	orreq.w	r2, r2, #1
20022c94:	601a      	streq	r2, [r3, #0]
20022c96:	6802      	ldr	r2, [r0, #0]
20022c98:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022c9a:	f36f 0315 	bfc	r3, #0, #22
20022c9e:	f043 0301 	orr.w	r3, r3, #1
20022ca2:	6293      	str	r3, [r2, #40]	@ 0x28
20022ca4:	2200      	movs	r2, #0
20022ca6:	f7ff fba7 	bl	200223f8 <HAL_FLASH_SET_CMD>
20022caa:	b925      	cbnz	r5, 20022cb6 <HAL_FLASH_RELEASE_DPD+0x3a>
20022cac:	6822      	ldr	r2, [r4, #0]
20022cae:	6813      	ldr	r3, [r2, #0]
20022cb0:	f023 0301 	bic.w	r3, r3, #1
20022cb4:	6013      	str	r3, [r2, #0]
20022cb6:	bd38      	pop	{r3, r4, r5, pc}
20022cb8:	2001      	movs	r0, #1
20022cba:	e7fc      	b.n	20022cb6 <HAL_FLASH_RELEASE_DPD+0x3a>

20022cbc <flash_handle_valid>:
20022cbc:	b118      	cbz	r0, 20022cc6 <flash_handle_valid+0xa>
20022cbe:	68c0      	ldr	r0, [r0, #12]
20022cc0:	3800      	subs	r0, #0
20022cc2:	bf18      	it	ne
20022cc4:	2001      	movne	r0, #1
20022cc6:	4770      	bx	lr

20022cc8 <HAL_GET_FLASH_MID>:
20022cc8:	2000      	movs	r0, #0
20022cca:	4770      	bx	lr

20022ccc <HAL_FLASH_DMA_START>:
20022ccc:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022cd0:	4688      	mov	r8, r1
20022cd2:	4699      	mov	r9, r3
20022cd4:	4604      	mov	r4, r0
20022cd6:	2800      	cmp	r0, #0
20022cd8:	d045      	beq.n	20022d66 <HAL_FLASH_DMA_START+0x9a>
20022cda:	6883      	ldr	r3, [r0, #8]
20022cdc:	2b00      	cmp	r3, #0
20022cde:	d042      	beq.n	20022d66 <HAL_FLASH_DMA_START+0x9a>
20022ce0:	f1b9 0f00 	cmp.w	r9, #0
20022ce4:	d03f      	beq.n	20022d66 <HAL_FLASH_DMA_START+0x9a>
20022ce6:	6801      	ldr	r1, [r0, #0]
20022ce8:	680f      	ldr	r7, [r1, #0]
20022cea:	b332      	cbz	r2, 20022d3a <HAL_FLASH_DMA_START+0x6e>
20022cec:	2210      	movs	r2, #16
20022cee:	609a      	str	r2, [r3, #8]
20022cf0:	2300      	movs	r3, #0
20022cf2:	6882      	ldr	r2, [r0, #8]
20022cf4:	464e      	mov	r6, r9
20022cf6:	6153      	str	r3, [r2, #20]
20022cf8:	6882      	ldr	r2, [r0, #8]
20022cfa:	6193      	str	r3, [r2, #24]
20022cfc:	6882      	ldr	r2, [r0, #8]
20022cfe:	60d3      	str	r3, [r2, #12]
20022d00:	2280      	movs	r2, #128	@ 0x80
20022d02:	6883      	ldr	r3, [r0, #8]
20022d04:	611a      	str	r2, [r3, #16]
20022d06:	6805      	ldr	r5, [r0, #0]
20022d08:	3504      	adds	r5, #4
20022d0a:	68a0      	ldr	r0, [r4, #8]
20022d0c:	f7ff f8d6 	bl	20021ebc <HAL_DMA_DeInit>
20022d10:	bb50      	cbnz	r0, 20022d68 <HAL_FLASH_DMA_START+0x9c>
20022d12:	68a0      	ldr	r0, [r4, #8]
20022d14:	f7ff f866 	bl	20021de4 <HAL_DMA_Init>
20022d18:	bb30      	cbnz	r0, 20022d68 <HAL_FLASH_DMA_START+0x9c>
20022d1a:	6823      	ldr	r3, [r4, #0]
20022d1c:	f047 0720 	orr.w	r7, r7, #32
20022d20:	601f      	str	r7, [r3, #0]
20022d22:	6822      	ldr	r2, [r4, #0]
20022d24:	f109 33ff 	add.w	r3, r9, #4294967295
20022d28:	6253      	str	r3, [r2, #36]	@ 0x24
20022d2a:	4641      	mov	r1, r8
20022d2c:	4633      	mov	r3, r6
20022d2e:	462a      	mov	r2, r5
20022d30:	68a0      	ldr	r0, [r4, #8]
20022d32:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022d36:	f7ff ba37 	b.w	200221a8 <HAL_DMA_Start>
20022d3a:	f44f 7100 	mov.w	r1, #512	@ 0x200
20022d3e:	609a      	str	r2, [r3, #8]
20022d40:	6883      	ldr	r3, [r0, #8]
20022d42:	f109 0603 	add.w	r6, r9, #3
20022d46:	6159      	str	r1, [r3, #20]
20022d48:	f44f 6100 	mov.w	r1, #2048	@ 0x800
20022d4c:	6883      	ldr	r3, [r0, #8]
20022d4e:	4645      	mov	r5, r8
20022d50:	6199      	str	r1, [r3, #24]
20022d52:	6883      	ldr	r3, [r0, #8]
20022d54:	08b6      	lsrs	r6, r6, #2
20022d56:	60da      	str	r2, [r3, #12]
20022d58:	2280      	movs	r2, #128	@ 0x80
20022d5a:	6883      	ldr	r3, [r0, #8]
20022d5c:	611a      	str	r2, [r3, #16]
20022d5e:	6803      	ldr	r3, [r0, #0]
20022d60:	f103 0804 	add.w	r8, r3, #4
20022d64:	e7d1      	b.n	20022d0a <HAL_FLASH_DMA_START+0x3e>
20022d66:	2001      	movs	r0, #1
20022d68:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

20022d6c <HAL_FLASH_DMA_WAIT_DONE>:
20022d6c:	b510      	push	{r4, lr}
20022d6e:	460a      	mov	r2, r1
20022d70:	4604      	mov	r4, r0
20022d72:	b170      	cbz	r0, 20022d92 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022d74:	6880      	ldr	r0, [r0, #8]
20022d76:	b160      	cbz	r0, 20022d92 <HAL_FLASH_DMA_WAIT_DONE+0x26>
20022d78:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20022d7a:	b111      	cbz	r1, 20022d82 <HAL_FLASH_DMA_WAIT_DONE+0x16>
20022d7c:	f04f 32ff 	mov.w	r2, #4294967295
20022d80:	2100      	movs	r1, #0
20022d82:	f7ff f909 	bl	20021f98 <HAL_DMA_PollForTransfer>
20022d86:	6822      	ldr	r2, [r4, #0]
20022d88:	6813      	ldr	r3, [r2, #0]
20022d8a:	f023 0320 	bic.w	r3, r3, #32
20022d8e:	6013      	str	r3, [r2, #0]
20022d90:	bd10      	pop	{r4, pc}
20022d92:	2001      	movs	r0, #1
20022d94:	e7fc      	b.n	20022d90 <HAL_FLASH_DMA_WAIT_DONE+0x24>

20022d96 <HAL_FLASH_ALIAS_CFG>:
20022d96:	b538      	push	{r3, r4, r5, lr}
20022d98:	461d      	mov	r5, r3
20022d9a:	4604      	mov	r4, r0
20022d9c:	b158      	cbz	r0, 20022db6 <HAL_FLASH_ALIAS_CFG+0x20>
20022d9e:	6903      	ldr	r3, [r0, #16]
20022da0:	428b      	cmp	r3, r1
20022da2:	bf98      	it	ls
20022da4:	1ac9      	subls	r1, r1, r3
20022da6:	f7ff fba9 	bl	200224fc <HAL_FLASH_SET_ALIAS_RANGE>
20022daa:	4629      	mov	r1, r5
20022dac:	4620      	mov	r0, r4
20022dae:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022db2:	f7ff bbb5 	b.w	20022520 <HAL_FLASH_SET_ALIAS_OFFSET>
20022db6:	bd38      	pop	{r3, r4, r5, pc}

20022db8 <nand_read_id>:
20022db8:	b510      	push	{r4, lr}
20022dba:	460b      	mov	r3, r1
20022dbc:	4604      	mov	r4, r0
20022dbe:	b086      	sub	sp, #24
20022dc0:	b320      	cbz	r0, 20022e0c <nand_read_id+0x54>
20022dc2:	2908      	cmp	r1, #8
20022dc4:	f04f 0100 	mov.w	r1, #0
20022dc8:	f04f 0201 	mov.w	r2, #1
20022dcc:	bf83      	ittte	hi
20022dce:	460b      	movhi	r3, r1
20022dd0:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
20022dd4:	e9cd 1100 	strdhi	r1, r1, [sp]
20022dd8:	e9cd 1102 	strdls	r1, r1, [sp, #8]
20022ddc:	bf8e      	itee	hi
20022dde:	4619      	movhi	r1, r3
20022de0:	e9cd 1100 	strdls	r1, r1, [sp]
20022de4:	b25b      	sxtbls	r3, r3
20022de6:	9204      	str	r2, [sp, #16]
20022de8:	f7ff fb46 	bl	20022478 <HAL_FLASH_MANUAL_CMD>
20022dec:	2103      	movs	r1, #3
20022dee:	4620      	mov	r0, r4
20022df0:	f7ff fae1 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022df4:	2200      	movs	r2, #0
20022df6:	219f      	movs	r1, #159	@ 0x9f
20022df8:	4620      	mov	r0, r4
20022dfa:	f7ff fafd 	bl	200223f8 <HAL_FLASH_SET_CMD>
20022dfe:	4620      	mov	r0, r4
20022e00:	f7ff fb2b 	bl	2002245a <HAL_FLASH_READ32>
20022e04:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022e08:	b006      	add	sp, #24
20022e0a:	bd10      	pop	{r4, pc}
20022e0c:	20ff      	movs	r0, #255	@ 0xff
20022e0e:	e7fb      	b.n	20022e08 <nand_read_id+0x50>

20022e10 <HAL_NAND_CONF_ECC>:
20022e10:	b538      	push	{r3, r4, r5, lr}
20022e12:	460d      	mov	r5, r1
20022e14:	4604      	mov	r4, r0
20022e16:	b398      	cbz	r0, 20022e80 <HAL_NAND_CONF_ECC+0x70>
20022e18:	68c3      	ldr	r3, [r0, #12]
20022e1a:	b38b      	cbz	r3, 20022e80 <HAL_NAND_CONF_ECC+0x70>
20022e1c:	799a      	ldrb	r2, [r3, #6]
20022e1e:	b392      	cbz	r2, 20022e86 <HAL_NAND_CONF_ECC+0x76>
20022e20:	7a9b      	ldrb	r3, [r3, #10]
20022e22:	b383      	cbz	r3, 20022e86 <HAL_NAND_CONF_ECC+0x76>
20022e24:	2101      	movs	r1, #1
20022e26:	f7ff fac6 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022e2a:	68e3      	ldr	r3, [r4, #12]
20022e2c:	2102      	movs	r1, #2
20022e2e:	799a      	ldrb	r2, [r3, #6]
20022e30:	4620      	mov	r0, r4
20022e32:	f7ff fc73 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022e36:	4620      	mov	r0, r4
20022e38:	f7ff fb0f 	bl	2002245a <HAL_FLASH_READ32>
20022e3c:	68e3      	ldr	r3, [r4, #12]
20022e3e:	7a9b      	ldrb	r3, [r3, #10]
20022e40:	b1dd      	cbz	r5, 20022e7a <HAL_NAND_CONF_ECC+0x6a>
20022e42:	ea43 0100 	orr.w	r1, r3, r0
20022e46:	4620      	mov	r0, r4
20022e48:	f7ff faae 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20022e4c:	2101      	movs	r1, #1
20022e4e:	4620      	mov	r0, r4
20022e50:	f7ff fab1 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022e54:	68e3      	ldr	r3, [r4, #12]
20022e56:	2103      	movs	r1, #3
20022e58:	799a      	ldrb	r2, [r3, #6]
20022e5a:	4620      	mov	r0, r4
20022e5c:	f7ff fc5e 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022e60:	68e3      	ldr	r3, [r4, #12]
20022e62:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20022e66:	2102      	movs	r1, #2
20022e68:	799a      	ldrb	r2, [r3, #6]
20022e6a:	4620      	mov	r0, r4
20022e6c:	f7ff fc56 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022e70:	4620      	mov	r0, r4
20022e72:	f7ff faf2 	bl	2002245a <HAL_FLASH_READ32>
20022e76:	2000      	movs	r0, #0
20022e78:	bd38      	pop	{r3, r4, r5, pc}
20022e7a:	ea20 0103 	bic.w	r1, r0, r3
20022e7e:	e7e2      	b.n	20022e46 <HAL_NAND_CONF_ECC+0x36>
20022e80:	f04f 30ff 	mov.w	r0, #4294967295
20022e84:	e7f8      	b.n	20022e78 <HAL_NAND_CONF_ECC+0x68>
20022e86:	f06f 0001 	mvn.w	r0, #1
20022e8a:	e7f5      	b.n	20022e78 <HAL_NAND_CONF_ECC+0x68>

20022e8c <HAL_NAND_GET_ECC_STATUS>:
20022e8c:	b510      	push	{r4, lr}
20022e8e:	4604      	mov	r4, r0
20022e90:	b320      	cbz	r0, 20022edc <HAL_NAND_GET_ECC_STATUS+0x50>
20022e92:	68c2      	ldr	r2, [r0, #12]
20022e94:	b31a      	cbz	r2, 20022ede <HAL_NAND_GET_ECC_STATUS+0x52>
20022e96:	7913      	ldrb	r3, [r2, #4]
20022e98:	b31b      	cbz	r3, 20022ee2 <HAL_NAND_GET_ECC_STATUS+0x56>
20022e9a:	79d3      	ldrb	r3, [r2, #7]
20022e9c:	b30b      	cbz	r3, 20022ee2 <HAL_NAND_GET_ECC_STATUS+0x56>
20022e9e:	2101      	movs	r1, #1
20022ea0:	f7ff fa89 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20022ea4:	68e3      	ldr	r3, [r4, #12]
20022ea6:	2102      	movs	r1, #2
20022ea8:	791a      	ldrb	r2, [r3, #4]
20022eaa:	4620      	mov	r0, r4
20022eac:	f7ff fc36 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20022eb0:	4620      	mov	r0, r4
20022eb2:	f7ff fad2 	bl	2002245a <HAL_FLASH_READ32>
20022eb6:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
20022eba:	2a3f      	cmp	r2, #63	@ 0x3f
20022ebc:	ea4f 1312 	mov.w	r3, r2, lsr #4
20022ec0:	d804      	bhi.n	20022ecc <HAL_NAND_GET_ECC_STATUS+0x40>
20022ec2:	2b01      	cmp	r3, #1
20022ec4:	d808      	bhi.n	20022ed8 <HAL_NAND_GET_ECC_STATUS+0x4c>
20022ec6:	f000 0030 	and.w	r0, r0, #48	@ 0x30
20022eca:	e007      	b.n	20022edc <HAL_NAND_GET_ECC_STATUS+0x50>
20022ecc:	3b04      	subs	r3, #4
20022ece:	2b01      	cmp	r3, #1
20022ed0:	d8f9      	bhi.n	20022ec6 <HAL_NAND_GET_ECC_STATUS+0x3a>
20022ed2:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
20022ed6:	e001      	b.n	20022edc <HAL_NAND_GET_ECC_STATUS+0x50>
20022ed8:	f000 0070 	and.w	r0, r0, #112	@ 0x70
20022edc:	bd10      	pop	{r4, pc}
20022ede:	4610      	mov	r0, r2
20022ee0:	e7fc      	b.n	20022edc <HAL_NAND_GET_ECC_STATUS+0x50>
20022ee2:	4618      	mov	r0, r3
20022ee4:	e7fa      	b.n	20022edc <HAL_NAND_GET_ECC_STATUS+0x50>
	...

20022ee8 <HAL_NAND_CHECK_ECC>:
20022ee8:	4603      	mov	r3, r0
20022eea:	1108      	asrs	r0, r1, #4
20022eec:	b172      	cbz	r2, 20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022eee:	2b07      	cmp	r3, #7
20022ef0:	d80c      	bhi.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022ef2:	e8df f003 	tbb	[pc, r3]
20022ef6:	0d04      	.short	0x0d04
20022ef8:	3f352e18 	.word	0x3f352e18
20022efc:	4c47      	.short	0x4c47
20022efe:	b128      	cbz	r0, 20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f00:	2801      	cmp	r0, #1
20022f02:	6813      	ldr	r3, [r2, #0]
20022f04:	d10a      	bne.n	20022f1c <HAL_NAND_CHECK_ECC+0x34>
20022f06:	f043 0301 	orr.w	r3, r3, #1
20022f0a:	6013      	str	r3, [r2, #0]
20022f0c:	2000      	movs	r0, #0
20022f0e:	4770      	bx	lr
20022f10:	f020 0302 	bic.w	r3, r0, #2
20022f14:	2b01      	cmp	r3, #1
20022f16:	d003      	beq.n	20022f20 <HAL_NAND_CHECK_ECC+0x38>
20022f18:	b1d0      	cbz	r0, 20022f50 <HAL_NAND_CHECK_ECC+0x68>
20022f1a:	6813      	ldr	r3, [r2, #0]
20022f1c:	4303      	orrs	r3, r0
20022f1e:	e016      	b.n	20022f4e <HAL_NAND_CHECK_ECC+0x66>
20022f20:	6813      	ldr	r3, [r2, #0]
20022f22:	4303      	orrs	r3, r0
20022f24:	e7f1      	b.n	20022f0a <HAL_NAND_CHECK_ECC+0x22>
20022f26:	2805      	cmp	r0, #5
20022f28:	d8f7      	bhi.n	20022f1a <HAL_NAND_CHECK_ECC+0x32>
20022f2a:	a301      	add	r3, pc, #4	@ (adr r3, 20022f30 <HAL_NAND_CHECK_ECC+0x48>)
20022f2c:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
20022f30:	20022f0d 	.word	0x20022f0d
20022f34:	20022f21 	.word	0x20022f21
20022f38:	20022f49 	.word	0x20022f49
20022f3c:	20022f21 	.word	0x20022f21
20022f40:	20022f1b 	.word	0x20022f1b
20022f44:	20022f21 	.word	0x20022f21
20022f48:	6813      	ldr	r3, [r2, #0]
20022f4a:	f043 0302 	orr.w	r3, r3, #2
20022f4e:	6013      	str	r3, [r2, #0]
20022f50:	4770      	bx	lr
20022f52:	2800      	cmp	r0, #0
20022f54:	d0da      	beq.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f56:	1e43      	subs	r3, r0, #1
20022f58:	2b05      	cmp	r3, #5
20022f5a:	6813      	ldr	r3, [r2, #0]
20022f5c:	d9e1      	bls.n	20022f22 <HAL_NAND_CHECK_ECC+0x3a>
20022f5e:	e7dd      	b.n	20022f1c <HAL_NAND_CHECK_ECC+0x34>
20022f60:	07c3      	lsls	r3, r0, #31
20022f62:	f000 0103 	and.w	r1, r0, #3
20022f66:	d402      	bmi.n	20022f6e <HAL_NAND_CHECK_ECC+0x86>
20022f68:	2900      	cmp	r1, #0
20022f6a:	d0cf      	beq.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f6c:	e7d5      	b.n	20022f1a <HAL_NAND_CHECK_ECC+0x32>
20022f6e:	6813      	ldr	r3, [r2, #0]
20022f70:	430b      	orrs	r3, r1
20022f72:	e7ca      	b.n	20022f0a <HAL_NAND_CHECK_ECC+0x22>
20022f74:	2800      	cmp	r0, #0
20022f76:	d0c9      	beq.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f78:	6813      	ldr	r3, [r2, #0]
20022f7a:	2808      	cmp	r0, #8
20022f7c:	ea43 0300 	orr.w	r3, r3, r0
20022f80:	dce5      	bgt.n	20022f4e <HAL_NAND_CHECK_ECC+0x66>
20022f82:	e7c2      	b.n	20022f0a <HAL_NAND_CHECK_ECC+0x22>
20022f84:	2800      	cmp	r0, #0
20022f86:	d0c1      	beq.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f88:	1e43      	subs	r3, r0, #1
20022f8a:	2b01      	cmp	r3, #1
20022f8c:	e7e5      	b.n	20022f5a <HAL_NAND_CHECK_ECC+0x72>
20022f8e:	2800      	cmp	r0, #0
20022f90:	d0bc      	beq.n	20022f0c <HAL_NAND_CHECK_ECC+0x24>
20022f92:	1e43      	subs	r3, r0, #1
20022f94:	2b02      	cmp	r3, #2
20022f96:	e7e0      	b.n	20022f5a <HAL_NAND_CHECK_ECC+0x72>

20022f98 <HAL_NAND_GET_ECC_RESULT>:
20022f98:	b510      	push	{r4, lr}
20022f9a:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
20022f9e:	4604      	mov	r4, r0
20022fa0:	b90b      	cbnz	r3, 20022fa6 <HAL_NAND_GET_ECC_RESULT+0xe>
20022fa2:	2000      	movs	r0, #0
20022fa4:	bd10      	pop	{r4, pc}
20022fa6:	f7ff ff71 	bl	20022e8c <HAL_NAND_GET_ECC_STATUS>
20022faa:	4601      	mov	r1, r0
20022fac:	2800      	cmp	r0, #0
20022fae:	d0f8      	beq.n	20022fa2 <HAL_NAND_GET_ECC_RESULT+0xa>
20022fb0:	6862      	ldr	r2, [r4, #4]
20022fb2:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
20022fb4:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
20022fb8:	6062      	str	r2, [r4, #4]
20022fba:	b938      	cbnz	r0, 20022fcc <HAL_NAND_GET_ECC_RESULT+0x34>
20022fbc:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
20022fc0:	1d22      	adds	r2, r4, #4
20022fc2:	0900      	lsrs	r0, r0, #4
20022fc4:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20022fc8:	f7ff bf8e 	b.w	20022ee8 <HAL_NAND_CHECK_ECC>
20022fcc:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
20022fd0:	ea4f 1321 	mov.w	r3, r1, asr #4
20022fd4:	db00      	blt.n	20022fd8 <HAL_NAND_GET_ECC_RESULT+0x40>
20022fd6:	e7fe      	b.n	20022fd6 <HAL_NAND_GET_ECC_RESULT+0x3e>
20022fd8:	6801      	ldr	r1, [r0, #0]
20022fda:	40d9      	lsrs	r1, r3
20022fdc:	f011 0f01 	tst.w	r1, #1
20022fe0:	bf18      	it	ne
20022fe2:	4618      	movne	r0, r3
20022fe4:	ea43 0302 	orr.w	r3, r3, r2
20022fe8:	bf08      	it	eq
20022fea:	2000      	moveq	r0, #0
20022fec:	6063      	str	r3, [r4, #4]
20022fee:	e7d9      	b.n	20022fa4 <HAL_NAND_GET_ECC_RESULT+0xc>

20022ff0 <HAL_NAND_EN_QUAL>:
20022ff0:	b538      	push	{r3, r4, r5, lr}
20022ff2:	460d      	mov	r5, r1
20022ff4:	4604      	mov	r4, r0
20022ff6:	b348      	cbz	r0, 2002304c <HAL_NAND_EN_QUAL+0x5c>
20022ff8:	68c3      	ldr	r3, [r0, #12]
20022ffa:	b33b      	cbz	r3, 2002304c <HAL_NAND_EN_QUAL+0x5c>
20022ffc:	799a      	ldrb	r2, [r3, #6]
20022ffe:	b10a      	cbz	r2, 20023004 <HAL_NAND_EN_QUAL+0x14>
20023000:	7a1b      	ldrb	r3, [r3, #8]
20023002:	b90b      	cbnz	r3, 20023008 <HAL_NAND_EN_QUAL+0x18>
20023004:	2000      	movs	r0, #0
20023006:	bd38      	pop	{r3, r4, r5, pc}
20023008:	2101      	movs	r1, #1
2002300a:	f7ff f9d4 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
2002300e:	68e3      	ldr	r3, [r4, #12]
20023010:	2102      	movs	r1, #2
20023012:	799a      	ldrb	r2, [r3, #6]
20023014:	4620      	mov	r0, r4
20023016:	f7ff fb81 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002301a:	4620      	mov	r0, r4
2002301c:	f7ff fa1d 	bl	2002245a <HAL_FLASH_READ32>
20023020:	68e3      	ldr	r3, [r4, #12]
20023022:	7a1b      	ldrb	r3, [r3, #8]
20023024:	b17d      	cbz	r5, 20023046 <HAL_NAND_EN_QUAL+0x56>
20023026:	ea43 0100 	orr.w	r1, r3, r0
2002302a:	4620      	mov	r0, r4
2002302c:	f7ff f9bc 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20023030:	2101      	movs	r1, #1
20023032:	4620      	mov	r0, r4
20023034:	f7ff f9bf 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20023038:	68e3      	ldr	r3, [r4, #12]
2002303a:	2103      	movs	r1, #3
2002303c:	4620      	mov	r0, r4
2002303e:	799a      	ldrb	r2, [r3, #6]
20023040:	f7ff fb6c 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023044:	e7de      	b.n	20023004 <HAL_NAND_EN_QUAL+0x14>
20023046:	ea20 0103 	bic.w	r1, r0, r3
2002304a:	e7ee      	b.n	2002302a <HAL_NAND_EN_QUAL+0x3a>
2002304c:	f04f 30ff 	mov.w	r0, #4294967295
20023050:	e7d9      	b.n	20023006 <HAL_NAND_EN_QUAL+0x16>

20023052 <nand_clear_status>:
20023052:	b538      	push	{r3, r4, r5, lr}
20023054:	460d      	mov	r5, r1
20023056:	2101      	movs	r1, #1
20023058:	4604      	mov	r4, r0
2002305a:	f7ff f9ac 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
2002305e:	2dc9      	cmp	r5, #201	@ 0xc9
20023060:	d001      	beq.n	20023066 <nand_clear_status+0x14>
20023062:	2d01      	cmp	r5, #1
20023064:	d109      	bne.n	2002307a <nand_clear_status+0x28>
20023066:	2102      	movs	r1, #2
20023068:	4620      	mov	r0, r4
2002306a:	f7ff f99d 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
2002306e:	68e3      	ldr	r3, [r4, #12]
20023070:	2103      	movs	r1, #3
20023072:	4620      	mov	r0, r4
20023074:	795a      	ldrb	r2, [r3, #5]
20023076:	f7ff fb51 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002307a:	2100      	movs	r1, #0
2002307c:	4620      	mov	r0, r4
2002307e:	f7ff f993 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20023082:	68e3      	ldr	r3, [r4, #12]
20023084:	2103      	movs	r1, #3
20023086:	4620      	mov	r0, r4
20023088:	795a      	ldrb	r2, [r3, #5]
2002308a:	f7ff fb47 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002308e:	2000      	movs	r0, #0
20023090:	bd38      	pop	{r3, r4, r5, pc}

20023092 <HAL_NAND_PAGE_SIZE>:
20023092:	b140      	cbz	r0, 200230a6 <HAL_NAND_PAGE_SIZE+0x14>
20023094:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
20023098:	f013 0f01 	tst.w	r3, #1
2002309c:	bf14      	ite	ne
2002309e:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
200230a2:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
200230a6:	4770      	bx	lr

200230a8 <HAL_NAND_READ_WITHOOB>:
200230a8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200230ac:	b085      	sub	sp, #20
200230ae:	460e      	mov	r6, r1
200230b0:	4691      	mov	r9, r2
200230b2:	461d      	mov	r5, r3
200230b4:	4604      	mov	r4, r0
200230b6:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
200230b8:	b1b0      	cbz	r0, 200230e8 <HAL_NAND_READ_WITHOOB+0x40>
200230ba:	68c3      	ldr	r3, [r0, #12]
200230bc:	b1a3      	cbz	r3, 200230e8 <HAL_NAND_READ_WITHOOB+0x40>
200230be:	69c3      	ldr	r3, [r0, #28]
200230c0:	b193      	cbz	r3, 200230e8 <HAL_NAND_READ_WITHOOB+0x40>
200230c2:	2f80      	cmp	r7, #128	@ 0x80
200230c4:	d810      	bhi.n	200230e8 <HAL_NAND_READ_WITHOOB+0x40>
200230c6:	f7ff ffe4 	bl	20023092 <HAL_NAND_PAGE_SIZE>
200230ca:	f100 3aff 	add.w	sl, r0, #4294967295
200230ce:	ea0a 0a01 	and.w	sl, sl, r1
200230d2:	eb0a 0305 	add.w	r3, sl, r5
200230d6:	4283      	cmp	r3, r0
200230d8:	4680      	mov	r8, r0
200230da:	d907      	bls.n	200230ec <HAL_NAND_READ_WITHOOB+0x44>
200230dc:	2002      	movs	r0, #2
200230de:	6060      	str	r0, [r4, #4]
200230e0:	2000      	movs	r0, #0
200230e2:	b005      	add	sp, #20
200230e4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200230e8:	2001      	movs	r0, #1
200230ea:	e7f8      	b.n	200230de <HAL_NAND_READ_WITHOOB+0x36>
200230ec:	2300      	movs	r3, #0
200230ee:	6063      	str	r3, [r4, #4]
200230f0:	6923      	ldr	r3, [r4, #16]
200230f2:	f04f 0b00 	mov.w	fp, #0
200230f6:	428b      	cmp	r3, r1
200230f8:	bf98      	it	ls
200230fa:	1ace      	subls	r6, r1, r3
200230fc:	fbb6 f2f0 	udiv	r2, r6, r0
20023100:	2104      	movs	r1, #4
20023102:	4620      	mov	r0, r4
20023104:	f7ff fb0a 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023108:	2014      	movs	r0, #20
2002310a:	f7fe fb89 	bl	20021820 <HAL_Delay_us_>
2002310e:	2101      	movs	r1, #1
20023110:	4620      	mov	r0, r4
20023112:	f7ff f950 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20023116:	2005      	movs	r0, #5
20023118:	f7fe fb82 	bl	20021820 <HAL_Delay_us_>
2002311c:	68e2      	ldr	r2, [r4, #12]
2002311e:	2102      	movs	r1, #2
20023120:	7912      	ldrb	r2, [r2, #4]
20023122:	4620      	mov	r0, r4
20023124:	f7ff fafa 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023128:	4620      	mov	r0, r4
2002312a:	f7ff f996 	bl	2002245a <HAL_FLASH_READ32>
2002312e:	07c1      	lsls	r1, r0, #31
20023130:	d4f1      	bmi.n	20023116 <HAL_NAND_READ_WITHOOB+0x6e>
20023132:	f1bb 0f00 	cmp.w	fp, #0
20023136:	d102      	bne.n	2002313e <HAL_NAND_READ_WITHOOB+0x96>
20023138:	f04f 0b01 	mov.w	fp, #1
2002313c:	e7eb      	b.n	20023116 <HAL_NAND_READ_WITHOOB+0x6e>
2002313e:	4620      	mov	r0, r4
20023140:	f7ff ff2a 	bl	20022f98 <HAL_NAND_GET_ECC_RESULT>
20023144:	b110      	cbz	r0, 2002314c <HAL_NAND_READ_WITHOOB+0xa4>
20023146:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
2002314a:	e7c8      	b.n	200230de <HAL_NAND_READ_WITHOOB+0x36>
2002314c:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
20023150:	68e3      	ldr	r3, [r4, #12]
20023152:	bbb2      	cbnz	r2, 200231c2 <HAL_NAND_READ_WITHOOB+0x11a>
20023154:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023158:	4620      	mov	r0, r4
2002315a:	f7ff f8fd 	bl	20022358 <HAL_FLASH_SET_AHB_RCMD>
2002315e:	68e0      	ldr	r0, [r4, #12]
20023160:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
20023164:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023168:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
2002316c:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
20023170:	f8cd c00c 	str.w	ip, [sp, #12]
20023174:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023178:	f8cd c008 	str.w	ip, [sp, #8]
2002317c:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
20023180:	f8cd c004 	str.w	ip, [sp, #4]
20023184:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
20023188:	9000      	str	r0, [sp, #0]
2002318a:	4620      	mov	r0, r4
2002318c:	f7ff f8ef 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
20023190:	03b2      	lsls	r2, r6, #14
20023192:	f8d4 b010 	ldr.w	fp, [r4, #16]
20023196:	d504      	bpl.n	200231a2 <HAL_NAND_READ_WITHOOB+0xfa>
20023198:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
2002319c:	b10a      	cbz	r2, 200231a2 <HAL_NAND_READ_WITHOOB+0xfa>
2002319e:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
200231a2:	ea49 0205 	orr.w	r2, r9, r5
200231a6:	ea42 020a 	orr.w	r2, r2, sl
200231aa:	0793      	lsls	r3, r2, #30
200231ac:	d102      	bne.n	200231b4 <HAL_NAND_READ_WITHOOB+0x10c>
200231ae:	1e6a      	subs	r2, r5, #1
200231b0:	2afe      	cmp	r2, #254	@ 0xfe
200231b2:	d821      	bhi.n	200231f8 <HAL_NAND_READ_WITHOOB+0x150>
200231b4:	462a      	mov	r2, r5
200231b6:	4648      	mov	r0, r9
200231b8:	eb0b 010a 	add.w	r1, fp, sl
200231bc:	f002 fad7 	bl	2002576e <memcpy>
200231c0:	e01d      	b.n	200231fe <HAL_NAND_READ_WITHOOB+0x156>
200231c2:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
200231c6:	4620      	mov	r0, r4
200231c8:	f7ff f8c6 	bl	20022358 <HAL_FLASH_SET_AHB_RCMD>
200231cc:	68e0      	ldr	r0, [r4, #12]
200231ce:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
200231d2:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
200231d6:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
200231da:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
200231de:	f8cd c00c 	str.w	ip, [sp, #12]
200231e2:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
200231e6:	f8cd c008 	str.w	ip, [sp, #8]
200231ea:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
200231ee:	f8cd c004 	str.w	ip, [sp, #4]
200231f2:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
200231f6:	e7c7      	b.n	20023188 <HAL_NAND_READ_WITHOOB+0xe0>
200231f8:	f1b9 0f00 	cmp.w	r9, #0
200231fc:	d1da      	bne.n	200231b4 <HAL_NAND_READ_WITHOOB+0x10c>
200231fe:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
20023200:	b12b      	cbz	r3, 2002320e <HAL_NAND_READ_WITHOOB+0x166>
20023202:	463a      	mov	r2, r7
20023204:	4618      	mov	r0, r3
20023206:	eb0b 0108 	add.w	r1, fp, r8
2002320a:	f002 fab0 	bl	2002576e <memcpy>
2002320e:	1978      	adds	r0, r7, r5
20023210:	e767      	b.n	200230e2 <HAL_NAND_READ_WITHOOB+0x3a>

20023212 <HAL_NAND_BLOCK_SIZE>:
20023212:	b508      	push	{r3, lr}
20023214:	4602      	mov	r2, r0
20023216:	f7ff ff3c 	bl	20023092 <HAL_NAND_PAGE_SIZE>
2002321a:	b128      	cbz	r0, 20023228 <HAL_NAND_BLOCK_SIZE+0x16>
2002321c:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20023220:	079b      	lsls	r3, r3, #30
20023222:	bf4c      	ite	mi
20023224:	01c0      	lslmi	r0, r0, #7
20023226:	0180      	lslpl	r0, r0, #6
20023228:	bd08      	pop	{r3, pc}

2002322a <HAL_NAND_GET_BADBLK>:
2002322a:	b51f      	push	{r0, r1, r2, r3, r4, lr}
2002322c:	4604      	mov	r4, r0
2002322e:	b910      	cbnz	r0, 20023236 <HAL_NAND_GET_BADBLK+0xc>
20023230:	2000      	movs	r0, #0
20023232:	b004      	add	sp, #16
20023234:	bd10      	pop	{r4, pc}
20023236:	6a03      	ldr	r3, [r0, #32]
20023238:	2b00      	cmp	r3, #0
2002323a:	d0f9      	beq.n	20023230 <HAL_NAND_GET_BADBLK+0x6>
2002323c:	f7ff ffe9 	bl	20023212 <HAL_NAND_BLOCK_SIZE>
20023240:	2304      	movs	r3, #4
20023242:	9301      	str	r3, [sp, #4]
20023244:	ab03      	add	r3, sp, #12
20023246:	9300      	str	r3, [sp, #0]
20023248:	2300      	movs	r3, #0
2002324a:	4341      	muls	r1, r0
2002324c:	461a      	mov	r2, r3
2002324e:	4620      	mov	r0, r4
20023250:	f7ff ff2a 	bl	200230a8 <HAL_NAND_READ_WITHOOB>
20023254:	b140      	cbz	r0, 20023268 <HAL_NAND_GET_BADBLK+0x3e>
20023256:	f89d 300c 	ldrb.w	r3, [sp, #12]
2002325a:	2bff      	cmp	r3, #255	@ 0xff
2002325c:	d0e8      	beq.n	20023230 <HAL_NAND_GET_BADBLK+0x6>
2002325e:	9803      	ldr	r0, [sp, #12]
20023260:	2800      	cmp	r0, #0
20023262:	bf08      	it	eq
20023264:	2001      	moveq	r0, #1
20023266:	e7e4      	b.n	20023232 <HAL_NAND_GET_BADBLK+0x8>
20023268:	2001      	movs	r0, #1
2002326a:	e7e2      	b.n	20023232 <HAL_NAND_GET_BADBLK+0x8>

2002326c <HAL_QSPIEX_WRITE_PAGE>:
2002326c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023270:	b099      	sub	sp, #100	@ 0x64
20023272:	4604      	mov	r4, r0
20023274:	460e      	mov	r6, r1
20023276:	4691      	mov	r9, r2
20023278:	f7ff fd20 	bl	20022cbc <flash_handle_valid>
2002327c:	b318      	cbz	r0, 200232c6 <HAL_QSPIEX_WRITE_PAGE+0x5a>
2002327e:	2b00      	cmp	r3, #0
20023280:	f000 80d7 	beq.w	20023432 <HAL_QSPIEX_WRITE_PAGE+0x1c6>
20023284:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20023288:	bf28      	it	cs
2002328a:	f44f 7380 	movcs.w	r3, #256	@ 0x100
2002328e:	68a1      	ldr	r1, [r4, #8]
20023290:	461d      	mov	r5, r3
20023292:	6962      	ldr	r2, [r4, #20]
20023294:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023298:	2900      	cmp	r1, #0
2002329a:	d03b      	beq.n	20023314 <HAL_QSPIEX_WRITE_PAGE+0xa8>
2002329c:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
200232a0:	d914      	bls.n	200232cc <HAL_QSPIEX_WRITE_PAGE+0x60>
200232a2:	2b02      	cmp	r3, #2
200232a4:	bf14      	ite	ne
200232a6:	2727      	movne	r7, #39	@ 0x27
200232a8:	2728      	moveq	r7, #40	@ 0x28
200232aa:	4639      	mov	r1, r7
200232ac:	4620      	mov	r0, r4
200232ae:	f7ff fa0e 	bl	200226ce <HAL_FLASH_PRE_CMD>
200232b2:	4649      	mov	r1, r9
200232b4:	462b      	mov	r3, r5
200232b6:	2201      	movs	r2, #1
200232b8:	4620      	mov	r0, r4
200232ba:	f7ff fd07 	bl	20022ccc <HAL_FLASH_DMA_START>
200232be:	4601      	mov	r1, r0
200232c0:	b148      	cbz	r0, 200232d6 <HAL_QSPIEX_WRITE_PAGE+0x6a>
200232c2:	2500      	movs	r5, #0
200232c4:	4628      	mov	r0, r5
200232c6:	b019      	add	sp, #100	@ 0x64
200232c8:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200232cc:	2b02      	cmp	r3, #2
200232ce:	bf14      	ite	ne
200232d0:	2716      	movne	r7, #22
200232d2:	2717      	moveq	r7, #23
200232d4:	e7e9      	b.n	200232aa <HAL_QSPIEX_WRITE_PAGE+0x3e>
200232d6:	4632      	mov	r2, r6
200232d8:	4620      	mov	r0, r4
200232da:	f7ff fa1f 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200232de:	2101      	movs	r1, #1
200232e0:	4620      	mov	r0, r4
200232e2:	f7ff f872 	bl	200223ca <HAL_FLASH_WRITE_DLEN2>
200232e6:	2301      	movs	r3, #1
200232e8:	4632      	mov	r2, r6
200232ea:	9300      	str	r3, [sp, #0]
200232ec:	4639      	mov	r1, r7
200232ee:	2302      	movs	r3, #2
200232f0:	4620      	mov	r0, r4
200232f2:	f7ff fa46 	bl	20022782 <HAL_FLASH_ISSUE_CMD_SEQ>
200232f6:	2800      	cmp	r0, #0
200232f8:	d1e3      	bne.n	200232c2 <HAL_QSPIEX_WRITE_PAGE+0x56>
200232fa:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
200232fe:	4620      	mov	r0, r4
20023300:	f7ff fd34 	bl	20022d6c <HAL_FLASH_DMA_WAIT_DONE>
20023304:	2800      	cmp	r0, #0
20023306:	d1dc      	bne.n	200232c2 <HAL_QSPIEX_WRITE_PAGE+0x56>
20023308:	6822      	ldr	r2, [r4, #0]
2002330a:	6813      	ldr	r3, [r2, #0]
2002330c:	f023 0320 	bic.w	r3, r3, #32
20023310:	6013      	str	r3, [r2, #0]
20023312:	e7d7      	b.n	200232c4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023314:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023318:	f240 8082 	bls.w	20023420 <HAL_QSPIEX_WRITE_PAGE+0x1b4>
2002331c:	2b02      	cmp	r3, #2
2002331e:	bf14      	ite	ne
20023320:	2327      	movne	r3, #39	@ 0x27
20023322:	2328      	moveq	r3, #40	@ 0x28
20023324:	462f      	mov	r7, r5
20023326:	f04f 0800 	mov.w	r8, #0
2002332a:	9303      	str	r3, [sp, #12]
2002332c:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
20023330:	2f40      	cmp	r7, #64	@ 0x40
20023332:	bfd4      	ite	le
20023334:	ea0a 0a07 	andle.w	sl, sl, r7
20023338:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
2002333c:	f1ba 0f00 	cmp.w	sl, #0
20023340:	d03f      	beq.n	200233c2 <HAL_QSPIEX_WRITE_PAGE+0x156>
20023342:	2200      	movs	r2, #0
20023344:	4620      	mov	r0, r4
20023346:	4611      	mov	r1, r2
20023348:	f7ff f9e8 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002334c:	eb09 0308 	add.w	r3, r9, r8
20023350:	f10d 0c20 	add.w	ip, sp, #32
20023354:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023358:	4662      	mov	r2, ip
2002335a:	6818      	ldr	r0, [r3, #0]
2002335c:	6859      	ldr	r1, [r3, #4]
2002335e:	3308      	adds	r3, #8
20023360:	c203      	stmia	r2!, {r0, r1}
20023362:	4573      	cmp	r3, lr
20023364:	4694      	mov	ip, r2
20023366:	d1f7      	bne.n	20023358 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023368:	f04f 0b00 	mov.w	fp, #0
2002336c:	ea4f 02aa 	mov.w	r2, sl, asr #2
20023370:	ab08      	add	r3, sp, #32
20023372:	f853 1b04 	ldr.w	r1, [r3], #4
20023376:	4620      	mov	r0, r4
20023378:	9205      	str	r2, [sp, #20]
2002337a:	9304      	str	r3, [sp, #16]
2002337c:	f7ff f814 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
20023380:	9a05      	ldr	r2, [sp, #20]
20023382:	f10b 0b01 	add.w	fp, fp, #1
20023386:	4593      	cmp	fp, r2
20023388:	9b04      	ldr	r3, [sp, #16]
2002338a:	d1f2      	bne.n	20023372 <HAL_QSPIEX_WRITE_PAGE+0x106>
2002338c:	4651      	mov	r1, sl
2002338e:	4620      	mov	r0, r4
20023390:	f7ff f811 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
20023394:	4620      	mov	r0, r4
20023396:	9903      	ldr	r1, [sp, #12]
20023398:	eb06 0208 	add.w	r2, r6, r8
2002339c:	f7ff f9be 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200233a0:	2101      	movs	r1, #1
200233a2:	4620      	mov	r0, r4
200233a4:	f7ff f807 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
200233a8:	2200      	movs	r2, #0
200233aa:	2102      	movs	r1, #2
200233ac:	4620      	mov	r0, r4
200233ae:	f7ff f9b5 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200233b2:	4620      	mov	r0, r4
200233b4:	f7ff f848 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
200233b8:	2800      	cmp	r0, #0
200233ba:	d0f1      	beq.n	200233a0 <HAL_QSPIEX_WRITE_PAGE+0x134>
200233bc:	eba7 070a 	sub.w	r7, r7, sl
200233c0:	44d0      	add	r8, sl
200233c2:	1e7b      	subs	r3, r7, #1
200233c4:	2b02      	cmp	r3, #2
200233c6:	d830      	bhi.n	2002342a <HAL_QSPIEX_WRITE_PAGE+0x1be>
200233c8:	6923      	ldr	r3, [r4, #16]
200233ca:	4446      	add	r6, r8
200233cc:	4333      	orrs	r3, r6
200233ce:	681b      	ldr	r3, [r3, #0]
200233d0:	463a      	mov	r2, r7
200233d2:	eb09 0108 	add.w	r1, r9, r8
200233d6:	a807      	add	r0, sp, #28
200233d8:	9307      	str	r3, [sp, #28]
200233da:	f002 f9c8 	bl	2002576e <memcpy>
200233de:	2200      	movs	r2, #0
200233e0:	4620      	mov	r0, r4
200233e2:	4611      	mov	r1, r2
200233e4:	f7ff f99a 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
200233e8:	9907      	ldr	r1, [sp, #28]
200233ea:	4620      	mov	r0, r4
200233ec:	f7fe ffdc 	bl	200223a8 <HAL_FLASH_WRITE_WORD>
200233f0:	2104      	movs	r1, #4
200233f2:	4620      	mov	r0, r4
200233f4:	f7fe ffdf 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
200233f8:	4632      	mov	r2, r6
200233fa:	4620      	mov	r0, r4
200233fc:	9903      	ldr	r1, [sp, #12]
200233fe:	f7ff f98d 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023402:	2101      	movs	r1, #1
20023404:	4620      	mov	r0, r4
20023406:	f7fe ffd6 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
2002340a:	2200      	movs	r2, #0
2002340c:	2102      	movs	r1, #2
2002340e:	4620      	mov	r0, r4
20023410:	f7ff f984 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023414:	4620      	mov	r0, r4
20023416:	f7ff f817 	bl	20022448 <HAL_FLASH_IS_PROG_DONE>
2002341a:	2800      	cmp	r0, #0
2002341c:	d0f1      	beq.n	20023402 <HAL_QSPIEX_WRITE_PAGE+0x196>
2002341e:	e751      	b.n	200232c4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023420:	2b02      	cmp	r3, #2
20023422:	bf14      	ite	ne
20023424:	2316      	movne	r3, #22
20023426:	2317      	moveq	r3, #23
20023428:	e77c      	b.n	20023324 <HAL_QSPIEX_WRITE_PAGE+0xb8>
2002342a:	2f00      	cmp	r7, #0
2002342c:	f73f af7e 	bgt.w	2002332c <HAL_QSPIEX_WRITE_PAGE+0xc0>
20023430:	e748      	b.n	200232c4 <HAL_QSPIEX_WRITE_PAGE+0x58>
20023432:	4618      	mov	r0, r3
20023434:	e747      	b.n	200232c6 <HAL_QSPIEX_WRITE_PAGE+0x5a>

20023436 <HAL_QSPIEX_SECT_ERASE>:
20023436:	b573      	push	{r0, r1, r4, r5, r6, lr}
20023438:	4604      	mov	r4, r0
2002343a:	460d      	mov	r5, r1
2002343c:	f7ff fc3e 	bl	20022cbc <flash_handle_valid>
20023440:	b1e8      	cbz	r0, 2002347e <HAL_QSPIEX_SECT_ERASE+0x48>
20023442:	6963      	ldr	r3, [r4, #20]
20023444:	460a      	mov	r2, r1
20023446:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
2002344a:	f04f 0100 	mov.w	r1, #0
2002344e:	4620      	mov	r0, r4
20023450:	bf94      	ite	ls
20023452:	261b      	movls	r6, #27
20023454:	2629      	movhi	r6, #41	@ 0x29
20023456:	f7ff f961 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
2002345a:	2101      	movs	r1, #1
2002345c:	4620      	mov	r0, r4
2002345e:	f7fe ffb4 	bl	200223ca <HAL_FLASH_WRITE_DLEN2>
20023462:	2301      	movs	r3, #1
20023464:	462a      	mov	r2, r5
20023466:	9300      	str	r3, [sp, #0]
20023468:	4631      	mov	r1, r6
2002346a:	2302      	movs	r3, #2
2002346c:	4620      	mov	r0, r4
2002346e:	f7ff f988 	bl	20022782 <HAL_FLASH_ISSUE_CMD_SEQ>
20023472:	3800      	subs	r0, #0
20023474:	bf18      	it	ne
20023476:	2001      	movne	r0, #1
20023478:	4240      	negs	r0, r0
2002347a:	b002      	add	sp, #8
2002347c:	bd70      	pop	{r4, r5, r6, pc}
2002347e:	f04f 30ff 	mov.w	r0, #4294967295
20023482:	e7fa      	b.n	2002347a <HAL_QSPIEX_SECT_ERASE+0x44>

20023484 <HAL_QSPI_READ_ID>:
20023484:	b138      	cbz	r0, 20023496 <HAL_QSPI_READ_ID+0x12>
20023486:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
2002348a:	b113      	cbz	r3, 20023492 <HAL_QSPI_READ_ID+0xe>
2002348c:	2100      	movs	r1, #0
2002348e:	f7ff bc93 	b.w	20022db8 <nand_read_id>
20023492:	f7ff ba99 	b.w	200229c8 <HAL_FLASH_GET_NOR_ID>
20023496:	20ff      	movs	r0, #255	@ 0xff
20023498:	4770      	bx	lr

2002349a <HAL_NOR_CFG_DTR>:
2002349a:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
2002349c:	4604      	mov	r4, r0
2002349e:	460a      	mov	r2, r1
200234a0:	b351      	cbz	r1, 200234f8 <HAL_NOR_CFG_DTR+0x5e>
200234a2:	68c5      	ldr	r5, [r0, #12]
200234a4:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
200234a8:	2b00      	cmp	r3, #0
200234aa:	d03b      	beq.n	20023524 <HAL_NOR_CFG_DTR+0x8a>
200234ac:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
200234b0:	b3c3      	cbz	r3, 20023524 <HAL_NOR_CFG_DTR+0x8a>
200234b2:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
200234b6:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
200234ba:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
200234be:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
200234c2:	9603      	str	r6, [sp, #12]
200234c4:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
200234c8:	9602      	str	r6, [sp, #8]
200234ca:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
200234ce:	9601      	str	r6, [sp, #4]
200234d0:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
200234d4:	9500      	str	r5, [sp, #0]
200234d6:	f7fe ff4a 	bl	2002236e <HAL_FLASH_CFG_AHB_RCMD>
200234da:	68e3      	ldr	r3, [r4, #12]
200234dc:	4620      	mov	r0, r4
200234de:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
200234e2:	f7fe ff39 	bl	20022358 <HAL_FLASH_SET_AHB_RCMD>
200234e6:	2101      	movs	r1, #1
200234e8:	4620      	mov	r0, r4
200234ea:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
200234ee:	f7ff f862 	bl	200225b6 <HAL_MPI_CFG_DTR>
200234f2:	2000      	movs	r0, #0
200234f4:	b004      	add	sp, #16
200234f6:	bd70      	pop	{r4, r5, r6, pc}
200234f8:	f7ff f85d 	bl	200225b6 <HAL_MPI_CFG_DTR>
200234fc:	6963      	ldr	r3, [r4, #20]
200234fe:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20023502:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023506:	d906      	bls.n	20023516 <HAL_NOR_CFG_DTR+0x7c>
20023508:	b919      	cbnz	r1, 20023512 <HAL_NOR_CFG_DTR+0x78>
2002350a:	4620      	mov	r0, r4
2002350c:	f7ff f8a2 	bl	20022654 <HAL_FLASH_CONFIG_FULL_AHB_READ>
20023510:	e7ef      	b.n	200234f2 <HAL_NOR_CFG_DTR+0x58>
20023512:	2101      	movs	r1, #1
20023514:	e7f9      	b.n	2002350a <HAL_NOR_CFG_DTR+0x70>
20023516:	b919      	cbnz	r1, 20023520 <HAL_NOR_CFG_DTR+0x86>
20023518:	4620      	mov	r0, r4
2002351a:	f7ff f857 	bl	200225cc <HAL_FLASH_CONFIG_AHB_READ>
2002351e:	e7e8      	b.n	200234f2 <HAL_NOR_CFG_DTR+0x58>
20023520:	2101      	movs	r1, #1
20023522:	e7f9      	b.n	20023518 <HAL_NOR_CFG_DTR+0x7e>
20023524:	2001      	movs	r0, #1
20023526:	e7e5      	b.n	200234f4 <HAL_NOR_CFG_DTR+0x5a>

20023528 <HAL_FLASH_Init>:
20023528:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
2002352c:	460e      	mov	r6, r1
2002352e:	4690      	mov	r8, r2
20023530:	461f      	mov	r7, r3
20023532:	4604      	mov	r4, r0
20023534:	b087      	sub	sp, #28
20023536:	2800      	cmp	r0, #0
20023538:	f000 80e5 	beq.w	20023706 <HAL_FLASH_Init+0x1de>
2002353c:	2900      	cmp	r1, #0
2002353e:	f000 80e2 	beq.w	20023706 <HAL_FLASH_Init+0x1de>
20023542:	f7fe fee7 	bl	20022314 <HAL_QSPI_Init>
20023546:	6820      	ldr	r0, [r4, #0]
20023548:	f7ff fbbe 	bl	20022cc8 <HAL_GET_FLASH_MID>
2002354c:	6933      	ldr	r3, [r6, #16]
2002354e:	2100      	movs	r1, #0
20023550:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
20023554:	68b3      	ldr	r3, [r6, #8]
20023556:	4605      	mov	r5, r0
20023558:	64a3      	str	r3, [r4, #72]	@ 0x48
2002355a:	68f3      	ldr	r3, [r6, #12]
2002355c:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
20023560:	051b      	lsls	r3, r3, #20
20023562:	64e3      	str	r3, [r4, #76]	@ 0x4c
20023564:	2302      	movs	r3, #2
20023566:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
2002356a:	6933      	ldr	r3, [r6, #16]
2002356c:	f8c4 8008 	str.w	r8, [r4, #8]
20023570:	1e5a      	subs	r2, r3, #1
20023572:	4253      	negs	r3, r2
20023574:	4153      	adcs	r3, r2
20023576:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
2002357a:	f1b8 0f00 	cmp.w	r8, #0
2002357e:	d058      	beq.n	20023632 <HAL_FLASH_Init+0x10a>
20023580:	2f00      	cmp	r7, #0
20023582:	d056      	beq.n	20023632 <HAL_FLASH_Init+0x10a>
20023584:	683b      	ldr	r3, [r7, #0]
20023586:	f8c8 3000 	str.w	r3, [r8]
2002358a:	68a3      	ldr	r3, [r4, #8]
2002358c:	68fa      	ldr	r2, [r7, #12]
2002358e:	605a      	str	r2, [r3, #4]
20023590:	2210      	movs	r2, #16
20023592:	68a3      	ldr	r3, [r4, #8]
20023594:	609a      	str	r2, [r3, #8]
20023596:	2280      	movs	r2, #128	@ 0x80
20023598:	68a3      	ldr	r3, [r4, #8]
2002359a:	60d9      	str	r1, [r3, #12]
2002359c:	68a3      	ldr	r3, [r4, #8]
2002359e:	611a      	str	r2, [r3, #16]
200235a0:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
200235a4:	68a3      	ldr	r3, [r4, #8]
200235a6:	6159      	str	r1, [r3, #20]
200235a8:	68a3      	ldr	r3, [r4, #8]
200235aa:	6199      	str	r1, [r3, #24]
200235ac:	68a3      	ldr	r3, [r4, #8]
200235ae:	61d9      	str	r1, [r3, #28]
200235b0:	68a3      	ldr	r3, [r4, #8]
200235b2:	621a      	str	r2, [r3, #32]
200235b4:	68a3      	ldr	r3, [r4, #8]
200235b6:	6259      	str	r1, [r3, #36]	@ 0x24
200235b8:	b1c0      	cbz	r0, 200235ec <HAL_FLASH_Init+0xc4>
200235ba:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200235be:	4298      	cmp	r0, r3
200235c0:	d014      	beq.n	200235ec <HAL_FLASH_Init+0xc4>
200235c2:	2701      	movs	r7, #1
200235c4:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200235c8:	2b00      	cmp	r3, #0
200235ca:	d13d      	bne.n	20023648 <HAL_FLASH_Init+0x120>
200235cc:	2f00      	cmp	r7, #0
200235ce:	d15a      	bne.n	20023686 <HAL_FLASH_Init+0x15e>
200235d0:	4620      	mov	r0, r4
200235d2:	f7ff fb53 	bl	20022c7c <HAL_FLASH_RELEASE_DPD>
200235d6:	4638      	mov	r0, r7
200235d8:	f7fe f979 	bl	200218ce <HAL_Delay_us>
200235dc:	2032      	movs	r0, #50	@ 0x32
200235de:	f7fe f976 	bl	200218ce <HAL_Delay_us>
200235e2:	4620      	mov	r0, r4
200235e4:	f7ff ff4e 	bl	20023484 <HAL_QSPI_READ_ID>
200235e8:	4605      	mov	r5, r0
200235ea:	e04c      	b.n	20023686 <HAL_FLASH_Init+0x15e>
200235ec:	2101      	movs	r1, #1
200235ee:	4620      	mov	r0, r4
200235f0:	f7fe ff37 	bl	20022462 <HAL_FLASH_SET_TXSLOT>
200235f4:	4baf      	ldr	r3, [pc, #700]	@ (200238b4 <HAL_FLASH_Init+0x38c>)
200235f6:	69a2      	ldr	r2, [r4, #24]
200235f8:	4620      	mov	r0, r4
200235fa:	429a      	cmp	r2, r3
200235fc:	f04f 0200 	mov.w	r2, #0
20023600:	bf8c      	ite	hi
20023602:	2101      	movhi	r1, #1
20023604:	4611      	movls	r1, r2
20023606:	f7ff fae5 	bl	20022bd4 <HAL_QSPI_SET_CLK_INV>
2002360a:	4620      	mov	r0, r4
2002360c:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
20023610:	f7fe ff2e 	bl	20022470 <HAL_FLASH_SET_CLK_rom>
20023614:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
20023618:	b12b      	cbz	r3, 20023626 <HAL_FLASH_Init+0xfe>
2002361a:	2b01      	cmp	r3, #1
2002361c:	d110      	bne.n	20023640 <HAL_FLASH_Init+0x118>
2002361e:	2100      	movs	r1, #0
20023620:	4620      	mov	r0, r4
20023622:	f7fe ffba 	bl	2002259a <HAL_FLASH_SET_DUAL_MODE>
20023626:	2101      	movs	r1, #1
20023628:	4620      	mov	r0, r4
2002362a:	f7fe ff82 	bl	20022532 <HAL_FLASH_ENABLE_QSPI>
2002362e:	2700      	movs	r7, #0
20023630:	e7c8      	b.n	200235c4 <HAL_FLASH_Init+0x9c>
20023632:	2d00      	cmp	r5, #0
20023634:	d0de      	beq.n	200235f4 <HAL_FLASH_Init+0xcc>
20023636:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
2002363a:	429d      	cmp	r5, r3
2002363c:	d1c1      	bne.n	200235c2 <HAL_FLASH_Init+0x9a>
2002363e:	e7d9      	b.n	200235f4 <HAL_FLASH_Init+0xcc>
20023640:	2b02      	cmp	r3, #2
20023642:	d1f0      	bne.n	20023626 <HAL_FLASH_Init+0xfe>
20023644:	2101      	movs	r1, #1
20023646:	e7eb      	b.n	20023620 <HAL_FLASH_Init+0xf8>
20023648:	6822      	ldr	r2, [r4, #0]
2002364a:	2600      	movs	r6, #0
2002364c:	6893      	ldr	r3, [r2, #8]
2002364e:	4631      	mov	r1, r6
20023650:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
20023654:	6093      	str	r3, [r2, #8]
20023656:	2301      	movs	r3, #1
20023658:	4632      	mov	r2, r6
2002365a:	4620      	mov	r0, r4
2002365c:	e9cd 6303 	strd	r6, r3, [sp, #12]
20023660:	e9cd 6601 	strd	r6, r6, [sp, #4]
20023664:	4633      	mov	r3, r6
20023666:	9600      	str	r6, [sp, #0]
20023668:	f7fe ff06 	bl	20022478 <HAL_FLASH_MANUAL_CMD>
2002366c:	4632      	mov	r2, r6
2002366e:	21ff      	movs	r1, #255	@ 0xff
20023670:	4620      	mov	r0, r4
20023672:	f7fe fec1 	bl	200223f8 <HAL_FLASH_SET_CMD>
20023676:	4630      	mov	r0, r6
20023678:	f7fe f929 	bl	200218ce <HAL_Delay_us>
2002367c:	20c8      	movs	r0, #200	@ 0xc8
2002367e:	f7fe f926 	bl	200218ce <HAL_Delay_us>
20023682:	2f00      	cmp	r7, #0
20023684:	d0ad      	beq.n	200235e2 <HAL_FLASH_Init+0xba>
20023686:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
2002368a:	b2ee      	uxtb	r6, r5
2002368c:	f3c5 2807 	ubfx	r8, r5, #8, #8
20023690:	6425      	str	r5, [r4, #64]	@ 0x40
20023692:	f3c5 4507 	ubfx	r5, r5, #16, #8
20023696:	4642      	mov	r2, r8
20023698:	4629      	mov	r1, r5
2002369a:	4630      	mov	r0, r6
2002369c:	b3ab      	cbz	r3, 2002370a <HAL_FLASH_Init+0x1e2>
2002369e:	f000 fe39 	bl	20024314 <spi_nand_get_cmd_by_id>
200236a2:	60e0      	str	r0, [r4, #12]
200236a4:	bba0      	cbnz	r0, 20023710 <HAL_FLASH_Init+0x1e8>
200236a6:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200236aa:	b32b      	cbz	r3, 200236f8 <HAL_FLASH_Init+0x1d0>
200236ac:	2108      	movs	r1, #8
200236ae:	4620      	mov	r0, r4
200236b0:	f7ff fb82 	bl	20022db8 <nand_read_id>
200236b4:	f3c0 2807 	ubfx	r8, r0, #8, #8
200236b8:	f3c0 4507 	ubfx	r5, r0, #16, #8
200236bc:	b2c6      	uxtb	r6, r0
200236be:	6420      	str	r0, [r4, #64]	@ 0x40
200236c0:	4642      	mov	r2, r8
200236c2:	4629      	mov	r1, r5
200236c4:	4630      	mov	r0, r6
200236c6:	f000 fe25 	bl	20024314 <spi_nand_get_cmd_by_id>
200236ca:	60e0      	str	r0, [r4, #12]
200236cc:	bb00      	cbnz	r0, 20023710 <HAL_FLASH_Init+0x1e8>
200236ce:	210f      	movs	r1, #15
200236d0:	4620      	mov	r0, r4
200236d2:	f7ff fb71 	bl	20022db8 <nand_read_id>
200236d6:	f3c0 2807 	ubfx	r8, r0, #8, #8
200236da:	f3c0 4507 	ubfx	r5, r0, #16, #8
200236de:	b2c6      	uxtb	r6, r0
200236e0:	6420      	str	r0, [r4, #64]	@ 0x40
200236e2:	4642      	mov	r2, r8
200236e4:	4629      	mov	r1, r5
200236e6:	4630      	mov	r0, r6
200236e8:	f000 fe14 	bl	20024314 <spi_nand_get_cmd_by_id>
200236ec:	60e0      	str	r0, [r4, #12]
200236ee:	b978      	cbnz	r0, 20023710 <HAL_FLASH_Init+0x1e8>
200236f0:	f000 fe28 	bl	20024344 <spi_nand_get_default_ctable>
200236f4:	60e0      	str	r0, [r4, #12]
200236f6:	b958      	cbnz	r0, 20023710 <HAL_FLASH_Init+0x1e8>
200236f8:	2100      	movs	r1, #0
200236fa:	4620      	mov	r0, r4
200236fc:	f7fe ff19 	bl	20022532 <HAL_FLASH_ENABLE_QSPI>
20023700:	2300      	movs	r3, #0
20023702:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
20023706:	2001      	movs	r0, #1
20023708:	e052      	b.n	200237b0 <HAL_FLASH_Init+0x288>
2002370a:	f000 fda5 	bl	20024258 <spi_flash_get_cmd_by_id>
2002370e:	e7c8      	b.n	200236a2 <HAL_FLASH_Init+0x17a>
20023710:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023714:	4642      	mov	r2, r8
20023716:	4629      	mov	r1, r5
20023718:	4630      	mov	r0, r6
2002371a:	2b00      	cmp	r3, #0
2002371c:	d04b      	beq.n	200237b6 <HAL_FLASH_Init+0x28e>
2002371e:	f000 fe1f 	bl	20024360 <spi_nand_get_size_by_id>
20023722:	4642      	mov	r2, r8
20023724:	4629      	mov	r1, r5
20023726:	4681      	mov	r9, r0
20023728:	4630      	mov	r0, r6
2002372a:	f000 fe23 	bl	20024374 <spi_nand_get_plane_select_flag>
2002372e:	4642      	mov	r2, r8
20023730:	4629      	mov	r1, r5
20023732:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
20023736:	4630      	mov	r0, r6
20023738:	f000 fe25 	bl	20024386 <spi_nand_get_big_page_flag>
2002373c:	4642      	mov	r2, r8
2002373e:	4629      	mov	r1, r5
20023740:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
20023744:	4630      	mov	r0, r6
20023746:	f000 fe27 	bl	20024398 <spi_nand_get_ecc_mode>
2002374a:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
2002374e:	4642      	mov	r2, r8
20023750:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
20023754:	4629      	mov	r1, r5
20023756:	4630      	mov	r0, r6
20023758:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
2002375c:	f000 fdec 	bl	20024338 <spi_nand_get_ext_cfg_by_id>
20023760:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023762:	f1b9 0f00 	cmp.w	r9, #0
20023766:	d003      	beq.n	20023770 <HAL_FLASH_Init+0x248>
20023768:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
2002376c:	f8c4 9014 	str.w	r9, [r4, #20]
20023770:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023774:	2b00      	cmp	r3, #0
20023776:	d17d      	bne.n	20023874 <HAL_FLASH_Init+0x34c>
20023778:	2f00      	cmp	r7, #0
2002377a:	d178      	bne.n	2002386e <HAL_FLASH_Init+0x346>
2002377c:	4620      	mov	r0, r4
2002377e:	f7ff f93e 	bl	200229fe <HAL_FLASH_CLR_PROTECT>
20023782:	6963      	ldr	r3, [r4, #20]
20023784:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023788:	d945      	bls.n	20023816 <HAL_FLASH_Init+0x2ee>
2002378a:	463a      	mov	r2, r7
2002378c:	2121      	movs	r1, #33	@ 0x21
2002378e:	4620      	mov	r0, r4
20023790:	f7fe ffc4 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023794:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023798:	bb0b      	cbnz	r3, 200237de <HAL_FLASH_Init+0x2b6>
2002379a:	4639      	mov	r1, r7
2002379c:	4620      	mov	r0, r4
2002379e:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
200237a2:	f7ff f906 	bl	200229b2 <HAL_FLASH_FADDR_SET_QSPI>
200237a6:	2107      	movs	r1, #7
200237a8:	4620      	mov	r0, r4
200237aa:	f7fe feec 	bl	20022586 <HAL_FLASH_SET_ROW_BOUNDARY>
200237ae:	2000      	movs	r0, #0
200237b0:	b007      	add	sp, #28
200237b2:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
200237b6:	f000 fd63 	bl	20024280 <spi_flash_get_size_by_id>
200237ba:	4642      	mov	r2, r8
200237bc:	4629      	mov	r1, r5
200237be:	4681      	mov	r9, r0
200237c0:	4630      	mov	r0, r6
200237c2:	f000 fd71 	bl	200242a8 <spi_flash_get_otp_base>
200237c6:	4642      	mov	r2, r8
200237c8:	63a0      	str	r0, [r4, #56]	@ 0x38
200237ca:	4629      	mov	r1, r5
200237cc:	4630      	mov	r0, r6
200237ce:	f000 fd1b 	bl	20024208 <spi_nor_get_ext_cfg_by_id>
200237d2:	63e0      	str	r0, [r4, #60]	@ 0x3c
200237d4:	2800      	cmp	r0, #0
200237d6:	d0c4      	beq.n	20023762 <HAL_FLASH_Init+0x23a>
200237d8:	6803      	ldr	r3, [r0, #0]
200237da:	63a3      	str	r3, [r4, #56]	@ 0x38
200237dc:	e7c1      	b.n	20023762 <HAL_FLASH_Init+0x23a>
200237de:	2101      	movs	r1, #1
200237e0:	4620      	mov	r0, r4
200237e2:	f7ff f8e6 	bl	200229b2 <HAL_FLASH_FADDR_SET_QSPI>
200237e6:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
200237ea:	f1b9 0f01 	cmp.w	r9, #1
200237ee:	d1da      	bne.n	200237a6 <HAL_FLASH_Init+0x27e>
200237f0:	4642      	mov	r2, r8
200237f2:	4629      	mov	r1, r5
200237f4:	4630      	mov	r0, r6
200237f6:	f000 fd4d 	bl	20024294 <spi_flash_is_support_dtr>
200237fa:	b120      	cbz	r0, 20023806 <HAL_FLASH_Init+0x2de>
200237fc:	4649      	mov	r1, r9
200237fe:	4620      	mov	r0, r4
20023800:	f7ff fe4b 	bl	2002349a <HAL_NOR_CFG_DTR>
20023804:	e7cf      	b.n	200237a6 <HAL_FLASH_Init+0x27e>
20023806:	463a      	mov	r2, r7
20023808:	4639      	mov	r1, r7
2002380a:	4620      	mov	r0, r4
2002380c:	f7fe fed3 	bl	200225b6 <HAL_MPI_CFG_DTR>
20023810:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023814:	e7c7      	b.n	200237a6 <HAL_FLASH_Init+0x27e>
20023816:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
2002381a:	b933      	cbnz	r3, 2002382a <HAL_FLASH_Init+0x302>
2002381c:	4639      	mov	r1, r7
2002381e:	4620      	mov	r0, r4
20023820:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023824:	f7ff f8ba 	bl	2002299c <HAL_FLASH_SET_QUAL_SPI>
20023828:	e7c1      	b.n	200237ae <HAL_FLASH_Init+0x286>
2002382a:	2101      	movs	r1, #1
2002382c:	4620      	mov	r0, r4
2002382e:	f7ff f8b5 	bl	2002299c <HAL_FLASH_SET_QUAL_SPI>
20023832:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
20023836:	f1b9 0f01 	cmp.w	r9, #1
2002383a:	d112      	bne.n	20023862 <HAL_FLASH_Init+0x33a>
2002383c:	4642      	mov	r2, r8
2002383e:	4629      	mov	r1, r5
20023840:	4630      	mov	r0, r6
20023842:	f000 fd27 	bl	20024294 <spi_flash_is_support_dtr>
20023846:	b120      	cbz	r0, 20023852 <HAL_FLASH_Init+0x32a>
20023848:	4649      	mov	r1, r9
2002384a:	4620      	mov	r0, r4
2002384c:	f7ff fe25 	bl	2002349a <HAL_NOR_CFG_DTR>
20023850:	e7ad      	b.n	200237ae <HAL_FLASH_Init+0x286>
20023852:	463a      	mov	r2, r7
20023854:	4639      	mov	r1, r7
20023856:	4620      	mov	r0, r4
20023858:	f7fe fead 	bl	200225b6 <HAL_MPI_CFG_DTR>
2002385c:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023860:	e7a5      	b.n	200237ae <HAL_FLASH_Init+0x286>
20023862:	463a      	mov	r2, r7
20023864:	4639      	mov	r1, r7
20023866:	4620      	mov	r0, r4
20023868:	f7fe fea5 	bl	200225b6 <HAL_MPI_CFG_DTR>
2002386c:	e79f      	b.n	200237ae <HAL_FLASH_Init+0x286>
2002386e:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023872:	e79c      	b.n	200237ae <HAL_FLASH_Init+0x286>
20023874:	2101      	movs	r1, #1
20023876:	4620      	mov	r0, r4
20023878:	f7fe fd9d 	bl	200223b6 <HAL_FLASH_WRITE_DLEN>
2002387c:	68e3      	ldr	r3, [r4, #12]
2002387e:	2102      	movs	r1, #2
20023880:	791a      	ldrb	r2, [r3, #4]
20023882:	4620      	mov	r0, r4
20023884:	f7fe ff4a 	bl	2002271c <HAL_FLASH_ISSUE_CMD>
20023888:	4620      	mov	r0, r4
2002388a:	f7fe fde6 	bl	2002245a <HAL_FLASH_READ32>
2002388e:	4605      	mov	r5, r0
20023890:	200a      	movs	r0, #10
20023892:	f7fe f81c 	bl	200218ce <HAL_Delay_us>
20023896:	07eb      	lsls	r3, r5, #31
20023898:	d4ec      	bmi.n	20023874 <HAL_FLASH_Init+0x34c>
2002389a:	4631      	mov	r1, r6
2002389c:	4620      	mov	r0, r4
2002389e:	f7ff fbd8 	bl	20023052 <nand_clear_status>
200238a2:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
200238a6:	2b02      	cmp	r3, #2
200238a8:	d181      	bne.n	200237ae <HAL_FLASH_Init+0x286>
200238aa:	2101      	movs	r1, #1
200238ac:	4620      	mov	r0, r4
200238ae:	f7ff fb9f 	bl	20022ff0 <HAL_NAND_EN_QUAL>
200238b2:	e77c      	b.n	200237ae <HAL_FLASH_Init+0x286>
200238b4:	03938700 	.word	0x03938700

200238b8 <HAL_PIN_Set2>:
200238b8:	0a03      	lsrs	r3, r0, #8
200238ba:	1e5a      	subs	r2, r3, #1
200238bc:	2a53      	cmp	r2, #83	@ 0x53
200238be:	b2c0      	uxtb	r0, r0
200238c0:	d80e      	bhi.n	200238e0 <HAL_PIN_Set2+0x28>
200238c2:	4a09      	ldr	r2, [pc, #36]	@ (200238e8 <HAL_PIN_Set2+0x30>)
200238c4:	009b      	lsls	r3, r3, #2
200238c6:	441a      	add	r2, r3
200238c8:	6813      	ldr	r3, [r2, #0]
200238ca:	f401 7140 	and.w	r1, r1, #768	@ 0x300
200238ce:	f36f 0309 	bfc	r3, #0, #10
200238d2:	430b      	orrs	r3, r1
200238d4:	4303      	orrs	r3, r0
200238d6:	f443 6380 	orr.w	r3, r3, #1024	@ 0x400
200238da:	2000      	movs	r0, #0
200238dc:	6013      	str	r3, [r2, #0]
200238de:	4770      	bx	lr
200238e0:	f04f 30ff 	mov.w	r0, #4294967295
200238e4:	4770      	bx	lr
200238e6:	bf00      	nop
200238e8:	50002ffc 	.word	0x50002ffc

200238ec <HAL_PIN_Set_DS0>:
200238ec:	2854      	cmp	r0, #84	@ 0x54
200238ee:	dc0e      	bgt.n	2002390e <HAL_PIN_Set_DS0+0x22>
200238f0:	b168      	cbz	r0, 2002390e <HAL_PIN_Set_DS0+0x22>
200238f2:	4b08      	ldr	r3, [pc, #32]	@ (20023914 <HAL_PIN_Set_DS0+0x28>)
200238f4:	0080      	lsls	r0, r0, #2
200238f6:	4403      	add	r3, r0
200238f8:	b12a      	cbz	r2, 20023906 <HAL_PIN_Set_DS0+0x1a>
200238fa:	681a      	ldr	r2, [r3, #0]
200238fc:	f442 5200 	orr.w	r2, r2, #8192	@ 0x2000
20023900:	2000      	movs	r0, #0
20023902:	601a      	str	r2, [r3, #0]
20023904:	4770      	bx	lr
20023906:	681a      	ldr	r2, [r3, #0]
20023908:	f422 5200 	bic.w	r2, r2, #8192	@ 0x2000
2002390c:	e7f8      	b.n	20023900 <HAL_PIN_Set_DS0+0x14>
2002390e:	f04f 30ff 	mov.w	r0, #4294967295
20023912:	4770      	bx	lr
20023914:	50002ffc 	.word	0x50002ffc

20023918 <HAL_PIN_Set_DS1>:
20023918:	2854      	cmp	r0, #84	@ 0x54
2002391a:	dc0e      	bgt.n	2002393a <HAL_PIN_Set_DS1+0x22>
2002391c:	b168      	cbz	r0, 2002393a <HAL_PIN_Set_DS1+0x22>
2002391e:	4b08      	ldr	r3, [pc, #32]	@ (20023940 <HAL_PIN_Set_DS1+0x28>)
20023920:	0080      	lsls	r0, r0, #2
20023922:	4403      	add	r3, r0
20023924:	b12a      	cbz	r2, 20023932 <HAL_PIN_Set_DS1+0x1a>
20023926:	681a      	ldr	r2, [r3, #0]
20023928:	f442 4280 	orr.w	r2, r2, #16384	@ 0x4000
2002392c:	2000      	movs	r0, #0
2002392e:	601a      	str	r2, [r3, #0]
20023930:	4770      	bx	lr
20023932:	681a      	ldr	r2, [r3, #0]
20023934:	f422 4280 	bic.w	r2, r2, #16384	@ 0x4000
20023938:	e7f8      	b.n	2002392c <HAL_PIN_Set_DS1+0x14>
2002393a:	f04f 30ff 	mov.w	r0, #4294967295
2002393e:	4770      	bx	lr
20023940:	50002ffc 	.word	0x50002ffc

20023944 <HAL_PMU_EnableDLL>:
20023944:	4b05      	ldr	r3, [pc, #20]	@ (2002395c <HAL_PMU_EnableDLL+0x18>)
20023946:	6eda      	ldr	r2, [r3, #108]	@ 0x6c
20023948:	b120      	cbz	r0, 20023954 <HAL_PMU_EnableDLL+0x10>
2002394a:	f042 0220 	orr.w	r2, r2, #32
2002394e:	2000      	movs	r0, #0
20023950:	66da      	str	r2, [r3, #108]	@ 0x6c
20023952:	4770      	bx	lr
20023954:	f022 0220 	bic.w	r2, r2, #32
20023958:	e7f9      	b.n	2002394e <HAL_PMU_EnableDLL+0xa>
2002395a:	bf00      	nop
2002395c:	500ca000 	.word	0x500ca000

20023960 <HAL_PMU_LoadCalData>:
20023960:	b510      	push	{r4, lr}
20023962:	4c27      	ldr	r4, [pc, #156]	@ (20023a00 <HAL_PMU_LoadCalData+0xa0>)
20023964:	220f      	movs	r2, #15
20023966:	4621      	mov	r1, r4
20023968:	2006      	movs	r0, #6
2002396a:	f000 fb95 	bl	20024098 <BSP_CONFIG_get>
2002396e:	2800      	cmp	r0, #0
20023970:	dd44      	ble.n	200239fc <HAL_PMU_LoadCalData+0x9c>
20023972:	2301      	movs	r3, #1
20023974:	7862      	ldrb	r2, [r4, #1]
20023976:	f804 3c01 	strb.w	r3, [r4, #-1]
2002397a:	7821      	ldrb	r1, [r4, #0]
2002397c:	4b21      	ldr	r3, [pc, #132]	@ (20023a04 <HAL_PMU_LoadCalData+0xa4>)
2002397e:	0792      	lsls	r2, r2, #30
20023980:	6ad8      	ldr	r0, [r3, #44]	@ 0x2c
20023982:	0649      	lsls	r1, r1, #25
20023984:	f001 6160 	and.w	r1, r1, #234881024	@ 0xe000000
20023988:	f002 4280 	and.w	r2, r2, #1073741824	@ 0x40000000
2002398c:	430a      	orrs	r2, r1
2002398e:	f020 419c 	bic.w	r1, r0, #1308622848	@ 0x4e000000
20023992:	430a      	orrs	r2, r1
20023994:	62da      	str	r2, [r3, #44]	@ 0x2c
20023996:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
2002399a:	78e1      	ldrb	r1, [r4, #3]
2002399c:	f361 0203 	bfi	r2, r1, #0, #4
200239a0:	f8c3 2094 	str.w	r2, [r3, #148]	@ 0x94
200239a4:	695a      	ldr	r2, [r3, #20]
200239a6:	7921      	ldrb	r1, [r4, #4]
200239a8:	f361 228d 	bfi	r2, r1, #10, #4
200239ac:	615a      	str	r2, [r3, #20]
200239ae:	7962      	ldrb	r2, [r4, #5]
200239b0:	79a0      	ldrb	r0, [r4, #6]
200239b2:	6e19      	ldr	r1, [r3, #96]	@ 0x60
200239b4:	00d2      	lsls	r2, r2, #3
200239b6:	02c0      	lsls	r0, r0, #11
200239b8:	f002 0278 	and.w	r2, r2, #120	@ 0x78
200239bc:	f400 40f0 	and.w	r0, r0, #30720	@ 0x7800
200239c0:	f021 1178 	bic.w	r1, r1, #7864440	@ 0x780078
200239c4:	f421 41f0 	bic.w	r1, r1, #30720	@ 0x7800
200239c8:	4302      	orrs	r2, r0
200239ca:	430a      	orrs	r2, r1
200239cc:	79e1      	ldrb	r1, [r4, #7]
200239ce:	04c9      	lsls	r1, r1, #19
200239d0:	f401 01f0 	and.w	r1, r1, #7864320	@ 0x780000
200239d4:	430a      	orrs	r2, r1
200239d6:	661a      	str	r2, [r3, #96]	@ 0x60
200239d8:	6a59      	ldr	r1, [r3, #36]	@ 0x24
200239da:	7a22      	ldrb	r2, [r4, #8]
200239dc:	f021 0127 	bic.w	r1, r1, #39	@ 0x27
200239e0:	f002 0207 	and.w	r2, r2, #7
200239e4:	430a      	orrs	r2, r1
200239e6:	7a61      	ldrb	r1, [r4, #9]
200239e8:	0149      	lsls	r1, r1, #5
200239ea:	f001 0120 	and.w	r1, r1, #32
200239ee:	430a      	orrs	r2, r1
200239f0:	625a      	str	r2, [r3, #36]	@ 0x24
200239f2:	6a9a      	ldr	r2, [r3, #40]	@ 0x28
200239f4:	7ba1      	ldrb	r1, [r4, #14]
200239f6:	f361 0203 	bfi	r2, r1, #0, #4
200239fa:	629a      	str	r2, [r3, #40]	@ 0x28
200239fc:	bd10      	pop	{r4, pc}
200239fe:	bf00      	nop
20023a00:	2004ca19 	.word	0x2004ca19
20023a04:	500ca000 	.word	0x500ca000

20023a08 <HAL_RCC_HCPU_ConfigSxModeVolt>:
20023a08:	b507      	push	{r0, r1, r2, lr}
20023a0a:	4a13      	ldr	r2, [pc, #76]	@ (20023a58 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
20023a0c:	4913      	ldr	r1, [pc, #76]	@ (20023a5c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20023a0e:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
20023a12:	f8d1 3098 	ldr.w	r3, [r1, #152]	@ 0x98
20023a16:	7892      	ldrb	r2, [r2, #2]
20023a18:	2802      	cmp	r0, #2
20023a1a:	f362 0304 	bfi	r3, r2, #0, #5
20023a1e:	f8c1 3098 	str.w	r3, [r1, #152]	@ 0x98
20023a22:	f10d 0007 	add.w	r0, sp, #7
20023a26:	d111      	bne.n	20023a4c <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
20023a28:	f002 ff86 	bl	20026938 <HAL_PMU_GetHpsysVoutRef>
20023a2c:	b110      	cbz	r0, 20023a34 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20023a2e:	230b      	movs	r3, #11
20023a30:	f88d 3007 	strb.w	r3, [sp, #7]
20023a34:	4a09      	ldr	r2, [pc, #36]	@ (20023a5c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
20023a36:	f89d 1007 	ldrb.w	r1, [sp, #7]
20023a3a:	f8d2 3090 	ldr.w	r3, [r2, #144]	@ 0x90
20023a3e:	f361 0303 	bfi	r3, r1, #0, #4
20023a42:	f8c2 3090 	str.w	r3, [r2, #144]	@ 0x90
20023a46:	b003      	add	sp, #12
20023a48:	f85d fb04 	ldr.w	pc, [sp], #4
20023a4c:	f002 ff80 	bl	20026950 <HAL_PMU_GetHpsysVoutRef2>
20023a50:	2800      	cmp	r0, #0
20023a52:	d0ef      	beq.n	20023a34 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20023a54:	230e      	movs	r3, #14
20023a56:	e7eb      	b.n	20023a30 <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
20023a58:	20026444 	.word	0x20026444
20023a5c:	500ca000 	.word	0x500ca000

20023a60 <HAL_RCC_HCPU_GetClockSrc>:
20023a60:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023a64:	2810      	cmp	r0, #16
20023a66:	6a1a      	ldr	r2, [r3, #32]
20023a68:	d80c      	bhi.n	20023a84 <HAL_RCC_HCPU_GetClockSrc+0x24>
20023a6a:	4b07      	ldr	r3, [pc, #28]	@ (20023a88 <HAL_RCC_HCPU_GetClockSrc+0x28>)
20023a6c:	40c3      	lsrs	r3, r0
20023a6e:	f013 0f01 	tst.w	r3, #1
20023a72:	bf0c      	ite	eq
20023a74:	2301      	moveq	r3, #1
20023a76:	2303      	movne	r3, #3
20023a78:	4083      	lsls	r3, r0
20023a7a:	4013      	ands	r3, r2
20023a7c:	fa23 f000 	lsr.w	r0, r3, r0
20023a80:	b2c0      	uxtb	r0, r0
20023a82:	4770      	bx	lr
20023a84:	2301      	movs	r3, #1
20023a86:	e7f7      	b.n	20023a78 <HAL_RCC_HCPU_GetClockSrc+0x18>
20023a88:	00012ff1 	.word	0x00012ff1

20023a8c <HAL_RCC_HCPU_GetDLLFreq>:
20023a8c:	2801      	cmp	r0, #1
20023a8e:	d003      	beq.n	20023a98 <HAL_RCC_HCPU_GetDLLFreq+0xc>
20023a90:	2802      	cmp	r0, #2
20023a92:	d00e      	beq.n	20023ab2 <HAL_RCC_HCPU_GetDLLFreq+0x26>
20023a94:	2000      	movs	r0, #0
20023a96:	4770      	bx	lr
20023a98:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023a9c:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
20023a9e:	b163      	cbz	r3, 20023aba <HAL_RCC_HCPU_GetDLLFreq+0x2e>
20023aa0:	f013 0001 	ands.w	r0, r3, #1
20023aa4:	d00a      	beq.n	20023abc <HAL_RCC_HCPU_GetDLLFreq+0x30>
20023aa6:	4806      	ldr	r0, [pc, #24]	@ (20023ac0 <HAL_RCC_HCPU_GetDLLFreq+0x34>)
20023aa8:	f3c3 0383 	ubfx	r3, r3, #2, #4
20023aac:	fb03 0000 	mla	r0, r3, r0, r0
20023ab0:	4770      	bx	lr
20023ab2:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023ab6:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
20023ab8:	e7f1      	b.n	20023a9e <HAL_RCC_HCPU_GetDLLFreq+0x12>
20023aba:	4618      	mov	r0, r3
20023abc:	4770      	bx	lr
20023abe:	bf00      	nop
20023ac0:	016e3600 	.word	0x016e3600

20023ac4 <HAL_RCC_HCPU_GetDLL1Freq>:
20023ac4:	2001      	movs	r0, #1
20023ac6:	f7ff bfe1 	b.w	20023a8c <HAL_RCC_HCPU_GetDLLFreq>
	...

20023acc <HAL_RCC_GetSysCLKFreq.part.0>:
20023acc:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023ad0:	6a1b      	ldr	r3, [r3, #32]
20023ad2:	f003 0303 	and.w	r3, r3, #3
20023ad6:	2b03      	cmp	r3, #3
20023ad8:	d101      	bne.n	20023ade <HAL_RCC_GetSysCLKFreq.part.0+0x12>
20023ada:	f7ff bff3 	b.w	20023ac4 <HAL_RCC_HCPU_GetDLL1Freq>
20023ade:	4801      	ldr	r0, [pc, #4]	@ (20023ae4 <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
20023ae0:	4770      	bx	lr
20023ae2:	bf00      	nop
20023ae4:	02dc6c00 	.word	0x02dc6c00

20023ae8 <HAL_RCC_HCPU_GetDLL2Freq>:
20023ae8:	2002      	movs	r0, #2
20023aea:	f7ff bfcf 	b.w	20023a8c <HAL_RCC_HCPU_GetDLLFreq>
	...

20023af0 <HAL_RCC_HCPU_EnableDLL>:
20023af0:	4b1a      	ldr	r3, [pc, #104]	@ (20023b5c <HAL_RCC_HCPU_EnableDLL+0x6c>)
20023af2:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
20023af6:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
20023afa:	4299      	cmp	r1, r3
20023afc:	b510      	push	{r4, lr}
20023afe:	d82a      	bhi.n	20023b56 <HAL_RCC_HCPU_EnableDLL+0x66>
20023b00:	2801      	cmp	r0, #1
20023b02:	d002      	beq.n	20023b0a <HAL_RCC_HCPU_EnableDLL+0x1a>
20023b04:	2802      	cmp	r0, #2
20023b06:	d024      	beq.n	20023b52 <HAL_RCC_HCPU_EnableDLL+0x62>
20023b08:	e7fe      	b.n	20023b08 <HAL_RCC_HCPU_EnableDLL+0x18>
20023b0a:	4c15      	ldr	r4, [pc, #84]	@ (20023b60 <HAL_RCC_HCPU_EnableDLL+0x70>)
20023b0c:	4a15      	ldr	r2, [pc, #84]	@ (20023b64 <HAL_RCC_HCPU_EnableDLL+0x74>)
20023b0e:	2000      	movs	r0, #0
20023b10:	6c53      	ldr	r3, [r2, #68]	@ 0x44
20023b12:	f043 0301 	orr.w	r3, r3, #1
20023b16:	6453      	str	r3, [r2, #68]	@ 0x44
20023b18:	4a13      	ldr	r2, [pc, #76]	@ (20023b68 <HAL_RCC_HCPU_EnableDLL+0x78>)
20023b1a:	6823      	ldr	r3, [r4, #0]
20023b1c:	fbb1 f1f2 	udiv	r1, r1, r2
20023b20:	f023 0301 	bic.w	r3, r3, #1
20023b24:	6023      	str	r3, [r4, #0]
20023b26:	6823      	ldr	r3, [r4, #0]
20023b28:	f423 4380 	bic.w	r3, r3, #16384	@ 0x4000
20023b2c:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
20023b30:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
20023b34:	f443 5300 	orr.w	r3, r3, #8192	@ 0x2000
20023b38:	f043 0301 	orr.w	r3, r3, #1
20023b3c:	6023      	str	r3, [r4, #0]
20023b3e:	f7fd fec6 	bl	200218ce <HAL_Delay_us>
20023b42:	200a      	movs	r0, #10
20023b44:	f7fd fec3 	bl	200218ce <HAL_Delay_us>
20023b48:	6823      	ldr	r3, [r4, #0]
20023b4a:	2b00      	cmp	r3, #0
20023b4c:	dafc      	bge.n	20023b48 <HAL_RCC_HCPU_EnableDLL+0x58>
20023b4e:	2000      	movs	r0, #0
20023b50:	bd10      	pop	{r4, pc}
20023b52:	4c06      	ldr	r4, [pc, #24]	@ (20023b6c <HAL_RCC_HCPU_EnableDLL+0x7c>)
20023b54:	e7da      	b.n	20023b0c <HAL_RCC_HCPU_EnableDLL+0x1c>
20023b56:	2001      	movs	r0, #1
20023b58:	e7fa      	b.n	20023b50 <HAL_RCC_HCPU_EnableDLL+0x60>
20023b5a:	bf00      	nop
20023b5c:	15752a00 	.word	0x15752a00
20023b60:	5000002c 	.word	0x5000002c
20023b64:	5000b000 	.word	0x5000b000
20023b68:	016e3600 	.word	0x016e3600
20023b6c:	50000030 	.word	0x50000030

20023b70 <HAL_RCC_HCPU_EnableDLL1>:
20023b70:	4601      	mov	r1, r0
20023b72:	2001      	movs	r0, #1
20023b74:	f7ff bfbc 	b.w	20023af0 <HAL_RCC_HCPU_EnableDLL>

20023b78 <HAL_RCC_HCPU_EnableDLL2>:
20023b78:	4601      	mov	r1, r0
20023b7a:	2002      	movs	r0, #2
20023b7c:	f7ff bfb8 	b.w	20023af0 <HAL_RCC_HCPU_EnableDLL>

20023b80 <HAL_RCC_HCPU_DisableDLL1>:
20023b80:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20023b84:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
20023b86:	2000      	movs	r0, #0
20023b88:	f023 0301 	bic.w	r3, r3, #1
20023b8c:	62d3      	str	r3, [r2, #44]	@ 0x2c
20023b8e:	4770      	bx	lr

20023b90 <HAL_RCC_HCPU_DisableDLL2>:
20023b90:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20023b94:	6b13      	ldr	r3, [r2, #48]	@ 0x30
20023b96:	2000      	movs	r0, #0
20023b98:	f023 0301 	bic.w	r3, r3, #1
20023b9c:	6313      	str	r3, [r2, #48]	@ 0x30
20023b9e:	4770      	bx	lr

20023ba0 <HAL_RCC_GetSysCLKFreq>:
20023ba0:	2801      	cmp	r0, #1
20023ba2:	d101      	bne.n	20023ba8 <HAL_RCC_GetSysCLKFreq+0x8>
20023ba4:	f7ff bf92 	b.w	20023acc <HAL_RCC_GetSysCLKFreq.part.0>
20023ba8:	4800      	ldr	r0, [pc, #0]	@ (20023bac <HAL_RCC_GetSysCLKFreq+0xc>)
20023baa:	4770      	bx	lr
20023bac:	02dc6c00 	.word	0x02dc6c00

20023bb0 <HAL_RCC_GetHCLKFreq>:
20023bb0:	1e02      	subs	r2, r0, #0
20023bb2:	bf08      	it	eq
20023bb4:	2201      	moveq	r2, #1
20023bb6:	b508      	push	{r3, lr}
20023bb8:	4610      	mov	r0, r2
20023bba:	f7ff fff1 	bl	20023ba0 <HAL_RCC_GetSysCLKFreq>
20023bbe:	2a01      	cmp	r2, #1
20023bc0:	d002      	beq.n	20023bc8 <HAL_RCC_GetHCLKFreq+0x18>
20023bc2:	2a02      	cmp	r2, #2
20023bc4:	d00a      	beq.n	20023bdc <HAL_RCC_GetHCLKFreq+0x2c>
20023bc6:	e7fe      	b.n	20023bc6 <HAL_RCC_GetHCLKFreq+0x16>
20023bc8:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023bcc:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
20023bce:	b2db      	uxtb	r3, r3
20023bd0:	2b01      	cmp	r3, #1
20023bd2:	bfb8      	it	lt
20023bd4:	2301      	movlt	r3, #1
20023bd6:	fbb0 f0f3 	udiv	r0, r0, r3
20023bda:	bd08      	pop	{r3, pc}
20023bdc:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
20023be0:	695b      	ldr	r3, [r3, #20]
20023be2:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
20023be6:	e7f3      	b.n	20023bd0 <HAL_RCC_GetHCLKFreq+0x20>

20023be8 <HAL_RCC_HCPU_ClockSelect>:
20023be8:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20023bec:	b510      	push	{r4, lr}
20023bee:	2810      	cmp	r0, #16
20023bf0:	6a1b      	ldr	r3, [r3, #32]
20023bf2:	d817      	bhi.n	20023c24 <HAL_RCC_HCPU_ClockSelect+0x3c>
20023bf4:	4a0c      	ldr	r2, [pc, #48]	@ (20023c28 <HAL_RCC_HCPU_ClockSelect+0x40>)
20023bf6:	40c2      	lsrs	r2, r0
20023bf8:	f012 0f01 	tst.w	r2, #1
20023bfc:	bf0c      	ite	eq
20023bfe:	2201      	moveq	r2, #1
20023c00:	2203      	movne	r2, #3
20023c02:	fa02 f400 	lsl.w	r4, r2, r0
20023c06:	4011      	ands	r1, r2
20023c08:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20023c0c:	ea23 0304 	bic.w	r3, r3, r4
20023c10:	4081      	lsls	r1, r0
20023c12:	430b      	orrs	r3, r1
20023c14:	6213      	str	r3, [r2, #32]
20023c16:	b920      	cbnz	r0, 20023c22 <HAL_RCC_HCPU_ClockSelect+0x3a>
20023c18:	2001      	movs	r0, #1
20023c1a:	f7ff ffc9 	bl	20023bb0 <HAL_RCC_GetHCLKFreq>
20023c1e:	4b03      	ldr	r3, [pc, #12]	@ (20023c2c <HAL_RCC_HCPU_ClockSelect+0x44>)
20023c20:	6018      	str	r0, [r3, #0]
20023c22:	bd10      	pop	{r4, pc}
20023c24:	2201      	movs	r2, #1
20023c26:	e7ec      	b.n	20023c02 <HAL_RCC_HCPU_ClockSelect+0x1a>
20023c28:	00012ff1 	.word	0x00012ff1
20023c2c:	20042c14 	.word	0x20042c14

20023c30 <HAL_RCC_HCPU_SetDiv>:
20023c30:	2800      	cmp	r0, #0
20023c32:	bfd8      	it	le
20023c34:	2000      	movle	r0, #0
20023c36:	b508      	push	{r3, lr}
20023c38:	bfcc      	ite	gt
20023c3a:	23ff      	movgt	r3, #255	@ 0xff
20023c3c:	4603      	movle	r3, r0
20023c3e:	2900      	cmp	r1, #0
20023c40:	db12      	blt.n	20023c68 <HAL_RCC_HCPU_SetDiv+0x38>
20023c42:	2a00      	cmp	r2, #0
20023c44:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
20023c48:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
20023c4c:	da0e      	bge.n	20023c6c <HAL_RCC_HCPU_SetDiv+0x3c>
20023c4e:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
20023c52:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
20023c54:	ea22 0303 	bic.w	r3, r2, r3
20023c58:	4303      	orrs	r3, r0
20023c5a:	624b      	str	r3, [r1, #36]	@ 0x24
20023c5c:	2001      	movs	r0, #1
20023c5e:	f7ff ffa7 	bl	20023bb0 <HAL_RCC_GetHCLKFreq>
20023c62:	4b07      	ldr	r3, [pc, #28]	@ (20023c80 <HAL_RCC_HCPU_SetDiv+0x50>)
20023c64:	6018      	str	r0, [r3, #0]
20023c66:	bd08      	pop	{r3, pc}
20023c68:	2a00      	cmp	r2, #0
20023c6a:	db04      	blt.n	20023c76 <HAL_RCC_HCPU_SetDiv+0x46>
20023c6c:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
20023c70:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
20023c74:	e7eb      	b.n	20023c4e <HAL_RCC_HCPU_SetDiv+0x1e>
20023c76:	2b00      	cmp	r3, #0
20023c78:	d0f0      	beq.n	20023c5c <HAL_RCC_HCPU_SetDiv+0x2c>
20023c7a:	23ff      	movs	r3, #255	@ 0xff
20023c7c:	e7e7      	b.n	20023c4e <HAL_RCC_HCPU_SetDiv+0x1e>
20023c7e:	bf00      	nop
20023c80:	20042c14 	.word	0x20042c14

20023c84 <HAL_RCC_HCPU_SwitchDvfsD2S>:
20023c84:	b570      	push	{r4, r5, r6, lr}
20023c86:	460c      	mov	r4, r1
20023c88:	4d19      	ldr	r5, [pc, #100]	@ (20023cf0 <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
20023c8a:	4606      	mov	r6, r0
20023c8c:	f7ff febc 	bl	20023a08 <HAL_RCC_HCPU_ConfigSxModeVolt>
20023c90:	692b      	ldr	r3, [r5, #16]
20023c92:	20fa      	movs	r0, #250	@ 0xfa
20023c94:	f023 0301 	bic.w	r3, r3, #1
20023c98:	612b      	str	r3, [r5, #16]
20023c9a:	f7fd fe18 	bl	200218ce <HAL_Delay_us>
20023c9e:	2c30      	cmp	r4, #48	@ 0x30
20023ca0:	d80d      	bhi.n	20023cbe <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
20023ca2:	2100      	movs	r1, #0
20023ca4:	4608      	mov	r0, r1
20023ca6:	f7ff ff9f 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023caa:	2030      	movs	r0, #48	@ 0x30
20023cac:	2204      	movs	r2, #4
20023cae:	2100      	movs	r1, #0
20023cb0:	fbb0 f0f4 	udiv	r0, r0, r4
20023cb4:	f7ff ffbc 	bl	20023c30 <HAL_RCC_HCPU_SetDiv>
20023cb8:	2400      	movs	r4, #0
20023cba:	4620      	mov	r0, r4
20023cbc:	bd70      	pop	{r4, r5, r6, pc}
20023cbe:	f7fe fb15 	bl	200222ec <HAL_HPAON_EnableXT48>
20023cc2:	480c      	ldr	r0, [pc, #48]	@ (20023cf4 <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
20023cc4:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
20023cc8:	6843      	ldr	r3, [r0, #4]
20023cca:	480b      	ldr	r0, [pc, #44]	@ (20023cf8 <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
20023ccc:	61eb      	str	r3, [r5, #28]
20023cce:	4360      	muls	r0, r4
20023cd0:	f7ff ff4e 	bl	20023b70 <HAL_RCC_HCPU_EnableDLL1>
20023cd4:	4604      	mov	r4, r0
20023cd6:	2800      	cmp	r0, #0
20023cd8:	d1ef      	bne.n	20023cba <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
20023cda:	2101      	movs	r1, #1
20023cdc:	2206      	movs	r2, #6
20023cde:	4608      	mov	r0, r1
20023ce0:	f7ff ffa6 	bl	20023c30 <HAL_RCC_HCPU_SetDiv>
20023ce4:	2103      	movs	r1, #3
20023ce6:	4620      	mov	r0, r4
20023ce8:	f7ff ff7e 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023cec:	e7e4      	b.n	20023cb8 <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
20023cee:	bf00      	nop
20023cf0:	5000b000 	.word	0x5000b000
20023cf4:	20026444 	.word	0x20026444
20023cf8:	000f4240 	.word	0x000f4240

20023cfc <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
20023cfc:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20023d00:	4c1d      	ldr	r4, [pc, #116]	@ (20023d78 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
20023d02:	4f1e      	ldr	r7, [pc, #120]	@ (20023d7c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
20023d04:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
20023d08:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
20023d0a:	7892      	ldrb	r2, [r2, #2]
20023d0c:	4605      	mov	r5, r0
20023d0e:	f362 4396 	bfi	r3, r2, #18, #5
20023d12:	ea4f 08c0 	mov.w	r8, r0, lsl #3
20023d16:	633b      	str	r3, [r7, #48]	@ 0x30
20023d18:	f10d 0007 	add.w	r0, sp, #7
20023d1c:	460e      	mov	r6, r1
20023d1e:	f002 fe0b 	bl	20026938 <HAL_PMU_GetHpsysVoutRef>
20023d22:	b110      	cbz	r0, 20023d2a <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
20023d24:	230b      	movs	r3, #11
20023d26:	f88d 3007 	strb.w	r3, [sp, #7]
20023d2a:	f89d 1007 	ldrb.w	r1, [sp, #7]
20023d2e:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
20023d32:	6d3b      	ldr	r3, [r7, #80]	@ 0x50
20023d34:	440a      	add	r2, r1
20023d36:	2100      	movs	r1, #0
20023d38:	f362 0385 	bfi	r3, r2, #2, #4
20023d3c:	4608      	mov	r0, r1
20023d3e:	653b      	str	r3, [r7, #80]	@ 0x50
20023d40:	f7ff ff52 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023d44:	2e30      	cmp	r6, #48	@ 0x30
20023d46:	d900      	bls.n	20023d4a <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
20023d48:	e7fe      	b.n	20023d48 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
20023d4a:	2030      	movs	r0, #48	@ 0x30
20023d4c:	2204      	movs	r2, #4
20023d4e:	2100      	movs	r1, #0
20023d50:	fbb0 f0f6 	udiv	r0, r0, r6
20023d54:	f7ff ff6c 	bl	20023c30 <HAL_RCC_HCPU_SetDiv>
20023d58:	f7ff ff12 	bl	20023b80 <HAL_RCC_HCPU_DisableDLL1>
20023d5c:	f7fe fad2 	bl	20022304 <HAL_HPAON_DisableXT48>
20023d60:	4444      	add	r4, r8
20023d62:	4b07      	ldr	r3, [pc, #28]	@ (20023d80 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
20023d64:	6862      	ldr	r2, [r4, #4]
20023d66:	61da      	str	r2, [r3, #28]
20023d68:	691a      	ldr	r2, [r3, #16]
20023d6a:	f042 0201 	orr.w	r2, r2, #1
20023d6e:	611a      	str	r2, [r3, #16]
20023d70:	b002      	add	sp, #8
20023d72:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023d76:	bf00      	nop
20023d78:	20026444 	.word	0x20026444
20023d7c:	500ca000 	.word	0x500ca000
20023d80:	5000b000 	.word	0x5000b000

20023d84 <HAL_RCC_HCPU_ConfigDvfs>:
20023d84:	b570      	push	{r4, r5, r6, lr}
20023d86:	4e31      	ldr	r6, [pc, #196]	@ (20023e4c <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
20023d88:	4605      	mov	r5, r0
20023d8a:	7833      	ldrb	r3, [r6, #0]
20023d8c:	460c      	mov	r4, r1
20023d8e:	2b01      	cmp	r3, #1
20023d90:	d943      	bls.n	20023e1a <HAL_RCC_HCPU_ConfigDvfs+0x96>
20023d92:	3b02      	subs	r3, #2
20023d94:	2b01      	cmp	r3, #1
20023d96:	d902      	bls.n	20023d9e <HAL_RCC_HCPU_ConfigDvfs+0x1a>
20023d98:	2501      	movs	r5, #1
20023d9a:	4628      	mov	r0, r5
20023d9c:	bd70      	pop	{r4, r5, r6, pc}
20023d9e:	4b2c      	ldr	r3, [pc, #176]	@ (20023e50 <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
20023da0:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
20023da4:	f7ff fea0 	bl	20023ae8 <HAL_RCC_HCPU_GetDLL2Freq>
20023da8:	4290      	cmp	r0, r2
20023daa:	d8f5      	bhi.n	20023d98 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20023dac:	2901      	cmp	r1, #1
20023dae:	d805      	bhi.n	20023dbc <HAL_RCC_HCPU_ConfigDvfs+0x38>
20023db0:	4629      	mov	r1, r5
20023db2:	4620      	mov	r0, r4
20023db4:	f7ff ffa2 	bl	20023cfc <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
20023db8:	2500      	movs	r5, #0
20023dba:	e035      	b.n	20023e28 <HAL_RCC_HCPU_ConfigDvfs+0xa4>
20023dbc:	2100      	movs	r1, #0
20023dbe:	4608      	mov	r0, r1
20023dc0:	f7ff ff12 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023dc4:	4620      	mov	r0, r4
20023dc6:	f7ff fe1f 	bl	20023a08 <HAL_RCC_HCPU_ConfigSxModeVolt>
20023dca:	20fa      	movs	r0, #250	@ 0xfa
20023dcc:	f7fd fd7f 	bl	200218ce <HAL_Delay_us>
20023dd0:	f7ff fed6 	bl	20023b80 <HAL_RCC_HCPU_DisableDLL1>
20023dd4:	2d30      	cmp	r5, #48	@ 0x30
20023dd6:	d80d      	bhi.n	20023df4 <HAL_RCC_HCPU_ConfigDvfs+0x70>
20023dd8:	f7fe fa94 	bl	20022304 <HAL_HPAON_DisableXT48>
20023ddc:	2100      	movs	r1, #0
20023dde:	4608      	mov	r0, r1
20023de0:	f7ff ff02 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023de4:	2204      	movs	r2, #4
20023de6:	2100      	movs	r1, #0
20023de8:	2030      	movs	r0, #48	@ 0x30
20023dea:	fbb0 f0f5 	udiv	r0, r0, r5
20023dee:	f7ff ff1f 	bl	20023c30 <HAL_RCC_HCPU_SetDiv>
20023df2:	e7e1      	b.n	20023db8 <HAL_RCC_HCPU_ConfigDvfs+0x34>
20023df4:	f7fe fa7a 	bl	200222ec <HAL_HPAON_EnableXT48>
20023df8:	4816      	ldr	r0, [pc, #88]	@ (20023e54 <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
20023dfa:	4368      	muls	r0, r5
20023dfc:	f7ff feb8 	bl	20023b70 <HAL_RCC_HCPU_EnableDLL1>
20023e00:	4605      	mov	r5, r0
20023e02:	2800      	cmp	r0, #0
20023e04:	d1c8      	bne.n	20023d98 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20023e06:	2101      	movs	r1, #1
20023e08:	2206      	movs	r2, #6
20023e0a:	4608      	mov	r0, r1
20023e0c:	f7ff ff10 	bl	20023c30 <HAL_RCC_HCPU_SetDiv>
20023e10:	2103      	movs	r1, #3
20023e12:	4628      	mov	r0, r5
20023e14:	f7ff fee8 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
20023e18:	e7ce      	b.n	20023db8 <HAL_RCC_HCPU_ConfigDvfs+0x34>
20023e1a:	2901      	cmp	r1, #1
20023e1c:	d909      	bls.n	20023e32 <HAL_RCC_HCPU_ConfigDvfs+0xae>
20023e1e:	4601      	mov	r1, r0
20023e20:	4620      	mov	r0, r4
20023e22:	f7ff ff2f 	bl	20023c84 <HAL_RCC_HCPU_SwitchDvfsD2S>
20023e26:	4605      	mov	r5, r0
20023e28:	2000      	movs	r0, #0
20023e2a:	7034      	strb	r4, [r6, #0]
20023e2c:	f7fd fd4f 	bl	200218ce <HAL_Delay_us>
20023e30:	e7b3      	b.n	20023d9a <HAL_RCC_HCPU_ConfigDvfs+0x16>
20023e32:	428b      	cmp	r3, r1
20023e34:	d103      	bne.n	20023e3e <HAL_RCC_HCPU_ConfigDvfs+0xba>
20023e36:	f04f 32ff 	mov.w	r2, #4294967295
20023e3a:	4611      	mov	r1, r2
20023e3c:	e7d4      	b.n	20023de8 <HAL_RCC_HCPU_ConfigDvfs+0x64>
20023e3e:	2190      	movs	r1, #144	@ 0x90
20023e40:	2002      	movs	r0, #2
20023e42:	f7ff ff1f 	bl	20023c84 <HAL_RCC_HCPU_SwitchDvfsD2S>
20023e46:	2800      	cmp	r0, #0
20023e48:	d1a6      	bne.n	20023d98 <HAL_RCC_HCPU_ConfigDvfs+0x14>
20023e4a:	e7b1      	b.n	20023db0 <HAL_RCC_HCPU_ConfigDvfs+0x2c>
20023e4c:	20042c18 	.word	0x20042c18
20023e50:	20026434 	.word	0x20026434
20023e54:	000f4240 	.word	0x000f4240

20023e58 <HAL_RCC_EnableModule>:
20023e58:	1c43      	adds	r3, r0, #1
20023e5a:	d014      	beq.n	20023e86 <HAL_RCC_EnableModule+0x2e>
20023e5c:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
20023e60:	b282      	uxth	r2, r0
20023e62:	d000      	beq.n	20023e66 <HAL_RCC_EnableModule+0xe>
20023e64:	e7fe      	b.n	20023e64 <HAL_RCC_EnableModule+0xc>
20023e66:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
20023e6a:	f3c0 2181 	ubfx	r1, r0, #10, #2
20023e6e:	f3c0 2301 	ubfx	r3, r0, #8, #2
20023e72:	b2d2      	uxtb	r2, r2
20023e74:	d108      	bne.n	20023e88 <HAL_RCC_EnableModule+0x30>
20023e76:	009b      	lsls	r3, r3, #2
20023e78:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20023e7c:	3310      	adds	r3, #16
20023e7e:	2101      	movs	r1, #1
20023e80:	fa01 f202 	lsl.w	r2, r1, r2
20023e84:	601a      	str	r2, [r3, #0]
20023e86:	4770      	bx	lr
20023e88:	2901      	cmp	r1, #1
20023e8a:	d104      	bne.n	20023e96 <HAL_RCC_EnableModule+0x3e>
20023e8c:	009b      	lsls	r3, r3, #2
20023e8e:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
20023e92:	3308      	adds	r3, #8
20023e94:	e7f3      	b.n	20023e7e <HAL_RCC_EnableModule+0x26>
20023e96:	2902      	cmp	r1, #2
20023e98:	d108      	bne.n	20023eac <HAL_RCC_EnableModule+0x54>
20023e9a:	2301      	movs	r3, #1
20023e9c:	4904      	ldr	r1, [pc, #16]	@ (20023eb0 <HAL_RCC_EnableModule+0x58>)
20023e9e:	4093      	lsls	r3, r2
20023ea0:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20023ea4:	4303      	orrs	r3, r0
20023ea6:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
20023eaa:	4770      	bx	lr
20023eac:	e7fe      	b.n	20023eac <HAL_RCC_EnableModule+0x54>
20023eae:	bf00      	nop
20023eb0:	50002000 	.word	0x50002000

20023eb4 <HAL_RCC_HCPU_ConfigHCLK>:
20023eb4:	28f0      	cmp	r0, #240	@ 0xf0
20023eb6:	d80d      	bhi.n	20023ed4 <HAL_RCC_HCPU_ConfigHCLK+0x20>
20023eb8:	2890      	cmp	r0, #144	@ 0x90
20023eba:	d807      	bhi.n	20023ecc <HAL_RCC_HCPU_ConfigHCLK+0x18>
20023ebc:	2830      	cmp	r0, #48	@ 0x30
20023ebe:	d807      	bhi.n	20023ed0 <HAL_RCC_HCPU_ConfigHCLK+0x1c>
20023ec0:	2818      	cmp	r0, #24
20023ec2:	bf94      	ite	ls
20023ec4:	2100      	movls	r1, #0
20023ec6:	2101      	movhi	r1, #1
20023ec8:	f7ff bf5c 	b.w	20023d84 <HAL_RCC_HCPU_ConfigDvfs>
20023ecc:	2103      	movs	r1, #3
20023ece:	e7fb      	b.n	20023ec8 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20023ed0:	2102      	movs	r1, #2
20023ed2:	e7f9      	b.n	20023ec8 <HAL_RCC_HCPU_ConfigHCLK+0x14>
20023ed4:	2001      	movs	r0, #1
20023ed6:	4770      	bx	lr

20023ed8 <BSP_OTP_CFG_READ.part.0>:
20023ed8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20023eda:	4606      	mov	r6, r0
20023edc:	2500      	movs	r5, #0
20023ede:	4608      	mov	r0, r1
20023ee0:	9f06      	ldr	r7, [sp, #24]
20023ee2:	5d59      	ldrb	r1, [r3, r5]
20023ee4:	29ff      	cmp	r1, #255	@ 0xff
20023ee6:	d101      	bne.n	20023eec <BSP_OTP_CFG_READ.part.0+0x14>
20023ee8:	2400      	movs	r4, #0
20023eea:	e013      	b.n	20023f14 <BSP_OTP_CFG_READ.part.0+0x3c>
20023eec:	195c      	adds	r4, r3, r5
20023eee:	42b1      	cmp	r1, r6
20023ef0:	7864      	ldrb	r4, [r4, #1]
20023ef2:	d006      	beq.n	20023f02 <BSP_OTP_CFG_READ.part.0+0x2a>
20023ef4:	1961      	adds	r1, r4, r5
20023ef6:	3102      	adds	r1, #2
20023ef8:	42b9      	cmp	r1, r7
20023efa:	daf5      	bge.n	20023ee8 <BSP_OTP_CFG_READ.part.0+0x10>
20023efc:	3402      	adds	r4, #2
20023efe:	4425      	add	r5, r4
20023f00:	e7ef      	b.n	20023ee2 <BSP_OTP_CFG_READ.part.0+0xa>
20023f02:	b13c      	cbz	r4, 20023f14 <BSP_OTP_CFG_READ.part.0+0x3c>
20023f04:	4294      	cmp	r4, r2
20023f06:	bfa8      	it	ge
20023f08:	4614      	movge	r4, r2
20023f0a:	3502      	adds	r5, #2
20023f0c:	4622      	mov	r2, r4
20023f0e:	1959      	adds	r1, r3, r5
20023f10:	f001 fc2d 	bl	2002576e <memcpy>
20023f14:	b2e0      	uxtb	r0, r4
20023f16:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}

20023f18 <BSP_OTP_CFG_READ>:
20023f18:	b410      	push	{r4}
20023f1a:	b11b      	cbz	r3, 20023f24 <BSP_OTP_CFG_READ+0xc>
20023f1c:	f85d 4b04 	ldr.w	r4, [sp], #4
20023f20:	f7ff bfda 	b.w	20023ed8 <BSP_OTP_CFG_READ.part.0>
20023f24:	4618      	mov	r0, r3
20023f26:	f85d 4b04 	ldr.w	r4, [sp], #4
20023f2a:	4770      	bx	lr

20023f2c <BSP_OTP_ReadCfg>:
20023f2c:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20023f2e:	9f08      	ldr	r7, [sp, #32]
20023f30:	4604      	mov	r4, r0
20023f32:	9700      	str	r7, [sp, #0]
20023f34:	460d      	mov	r5, r1
20023f36:	4616      	mov	r6, r2
20023f38:	f7ff ffee 	bl	20023f18 <BSP_OTP_CFG_READ>
20023f3c:	b998      	cbnz	r0, 20023f66 <BSP_OTP_ReadCfg+0x3a>
20023f3e:	f44f 7780 	mov.w	r7, #256	@ 0x100
20023f42:	4632      	mov	r2, r6
20023f44:	4629      	mov	r1, r5
20023f46:	4620      	mov	r0, r4
20023f48:	4b08      	ldr	r3, [pc, #32]	@ (20023f6c <BSP_OTP_ReadCfg+0x40>)
20023f4a:	9700      	str	r7, [sp, #0]
20023f4c:	f7ff ffc4 	bl	20023ed8 <BSP_OTP_CFG_READ.part.0>
20023f50:	b948      	cbnz	r0, 20023f66 <BSP_OTP_ReadCfg+0x3a>
20023f52:	4632      	mov	r2, r6
20023f54:	4629      	mov	r1, r5
20023f56:	4620      	mov	r0, r4
20023f58:	4b05      	ldr	r3, [pc, #20]	@ (20023f70 <BSP_OTP_ReadCfg+0x44>)
20023f5a:	9708      	str	r7, [sp, #32]
20023f5c:	b003      	add	sp, #12
20023f5e:	e8bd 40f0 	ldmia.w	sp!, {r4, r5, r6, r7, lr}
20023f62:	f7ff bfb9 	b.w	20023ed8 <BSP_OTP_CFG_READ.part.0>
20023f66:	b003      	add	sp, #12
20023f68:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023f6a:	bf00      	nop
20023f6c:	2004cb28 	.word	0x2004cb28
20023f70:	2004ca28 	.word	0x2004ca28

20023f74 <BSP_GetFlashByAddr>:
20023f74:	f100 4370 	add.w	r3, r0, #4026531840	@ 0xf0000000
20023f78:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20023f7c:	d30c      	bcc.n	20023f98 <BSP_GetFlashByAddr+0x24>
20023f7e:	f100 436e 	add.w	r3, r0, #3992977408	@ 0xee000000
20023f82:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20023f86:	d309      	bcc.n	20023f9c <BSP_GetFlashByAddr+0x28>
20023f88:	f100 406c 	add.w	r0, r0, #3959422976	@ 0xec000000
20023f8c:	f1b0 6f40 	cmp.w	r0, #201326592	@ 0xc000000
20023f90:	4803      	ldr	r0, [pc, #12]	@ (20023fa0 <BSP_GetFlashByAddr+0x2c>)
20023f92:	bf28      	it	cs
20023f94:	2000      	movcs	r0, #0
20023f96:	4770      	bx	lr
20023f98:	4802      	ldr	r0, [pc, #8]	@ (20023fa4 <BSP_GetFlashByAddr+0x30>)
20023f9a:	4770      	bx	lr
20023f9c:	4802      	ldr	r0, [pc, #8]	@ (20023fa8 <BSP_GetFlashByAddr+0x34>)
20023f9e:	4770      	bx	lr
20023fa0:	50043000 	.word	0x50043000
20023fa4:	50041000 	.word	0x50041000
20023fa8:	50042000 	.word	0x50042000

20023fac <BSP_Get_UserOTP_Cache>:
20023fac:	4800      	ldr	r0, [pc, #0]	@ (20023fb0 <BSP_Get_UserOTP_Cache+0x4>)
20023fae:	4770      	bx	lr
20023fb0:	2004cb28 	.word	0x2004cb28

20023fb4 <BSP_Get_CustOTP_Cache>:
20023fb4:	4800      	ldr	r0, [pc, #0]	@ (20023fb8 <BSP_Get_CustOTP_Cache+0x4>)
20023fb6:	4770      	bx	lr
20023fb8:	2004ca28 	.word	0x2004ca28

20023fbc <BSP_System_Config>:
20023fbc:	b570      	push	{r4, r5, r6, lr}
20023fbe:	b09c      	sub	sp, #112	@ 0x70
20023fc0:	f7fe f93a 	bl	20022238 <HAL_EFUSE_Init>
20023fc4:	4604      	mov	r4, r0
20023fc6:	2800      	cmp	r0, #0
20023fc8:	d160      	bne.n	2002408c <BSP_System_Config+0xd0>
20023fca:	f7fd fc80 	bl	200218ce <HAL_Delay_us>
20023fce:	200a      	movs	r0, #10
20023fd0:	f7fd fc7d 	bl	200218ce <HAL_Delay_us>
20023fd4:	2220      	movs	r2, #32
20023fd6:	4621      	mov	r1, r4
20023fd8:	482e      	ldr	r0, [pc, #184]	@ (20024094 <BSP_System_Config+0xd8>)
20023fda:	f001 fb59 	bl	20025690 <memset>
20023fde:	2220      	movs	r2, #32
20023fe0:	f44f 7080 	mov.w	r0, #256	@ 0x100
20023fe4:	492b      	ldr	r1, [pc, #172]	@ (20024094 <BSP_System_Config+0xd8>)
20023fe6:	f7fe f929 	bl	2002223c <HAL_EFUSE_Read>
20023fea:	2820      	cmp	r0, #32
20023fec:	4605      	mov	r5, r0
20023fee:	d14f      	bne.n	20024090 <BSP_System_Config+0xd4>
20023ff0:	f7ff fcb6 	bl	20023960 <HAL_PMU_LoadCalData>
20023ff4:	f7fd fb70 	bl	200216d8 <BSP_GetOtpBase>
20023ff8:	4606      	mov	r6, r0
20023ffa:	2240      	movs	r2, #64	@ 0x40
20023ffc:	4621      	mov	r1, r4
20023ffe:	a80c      	add	r0, sp, #48	@ 0x30
20024000:	f001 fb46 	bl	20025690 <memset>
20024004:	4630      	mov	r0, r6
20024006:	f7ff ffb5 	bl	20023f74 <BSP_GetFlashByAddr>
2002400a:	900c      	str	r0, [sp, #48]	@ 0x30
2002400c:	b900      	cbnz	r0, 20024010 <BSP_System_Config+0x54>
2002400e:	e7fe      	b.n	2002400e <BSP_System_Config+0x52>
20024010:	a80c      	add	r0, sp, #48	@ 0x30
20024012:	f7fe fd84 	bl	20022b1e <HAL_FLASH_PreInit>
20024016:	b100      	cbz	r0, 2002401a <BSP_System_Config+0x5e>
20024018:	e7fe      	b.n	20024018 <BSP_System_Config+0x5c>
2002401a:	462b      	mov	r3, r5
2002401c:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
20024020:	aa04      	add	r2, sp, #16
20024022:	a80c      	add	r0, sp, #48	@ 0x30
20024024:	f7fe fddd 	bl	20022be2 <HAL_QSPI_READ_OTP>
20024028:	2800      	cmp	r0, #0
2002402a:	dc00      	bgt.n	2002402e <BSP_System_Config+0x72>
2002402c:	e7fe      	b.n	2002402c <BSP_System_Config+0x70>
2002402e:	f7ff ffbd 	bl	20023fac <BSP_Get_UserOTP_Cache>
20024032:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024036:	4602      	mov	r2, r0
20024038:	f44f 5100 	mov.w	r1, #8192	@ 0x2000
2002403c:	a80c      	add	r0, sp, #48	@ 0x30
2002403e:	f7fe fdd0 	bl	20022be2 <HAL_QSPI_READ_OTP>
20024042:	2800      	cmp	r0, #0
20024044:	dc00      	bgt.n	20024048 <BSP_System_Config+0x8c>
20024046:	e7fe      	b.n	20024046 <BSP_System_Config+0x8a>
20024048:	f7ff ffb4 	bl	20023fb4 <BSP_Get_CustOTP_Cache>
2002404c:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024050:	4602      	mov	r2, r0
20024052:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20024056:	a80c      	add	r0, sp, #48	@ 0x30
20024058:	f7fe fdc3 	bl	20022be2 <HAL_QSPI_READ_OTP>
2002405c:	2800      	cmp	r0, #0
2002405e:	dc00      	bgt.n	20024062 <BSP_System_Config+0xa6>
20024060:	e7fe      	b.n	20024060 <BSP_System_Config+0xa4>
20024062:	9000      	str	r0, [sp, #0]
20024064:	2204      	movs	r2, #4
20024066:	2003      	movs	r0, #3
20024068:	ab04      	add	r3, sp, #16
2002406a:	a903      	add	r1, sp, #12
2002406c:	f7ff ff5e 	bl	20023f2c <BSP_OTP_ReadCfg>
20024070:	b910      	cbnz	r0, 20024078 <BSP_System_Config+0xbc>
20024072:	2000      	movs	r0, #0
20024074:	b01c      	add	sp, #112	@ 0x70
20024076:	bd70      	pop	{r4, r5, r6, pc}
20024078:	9803      	ldr	r0, [sp, #12]
2002407a:	2800      	cmp	r0, #0
2002407c:	d0f9      	beq.n	20024072 <BSP_System_Config+0xb6>
2002407e:	f240 33ff 	movw	r3, #1023	@ 0x3ff
20024082:	4298      	cmp	r0, r3
20024084:	d0f5      	beq.n	20024072 <BSP_System_Config+0xb6>
20024086:	f002 fc6f 	bl	20026968 <BSP_HxtCbank_Config>
2002408a:	e7f2      	b.n	20024072 <BSP_System_Config+0xb6>
2002408c:	2001      	movs	r0, #1
2002408e:	e7f1      	b.n	20024074 <BSP_System_Config+0xb8>
20024090:	2002      	movs	r0, #2
20024092:	e7ef      	b.n	20024074 <BSP_System_Config+0xb8>
20024094:	2004cc28 	.word	0x2004cc28

20024098 <BSP_CONFIG_get>:
20024098:	b5f0      	push	{r4, r5, r6, r7, lr}
2002409a:	4604      	mov	r4, r0
2002409c:	4610      	mov	r0, r2
2002409e:	b109      	cbz	r1, 200240a4 <BSP_CONFIG_get+0xc>
200240a0:	2a00      	cmp	r2, #0
200240a2:	dc01      	bgt.n	200240a8 <BSP_CONFIG_get+0x10>
200240a4:	2000      	movs	r0, #0
200240a6:	bdf0      	pop	{r4, r5, r6, r7, pc}
200240a8:	4b56      	ldr	r3, [pc, #344]	@ (20024204 <BSP_CONFIG_get+0x16c>)
200240aa:	781a      	ldrb	r2, [r3, #0]
200240ac:	2a00      	cmp	r2, #0
200240ae:	d0f9      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
200240b0:	2c04      	cmp	r4, #4
200240b2:	d152      	bne.n	2002415a <BSP_CONFIG_get+0xc2>
200240b4:	280d      	cmp	r0, #13
200240b6:	ddf5      	ble.n	200240a4 <BSP_CONFIG_get+0xc>
200240b8:	795a      	ldrb	r2, [r3, #5]
200240ba:	f893 c004 	ldrb.w	ip, [r3, #4]
200240be:	0212      	lsls	r2, r2, #8
200240c0:	f402 6270 	and.w	r2, r2, #3840	@ 0xf00
200240c4:	ea4c 0c02 	orr.w	ip, ip, r2
200240c8:	f8a1 c000 	strh.w	ip, [r1]
200240cc:	799d      	ldrb	r5, [r3, #6]
200240ce:	795a      	ldrb	r2, [r3, #5]
200240d0:	012d      	lsls	r5, r5, #4
200240d2:	f005 0510 	and.w	r5, r5, #16
200240d6:	ea45 1512 	orr.w	r5, r5, r2, lsr #4
200240da:	808d      	strh	r5, [r1, #4]
200240dc:	79df      	ldrb	r7, [r3, #7]
200240de:	799a      	ldrb	r2, [r3, #6]
200240e0:	01ff      	lsls	r7, r7, #7
200240e2:	f407 6778 	and.w	r7, r7, #3968	@ 0xf80
200240e6:	ea47 0752 	orr.w	r7, r7, r2, lsr #1
200240ea:	804f      	strh	r7, [r1, #2]
200240ec:	7a1c      	ldrb	r4, [r3, #8]
200240ee:	79da      	ldrb	r2, [r3, #7]
200240f0:	00e4      	lsls	r4, r4, #3
200240f2:	f004 0418 	and.w	r4, r4, #24
200240f6:	ea44 1452 	orr.w	r4, r4, r2, lsr #5
200240fa:	80cc      	strh	r4, [r1, #6]
200240fc:	7a5a      	ldrb	r2, [r3, #9]
200240fe:	7a1e      	ldrb	r6, [r3, #8]
20024100:	0192      	lsls	r2, r2, #6
20024102:	f402 627c 	and.w	r2, r2, #4032	@ 0xfc0
20024106:	ea42 0296 	orr.w	r2, r2, r6, lsr #2
2002410a:	810a      	strh	r2, [r1, #8]
2002410c:	7a9e      	ldrb	r6, [r3, #10]
2002410e:	7a5b      	ldrb	r3, [r3, #9]
20024110:	00b6      	lsls	r6, r6, #2
20024112:	f006 063c 	and.w	r6, r6, #60	@ 0x3c
20024116:	ea46 1393 	orr.w	r3, r6, r3, lsr #6
2002411a:	eb05 0585 	add.w	r5, r5, r5, lsl #2
2002411e:	eb04 0484 	add.w	r4, r4, r4, lsl #2
20024122:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024126:	eb05 0585 	add.w	r5, r5, r5, lsl #2
2002412a:	eb04 0484 	add.w	r4, r4, r4, lsl #2
2002412e:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024132:	00ad      	lsls	r5, r5, #2
20024134:	00a4      	lsls	r4, r4, #2
20024136:	009b      	lsls	r3, r3, #2
20024138:	808d      	strh	r5, [r1, #4]
2002413a:	80cc      	strh	r4, [r1, #6]
2002413c:	814b      	strh	r3, [r1, #10]
2002413e:	f1bc 0f00 	cmp.w	ip, #0
20024142:	d0af      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
20024144:	2d00      	cmp	r5, #0
20024146:	d0ad      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
20024148:	2f00      	cmp	r7, #0
2002414a:	d0ab      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
2002414c:	2c00      	cmp	r4, #0
2002414e:	d0a9      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
20024150:	2a00      	cmp	r2, #0
20024152:	d0a7      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
20024154:	2b00      	cmp	r3, #0
20024156:	d0a5      	beq.n	200240a4 <BSP_CONFIG_get+0xc>
20024158:	e7a5      	b.n	200240a6 <BSP_CONFIG_get+0xe>
2002415a:	2c06      	cmp	r4, #6
2002415c:	d132      	bne.n	200241c4 <BSP_CONFIG_get+0x12c>
2002415e:	280e      	cmp	r0, #14
20024160:	dda0      	ble.n	200240a4 <BSP_CONFIG_get+0xc>
20024162:	f002 0207 	and.w	r2, r2, #7
20024166:	700a      	strb	r2, [r1, #0]
20024168:	781a      	ldrb	r2, [r3, #0]
2002416a:	f3c2 04c0 	ubfx	r4, r2, #3, #1
2002416e:	704c      	strb	r4, [r1, #1]
20024170:	785c      	ldrb	r4, [r3, #1]
20024172:	0912      	lsrs	r2, r2, #4
20024174:	f004 050f 	and.w	r5, r4, #15
20024178:	0924      	lsrs	r4, r4, #4
2002417a:	708a      	strb	r2, [r1, #2]
2002417c:	70cd      	strb	r5, [r1, #3]
2002417e:	710c      	strb	r4, [r1, #4]
20024180:	7b5c      	ldrb	r4, [r3, #13]
20024182:	789e      	ldrb	r6, [r3, #2]
20024184:	0924      	lsrs	r4, r4, #4
20024186:	730c      	strb	r4, [r1, #12]
20024188:	7b9d      	ldrb	r5, [r3, #14]
2002418a:	f005 050f 	and.w	r5, r5, #15
2002418e:	734d      	strb	r5, [r1, #13]
20024190:	0935      	lsrs	r5, r6, #4
20024192:	718d      	strb	r5, [r1, #6]
20024194:	78dd      	ldrb	r5, [r3, #3]
20024196:	f006 060f 	and.w	r6, r6, #15
2002419a:	f005 070f 	and.w	r7, r5, #15
2002419e:	71cf      	strb	r7, [r1, #7]
200241a0:	7b5f      	ldrb	r7, [r3, #13]
200241a2:	092d      	lsrs	r5, r5, #4
200241a4:	f007 0707 	and.w	r7, r7, #7
200241a8:	720f      	strb	r7, [r1, #8]
200241aa:	7b5b      	ldrb	r3, [r3, #13]
200241ac:	738d      	strb	r5, [r1, #14]
200241ae:	f3c3 03c0 	ubfx	r3, r3, #3, #1
200241b2:	724b      	strb	r3, [r1, #9]
200241b4:	714e      	strb	r6, [r1, #5]
200241b6:	2a00      	cmp	r2, #0
200241b8:	f43f af74 	beq.w	200240a4 <BSP_CONFIG_get+0xc>
200241bc:	2c00      	cmp	r4, #0
200241be:	f43f af71 	beq.w	200240a4 <BSP_CONFIG_get+0xc>
200241c2:	e770      	b.n	200240a6 <BSP_CONFIG_get+0xe>
200241c4:	2c15      	cmp	r4, #21
200241c6:	f47f af6d 	bne.w	200240a4 <BSP_CONFIG_get+0xc>
200241ca:	2807      	cmp	r0, #7
200241cc:	f77f af6a 	ble.w	200240a4 <BSP_CONFIG_get+0xc>
200241d0:	7a9a      	ldrb	r2, [r3, #10]
200241d2:	0912      	lsrs	r2, r2, #4
200241d4:	700a      	strb	r2, [r1, #0]
200241d6:	7ada      	ldrb	r2, [r3, #11]
200241d8:	f002 023f 	and.w	r2, r2, #63	@ 0x3f
200241dc:	704a      	strb	r2, [r1, #1]
200241de:	7b1a      	ldrb	r2, [r3, #12]
200241e0:	7adc      	ldrb	r4, [r3, #11]
200241e2:	0092      	lsls	r2, r2, #2
200241e4:	f002 021c 	and.w	r2, r2, #28
200241e8:	ea42 1294 	orr.w	r2, r2, r4, lsr #6
200241ec:	708a      	strb	r2, [r1, #2]
200241ee:	7b1a      	ldrb	r2, [r3, #12]
200241f0:	08d2      	lsrs	r2, r2, #3
200241f2:	70ca      	strb	r2, [r1, #3]
200241f4:	7b9a      	ldrb	r2, [r3, #14]
200241f6:	7bdb      	ldrb	r3, [r3, #15]
200241f8:	011b      	lsls	r3, r3, #4
200241fa:	ea43 1312 	orr.w	r3, r3, r2, lsr #4
200241fe:	710b      	strb	r3, [r1, #4]
20024200:	e751      	b.n	200240a6 <BSP_CONFIG_get+0xe>
20024202:	bf00      	nop
20024204:	2004cc28 	.word	0x2004cc28

20024208 <spi_nor_get_ext_cfg_by_id>:
20024208:	2000      	movs	r0, #0
2002420a:	4770      	bx	lr

2002420c <spi_nor_get_user_flash_cfg>:
2002420c:	2000      	movs	r0, #0
2002420e:	4770      	bx	lr

20024210 <spi_flash_get_rdid>:
20024210:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024212:	4604      	mov	r4, r0
20024214:	3801      	subs	r0, #1
20024216:	b2c0      	uxtb	r0, r0
20024218:	28fd      	cmp	r0, #253	@ 0xfd
2002421a:	d816      	bhi.n	2002424a <spi_flash_get_rdid+0x3a>
2002421c:	2500      	movs	r5, #0
2002421e:	4e0d      	ldr	r6, [pc, #52]	@ (20024254 <spi_flash_get_rdid+0x44>)
20024220:	f856 0b04 	ldr.w	r0, [r6], #4
20024224:	7807      	ldrb	r7, [r0, #0]
20024226:	b937      	cbnz	r7, 20024236 <spi_flash_get_rdid+0x26>
20024228:	3501      	adds	r5, #1
2002422a:	2d06      	cmp	r5, #6
2002422c:	d1f8      	bne.n	20024220 <spi_flash_get_rdid+0x10>
2002422e:	4620      	mov	r0, r4
20024230:	f7ff ffec 	bl	2002420c <spi_nor_get_user_flash_cfg>
20024234:	e00d      	b.n	20024252 <spi_flash_get_rdid+0x42>
20024236:	42a7      	cmp	r7, r4
20024238:	d105      	bne.n	20024246 <spi_flash_get_rdid+0x36>
2002423a:	7847      	ldrb	r7, [r0, #1]
2002423c:	4297      	cmp	r7, r2
2002423e:	d102      	bne.n	20024246 <spi_flash_get_rdid+0x36>
20024240:	7887      	ldrb	r7, [r0, #2]
20024242:	428f      	cmp	r7, r1
20024244:	d003      	beq.n	2002424e <spi_flash_get_rdid+0x3e>
20024246:	3008      	adds	r0, #8
20024248:	e7ec      	b.n	20024224 <spi_flash_get_rdid+0x14>
2002424a:	2000      	movs	r0, #0
2002424c:	e001      	b.n	20024252 <spi_flash_get_rdid+0x42>
2002424e:	b103      	cbz	r3, 20024252 <spi_flash_get_rdid+0x42>
20024250:	701d      	strb	r5, [r3, #0]
20024252:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024254:	20042c1c 	.word	0x20042c1c

20024258 <spi_flash_get_cmd_by_id>:
20024258:	b507      	push	{r0, r1, r2, lr}
2002425a:	f10d 0307 	add.w	r3, sp, #7
2002425e:	f7ff ffd7 	bl	20024210 <spi_flash_get_rdid>
20024262:	4b06      	ldr	r3, [pc, #24]	@ (2002427c <spi_flash_get_cmd_by_id+0x24>)
20024264:	b140      	cbz	r0, 20024278 <spi_flash_get_cmd_by_id+0x20>
20024266:	f44f 7105 	mov.w	r1, #532	@ 0x214
2002426a:	f89d 2007 	ldrb.w	r2, [sp, #7]
2002426e:	fb01 3002 	mla	r0, r1, r2, r3
20024272:	b003      	add	sp, #12
20024274:	f85d fb04 	ldr.w	pc, [sp], #4
20024278:	4618      	mov	r0, r3
2002427a:	e7fa      	b.n	20024272 <spi_flash_get_cmd_by_id+0x1a>
2002427c:	20042e64 	.word	0x20042e64

20024280 <spi_flash_get_size_by_id>:
20024280:	b508      	push	{r3, lr}
20024282:	2300      	movs	r3, #0
20024284:	f7ff ffc4 	bl	20024210 <spi_flash_get_rdid>
20024288:	b108      	cbz	r0, 2002428e <spi_flash_get_size_by_id+0xe>
2002428a:	6840      	ldr	r0, [r0, #4]
2002428c:	bd08      	pop	{r3, pc}
2002428e:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
20024292:	e7fb      	b.n	2002428c <spi_flash_get_size_by_id+0xc>

20024294 <spi_flash_is_support_dtr>:
20024294:	b508      	push	{r3, lr}
20024296:	2300      	movs	r3, #0
20024298:	f7ff ffba 	bl	20024210 <spi_flash_get_rdid>
2002429c:	b110      	cbz	r0, 200242a4 <spi_flash_is_support_dtr+0x10>
2002429e:	78c0      	ldrb	r0, [r0, #3]
200242a0:	f000 0001 	and.w	r0, r0, #1
200242a4:	bd08      	pop	{r3, pc}
	...

200242a8 <spi_flash_get_otp_base>:
200242a8:	b508      	push	{r3, lr}
200242aa:	2300      	movs	r3, #0
200242ac:	f7ff ffb0 	bl	20024210 <spi_flash_get_rdid>
200242b0:	b130      	cbz	r0, 200242c0 <spi_flash_get_otp_base+0x18>
200242b2:	78c3      	ldrb	r3, [r0, #3]
200242b4:	4803      	ldr	r0, [pc, #12]	@ (200242c4 <spi_flash_get_otp_base+0x1c>)
200242b6:	f003 0306 	and.w	r3, r3, #6
200242ba:	2b02      	cmp	r3, #2
200242bc:	bf18      	it	ne
200242be:	2000      	movne	r0, #0
200242c0:	bd08      	pop	{r3, pc}
200242c2:	bf00      	nop
200242c4:	00ffc000 	.word	0x00ffc000

200242c8 <spi_nand_get_user_flash_cfg>:
200242c8:	2000      	movs	r0, #0
200242ca:	4770      	bx	lr

200242cc <spi_nand_get_rdid>:
200242cc:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200242ce:	4604      	mov	r4, r0
200242d0:	3801      	subs	r0, #1
200242d2:	b2c0      	uxtb	r0, r0
200242d4:	28fd      	cmp	r0, #253	@ 0xfd
200242d6:	d816      	bhi.n	20024306 <spi_nand_get_rdid+0x3a>
200242d8:	2500      	movs	r5, #0
200242da:	4e0d      	ldr	r6, [pc, #52]	@ (20024310 <spi_nand_get_rdid+0x44>)
200242dc:	f856 0b04 	ldr.w	r0, [r6], #4
200242e0:	7807      	ldrb	r7, [r0, #0]
200242e2:	b937      	cbnz	r7, 200242f2 <spi_nand_get_rdid+0x26>
200242e4:	3501      	adds	r5, #1
200242e6:	2d06      	cmp	r5, #6
200242e8:	d1f8      	bne.n	200242dc <spi_nand_get_rdid+0x10>
200242ea:	4620      	mov	r0, r4
200242ec:	f7ff ffec 	bl	200242c8 <spi_nand_get_user_flash_cfg>
200242f0:	e00d      	b.n	2002430e <spi_nand_get_rdid+0x42>
200242f2:	42a7      	cmp	r7, r4
200242f4:	d105      	bne.n	20024302 <spi_nand_get_rdid+0x36>
200242f6:	7847      	ldrb	r7, [r0, #1]
200242f8:	4297      	cmp	r7, r2
200242fa:	d102      	bne.n	20024302 <spi_nand_get_rdid+0x36>
200242fc:	7887      	ldrb	r7, [r0, #2]
200242fe:	428f      	cmp	r7, r1
20024300:	d003      	beq.n	2002430a <spi_nand_get_rdid+0x3e>
20024302:	3008      	adds	r0, #8
20024304:	e7ec      	b.n	200242e0 <spi_nand_get_rdid+0x14>
20024306:	2000      	movs	r0, #0
20024308:	e001      	b.n	2002430e <spi_nand_get_rdid+0x42>
2002430a:	b103      	cbz	r3, 2002430e <spi_nand_get_rdid+0x42>
2002430c:	701d      	strb	r5, [r3, #0]
2002430e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024310:	20043adc 	.word	0x20043adc

20024314 <spi_nand_get_cmd_by_id>:
20024314:	b507      	push	{r0, r1, r2, lr}
20024316:	f10d 0307 	add.w	r3, sp, #7
2002431a:	f7ff ffd7 	bl	200242cc <spi_nand_get_rdid>
2002431e:	b130      	cbz	r0, 2002432e <spi_nand_get_cmd_by_id+0x1a>
20024320:	f44f 7205 	mov.w	r2, #532	@ 0x214
20024324:	f89d 3007 	ldrb.w	r3, [sp, #7]
20024328:	4802      	ldr	r0, [pc, #8]	@ (20024334 <spi_nand_get_cmd_by_id+0x20>)
2002432a:	fb02 0003 	mla	r0, r2, r3, r0
2002432e:	b003      	add	sp, #12
20024330:	f85d fb04 	ldr.w	pc, [sp], #4
20024334:	20043d24 	.word	0x20043d24

20024338 <spi_nand_get_ext_cfg_by_id>:
20024338:	2000      	movs	r0, #0
2002433a:	4770      	bx	lr

2002433c <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
2002433c:	f04f 30ff 	mov.w	r0, #4294967295
20024340:	4770      	bx	lr
	...

20024344 <spi_nand_get_default_ctable>:
20024344:	b508      	push	{r3, lr}
20024346:	f7ff fff9 	bl	2002433c <HAL_GET_NAND_FLASH_DEFAUT_IDX>
2002434a:	1e03      	subs	r3, r0, #0
2002434c:	bfa5      	ittet	ge
2002434e:	f44f 7205 	movge.w	r2, #532	@ 0x214
20024352:	4802      	ldrge	r0, [pc, #8]	@ (2002435c <spi_nand_get_default_ctable+0x18>)
20024354:	2000      	movlt	r0, #0
20024356:	fb02 0003 	mlage	r0, r2, r3, r0
2002435a:	bd08      	pop	{r3, pc}
2002435c:	20043d24 	.word	0x20043d24

20024360 <spi_nand_get_size_by_id>:
20024360:	b508      	push	{r3, lr}
20024362:	2300      	movs	r3, #0
20024364:	f7ff ffb2 	bl	200242cc <spi_nand_get_rdid>
20024368:	b108      	cbz	r0, 2002436e <spi_nand_get_size_by_id+0xe>
2002436a:	6840      	ldr	r0, [r0, #4]
2002436c:	bd08      	pop	{r3, pc}
2002436e:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20024372:	e7fb      	b.n	2002436c <spi_nand_get_size_by_id+0xc>

20024374 <spi_nand_get_plane_select_flag>:
20024374:	b508      	push	{r3, lr}
20024376:	2300      	movs	r3, #0
20024378:	f7ff ffa8 	bl	200242cc <spi_nand_get_rdid>
2002437c:	b110      	cbz	r0, 20024384 <spi_nand_get_plane_select_flag+0x10>
2002437e:	78c0      	ldrb	r0, [r0, #3]
20024380:	f3c0 0040 	ubfx	r0, r0, #1, #1
20024384:	bd08      	pop	{r3, pc}

20024386 <spi_nand_get_big_page_flag>:
20024386:	b508      	push	{r3, lr}
20024388:	2300      	movs	r3, #0
2002438a:	f7ff ff9f 	bl	200242cc <spi_nand_get_rdid>
2002438e:	b110      	cbz	r0, 20024396 <spi_nand_get_big_page_flag+0x10>
20024390:	78c0      	ldrb	r0, [r0, #3]
20024392:	f3c0 0081 	ubfx	r0, r0, #2, #2
20024396:	bd08      	pop	{r3, pc}

20024398 <spi_nand_get_ecc_mode>:
20024398:	b508      	push	{r3, lr}
2002439a:	2300      	movs	r3, #0
2002439c:	f7ff ff96 	bl	200242cc <spi_nand_get_rdid>
200243a0:	b108      	cbz	r0, 200243a6 <spi_nand_get_ecc_mode+0xe>
200243a2:	78c0      	ldrb	r0, [r0, #3]
200243a4:	0900      	lsrs	r0, r0, #4
200243a6:	bd08      	pop	{r3, pc}

200243a8 <bbm_map_check.part.0>:
200243a8:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
200243aa:	4b21      	ldr	r3, [pc, #132]	@ (20024430 <bbm_map_check.part.0+0x88>)
200243ac:	4606      	mov	r6, r0
200243ae:	681d      	ldr	r5, [r3, #0]
200243b0:	4b20      	ldr	r3, [pc, #128]	@ (20024434 <bbm_map_check.part.0+0x8c>)
200243b2:	3d04      	subs	r5, #4
200243b4:	681f      	ldr	r7, [r3, #0]
200243b6:	2300      	movs	r3, #0
200243b8:	f100 0e1a 	add.w	lr, r0, #26
200243bc:	42ab      	cmp	r3, r5
200243be:	db02      	blt.n	200243c6 <bbm_map_check.part.0+0x1e>
200243c0:	2000      	movs	r0, #0
200243c2:	b003      	add	sp, #12
200243c4:	bdf0      	pop	{r4, r5, r6, r7, pc}
200243c6:	8b31      	ldrh	r1, [r6, #24]
200243c8:	b321      	cbz	r1, 20024414 <bbm_map_check.part.0+0x6c>
200243ca:	8b72      	ldrh	r2, [r6, #26]
200243cc:	b33a      	cbz	r2, 2002441e <bbm_map_check.part.0+0x76>
200243ce:	42b9      	cmp	r1, r7
200243d0:	d201      	bcs.n	200243d6 <bbm_map_check.part.0+0x2e>
200243d2:	4297      	cmp	r7, r2
200243d4:	d905      	bls.n	200243e2 <bbm_map_check.part.0+0x3a>
200243d6:	4b18      	ldr	r3, [pc, #96]	@ (20024438 <bbm_map_check.part.0+0x90>)
200243d8:	681b      	ldr	r3, [r3, #0]
200243da:	b10b      	cbz	r3, 200243e0 <bbm_map_check.part.0+0x38>
200243dc:	4817      	ldr	r0, [pc, #92]	@ (2002443c <bbm_map_check.part.0+0x94>)
200243de:	4798      	blx	r3
200243e0:	e7fe      	b.n	200243e0 <bbm_map_check.part.0+0x38>
200243e2:	3301      	adds	r3, #1
200243e4:	461c      	mov	r4, r3
200243e6:	42ac      	cmp	r4, r5
200243e8:	db01      	blt.n	200243ee <bbm_map_check.part.0+0x46>
200243ea:	3604      	adds	r6, #4
200243ec:	e7e6      	b.n	200243bc <bbm_map_check.part.0+0x14>
200243ee:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
200243f2:	f1bc 0f00 	cmp.w	ip, #0
200243f6:	d0f8      	beq.n	200243ea <bbm_map_check.part.0+0x42>
200243f8:	4562      	cmp	r2, ip
200243fa:	d109      	bne.n	20024410 <bbm_map_check.part.0+0x68>
200243fc:	4b0e      	ldr	r3, [pc, #56]	@ (20024438 <bbm_map_check.part.0+0x90>)
200243fe:	681d      	ldr	r5, [r3, #0]
20024400:	b12d      	cbz	r5, 2002440e <bbm_map_check.part.0+0x66>
20024402:	3406      	adds	r4, #6
20024404:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
20024408:	480d      	ldr	r0, [pc, #52]	@ (20024440 <bbm_map_check.part.0+0x98>)
2002440a:	9200      	str	r2, [sp, #0]
2002440c:	47a8      	blx	r5
2002440e:	e7fe      	b.n	2002440e <bbm_map_check.part.0+0x66>
20024410:	3401      	adds	r4, #1
20024412:	e7e8      	b.n	200243e6 <bbm_map_check.part.0+0x3e>
20024414:	eb00 0283 	add.w	r2, r0, r3, lsl #2
20024418:	8b52      	ldrh	r2, [r2, #26]
2002441a:	2a00      	cmp	r2, #0
2002441c:	d0d0      	beq.n	200243c0 <bbm_map_check.part.0+0x18>
2002441e:	4a06      	ldr	r2, [pc, #24]	@ (20024438 <bbm_map_check.part.0+0x90>)
20024420:	6814      	ldr	r4, [r2, #0]
20024422:	b124      	cbz	r4, 2002442e <bbm_map_check.part.0+0x86>
20024424:	eb00 0383 	add.w	r3, r0, r3, lsl #2
20024428:	8b5a      	ldrh	r2, [r3, #26]
2002442a:	4806      	ldr	r0, [pc, #24]	@ (20024444 <bbm_map_check.part.0+0x9c>)
2002442c:	47a0      	blx	r4
2002442e:	e7fe      	b.n	2002442e <bbm_map_check.part.0+0x86>
20024430:	2004cc58 	.word	0x2004cc58
20024434:	2004cc5c 	.word	0x2004cc5c
20024438:	2004cc48 	.word	0x2004cc48
2002443c:	20025f74 	.word	0x20025f74
20024440:	20025f91 	.word	0x20025f91
20024444:	20025fde 	.word	0x20025fde

20024448 <bbm_crc_check>:
20024448:	f04f 32ff 	mov.w	r2, #4294967295
2002444c:	b510      	push	{r4, lr}
2002444e:	4c07      	ldr	r4, [pc, #28]	@ (2002446c <bbm_crc_check+0x24>)
20024450:	4401      	add	r1, r0
20024452:	4288      	cmp	r0, r1
20024454:	d101      	bne.n	2002445a <bbm_crc_check+0x12>
20024456:	43d0      	mvns	r0, r2
20024458:	bd10      	pop	{r4, pc}
2002445a:	f810 3b01 	ldrb.w	r3, [r0], #1
2002445e:	4053      	eors	r3, r2
20024460:	b2db      	uxtb	r3, r3
20024462:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
20024466:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
2002446a:	e7f2      	b.n	20024452 <bbm_crc_check+0xa>
2002446c:	20026464 	.word	0x20026464

20024470 <bbm_get_phy_blk>:
20024470:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024472:	4b14      	ldr	r3, [pc, #80]	@ (200244c4 <bbm_get_phy_blk+0x54>)
20024474:	4601      	mov	r1, r0
20024476:	681e      	ldr	r6, [r3, #0]
20024478:	42b0      	cmp	r0, r6
2002447a:	d21e      	bcs.n	200244ba <bbm_get_phy_blk+0x4a>
2002447c:	b138      	cbz	r0, 2002448e <bbm_get_phy_blk+0x1e>
2002447e:	4b12      	ldr	r3, [pc, #72]	@ (200244c8 <bbm_get_phy_blk+0x58>)
20024480:	2200      	movs	r2, #0
20024482:	681c      	ldr	r4, [r3, #0]
20024484:	4b11      	ldr	r3, [pc, #68]	@ (200244cc <bbm_get_phy_blk+0x5c>)
20024486:	3c04      	subs	r4, #4
20024488:	461d      	mov	r5, r3
2002448a:	4294      	cmp	r4, r2
2002448c:	dc00      	bgt.n	20024490 <bbm_get_phy_blk+0x20>
2002448e:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024490:	8b1f      	ldrh	r7, [r3, #24]
20024492:	428f      	cmp	r7, r1
20024494:	d10a      	bne.n	200244ac <bbm_get_phy_blk+0x3c>
20024496:	eb05 0582 	add.w	r5, r5, r2, lsl #2
2002449a:	8b6a      	ldrh	r2, [r5, #26]
2002449c:	4296      	cmp	r6, r2
2002449e:	dd0f      	ble.n	200244c0 <bbm_get_phy_blk+0x50>
200244a0:	4b0b      	ldr	r3, [pc, #44]	@ (200244d0 <bbm_get_phy_blk+0x60>)
200244a2:	681b      	ldr	r3, [r3, #0]
200244a4:	b10b      	cbz	r3, 200244aa <bbm_get_phy_blk+0x3a>
200244a6:	480b      	ldr	r0, [pc, #44]	@ (200244d4 <bbm_get_phy_blk+0x64>)
200244a8:	4798      	blx	r3
200244aa:	e7fe      	b.n	200244aa <bbm_get_phy_blk+0x3a>
200244ac:	b917      	cbnz	r7, 200244b4 <bbm_get_phy_blk+0x44>
200244ae:	8b5f      	ldrh	r7, [r3, #26]
200244b0:	2f00      	cmp	r7, #0
200244b2:	d0ec      	beq.n	2002448e <bbm_get_phy_blk+0x1e>
200244b4:	3201      	adds	r2, #1
200244b6:	3304      	adds	r3, #4
200244b8:	e7e7      	b.n	2002448a <bbm_get_phy_blk+0x1a>
200244ba:	f04f 30ff 	mov.w	r0, #4294967295
200244be:	e7e6      	b.n	2002448e <bbm_get_phy_blk+0x1e>
200244c0:	4610      	mov	r0, r2
200244c2:	e7e4      	b.n	2002448e <bbm_get_phy_blk+0x1e>
200244c4:	2004cc5c 	.word	0x2004cc5c
200244c8:	2004cc58 	.word	0x2004cc58
200244cc:	2004cc60 	.word	0x2004cc60
200244d0:	2004cc48 	.word	0x2004cc48
200244d4:	20025ffc 	.word	0x20025ffc

200244d8 <bbm_get_version_inblk>:
200244d8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200244dc:	4607      	mov	r7, r0
200244de:	4688      	mov	r8, r1
200244e0:	b087      	sub	sp, #28
200244e2:	2900      	cmp	r1, #0
200244e4:	d14b      	bne.n	2002457e <bbm_get_version_inblk+0xa6>
200244e6:	2500      	movs	r5, #0
200244e8:	4628      	mov	r0, r5
200244ea:	b007      	add	sp, #28
200244ec:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200244f0:	2200      	movs	r2, #0
200244f2:	e9cd 2201 	strd	r2, r2, [sp, #4]
200244f6:	4e26      	ldr	r6, [pc, #152]	@ (20024590 <bbm_get_version_inblk+0xb8>)
200244f8:	9100      	str	r1, [sp, #0]
200244fa:	4638      	mov	r0, r7
200244fc:	4621      	mov	r1, r4
200244fe:	6833      	ldr	r3, [r6, #0]
20024500:	f7fc f950 	bl	200207a4 <port_read_page>
20024504:	2800      	cmp	r0, #0
20024506:	dd32      	ble.n	2002456e <bbm_get_version_inblk+0x96>
20024508:	6832      	ldr	r2, [r6, #0]
2002450a:	6813      	ldr	r3, [r2, #0]
2002450c:	455b      	cmp	r3, fp
2002450e:	d123      	bne.n	20024558 <bbm_get_version_inblk+0x80>
20024510:	6856      	ldr	r6, [r2, #4]
20024512:	f3c6 061e 	ubfx	r6, r6, #0, #31
20024516:	42ae      	cmp	r6, r5
20024518:	dd15      	ble.n	20024546 <bbm_get_version_inblk+0x6e>
2002451a:	4610      	mov	r0, r2
2002451c:	2110      	movs	r1, #16
2002451e:	9205      	str	r2, [sp, #20]
20024520:	f7ff ff92 	bl	20024448 <bbm_crc_check>
20024524:	9a05      	ldr	r2, [sp, #20]
20024526:	6913      	ldr	r3, [r2, #16]
20024528:	4283      	cmp	r3, r0
2002452a:	d113      	bne.n	20024554 <bbm_get_version_inblk+0x7c>
2002452c:	f8c8 4000 	str.w	r4, [r8]
20024530:	4635      	mov	r5, r6
20024532:	3401      	adds	r4, #1
20024534:	f8da 1000 	ldr.w	r1, [sl]
20024538:	f8d9 3000 	ldr.w	r3, [r9]
2002453c:	fbb3 f3f1 	udiv	r3, r3, r1
20024540:	42a3      	cmp	r3, r4
20024542:	d8d5      	bhi.n	200244f0 <bbm_get_version_inblk+0x18>
20024544:	e7d0      	b.n	200244e8 <bbm_get_version_inblk+0x10>
20024546:	4b13      	ldr	r3, [pc, #76]	@ (20024594 <bbm_get_version_inblk+0xbc>)
20024548:	681b      	ldr	r3, [r3, #0]
2002454a:	b11b      	cbz	r3, 20024554 <bbm_get_version_inblk+0x7c>
2002454c:	4632      	mov	r2, r6
2002454e:	4629      	mov	r1, r5
20024550:	4811      	ldr	r0, [pc, #68]	@ (20024598 <bbm_get_version_inblk+0xc0>)
20024552:	4798      	blx	r3
20024554:	462e      	mov	r6, r5
20024556:	e7eb      	b.n	20024530 <bbm_get_version_inblk+0x58>
20024558:	1c5a      	adds	r2, r3, #1
2002455a:	d0c5      	beq.n	200244e8 <bbm_get_version_inblk+0x10>
2002455c:	4a0d      	ldr	r2, [pc, #52]	@ (20024594 <bbm_get_version_inblk+0xbc>)
2002455e:	6815      	ldr	r5, [r2, #0]
20024560:	2d00      	cmp	r5, #0
20024562:	d0c0      	beq.n	200244e6 <bbm_get_version_inblk+0xe>
20024564:	4622      	mov	r2, r4
20024566:	4639      	mov	r1, r7
20024568:	480c      	ldr	r0, [pc, #48]	@ (2002459c <bbm_get_version_inblk+0xc4>)
2002456a:	47a8      	blx	r5
2002456c:	e7bb      	b.n	200244e6 <bbm_get_version_inblk+0xe>
2002456e:	4b09      	ldr	r3, [pc, #36]	@ (20024594 <bbm_get_version_inblk+0xbc>)
20024570:	681b      	ldr	r3, [r3, #0]
20024572:	2b00      	cmp	r3, #0
20024574:	d0ee      	beq.n	20024554 <bbm_get_version_inblk+0x7c>
20024576:	4622      	mov	r2, r4
20024578:	4639      	mov	r1, r7
2002457a:	4809      	ldr	r0, [pc, #36]	@ (200245a0 <bbm_get_version_inblk+0xc8>)
2002457c:	e7e9      	b.n	20024552 <bbm_get_version_inblk+0x7a>
2002457e:	2400      	movs	r4, #0
20024580:	f8df a020 	ldr.w	sl, [pc, #32]	@ 200245a4 <bbm_get_version_inblk+0xcc>
20024584:	4625      	mov	r5, r4
20024586:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 200245a8 <bbm_get_version_inblk+0xd0>
2002458a:	f8df b020 	ldr.w	fp, [pc, #32]	@ 200245ac <bbm_get_version_inblk+0xd4>
2002458e:	e7d1      	b.n	20024534 <bbm_get_version_inblk+0x5c>
20024590:	2004cc4c 	.word	0x2004cc4c
20024594:	2004cc48 	.word	0x2004cc48
20024598:	2002601b 	.word	0x2002601b
2002459c:	20026048 	.word	0x20026048
200245a0:	20026079 	.word	0x20026079
200245a4:	2004499c 	.word	0x2004499c
200245a8:	200449a0 	.word	0x200449a0
200245ac:	5366424d 	.word	0x5366424d

200245b0 <bbm_get_map_table>:
200245b0:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200245b4:	2801      	cmp	r0, #1
200245b6:	4607      	mov	r7, r0
200245b8:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 20024718 <bbm_get_map_table+0x168>
200245bc:	b087      	sub	sp, #28
200245be:	dd0a      	ble.n	200245d6 <bbm_get_map_table+0x26>
200245c0:	f8db 3000 	ldr.w	r3, [fp]
200245c4:	b91b      	cbnz	r3, 200245ce <bbm_get_map_table+0x1e>
200245c6:	2000      	movs	r0, #0
200245c8:	b007      	add	sp, #28
200245ca:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200245ce:	4601      	mov	r1, r0
200245d0:	4847      	ldr	r0, [pc, #284]	@ (200246f0 <bbm_get_map_table+0x140>)
200245d2:	4798      	blx	r3
200245d4:	e7f7      	b.n	200245c6 <bbm_get_map_table+0x16>
200245d6:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 2002471c <bbm_get_map_table+0x16c>
200245da:	2800      	cmp	r0, #0
200245dc:	d163      	bne.n	200246a6 <bbm_get_map_table+0xf6>
200245de:	f8b8 6000 	ldrh.w	r6, [r8]
200245e2:	f8b8 5002 	ldrh.w	r5, [r8, #2]
200245e6:	2e00      	cmp	r6, #0
200245e8:	d062      	beq.n	200246b0 <bbm_get_map_table+0x100>
200245ea:	4630      	mov	r0, r6
200245ec:	a904      	add	r1, sp, #16
200245ee:	f7ff ff73 	bl	200244d8 <bbm_get_version_inblk>
200245f2:	4681      	mov	r9, r0
200245f4:	2d00      	cmp	r5, #0
200245f6:	d05d      	beq.n	200246b4 <bbm_get_map_table+0x104>
200245f8:	4628      	mov	r0, r5
200245fa:	a905      	add	r1, sp, #20
200245fc:	f7ff ff6c 	bl	200244d8 <bbm_get_version_inblk>
20024600:	4604      	mov	r4, r0
20024602:	f8db a000 	ldr.w	sl, [fp]
20024606:	f1ba 0f00 	cmp.w	sl, #0
2002460a:	d005      	beq.n	20024618 <bbm_get_map_table+0x68>
2002460c:	4623      	mov	r3, r4
2002460e:	4632      	mov	r2, r6
20024610:	4649      	mov	r1, r9
20024612:	4838      	ldr	r0, [pc, #224]	@ (200246f4 <bbm_get_map_table+0x144>)
20024614:	9500      	str	r5, [sp, #0]
20024616:	47d0      	blx	sl
20024618:	45a1      	cmp	r9, r4
2002461a:	d0d4      	beq.n	200245c6 <bbm_get_map_table+0x16>
2002461c:	f04f 0200 	mov.w	r2, #0
20024620:	bf98      	it	ls
20024622:	462e      	movls	r6, r5
20024624:	f107 0308 	add.w	r3, r7, #8
20024628:	bf94      	ite	ls
2002462a:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
2002462e:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
20024632:	e9cd 2201 	strd	r2, r2, [sp, #4]
20024636:	4b30      	ldr	r3, [pc, #192]	@ (200246f8 <bbm_get_map_table+0x148>)
20024638:	bf88      	it	hi
2002463a:	f8dd a010 	ldrhi.w	sl, [sp, #16]
2002463e:	681b      	ldr	r3, [r3, #0]
20024640:	bf98      	it	ls
20024642:	f8dd a014 	ldrls.w	sl, [sp, #20]
20024646:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 20024720 <bbm_get_map_table+0x170>
2002464a:	9300      	str	r3, [sp, #0]
2002464c:	4651      	mov	r1, sl
2002464e:	4630      	mov	r0, r6
20024650:	f8d8 3000 	ldr.w	r3, [r8]
20024654:	bf88      	it	hi
20024656:	464c      	movhi	r4, r9
20024658:	f7fc f8a4 	bl	200207a4 <port_read_page>
2002465c:	2800      	cmp	r0, #0
2002465e:	f8db 5000 	ldr.w	r5, [fp]
20024662:	dd38      	ble.n	200246d6 <bbm_get_map_table+0x126>
20024664:	f8d8 8000 	ldr.w	r8, [r8]
20024668:	4b24      	ldr	r3, [pc, #144]	@ (200246fc <bbm_get_map_table+0x14c>)
2002466a:	f8d8 2000 	ldr.w	r2, [r8]
2002466e:	429a      	cmp	r2, r3
20024670:	d12b      	bne.n	200246ca <bbm_get_map_table+0x11a>
20024672:	2110      	movs	r1, #16
20024674:	4640      	mov	r0, r8
20024676:	f7ff fee7 	bl	20024448 <bbm_crc_check>
2002467a:	f8d8 2010 	ldr.w	r2, [r8, #16]
2002467e:	4601      	mov	r1, r0
20024680:	4282      	cmp	r2, r0
20024682:	d11e      	bne.n	200246c2 <bbm_get_map_table+0x112>
20024684:	f8d8 1004 	ldr.w	r1, [r8, #4]
20024688:	f3c1 011e 	ubfx	r1, r1, #0, #31
2002468c:	42a1      	cmp	r1, r4
2002468e:	d113      	bne.n	200246b8 <bbm_get_map_table+0x108>
20024690:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024694:	481a      	ldr	r0, [pc, #104]	@ (20024700 <bbm_get_map_table+0x150>)
20024696:	4641      	mov	r1, r8
20024698:	fb02 0007 	mla	r0, r2, r7, r0
2002469c:	f001 f867 	bl	2002576e <memcpy>
200246a0:	bb0d      	cbnz	r5, 200246e6 <bbm_get_map_table+0x136>
200246a2:	4620      	mov	r0, r4
200246a4:	e790      	b.n	200245c8 <bbm_get_map_table+0x18>
200246a6:	f8b8 6004 	ldrh.w	r6, [r8, #4]
200246aa:	f8b8 5006 	ldrh.w	r5, [r8, #6]
200246ae:	e79a      	b.n	200245e6 <bbm_get_map_table+0x36>
200246b0:	46b1      	mov	r9, r6
200246b2:	e79f      	b.n	200245f4 <bbm_get_map_table+0x44>
200246b4:	462c      	mov	r4, r5
200246b6:	e7a4      	b.n	20024602 <bbm_get_map_table+0x52>
200246b8:	b115      	cbz	r5, 200246c0 <bbm_get_map_table+0x110>
200246ba:	4622      	mov	r2, r4
200246bc:	4811      	ldr	r0, [pc, #68]	@ (20024704 <bbm_get_map_table+0x154>)
200246be:	47a8      	blx	r5
200246c0:	e7fe      	b.n	200246c0 <bbm_get_map_table+0x110>
200246c2:	b10d      	cbz	r5, 200246c8 <bbm_get_map_table+0x118>
200246c4:	4810      	ldr	r0, [pc, #64]	@ (20024708 <bbm_get_map_table+0x158>)
200246c6:	47a8      	blx	r5
200246c8:	e7fe      	b.n	200246c8 <bbm_get_map_table+0x118>
200246ca:	b11d      	cbz	r5, 200246d4 <bbm_get_map_table+0x124>
200246cc:	4652      	mov	r2, sl
200246ce:	4631      	mov	r1, r6
200246d0:	480e      	ldr	r0, [pc, #56]	@ (2002470c <bbm_get_map_table+0x15c>)
200246d2:	47a8      	blx	r5
200246d4:	e7fe      	b.n	200246d4 <bbm_get_map_table+0x124>
200246d6:	2d00      	cmp	r5, #0
200246d8:	f43f af75 	beq.w	200245c6 <bbm_get_map_table+0x16>
200246dc:	4652      	mov	r2, sl
200246de:	4631      	mov	r1, r6
200246e0:	480b      	ldr	r0, [pc, #44]	@ (20024710 <bbm_get_map_table+0x160>)
200246e2:	47a8      	blx	r5
200246e4:	e76f      	b.n	200245c6 <bbm_get_map_table+0x16>
200246e6:	4621      	mov	r1, r4
200246e8:	480a      	ldr	r0, [pc, #40]	@ (20024714 <bbm_get_map_table+0x164>)
200246ea:	47a8      	blx	r5
200246ec:	e7d9      	b.n	200246a2 <bbm_get_map_table+0xf2>
200246ee:	bf00      	nop
200246f0:	20026097 	.word	0x20026097
200246f4:	200260ab 	.word	0x200260ab
200246f8:	2004499c 	.word	0x2004499c
200246fc:	5366424d 	.word	0x5366424d
20024700:	2004cc60 	.word	0x2004cc60
20024704:	200260d1 	.word	0x200260d1
20024708:	2002611b 	.word	0x2002611b
2002470c:	2002612d 	.word	0x2002612d
20024710:	20026162 	.word	0x20026162
20024714:	2002618e 	.word	0x2002618e
20024718:	2004cc48 	.word	0x2004cc48
2002471c:	2004d070 	.word	0x2004d070
20024720:	2004cc4c 	.word	0x2004cc4c

20024724 <bbm_get_page_num>:
20024724:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20024728:	4605      	mov	r5, r0
2002472a:	2400      	movs	r4, #0
2002472c:	4f13      	ldr	r7, [pc, #76]	@ (2002477c <bbm_get_page_num+0x58>)
2002472e:	4e14      	ldr	r6, [pc, #80]	@ (20024780 <bbm_get_page_num+0x5c>)
20024730:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 20024784 <bbm_get_page_num+0x60>
20024734:	b085      	sub	sp, #20
20024736:	6839      	ldr	r1, [r7, #0]
20024738:	6833      	ldr	r3, [r6, #0]
2002473a:	fbb3 f3f1 	udiv	r3, r3, r1
2002473e:	42a3      	cmp	r3, r4
20024740:	d802      	bhi.n	20024748 <bbm_get_page_num+0x24>
20024742:	f04f 34ff 	mov.w	r4, #4294967295
20024746:	e015      	b.n	20024774 <bbm_get_page_num+0x50>
20024748:	2200      	movs	r2, #0
2002474a:	e9cd 2201 	strd	r2, r2, [sp, #4]
2002474e:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 20024788 <bbm_get_page_num+0x64>
20024752:	9100      	str	r1, [sp, #0]
20024754:	4628      	mov	r0, r5
20024756:	4621      	mov	r1, r4
20024758:	f8d9 3000 	ldr.w	r3, [r9]
2002475c:	f7fc f822 	bl	200207a4 <port_read_page>
20024760:	b120      	cbz	r0, 2002476c <bbm_get_page_num+0x48>
20024762:	f8d9 3000 	ldr.w	r3, [r9]
20024766:	681b      	ldr	r3, [r3, #0]
20024768:	4543      	cmp	r3, r8
2002476a:	d101      	bne.n	20024770 <bbm_get_page_num+0x4c>
2002476c:	3401      	adds	r4, #1
2002476e:	e7e2      	b.n	20024736 <bbm_get_page_num+0x12>
20024770:	3301      	adds	r3, #1
20024772:	d1fb      	bne.n	2002476c <bbm_get_page_num+0x48>
20024774:	4620      	mov	r0, r4
20024776:	b005      	add	sp, #20
20024778:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
2002477c:	2004499c 	.word	0x2004499c
20024780:	200449a0 	.word	0x200449a0
20024784:	5366424d 	.word	0x5366424d
20024788:	2004cc4c 	.word	0x2004cc4c

2002478c <bbm_read_page>:
2002478c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002478e:	4604      	mov	r4, r0
20024790:	b085      	sub	sp, #20
20024792:	b280      	uxth	r0, r0
20024794:	461f      	mov	r7, r3
20024796:	460d      	mov	r5, r1
20024798:	4616      	mov	r6, r2
2002479a:	f7ff fe69 	bl	20024470 <bbm_get_phy_blk>
2002479e:	1c43      	adds	r3, r0, #1
200247a0:	d108      	bne.n	200247b4 <bbm_read_page+0x28>
200247a2:	4b0a      	ldr	r3, [pc, #40]	@ (200247cc <bbm_read_page+0x40>)
200247a4:	681b      	ldr	r3, [r3, #0]
200247a6:	b113      	cbz	r3, 200247ae <bbm_read_page+0x22>
200247a8:	4621      	mov	r1, r4
200247aa:	4809      	ldr	r0, [pc, #36]	@ (200247d0 <bbm_read_page+0x44>)
200247ac:	4798      	blx	r3
200247ae:	2000      	movs	r0, #0
200247b0:	b005      	add	sp, #20
200247b2:	bdf0      	pop	{r4, r5, r6, r7, pc}
200247b4:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
200247b6:	4632      	mov	r2, r6
200247b8:	9302      	str	r3, [sp, #8]
200247ba:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
200247bc:	4629      	mov	r1, r5
200247be:	9301      	str	r3, [sp, #4]
200247c0:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
200247c2:	9300      	str	r3, [sp, #0]
200247c4:	463b      	mov	r3, r7
200247c6:	f7fb ffed 	bl	200207a4 <port_read_page>
200247ca:	e7f1      	b.n	200247b0 <bbm_read_page+0x24>
200247cc:	2004cc48 	.word	0x2004cc48
200247d0:	200261a1 	.word	0x200261a1

200247d4 <port_write_page>:
200247d4:	4b01      	ldr	r3, [pc, #4]	@ (200247dc <port_write_page+0x8>)
200247d6:	6818      	ldr	r0, [r3, #0]
200247d8:	4770      	bx	lr
200247da:	bf00      	nop
200247dc:	2004499c 	.word	0x2004499c

200247e0 <bbm_write_talbe.isra.0>:
200247e0:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
200247e2:	4604      	mov	r4, r0
200247e4:	4608      	mov	r0, r1
200247e6:	460e      	mov	r6, r1
200247e8:	f7ff ff9c 	bl	20024724 <bbm_get_page_num>
200247ec:	1e05      	subs	r5, r0, #0
200247ee:	db25      	blt.n	2002483c <bbm_write_talbe.isra.0+0x5c>
200247f0:	4b13      	ldr	r3, [pc, #76]	@ (20024840 <bbm_write_talbe.isra.0+0x60>)
200247f2:	681a      	ldr	r2, [r3, #0]
200247f4:	4b13      	ldr	r3, [pc, #76]	@ (20024844 <bbm_write_talbe.isra.0+0x64>)
200247f6:	681b      	ldr	r3, [r3, #0]
200247f8:	fbb3 f3f2 	udiv	r3, r3, r2
200247fc:	429d      	cmp	r5, r3
200247fe:	da1d      	bge.n	2002483c <bbm_write_talbe.isra.0+0x5c>
20024800:	4f11      	ldr	r7, [pc, #68]	@ (20024848 <bbm_write_talbe.isra.0+0x68>)
20024802:	21ff      	movs	r1, #255	@ 0xff
20024804:	6838      	ldr	r0, [r7, #0]
20024806:	f000 ff43 	bl	20025690 <memset>
2002480a:	4264      	negs	r4, r4
2002480c:	490f      	ldr	r1, [pc, #60]	@ (2002484c <bbm_write_talbe.isra.0+0x6c>)
2002480e:	f404 7402 	and.w	r4, r4, #520	@ 0x208
20024812:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024816:	6838      	ldr	r0, [r7, #0]
20024818:	4421      	add	r1, r4
2002481a:	f000 ffa8 	bl	2002576e <memcpy>
2002481e:	6838      	ldr	r0, [r7, #0]
20024820:	b160      	cbz	r0, 2002483c <bbm_write_talbe.isra.0+0x5c>
20024822:	6802      	ldr	r2, [r0, #0]
20024824:	4b0a      	ldr	r3, [pc, #40]	@ (20024850 <bbm_write_talbe.isra.0+0x70>)
20024826:	429a      	cmp	r2, r3
20024828:	d108      	bne.n	2002483c <bbm_write_talbe.isra.0+0x5c>
2002482a:	f7ff fdbd 	bl	200243a8 <bbm_map_check.part.0>
2002482e:	2300      	movs	r3, #0
20024830:	9300      	str	r3, [sp, #0]
20024832:	4629      	mov	r1, r5
20024834:	4630      	mov	r0, r6
20024836:	683a      	ldr	r2, [r7, #0]
20024838:	f7ff ffcc 	bl	200247d4 <port_write_page>
2002483c:	b003      	add	sp, #12
2002483e:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024840:	2004499c 	.word	0x2004499c
20024844:	200449a0 	.word	0x200449a0
20024848:	2004cc4c 	.word	0x2004cc4c
2002484c:	2004cc60 	.word	0x2004cc60
20024850:	5366424d 	.word	0x5366424d

20024854 <port_erase_block>:
20024854:	2000      	movs	r0, #0
20024856:	4770      	bx	lr

20024858 <bbm_init_table>:
20024858:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002485c:	4c7c      	ldr	r4, [pc, #496]	@ (20024a50 <bbm_init_table+0x1f8>)
2002485e:	4b7d      	ldr	r3, [pc, #500]	@ (20024a54 <bbm_init_table+0x1fc>)
20024860:	6822      	ldr	r2, [r4, #0]
20024862:	b085      	sub	sp, #20
20024864:	429a      	cmp	r2, r3
20024866:	f000 80ed 	beq.w	20024a44 <bbm_init_table+0x1ec>
2002486a:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
2002486e:	429a      	cmp	r2, r3
20024870:	f000 80e8 	beq.w	20024a44 <bbm_init_table+0x1ec>
20024874:	6023      	str	r3, [r4, #0]
20024876:	2301      	movs	r3, #1
20024878:	6063      	str	r3, [r4, #4]
2002487a:	2300      	movs	r3, #0
2002487c:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 20024a88 <bbm_init_table+0x230>
20024880:	8123      	strh	r3, [r4, #8]
20024882:	f8d9 3000 	ldr.w	r3, [r9]
20024886:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 20024a8c <bbm_init_table+0x234>
2002488a:	3b04      	subs	r3, #4
2002488c:	f8df a200 	ldr.w	sl, [pc, #512]	@ 20024a90 <bbm_init_table+0x238>
20024890:	8163      	strh	r3, [r4, #10]
20024892:	f8d8 3000 	ldr.w	r3, [r8]
20024896:	f8da 5000 	ldr.w	r5, [sl]
2002489a:	3b01      	subs	r3, #1
2002489c:	4e6e      	ldr	r6, [pc, #440]	@ (20024a58 <bbm_init_table+0x200>)
2002489e:	81a3      	strh	r3, [r4, #12]
200248a0:	81e5      	strh	r5, [r4, #14]
200248a2:	f8d8 3000 	ldr.w	r3, [r8]
200248a6:	429d      	cmp	r5, r3
200248a8:	db10      	blt.n	200248cc <bbm_init_table+0x74>
200248aa:	2500      	movs	r5, #0
200248ac:	462f      	mov	r7, r5
200248ae:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 20024a58 <bbm_init_table+0x200>
200248b2:	f8da 6000 	ldr.w	r6, [sl]
200248b6:	42b5      	cmp	r5, r6
200248b8:	db1d      	blt.n	200248f6 <bbm_init_table+0x9e>
200248ba:	8963      	ldrh	r3, [r4, #10]
200248bc:	2b00      	cmp	r3, #0
200248be:	d148      	bne.n	20024952 <bbm_init_table+0xfa>
200248c0:	4b65      	ldr	r3, [pc, #404]	@ (20024a58 <bbm_init_table+0x200>)
200248c2:	681b      	ldr	r3, [r3, #0]
200248c4:	b10b      	cbz	r3, 200248ca <bbm_init_table+0x72>
200248c6:	4865      	ldr	r0, [pc, #404]	@ (20024a5c <bbm_init_table+0x204>)
200248c8:	4798      	blx	r3
200248ca:	e7fe      	b.n	200248ca <bbm_init_table+0x72>
200248cc:	4628      	mov	r0, r5
200248ce:	f7fb ffcf 	bl	20020870 <bbm_get_bb>
200248d2:	b950      	cbnz	r0, 200248ea <bbm_init_table+0x92>
200248d4:	4628      	mov	r0, r5
200248d6:	f7ff ffbd 	bl	20024854 <port_erase_block>
200248da:	b120      	cbz	r0, 200248e6 <bbm_init_table+0x8e>
200248dc:	6833      	ldr	r3, [r6, #0]
200248de:	b113      	cbz	r3, 200248e6 <bbm_init_table+0x8e>
200248e0:	4629      	mov	r1, r5
200248e2:	485f      	ldr	r0, [pc, #380]	@ (20024a60 <bbm_init_table+0x208>)
200248e4:	4798      	blx	r3
200248e6:	3501      	adds	r5, #1
200248e8:	e7db      	b.n	200248a2 <bbm_init_table+0x4a>
200248ea:	6833      	ldr	r3, [r6, #0]
200248ec:	2b00      	cmp	r3, #0
200248ee:	d0fa      	beq.n	200248e6 <bbm_init_table+0x8e>
200248f0:	4629      	mov	r1, r5
200248f2:	485c      	ldr	r0, [pc, #368]	@ (20024a64 <bbm_init_table+0x20c>)
200248f4:	e7f6      	b.n	200248e4 <bbm_init_table+0x8c>
200248f6:	4628      	mov	r0, r5
200248f8:	f7fb ffba 	bl	20020870 <bbm_get_bb>
200248fc:	b338      	cbz	r0, 2002494e <bbm_init_table+0xf6>
200248fe:	f8db 3000 	ldr.w	r3, [fp]
20024902:	b113      	cbz	r3, 2002490a <bbm_init_table+0xb2>
20024904:	4629      	mov	r1, r5
20024906:	4858      	ldr	r0, [pc, #352]	@ (20024a68 <bbm_init_table+0x210>)
20024908:	4798      	blx	r3
2002490a:	89a0      	ldrh	r0, [r4, #12]
2002490c:	f7fb ffb0 	bl	20020870 <bbm_get_bb>
20024910:	89a3      	ldrh	r3, [r4, #12]
20024912:	4606      	mov	r6, r0
20024914:	3b01      	subs	r3, #1
20024916:	81a3      	strh	r3, [r4, #12]
20024918:	8963      	ldrh	r3, [r4, #10]
2002491a:	3b01      	subs	r3, #1
2002491c:	b29b      	uxth	r3, r3
2002491e:	8163      	strh	r3, [r4, #10]
20024920:	b108      	cbz	r0, 20024926 <bbm_init_table+0xce>
20024922:	2b00      	cmp	r3, #0
20024924:	d1f1      	bne.n	2002490a <bbm_init_table+0xb2>
20024926:	f8db 3000 	ldr.w	r3, [fp]
2002492a:	b11b      	cbz	r3, 20024934 <bbm_init_table+0xdc>
2002492c:	463a      	mov	r2, r7
2002492e:	4629      	mov	r1, r5
20024930:	484e      	ldr	r0, [pc, #312]	@ (20024a6c <bbm_init_table+0x214>)
20024932:	4798      	blx	r3
20024934:	b93e      	cbnz	r6, 20024946 <bbm_init_table+0xee>
20024936:	89a2      	ldrh	r2, [r4, #12]
20024938:	1dbb      	adds	r3, r7, #6
2002493a:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
2002493e:	3201      	adds	r2, #1
20024940:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20024944:	805a      	strh	r2, [r3, #2]
20024946:	8923      	ldrh	r3, [r4, #8]
20024948:	3701      	adds	r7, #1
2002494a:	3301      	adds	r3, #1
2002494c:	8123      	strh	r3, [r4, #8]
2002494e:	3501      	adds	r5, #1
20024950:	e7af      	b.n	200248b2 <bbm_init_table+0x5a>
20024952:	2110      	movs	r1, #16
20024954:	483e      	ldr	r0, [pc, #248]	@ (20024a50 <bbm_init_table+0x1f8>)
20024956:	f7ff fd77 	bl	20024448 <bbm_crc_check>
2002495a:	f8d9 1000 	ldr.w	r1, [r9]
2002495e:	6120      	str	r0, [r4, #16]
20024960:	3904      	subs	r1, #4
20024962:	0089      	lsls	r1, r1, #2
20024964:	4842      	ldr	r0, [pc, #264]	@ (20024a70 <bbm_init_table+0x218>)
20024966:	f7ff fd6f 	bl	20024448 <bbm_crc_check>
2002496a:	f44f 7202 	mov.w	r2, #520	@ 0x208
2002496e:	4938      	ldr	r1, [pc, #224]	@ (20024a50 <bbm_init_table+0x1f8>)
20024970:	6160      	str	r0, [r4, #20]
20024972:	1888      	adds	r0, r1, r2
20024974:	f000 fefb 	bl	2002576e <memcpy>
20024978:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
2002497c:	2110      	movs	r1, #16
2002497e:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20024982:	483c      	ldr	r0, [pc, #240]	@ (20024a74 <bbm_init_table+0x21c>)
20024984:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20024988:	f7ff fd5e 	bl	20024448 <bbm_crc_check>
2002498c:	2700      	movs	r7, #0
2002498e:	f8df a104 	ldr.w	sl, [pc, #260]	@ 20024a94 <bbm_init_table+0x23c>
20024992:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 20024a98 <bbm_init_table+0x240>
20024996:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
2002499a:	f8d8 3000 	ldr.w	r3, [r8]
2002499e:	429e      	cmp	r6, r3
200249a0:	db08      	blt.n	200249b4 <bbm_init_table+0x15c>
200249a2:	2f03      	cmp	r7, #3
200249a4:	dc2f      	bgt.n	20024a06 <bbm_init_table+0x1ae>
200249a6:	4b2c      	ldr	r3, [pc, #176]	@ (20024a58 <bbm_init_table+0x200>)
200249a8:	681b      	ldr	r3, [r3, #0]
200249aa:	b113      	cbz	r3, 200249b2 <bbm_init_table+0x15a>
200249ac:	4639      	mov	r1, r7
200249ae:	4832      	ldr	r0, [pc, #200]	@ (20024a78 <bbm_init_table+0x220>)
200249b0:	4798      	blx	r3
200249b2:	e7fe      	b.n	200249b2 <bbm_init_table+0x15a>
200249b4:	4630      	mov	r0, r6
200249b6:	f7fb ff5b 	bl	20020870 <bbm_get_bb>
200249ba:	4604      	mov	r4, r0
200249bc:	bb08      	cbnz	r0, 20024a02 <bbm_init_table+0x1aa>
200249be:	f8da 5000 	ldr.w	r5, [sl]
200249c2:	21ff      	movs	r1, #255	@ 0xff
200249c4:	462a      	mov	r2, r5
200249c6:	f8d9 0000 	ldr.w	r0, [r9]
200249ca:	f000 fe61 	bl	20025690 <memset>
200249ce:	e9cd 4401 	strd	r4, r4, [sp, #4]
200249d2:	9500      	str	r5, [sp, #0]
200249d4:	f8d9 3000 	ldr.w	r3, [r9]
200249d8:	4622      	mov	r2, r4
200249da:	4621      	mov	r1, r4
200249dc:	4630      	mov	r0, r6
200249de:	f7fb fee1 	bl	200207a4 <port_read_page>
200249e2:	f8da 3000 	ldr.w	r3, [sl]
200249e6:	4298      	cmp	r0, r3
200249e8:	d109      	bne.n	200249fe <bbm_init_table+0x1a6>
200249ea:	f8d9 3000 	ldr.w	r3, [r9]
200249ee:	681b      	ldr	r3, [r3, #0]
200249f0:	3301      	adds	r3, #1
200249f2:	bf01      	itttt	eq
200249f4:	4b21      	ldreq	r3, [pc, #132]	@ (20024a7c <bbm_init_table+0x224>)
200249f6:	1d3a      	addeq	r2, r7, #4
200249f8:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
200249fc:	3701      	addeq	r7, #1
200249fe:	2f03      	cmp	r7, #3
20024a00:	dc01      	bgt.n	20024a06 <bbm_init_table+0x1ae>
20024a02:	3601      	adds	r6, #1
20024a04:	e7c9      	b.n	2002499a <bbm_init_table+0x142>
20024a06:	2500      	movs	r5, #0
20024a08:	4c1c      	ldr	r4, [pc, #112]	@ (20024a7c <bbm_init_table+0x224>)
20024a0a:	2000      	movs	r0, #0
20024a0c:	8921      	ldrh	r1, [r4, #8]
20024a0e:	f7ff fee7 	bl	200247e0 <bbm_write_talbe.isra.0>
20024a12:	8923      	ldrh	r3, [r4, #8]
20024a14:	2001      	movs	r0, #1
20024a16:	8961      	ldrh	r1, [r4, #10]
20024a18:	8023      	strh	r3, [r4, #0]
20024a1a:	8223      	strh	r3, [r4, #16]
20024a1c:	8125      	strh	r5, [r4, #8]
20024a1e:	f7ff fedf 	bl	200247e0 <bbm_write_talbe.isra.0>
20024a22:	8963      	ldrh	r3, [r4, #10]
20024a24:	8165      	strh	r5, [r4, #10]
20024a26:	80a3      	strh	r3, [r4, #4]
20024a28:	8263      	strh	r3, [r4, #18]
20024a2a:	89a3      	ldrh	r3, [r4, #12]
20024a2c:	8063      	strh	r3, [r4, #2]
20024a2e:	89e3      	ldrh	r3, [r4, #14]
20024a30:	80e3      	strh	r3, [r4, #6]
20024a32:	4b09      	ldr	r3, [pc, #36]	@ (20024a58 <bbm_init_table+0x200>)
20024a34:	681b      	ldr	r3, [r3, #0]
20024a36:	b10b      	cbz	r3, 20024a3c <bbm_init_table+0x1e4>
20024a38:	4811      	ldr	r0, [pc, #68]	@ (20024a80 <bbm_init_table+0x228>)
20024a3a:	4798      	blx	r3
20024a3c:	2000      	movs	r0, #0
20024a3e:	b005      	add	sp, #20
20024a40:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024a44:	4b04      	ldr	r3, [pc, #16]	@ (20024a58 <bbm_init_table+0x200>)
20024a46:	681b      	ldr	r3, [r3, #0]
20024a48:	b10b      	cbz	r3, 20024a4e <bbm_init_table+0x1f6>
20024a4a:	480e      	ldr	r0, [pc, #56]	@ (20024a84 <bbm_init_table+0x22c>)
20024a4c:	4798      	blx	r3
20024a4e:	e7fe      	b.n	20024a4e <bbm_init_table+0x1f6>
20024a50:	2004cc60 	.word	0x2004cc60
20024a54:	5366424d 	.word	0x5366424d
20024a58:	2004cc48 	.word	0x2004cc48
20024a5c:	20026236 	.word	0x20026236
20024a60:	200261c4 	.word	0x200261c4
20024a64:	200261e6 	.word	0x200261e6
20024a68:	20026203 	.word	0x20026203
20024a6c:	20026222 	.word	0x20026222
20024a70:	2004cc78 	.word	0x2004cc78
20024a74:	2004ce68 	.word	0x2004ce68
20024a78:	20026250 	.word	0x20026250
20024a7c:	2004d070 	.word	0x2004d070
20024a80:	20026277 	.word	0x20026277
20024a84:	20026293 	.word	0x20026293
20024a88:	2004cc58 	.word	0x2004cc58
20024a8c:	2004cc54 	.word	0x2004cc54
20024a90:	2004cc5c 	.word	0x2004cc5c
20024a94:	2004499c 	.word	0x2004499c
20024a98:	2004cc4c 	.word	0x2004cc4c

20024a9c <sif_bbm_init>:
20024a9c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20024aa0:	b087      	sub	sp, #28
20024aa2:	2900      	cmp	r1, #0
20024aa4:	f000 8129 	beq.w	20024cfa <sif_bbm_init+0x25e>
20024aa8:	4b95      	ldr	r3, [pc, #596]	@ (20024d00 <sif_bbm_init+0x264>)
20024aaa:	681a      	ldr	r2, [r3, #0]
20024aac:	2a01      	cmp	r2, #1
20024aae:	d108      	bne.n	20024ac2 <sif_bbm_init+0x26>
20024ab0:	4b94      	ldr	r3, [pc, #592]	@ (20024d04 <sif_bbm_init+0x268>)
20024ab2:	681b      	ldr	r3, [r3, #0]
20024ab4:	b10b      	cbz	r3, 20024aba <sif_bbm_init+0x1e>
20024ab6:	4894      	ldr	r0, [pc, #592]	@ (20024d08 <sif_bbm_init+0x26c>)
20024ab8:	4798      	blx	r3
20024aba:	2000      	movs	r0, #0
20024abc:	b007      	add	sp, #28
20024abe:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20024ac2:	2201      	movs	r2, #1
20024ac4:	601a      	str	r2, [r3, #0]
20024ac6:	4b91      	ldr	r3, [pc, #580]	@ (20024d0c <sif_bbm_init+0x270>)
20024ac8:	681c      	ldr	r4, [r3, #0]
20024aca:	b904      	cbnz	r4, 20024ace <sif_bbm_init+0x32>
20024acc:	e7fe      	b.n	20024acc <sif_bbm_init+0x30>
20024ace:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 20024d4c <sif_bbm_init+0x2b0>
20024ad2:	f8da 2000 	ldr.w	r2, [sl]
20024ad6:	b902      	cbnz	r2, 20024ada <sif_bbm_init+0x3e>
20024ad8:	e7fe      	b.n	20024ad8 <sif_bbm_init+0x3c>
20024ada:	fbb0 f4f4 	udiv	r4, r0, r4
20024ade:	f04f 0800 	mov.w	r8, #0
20024ae2:	4a8b      	ldr	r2, [pc, #556]	@ (20024d10 <sif_bbm_init+0x274>)
20024ae4:	f8df b268 	ldr.w	fp, [pc, #616]	@ 20024d50 <sif_bbm_init+0x2b4>
20024ae8:	0963      	lsrs	r3, r4, #5
20024aea:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20024d54 <sif_bbm_init+0x2b8>
20024aee:	6013      	str	r3, [r2, #0]
20024af0:	f8cb 4000 	str.w	r4, [fp]
20024af4:	1ae4      	subs	r4, r4, r3
20024af6:	4b87      	ldr	r3, [pc, #540]	@ (20024d14 <sif_bbm_init+0x278>)
20024af8:	2218      	movs	r2, #24
20024afa:	f8c9 1000 	str.w	r1, [r9]
20024afe:	4886      	ldr	r0, [pc, #536]	@ (20024d18 <sif_bbm_init+0x27c>)
20024b00:	2100      	movs	r1, #0
20024b02:	601c      	str	r4, [r3, #0]
20024b04:	f000 fdc4 	bl	20025690 <memset>
20024b08:	f44f 6282 	mov.w	r2, #1040	@ 0x410
20024b0c:	2100      	movs	r1, #0
20024b0e:	4883      	ldr	r0, [pc, #524]	@ (20024d1c <sif_bbm_init+0x280>)
20024b10:	f000 fdbe 	bl	20025690 <memset>
20024b14:	4647      	mov	r7, r8
20024b16:	4646      	mov	r6, r8
20024b18:	f8db 3000 	ldr.w	r3, [fp]
20024b1c:	429c      	cmp	r4, r3
20024b1e:	db02      	blt.n	20024b26 <sif_bbm_init+0x8a>
20024b20:	f04f 35ff 	mov.w	r5, #4294967295
20024b24:	e064      	b.n	20024bf0 <sif_bbm_init+0x154>
20024b26:	4620      	mov	r0, r4
20024b28:	f7fb fea2 	bl	20020870 <bbm_get_bb>
20024b2c:	4605      	mov	r5, r0
20024b2e:	b138      	cbz	r0, 20024b40 <sif_bbm_init+0xa4>
20024b30:	4b74      	ldr	r3, [pc, #464]	@ (20024d04 <sif_bbm_init+0x268>)
20024b32:	681b      	ldr	r3, [r3, #0]
20024b34:	b113      	cbz	r3, 20024b3c <sif_bbm_init+0xa0>
20024b36:	4621      	mov	r1, r4
20024b38:	4879      	ldr	r0, [pc, #484]	@ (20024d20 <sif_bbm_init+0x284>)
20024b3a:	4798      	blx	r3
20024b3c:	3401      	adds	r4, #1
20024b3e:	e7eb      	b.n	20024b18 <sif_bbm_init+0x7c>
20024b40:	f8da 2000 	ldr.w	r2, [sl]
20024b44:	21ff      	movs	r1, #255	@ 0xff
20024b46:	f8d9 0000 	ldr.w	r0, [r9]
20024b4a:	9205      	str	r2, [sp, #20]
20024b4c:	f000 fda0 	bl	20025690 <memset>
20024b50:	9a05      	ldr	r2, [sp, #20]
20024b52:	e9cd 5501 	strd	r5, r5, [sp, #4]
20024b56:	9200      	str	r2, [sp, #0]
20024b58:	f8d9 3000 	ldr.w	r3, [r9]
20024b5c:	462a      	mov	r2, r5
20024b5e:	4629      	mov	r1, r5
20024b60:	4620      	mov	r0, r4
20024b62:	f7fb fe1f 	bl	200207a4 <port_read_page>
20024b66:	f8da 3000 	ldr.w	r3, [sl]
20024b6a:	4298      	cmp	r0, r3
20024b6c:	d12e      	bne.n	20024bcc <sif_bbm_init+0x130>
20024b6e:	f8d9 1000 	ldr.w	r1, [r9]
20024b72:	486c      	ldr	r0, [pc, #432]	@ (20024d24 <sif_bbm_init+0x288>)
20024b74:	680b      	ldr	r3, [r1, #0]
20024b76:	b2a2      	uxth	r2, r4
20024b78:	4283      	cmp	r3, r0
20024b7a:	4b67      	ldr	r3, [pc, #412]	@ (20024d18 <sif_bbm_init+0x27c>)
20024b7c:	d11f      	bne.n	20024bbe <sif_bbm_init+0x122>
20024b7e:	f991 1007 	ldrsb.w	r1, [r1, #7]
20024b82:	2900      	cmp	r1, #0
20024b84:	bfb5      	itete	lt
20024b86:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
20024b8a:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
20024b8e:	808a      	strhlt	r2, [r1, #4]
20024b90:	3601      	addge	r6, #1
20024b92:	bfb8      	it	lt
20024b94:	3701      	addlt	r7, #1
20024b96:	eb06 0208 	add.w	r2, r6, r8
20024b9a:	443a      	add	r2, r7
20024b9c:	2a03      	cmp	r2, #3
20024b9e:	ddcd      	ble.n	20024b3c <sif_bbm_init+0xa0>
20024ba0:	2e00      	cmp	r6, #0
20024ba2:	f000 8081 	beq.w	20024ca8 <sif_bbm_init+0x20c>
20024ba6:	2f00      	cmp	r7, #0
20024ba8:	d07e      	beq.n	20024ca8 <sif_bbm_init+0x20c>
20024baa:	2e01      	cmp	r6, #1
20024bac:	d001      	beq.n	20024bb2 <sif_bbm_init+0x116>
20024bae:	2f01      	cmp	r7, #1
20024bb0:	d11e      	bne.n	20024bf0 <sif_bbm_init+0x154>
20024bb2:	8819      	ldrh	r1, [r3, #0]
20024bb4:	891a      	ldrh	r2, [r3, #8]
20024bb6:	b981      	cbnz	r1, 20024bda <sif_bbm_init+0x13e>
20024bb8:	801a      	strh	r2, [r3, #0]
20024bba:	895a      	ldrh	r2, [r3, #10]
20024bbc:	e013      	b.n	20024be6 <sif_bbm_init+0x14a>
20024bbe:	f108 0104 	add.w	r1, r8, #4
20024bc2:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
20024bc6:	f108 0801 	add.w	r8, r8, #1
20024bca:	e7e4      	b.n	20024b96 <sif_bbm_init+0xfa>
20024bcc:	4b4d      	ldr	r3, [pc, #308]	@ (20024d04 <sif_bbm_init+0x268>)
20024bce:	681b      	ldr	r3, [r3, #0]
20024bd0:	2b00      	cmp	r3, #0
20024bd2:	d0b3      	beq.n	20024b3c <sif_bbm_init+0xa0>
20024bd4:	4854      	ldr	r0, [pc, #336]	@ (20024d28 <sif_bbm_init+0x28c>)
20024bd6:	1c61      	adds	r1, r4, #1
20024bd8:	e7af      	b.n	20024b3a <sif_bbm_init+0x9e>
20024bda:	8859      	ldrh	r1, [r3, #2]
20024bdc:	b909      	cbnz	r1, 20024be2 <sif_bbm_init+0x146>
20024bde:	805a      	strh	r2, [r3, #2]
20024be0:	e7eb      	b.n	20024bba <sif_bbm_init+0x11e>
20024be2:	2a00      	cmp	r2, #0
20024be4:	d0e9      	beq.n	20024bba <sif_bbm_init+0x11e>
20024be6:	8899      	ldrh	r1, [r3, #4]
20024be8:	2900      	cmp	r1, #0
20024bea:	d158      	bne.n	20024c9e <sif_bbm_init+0x202>
20024bec:	809a      	strh	r2, [r3, #4]
20024bee:	2502      	movs	r5, #2
20024bf0:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 20024d04 <sif_bbm_init+0x268>
20024bf4:	f8d9 4000 	ldr.w	r4, [r9]
20024bf8:	b124      	cbz	r4, 20024c04 <sif_bbm_init+0x168>
20024bfa:	4643      	mov	r3, r8
20024bfc:	463a      	mov	r2, r7
20024bfe:	4631      	mov	r1, r6
20024c00:	484a      	ldr	r0, [pc, #296]	@ (20024d2c <sif_bbm_init+0x290>)
20024c02:	47a0      	blx	r4
20024c04:	f8d9 3000 	ldr.w	r3, [r9]
20024c08:	b113      	cbz	r3, 20024c10 <sif_bbm_init+0x174>
20024c0a:	4629      	mov	r1, r5
20024c0c:	4848      	ldr	r0, [pc, #288]	@ (20024d30 <sif_bbm_init+0x294>)
20024c0e:	4798      	blx	r3
20024c10:	f035 0002 	bics.w	r0, r5, #2
20024c14:	d164      	bne.n	20024ce0 <sif_bbm_init+0x244>
20024c16:	f7ff fccb 	bl	200245b0 <bbm_get_map_table>
20024c1a:	4605      	mov	r5, r0
20024c1c:	2001      	movs	r0, #1
20024c1e:	f7ff fcc7 	bl	200245b0 <bbm_get_map_table>
20024c22:	f8d9 6000 	ldr.w	r6, [r9]
20024c26:	4604      	mov	r4, r0
20024c28:	b13e      	cbz	r6, 20024c3a <sif_bbm_init+0x19e>
20024c2a:	4a3b      	ldr	r2, [pc, #236]	@ (20024d18 <sif_bbm_init+0x27c>)
20024c2c:	4629      	mov	r1, r5
20024c2e:	8a53      	ldrh	r3, [r2, #18]
20024c30:	9300      	str	r3, [sp, #0]
20024c32:	8a12      	ldrh	r2, [r2, #16]
20024c34:	4603      	mov	r3, r0
20024c36:	483f      	ldr	r0, [pc, #252]	@ (20024d34 <sif_bbm_init+0x298>)
20024c38:	47b0      	blx	r6
20024c3a:	42a5      	cmp	r5, r4
20024c3c:	4c37      	ldr	r4, [pc, #220]	@ (20024d1c <sif_bbm_init+0x280>)
20024c3e:	dd35      	ble.n	20024cac <sif_bbm_init+0x210>
20024c40:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024c44:	4621      	mov	r1, r4
20024c46:	18a0      	adds	r0, r4, r2
20024c48:	f000 fd91 	bl	2002576e <memcpy>
20024c4c:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20024c50:	2110      	movs	r1, #16
20024c52:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20024c56:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
20024c5a:	f504 7002 	add.w	r0, r4, #520	@ 0x208
20024c5e:	f7ff fbf3 	bl	20024448 <bbm_crc_check>
20024c62:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
20024c66:	2001      	movs	r0, #1
20024c68:	4b2b      	ldr	r3, [pc, #172]	@ (20024d18 <sif_bbm_init+0x27c>)
20024c6a:	8a59      	ldrh	r1, [r3, #18]
20024c6c:	f7ff fdb8 	bl	200247e0 <bbm_write_talbe.isra.0>
20024c70:	6822      	ldr	r2, [r4, #0]
20024c72:	4b2c      	ldr	r3, [pc, #176]	@ (20024d24 <sif_bbm_init+0x288>)
20024c74:	429a      	cmp	r2, r3
20024c76:	d12d      	bne.n	20024cd4 <sif_bbm_init+0x238>
20024c78:	4828      	ldr	r0, [pc, #160]	@ (20024d1c <sif_bbm_init+0x280>)
20024c7a:	f7ff fb95 	bl	200243a8 <bbm_map_check.part.0>
20024c7e:	f8d9 4000 	ldr.w	r4, [r9]
20024c82:	b12c      	cbz	r4, 20024c90 <sif_bbm_init+0x1f4>
20024c84:	4b2c      	ldr	r3, [pc, #176]	@ (20024d38 <sif_bbm_init+0x29c>)
20024c86:	4924      	ldr	r1, [pc, #144]	@ (20024d18 <sif_bbm_init+0x27c>)
20024c88:	482c      	ldr	r0, [pc, #176]	@ (20024d3c <sif_bbm_init+0x2a0>)
20024c8a:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
20024c8e:	47a0      	blx	r4
20024c90:	f8d9 3000 	ldr.w	r3, [r9]
20024c94:	2b00      	cmp	r3, #0
20024c96:	f43f af10 	beq.w	20024aba <sif_bbm_init+0x1e>
20024c9a:	4829      	ldr	r0, [pc, #164]	@ (20024d40 <sif_bbm_init+0x2a4>)
20024c9c:	e70c      	b.n	20024ab8 <sif_bbm_init+0x1c>
20024c9e:	88d9      	ldrh	r1, [r3, #6]
20024ca0:	2900      	cmp	r1, #0
20024ca2:	d1a4      	bne.n	20024bee <sif_bbm_init+0x152>
20024ca4:	80da      	strh	r2, [r3, #6]
20024ca6:	e7a2      	b.n	20024bee <sif_bbm_init+0x152>
20024ca8:	2501      	movs	r5, #1
20024caa:	e7a1      	b.n	20024bf0 <sif_bbm_init+0x154>
20024cac:	dae0      	bge.n	20024c70 <sif_bbm_init+0x1d4>
20024cae:	f44f 7202 	mov.w	r2, #520	@ 0x208
20024cb2:	4620      	mov	r0, r4
20024cb4:	18a1      	adds	r1, r4, r2
20024cb6:	f000 fd5a 	bl	2002576e <memcpy>
20024cba:	79e3      	ldrb	r3, [r4, #7]
20024cbc:	2110      	movs	r1, #16
20024cbe:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
20024cc2:	71e3      	strb	r3, [r4, #7]
20024cc4:	4620      	mov	r0, r4
20024cc6:	f7ff fbbf 	bl	20024448 <bbm_crc_check>
20024cca:	4b13      	ldr	r3, [pc, #76]	@ (20024d18 <sif_bbm_init+0x27c>)
20024ccc:	6120      	str	r0, [r4, #16]
20024cce:	8a19      	ldrh	r1, [r3, #16]
20024cd0:	2000      	movs	r0, #0
20024cd2:	e7cb      	b.n	20024c6c <sif_bbm_init+0x1d0>
20024cd4:	f8d9 3000 	ldr.w	r3, [r9]
20024cd8:	b10b      	cbz	r3, 20024cde <sif_bbm_init+0x242>
20024cda:	481a      	ldr	r0, [pc, #104]	@ (20024d44 <sif_bbm_init+0x2a8>)
20024cdc:	4798      	blx	r3
20024cde:	e7fe      	b.n	20024cde <sif_bbm_init+0x242>
20024ce0:	2d01      	cmp	r5, #1
20024ce2:	d102      	bne.n	20024cea <sif_bbm_init+0x24e>
20024ce4:	f7ff fdb8 	bl	20024858 <bbm_init_table>
20024ce8:	e7c9      	b.n	20024c7e <sif_bbm_init+0x1e2>
20024cea:	f8d9 3000 	ldr.w	r3, [r9]
20024cee:	b11b      	cbz	r3, 20024cf8 <sif_bbm_init+0x25c>
20024cf0:	f04f 31ff 	mov.w	r1, #4294967295
20024cf4:	4814      	ldr	r0, [pc, #80]	@ (20024d48 <sif_bbm_init+0x2ac>)
20024cf6:	4798      	blx	r3
20024cf8:	e7fe      	b.n	20024cf8 <sif_bbm_init+0x25c>
20024cfa:	f04f 30ff 	mov.w	r0, #4294967295
20024cfe:	e6dd      	b.n	20024abc <sif_bbm_init+0x20>
20024d00:	2004cc50 	.word	0x2004cc50
20024d04:	2004cc48 	.word	0x2004cc48
20024d08:	200262a7 	.word	0x200262a7
20024d0c:	200449a0 	.word	0x200449a0
20024d10:	2004cc58 	.word	0x2004cc58
20024d14:	2004cc5c 	.word	0x2004cc5c
20024d18:	2004d070 	.word	0x2004d070
20024d1c:	2004cc60 	.word	0x2004cc60
20024d20:	200262d5 	.word	0x200262d5
20024d24:	5366424d 	.word	0x5366424d
20024d28:	200262e1 	.word	0x200262e1
20024d2c:	20026300 	.word	0x20026300
20024d30:	2002631f 	.word	0x2002631f
20024d34:	20026331 	.word	0x20026331
20024d38:	2004ce68 	.word	0x2004ce68
20024d3c:	2002638c 	.word	0x2002638c
20024d40:	200263b0 	.word	0x200263b0
20024d44:	20026355 	.word	0x20026355
20024d48:	2002636b 	.word	0x2002636b
20024d4c:	2004499c 	.word	0x2004499c
20024d50:	2004cc54 	.word	0x2004cc54
20024d54:	2004cc4c 	.word	0x2004cc4c

20024d58 <bbm_set_page_size>:
20024d58:	4b01      	ldr	r3, [pc, #4]	@ (20024d60 <bbm_set_page_size+0x8>)
20024d5a:	6018      	str	r0, [r3, #0]
20024d5c:	4770      	bx	lr
20024d5e:	bf00      	nop
20024d60:	2004499c 	.word	0x2004499c

20024d64 <bbm_set_blk_size>:
20024d64:	4b01      	ldr	r3, [pc, #4]	@ (20024d6c <bbm_set_blk_size+0x8>)
20024d66:	6018      	str	r0, [r3, #0]
20024d68:	4770      	bx	lr
20024d6a:	bf00      	nop
20024d6c:	200449a0 	.word	0x200449a0

20024d70 <sf_crypto_cmac_gen_subkey>:
20024d70:	2300      	movs	r3, #0
20024d72:	b530      	push	{r4, r5, lr}
20024d74:	f100 0210 	add.w	r2, r0, #16
20024d78:	f101 0410 	add.w	r4, r1, #16
20024d7c:	f812 5d01 	ldrb.w	r5, [r2, #-1]!
20024d80:	ea43 0345 	orr.w	r3, r3, r5, lsl #1
20024d84:	f804 3d01 	strb.w	r3, [r4, #-1]!
20024d88:	7813      	ldrb	r3, [r2, #0]
20024d8a:	4282      	cmp	r2, r0
20024d8c:	ea4f 13d3 	mov.w	r3, r3, lsr #7
20024d90:	d1f4      	bne.n	20024d7c <sf_crypto_cmac_gen_subkey+0xc>
20024d92:	f992 3000 	ldrsb.w	r3, [r2]
20024d96:	2b00      	cmp	r3, #0
20024d98:	bfbe      	ittt	lt
20024d9a:	7bcb      	ldrblt	r3, [r1, #15]
20024d9c:	f083 0387 	eorlt.w	r3, r3, #135	@ 0x87
20024da0:	73cb      	strblt	r3, [r1, #15]
20024da2:	bd30      	pop	{r4, r5, pc}

20024da4 <sf_crypto_aes_cmac_init>:
20024da4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20024da8:	2a20      	cmp	r2, #32
20024daa:	4604      	mov	r4, r0
20024dac:	460e      	mov	r6, r1
20024dae:	4615      	mov	r5, r2
20024db0:	b08c      	sub	sp, #48	@ 0x30
20024db2:	d12e      	bne.n	20024e12 <sf_crypto_aes_cmac_init+0x6e>
20024db4:	b380      	cbz	r0, 20024e18 <sf_crypto_aes_cmac_init+0x74>
20024db6:	2710      	movs	r7, #16
20024db8:	ab04      	add	r3, sp, #16
20024dba:	6001      	str	r1, [r0, #0]
20024dbc:	8082      	strh	r2, [r0, #4]
20024dbe:	2100      	movs	r1, #0
20024dc0:	463a      	mov	r2, r7
20024dc2:	4618      	mov	r0, r3
20024dc4:	f000 fc64 	bl	20025690 <memset>
20024dc8:	2300      	movs	r3, #0
20024dca:	f10d 0820 	add.w	r8, sp, #32
20024dce:	4629      	mov	r1, r5
20024dd0:	9000      	str	r0, [sp, #0]
20024dd2:	461a      	mov	r2, r3
20024dd4:	4630      	mov	r0, r6
20024dd6:	e9cd 7801 	strd	r7, r8, [sp, #4]
20024dda:	f000 f8da 	bl	20024f92 <sf_crypto_aes_enc_sync>
20024dde:	4605      	mov	r5, r0
20024de0:	b100      	cbz	r0, 20024de4 <sf_crypto_aes_cmac_init+0x40>
20024de2:	e7fe      	b.n	20024de2 <sf_crypto_aes_cmac_init+0x3e>
20024de4:	1da6      	adds	r6, r4, #6
20024de6:	4631      	mov	r1, r6
20024de8:	4640      	mov	r0, r8
20024dea:	f7ff ffc1 	bl	20024d70 <sf_crypto_cmac_gen_subkey>
20024dee:	4630      	mov	r0, r6
20024df0:	f104 0116 	add.w	r1, r4, #22
20024df4:	f7ff ffbc 	bl	20024d70 <sf_crypto_cmac_gen_subkey>
20024df8:	463a      	mov	r2, r7
20024dfa:	4629      	mov	r1, r5
20024dfc:	f104 0028 	add.w	r0, r4, #40	@ 0x28
20024e00:	f000 fc46 	bl	20025690 <memset>
20024e04:	f240 1301 	movw	r3, #257	@ 0x101
20024e08:	8723      	strh	r3, [r4, #56]	@ 0x38
20024e0a:	4628      	mov	r0, r5
20024e0c:	b00c      	add	sp, #48	@ 0x30
20024e0e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20024e12:	f06f 0502 	mvn.w	r5, #2
20024e16:	e7f8      	b.n	20024e0a <sf_crypto_aes_cmac_init+0x66>
20024e18:	f04f 35ff 	mov.w	r5, #4294967295
20024e1c:	e7f5      	b.n	20024e0a <sf_crypto_aes_cmac_init+0x66>

20024e1e <sf_crypto_aes_cmac_calc>:
20024e1e:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20024e22:	b089      	sub	sp, #36	@ 0x24
20024e24:	460f      	mov	r7, r1
20024e26:	4604      	mov	r4, r0
20024e28:	9e10      	ldr	r6, [sp, #64]	@ 0x40
20024e2a:	b138      	cbz	r0, 20024e3c <sf_crypto_aes_cmac_calc+0x1e>
20024e2c:	b136      	cbz	r6, 20024e3c <sf_crypto_aes_cmac_calc+0x1e>
20024e2e:	f890 1039 	ldrb.w	r1, [r0, #57]	@ 0x39
20024e32:	2900      	cmp	r1, #0
20024e34:	f000 80aa 	beq.w	20024f8c <sf_crypto_aes_cmac_calc+0x16e>
20024e38:	b11a      	cbz	r2, 20024e42 <sf_crypto_aes_cmac_calc+0x24>
20024e3a:	b957      	cbnz	r7, 20024e52 <sf_crypto_aes_cmac_calc+0x34>
20024e3c:	f04f 30ff 	mov.w	r0, #4294967295
20024e40:	e0a1      	b.n	20024f86 <sf_crypto_aes_cmac_calc+0x168>
20024e42:	f890 1038 	ldrb.w	r1, [r0, #56]	@ 0x38
20024e46:	b109      	cbz	r1, 20024e4c <sf_crypto_aes_cmac_calc+0x2e>
20024e48:	2b00      	cmp	r3, #0
20024e4a:	d16e      	bne.n	20024f2a <sf_crypto_aes_cmac_calc+0x10c>
20024e4c:	f06f 0003 	mvn.w	r0, #3
20024e50:	e099      	b.n	20024f86 <sf_crypto_aes_cmac_calc+0x168>
20024e52:	f002 000f 	and.w	r0, r2, #15
20024e56:	b973      	cbnz	r3, 20024e76 <sf_crypto_aes_cmac_calc+0x58>
20024e58:	2800      	cmp	r0, #0
20024e5a:	d1f7      	bne.n	20024e4c <sf_crypto_aes_cmac_calc+0x2e>
20024e5c:	e9cd 2601 	strd	r2, r6, [sp, #4]
20024e60:	9700      	str	r7, [sp, #0]
20024e62:	2303      	movs	r3, #3
20024e64:	88a1      	ldrh	r1, [r4, #4]
20024e66:	6820      	ldr	r0, [r4, #0]
20024e68:	f104 0228 	add.w	r2, r4, #40	@ 0x28
20024e6c:	f000 f891 	bl	20024f92 <sf_crypto_aes_enc_sync>
20024e70:	2800      	cmp	r0, #0
20024e72:	d07b      	beq.n	20024f6c <sf_crypto_aes_cmac_calc+0x14e>
20024e74:	e7fe      	b.n	20024e74 <sf_crypto_aes_cmac_calc+0x56>
20024e76:	320f      	adds	r2, #15
20024e78:	ea4f 1812 	mov.w	r8, r2, lsr #4
20024e7c:	f108 31ff 	add.w	r1, r8, #4294967295
20024e80:	eb07 1101 	add.w	r1, r7, r1, lsl #4
20024e84:	b3c0      	cbz	r0, 20024ef8 <sf_crypto_aes_cmac_calc+0xda>
20024e86:	f1c0 0910 	rsb	r9, r0, #16
20024e8a:	fa1f f989 	uxth.w	r9, r9
20024e8e:	f1c9 0510 	rsb	r5, r9, #16
20024e92:	462a      	mov	r2, r5
20024e94:	a804      	add	r0, sp, #16
20024e96:	f000 fc6a 	bl	2002576e <memcpy>
20024e9a:	f105 0320 	add.w	r3, r5, #32
20024e9e:	eb0d 0203 	add.w	r2, sp, r3
20024ea2:	2380      	movs	r3, #128	@ 0x80
20024ea4:	f802 3c10 	strb.w	r3, [r2, #-16]
20024ea8:	ab08      	add	r3, sp, #32
20024eaa:	eba3 0209 	sub.w	r2, r3, r9
20024eae:	2100      	movs	r1, #0
20024eb0:	2301      	movs	r3, #1
20024eb2:	454b      	cmp	r3, r9
20024eb4:	d33f      	bcc.n	20024f36 <sf_crypto_aes_cmac_calc+0x118>
20024eb6:	aa04      	add	r2, sp, #16
20024eb8:	f104 0315 	add.w	r3, r4, #21
20024ebc:	f104 0025 	add.w	r0, r4, #37	@ 0x25
20024ec0:	7811      	ldrb	r1, [r2, #0]
20024ec2:	f813 5f01 	ldrb.w	r5, [r3, #1]!
20024ec6:	4069      	eors	r1, r5
20024ec8:	4283      	cmp	r3, r0
20024eca:	f802 1b01 	strb.w	r1, [r2], #1
20024ece:	d1f7      	bne.n	20024ec0 <sf_crypto_aes_cmac_calc+0xa2>
20024ed0:	f1b8 0f01 	cmp.w	r8, #1
20024ed4:	f104 0528 	add.w	r5, r4, #40	@ 0x28
20024ed8:	d93b      	bls.n	20024f52 <sf_crypto_aes_cmac_calc+0x134>
20024eda:	f108 38ff 	add.w	r8, r8, #4294967295
20024ede:	ea4f 1308 	mov.w	r3, r8, lsl #4
20024ee2:	e9cd 7300 	strd	r7, r3, [sp]
20024ee6:	9602      	str	r6, [sp, #8]
20024ee8:	2303      	movs	r3, #3
20024eea:	462a      	mov	r2, r5
20024eec:	88a1      	ldrh	r1, [r4, #4]
20024eee:	6820      	ldr	r0, [r4, #0]
20024ef0:	f000 f84f 	bl	20024f92 <sf_crypto_aes_enc_sync>
20024ef4:	b318      	cbz	r0, 20024f3e <sf_crypto_aes_cmac_calc+0x120>
20024ef6:	e7fe      	b.n	20024ef6 <sf_crypto_aes_cmac_calc+0xd8>
20024ef8:	460b      	mov	r3, r1
20024efa:	ad04      	add	r5, sp, #16
20024efc:	f101 0c10 	add.w	ip, r1, #16
20024f00:	462a      	mov	r2, r5
20024f02:	6818      	ldr	r0, [r3, #0]
20024f04:	6859      	ldr	r1, [r3, #4]
20024f06:	3308      	adds	r3, #8
20024f08:	c203      	stmia	r2!, {r0, r1}
20024f0a:	4563      	cmp	r3, ip
20024f0c:	4615      	mov	r5, r2
20024f0e:	d1f7      	bne.n	20024f00 <sf_crypto_aes_cmac_calc+0xe2>
20024f10:	ab04      	add	r3, sp, #16
20024f12:	1d62      	adds	r2, r4, #5
20024f14:	f104 0015 	add.w	r0, r4, #21
20024f18:	7819      	ldrb	r1, [r3, #0]
20024f1a:	f812 5f01 	ldrb.w	r5, [r2, #1]!
20024f1e:	4069      	eors	r1, r5
20024f20:	4282      	cmp	r2, r0
20024f22:	f803 1b01 	strb.w	r1, [r3], #1
20024f26:	d1f7      	bne.n	20024f18 <sf_crypto_aes_cmac_calc+0xfa>
20024f28:	e7d2      	b.n	20024ed0 <sf_crypto_aes_cmac_calc+0xb2>
20024f2a:	4615      	mov	r5, r2
20024f2c:	f04f 0910 	mov.w	r9, #16
20024f30:	f04f 0801 	mov.w	r8, #1
20024f34:	e7b1      	b.n	20024e9a <sf_crypto_aes_cmac_calc+0x7c>
20024f36:	f802 1f01 	strb.w	r1, [r2, #1]!
20024f3a:	3301      	adds	r3, #1
20024f3c:	e7b9      	b.n	20024eb2 <sf_crypto_aes_cmac_calc+0x94>
20024f3e:	4633      	mov	r3, r6
20024f40:	462a      	mov	r2, r5
20024f42:	f106 0110 	add.w	r1, r6, #16
20024f46:	f853 0b04 	ldr.w	r0, [r3], #4
20024f4a:	428b      	cmp	r3, r1
20024f4c:	f842 0b04 	str.w	r0, [r2], #4
20024f50:	d1f9      	bne.n	20024f46 <sf_crypto_aes_cmac_calc+0x128>
20024f52:	2310      	movs	r3, #16
20024f54:	9301      	str	r3, [sp, #4]
20024f56:	446b      	add	r3, sp
20024f58:	9300      	str	r3, [sp, #0]
20024f5a:	9602      	str	r6, [sp, #8]
20024f5c:	2303      	movs	r3, #3
20024f5e:	462a      	mov	r2, r5
20024f60:	88a1      	ldrh	r1, [r4, #4]
20024f62:	6820      	ldr	r0, [r4, #0]
20024f64:	f000 f815 	bl	20024f92 <sf_crypto_aes_enc_sync>
20024f68:	b100      	cbz	r0, 20024f6c <sf_crypto_aes_cmac_calc+0x14e>
20024f6a:	e7fe      	b.n	20024f6a <sf_crypto_aes_cmac_calc+0x14c>
20024f6c:	f104 0328 	add.w	r3, r4, #40	@ 0x28
20024f70:	f106 0210 	add.w	r2, r6, #16
20024f74:	f856 1b04 	ldr.w	r1, [r6], #4
20024f78:	4296      	cmp	r6, r2
20024f7a:	f843 1b04 	str.w	r1, [r3], #4
20024f7e:	d1f9      	bne.n	20024f74 <sf_crypto_aes_cmac_calc+0x156>
20024f80:	2000      	movs	r0, #0
20024f82:	f884 0038 	strb.w	r0, [r4, #56]	@ 0x38
20024f86:	b009      	add	sp, #36	@ 0x24
20024f88:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20024f8c:	f06f 0001 	mvn.w	r0, #1
20024f90:	e7f9      	b.n	20024f86 <sf_crypto_aes_cmac_calc+0x168>

20024f92 <sf_crypto_aes_enc_sync>:
20024f92:	b508      	push	{r3, lr}
20024f94:	f7fc fcf8 	bl	20021988 <HAL_AES_init>
20024f98:	b100      	cbz	r0, 20024f9c <sf_crypto_aes_enc_sync+0xa>
20024f9a:	e7fe      	b.n	20024f9a <sf_crypto_aes_enc_sync+0x8>
20024f9c:	2001      	movs	r0, #1
20024f9e:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
20024fa2:	9902      	ldr	r1, [sp, #8]
20024fa4:	f7fc fd36 	bl	20021a14 <HAL_AES_run>
20024fa8:	b100      	cbz	r0, 20024fac <sf_crypto_aes_enc_sync+0x1a>
20024faa:	e7fe      	b.n	20024faa <sf_crypto_aes_enc_sync+0x18>
20024fac:	bd08      	pop	{r3, pc}
	...

20024fb0 <sbrk_aligned>:
20024fb0:	b570      	push	{r4, r5, r6, lr}
20024fb2:	4e0f      	ldr	r6, [pc, #60]	@ (20024ff0 <sbrk_aligned+0x40>)
20024fb4:	460c      	mov	r4, r1
20024fb6:	4605      	mov	r5, r0
20024fb8:	6831      	ldr	r1, [r6, #0]
20024fba:	b911      	cbnz	r1, 20024fc2 <sbrk_aligned+0x12>
20024fbc:	f000 fba4 	bl	20025708 <_sbrk_r>
20024fc0:	6030      	str	r0, [r6, #0]
20024fc2:	4621      	mov	r1, r4
20024fc4:	4628      	mov	r0, r5
20024fc6:	f000 fb9f 	bl	20025708 <_sbrk_r>
20024fca:	1c43      	adds	r3, r0, #1
20024fcc:	d103      	bne.n	20024fd6 <sbrk_aligned+0x26>
20024fce:	f04f 34ff 	mov.w	r4, #4294967295
20024fd2:	4620      	mov	r0, r4
20024fd4:	bd70      	pop	{r4, r5, r6, pc}
20024fd6:	1cc4      	adds	r4, r0, #3
20024fd8:	f024 0403 	bic.w	r4, r4, #3
20024fdc:	42a0      	cmp	r0, r4
20024fde:	d0f8      	beq.n	20024fd2 <sbrk_aligned+0x22>
20024fe0:	1a21      	subs	r1, r4, r0
20024fe2:	4628      	mov	r0, r5
20024fe4:	f000 fb90 	bl	20025708 <_sbrk_r>
20024fe8:	3001      	adds	r0, #1
20024fea:	d1f2      	bne.n	20024fd2 <sbrk_aligned+0x22>
20024fec:	e7ef      	b.n	20024fce <sbrk_aligned+0x1e>
20024fee:	bf00      	nop
20024ff0:	2004d088 	.word	0x2004d088

20024ff4 <_malloc_r>:
20024ff4:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20024ff8:	1ccd      	adds	r5, r1, #3
20024ffa:	4606      	mov	r6, r0
20024ffc:	f025 0503 	bic.w	r5, r5, #3
20025000:	3508      	adds	r5, #8
20025002:	2d0c      	cmp	r5, #12
20025004:	bf38      	it	cc
20025006:	250c      	movcc	r5, #12
20025008:	2d00      	cmp	r5, #0
2002500a:	db01      	blt.n	20025010 <_malloc_r+0x1c>
2002500c:	42a9      	cmp	r1, r5
2002500e:	d904      	bls.n	2002501a <_malloc_r+0x26>
20025010:	230c      	movs	r3, #12
20025012:	6033      	str	r3, [r6, #0]
20025014:	2000      	movs	r0, #0
20025016:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
2002501a:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 200250f0 <_malloc_r+0xfc>
2002501e:	f000 f869 	bl	200250f4 <__malloc_lock>
20025022:	f8d8 3000 	ldr.w	r3, [r8]
20025026:	461c      	mov	r4, r3
20025028:	bb44      	cbnz	r4, 2002507c <_malloc_r+0x88>
2002502a:	4629      	mov	r1, r5
2002502c:	4630      	mov	r0, r6
2002502e:	f7ff ffbf 	bl	20024fb0 <sbrk_aligned>
20025032:	1c43      	adds	r3, r0, #1
20025034:	4604      	mov	r4, r0
20025036:	d158      	bne.n	200250ea <_malloc_r+0xf6>
20025038:	f8d8 4000 	ldr.w	r4, [r8]
2002503c:	4627      	mov	r7, r4
2002503e:	2f00      	cmp	r7, #0
20025040:	d143      	bne.n	200250ca <_malloc_r+0xd6>
20025042:	2c00      	cmp	r4, #0
20025044:	d04b      	beq.n	200250de <_malloc_r+0xea>
20025046:	6823      	ldr	r3, [r4, #0]
20025048:	4639      	mov	r1, r7
2002504a:	4630      	mov	r0, r6
2002504c:	eb04 0903 	add.w	r9, r4, r3
20025050:	f000 fb5a 	bl	20025708 <_sbrk_r>
20025054:	4581      	cmp	r9, r0
20025056:	d142      	bne.n	200250de <_malloc_r+0xea>
20025058:	6821      	ldr	r1, [r4, #0]
2002505a:	4630      	mov	r0, r6
2002505c:	1a6d      	subs	r5, r5, r1
2002505e:	4629      	mov	r1, r5
20025060:	f7ff ffa6 	bl	20024fb0 <sbrk_aligned>
20025064:	3001      	adds	r0, #1
20025066:	d03a      	beq.n	200250de <_malloc_r+0xea>
20025068:	6823      	ldr	r3, [r4, #0]
2002506a:	442b      	add	r3, r5
2002506c:	6023      	str	r3, [r4, #0]
2002506e:	f8d8 3000 	ldr.w	r3, [r8]
20025072:	685a      	ldr	r2, [r3, #4]
20025074:	bb62      	cbnz	r2, 200250d0 <_malloc_r+0xdc>
20025076:	f8c8 7000 	str.w	r7, [r8]
2002507a:	e00f      	b.n	2002509c <_malloc_r+0xa8>
2002507c:	6822      	ldr	r2, [r4, #0]
2002507e:	1b52      	subs	r2, r2, r5
20025080:	d420      	bmi.n	200250c4 <_malloc_r+0xd0>
20025082:	2a0b      	cmp	r2, #11
20025084:	d917      	bls.n	200250b6 <_malloc_r+0xc2>
20025086:	1961      	adds	r1, r4, r5
20025088:	42a3      	cmp	r3, r4
2002508a:	6025      	str	r5, [r4, #0]
2002508c:	bf18      	it	ne
2002508e:	6059      	strne	r1, [r3, #4]
20025090:	6863      	ldr	r3, [r4, #4]
20025092:	bf08      	it	eq
20025094:	f8c8 1000 	streq.w	r1, [r8]
20025098:	5162      	str	r2, [r4, r5]
2002509a:	604b      	str	r3, [r1, #4]
2002509c:	4630      	mov	r0, r6
2002509e:	f000 f82f 	bl	20025100 <__malloc_unlock>
200250a2:	f104 000b 	add.w	r0, r4, #11
200250a6:	1d23      	adds	r3, r4, #4
200250a8:	f020 0007 	bic.w	r0, r0, #7
200250ac:	1ac2      	subs	r2, r0, r3
200250ae:	bf1c      	itt	ne
200250b0:	1a1b      	subne	r3, r3, r0
200250b2:	50a3      	strne	r3, [r4, r2]
200250b4:	e7af      	b.n	20025016 <_malloc_r+0x22>
200250b6:	6862      	ldr	r2, [r4, #4]
200250b8:	42a3      	cmp	r3, r4
200250ba:	bf0c      	ite	eq
200250bc:	f8c8 2000 	streq.w	r2, [r8]
200250c0:	605a      	strne	r2, [r3, #4]
200250c2:	e7eb      	b.n	2002509c <_malloc_r+0xa8>
200250c4:	4623      	mov	r3, r4
200250c6:	6864      	ldr	r4, [r4, #4]
200250c8:	e7ae      	b.n	20025028 <_malloc_r+0x34>
200250ca:	463c      	mov	r4, r7
200250cc:	687f      	ldr	r7, [r7, #4]
200250ce:	e7b6      	b.n	2002503e <_malloc_r+0x4a>
200250d0:	461a      	mov	r2, r3
200250d2:	685b      	ldr	r3, [r3, #4]
200250d4:	42a3      	cmp	r3, r4
200250d6:	d1fb      	bne.n	200250d0 <_malloc_r+0xdc>
200250d8:	2300      	movs	r3, #0
200250da:	6053      	str	r3, [r2, #4]
200250dc:	e7de      	b.n	2002509c <_malloc_r+0xa8>
200250de:	230c      	movs	r3, #12
200250e0:	4630      	mov	r0, r6
200250e2:	6033      	str	r3, [r6, #0]
200250e4:	f000 f80c 	bl	20025100 <__malloc_unlock>
200250e8:	e794      	b.n	20025014 <_malloc_r+0x20>
200250ea:	6005      	str	r5, [r0, #0]
200250ec:	e7d6      	b.n	2002509c <_malloc_r+0xa8>
200250ee:	bf00      	nop
200250f0:	2004d08c 	.word	0x2004d08c

200250f4 <__malloc_lock>:
200250f4:	4801      	ldr	r0, [pc, #4]	@ (200250fc <__malloc_lock+0x8>)
200250f6:	f000 bb2a 	b.w	2002574e <__retarget_lock_acquire_recursive>
200250fa:	bf00      	nop
200250fc:	2004d1d0 	.word	0x2004d1d0

20025100 <__malloc_unlock>:
20025100:	4801      	ldr	r0, [pc, #4]	@ (20025108 <__malloc_unlock+0x8>)
20025102:	f000 bb25 	b.w	20025750 <__retarget_lock_release_recursive>
20025106:	bf00      	nop
20025108:	2004d1d0 	.word	0x2004d1d0

2002510c <__sflush_r>:
2002510c:	f9b1 200c 	ldrsh.w	r2, [r1, #12]
20025110:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025114:	0716      	lsls	r6, r2, #28
20025116:	4605      	mov	r5, r0
20025118:	460c      	mov	r4, r1
2002511a:	d451      	bmi.n	200251c0 <__sflush_r+0xb4>
2002511c:	684b      	ldr	r3, [r1, #4]
2002511e:	2b00      	cmp	r3, #0
20025120:	dc02      	bgt.n	20025128 <__sflush_r+0x1c>
20025122:	6c0b      	ldr	r3, [r1, #64]	@ 0x40
20025124:	2b00      	cmp	r3, #0
20025126:	dd49      	ble.n	200251bc <__sflush_r+0xb0>
20025128:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
2002512a:	2e00      	cmp	r6, #0
2002512c:	d046      	beq.n	200251bc <__sflush_r+0xb0>
2002512e:	2300      	movs	r3, #0
20025130:	f412 5280 	ands.w	r2, r2, #4096	@ 0x1000
20025134:	682f      	ldr	r7, [r5, #0]
20025136:	602b      	str	r3, [r5, #0]
20025138:	d031      	beq.n	2002519e <__sflush_r+0x92>
2002513a:	6d62      	ldr	r2, [r4, #84]	@ 0x54
2002513c:	89a3      	ldrh	r3, [r4, #12]
2002513e:	0759      	lsls	r1, r3, #29
20025140:	d505      	bpl.n	2002514e <__sflush_r+0x42>
20025142:	6863      	ldr	r3, [r4, #4]
20025144:	1ad2      	subs	r2, r2, r3
20025146:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20025148:	b10b      	cbz	r3, 2002514e <__sflush_r+0x42>
2002514a:	6c23      	ldr	r3, [r4, #64]	@ 0x40
2002514c:	1ad2      	subs	r2, r2, r3
2002514e:	2300      	movs	r3, #0
20025150:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025152:	6a21      	ldr	r1, [r4, #32]
20025154:	4628      	mov	r0, r5
20025156:	47b0      	blx	r6
20025158:	1c42      	adds	r2, r0, #1
2002515a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002515e:	d106      	bne.n	2002516e <__sflush_r+0x62>
20025160:	6829      	ldr	r1, [r5, #0]
20025162:	291d      	cmp	r1, #29
20025164:	d845      	bhi.n	200251f2 <__sflush_r+0xe6>
20025166:	4a28      	ldr	r2, [pc, #160]	@ (20025208 <__sflush_r+0xfc>)
20025168:	40ca      	lsrs	r2, r1
2002516a:	07d6      	lsls	r6, r2, #31
2002516c:	d541      	bpl.n	200251f2 <__sflush_r+0xe6>
2002516e:	2200      	movs	r2, #0
20025170:	04d9      	lsls	r1, r3, #19
20025172:	6062      	str	r2, [r4, #4]
20025174:	6922      	ldr	r2, [r4, #16]
20025176:	6022      	str	r2, [r4, #0]
20025178:	d504      	bpl.n	20025184 <__sflush_r+0x78>
2002517a:	1c42      	adds	r2, r0, #1
2002517c:	d101      	bne.n	20025182 <__sflush_r+0x76>
2002517e:	682b      	ldr	r3, [r5, #0]
20025180:	b903      	cbnz	r3, 20025184 <__sflush_r+0x78>
20025182:	6560      	str	r0, [r4, #84]	@ 0x54
20025184:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20025186:	602f      	str	r7, [r5, #0]
20025188:	b1c1      	cbz	r1, 200251bc <__sflush_r+0xb0>
2002518a:	f104 0344 	add.w	r3, r4, #68	@ 0x44
2002518e:	4299      	cmp	r1, r3
20025190:	d002      	beq.n	20025198 <__sflush_r+0x8c>
20025192:	4628      	mov	r0, r5
20025194:	f000 faf8 	bl	20025788 <_free_r>
20025198:	2300      	movs	r3, #0
2002519a:	6363      	str	r3, [r4, #52]	@ 0x34
2002519c:	e00e      	b.n	200251bc <__sflush_r+0xb0>
2002519e:	2301      	movs	r3, #1
200251a0:	6a21      	ldr	r1, [r4, #32]
200251a2:	4628      	mov	r0, r5
200251a4:	47b0      	blx	r6
200251a6:	4602      	mov	r2, r0
200251a8:	1c50      	adds	r0, r2, #1
200251aa:	d1c7      	bne.n	2002513c <__sflush_r+0x30>
200251ac:	682b      	ldr	r3, [r5, #0]
200251ae:	2b00      	cmp	r3, #0
200251b0:	d0c4      	beq.n	2002513c <__sflush_r+0x30>
200251b2:	2b1d      	cmp	r3, #29
200251b4:	d001      	beq.n	200251ba <__sflush_r+0xae>
200251b6:	2b16      	cmp	r3, #22
200251b8:	d119      	bne.n	200251ee <__sflush_r+0xe2>
200251ba:	602f      	str	r7, [r5, #0]
200251bc:	2000      	movs	r0, #0
200251be:	e01d      	b.n	200251fc <__sflush_r+0xf0>
200251c0:	690f      	ldr	r7, [r1, #16]
200251c2:	2f00      	cmp	r7, #0
200251c4:	d0fa      	beq.n	200251bc <__sflush_r+0xb0>
200251c6:	0793      	lsls	r3, r2, #30
200251c8:	680e      	ldr	r6, [r1, #0]
200251ca:	600f      	str	r7, [r1, #0]
200251cc:	bf0c      	ite	eq
200251ce:	694b      	ldreq	r3, [r1, #20]
200251d0:	2300      	movne	r3, #0
200251d2:	eba6 0807 	sub.w	r8, r6, r7
200251d6:	608b      	str	r3, [r1, #8]
200251d8:	f1b8 0f00 	cmp.w	r8, #0
200251dc:	ddee      	ble.n	200251bc <__sflush_r+0xb0>
200251de:	4643      	mov	r3, r8
200251e0:	463a      	mov	r2, r7
200251e2:	6a21      	ldr	r1, [r4, #32]
200251e4:	4628      	mov	r0, r5
200251e6:	6aa6      	ldr	r6, [r4, #40]	@ 0x28
200251e8:	47b0      	blx	r6
200251ea:	2800      	cmp	r0, #0
200251ec:	dc08      	bgt.n	20025200 <__sflush_r+0xf4>
200251ee:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200251f2:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
200251f6:	f04f 30ff 	mov.w	r0, #4294967295
200251fa:	81a3      	strh	r3, [r4, #12]
200251fc:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025200:	4407      	add	r7, r0
20025202:	eba8 0800 	sub.w	r8, r8, r0
20025206:	e7e7      	b.n	200251d8 <__sflush_r+0xcc>
20025208:	20400001 	.word	0x20400001

2002520c <_fflush_r>:
2002520c:	b538      	push	{r3, r4, r5, lr}
2002520e:	690b      	ldr	r3, [r1, #16]
20025210:	4605      	mov	r5, r0
20025212:	460c      	mov	r4, r1
20025214:	b913      	cbnz	r3, 2002521c <_fflush_r+0x10>
20025216:	2500      	movs	r5, #0
20025218:	4628      	mov	r0, r5
2002521a:	bd38      	pop	{r3, r4, r5, pc}
2002521c:	b118      	cbz	r0, 20025226 <_fflush_r+0x1a>
2002521e:	6a03      	ldr	r3, [r0, #32]
20025220:	b90b      	cbnz	r3, 20025226 <_fflush_r+0x1a>
20025222:	f000 f8a9 	bl	20025378 <__sinit>
20025226:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
2002522a:	2b00      	cmp	r3, #0
2002522c:	d0f3      	beq.n	20025216 <_fflush_r+0xa>
2002522e:	6e62      	ldr	r2, [r4, #100]	@ 0x64
20025230:	07d0      	lsls	r0, r2, #31
20025232:	d404      	bmi.n	2002523e <_fflush_r+0x32>
20025234:	0599      	lsls	r1, r3, #22
20025236:	d402      	bmi.n	2002523e <_fflush_r+0x32>
20025238:	6da0      	ldr	r0, [r4, #88]	@ 0x58
2002523a:	f000 fa88 	bl	2002574e <__retarget_lock_acquire_recursive>
2002523e:	4628      	mov	r0, r5
20025240:	4621      	mov	r1, r4
20025242:	f7ff ff63 	bl	2002510c <__sflush_r>
20025246:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025248:	4605      	mov	r5, r0
2002524a:	07da      	lsls	r2, r3, #31
2002524c:	d4e4      	bmi.n	20025218 <_fflush_r+0xc>
2002524e:	89a3      	ldrh	r3, [r4, #12]
20025250:	059b      	lsls	r3, r3, #22
20025252:	d4e1      	bmi.n	20025218 <_fflush_r+0xc>
20025254:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025256:	f000 fa7b 	bl	20025750 <__retarget_lock_release_recursive>
2002525a:	e7dd      	b.n	20025218 <_fflush_r+0xc>

2002525c <std>:
2002525c:	2300      	movs	r3, #0
2002525e:	b510      	push	{r4, lr}
20025260:	4604      	mov	r4, r0
20025262:	6083      	str	r3, [r0, #8]
20025264:	8181      	strh	r1, [r0, #12]
20025266:	4619      	mov	r1, r3
20025268:	6643      	str	r3, [r0, #100]	@ 0x64
2002526a:	81c2      	strh	r2, [r0, #14]
2002526c:	2208      	movs	r2, #8
2002526e:	6183      	str	r3, [r0, #24]
20025270:	e9c0 3300 	strd	r3, r3, [r0]
20025274:	e9c0 3304 	strd	r3, r3, [r0, #16]
20025278:	305c      	adds	r0, #92	@ 0x5c
2002527a:	f000 fa09 	bl	20025690 <memset>
2002527e:	4b0d      	ldr	r3, [pc, #52]	@ (200252b4 <std+0x58>)
20025280:	6224      	str	r4, [r4, #32]
20025282:	6263      	str	r3, [r4, #36]	@ 0x24
20025284:	4b0c      	ldr	r3, [pc, #48]	@ (200252b8 <std+0x5c>)
20025286:	62a3      	str	r3, [r4, #40]	@ 0x28
20025288:	4b0c      	ldr	r3, [pc, #48]	@ (200252bc <std+0x60>)
2002528a:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002528c:	4b0c      	ldr	r3, [pc, #48]	@ (200252c0 <std+0x64>)
2002528e:	6323      	str	r3, [r4, #48]	@ 0x30
20025290:	4b0c      	ldr	r3, [pc, #48]	@ (200252c4 <std+0x68>)
20025292:	429c      	cmp	r4, r3
20025294:	d006      	beq.n	200252a4 <std+0x48>
20025296:	f103 0268 	add.w	r2, r3, #104	@ 0x68
2002529a:	4294      	cmp	r4, r2
2002529c:	d002      	beq.n	200252a4 <std+0x48>
2002529e:	33d0      	adds	r3, #208	@ 0xd0
200252a0:	429c      	cmp	r4, r3
200252a2:	d105      	bne.n	200252b0 <std+0x54>
200252a4:	f104 0058 	add.w	r0, r4, #88	@ 0x58
200252a8:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
200252ac:	f000 ba4e 	b.w	2002574c <__retarget_lock_init_recursive>
200252b0:	bd10      	pop	{r4, pc}
200252b2:	bf00      	nop
200252b4:	200254c5 	.word	0x200254c5
200252b8:	200254e7 	.word	0x200254e7
200252bc:	2002551f 	.word	0x2002551f
200252c0:	20025545 	.word	0x20025545
200252c4:	2004d090 	.word	0x2004d090

200252c8 <stdio_exit_handler>:
200252c8:	4a02      	ldr	r2, [pc, #8]	@ (200252d4 <stdio_exit_handler+0xc>)
200252ca:	4903      	ldr	r1, [pc, #12]	@ (200252d8 <stdio_exit_handler+0x10>)
200252cc:	4803      	ldr	r0, [pc, #12]	@ (200252dc <stdio_exit_handler+0x14>)
200252ce:	f000 b86b 	b.w	200253a8 <_fwalk_sglue>
200252d2:	bf00      	nop
200252d4:	200449a4 	.word	0x200449a4
200252d8:	2002520d 	.word	0x2002520d
200252dc:	200449b4 	.word	0x200449b4

200252e0 <cleanup_stdio>:
200252e0:	6841      	ldr	r1, [r0, #4]
200252e2:	4b0c      	ldr	r3, [pc, #48]	@ (20025314 <cleanup_stdio+0x34>)
200252e4:	4299      	cmp	r1, r3
200252e6:	b510      	push	{r4, lr}
200252e8:	4604      	mov	r4, r0
200252ea:	d001      	beq.n	200252f0 <cleanup_stdio+0x10>
200252ec:	f7ff ff8e 	bl	2002520c <_fflush_r>
200252f0:	68a1      	ldr	r1, [r4, #8]
200252f2:	4b09      	ldr	r3, [pc, #36]	@ (20025318 <cleanup_stdio+0x38>)
200252f4:	4299      	cmp	r1, r3
200252f6:	d002      	beq.n	200252fe <cleanup_stdio+0x1e>
200252f8:	4620      	mov	r0, r4
200252fa:	f7ff ff87 	bl	2002520c <_fflush_r>
200252fe:	68e1      	ldr	r1, [r4, #12]
20025300:	4b06      	ldr	r3, [pc, #24]	@ (2002531c <cleanup_stdio+0x3c>)
20025302:	4299      	cmp	r1, r3
20025304:	d004      	beq.n	20025310 <cleanup_stdio+0x30>
20025306:	4620      	mov	r0, r4
20025308:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002530c:	f7ff bf7e 	b.w	2002520c <_fflush_r>
20025310:	bd10      	pop	{r4, pc}
20025312:	bf00      	nop
20025314:	2004d090 	.word	0x2004d090
20025318:	2004d0f8 	.word	0x2004d0f8
2002531c:	2004d160 	.word	0x2004d160

20025320 <global_stdio_init.part.0>:
20025320:	4b0c      	ldr	r3, [pc, #48]	@ (20025354 <global_stdio_init.part.0+0x34>)
20025322:	2104      	movs	r1, #4
20025324:	4a0c      	ldr	r2, [pc, #48]	@ (20025358 <global_stdio_init.part.0+0x38>)
20025326:	480d      	ldr	r0, [pc, #52]	@ (2002535c <global_stdio_init.part.0+0x3c>)
20025328:	b510      	push	{r4, lr}
2002532a:	601a      	str	r2, [r3, #0]
2002532c:	2200      	movs	r2, #0
2002532e:	f7ff ff95 	bl	2002525c <std>
20025332:	4b0a      	ldr	r3, [pc, #40]	@ (2002535c <global_stdio_init.part.0+0x3c>)
20025334:	2201      	movs	r2, #1
20025336:	2109      	movs	r1, #9
20025338:	461c      	mov	r4, r3
2002533a:	f103 0068 	add.w	r0, r3, #104	@ 0x68
2002533e:	f7ff ff8d 	bl	2002525c <std>
20025342:	2202      	movs	r2, #2
20025344:	f104 00d0 	add.w	r0, r4, #208	@ 0xd0
20025348:	2112      	movs	r1, #18
2002534a:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
2002534e:	f7ff bf85 	b.w	2002525c <std>
20025352:	bf00      	nop
20025354:	2004d1c8 	.word	0x2004d1c8
20025358:	200252c9 	.word	0x200252c9
2002535c:	2004d090 	.word	0x2004d090

20025360 <__sfp_lock_acquire>:
20025360:	4801      	ldr	r0, [pc, #4]	@ (20025368 <__sfp_lock_acquire+0x8>)
20025362:	f000 b9f4 	b.w	2002574e <__retarget_lock_acquire_recursive>
20025366:	bf00      	nop
20025368:	2004d1d1 	.word	0x2004d1d1

2002536c <__sfp_lock_release>:
2002536c:	4801      	ldr	r0, [pc, #4]	@ (20025374 <__sfp_lock_release+0x8>)
2002536e:	f000 b9ef 	b.w	20025750 <__retarget_lock_release_recursive>
20025372:	bf00      	nop
20025374:	2004d1d1 	.word	0x2004d1d1

20025378 <__sinit>:
20025378:	b510      	push	{r4, lr}
2002537a:	4604      	mov	r4, r0
2002537c:	f7ff fff0 	bl	20025360 <__sfp_lock_acquire>
20025380:	6a23      	ldr	r3, [r4, #32]
20025382:	b11b      	cbz	r3, 2002538c <__sinit+0x14>
20025384:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025388:	f7ff bff0 	b.w	2002536c <__sfp_lock_release>
2002538c:	4b04      	ldr	r3, [pc, #16]	@ (200253a0 <__sinit+0x28>)
2002538e:	6223      	str	r3, [r4, #32]
20025390:	4b04      	ldr	r3, [pc, #16]	@ (200253a4 <__sinit+0x2c>)
20025392:	681b      	ldr	r3, [r3, #0]
20025394:	2b00      	cmp	r3, #0
20025396:	d1f5      	bne.n	20025384 <__sinit+0xc>
20025398:	f7ff ffc2 	bl	20025320 <global_stdio_init.part.0>
2002539c:	e7f2      	b.n	20025384 <__sinit+0xc>
2002539e:	bf00      	nop
200253a0:	200252e1 	.word	0x200252e1
200253a4:	2004d1c8 	.word	0x2004d1c8

200253a8 <_fwalk_sglue>:
200253a8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
200253ac:	4607      	mov	r7, r0
200253ae:	4688      	mov	r8, r1
200253b0:	4614      	mov	r4, r2
200253b2:	2600      	movs	r6, #0
200253b4:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
200253b8:	f1b9 0901 	subs.w	r9, r9, #1
200253bc:	d505      	bpl.n	200253ca <_fwalk_sglue+0x22>
200253be:	6824      	ldr	r4, [r4, #0]
200253c0:	2c00      	cmp	r4, #0
200253c2:	d1f7      	bne.n	200253b4 <_fwalk_sglue+0xc>
200253c4:	4630      	mov	r0, r6
200253c6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200253ca:	89ab      	ldrh	r3, [r5, #12]
200253cc:	2b01      	cmp	r3, #1
200253ce:	d907      	bls.n	200253e0 <_fwalk_sglue+0x38>
200253d0:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
200253d4:	3301      	adds	r3, #1
200253d6:	d003      	beq.n	200253e0 <_fwalk_sglue+0x38>
200253d8:	4629      	mov	r1, r5
200253da:	4638      	mov	r0, r7
200253dc:	47c0      	blx	r8
200253de:	4306      	orrs	r6, r0
200253e0:	3568      	adds	r5, #104	@ 0x68
200253e2:	e7e9      	b.n	200253b8 <_fwalk_sglue+0x10>

200253e4 <iprintf>:
200253e4:	b40f      	push	{r0, r1, r2, r3}
200253e6:	b507      	push	{r0, r1, r2, lr}
200253e8:	4906      	ldr	r1, [pc, #24]	@ (20025404 <iprintf+0x20>)
200253ea:	ab04      	add	r3, sp, #16
200253ec:	6808      	ldr	r0, [r1, #0]
200253ee:	f853 2b04 	ldr.w	r2, [r3], #4
200253f2:	6881      	ldr	r1, [r0, #8]
200253f4:	9301      	str	r3, [sp, #4]
200253f6:	f000 fa3b 	bl	20025870 <_vfiprintf_r>
200253fa:	b003      	add	sp, #12
200253fc:	f85d eb04 	ldr.w	lr, [sp], #4
20025400:	b004      	add	sp, #16
20025402:	4770      	bx	lr
20025404:	200449b0 	.word	0x200449b0

20025408 <_puts_r>:
20025408:	6a03      	ldr	r3, [r0, #32]
2002540a:	b570      	push	{r4, r5, r6, lr}
2002540c:	4605      	mov	r5, r0
2002540e:	460e      	mov	r6, r1
20025410:	6884      	ldr	r4, [r0, #8]
20025412:	b90b      	cbnz	r3, 20025418 <_puts_r+0x10>
20025414:	f7ff ffb0 	bl	20025378 <__sinit>
20025418:	6e63      	ldr	r3, [r4, #100]	@ 0x64
2002541a:	07db      	lsls	r3, r3, #31
2002541c:	d405      	bmi.n	2002542a <_puts_r+0x22>
2002541e:	89a3      	ldrh	r3, [r4, #12]
20025420:	0598      	lsls	r0, r3, #22
20025422:	d402      	bmi.n	2002542a <_puts_r+0x22>
20025424:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025426:	f000 f992 	bl	2002574e <__retarget_lock_acquire_recursive>
2002542a:	89a3      	ldrh	r3, [r4, #12]
2002542c:	0719      	lsls	r1, r3, #28
2002542e:	d502      	bpl.n	20025436 <_puts_r+0x2e>
20025430:	6923      	ldr	r3, [r4, #16]
20025432:	2b00      	cmp	r3, #0
20025434:	d135      	bne.n	200254a2 <_puts_r+0x9a>
20025436:	4621      	mov	r1, r4
20025438:	4628      	mov	r0, r5
2002543a:	f000 f8c5 	bl	200255c8 <__swsetup_r>
2002543e:	b380      	cbz	r0, 200254a2 <_puts_r+0x9a>
20025440:	f04f 35ff 	mov.w	r5, #4294967295
20025444:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025446:	07da      	lsls	r2, r3, #31
20025448:	d405      	bmi.n	20025456 <_puts_r+0x4e>
2002544a:	89a3      	ldrh	r3, [r4, #12]
2002544c:	059b      	lsls	r3, r3, #22
2002544e:	d402      	bmi.n	20025456 <_puts_r+0x4e>
20025450:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025452:	f000 f97d 	bl	20025750 <__retarget_lock_release_recursive>
20025456:	4628      	mov	r0, r5
20025458:	bd70      	pop	{r4, r5, r6, pc}
2002545a:	2b00      	cmp	r3, #0
2002545c:	da04      	bge.n	20025468 <_puts_r+0x60>
2002545e:	69a2      	ldr	r2, [r4, #24]
20025460:	4293      	cmp	r3, r2
20025462:	db17      	blt.n	20025494 <_puts_r+0x8c>
20025464:	290a      	cmp	r1, #10
20025466:	d015      	beq.n	20025494 <_puts_r+0x8c>
20025468:	6823      	ldr	r3, [r4, #0]
2002546a:	1c5a      	adds	r2, r3, #1
2002546c:	6022      	str	r2, [r4, #0]
2002546e:	7019      	strb	r1, [r3, #0]
20025470:	68a3      	ldr	r3, [r4, #8]
20025472:	f816 1f01 	ldrb.w	r1, [r6, #1]!
20025476:	3b01      	subs	r3, #1
20025478:	60a3      	str	r3, [r4, #8]
2002547a:	2900      	cmp	r1, #0
2002547c:	d1ed      	bne.n	2002545a <_puts_r+0x52>
2002547e:	2b00      	cmp	r3, #0
20025480:	da11      	bge.n	200254a6 <_puts_r+0x9e>
20025482:	4622      	mov	r2, r4
20025484:	210a      	movs	r1, #10
20025486:	4628      	mov	r0, r5
20025488:	f000 f860 	bl	2002554c <__swbuf_r>
2002548c:	3001      	adds	r0, #1
2002548e:	d0d7      	beq.n	20025440 <_puts_r+0x38>
20025490:	250a      	movs	r5, #10
20025492:	e7d7      	b.n	20025444 <_puts_r+0x3c>
20025494:	4622      	mov	r2, r4
20025496:	4628      	mov	r0, r5
20025498:	f000 f858 	bl	2002554c <__swbuf_r>
2002549c:	3001      	adds	r0, #1
2002549e:	d1e7      	bne.n	20025470 <_puts_r+0x68>
200254a0:	e7ce      	b.n	20025440 <_puts_r+0x38>
200254a2:	3e01      	subs	r6, #1
200254a4:	e7e4      	b.n	20025470 <_puts_r+0x68>
200254a6:	6823      	ldr	r3, [r4, #0]
200254a8:	1c5a      	adds	r2, r3, #1
200254aa:	6022      	str	r2, [r4, #0]
200254ac:	220a      	movs	r2, #10
200254ae:	701a      	strb	r2, [r3, #0]
200254b0:	e7ee      	b.n	20025490 <_puts_r+0x88>
	...

200254b4 <puts>:
200254b4:	4b02      	ldr	r3, [pc, #8]	@ (200254c0 <puts+0xc>)
200254b6:	4601      	mov	r1, r0
200254b8:	6818      	ldr	r0, [r3, #0]
200254ba:	f7ff bfa5 	b.w	20025408 <_puts_r>
200254be:	bf00      	nop
200254c0:	200449b0 	.word	0x200449b0

200254c4 <__sread>:
200254c4:	b510      	push	{r4, lr}
200254c6:	460c      	mov	r4, r1
200254c8:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200254cc:	f000 f90a 	bl	200256e4 <_read_r>
200254d0:	2800      	cmp	r0, #0
200254d2:	bfab      	itete	ge
200254d4:	6d63      	ldrge	r3, [r4, #84]	@ 0x54
200254d6:	89a3      	ldrhlt	r3, [r4, #12]
200254d8:	181b      	addge	r3, r3, r0
200254da:	f423 5380 	biclt.w	r3, r3, #4096	@ 0x1000
200254de:	bfac      	ite	ge
200254e0:	6563      	strge	r3, [r4, #84]	@ 0x54
200254e2:	81a3      	strhlt	r3, [r4, #12]
200254e4:	bd10      	pop	{r4, pc}

200254e6 <__swrite>:
200254e6:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200254ea:	461f      	mov	r7, r3
200254ec:	898b      	ldrh	r3, [r1, #12]
200254ee:	4605      	mov	r5, r0
200254f0:	460c      	mov	r4, r1
200254f2:	05db      	lsls	r3, r3, #23
200254f4:	4616      	mov	r6, r2
200254f6:	d505      	bpl.n	20025504 <__swrite+0x1e>
200254f8:	2302      	movs	r3, #2
200254fa:	2200      	movs	r2, #0
200254fc:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025500:	f000 f8de 	bl	200256c0 <_lseek_r>
20025504:	89a3      	ldrh	r3, [r4, #12]
20025506:	4632      	mov	r2, r6
20025508:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
2002550c:	4628      	mov	r0, r5
2002550e:	f423 5380 	bic.w	r3, r3, #4096	@ 0x1000
20025512:	81a3      	strh	r3, [r4, #12]
20025514:	463b      	mov	r3, r7
20025516:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002551a:	f000 b905 	b.w	20025728 <_write_r>

2002551e <__sseek>:
2002551e:	b510      	push	{r4, lr}
20025520:	460c      	mov	r4, r1
20025522:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025526:	f000 f8cb 	bl	200256c0 <_lseek_r>
2002552a:	1c42      	adds	r2, r0, #1
2002552c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025530:	bf15      	itete	ne
20025532:	6560      	strne	r0, [r4, #84]	@ 0x54
20025534:	f423 5380 	biceq.w	r3, r3, #4096	@ 0x1000
20025538:	f443 5380 	orrne.w	r3, r3, #4096	@ 0x1000
2002553c:	81a3      	strheq	r3, [r4, #12]
2002553e:	bf18      	it	ne
20025540:	81a3      	strhne	r3, [r4, #12]
20025542:	bd10      	pop	{r4, pc}

20025544 <__sclose>:
20025544:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025548:	f000 b8aa 	b.w	200256a0 <_close_r>

2002554c <__swbuf_r>:
2002554c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002554e:	460e      	mov	r6, r1
20025550:	4614      	mov	r4, r2
20025552:	4605      	mov	r5, r0
20025554:	b118      	cbz	r0, 2002555e <__swbuf_r+0x12>
20025556:	6a03      	ldr	r3, [r0, #32]
20025558:	b90b      	cbnz	r3, 2002555e <__swbuf_r+0x12>
2002555a:	f7ff ff0d 	bl	20025378 <__sinit>
2002555e:	69a3      	ldr	r3, [r4, #24]
20025560:	60a3      	str	r3, [r4, #8]
20025562:	89a3      	ldrh	r3, [r4, #12]
20025564:	071a      	lsls	r2, r3, #28
20025566:	d501      	bpl.n	2002556c <__swbuf_r+0x20>
20025568:	6923      	ldr	r3, [r4, #16]
2002556a:	b943      	cbnz	r3, 2002557e <__swbuf_r+0x32>
2002556c:	4621      	mov	r1, r4
2002556e:	4628      	mov	r0, r5
20025570:	f000 f82a 	bl	200255c8 <__swsetup_r>
20025574:	b118      	cbz	r0, 2002557e <__swbuf_r+0x32>
20025576:	f04f 37ff 	mov.w	r7, #4294967295
2002557a:	4638      	mov	r0, r7
2002557c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002557e:	6823      	ldr	r3, [r4, #0]
20025580:	b2f6      	uxtb	r6, r6
20025582:	6922      	ldr	r2, [r4, #16]
20025584:	4637      	mov	r7, r6
20025586:	1a98      	subs	r0, r3, r2
20025588:	6963      	ldr	r3, [r4, #20]
2002558a:	4283      	cmp	r3, r0
2002558c:	dc05      	bgt.n	2002559a <__swbuf_r+0x4e>
2002558e:	4621      	mov	r1, r4
20025590:	4628      	mov	r0, r5
20025592:	f7ff fe3b 	bl	2002520c <_fflush_r>
20025596:	2800      	cmp	r0, #0
20025598:	d1ed      	bne.n	20025576 <__swbuf_r+0x2a>
2002559a:	68a3      	ldr	r3, [r4, #8]
2002559c:	3b01      	subs	r3, #1
2002559e:	60a3      	str	r3, [r4, #8]
200255a0:	6823      	ldr	r3, [r4, #0]
200255a2:	1c5a      	adds	r2, r3, #1
200255a4:	6022      	str	r2, [r4, #0]
200255a6:	701e      	strb	r6, [r3, #0]
200255a8:	1c43      	adds	r3, r0, #1
200255aa:	6962      	ldr	r2, [r4, #20]
200255ac:	429a      	cmp	r2, r3
200255ae:	d004      	beq.n	200255ba <__swbuf_r+0x6e>
200255b0:	89a3      	ldrh	r3, [r4, #12]
200255b2:	07db      	lsls	r3, r3, #31
200255b4:	d5e1      	bpl.n	2002557a <__swbuf_r+0x2e>
200255b6:	2e0a      	cmp	r6, #10
200255b8:	d1df      	bne.n	2002557a <__swbuf_r+0x2e>
200255ba:	4621      	mov	r1, r4
200255bc:	4628      	mov	r0, r5
200255be:	f7ff fe25 	bl	2002520c <_fflush_r>
200255c2:	2800      	cmp	r0, #0
200255c4:	d0d9      	beq.n	2002557a <__swbuf_r+0x2e>
200255c6:	e7d6      	b.n	20025576 <__swbuf_r+0x2a>

200255c8 <__swsetup_r>:
200255c8:	b538      	push	{r3, r4, r5, lr}
200255ca:	4b28      	ldr	r3, [pc, #160]	@ (2002566c <__swsetup_r+0xa4>)
200255cc:	4605      	mov	r5, r0
200255ce:	460c      	mov	r4, r1
200255d0:	6818      	ldr	r0, [r3, #0]
200255d2:	b118      	cbz	r0, 200255dc <__swsetup_r+0x14>
200255d4:	6a03      	ldr	r3, [r0, #32]
200255d6:	b90b      	cbnz	r3, 200255dc <__swsetup_r+0x14>
200255d8:	f7ff fece 	bl	20025378 <__sinit>
200255dc:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200255e0:	071a      	lsls	r2, r3, #28
200255e2:	d421      	bmi.n	20025628 <__swsetup_r+0x60>
200255e4:	06d8      	lsls	r0, r3, #27
200255e6:	d407      	bmi.n	200255f8 <__swsetup_r+0x30>
200255e8:	2209      	movs	r2, #9
200255ea:	602a      	str	r2, [r5, #0]
200255ec:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
200255f0:	f04f 30ff 	mov.w	r0, #4294967295
200255f4:	81a3      	strh	r3, [r4, #12]
200255f6:	e030      	b.n	2002565a <__swsetup_r+0x92>
200255f8:	0759      	lsls	r1, r3, #29
200255fa:	d512      	bpl.n	20025622 <__swsetup_r+0x5a>
200255fc:	6b61      	ldr	r1, [r4, #52]	@ 0x34
200255fe:	b141      	cbz	r1, 20025612 <__swsetup_r+0x4a>
20025600:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025604:	4299      	cmp	r1, r3
20025606:	d002      	beq.n	2002560e <__swsetup_r+0x46>
20025608:	4628      	mov	r0, r5
2002560a:	f000 f8bd 	bl	20025788 <_free_r>
2002560e:	2300      	movs	r3, #0
20025610:	6363      	str	r3, [r4, #52]	@ 0x34
20025612:	2200      	movs	r2, #0
20025614:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025618:	6062      	str	r2, [r4, #4]
2002561a:	f023 0324 	bic.w	r3, r3, #36	@ 0x24
2002561e:	6922      	ldr	r2, [r4, #16]
20025620:	6022      	str	r2, [r4, #0]
20025622:	f043 0308 	orr.w	r3, r3, #8
20025626:	81a3      	strh	r3, [r4, #12]
20025628:	6922      	ldr	r2, [r4, #16]
2002562a:	b93a      	cbnz	r2, 2002563c <__swsetup_r+0x74>
2002562c:	059a      	lsls	r2, r3, #22
2002562e:	d501      	bpl.n	20025634 <__swsetup_r+0x6c>
20025630:	0618      	lsls	r0, r3, #24
20025632:	d503      	bpl.n	2002563c <__swsetup_r+0x74>
20025634:	4621      	mov	r1, r4
20025636:	4628      	mov	r0, r5
20025638:	f000 fbe8 	bl	20025e0c <__smakebuf_r>
2002563c:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025640:	f013 0201 	ands.w	r2, r3, #1
20025644:	d00a      	beq.n	2002565c <__swsetup_r+0x94>
20025646:	2200      	movs	r2, #0
20025648:	60a2      	str	r2, [r4, #8]
2002564a:	6962      	ldr	r2, [r4, #20]
2002564c:	4252      	negs	r2, r2
2002564e:	61a2      	str	r2, [r4, #24]
20025650:	6922      	ldr	r2, [r4, #16]
20025652:	b942      	cbnz	r2, 20025666 <__swsetup_r+0x9e>
20025654:	f013 0080 	ands.w	r0, r3, #128	@ 0x80
20025658:	d1c8      	bne.n	200255ec <__swsetup_r+0x24>
2002565a:	bd38      	pop	{r3, r4, r5, pc}
2002565c:	0799      	lsls	r1, r3, #30
2002565e:	bf58      	it	pl
20025660:	6962      	ldrpl	r2, [r4, #20]
20025662:	60a2      	str	r2, [r4, #8]
20025664:	e7f4      	b.n	20025650 <__swsetup_r+0x88>
20025666:	2000      	movs	r0, #0
20025668:	e7f7      	b.n	2002565a <__swsetup_r+0x92>
2002566a:	bf00      	nop
2002566c:	200449b0 	.word	0x200449b0

20025670 <memcmp>:
20025670:	3901      	subs	r1, #1
20025672:	4402      	add	r2, r0
20025674:	b510      	push	{r4, lr}
20025676:	4290      	cmp	r0, r2
20025678:	d101      	bne.n	2002567e <memcmp+0xe>
2002567a:	2000      	movs	r0, #0
2002567c:	e005      	b.n	2002568a <memcmp+0x1a>
2002567e:	7803      	ldrb	r3, [r0, #0]
20025680:	f811 4f01 	ldrb.w	r4, [r1, #1]!
20025684:	42a3      	cmp	r3, r4
20025686:	d001      	beq.n	2002568c <memcmp+0x1c>
20025688:	1b18      	subs	r0, r3, r4
2002568a:	bd10      	pop	{r4, pc}
2002568c:	3001      	adds	r0, #1
2002568e:	e7f2      	b.n	20025676 <memcmp+0x6>

20025690 <memset>:
20025690:	4402      	add	r2, r0
20025692:	4603      	mov	r3, r0
20025694:	4293      	cmp	r3, r2
20025696:	d100      	bne.n	2002569a <memset+0xa>
20025698:	4770      	bx	lr
2002569a:	f803 1b01 	strb.w	r1, [r3], #1
2002569e:	e7f9      	b.n	20025694 <memset+0x4>

200256a0 <_close_r>:
200256a0:	b538      	push	{r3, r4, r5, lr}
200256a2:	2300      	movs	r3, #0
200256a4:	4d05      	ldr	r5, [pc, #20]	@ (200256bc <_close_r+0x1c>)
200256a6:	4604      	mov	r4, r0
200256a8:	4608      	mov	r0, r1
200256aa:	602b      	str	r3, [r5, #0]
200256ac:	f7fb ffe4 	bl	20021678 <_close>
200256b0:	1c43      	adds	r3, r0, #1
200256b2:	d102      	bne.n	200256ba <_close_r+0x1a>
200256b4:	682b      	ldr	r3, [r5, #0]
200256b6:	b103      	cbz	r3, 200256ba <_close_r+0x1a>
200256b8:	6023      	str	r3, [r4, #0]
200256ba:	bd38      	pop	{r3, r4, r5, pc}
200256bc:	2004d1cc 	.word	0x2004d1cc

200256c0 <_lseek_r>:
200256c0:	b538      	push	{r3, r4, r5, lr}
200256c2:	4604      	mov	r4, r0
200256c4:	4d06      	ldr	r5, [pc, #24]	@ (200256e0 <_lseek_r+0x20>)
200256c6:	4608      	mov	r0, r1
200256c8:	4611      	mov	r1, r2
200256ca:	2200      	movs	r2, #0
200256cc:	602a      	str	r2, [r5, #0]
200256ce:	461a      	mov	r2, r3
200256d0:	f7fb ffd5 	bl	2002167e <_lseek>
200256d4:	1c43      	adds	r3, r0, #1
200256d6:	d102      	bne.n	200256de <_lseek_r+0x1e>
200256d8:	682b      	ldr	r3, [r5, #0]
200256da:	b103      	cbz	r3, 200256de <_lseek_r+0x1e>
200256dc:	6023      	str	r3, [r4, #0]
200256de:	bd38      	pop	{r3, r4, r5, pc}
200256e0:	2004d1cc 	.word	0x2004d1cc

200256e4 <_read_r>:
200256e4:	b538      	push	{r3, r4, r5, lr}
200256e6:	4604      	mov	r4, r0
200256e8:	4d06      	ldr	r5, [pc, #24]	@ (20025704 <_read_r+0x20>)
200256ea:	4608      	mov	r0, r1
200256ec:	4611      	mov	r1, r2
200256ee:	2200      	movs	r2, #0
200256f0:	602a      	str	r2, [r5, #0]
200256f2:	461a      	mov	r2, r3
200256f4:	f7fb ffc6 	bl	20021684 <_read>
200256f8:	1c43      	adds	r3, r0, #1
200256fa:	d102      	bne.n	20025702 <_read_r+0x1e>
200256fc:	682b      	ldr	r3, [r5, #0]
200256fe:	b103      	cbz	r3, 20025702 <_read_r+0x1e>
20025700:	6023      	str	r3, [r4, #0]
20025702:	bd38      	pop	{r3, r4, r5, pc}
20025704:	2004d1cc 	.word	0x2004d1cc

20025708 <_sbrk_r>:
20025708:	b538      	push	{r3, r4, r5, lr}
2002570a:	2300      	movs	r3, #0
2002570c:	4d05      	ldr	r5, [pc, #20]	@ (20025724 <_sbrk_r+0x1c>)
2002570e:	4604      	mov	r4, r0
20025710:	4608      	mov	r0, r1
20025712:	602b      	str	r3, [r5, #0]
20025714:	f000 fbd6 	bl	20025ec4 <_sbrk>
20025718:	1c43      	adds	r3, r0, #1
2002571a:	d102      	bne.n	20025722 <_sbrk_r+0x1a>
2002571c:	682b      	ldr	r3, [r5, #0]
2002571e:	b103      	cbz	r3, 20025722 <_sbrk_r+0x1a>
20025720:	6023      	str	r3, [r4, #0]
20025722:	bd38      	pop	{r3, r4, r5, pc}
20025724:	2004d1cc 	.word	0x2004d1cc

20025728 <_write_r>:
20025728:	b538      	push	{r3, r4, r5, lr}
2002572a:	4604      	mov	r4, r0
2002572c:	4d06      	ldr	r5, [pc, #24]	@ (20025748 <_write_r+0x20>)
2002572e:	4608      	mov	r0, r1
20025730:	4611      	mov	r1, r2
20025732:	2200      	movs	r2, #0
20025734:	602a      	str	r2, [r5, #0]
20025736:	461a      	mov	r2, r3
20025738:	f7fb fb80 	bl	20020e3c <_write>
2002573c:	1c43      	adds	r3, r0, #1
2002573e:	d102      	bne.n	20025746 <_write_r+0x1e>
20025740:	682b      	ldr	r3, [r5, #0]
20025742:	b103      	cbz	r3, 20025746 <_write_r+0x1e>
20025744:	6023      	str	r3, [r4, #0]
20025746:	bd38      	pop	{r3, r4, r5, pc}
20025748:	2004d1cc 	.word	0x2004d1cc

2002574c <__retarget_lock_init_recursive>:
2002574c:	4770      	bx	lr

2002574e <__retarget_lock_acquire_recursive>:
2002574e:	4770      	bx	lr

20025750 <__retarget_lock_release_recursive>:
20025750:	4770      	bx	lr

20025752 <memchr>:
20025752:	b2c9      	uxtb	r1, r1
20025754:	4603      	mov	r3, r0
20025756:	4402      	add	r2, r0
20025758:	b510      	push	{r4, lr}
2002575a:	4293      	cmp	r3, r2
2002575c:	4618      	mov	r0, r3
2002575e:	d101      	bne.n	20025764 <memchr+0x12>
20025760:	2000      	movs	r0, #0
20025762:	e003      	b.n	2002576c <memchr+0x1a>
20025764:	7804      	ldrb	r4, [r0, #0]
20025766:	3301      	adds	r3, #1
20025768:	428c      	cmp	r4, r1
2002576a:	d1f6      	bne.n	2002575a <memchr+0x8>
2002576c:	bd10      	pop	{r4, pc}

2002576e <memcpy>:
2002576e:	440a      	add	r2, r1
20025770:	1e43      	subs	r3, r0, #1
20025772:	4291      	cmp	r1, r2
20025774:	d100      	bne.n	20025778 <memcpy+0xa>
20025776:	4770      	bx	lr
20025778:	b510      	push	{r4, lr}
2002577a:	f811 4b01 	ldrb.w	r4, [r1], #1
2002577e:	4291      	cmp	r1, r2
20025780:	f803 4f01 	strb.w	r4, [r3, #1]!
20025784:	d1f9      	bne.n	2002577a <memcpy+0xc>
20025786:	bd10      	pop	{r4, pc}

20025788 <_free_r>:
20025788:	b538      	push	{r3, r4, r5, lr}
2002578a:	4605      	mov	r5, r0
2002578c:	2900      	cmp	r1, #0
2002578e:	d041      	beq.n	20025814 <_free_r+0x8c>
20025790:	f851 3c04 	ldr.w	r3, [r1, #-4]
20025794:	1f0c      	subs	r4, r1, #4
20025796:	2b00      	cmp	r3, #0
20025798:	bfb8      	it	lt
2002579a:	18e4      	addlt	r4, r4, r3
2002579c:	f7ff fcaa 	bl	200250f4 <__malloc_lock>
200257a0:	4a1d      	ldr	r2, [pc, #116]	@ (20025818 <_free_r+0x90>)
200257a2:	6813      	ldr	r3, [r2, #0]
200257a4:	b933      	cbnz	r3, 200257b4 <_free_r+0x2c>
200257a6:	6063      	str	r3, [r4, #4]
200257a8:	6014      	str	r4, [r2, #0]
200257aa:	4628      	mov	r0, r5
200257ac:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
200257b0:	f7ff bca6 	b.w	20025100 <__malloc_unlock>
200257b4:	42a3      	cmp	r3, r4
200257b6:	d908      	bls.n	200257ca <_free_r+0x42>
200257b8:	6820      	ldr	r0, [r4, #0]
200257ba:	1821      	adds	r1, r4, r0
200257bc:	428b      	cmp	r3, r1
200257be:	bf01      	itttt	eq
200257c0:	6819      	ldreq	r1, [r3, #0]
200257c2:	685b      	ldreq	r3, [r3, #4]
200257c4:	1809      	addeq	r1, r1, r0
200257c6:	6021      	streq	r1, [r4, #0]
200257c8:	e7ed      	b.n	200257a6 <_free_r+0x1e>
200257ca:	461a      	mov	r2, r3
200257cc:	685b      	ldr	r3, [r3, #4]
200257ce:	b10b      	cbz	r3, 200257d4 <_free_r+0x4c>
200257d0:	42a3      	cmp	r3, r4
200257d2:	d9fa      	bls.n	200257ca <_free_r+0x42>
200257d4:	6811      	ldr	r1, [r2, #0]
200257d6:	1850      	adds	r0, r2, r1
200257d8:	42a0      	cmp	r0, r4
200257da:	d10b      	bne.n	200257f4 <_free_r+0x6c>
200257dc:	6820      	ldr	r0, [r4, #0]
200257de:	4401      	add	r1, r0
200257e0:	1850      	adds	r0, r2, r1
200257e2:	6011      	str	r1, [r2, #0]
200257e4:	4283      	cmp	r3, r0
200257e6:	d1e0      	bne.n	200257aa <_free_r+0x22>
200257e8:	6818      	ldr	r0, [r3, #0]
200257ea:	685b      	ldr	r3, [r3, #4]
200257ec:	4408      	add	r0, r1
200257ee:	6053      	str	r3, [r2, #4]
200257f0:	6010      	str	r0, [r2, #0]
200257f2:	e7da      	b.n	200257aa <_free_r+0x22>
200257f4:	d902      	bls.n	200257fc <_free_r+0x74>
200257f6:	230c      	movs	r3, #12
200257f8:	602b      	str	r3, [r5, #0]
200257fa:	e7d6      	b.n	200257aa <_free_r+0x22>
200257fc:	6820      	ldr	r0, [r4, #0]
200257fe:	1821      	adds	r1, r4, r0
20025800:	428b      	cmp	r3, r1
20025802:	bf02      	ittt	eq
20025804:	6819      	ldreq	r1, [r3, #0]
20025806:	685b      	ldreq	r3, [r3, #4]
20025808:	1809      	addeq	r1, r1, r0
2002580a:	6063      	str	r3, [r4, #4]
2002580c:	bf08      	it	eq
2002580e:	6021      	streq	r1, [r4, #0]
20025810:	6054      	str	r4, [r2, #4]
20025812:	e7ca      	b.n	200257aa <_free_r+0x22>
20025814:	bd38      	pop	{r3, r4, r5, pc}
20025816:	bf00      	nop
20025818:	2004d08c 	.word	0x2004d08c

2002581c <__sfputc_r>:
2002581c:	6893      	ldr	r3, [r2, #8]
2002581e:	3b01      	subs	r3, #1
20025820:	2b00      	cmp	r3, #0
20025822:	b410      	push	{r4}
20025824:	6093      	str	r3, [r2, #8]
20025826:	da08      	bge.n	2002583a <__sfputc_r+0x1e>
20025828:	6994      	ldr	r4, [r2, #24]
2002582a:	42a3      	cmp	r3, r4
2002582c:	db01      	blt.n	20025832 <__sfputc_r+0x16>
2002582e:	290a      	cmp	r1, #10
20025830:	d103      	bne.n	2002583a <__sfputc_r+0x1e>
20025832:	f85d 4b04 	ldr.w	r4, [sp], #4
20025836:	f7ff be89 	b.w	2002554c <__swbuf_r>
2002583a:	6813      	ldr	r3, [r2, #0]
2002583c:	1c58      	adds	r0, r3, #1
2002583e:	6010      	str	r0, [r2, #0]
20025840:	4608      	mov	r0, r1
20025842:	7019      	strb	r1, [r3, #0]
20025844:	f85d 4b04 	ldr.w	r4, [sp], #4
20025848:	4770      	bx	lr

2002584a <__sfputs_r>:
2002584a:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002584c:	4606      	mov	r6, r0
2002584e:	460f      	mov	r7, r1
20025850:	4614      	mov	r4, r2
20025852:	18d5      	adds	r5, r2, r3
20025854:	42ac      	cmp	r4, r5
20025856:	d101      	bne.n	2002585c <__sfputs_r+0x12>
20025858:	2000      	movs	r0, #0
2002585a:	e007      	b.n	2002586c <__sfputs_r+0x22>
2002585c:	463a      	mov	r2, r7
2002585e:	f814 1b01 	ldrb.w	r1, [r4], #1
20025862:	4630      	mov	r0, r6
20025864:	f7ff ffda 	bl	2002581c <__sfputc_r>
20025868:	1c43      	adds	r3, r0, #1
2002586a:	d1f3      	bne.n	20025854 <__sfputs_r+0xa>
2002586c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

20025870 <_vfiprintf_r>:
20025870:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025874:	460d      	mov	r5, r1
20025876:	b09d      	sub	sp, #116	@ 0x74
20025878:	4614      	mov	r4, r2
2002587a:	4698      	mov	r8, r3
2002587c:	4606      	mov	r6, r0
2002587e:	b118      	cbz	r0, 20025888 <_vfiprintf_r+0x18>
20025880:	6a03      	ldr	r3, [r0, #32]
20025882:	b90b      	cbnz	r3, 20025888 <_vfiprintf_r+0x18>
20025884:	f7ff fd78 	bl	20025378 <__sinit>
20025888:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
2002588a:	07d9      	lsls	r1, r3, #31
2002588c:	d405      	bmi.n	2002589a <_vfiprintf_r+0x2a>
2002588e:	89ab      	ldrh	r3, [r5, #12]
20025890:	059a      	lsls	r2, r3, #22
20025892:	d402      	bmi.n	2002589a <_vfiprintf_r+0x2a>
20025894:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025896:	f7ff ff5a 	bl	2002574e <__retarget_lock_acquire_recursive>
2002589a:	89ab      	ldrh	r3, [r5, #12]
2002589c:	071b      	lsls	r3, r3, #28
2002589e:	d501      	bpl.n	200258a4 <_vfiprintf_r+0x34>
200258a0:	692b      	ldr	r3, [r5, #16]
200258a2:	b99b      	cbnz	r3, 200258cc <_vfiprintf_r+0x5c>
200258a4:	4629      	mov	r1, r5
200258a6:	4630      	mov	r0, r6
200258a8:	f7ff fe8e 	bl	200255c8 <__swsetup_r>
200258ac:	b170      	cbz	r0, 200258cc <_vfiprintf_r+0x5c>
200258ae:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
200258b0:	07dc      	lsls	r4, r3, #31
200258b2:	d504      	bpl.n	200258be <_vfiprintf_r+0x4e>
200258b4:	f04f 30ff 	mov.w	r0, #4294967295
200258b8:	b01d      	add	sp, #116	@ 0x74
200258ba:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200258be:	89ab      	ldrh	r3, [r5, #12]
200258c0:	0598      	lsls	r0, r3, #22
200258c2:	d4f7      	bmi.n	200258b4 <_vfiprintf_r+0x44>
200258c4:	6da8      	ldr	r0, [r5, #88]	@ 0x58
200258c6:	f7ff ff43 	bl	20025750 <__retarget_lock_release_recursive>
200258ca:	e7f3      	b.n	200258b4 <_vfiprintf_r+0x44>
200258cc:	2300      	movs	r3, #0
200258ce:	f8cd 800c 	str.w	r8, [sp, #12]
200258d2:	f04f 0901 	mov.w	r9, #1
200258d6:	f8df 81b4 	ldr.w	r8, [pc, #436]	@ 20025a8c <_vfiprintf_r+0x21c>
200258da:	9309      	str	r3, [sp, #36]	@ 0x24
200258dc:	2320      	movs	r3, #32
200258de:	f88d 3029 	strb.w	r3, [sp, #41]	@ 0x29
200258e2:	2330      	movs	r3, #48	@ 0x30
200258e4:	f88d 302a 	strb.w	r3, [sp, #42]	@ 0x2a
200258e8:	4623      	mov	r3, r4
200258ea:	469a      	mov	sl, r3
200258ec:	f813 2b01 	ldrb.w	r2, [r3], #1
200258f0:	b10a      	cbz	r2, 200258f6 <_vfiprintf_r+0x86>
200258f2:	2a25      	cmp	r2, #37	@ 0x25
200258f4:	d1f9      	bne.n	200258ea <_vfiprintf_r+0x7a>
200258f6:	ebba 0b04 	subs.w	fp, sl, r4
200258fa:	d00b      	beq.n	20025914 <_vfiprintf_r+0xa4>
200258fc:	465b      	mov	r3, fp
200258fe:	4622      	mov	r2, r4
20025900:	4629      	mov	r1, r5
20025902:	4630      	mov	r0, r6
20025904:	f7ff ffa1 	bl	2002584a <__sfputs_r>
20025908:	3001      	adds	r0, #1
2002590a:	f000 80a7 	beq.w	20025a5c <_vfiprintf_r+0x1ec>
2002590e:	9a09      	ldr	r2, [sp, #36]	@ 0x24
20025910:	445a      	add	r2, fp
20025912:	9209      	str	r2, [sp, #36]	@ 0x24
20025914:	f89a 3000 	ldrb.w	r3, [sl]
20025918:	2b00      	cmp	r3, #0
2002591a:	f000 809f 	beq.w	20025a5c <_vfiprintf_r+0x1ec>
2002591e:	2300      	movs	r3, #0
20025920:	f04f 32ff 	mov.w	r2, #4294967295
20025924:	f10a 0a01 	add.w	sl, sl, #1
20025928:	9304      	str	r3, [sp, #16]
2002592a:	9307      	str	r3, [sp, #28]
2002592c:	f88d 3053 	strb.w	r3, [sp, #83]	@ 0x53
20025930:	931a      	str	r3, [sp, #104]	@ 0x68
20025932:	e9cd 2305 	strd	r2, r3, [sp, #20]
20025936:	4654      	mov	r4, sl
20025938:	2205      	movs	r2, #5
2002593a:	4854      	ldr	r0, [pc, #336]	@ (20025a8c <_vfiprintf_r+0x21c>)
2002593c:	f814 1b01 	ldrb.w	r1, [r4], #1
20025940:	f7ff ff07 	bl	20025752 <memchr>
20025944:	9a04      	ldr	r2, [sp, #16]
20025946:	b9d8      	cbnz	r0, 20025980 <_vfiprintf_r+0x110>
20025948:	06d1      	lsls	r1, r2, #27
2002594a:	bf44      	itt	mi
2002594c:	2320      	movmi	r3, #32
2002594e:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20025952:	0713      	lsls	r3, r2, #28
20025954:	bf44      	itt	mi
20025956:	232b      	movmi	r3, #43	@ 0x2b
20025958:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
2002595c:	f89a 3000 	ldrb.w	r3, [sl]
20025960:	2b2a      	cmp	r3, #42	@ 0x2a
20025962:	d015      	beq.n	20025990 <_vfiprintf_r+0x120>
20025964:	9a07      	ldr	r2, [sp, #28]
20025966:	4654      	mov	r4, sl
20025968:	2000      	movs	r0, #0
2002596a:	f04f 0c0a 	mov.w	ip, #10
2002596e:	4621      	mov	r1, r4
20025970:	f811 3b01 	ldrb.w	r3, [r1], #1
20025974:	3b30      	subs	r3, #48	@ 0x30
20025976:	2b09      	cmp	r3, #9
20025978:	d94b      	bls.n	20025a12 <_vfiprintf_r+0x1a2>
2002597a:	b1b0      	cbz	r0, 200259aa <_vfiprintf_r+0x13a>
2002597c:	9207      	str	r2, [sp, #28]
2002597e:	e014      	b.n	200259aa <_vfiprintf_r+0x13a>
20025980:	eba0 0308 	sub.w	r3, r0, r8
20025984:	46a2      	mov	sl, r4
20025986:	fa09 f303 	lsl.w	r3, r9, r3
2002598a:	4313      	orrs	r3, r2
2002598c:	9304      	str	r3, [sp, #16]
2002598e:	e7d2      	b.n	20025936 <_vfiprintf_r+0xc6>
20025990:	9b03      	ldr	r3, [sp, #12]
20025992:	1d19      	adds	r1, r3, #4
20025994:	681b      	ldr	r3, [r3, #0]
20025996:	2b00      	cmp	r3, #0
20025998:	9103      	str	r1, [sp, #12]
2002599a:	bfbb      	ittet	lt
2002599c:	425b      	neglt	r3, r3
2002599e:	f042 0202 	orrlt.w	r2, r2, #2
200259a2:	9307      	strge	r3, [sp, #28]
200259a4:	9307      	strlt	r3, [sp, #28]
200259a6:	bfb8      	it	lt
200259a8:	9204      	strlt	r2, [sp, #16]
200259aa:	7823      	ldrb	r3, [r4, #0]
200259ac:	2b2e      	cmp	r3, #46	@ 0x2e
200259ae:	d10a      	bne.n	200259c6 <_vfiprintf_r+0x156>
200259b0:	7863      	ldrb	r3, [r4, #1]
200259b2:	2b2a      	cmp	r3, #42	@ 0x2a
200259b4:	d132      	bne.n	20025a1c <_vfiprintf_r+0x1ac>
200259b6:	9b03      	ldr	r3, [sp, #12]
200259b8:	3402      	adds	r4, #2
200259ba:	1d1a      	adds	r2, r3, #4
200259bc:	681b      	ldr	r3, [r3, #0]
200259be:	ea43 73e3 	orr.w	r3, r3, r3, asr #31
200259c2:	9203      	str	r2, [sp, #12]
200259c4:	9305      	str	r3, [sp, #20]
200259c6:	f8df a0d4 	ldr.w	sl, [pc, #212]	@ 20025a9c <_vfiprintf_r+0x22c>
200259ca:	2203      	movs	r2, #3
200259cc:	7821      	ldrb	r1, [r4, #0]
200259ce:	4650      	mov	r0, sl
200259d0:	f7ff febf 	bl	20025752 <memchr>
200259d4:	b138      	cbz	r0, 200259e6 <_vfiprintf_r+0x176>
200259d6:	eba0 000a 	sub.w	r0, r0, sl
200259da:	2240      	movs	r2, #64	@ 0x40
200259dc:	9b04      	ldr	r3, [sp, #16]
200259de:	3401      	adds	r4, #1
200259e0:	4082      	lsls	r2, r0
200259e2:	4313      	orrs	r3, r2
200259e4:	9304      	str	r3, [sp, #16]
200259e6:	f814 1b01 	ldrb.w	r1, [r4], #1
200259ea:	2206      	movs	r2, #6
200259ec:	4828      	ldr	r0, [pc, #160]	@ (20025a90 <_vfiprintf_r+0x220>)
200259ee:	f88d 1028 	strb.w	r1, [sp, #40]	@ 0x28
200259f2:	f7ff feae 	bl	20025752 <memchr>
200259f6:	2800      	cmp	r0, #0
200259f8:	d03f      	beq.n	20025a7a <_vfiprintf_r+0x20a>
200259fa:	4b26      	ldr	r3, [pc, #152]	@ (20025a94 <_vfiprintf_r+0x224>)
200259fc:	bb1b      	cbnz	r3, 20025a46 <_vfiprintf_r+0x1d6>
200259fe:	9b03      	ldr	r3, [sp, #12]
20025a00:	3307      	adds	r3, #7
20025a02:	f023 0307 	bic.w	r3, r3, #7
20025a06:	3308      	adds	r3, #8
20025a08:	9303      	str	r3, [sp, #12]
20025a0a:	9b09      	ldr	r3, [sp, #36]	@ 0x24
20025a0c:	443b      	add	r3, r7
20025a0e:	9309      	str	r3, [sp, #36]	@ 0x24
20025a10:	e76a      	b.n	200258e8 <_vfiprintf_r+0x78>
20025a12:	fb0c 3202 	mla	r2, ip, r2, r3
20025a16:	460c      	mov	r4, r1
20025a18:	2001      	movs	r0, #1
20025a1a:	e7a8      	b.n	2002596e <_vfiprintf_r+0xfe>
20025a1c:	2300      	movs	r3, #0
20025a1e:	3401      	adds	r4, #1
20025a20:	f04f 0c0a 	mov.w	ip, #10
20025a24:	4619      	mov	r1, r3
20025a26:	9305      	str	r3, [sp, #20]
20025a28:	4620      	mov	r0, r4
20025a2a:	f810 2b01 	ldrb.w	r2, [r0], #1
20025a2e:	3a30      	subs	r2, #48	@ 0x30
20025a30:	2a09      	cmp	r2, #9
20025a32:	d903      	bls.n	20025a3c <_vfiprintf_r+0x1cc>
20025a34:	2b00      	cmp	r3, #0
20025a36:	d0c6      	beq.n	200259c6 <_vfiprintf_r+0x156>
20025a38:	9105      	str	r1, [sp, #20]
20025a3a:	e7c4      	b.n	200259c6 <_vfiprintf_r+0x156>
20025a3c:	fb0c 2101 	mla	r1, ip, r1, r2
20025a40:	4604      	mov	r4, r0
20025a42:	2301      	movs	r3, #1
20025a44:	e7f0      	b.n	20025a28 <_vfiprintf_r+0x1b8>
20025a46:	ab03      	add	r3, sp, #12
20025a48:	462a      	mov	r2, r5
20025a4a:	a904      	add	r1, sp, #16
20025a4c:	4630      	mov	r0, r6
20025a4e:	9300      	str	r3, [sp, #0]
20025a50:	4b11      	ldr	r3, [pc, #68]	@ (20025a98 <_vfiprintf_r+0x228>)
20025a52:	f3af 8000 	nop.w
20025a56:	4607      	mov	r7, r0
20025a58:	1c78      	adds	r0, r7, #1
20025a5a:	d1d6      	bne.n	20025a0a <_vfiprintf_r+0x19a>
20025a5c:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20025a5e:	07d9      	lsls	r1, r3, #31
20025a60:	d405      	bmi.n	20025a6e <_vfiprintf_r+0x1fe>
20025a62:	89ab      	ldrh	r3, [r5, #12]
20025a64:	059a      	lsls	r2, r3, #22
20025a66:	d402      	bmi.n	20025a6e <_vfiprintf_r+0x1fe>
20025a68:	6da8      	ldr	r0, [r5, #88]	@ 0x58
20025a6a:	f7ff fe71 	bl	20025750 <__retarget_lock_release_recursive>
20025a6e:	89ab      	ldrh	r3, [r5, #12]
20025a70:	065b      	lsls	r3, r3, #25
20025a72:	f53f af1f 	bmi.w	200258b4 <_vfiprintf_r+0x44>
20025a76:	9809      	ldr	r0, [sp, #36]	@ 0x24
20025a78:	e71e      	b.n	200258b8 <_vfiprintf_r+0x48>
20025a7a:	ab03      	add	r3, sp, #12
20025a7c:	462a      	mov	r2, r5
20025a7e:	a904      	add	r1, sp, #16
20025a80:	4630      	mov	r0, r6
20025a82:	9300      	str	r3, [sp, #0]
20025a84:	4b04      	ldr	r3, [pc, #16]	@ (20025a98 <_vfiprintf_r+0x228>)
20025a86:	f000 f87d 	bl	20025b84 <_printf_i>
20025a8a:	e7e4      	b.n	20025a56 <_vfiprintf_r+0x1e6>
20025a8c:	200263c3 	.word	0x200263c3
20025a90:	200263cd 	.word	0x200263cd
20025a94:	00000000 	.word	0x00000000
20025a98:	2002584b 	.word	0x2002584b
20025a9c:	200263c9 	.word	0x200263c9

20025aa0 <_printf_common>:
20025aa0:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20025aa4:	4616      	mov	r6, r2
20025aa6:	4698      	mov	r8, r3
20025aa8:	688a      	ldr	r2, [r1, #8]
20025aaa:	4607      	mov	r7, r0
20025aac:	690b      	ldr	r3, [r1, #16]
20025aae:	460c      	mov	r4, r1
20025ab0:	f8dd 9020 	ldr.w	r9, [sp, #32]
20025ab4:	4293      	cmp	r3, r2
20025ab6:	bfb8      	it	lt
20025ab8:	4613      	movlt	r3, r2
20025aba:	6033      	str	r3, [r6, #0]
20025abc:	f891 2043 	ldrb.w	r2, [r1, #67]	@ 0x43
20025ac0:	b10a      	cbz	r2, 20025ac6 <_printf_common+0x26>
20025ac2:	3301      	adds	r3, #1
20025ac4:	6033      	str	r3, [r6, #0]
20025ac6:	6823      	ldr	r3, [r4, #0]
20025ac8:	0699      	lsls	r1, r3, #26
20025aca:	bf42      	ittt	mi
20025acc:	6833      	ldrmi	r3, [r6, #0]
20025ace:	3302      	addmi	r3, #2
20025ad0:	6033      	strmi	r3, [r6, #0]
20025ad2:	6825      	ldr	r5, [r4, #0]
20025ad4:	f015 0506 	ands.w	r5, r5, #6
20025ad8:	d106      	bne.n	20025ae8 <_printf_common+0x48>
20025ada:	f104 0a19 	add.w	sl, r4, #25
20025ade:	68e3      	ldr	r3, [r4, #12]
20025ae0:	6832      	ldr	r2, [r6, #0]
20025ae2:	1a9b      	subs	r3, r3, r2
20025ae4:	42ab      	cmp	r3, r5
20025ae6:	dc2b      	bgt.n	20025b40 <_printf_common+0xa0>
20025ae8:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
20025aec:	6822      	ldr	r2, [r4, #0]
20025aee:	3b00      	subs	r3, #0
20025af0:	bf18      	it	ne
20025af2:	2301      	movne	r3, #1
20025af4:	0692      	lsls	r2, r2, #26
20025af6:	d430      	bmi.n	20025b5a <_printf_common+0xba>
20025af8:	f104 0243 	add.w	r2, r4, #67	@ 0x43
20025afc:	4641      	mov	r1, r8
20025afe:	4638      	mov	r0, r7
20025b00:	47c8      	blx	r9
20025b02:	3001      	adds	r0, #1
20025b04:	d023      	beq.n	20025b4e <_printf_common+0xae>
20025b06:	6823      	ldr	r3, [r4, #0]
20025b08:	341a      	adds	r4, #26
20025b0a:	f854 2c0a 	ldr.w	r2, [r4, #-10]
20025b0e:	f003 0306 	and.w	r3, r3, #6
20025b12:	2b04      	cmp	r3, #4
20025b14:	bf0a      	itet	eq
20025b16:	f854 5c0e 	ldreq.w	r5, [r4, #-14]
20025b1a:	2500      	movne	r5, #0
20025b1c:	6833      	ldreq	r3, [r6, #0]
20025b1e:	f04f 0600 	mov.w	r6, #0
20025b22:	bf08      	it	eq
20025b24:	1aed      	subeq	r5, r5, r3
20025b26:	f854 3c12 	ldr.w	r3, [r4, #-18]
20025b2a:	bf08      	it	eq
20025b2c:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
20025b30:	4293      	cmp	r3, r2
20025b32:	bfc4      	itt	gt
20025b34:	1a9b      	subgt	r3, r3, r2
20025b36:	18ed      	addgt	r5, r5, r3
20025b38:	42b5      	cmp	r5, r6
20025b3a:	d11a      	bne.n	20025b72 <_printf_common+0xd2>
20025b3c:	2000      	movs	r0, #0
20025b3e:	e008      	b.n	20025b52 <_printf_common+0xb2>
20025b40:	2301      	movs	r3, #1
20025b42:	4652      	mov	r2, sl
20025b44:	4641      	mov	r1, r8
20025b46:	4638      	mov	r0, r7
20025b48:	47c8      	blx	r9
20025b4a:	3001      	adds	r0, #1
20025b4c:	d103      	bne.n	20025b56 <_printf_common+0xb6>
20025b4e:	f04f 30ff 	mov.w	r0, #4294967295
20025b52:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20025b56:	3501      	adds	r5, #1
20025b58:	e7c1      	b.n	20025ade <_printf_common+0x3e>
20025b5a:	18e1      	adds	r1, r4, r3
20025b5c:	1c5a      	adds	r2, r3, #1
20025b5e:	2030      	movs	r0, #48	@ 0x30
20025b60:	3302      	adds	r3, #2
20025b62:	4422      	add	r2, r4
20025b64:	f881 0043 	strb.w	r0, [r1, #67]	@ 0x43
20025b68:	f894 1045 	ldrb.w	r1, [r4, #69]	@ 0x45
20025b6c:	f882 1043 	strb.w	r1, [r2, #67]	@ 0x43
20025b70:	e7c2      	b.n	20025af8 <_printf_common+0x58>
20025b72:	2301      	movs	r3, #1
20025b74:	4622      	mov	r2, r4
20025b76:	4641      	mov	r1, r8
20025b78:	4638      	mov	r0, r7
20025b7a:	47c8      	blx	r9
20025b7c:	3001      	adds	r0, #1
20025b7e:	d0e6      	beq.n	20025b4e <_printf_common+0xae>
20025b80:	3601      	adds	r6, #1
20025b82:	e7d9      	b.n	20025b38 <_printf_common+0x98>

20025b84 <_printf_i>:
20025b84:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
20025b88:	7e0f      	ldrb	r7, [r1, #24]
20025b8a:	4691      	mov	r9, r2
20025b8c:	4680      	mov	r8, r0
20025b8e:	460c      	mov	r4, r1
20025b90:	2f78      	cmp	r7, #120	@ 0x78
20025b92:	469a      	mov	sl, r3
20025b94:	9e0c      	ldr	r6, [sp, #48]	@ 0x30
20025b96:	f101 0243 	add.w	r2, r1, #67	@ 0x43
20025b9a:	d807      	bhi.n	20025bac <_printf_i+0x28>
20025b9c:	2f62      	cmp	r7, #98	@ 0x62
20025b9e:	d80a      	bhi.n	20025bb6 <_printf_i+0x32>
20025ba0:	2f00      	cmp	r7, #0
20025ba2:	f000 80d2 	beq.w	20025d4a <_printf_i+0x1c6>
20025ba6:	2f58      	cmp	r7, #88	@ 0x58
20025ba8:	f000 80b7 	beq.w	20025d1a <_printf_i+0x196>
20025bac:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20025bb0:	f884 7042 	strb.w	r7, [r4, #66]	@ 0x42
20025bb4:	e03a      	b.n	20025c2c <_printf_i+0xa8>
20025bb6:	f1a7 0363 	sub.w	r3, r7, #99	@ 0x63
20025bba:	2b15      	cmp	r3, #21
20025bbc:	d8f6      	bhi.n	20025bac <_printf_i+0x28>
20025bbe:	a101      	add	r1, pc, #4	@ (adr r1, 20025bc4 <_printf_i+0x40>)
20025bc0:	f851 f023 	ldr.w	pc, [r1, r3, lsl #2]
20025bc4:	20025c1d 	.word	0x20025c1d
20025bc8:	20025c31 	.word	0x20025c31
20025bcc:	20025bad 	.word	0x20025bad
20025bd0:	20025bad 	.word	0x20025bad
20025bd4:	20025bad 	.word	0x20025bad
20025bd8:	20025bad 	.word	0x20025bad
20025bdc:	20025c31 	.word	0x20025c31
20025be0:	20025bad 	.word	0x20025bad
20025be4:	20025bad 	.word	0x20025bad
20025be8:	20025bad 	.word	0x20025bad
20025bec:	20025bad 	.word	0x20025bad
20025bf0:	20025d31 	.word	0x20025d31
20025bf4:	20025c5b 	.word	0x20025c5b
20025bf8:	20025ce7 	.word	0x20025ce7
20025bfc:	20025bad 	.word	0x20025bad
20025c00:	20025bad 	.word	0x20025bad
20025c04:	20025d53 	.word	0x20025d53
20025c08:	20025bad 	.word	0x20025bad
20025c0c:	20025c5b 	.word	0x20025c5b
20025c10:	20025bad 	.word	0x20025bad
20025c14:	20025bad 	.word	0x20025bad
20025c18:	20025cef 	.word	0x20025cef
20025c1c:	6833      	ldr	r3, [r6, #0]
20025c1e:	1d1a      	adds	r2, r3, #4
20025c20:	681b      	ldr	r3, [r3, #0]
20025c22:	6032      	str	r2, [r6, #0]
20025c24:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20025c28:	f884 3042 	strb.w	r3, [r4, #66]	@ 0x42
20025c2c:	2301      	movs	r3, #1
20025c2e:	e09d      	b.n	20025d6c <_printf_i+0x1e8>
20025c30:	6833      	ldr	r3, [r6, #0]
20025c32:	6820      	ldr	r0, [r4, #0]
20025c34:	1d19      	adds	r1, r3, #4
20025c36:	6031      	str	r1, [r6, #0]
20025c38:	0606      	lsls	r6, r0, #24
20025c3a:	d501      	bpl.n	20025c40 <_printf_i+0xbc>
20025c3c:	681d      	ldr	r5, [r3, #0]
20025c3e:	e003      	b.n	20025c48 <_printf_i+0xc4>
20025c40:	0645      	lsls	r5, r0, #25
20025c42:	d5fb      	bpl.n	20025c3c <_printf_i+0xb8>
20025c44:	f9b3 5000 	ldrsh.w	r5, [r3]
20025c48:	2d00      	cmp	r5, #0
20025c4a:	da03      	bge.n	20025c54 <_printf_i+0xd0>
20025c4c:	232d      	movs	r3, #45	@ 0x2d
20025c4e:	426d      	negs	r5, r5
20025c50:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20025c54:	4859      	ldr	r0, [pc, #356]	@ (20025dbc <_printf_i+0x238>)
20025c56:	230a      	movs	r3, #10
20025c58:	e010      	b.n	20025c7c <_printf_i+0xf8>
20025c5a:	6821      	ldr	r1, [r4, #0]
20025c5c:	6833      	ldr	r3, [r6, #0]
20025c5e:	0608      	lsls	r0, r1, #24
20025c60:	f853 5b04 	ldr.w	r5, [r3], #4
20025c64:	d402      	bmi.n	20025c6c <_printf_i+0xe8>
20025c66:	0649      	lsls	r1, r1, #25
20025c68:	bf48      	it	mi
20025c6a:	b2ad      	uxthmi	r5, r5
20025c6c:	2f6f      	cmp	r7, #111	@ 0x6f
20025c6e:	4853      	ldr	r0, [pc, #332]	@ (20025dbc <_printf_i+0x238>)
20025c70:	6033      	str	r3, [r6, #0]
20025c72:	d159      	bne.n	20025d28 <_printf_i+0x1a4>
20025c74:	2308      	movs	r3, #8
20025c76:	2100      	movs	r1, #0
20025c78:	f884 1043 	strb.w	r1, [r4, #67]	@ 0x43
20025c7c:	6866      	ldr	r6, [r4, #4]
20025c7e:	2e00      	cmp	r6, #0
20025c80:	60a6      	str	r6, [r4, #8]
20025c82:	db05      	blt.n	20025c90 <_printf_i+0x10c>
20025c84:	6821      	ldr	r1, [r4, #0]
20025c86:	432e      	orrs	r6, r5
20025c88:	f021 0104 	bic.w	r1, r1, #4
20025c8c:	6021      	str	r1, [r4, #0]
20025c8e:	d04d      	beq.n	20025d2c <_printf_i+0x1a8>
20025c90:	4616      	mov	r6, r2
20025c92:	fbb5 f1f3 	udiv	r1, r5, r3
20025c96:	fb03 5711 	mls	r7, r3, r1, r5
20025c9a:	5dc7      	ldrb	r7, [r0, r7]
20025c9c:	f806 7d01 	strb.w	r7, [r6, #-1]!
20025ca0:	462f      	mov	r7, r5
20025ca2:	460d      	mov	r5, r1
20025ca4:	42bb      	cmp	r3, r7
20025ca6:	d9f4      	bls.n	20025c92 <_printf_i+0x10e>
20025ca8:	2b08      	cmp	r3, #8
20025caa:	d10b      	bne.n	20025cc4 <_printf_i+0x140>
20025cac:	6823      	ldr	r3, [r4, #0]
20025cae:	07df      	lsls	r7, r3, #31
20025cb0:	d508      	bpl.n	20025cc4 <_printf_i+0x140>
20025cb2:	6923      	ldr	r3, [r4, #16]
20025cb4:	6861      	ldr	r1, [r4, #4]
20025cb6:	4299      	cmp	r1, r3
20025cb8:	bfde      	ittt	le
20025cba:	2330      	movle	r3, #48	@ 0x30
20025cbc:	f806 3c01 	strble.w	r3, [r6, #-1]
20025cc0:	f106 36ff 	addle.w	r6, r6, #4294967295
20025cc4:	1b92      	subs	r2, r2, r6
20025cc6:	6122      	str	r2, [r4, #16]
20025cc8:	464b      	mov	r3, r9
20025cca:	aa03      	add	r2, sp, #12
20025ccc:	4621      	mov	r1, r4
20025cce:	4640      	mov	r0, r8
20025cd0:	f8cd a000 	str.w	sl, [sp]
20025cd4:	f7ff fee4 	bl	20025aa0 <_printf_common>
20025cd8:	3001      	adds	r0, #1
20025cda:	d14c      	bne.n	20025d76 <_printf_i+0x1f2>
20025cdc:	f04f 30ff 	mov.w	r0, #4294967295
20025ce0:	b004      	add	sp, #16
20025ce2:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20025ce6:	6823      	ldr	r3, [r4, #0]
20025ce8:	f043 0320 	orr.w	r3, r3, #32
20025cec:	6023      	str	r3, [r4, #0]
20025cee:	2778      	movs	r7, #120	@ 0x78
20025cf0:	4833      	ldr	r0, [pc, #204]	@ (20025dc0 <_printf_i+0x23c>)
20025cf2:	6823      	ldr	r3, [r4, #0]
20025cf4:	f884 7045 	strb.w	r7, [r4, #69]	@ 0x45
20025cf8:	061f      	lsls	r7, r3, #24
20025cfa:	6831      	ldr	r1, [r6, #0]
20025cfc:	f851 5b04 	ldr.w	r5, [r1], #4
20025d00:	d402      	bmi.n	20025d08 <_printf_i+0x184>
20025d02:	065f      	lsls	r7, r3, #25
20025d04:	bf48      	it	mi
20025d06:	b2ad      	uxthmi	r5, r5
20025d08:	6031      	str	r1, [r6, #0]
20025d0a:	07d9      	lsls	r1, r3, #31
20025d0c:	bf44      	itt	mi
20025d0e:	f043 0320 	orrmi.w	r3, r3, #32
20025d12:	6023      	strmi	r3, [r4, #0]
20025d14:	b11d      	cbz	r5, 20025d1e <_printf_i+0x19a>
20025d16:	2310      	movs	r3, #16
20025d18:	e7ad      	b.n	20025c76 <_printf_i+0xf2>
20025d1a:	4828      	ldr	r0, [pc, #160]	@ (20025dbc <_printf_i+0x238>)
20025d1c:	e7e9      	b.n	20025cf2 <_printf_i+0x16e>
20025d1e:	6823      	ldr	r3, [r4, #0]
20025d20:	f023 0320 	bic.w	r3, r3, #32
20025d24:	6023      	str	r3, [r4, #0]
20025d26:	e7f6      	b.n	20025d16 <_printf_i+0x192>
20025d28:	230a      	movs	r3, #10
20025d2a:	e7a4      	b.n	20025c76 <_printf_i+0xf2>
20025d2c:	4616      	mov	r6, r2
20025d2e:	e7bb      	b.n	20025ca8 <_printf_i+0x124>
20025d30:	6833      	ldr	r3, [r6, #0]
20025d32:	6825      	ldr	r5, [r4, #0]
20025d34:	1d18      	adds	r0, r3, #4
20025d36:	6961      	ldr	r1, [r4, #20]
20025d38:	6030      	str	r0, [r6, #0]
20025d3a:	062e      	lsls	r6, r5, #24
20025d3c:	681b      	ldr	r3, [r3, #0]
20025d3e:	d501      	bpl.n	20025d44 <_printf_i+0x1c0>
20025d40:	6019      	str	r1, [r3, #0]
20025d42:	e002      	b.n	20025d4a <_printf_i+0x1c6>
20025d44:	0668      	lsls	r0, r5, #25
20025d46:	d5fb      	bpl.n	20025d40 <_printf_i+0x1bc>
20025d48:	8019      	strh	r1, [r3, #0]
20025d4a:	2300      	movs	r3, #0
20025d4c:	4616      	mov	r6, r2
20025d4e:	6123      	str	r3, [r4, #16]
20025d50:	e7ba      	b.n	20025cc8 <_printf_i+0x144>
20025d52:	6833      	ldr	r3, [r6, #0]
20025d54:	2100      	movs	r1, #0
20025d56:	1d1a      	adds	r2, r3, #4
20025d58:	6032      	str	r2, [r6, #0]
20025d5a:	681e      	ldr	r6, [r3, #0]
20025d5c:	6862      	ldr	r2, [r4, #4]
20025d5e:	4630      	mov	r0, r6
20025d60:	f7ff fcf7 	bl	20025752 <memchr>
20025d64:	b108      	cbz	r0, 20025d6a <_printf_i+0x1e6>
20025d66:	1b80      	subs	r0, r0, r6
20025d68:	6060      	str	r0, [r4, #4]
20025d6a:	6863      	ldr	r3, [r4, #4]
20025d6c:	6123      	str	r3, [r4, #16]
20025d6e:	2300      	movs	r3, #0
20025d70:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20025d74:	e7a8      	b.n	20025cc8 <_printf_i+0x144>
20025d76:	6923      	ldr	r3, [r4, #16]
20025d78:	4632      	mov	r2, r6
20025d7a:	4649      	mov	r1, r9
20025d7c:	4640      	mov	r0, r8
20025d7e:	47d0      	blx	sl
20025d80:	3001      	adds	r0, #1
20025d82:	d0ab      	beq.n	20025cdc <_printf_i+0x158>
20025d84:	6823      	ldr	r3, [r4, #0]
20025d86:	079b      	lsls	r3, r3, #30
20025d88:	d413      	bmi.n	20025db2 <_printf_i+0x22e>
20025d8a:	68e0      	ldr	r0, [r4, #12]
20025d8c:	9b03      	ldr	r3, [sp, #12]
20025d8e:	4298      	cmp	r0, r3
20025d90:	bfb8      	it	lt
20025d92:	4618      	movlt	r0, r3
20025d94:	e7a4      	b.n	20025ce0 <_printf_i+0x15c>
20025d96:	2301      	movs	r3, #1
20025d98:	4632      	mov	r2, r6
20025d9a:	4649      	mov	r1, r9
20025d9c:	4640      	mov	r0, r8
20025d9e:	47d0      	blx	sl
20025da0:	3001      	adds	r0, #1
20025da2:	d09b      	beq.n	20025cdc <_printf_i+0x158>
20025da4:	3501      	adds	r5, #1
20025da6:	68e3      	ldr	r3, [r4, #12]
20025da8:	9903      	ldr	r1, [sp, #12]
20025daa:	1a5b      	subs	r3, r3, r1
20025dac:	42ab      	cmp	r3, r5
20025dae:	dcf2      	bgt.n	20025d96 <_printf_i+0x212>
20025db0:	e7eb      	b.n	20025d8a <_printf_i+0x206>
20025db2:	2500      	movs	r5, #0
20025db4:	f104 0619 	add.w	r6, r4, #25
20025db8:	e7f5      	b.n	20025da6 <_printf_i+0x222>
20025dba:	bf00      	nop
20025dbc:	200263d4 	.word	0x200263d4
20025dc0:	200263e5 	.word	0x200263e5

20025dc4 <__swhatbuf_r>:
20025dc4:	b570      	push	{r4, r5, r6, lr}
20025dc6:	460c      	mov	r4, r1
20025dc8:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20025dcc:	b096      	sub	sp, #88	@ 0x58
20025dce:	4615      	mov	r5, r2
20025dd0:	2900      	cmp	r1, #0
20025dd2:	461e      	mov	r6, r3
20025dd4:	da0a      	bge.n	20025dec <__swhatbuf_r+0x28>
20025dd6:	89a1      	ldrh	r1, [r4, #12]
20025dd8:	f011 0180 	ands.w	r1, r1, #128	@ 0x80
20025ddc:	d113      	bne.n	20025e06 <__swhatbuf_r+0x42>
20025dde:	f44f 6280 	mov.w	r2, #1024	@ 0x400
20025de2:	2000      	movs	r0, #0
20025de4:	6031      	str	r1, [r6, #0]
20025de6:	602a      	str	r2, [r5, #0]
20025de8:	b016      	add	sp, #88	@ 0x58
20025dea:	bd70      	pop	{r4, r5, r6, pc}
20025dec:	466a      	mov	r2, sp
20025dee:	f000 f847 	bl	20025e80 <_fstat_r>
20025df2:	2800      	cmp	r0, #0
20025df4:	dbef      	blt.n	20025dd6 <__swhatbuf_r+0x12>
20025df6:	9901      	ldr	r1, [sp, #4]
20025df8:	f401 4170 	and.w	r1, r1, #61440	@ 0xf000
20025dfc:	f5a1 5300 	sub.w	r3, r1, #8192	@ 0x2000
20025e00:	4259      	negs	r1, r3
20025e02:	4159      	adcs	r1, r3
20025e04:	e7eb      	b.n	20025dde <__swhatbuf_r+0x1a>
20025e06:	2100      	movs	r1, #0
20025e08:	2240      	movs	r2, #64	@ 0x40
20025e0a:	e7ea      	b.n	20025de2 <__swhatbuf_r+0x1e>

20025e0c <__smakebuf_r>:
20025e0c:	898b      	ldrh	r3, [r1, #12]
20025e0e:	b573      	push	{r0, r1, r4, r5, r6, lr}
20025e10:	079e      	lsls	r6, r3, #30
20025e12:	4605      	mov	r5, r0
20025e14:	460c      	mov	r4, r1
20025e16:	d507      	bpl.n	20025e28 <__smakebuf_r+0x1c>
20025e18:	f104 0347 	add.w	r3, r4, #71	@ 0x47
20025e1c:	6023      	str	r3, [r4, #0]
20025e1e:	6123      	str	r3, [r4, #16]
20025e20:	2301      	movs	r3, #1
20025e22:	6163      	str	r3, [r4, #20]
20025e24:	b002      	add	sp, #8
20025e26:	bd70      	pop	{r4, r5, r6, pc}
20025e28:	ab01      	add	r3, sp, #4
20025e2a:	466a      	mov	r2, sp
20025e2c:	f7ff ffca 	bl	20025dc4 <__swhatbuf_r>
20025e30:	9e00      	ldr	r6, [sp, #0]
20025e32:	4628      	mov	r0, r5
20025e34:	4631      	mov	r1, r6
20025e36:	f7ff f8dd 	bl	20024ff4 <_malloc_r>
20025e3a:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025e3e:	b938      	cbnz	r0, 20025e50 <__smakebuf_r+0x44>
20025e40:	059a      	lsls	r2, r3, #22
20025e42:	d4ef      	bmi.n	20025e24 <__smakebuf_r+0x18>
20025e44:	f023 0303 	bic.w	r3, r3, #3
20025e48:	f043 0302 	orr.w	r3, r3, #2
20025e4c:	81a3      	strh	r3, [r4, #12]
20025e4e:	e7e3      	b.n	20025e18 <__smakebuf_r+0xc>
20025e50:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025e54:	6020      	str	r0, [r4, #0]
20025e56:	81a3      	strh	r3, [r4, #12]
20025e58:	9b01      	ldr	r3, [sp, #4]
20025e5a:	e9c4 0604 	strd	r0, r6, [r4, #16]
20025e5e:	2b00      	cmp	r3, #0
20025e60:	d0e0      	beq.n	20025e24 <__smakebuf_r+0x18>
20025e62:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20025e66:	4628      	mov	r0, r5
20025e68:	f000 f81c 	bl	20025ea4 <_isatty_r>
20025e6c:	2800      	cmp	r0, #0
20025e6e:	d0d9      	beq.n	20025e24 <__smakebuf_r+0x18>
20025e70:	89a3      	ldrh	r3, [r4, #12]
20025e72:	f023 0303 	bic.w	r3, r3, #3
20025e76:	f043 0301 	orr.w	r3, r3, #1
20025e7a:	81a3      	strh	r3, [r4, #12]
20025e7c:	e7d2      	b.n	20025e24 <__smakebuf_r+0x18>
	...

20025e80 <_fstat_r>:
20025e80:	b538      	push	{r3, r4, r5, lr}
20025e82:	2300      	movs	r3, #0
20025e84:	4d06      	ldr	r5, [pc, #24]	@ (20025ea0 <_fstat_r+0x20>)
20025e86:	4604      	mov	r4, r0
20025e88:	4608      	mov	r0, r1
20025e8a:	4611      	mov	r1, r2
20025e8c:	602b      	str	r3, [r5, #0]
20025e8e:	f7fb fbfb 	bl	20021688 <_fstat>
20025e92:	1c43      	adds	r3, r0, #1
20025e94:	d102      	bne.n	20025e9c <_fstat_r+0x1c>
20025e96:	682b      	ldr	r3, [r5, #0]
20025e98:	b103      	cbz	r3, 20025e9c <_fstat_r+0x1c>
20025e9a:	6023      	str	r3, [r4, #0]
20025e9c:	bd38      	pop	{r3, r4, r5, pc}
20025e9e:	bf00      	nop
20025ea0:	2004d1cc 	.word	0x2004d1cc

20025ea4 <_isatty_r>:
20025ea4:	b538      	push	{r3, r4, r5, lr}
20025ea6:	2300      	movs	r3, #0
20025ea8:	4d05      	ldr	r5, [pc, #20]	@ (20025ec0 <_isatty_r+0x1c>)
20025eaa:	4604      	mov	r4, r0
20025eac:	4608      	mov	r0, r1
20025eae:	602b      	str	r3, [r5, #0]
20025eb0:	f7fb fbec 	bl	2002168c <_isatty>
20025eb4:	1c43      	adds	r3, r0, #1
20025eb6:	d102      	bne.n	20025ebe <_isatty_r+0x1a>
20025eb8:	682b      	ldr	r3, [r5, #0]
20025eba:	b103      	cbz	r3, 20025ebe <_isatty_r+0x1a>
20025ebc:	6023      	str	r3, [r4, #0]
20025ebe:	bd38      	pop	{r3, r4, r5, pc}
20025ec0:	2004d1cc 	.word	0x2004d1cc

20025ec4 <_sbrk>:
20025ec4:	4a05      	ldr	r2, [pc, #20]	@ (20025edc <_sbrk+0x18>)
20025ec6:	4603      	mov	r3, r0
20025ec8:	6810      	ldr	r0, [r2, #0]
20025eca:	b110      	cbz	r0, 20025ed2 <_sbrk+0xe>
20025ecc:	4403      	add	r3, r0
20025ece:	6013      	str	r3, [r2, #0]
20025ed0:	4770      	bx	lr
20025ed2:	4803      	ldr	r0, [pc, #12]	@ (20025ee0 <_sbrk+0x1c>)
20025ed4:	4403      	add	r3, r0
20025ed6:	6013      	str	r3, [r2, #0]
20025ed8:	4770      	bx	lr
20025eda:	bf00      	nop
20025edc:	2004d1d4 	.word	0x2004d1d4
20025ee0:	20042000 	.word	0x20042000
20025ee4:	61766e69 	.word	0x61766e69
20025ee8:	2064696c 	.word	0x2064696c
20025eec:	746f6f62 	.word	0x746f6f62
20025ef0:	76656420 	.word	0x76656420
20025ef4:	00656369 	.word	0x00656369
20025ef8:	693a4c42 	.word	0x693a4c42
20025efc:	6c61766e 	.word	0x6c61766e
20025f00:	66206469 	.word	0x66206469
20025f04:	20626174 	.word	0x20626174
20025f08:	6967616d 	.word	0x6967616d
20025f0c:	72662063 	.word	0x72662063
20025f10:	64206d6f 	.word	0x64206d6f
20025f14:	63697665 	.word	0x63697665
20025f18:	64253a65 	.word	0x64253a65
20025f1c:	4c42000a 	.word	0x4c42000a
20025f20:	6f6f623a 	.word	0x6f6f623a
20025f24:	65642074 	.word	0x65642074
20025f28:	65636976 	.word	0x65636976
20025f2c:	696e6920 	.word	0x696e6920
20025f30:	61662074 	.word	0x61662074
20025f34:	66206c69 	.word	0x66206c69
20025f38:	3a6d6f72 	.word	0x3a6d6f72
20025f3c:	000a6425 	.word	0x000a6425
20025f40:	64616f6c 	.word	0x64616f6c
20025f44:	6e616220 	.word	0x6e616220
20025f48:	6620306b 	.word	0x6620306b
20025f4c:	736c6961 	.word	0x736c6961
20025f50:	616d6900 	.word	0x616d6900
20025f54:	73206567 	.word	0x73206567
20025f58:	616e6769 	.word	0x616e6769
20025f5c:	65727574 	.word	0x65727574
20025f60:	72657620 	.word	0x72657620
20025f64:	63696669 	.word	0x63696669
20025f68:	6f697461 	.word	0x6f697461
20025f6c:	6166206e 	.word	0x6166206e
20025f70:	00736c69 	.word	0x00736c69
20025f74:	2070614d 	.word	0x2070614d
20025f78:	6f727265 	.word	0x6f727265
20025f7c:	6c203a72 	.word	0x6c203a72
20025f80:	6369676f 	.word	0x6369676f
20025f84:	2c642520 	.word	0x2c642520
20025f88:	79687020 	.word	0x79687020
20025f8c:	0a642520 	.word	0x0a642520
20025f90:	52524500 	.word	0x52524500
20025f94:	2032203a 	.word	0x2032203a
20025f98:	69676f6c 	.word	0x69676f6c
20025f9c:	6c622063 	.word	0x6c622063
20025fa0:	736b636f 	.word	0x736b636f
20025fa4:	70616d20 	.word	0x70616d20
20025fa8:	206f7420 	.word	0x206f7420
20025fac:	656d6173 	.word	0x656d6173
20025fb0:	6b6c6220 	.word	0x6b6c6220
20025fb4:	6f6c203a 	.word	0x6f6c203a
20025fb8:	30636967 	.word	0x30636967
20025fbc:	2c642520 	.word	0x2c642520
20025fc0:	79687020 	.word	0x79687020
20025fc4:	64252030 	.word	0x64252030
20025fc8:	6f6c202c 	.word	0x6f6c202c
20025fcc:	31636967 	.word	0x31636967
20025fd0:	2c642520 	.word	0x2c642520
20025fd4:	79687020 	.word	0x79687020
20025fd8:	64252031 	.word	0x64252031
20025fdc:	614d000a 	.word	0x614d000a
20025fe0:	72652070 	.word	0x72652070
20025fe4:	30726f72 	.word	0x30726f72
20025fe8:	6f6c203a 	.word	0x6f6c203a
20025fec:	20636967 	.word	0x20636967
20025ff0:	202c6425 	.word	0x202c6425
20025ff4:	20796870 	.word	0x20796870
20025ff8:	000a6425 	.word	0x000a6425
20025ffc:	20746547 	.word	0x20746547
20026000:	2070616d 	.word	0x2070616d
20026004:	636f6c62 	.word	0x636f6c62
20026008:	7265206b 	.word	0x7265206b
2002600c:	20726f72 	.word	0x20726f72
20026010:	2d206425 	.word	0x2d206425
20026014:	25203e2d 	.word	0x25203e2d
20026018:	42000a64 	.word	0x42000a64
2002601c:	76204d42 	.word	0x76204d42
20026020:	69737265 	.word	0x69737265
20026024:	6e206e6f 	.word	0x6e206e6f
20026028:	6920746f 	.word	0x6920746f
2002602c:	6572636e 	.word	0x6572636e
20026030:	64657361 	.word	0x64657361
20026034:	7270203a 	.word	0x7270203a
20026038:	25207665 	.word	0x25207665
2002603c:	63202c64 	.word	0x63202c64
20026040:	20727275 	.word	0x20727275
20026044:	000a6425 	.word	0x000a6425
20026048:	41544144 	.word	0x41544144
2002604c:	746f6e20 	.word	0x746f6e20
20026050:	61657220 	.word	0x61657220
20026054:	616e6f73 	.word	0x616e6f73
20026058:	20656c62 	.word	0x20656c62
2002605c:	42206e69 	.word	0x42206e69
20026060:	62204d42 	.word	0x62204d42
20026064:	25206b6c 	.word	0x25206b6c
20026068:	61702064 	.word	0x61702064
2002606c:	25206567 	.word	0x25206567
20026070:	30203a64 	.word	0x30203a64
20026074:	0a782578 	.word	0x0a782578
20026078:	61655200 	.word	0x61655200
2002607c:	62622064 	.word	0x62622064
20026080:	6c62206d 	.word	0x6c62206d
20026084:	6425206b 	.word	0x6425206b
20026088:	67617020 	.word	0x67617020
2002608c:	64252065 	.word	0x64252065
20026090:	69616620 	.word	0x69616620
20026094:	49000a6c 	.word	0x49000a6c
20026098:	6c61766e 	.word	0x6c61766e
2002609c:	42206469 	.word	0x42206469
200260a0:	49204d42 	.word	0x49204d42
200260a4:	25205844 	.word	0x25205844
200260a8:	56000a64 	.word	0x56000a64
200260ac:	64252031 	.word	0x64252031
200260b0:	206e6920 	.word	0x206e6920
200260b4:	636f6c62 	.word	0x636f6c62
200260b8:	6425206b 	.word	0x6425206b
200260bc:	3256202c 	.word	0x3256202c
200260c0:	20642520 	.word	0x20642520
200260c4:	62206e69 	.word	0x62206e69
200260c8:	6b636f6c 	.word	0x6b636f6c
200260cc:	0a642520 	.word	0x0a642520
200260d0:	6d615300 	.word	0x6d615300
200260d4:	69687465 	.word	0x69687465
200260d8:	6d20676e 	.word	0x6d20676e
200260dc:	20747375 	.word	0x20747375
200260e0:	77206562 	.word	0x77206562
200260e4:	676e6f72 	.word	0x676e6f72
200260e8:	6567202c 	.word	0x6567202c
200260ec:	656e2074 	.word	0x656e2074
200260f0:	65762077 	.word	0x65762077
200260f4:	6f697372 	.word	0x6f697372
200260f8:	6425206e 	.word	0x6425206e
200260fc:	206f6420 	.word	0x206f6420
20026100:	20746f6e 	.word	0x20746f6e
20026104:	656d6173 	.word	0x656d6173
20026108:	206f7420 	.word	0x206f7420
2002610c:	76657270 	.word	0x76657270
20026110:	65686320 	.word	0x65686320
20026114:	25206b63 	.word	0x25206b63
20026118:	43000a64 	.word	0x43000a64
2002611c:	63204352 	.word	0x63204352
20026120:	6b636568 	.word	0x6b636568
20026124:	72726520 	.word	0x72726520
20026128:	0a20726f 	.word	0x0a20726f
2002612c:	61655200 	.word	0x61655200
20026130:	62622064 	.word	0x62622064
20026134:	6c62206d 	.word	0x6c62206d
20026138:	6425206b 	.word	0x6425206b
2002613c:	67617020 	.word	0x67617020
20026140:	64252065 	.word	0x64252065
20026144:	74616420 	.word	0x74616420
20026148:	6f6e2061 	.word	0x6f6e2061
2002614c:	72772074 	.word	0x72772074
20026150:	20657469 	.word	0x20657469
20026154:	20726f66 	.word	0x20726f66
20026158:	20646e32 	.word	0x20646e32
2002615c:	656d6974 	.word	0x656d6974
20026160:	6552000a 	.word	0x6552000a
20026164:	62206461 	.word	0x62206461
20026168:	62206d62 	.word	0x62206d62
2002616c:	25206b6c 	.word	0x25206b6c
20026170:	61702064 	.word	0x61702064
20026174:	25206567 	.word	0x25206567
20026178:	61662064 	.word	0x61662064
2002617c:	66206c69 	.word	0x66206c69
20026180:	3220726f 	.word	0x3220726f
20026184:	7420646e 	.word	0x7420646e
20026188:	3f656d69 	.word	0x3f656d69
2002618c:	614c000a 	.word	0x614c000a
20026190:	74736574 	.word	0x74736574
20026194:	72657620 	.word	0x72657620
20026198:	6e6f6973 	.word	0x6e6f6973
2002619c:	0a642520 	.word	0x0a642520
200261a0:	74654700 	.word	0x74654700
200261a4:	79687020 	.word	0x79687020
200261a8:	6b6c6220 	.word	0x6b6c6220
200261ac:	726f6620 	.word	0x726f6620
200261b0:	20642520 	.word	0x20642520
200261b4:	6c696166 	.word	0x6c696166
200261b8:	65687720 	.word	0x65687720
200261bc:	6572206e 	.word	0x6572206e
200261c0:	000a6461 	.word	0x000a6461
200261c4:	636f6c42 	.word	0x636f6c42
200261c8:	6425206b 	.word	0x6425206b
200261cc:	61726520 	.word	0x61726520
200261d0:	66206573 	.word	0x66206573
200261d4:	2c6c6961 	.word	0x2c6c6961
200261d8:	72616d20 	.word	0x72616d20
200261dc:	7361206b 	.word	0x7361206b
200261e0:	64616220 	.word	0x64616220
200261e4:	6c42000a 	.word	0x6c42000a
200261e8:	206b636f 	.word	0x206b636f
200261ec:	63206425 	.word	0x63206425
200261f0:	6b636568 	.word	0x6b636568
200261f4:	20736120 	.word	0x20736120
200261f8:	20646162 	.word	0x20646162
200261fc:	636f6c62 	.word	0x636f6c62
20026200:	42000a6b 	.word	0x42000a6b
20026204:	6b636f6c 	.word	0x6b636f6c
20026208:	20642520 	.word	0x20642520
2002620c:	62207369 	.word	0x62207369
20026210:	69206461 	.word	0x69206461
20026214:	7375206e 	.word	0x7375206e
20026218:	62207265 	.word	0x62207265
2002621c:	6b636f6c 	.word	0x6b636f6c
20026220:	6162000a 	.word	0x6162000a
20026224:	64252064 	.word	0x64252064
20026228:	6572202c 	.word	0x6572202c
2002622c:	63616c70 	.word	0x63616c70
20026230:	64252065 	.word	0x64252065
20026234:	6f4e000a 	.word	0x6f4e000a
20026238:	63616220 	.word	0x63616220
2002623c:	2070756b 	.word	0x2070756b
20026240:	636f6c62 	.word	0x636f6c62
20026244:	6e61206b 	.word	0x6e61206b
20026248:	6f6d2079 	.word	0x6f6d2079
2002624c:	000a6572 	.word	0x000a6572
20026250:	74706d65 	.word	0x74706d65
20026254:	61742079 	.word	0x61742079
20026258:	20656c62 	.word	0x20656c62
2002625c:	6e206425 	.word	0x6e206425
20026260:	6520746f 	.word	0x6520746f
20026264:	67756f6e 	.word	0x67756f6e
20026268:	6f662068 	.word	0x6f662068
2002626c:	6e692072 	.word	0x6e692072
20026270:	61697469 	.word	0x61697469
20026274:	55000a6c 	.word	0x55000a6c
20026278:	74616470 	.word	0x74616470
2002627c:	61742065 	.word	0x61742065
20026280:	20656c62 	.word	0x20656c62
20026284:	66206f74 	.word	0x66206f74
20026288:	6873616c 	.word	0x6873616c
2002628c:	6e6f6420 	.word	0x6e6f6420
20026290:	49000a65 	.word	0x49000a65
20026294:	6974696e 	.word	0x6974696e
20026298:	74206c61 	.word	0x74206c61
2002629c:	656c6261 	.word	0x656c6261
200262a0:	69616620 	.word	0x69616620
200262a4:	42000a6c 	.word	0x42000a6c
200262a8:	69204d42 	.word	0x69204d42
200262ac:	6974696e 	.word	0x6974696e
200262b0:	7a696c61 	.word	0x7a696c61
200262b4:	62206465 	.word	0x62206465
200262b8:	726f6665 	.word	0x726f6665
200262bc:	64202c65 	.word	0x64202c65
200262c0:	6f6e206f 	.word	0x6f6e206f
200262c4:	6e692074 	.word	0x6e692074
200262c8:	61207469 	.word	0x61207469
200262cc:	6d20796e 	.word	0x6d20796e
200262d0:	0a65726f 	.word	0x0a65726f
200262d4:	54454400 	.word	0x54454400
200262d8:	20642520 	.word	0x20642520
200262dc:	0a646162 	.word	0x0a646162
200262e0:	4b4c4200 	.word	0x4b4c4200
200262e4:	20642520 	.word	0x20642520
200262e8:	64616572 	.word	0x64616572
200262ec:	69616620 	.word	0x69616620
200262f0:	6d202c6c 	.word	0x6d202c6c
200262f4:	206b7261 	.word	0x206b7261
200262f8:	62207361 	.word	0x62207361
200262fc:	000a6461 	.word	0x000a6461
20026300:	20746564 	.word	0x20746564
20026304:	206d6262 	.word	0x206d6262
20026308:	6c626174 	.word	0x6c626174
2002630c:	69772065 	.word	0x69772065
20026310:	25206874 	.word	0x25206874
20026314:	25202c64 	.word	0x25202c64
20026318:	25202c64 	.word	0x25202c64
2002631c:	64000a64 	.word	0x64000a64
20026320:	63657465 	.word	0x63657465
20026324:	65722074 	.word	0x65722074
20026328:	746c7573 	.word	0x746c7573
2002632c:	0a642520 	.word	0x0a642520
20026330:	20317600 	.word	0x20317600
20026334:	69206425 	.word	0x69206425
20026338:	6c62206e 	.word	0x6c62206e
2002633c:	6425206b 	.word	0x6425206b
20026340:	3276202c 	.word	0x3276202c
20026344:	20642520 	.word	0x20642520
20026348:	62206e69 	.word	0x62206e69
2002634c:	6b636f6c 	.word	0x6b636f6c
20026350:	0a642520 	.word	0x0a642520
20026354:	65684300 	.word	0x65684300
20026358:	62206b63 	.word	0x62206b63
2002635c:	74206d62 	.word	0x74206d62
20026360:	656c6261 	.word	0x656c6261
20026364:	69616620 	.word	0x69616620
20026368:	64000a6c 	.word	0x64000a6c
2002636c:	63657465 	.word	0x63657465
20026370:	65722074 	.word	0x65722074
20026374:	746c7573 	.word	0x746c7573
20026378:	20642520 	.word	0x20642520
2002637c:	20746f6e 	.word	0x20746f6e
20026380:	73616572 	.word	0x73616572
20026384:	62616e6f 	.word	0x62616e6f
20026388:	000a656c 	.word	0x000a656c
2002638c:	204d4242 	.word	0x204d4242
20026390:	3a4d454d 	.word	0x3a4d454d
20026394:	78746320 	.word	0x78746320
20026398:	2c702520 	.word	0x2c702520
2002639c:	70616d20 	.word	0x70616d20
200263a0:	70252031 	.word	0x70252031
200263a4:	616d202c 	.word	0x616d202c
200263a8:	25203270 	.word	0x25203270
200263ac:	000a2070 	.word	0x000a2070
200263b0:	5f666973 	.word	0x5f666973
200263b4:	5f6d6262 	.word	0x5f6d6262
200263b8:	74696e69 	.word	0x74696e69
200263bc:	6e6f6420 	.word	0x6e6f6420
200263c0:	23000a65 	.word	0x23000a65
200263c4:	202b302d 	.word	0x202b302d
200263c8:	4c6c6800 	.word	0x4c6c6800
200263cc:	67666500 	.word	0x67666500
200263d0:	00474645 	.word	0x00474645
200263d4:	33323130 	.word	0x33323130
200263d8:	37363534 	.word	0x37363534
200263dc:	42413938 	.word	0x42413938
200263e0:	46454443 	.word	0x46454443
200263e4:	32313000 	.word	0x32313000
200263e8:	36353433 	.word	0x36353433
200263ec:	61393837 	.word	0x61393837
200263f0:	65646362 	.word	0x65646362
200263f4:	00000066 	.word	0x00000066
200263f8:	50042000 	.word	0x50042000
200263fc:	00000002 	.word	0x00000002
20026400:	12000000 	.word	0x12000000
20026404:	00000004 	.word	0x00000004
20026408:	00000000 	.word	0x00000000
2002640c:	50041000 	.word	0x50041000
20026410:	00000002 	.word	0x00000002
20026414:	10000000 	.word	0x10000000
20026418:	00000004 	.word	0x00000004
2002641c:	00000000 	.word	0x00000000
20026420:	50043000 	.word	0x50043000
20026424:	00000002 	.word	0x00000002
20026428:	14000000 	.word	0x14000000
2002642c:	00000004 	.word	0x00000004
20026430:	00000000 	.word	0x00000000

20026434 <hpsys_dll2_limit>:
	...
2002643c:	112a8800 112a8800                       ..*...*.

20026444 <hpsys_dvfs_config>:
20026444:	000906fb 00100330 000a08fd 00110331     ....0.......1...
20026454:	000d0b00 00130213 000f0e02 00130213     ................

20026464 <crc32tab>:
20026464:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
20026474:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
20026484:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
20026494:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
200264a4:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
200264b4:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
200264c4:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
200264d4:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
200264e4:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
200264f4:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
20026504:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
20026514:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
20026524:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
20026534:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
20026544:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
20026554:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
20026564:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
20026574:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
20026584:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
20026594:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
200265a4:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
200265b4:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
200265c4:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
200265d4:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
200265e4:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
200265f4:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
20026604:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
20026614:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
20026624:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
20026634:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
20026644:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
20026654:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
20026664:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
20026674:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
20026684:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
20026694:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
200266a4:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
200266b4:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
200266c4:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
200266d4:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
200266e4:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
200266f4:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
20026704:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
20026714:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
20026724:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
20026734:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
20026744:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
20026754:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
20026764:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
20026774:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
20026784:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
20026794:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
200267a4:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
200267b4:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
200267c4:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
200267d4:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
200267e4:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
200267f4:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
20026804:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
20026814:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
20026824:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
20026834:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
20026844:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
20026854:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

20026864 <_init>:
20026864:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20026866:	bf00      	nop
20026868:	bcf8      	pop	{r3, r4, r5, r6, r7}
2002686a:	bc08      	pop	{r3}
2002686c:	469e      	mov	lr, r3
2002686e:	4770      	bx	lr

20026870 <_fini>:
20026870:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20026872:	bf00      	nop
20026874:	bcf8      	pop	{r3, r4, r5, r6, r7}
20026876:	bc08      	pop	{r3}
20026878:	469e      	mov	lr, r3
2002687a:	4770      	bx	lr

2002687c <__EH_FRAME_BEGIN__>:
2002687c:	0000 0000                                   ....

Disassembly of section .l1_ret_text_HAL_EFUSE_Extract:

20026880 <HAL_EFUSE_Extract>:
20026880:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20026884:	2800      	cmp	r0, #0
20026886:	d041      	beq.n	2002690c <HAL_EFUSE_Extract+0x8c>
20026888:	2a00      	cmp	r2, #0
2002688a:	d03f      	beq.n	2002690c <HAL_EFUSE_Extract+0x8c>
2002688c:	18cc      	adds	r4, r1, r3
2002688e:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20026892:	dc3b      	bgt.n	2002690c <HAL_EFUSE_Extract+0x8c>
20026894:	2400      	movs	r4, #0
20026896:	46a4      	mov	ip, r4
20026898:	094e      	lsrs	r6, r1, #5
2002689a:	1ddd      	adds	r5, r3, #7
2002689c:	f850 7026 	ldr.w	r7, [r0, r6, lsl #2]
200268a0:	f001 011f 	and.w	r1, r1, #31
200268a4:	f3c5 05cf 	ubfx	r5, r5, #3, #16
200268a8:	42a5      	cmp	r5, r4
200268aa:	d807      	bhi.n	200268bc <HAL_EFUSE_Extract+0x3c>
200268ac:	2400      	movs	r4, #0
200268ae:	46a6      	mov	lr, r4
200268b0:	46a4      	mov	ip, r4
200268b2:	459c      	cmp	ip, r3
200268b4:	d106      	bne.n	200268c4 <HAL_EFUSE_Extract+0x44>
200268b6:	4618      	mov	r0, r3
200268b8:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200268bc:	f802 c004 	strb.w	ip, [r2, r4]
200268c0:	3401      	adds	r4, #1
200268c2:	e7f1      	b.n	200268a8 <HAL_EFUSE_Extract+0x28>
200268c4:	fa27 f501 	lsr.w	r5, r7, r1
200268c8:	3101      	adds	r1, #1
200268ca:	f812 800e 	ldrb.w	r8, [r2, lr]
200268ce:	b289      	uxth	r1, r1
200268d0:	f005 0501 	and.w	r5, r5, #1
200268d4:	2920      	cmp	r1, #32
200268d6:	fa05 f504 	lsl.w	r5, r5, r4
200268da:	bf08      	it	eq
200268dc:	3601      	addeq	r6, #1
200268de:	ea45 0508 	orr.w	r5, r5, r8
200268e2:	f104 0401 	add.w	r4, r4, #1
200268e6:	b2a4      	uxth	r4, r4
200268e8:	f802 500e 	strb.w	r5, [r2, lr]
200268ec:	bf02      	ittt	eq
200268ee:	b2b6      	uxtheq	r6, r6
200268f0:	2100      	moveq	r1, #0
200268f2:	f850 7026 	ldreq.w	r7, [r0, r6, lsl #2]
200268f6:	2c08      	cmp	r4, #8
200268f8:	bf04      	itt	eq
200268fa:	f10e 0401 	addeq.w	r4, lr, #1
200268fe:	fa1f fe84 	uxtheq.w	lr, r4
20026902:	f10c 0c01 	add.w	ip, ip, #1
20026906:	bf08      	it	eq
20026908:	2400      	moveq	r4, #0
2002690a:	e7d2      	b.n	200268b2 <HAL_EFUSE_Extract+0x32>
2002690c:	2300      	movs	r3, #0
2002690e:	e7d2      	b.n	200268b6 <HAL_EFUSE_Extract+0x36>

Disassembly of section .l1_ret_text_HAL_Set_backup:

20026910 <HAL_Set_backup>:
20026910:	4b01      	ldr	r3, [pc, #4]	@ (20026918 <HAL_Set_backup+0x8>)
20026912:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
20026916:	4770      	bx	lr
20026918:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

2002691c <HAL_Get_backup>:
2002691c:	4b01      	ldr	r3, [pc, #4]	@ (20026924 <HAL_Get_backup+0x8>)
2002691e:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
20026922:	4770      	bx	lr
20026924:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_SET_HXT_CBANK:

20026928 <HAL_PMU_SET_HXT_CBANK>:
20026928:	4a02      	ldr	r2, [pc, #8]	@ (20026934 <HAL_PMU_SET_HXT_CBANK+0xc>)
2002692a:	6ed3      	ldr	r3, [r2, #108]	@ 0x6c
2002692c:	f360 531d 	bfi	r3, r0, #20, #10
20026930:	66d3      	str	r3, [r2, #108]	@ 0x6c
20026932:	4770      	bx	lr
20026934:	500ca000 	.word	0x500ca000

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

20026938 <HAL_PMU_GetHpsysVoutRef>:
20026938:	4b04      	ldr	r3, [pc, #16]	@ (2002694c <HAL_PMU_GetHpsysVoutRef+0x14>)
2002693a:	781a      	ldrb	r2, [r3, #0]
2002693c:	b122      	cbz	r2, 20026948 <HAL_PMU_GetHpsysVoutRef+0x10>
2002693e:	b118      	cbz	r0, 20026948 <HAL_PMU_GetHpsysVoutRef+0x10>
20026940:	78db      	ldrb	r3, [r3, #3]
20026942:	7003      	strb	r3, [r0, #0]
20026944:	2000      	movs	r0, #0
20026946:	4770      	bx	lr
20026948:	2001      	movs	r0, #1
2002694a:	4770      	bx	lr
2002694c:	2004ca18 	.word	0x2004ca18

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

20026950 <HAL_PMU_GetHpsysVoutRef2>:
20026950:	4b04      	ldr	r3, [pc, #16]	@ (20026964 <HAL_PMU_GetHpsysVoutRef2+0x14>)
20026952:	781a      	ldrb	r2, [r3, #0]
20026954:	b122      	cbz	r2, 20026960 <HAL_PMU_GetHpsysVoutRef2+0x10>
20026956:	b118      	cbz	r0, 20026960 <HAL_PMU_GetHpsysVoutRef2+0x10>
20026958:	7b5b      	ldrb	r3, [r3, #13]
2002695a:	7003      	strb	r3, [r0, #0]
2002695c:	2000      	movs	r0, #0
2002695e:	4770      	bx	lr
20026960:	2001      	movs	r0, #1
20026962:	4770      	bx	lr
20026964:	2004ca18 	.word	0x2004ca18

Disassembly of section .l1_ret_text_BSP_HxtCbank_Config:

20026968 <BSP_HxtCbank_Config>:
20026968:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
2002696a:	4607      	mov	r7, r0
2002696c:	2000      	movs	r0, #0
2002696e:	f7fd f877 	bl	20023a60 <HAL_RCC_HCPU_GetClockSrc>
20026972:	2100      	movs	r1, #0
20026974:	4604      	mov	r4, r0
20026976:	4608      	mov	r0, r1
20026978:	f7fd f936 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
2002697c:	f7fd f8a2 	bl	20023ac4 <HAL_RCC_HCPU_GetDLL1Freq>
20026980:	4606      	mov	r6, r0
20026982:	f7fd f8b1 	bl	20023ae8 <HAL_RCC_HCPU_GetDLL2Freq>
20026986:	4605      	mov	r5, r0
20026988:	4638      	mov	r0, r7
2002698a:	f7ff ffcd 	bl	20026928 <HAL_PMU_SET_HXT_CBANK>
2002698e:	2000      	movs	r0, #0
20026990:	f7fa ff9d 	bl	200218ce <HAL_Delay_us>
20026994:	2028      	movs	r0, #40	@ 0x28
20026996:	f7fa ff9a 	bl	200218ce <HAL_Delay_us>
2002699a:	f7fd f8f1 	bl	20023b80 <HAL_RCC_HCPU_DisableDLL1>
2002699e:	f7fd f8f7 	bl	20023b90 <HAL_RCC_HCPU_DisableDLL2>
200269a2:	4630      	mov	r0, r6
200269a4:	f7fd f8e4 	bl	20023b70 <HAL_RCC_HCPU_EnableDLL1>
200269a8:	4628      	mov	r0, r5
200269aa:	f7fd f8e5 	bl	20023b78 <HAL_RCC_HCPU_EnableDLL2>
200269ae:	4621      	mov	r1, r4
200269b0:	2000      	movs	r0, #0
200269b2:	f7fd f919 	bl	20023be8 <HAL_RCC_HCPU_ClockSelect>
200269b6:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
200269ba:	2000      	movs	r0, #0
200269bc:	f7fa bf87 	b.w	200218ce <HAL_Delay_us>
