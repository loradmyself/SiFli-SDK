
build_dpi-hdk_lb57gyd7n6_epd_hcpu\bootloader\bootloader.elf:     file format elf32-littlearm


Disassembly of section .text:

20020204 <deregister_tm_clones>:
20020204:	4803      	ldr	r0, [pc, #12]	@ (20020214 <deregister_tm_clones+0x10>)
20020206:	4b04      	ldr	r3, [pc, #16]	@ (20020218 <deregister_tm_clones+0x14>)
20020208:	4283      	cmp	r3, r0
2002020a:	d002      	beq.n	20020212 <deregister_tm_clones+0xe>
2002020c:	4b03      	ldr	r3, [pc, #12]	@ (2002021c <deregister_tm_clones+0x18>)
2002020e:	b103      	cbz	r3, 20020212 <deregister_tm_clones+0xe>
20020210:	4718      	bx	r3
20020212:	4770      	bx	lr
20020214:	20044a08 	.word	0x20044a08
20020218:	20044a08 	.word	0x20044a08
2002021c:	00000000 	.word	0x00000000

20020220 <register_tm_clones>:
20020220:	4b06      	ldr	r3, [pc, #24]	@ (2002023c <register_tm_clones+0x1c>)
20020222:	4907      	ldr	r1, [pc, #28]	@ (20020240 <register_tm_clones+0x20>)
20020224:	1ac9      	subs	r1, r1, r3
20020226:	1089      	asrs	r1, r1, #2
20020228:	bf48      	it	mi
2002022a:	3101      	addmi	r1, #1
2002022c:	1049      	asrs	r1, r1, #1
2002022e:	d003      	beq.n	20020238 <register_tm_clones+0x18>
20020230:	4b04      	ldr	r3, [pc, #16]	@ (20020244 <register_tm_clones+0x24>)
20020232:	b10b      	cbz	r3, 20020238 <register_tm_clones+0x18>
20020234:	4801      	ldr	r0, [pc, #4]	@ (2002023c <register_tm_clones+0x1c>)
20020236:	4718      	bx	r3
20020238:	4770      	bx	lr
2002023a:	bf00      	nop
2002023c:	20044a08 	.word	0x20044a08
20020240:	20044a08 	.word	0x20044a08
20020244:	00000000 	.word	0x00000000

20020248 <__do_global_dtors_aux>:
20020248:	b510      	push	{r4, lr}
2002024a:	4c06      	ldr	r4, [pc, #24]	@ (20020264 <__do_global_dtors_aux+0x1c>)
2002024c:	7823      	ldrb	r3, [r4, #0]
2002024e:	b943      	cbnz	r3, 20020262 <__do_global_dtors_aux+0x1a>
20020250:	f7ff ffd8 	bl	20020204 <deregister_tm_clones>
20020254:	4b04      	ldr	r3, [pc, #16]	@ (20020268 <__do_global_dtors_aux+0x20>)
20020256:	b113      	cbz	r3, 2002025e <__do_global_dtors_aux+0x16>
20020258:	4804      	ldr	r0, [pc, #16]	@ (2002026c <__do_global_dtors_aux+0x24>)
2002025a:	f3af 8000 	nop.w
2002025e:	2301      	movs	r3, #1
20020260:	7023      	strb	r3, [r4, #0]
20020262:	bd10      	pop	{r4, pc}
20020264:	20044a08 	.word	0x20044a08
20020268:	00000000 	.word	0x00000000
2002026c:	20027a54 	.word	0x20027a54

20020270 <frame_dummy>:
20020270:	b508      	push	{r3, lr}
20020272:	4b05      	ldr	r3, [pc, #20]	@ (20020288 <frame_dummy+0x18>)
20020274:	b11b      	cbz	r3, 2002027e <frame_dummy+0xe>
20020276:	4905      	ldr	r1, [pc, #20]	@ (2002028c <frame_dummy+0x1c>)
20020278:	4805      	ldr	r0, [pc, #20]	@ (20020290 <frame_dummy+0x20>)
2002027a:	f3af 8000 	nop.w
2002027e:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020282:	f7ff bfcd 	b.w	20020220 <register_tm_clones>
20020286:	bf00      	nop
20020288:	00000000 	.word	0x00000000
2002028c:	20044a0c 	.word	0x20044a0c
20020290:	20027a54 	.word	0x20027a54

20020294 <boot_uart_tx>:
20020294:	2300      	movs	r3, #0
20020296:	b510      	push	{r4, lr}
20020298:	4293      	cmp	r3, r2
2002029a:	db00      	blt.n	2002029e <boot_uart_tx+0xa>
2002029c:	bd10      	pop	{r4, pc}
2002029e:	69c4      	ldr	r4, [r0, #28]
200202a0:	0624      	lsls	r4, r4, #24
200202a2:	d5fc      	bpl.n	2002029e <boot_uart_tx+0xa>
200202a4:	5ccc      	ldrb	r4, [r1, r3]
200202a6:	3301      	adds	r3, #1
200202a8:	6284      	str	r4, [r0, #40]	@ 0x28
200202aa:	e7f5      	b.n	20020298 <boot_uart_tx+0x4>

200202ac <mpu_config>:
200202ac:	4770      	bx	lr

200202ae <cache_enable>:
200202ae:	4770      	bx	lr

200202b0 <board_pinmux_mpi1_type1>:
200202b0:	b510      	push	{r4, lr}
200202b2:	2100      	movs	r1, #0
200202b4:	f640 3004 	movw	r0, #2820	@ 0xb04
200202b8:	f004 f8ae 	bl	20024418 <HAL_PIN_Set2>
200202bc:	2100      	movs	r1, #0
200202be:	f44f 7082 	mov.w	r0, #260	@ 0x104
200202c2:	f004 f8a9 	bl	20024418 <HAL_PIN_Set2>
200202c6:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202ca:	f640 5004 	movw	r0, #3332	@ 0xd04
200202ce:	f004 f8a3 	bl	20024418 <HAL_PIN_Set2>
200202d2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200202d6:	f44f 7041 	mov.w	r0, #772	@ 0x304
200202da:	f004 f89d 	bl	20024418 <HAL_PIN_Set2>
200202de:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202e2:	f240 5004 	movw	r0, #1284	@ 0x504
200202e6:	f004 f897 	bl	20024418 <HAL_PIN_Set2>
200202ea:	f44f 7140 	mov.w	r1, #768	@ 0x300
200202ee:	f640 4004 	movw	r0, #3076	@ 0xc04
200202f2:	f004 f891 	bl	20024418 <HAL_PIN_Set2>
200202f6:	2400      	movs	r4, #0
200202f8:	2201      	movs	r2, #1
200202fa:	3401      	adds	r4, #1
200202fc:	4611      	mov	r1, r2
200202fe:	4620      	mov	r0, r4
20020300:	f004 f8d4 	bl	200244ac <HAL_PIN_Set_DS0>
20020304:	2200      	movs	r2, #0
20020306:	2101      	movs	r1, #1
20020308:	4620      	mov	r0, r4
2002030a:	f004 f8e5 	bl	200244d8 <HAL_PIN_Set_DS1>
2002030e:	2c0d      	cmp	r4, #13
20020310:	d1f2      	bne.n	200202f8 <board_pinmux_mpi1_type1+0x48>
20020312:	bd10      	pop	{r4, pc}

20020314 <board_pinmux_mpi1_type2>:
20020314:	b510      	push	{r4, lr}
20020316:	2100      	movs	r1, #0
20020318:	f640 3004 	movw	r0, #2820	@ 0xb04
2002031c:	f004 f87c 	bl	20024418 <HAL_PIN_Set2>
20020320:	2100      	movs	r1, #0
20020322:	f240 4004 	movw	r0, #1028	@ 0x404
20020326:	f004 f877 	bl	20024418 <HAL_PIN_Set2>
2002032a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002032e:	f640 5004 	movw	r0, #3332	@ 0xd04
20020332:	f004 f871 	bl	20024418 <HAL_PIN_Set2>
20020336:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002033a:	f44f 7041 	mov.w	r0, #772	@ 0x304
2002033e:	f004 f86b 	bl	20024418 <HAL_PIN_Set2>
20020342:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020346:	f44f 7001 	mov.w	r0, #516	@ 0x204
2002034a:	f004 f865 	bl	20024418 <HAL_PIN_Set2>
2002034e:	f44f 7140 	mov.w	r1, #768	@ 0x300
20020352:	f640 2004 	movw	r0, #2564	@ 0xa04
20020356:	f004 f85f 	bl	20024418 <HAL_PIN_Set2>
2002035a:	2400      	movs	r4, #0
2002035c:	2201      	movs	r2, #1
2002035e:	3401      	adds	r4, #1
20020360:	4611      	mov	r1, r2
20020362:	4620      	mov	r0, r4
20020364:	f004 f8a2 	bl	200244ac <HAL_PIN_Set_DS0>
20020368:	2200      	movs	r2, #0
2002036a:	2101      	movs	r1, #1
2002036c:	4620      	mov	r0, r4
2002036e:	f004 f8b3 	bl	200244d8 <HAL_PIN_Set_DS1>
20020372:	2c0d      	cmp	r4, #13
20020374:	d1f2      	bne.n	2002035c <board_pinmux_mpi1_type2+0x48>
20020376:	bd10      	pop	{r4, pc}

20020378 <board_pinmux_mpi2>:
20020378:	b510      	push	{r4, lr}
2002037a:	2100      	movs	r1, #0
2002037c:	f641 2004 	movw	r0, #6660	@ 0x1a04
20020380:	f004 f84a 	bl	20024418 <HAL_PIN_Set2>
20020384:	2100      	movs	r1, #0
20020386:	f241 4004 	movw	r0, #5124	@ 0x1404
2002038a:	f004 f845 	bl	20024418 <HAL_PIN_Set2>
2002038e:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020392:	f641 0004 	movw	r0, #6148	@ 0x1804
20020396:	f004 f83f 	bl	20024418 <HAL_PIN_Set2>
2002039a:	f44f 7180 	mov.w	r1, #256	@ 0x100
2002039e:	f241 3004 	movw	r0, #4868	@ 0x1304
200203a2:	f004 f839 	bl	20024418 <HAL_PIN_Set2>
200203a6:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203aa:	f241 2004 	movw	r0, #4612	@ 0x1204
200203ae:	f004 f833 	bl	20024418 <HAL_PIN_Set2>
200203b2:	f44f 7140 	mov.w	r1, #768	@ 0x300
200203b6:	f641 1004 	movw	r0, #6404	@ 0x1904
200203ba:	f004 f82d 	bl	20024418 <HAL_PIN_Set2>
200203be:	240e      	movs	r4, #14
200203c0:	2201      	movs	r2, #1
200203c2:	4620      	mov	r0, r4
200203c4:	4611      	mov	r1, r2
200203c6:	f004 f871 	bl	200244ac <HAL_PIN_Set_DS0>
200203ca:	4620      	mov	r0, r4
200203cc:	2200      	movs	r2, #0
200203ce:	2101      	movs	r1, #1
200203d0:	3401      	adds	r4, #1
200203d2:	f004 f881 	bl	200244d8 <HAL_PIN_Set_DS1>
200203d6:	2c1b      	cmp	r4, #27
200203d8:	d1f2      	bne.n	200203c0 <board_pinmux_mpi2+0x48>
200203da:	bd10      	pop	{r4, pc}

200203dc <board_pinmux_mpi3>:
200203dc:	b510      	push	{r4, lr}
200203de:	2100      	movs	r1, #0
200203e0:	f642 3001 	movw	r0, #11009	@ 0x2b01
200203e4:	f004 f818 	bl	20024418 <HAL_PIN_Set2>
200203e8:	2100      	movs	r1, #0
200203ea:	f242 7001 	movw	r0, #9985	@ 0x2701
200203ee:	f004 f813 	bl	20024418 <HAL_PIN_Set2>
200203f2:	f44f 7180 	mov.w	r1, #256	@ 0x100
200203f6:	f642 2001 	movw	r0, #10753	@ 0x2a01
200203fa:	f004 f80d 	bl	20024418 <HAL_PIN_Set2>
200203fe:	f44f 7180 	mov.w	r1, #256	@ 0x100
20020402:	f642 0001 	movw	r0, #10241	@ 0x2801
20020406:	f004 f807 	bl	20024418 <HAL_PIN_Set2>
2002040a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002040e:	f642 1001 	movw	r0, #10497	@ 0x2901
20020412:	f004 f801 	bl	20024418 <HAL_PIN_Set2>
20020416:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002041a:	f642 4001 	movw	r0, #11265	@ 0x2c01
2002041e:	f003 fffb 	bl	20024418 <HAL_PIN_Set2>
20020422:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
20020426:	4b13      	ldr	r3, [pc, #76]	@ (20020474 <board_pinmux_mpi3+0x98>)
20020428:	2427      	movs	r4, #39	@ 0x27
2002042a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002042e:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
20020432:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020436:	f44f 4200 	mov.w	r2, #32768	@ 0x8000
2002043a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002043e:	f44f 5200 	mov.w	r2, #8192	@ 0x2000
20020442:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020446:	f44f 4280 	mov.w	r2, #16384	@ 0x4000
2002044a:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
2002044e:	f44f 3200 	mov.w	r2, #131072	@ 0x20000
20020452:	f8c3 20ac 	str.w	r2, [r3, #172]	@ 0xac
20020456:	2201      	movs	r2, #1
20020458:	4620      	mov	r0, r4
2002045a:	4611      	mov	r1, r2
2002045c:	f004 f826 	bl	200244ac <HAL_PIN_Set_DS0>
20020460:	4620      	mov	r0, r4
20020462:	2200      	movs	r2, #0
20020464:	2101      	movs	r1, #1
20020466:	3401      	adds	r4, #1
20020468:	f004 f836 	bl	200244d8 <HAL_PIN_Set_DS1>
2002046c:	2c2d      	cmp	r4, #45	@ 0x2d
2002046e:	d1f2      	bne.n	20020456 <board_pinmux_mpi3+0x7a>
20020470:	bd10      	pop	{r4, pc}
20020472:	bf00      	nop
20020474:	500ca000 	.word	0x500ca000

20020478 <board_pinmux_sd>:
20020478:	b510      	push	{r4, lr}
2002047a:	f44f 7140 	mov.w	r1, #768	@ 0x300
2002047e:	f642 2002 	movw	r0, #10754	@ 0x2a02
20020482:	f003 ffc9 	bl	20024418 <HAL_PIN_Set2>
20020486:	f44f 4300 	mov.w	r3, #32768	@ 0x8000
2002048a:	4c1c      	ldr	r4, [pc, #112]	@ (200204fc <board_pinmux_sd+0x84>)
2002048c:	2014      	movs	r0, #20
2002048e:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
20020492:	f001 faae 	bl	200219f2 <HAL_Delay_us>
20020496:	2100      	movs	r1, #0
20020498:	f642 1002 	movw	r0, #10498	@ 0x2902
2002049c:	f003 ffbc 	bl	20024418 <HAL_PIN_Set2>
200204a0:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204a4:	f642 3002 	movw	r0, #11010	@ 0x2b02
200204a8:	f003 ffb6 	bl	20024418 <HAL_PIN_Set2>
200204ac:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204b0:	f642 4002 	movw	r0, #11266	@ 0x2c02
200204b4:	f003 ffb0 	bl	20024418 <HAL_PIN_Set2>
200204b8:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204bc:	f242 7002 	movw	r0, #9986	@ 0x2702
200204c0:	f003 ffaa 	bl	20024418 <HAL_PIN_Set2>
200204c4:	f44f 7140 	mov.w	r1, #768	@ 0x300
200204c8:	f642 0002 	movw	r0, #10242	@ 0x2802
200204cc:	f003 ffa4 	bl	20024418 <HAL_PIN_Set2>
200204d0:	f44f 4380 	mov.w	r3, #16384	@ 0x4000
200204d4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204d8:	f44f 3380 	mov.w	r3, #65536	@ 0x10000
200204dc:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e0:	f44f 3300 	mov.w	r3, #131072	@ 0x20000
200204e4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204e8:	f44f 5380 	mov.w	r3, #4096	@ 0x1000
200204ec:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f0:	f44f 5300 	mov.w	r3, #8192	@ 0x2000
200204f4:	f8c4 30ac 	str.w	r3, [r4, #172]	@ 0xac
200204f8:	bd10      	pop	{r4, pc}
200204fa:	bf00      	nop
200204fc:	500ca000 	.word	0x500ca000

20020500 <board_boot_from>:
20020500:	b508      	push	{r3, lr}
20020502:	2000      	movs	r0, #0
20020504:	f007 fc4e 	bl	20027da4 <HAL_Get_backup>
20020508:	f000 000f 	and.w	r0, r0, #15
2002050c:	bd08      	pop	{r3, pc}

2002050e <board_init>:
2002050e:	f004 bb37 	b.w	20024b80 <BSP_System_Config>

20020512 <bootloader_switch_clock>:
20020512:	2102      	movs	r1, #2
20020514:	2004      	movs	r0, #4
20020516:	f004 b949 	b.w	200247ac <HAL_RCC_HCPU_ClockSelect>

2002051a <board_init_psram>:
2002051a:	2201      	movs	r2, #1
2002051c:	b508      	push	{r3, lr}
2002051e:	4611      	mov	r1, r2
20020520:	2000      	movs	r0, #0
20020522:	f007 fc65 	bl	20027df0 <HAL_PMU_ConfigPeriLdo>
20020526:	2001      	movs	r0, #1
20020528:	f7ff fff3 	bl	20020512 <bootloader_switch_clock>
2002052c:	2002      	movs	r0, #2
2002052e:	f001 f911 	bl	20021754 <BSP_SetFlash1DIV>
20020532:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20020536:	f001 b8c5 	b.w	200216c4 <bsp_psramc_init>
	...

2002053c <erase_nor>:
2002053c:	b570      	push	{r4, r5, r6, lr}
2002053e:	4b13      	ldr	r3, [pc, #76]	@ (2002058c <erase_nor+0x50>)
20020540:	460c      	mov	r4, r1
20020542:	681e      	ldr	r6, [r3, #0]
20020544:	6933      	ldr	r3, [r6, #16]
20020546:	4283      	cmp	r3, r0
20020548:	d901      	bls.n	2002054e <erase_nor+0x12>
2002054a:	2001      	movs	r0, #1
2002054c:	bd70      	pop	{r4, r5, r6, pc}
2002054e:	6972      	ldr	r2, [r6, #20]
20020550:	441a      	add	r2, r3
20020552:	4282      	cmp	r2, r0
20020554:	d3f9      	bcc.n	2002054a <erase_nor+0xe>
20020556:	1ac0      	subs	r0, r0, r3
20020558:	f3c0 030b 	ubfx	r3, r0, #0, #12
2002055c:	b97b      	cbnz	r3, 2002057e <erase_nor+0x42>
2002055e:	f3c1 030b 	ubfx	r3, r1, #0, #12
20020562:	b97b      	cbnz	r3, 20020584 <erase_nor+0x48>
20020564:	1845      	adds	r5, r0, r1
20020566:	1b29      	subs	r1, r5, r4
20020568:	b90c      	cbnz	r4, 2002056e <erase_nor+0x32>
2002056a:	4620      	mov	r0, r4
2002056c:	e7ee      	b.n	2002054c <erase_nor+0x10>
2002056e:	4630      	mov	r0, r6
20020570:	f003 f8bd 	bl	200236ee <HAL_QSPIEX_SECT_ERASE>
20020574:	2800      	cmp	r0, #0
20020576:	d1e8      	bne.n	2002054a <erase_nor+0xe>
20020578:	f5a4 5480 	sub.w	r4, r4, #4096	@ 0x1000
2002057c:	e7f3      	b.n	20020566 <erase_nor+0x2a>
2002057e:	f04f 30ff 	mov.w	r0, #4294967295
20020582:	e7e3      	b.n	2002054c <erase_nor+0x10>
20020584:	f06f 0001 	mvn.w	r0, #1
20020588:	e7e0      	b.n	2002054c <erase_nor+0x10>
2002058a:	bf00      	nop
2002058c:	20046d30 	.word	0x20046d30

20020590 <write_nor>:
20020590:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20020594:	4b1e      	ldr	r3, [pc, #120]	@ (20020610 <write_nor+0x80>)
20020596:	460f      	mov	r7, r1
20020598:	f8d3 8000 	ldr.w	r8, [r3]
2002059c:	4616      	mov	r6, r2
2002059e:	f8d8 5010 	ldr.w	r5, [r8, #16]
200205a2:	4285      	cmp	r5, r0
200205a4:	d902      	bls.n	200205ac <write_nor+0x1c>
200205a6:	2000      	movs	r0, #0
200205a8:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200205ac:	f8d8 2014 	ldr.w	r2, [r8, #20]
200205b0:	442a      	add	r2, r5
200205b2:	4282      	cmp	r2, r0
200205b4:	d3f7      	bcc.n	200205a6 <write_nor+0x16>
200205b6:	1b45      	subs	r5, r0, r5
200205b8:	f015 04ff 	ands.w	r4, r5, #255	@ 0xff
200205bc:	d012      	beq.n	200205e4 <write_nor+0x54>
200205be:	f5c4 7480 	rsb	r4, r4, #256	@ 0x100
200205c2:	42b4      	cmp	r4, r6
200205c4:	bf28      	it	cs
200205c6:	4634      	movcs	r4, r6
200205c8:	460a      	mov	r2, r1
200205ca:	4623      	mov	r3, r4
200205cc:	4629      	mov	r1, r5
200205ce:	4640      	mov	r0, r8
200205d0:	f002 ffa8 	bl	20023524 <HAL_QSPIEX_WRITE_PAGE>
200205d4:	4284      	cmp	r4, r0
200205d6:	d1e6      	bne.n	200205a6 <write_nor+0x16>
200205d8:	4425      	add	r5, r4
200205da:	4427      	add	r7, r4
200205dc:	1b34      	subs	r4, r6, r4
200205de:	b91c      	cbnz	r4, 200205e8 <write_nor+0x58>
200205e0:	4630      	mov	r0, r6
200205e2:	e7e1      	b.n	200205a8 <write_nor+0x18>
200205e4:	4634      	mov	r4, r6
200205e6:	e7fa      	b.n	200205de <write_nor+0x4e>
200205e8:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
200205ec:	46a1      	mov	r9, r4
200205ee:	bf28      	it	cs
200205f0:	f44f 7980 	movcs.w	r9, #256	@ 0x100
200205f4:	463a      	mov	r2, r7
200205f6:	464b      	mov	r3, r9
200205f8:	4629      	mov	r1, r5
200205fa:	4640      	mov	r0, r8
200205fc:	f002 ff92 	bl	20023524 <HAL_QSPIEX_WRITE_PAGE>
20020600:	4581      	cmp	r9, r0
20020602:	d1d0      	bne.n	200205a6 <write_nor+0x16>
20020604:	444d      	add	r5, r9
20020606:	444f      	add	r7, r9
20020608:	eba4 0409 	sub.w	r4, r4, r9
2002060c:	e7e7      	b.n	200205de <write_nor+0x4e>
2002060e:	bf00      	nop
20020610:	20046d30 	.word	0x20046d30

20020614 <read_nor>:
20020614:	460b      	mov	r3, r1
20020616:	b510      	push	{r4, lr}
20020618:	4614      	mov	r4, r2
2002061a:	4601      	mov	r1, r0
2002061c:	4618      	mov	r0, r3
2002061e:	f005 fe88 	bl	20026332 <memcpy>
20020622:	4620      	mov	r0, r4
20020624:	bd10      	pop	{r4, pc}
	...

20020628 <read_nand>:
20020628:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
2002062c:	2600      	movs	r6, #0
2002062e:	460f      	mov	r7, r1
20020630:	4615      	mov	r5, r2
20020632:	46b0      	mov	r8, r6
20020634:	4b19      	ldr	r3, [pc, #100]	@ (2002069c <read_nand+0x74>)
20020636:	f8df a068 	ldr.w	sl, [pc, #104]	@ 200206a0 <read_nand+0x78>
2002063a:	681b      	ldr	r3, [r3, #0]
2002063c:	f8df b064 	ldr.w	fp, [pc, #100]	@ 200206a4 <read_nand+0x7c>
20020640:	691b      	ldr	r3, [r3, #16]
20020642:	4604      	mov	r4, r0
20020644:	4283      	cmp	r3, r0
20020646:	b085      	sub	sp, #20
20020648:	bf98      	it	ls
2002064a:	1ac4      	subls	r4, r0, r3
2002064c:	b91d      	cbnz	r5, 20020656 <read_nand+0x2e>
2002064e:	4630      	mov	r0, r6
20020650:	b005      	add	sp, #20
20020652:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020656:	f8da 1000 	ldr.w	r1, [sl]
2002065a:	f8db 0000 	ldr.w	r0, [fp]
2002065e:	42a9      	cmp	r1, r5
20020660:	fbb0 fcf1 	udiv	ip, r0, r1
20020664:	4689      	mov	r9, r1
20020666:	f101 32ff 	add.w	r2, r1, #4294967295
2002066a:	bf28      	it	cs
2002066c:	46a9      	movcs	r9, r5
2002066e:	fbb4 f1f1 	udiv	r1, r4, r1
20020672:	f10c 3cff 	add.w	ip, ip, #4294967295
20020676:	fbb4 f0f0 	udiv	r0, r4, r0
2002067a:	e9cd 8801 	strd	r8, r8, [sp, #4]
2002067e:	f8cd 9000 	str.w	r9, [sp]
20020682:	19bb      	adds	r3, r7, r6
20020684:	4022      	ands	r2, r4
20020686:	ea0c 0101 	and.w	r1, ip, r1
2002068a:	f004 fe61 	bl	20025350 <bbm_read_page>
2002068e:	4548      	cmp	r0, r9
20020690:	d1dd      	bne.n	2002064e <read_nand+0x26>
20020692:	4406      	add	r6, r0
20020694:	1a2d      	subs	r5, r5, r0
20020696:	4404      	add	r4, r0
20020698:	e7d8      	b.n	2002064c <read_nand+0x24>
2002069a:	bf00      	nop
2002069c:	20046d30 	.word	0x20046d30
200206a0:	20042c04 	.word	0x20042c04
200206a4:	20042c00 	.word	0x20042c00

200206a8 <read_sdnand>:
200206a8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200206ac:	f3c0 0408 	ubfx	r4, r0, #0, #9
200206b0:	460e      	mov	r6, r1
200206b2:	4615      	mov	r5, r2
200206b4:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
200206b8:	b38c      	cbz	r4, 2002071e <read_sdnand+0x76>
200206ba:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 20020734 <read_sdnand+0x8c>
200206be:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
200206c2:	eba8 0004 	sub.w	r0, r8, r4
200206c6:	f44f 7200 	mov.w	r2, #512	@ 0x200
200206ca:	4649      	mov	r1, r9
200206cc:	f000 fed2 	bl	20021474 <sd_read_data>
200206d0:	42af      	cmp	r7, r5
200206d2:	bf28      	it	cs
200206d4:	462f      	movcs	r7, r5
200206d6:	4630      	mov	r0, r6
200206d8:	eb09 0104 	add.w	r1, r9, r4
200206dc:	463a      	mov	r2, r7
200206de:	f005 fe28 	bl	20026332 <memcpy>
200206e2:	1bec      	subs	r4, r5, r7
200206e4:	44b8      	add	r8, r7
200206e6:	443e      	add	r6, r7
200206e8:	2700      	movs	r7, #0
200206ea:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
200206ee:	f02a 0a01 	bic.w	sl, sl, #1
200206f2:	4557      	cmp	r7, sl
200206f4:	eb07 0906 	add.w	r9, r7, r6
200206f8:	eb08 0007 	add.w	r0, r8, r7
200206fc:	d111      	bne.n	20020722 <read_sdnand+0x7a>
200206fe:	f3c4 0408 	ubfx	r4, r4, #0, #9
20020702:	b14c      	cbz	r4, 20020718 <read_sdnand+0x70>
20020704:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020708:	490a      	ldr	r1, [pc, #40]	@ (20020734 <read_sdnand+0x8c>)
2002070a:	f000 feb3 	bl	20021474 <sd_read_data>
2002070e:	4622      	mov	r2, r4
20020710:	4648      	mov	r0, r9
20020712:	4908      	ldr	r1, [pc, #32]	@ (20020734 <read_sdnand+0x8c>)
20020714:	f005 fe0d 	bl	20026332 <memcpy>
20020718:	4628      	mov	r0, r5
2002071a:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002071e:	4614      	mov	r4, r2
20020720:	e7e2      	b.n	200206e8 <read_sdnand+0x40>
20020722:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020726:	4649      	mov	r1, r9
20020728:	f000 fea4 	bl	20021474 <sd_read_data>
2002072c:	f507 7700 	add.w	r7, r7, #512	@ 0x200
20020730:	e7df      	b.n	200206f2 <read_sdnand+0x4a>
20020732:	bf00      	nop
20020734:	20046b2c 	.word	0x20046b2c

20020738 <read_sdemmc>:
20020738:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
2002073c:	f3c0 0408 	ubfx	r4, r0, #0, #9
20020740:	460e      	mov	r6, r1
20020742:	4615      	mov	r5, r2
20020744:	f100 481c 	add.w	r8, r0, #2617245696	@ 0x9c000000
20020748:	b38c      	cbz	r4, 200207ae <read_sdemmc+0x76>
2002074a:	f8df 9078 	ldr.w	r9, [pc, #120]	@ 200207c4 <read_sdemmc+0x8c>
2002074e:	f5c4 7700 	rsb	r7, r4, #512	@ 0x200
20020752:	eba8 0004 	sub.w	r0, r8, r4
20020756:	f44f 7200 	mov.w	r2, #512	@ 0x200
2002075a:	4649      	mov	r1, r9
2002075c:	f000 fd2e 	bl	200211bc <emmc_read_data>
20020760:	42af      	cmp	r7, r5
20020762:	bf28      	it	cs
20020764:	462f      	movcs	r7, r5
20020766:	4630      	mov	r0, r6
20020768:	eb09 0104 	add.w	r1, r9, r4
2002076c:	463a      	mov	r2, r7
2002076e:	f005 fde0 	bl	20026332 <memcpy>
20020772:	1bec      	subs	r4, r5, r7
20020774:	44b8      	add	r8, r7
20020776:	443e      	add	r6, r7
20020778:	2700      	movs	r7, #0
2002077a:	f424 7aff 	bic.w	sl, r4, #510	@ 0x1fe
2002077e:	f02a 0a01 	bic.w	sl, sl, #1
20020782:	4557      	cmp	r7, sl
20020784:	eb07 0906 	add.w	r9, r7, r6
20020788:	eb08 0007 	add.w	r0, r8, r7
2002078c:	d111      	bne.n	200207b2 <read_sdemmc+0x7a>
2002078e:	f3c4 0408 	ubfx	r4, r4, #0, #9
20020792:	b14c      	cbz	r4, 200207a8 <read_sdemmc+0x70>
20020794:	f44f 7200 	mov.w	r2, #512	@ 0x200
20020798:	490a      	ldr	r1, [pc, #40]	@ (200207c4 <read_sdemmc+0x8c>)
2002079a:	f000 fd0f 	bl	200211bc <emmc_read_data>
2002079e:	4622      	mov	r2, r4
200207a0:	4648      	mov	r0, r9
200207a2:	4908      	ldr	r1, [pc, #32]	@ (200207c4 <read_sdemmc+0x8c>)
200207a4:	f005 fdc5 	bl	20026332 <memcpy>
200207a8:	4628      	mov	r0, r5
200207aa:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200207ae:	4614      	mov	r4, r2
200207b0:	e7e2      	b.n	20020778 <read_sdemmc+0x40>
200207b2:	f44f 7200 	mov.w	r2, #512	@ 0x200
200207b6:	4649      	mov	r1, r9
200207b8:	f000 fd00 	bl	200211bc <emmc_read_data>
200207bc:	f507 7700 	add.w	r7, r7, #512	@ 0x200
200207c0:	e7df      	b.n	20020782 <read_sdemmc+0x4a>
200207c2:	bf00      	nop
200207c4:	20046b2c 	.word	0x20046b2c

200207c8 <port_read_page>:
200207c8:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
200207cc:	4615      	mov	r5, r2
200207ce:	460e      	mov	r6, r1
200207d0:	492b      	ldr	r1, [pc, #172]	@ (20020880 <port_read_page+0xb8>)
200207d2:	461a      	mov	r2, r3
200207d4:	e9dd 3c08 	ldrd	r3, ip, [sp, #32]
200207d8:	680f      	ldr	r7, [r1, #0]
200207da:	18e9      	adds	r1, r5, r3
200207dc:	428f      	cmp	r7, r1
200207de:	f8dd e028 	ldr.w	lr, [sp, #40]	@ 0x28
200207e2:	d200      	bcs.n	200207e6 <port_read_page+0x1e>
200207e4:	e7fe      	b.n	200207e4 <port_read_page+0x1c>
200207e6:	4927      	ldr	r1, [pc, #156]	@ (20020884 <port_read_page+0xbc>)
200207e8:	f107 0980 	add.w	r9, r7, #128	@ 0x80
200207ec:	f1b9 0f00 	cmp.w	r9, #0
200207f0:	6809      	ldr	r1, [r1, #0]
200207f2:	dd18      	ble.n	20020826 <port_read_page+0x5e>
200207f4:	4c24      	ldr	r4, [pc, #144]	@ (20020888 <port_read_page+0xc0>)
200207f6:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
200207fa:	f004 081f 	and.w	r8, r4, #31
200207fe:	44c8      	add	r8, r9
20020800:	f024 041f 	bic.w	r4, r4, #31
20020804:	f3bf 8f4f 	dsb	sy
20020808:	f8df a084 	ldr.w	sl, [pc, #132]	@ 20020890 <port_read_page+0xc8>
2002080c:	44a0      	add	r8, r4
2002080e:	f8ca 425c 	str.w	r4, [sl, #604]	@ 0x25c
20020812:	3420      	adds	r4, #32
20020814:	eba8 0904 	sub.w	r9, r8, r4
20020818:	f1b9 0f00 	cmp.w	r9, #0
2002081c:	dcf7      	bgt.n	2002080e <port_read_page+0x46>
2002081e:	f3bf 8f4f 	dsb	sy
20020822:	f3bf 8f6f 	isb	sy
20020826:	07c4      	lsls	r4, r0, #31
20020828:	d51e      	bpl.n	20020868 <port_read_page+0xa0>
2002082a:	4c17      	ldr	r4, [pc, #92]	@ (20020888 <port_read_page+0xc0>)
2002082c:	f894 80d7 	ldrb.w	r8, [r4, #215]	@ 0xd7
20020830:	f1b8 0f00 	cmp.w	r8, #0
20020834:	d018      	beq.n	20020868 <port_read_page+0xa0>
20020836:	f8d4 40b8 	ldr.w	r4, [r4, #184]	@ 0xb8
2002083a:	f504 5880 	add.w	r8, r4, #4096	@ 0x1000
2002083e:	f004 041f 	and.w	r4, r4, #31
20020842:	f504 6408 	add.w	r4, r4, #2176	@ 0x880
20020846:	f028 081f 	bic.w	r8, r8, #31
2002084a:	f3bf 8f4f 	dsb	sy
2002084e:	f8df 9040 	ldr.w	r9, [pc, #64]	@ 20020890 <port_read_page+0xc8>
20020852:	3c20      	subs	r4, #32
20020854:	2c00      	cmp	r4, #0
20020856:	f8c9 825c 	str.w	r8, [r9, #604]	@ 0x25c
2002085a:	f108 0820 	add.w	r8, r8, #32
2002085e:	dcf8      	bgt.n	20020852 <port_read_page+0x8a>
20020860:	f3bf 8f4f 	dsb	sy
20020864:	f3bf 8f6f 	isb	sy
20020868:	fb07 5506 	mla	r5, r7, r6, r5
2002086c:	e9cd ce08 	strd	ip, lr, [sp, #32]
20020870:	fb01 5100 	mla	r1, r1, r0, r5
20020874:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020878:	4804      	ldr	r0, [pc, #16]	@ (2002088c <port_read_page+0xc4>)
2002087a:	f002 bd71 	b.w	20023360 <HAL_NAND_READ_WITHOOB>
2002087e:	bf00      	nop
20020880:	20042c04 	.word	0x20042c04
20020884:	20042c00 	.word	0x20042c00
20020888:	20046f70 	.word	0x20046f70
2002088c:	20047018 	.word	0x20047018
20020890:	e000ed00 	.word	0xe000ed00

20020894 <bbm_get_bb>:
20020894:	b410      	push	{r4}
20020896:	4b1e      	ldr	r3, [pc, #120]	@ (20020910 <bbm_get_bb+0x7c>)
20020898:	4601      	mov	r1, r0
2002089a:	6818      	ldr	r0, [r3, #0]
2002089c:	3080      	adds	r0, #128	@ 0x80
2002089e:	2800      	cmp	r0, #0
200208a0:	dd14      	ble.n	200208cc <bbm_get_bb+0x38>
200208a2:	4b1c      	ldr	r3, [pc, #112]	@ (20020914 <bbm_get_bb+0x80>)
200208a4:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208a6:	f003 021f 	and.w	r2, r3, #31
200208aa:	4402      	add	r2, r0
200208ac:	f023 031f 	bic.w	r3, r3, #31
200208b0:	f3bf 8f4f 	dsb	sy
200208b4:	4c18      	ldr	r4, [pc, #96]	@ (20020918 <bbm_get_bb+0x84>)
200208b6:	441a      	add	r2, r3
200208b8:	f8c4 325c 	str.w	r3, [r4, #604]	@ 0x25c
200208bc:	3320      	adds	r3, #32
200208be:	1ad0      	subs	r0, r2, r3
200208c0:	2800      	cmp	r0, #0
200208c2:	dcf9      	bgt.n	200208b8 <bbm_get_bb+0x24>
200208c4:	f3bf 8f4f 	dsb	sy
200208c8:	f3bf 8f6f 	isb	sy
200208cc:	07cb      	lsls	r3, r1, #31
200208ce:	d51a      	bpl.n	20020906 <bbm_get_bb+0x72>
200208d0:	4b10      	ldr	r3, [pc, #64]	@ (20020914 <bbm_get_bb+0x80>)
200208d2:	f893 2083 	ldrb.w	r2, [r3, #131]	@ 0x83
200208d6:	b1b2      	cbz	r2, 20020906 <bbm_get_bb+0x72>
200208d8:	6e5b      	ldr	r3, [r3, #100]	@ 0x64
200208da:	f503 5280 	add.w	r2, r3, #4096	@ 0x1000
200208de:	f003 031f 	and.w	r3, r3, #31
200208e2:	f503 6308 	add.w	r3, r3, #2176	@ 0x880
200208e6:	f022 021f 	bic.w	r2, r2, #31
200208ea:	f3bf 8f4f 	dsb	sy
200208ee:	480a      	ldr	r0, [pc, #40]	@ (20020918 <bbm_get_bb+0x84>)
200208f0:	3b20      	subs	r3, #32
200208f2:	2b00      	cmp	r3, #0
200208f4:	f8c0 225c 	str.w	r2, [r0, #604]	@ 0x25c
200208f8:	f102 0220 	add.w	r2, r2, #32
200208fc:	dcf8      	bgt.n	200208f0 <bbm_get_bb+0x5c>
200208fe:	f3bf 8f4f 	dsb	sy
20020902:	f3bf 8f6f 	isb	sy
20020906:	4805      	ldr	r0, [pc, #20]	@ (2002091c <bbm_get_bb+0x88>)
20020908:	f85d 4b04 	ldr.w	r4, [sp], #4
2002090c:	f002 bde9 	b.w	200234e2 <HAL_NAND_GET_BADBLK>
20020910:	20042c04 	.word	0x20042c04
20020914:	20046f70 	.word	0x20046f70
20020918:	e000ed00 	.word	0xe000ed00
2002091c:	20046fc4 	.word	0x20046fc4

20020920 <boot_device_init>:
20020920:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20020924:	b08c      	sub	sp, #48	@ 0x30
20020926:	f001 fd83 	bl	20022430 <HAL_HPAON_EnableXT48>
2002092a:	2101      	movs	r1, #1
2002092c:	2000      	movs	r0, #0
2002092e:	f003 ff3d 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20020932:	2101      	movs	r1, #1
20020934:	200c      	movs	r0, #12
20020936:	f003 ff39 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
2002093a:	2001      	movs	r0, #1
2002093c:	f003 fde2 	bl	20024504 <HAL_PMU_EnableDLL>
20020940:	4fa3      	ldr	r7, [pc, #652]	@ (20020bd0 <boot_device_init+0x2b0>)
20020942:	2090      	movs	r0, #144	@ 0x90
20020944:	f004 f898 	bl	20024a78 <HAL_RCC_HCPU_ConfigHCLK>
20020948:	48a2      	ldr	r0, [pc, #648]	@ (20020bd4 <boot_device_init+0x2b4>)
2002094a:	f003 fef7 	bl	2002473c <HAL_RCC_HCPU_EnableDLL2>
2002094e:	783b      	ldrb	r3, [r7, #0]
20020950:	4ca1      	ldr	r4, [pc, #644]	@ (20020bd8 <boot_device_init+0x2b8>)
20020952:	2b06      	cmp	r3, #6
20020954:	f200 8137 	bhi.w	20020bc6 <boot_device_init+0x2a6>
20020958:	e8df f013 	tbh	[pc, r3, lsl #1]
2002095c:	00440007 	.word	0x00440007
20020960:	009f0044 	.word	0x009f0044
20020964:	011b009f 	.word	0x011b009f
20020968:	012a      	.short	0x012a
2002096a:	2006      	movs	r0, #6
2002096c:	4e9b      	ldr	r6, [pc, #620]	@ (20020bdc <boot_device_init+0x2bc>)
2002096e:	f000 fef7 	bl	20021760 <BSP_SetFlash2DIV>
20020972:	ad02      	add	r5, sp, #8
20020974:	2102      	movs	r1, #2
20020976:	2006      	movs	r0, #6
20020978:	f003 ff18 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
2002097c:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
2002097e:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020980:	6833      	ldr	r3, [r6, #0]
20020982:	2210      	movs	r2, #16
20020984:	2100      	movs	r1, #0
20020986:	602b      	str	r3, [r5, #0]
20020988:	a808      	add	r0, sp, #32
2002098a:	f005 fc63 	bl	20026254 <memset>
2002098e:	4b94      	ldr	r3, [pc, #592]	@ (20020be0 <boot_device_init+0x2c0>)
20020990:	2601      	movs	r6, #1
20020992:	9307      	str	r3, [sp, #28]
20020994:	2333      	movs	r3, #51	@ 0x33
20020996:	960a      	str	r6, [sp, #40]	@ 0x28
20020998:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
2002099c:	f7ff fcec 	bl	20020378 <board_pinmux_mpi2>
200209a0:	2302      	movs	r3, #2
200209a2:	4d90      	ldr	r5, [pc, #576]	@ (20020be4 <boot_device_init+0x2c4>)
200209a4:	9303      	str	r3, [sp, #12]
200209a6:	4b90      	ldr	r3, [pc, #576]	@ (20020be8 <boot_device_init+0x2c8>)
200209a8:	2000      	movs	r0, #0
200209aa:	6023      	str	r3, [r4, #0]
200209ac:	f001 f821 	bl	200219f2 <HAL_Delay_us>
200209b0:	f885 6099 	strb.w	r6, [r5, #153]	@ 0x99
200209b4:	f000 fec2 	bl	2002173c <BSP_GetFlash2DIV>
200209b8:	f105 0654 	add.w	r6, r5, #84	@ 0x54
200209bc:	4a8b      	ldr	r2, [pc, #556]	@ (20020bec <boot_device_init+0x2cc>)
200209be:	9000      	str	r0, [sp, #0]
200209c0:	ab07      	add	r3, sp, #28
200209c2:	4630      	mov	r0, r6
200209c4:	a902      	add	r1, sp, #8
200209c6:	f002 ff45 	bl	20023854 <HAL_FLASH_Init>
200209ca:	4b89      	ldr	r3, [pc, #548]	@ (20020bf0 <boot_device_init+0x2d0>)
200209cc:	4a89      	ldr	r2, [pc, #548]	@ (20020bf4 <boot_device_init+0x2d4>)
200209ce:	601a      	str	r2, [r3, #0]
200209d0:	4a89      	ldr	r2, [pc, #548]	@ (20020bf8 <boot_device_init+0x2d8>)
200209d2:	4b8a      	ldr	r3, [pc, #552]	@ (20020bfc <boot_device_init+0x2dc>)
200209d4:	601a      	str	r2, [r3, #0]
200209d6:	f8d5 209c 	ldr.w	r2, [r5, #156]	@ 0x9c
200209da:	4b89      	ldr	r3, [pc, #548]	@ (20020c00 <boot_device_init+0x2e0>)
200209dc:	601a      	str	r2, [r3, #0]
200209de:	4b89      	ldr	r3, [pc, #548]	@ (20020c04 <boot_device_init+0x2e4>)
200209e0:	601e      	str	r6, [r3, #0]
200209e2:	e037      	b.n	20020a54 <boot_device_init+0x134>
200209e4:	2006      	movs	r0, #6
200209e6:	4e88      	ldr	r6, [pc, #544]	@ (20020c08 <boot_device_init+0x2e8>)
200209e8:	f000 feb4 	bl	20021754 <BSP_SetFlash1DIV>
200209ec:	ad02      	add	r5, sp, #8
200209ee:	2102      	movs	r1, #2
200209f0:	2004      	movs	r0, #4
200209f2:	f003 fedb 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
200209f6:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
200209f8:	c50f      	stmia	r5!, {r0, r1, r2, r3}
200209fa:	6833      	ldr	r3, [r6, #0]
200209fc:	2210      	movs	r2, #16
200209fe:	602b      	str	r3, [r5, #0]
20020a00:	2100      	movs	r1, #0
20020a02:	a808      	add	r0, sp, #32
20020a04:	f005 fc26 	bl	20026254 <memset>
20020a08:	4b80      	ldr	r3, [pc, #512]	@ (20020c0c <boot_device_init+0x2ec>)
20020a0a:	4d76      	ldr	r5, [pc, #472]	@ (20020be4 <boot_device_init+0x2c4>)
20020a0c:	9307      	str	r3, [sp, #28]
20020a0e:	2332      	movs	r3, #50	@ 0x32
20020a10:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020a14:	2301      	movs	r3, #1
20020a16:	f885 3045 	strb.w	r3, [r5, #69]	@ 0x45
20020a1a:	783b      	ldrb	r3, [r7, #0]
20020a1c:	2b01      	cmp	r3, #1
20020a1e:	d139      	bne.n	20020a94 <boot_device_init+0x174>
20020a20:	f7ff fc46 	bl	200202b0 <board_pinmux_mpi1_type1>
20020a24:	2302      	movs	r3, #2
20020a26:	9303      	str	r3, [sp, #12]
20020a28:	f000 fe82 	bl	20021730 <BSP_GetFlash1DIV>
20020a2c:	4a78      	ldr	r2, [pc, #480]	@ (20020c10 <boot_device_init+0x2f0>)
20020a2e:	9000      	str	r0, [sp, #0]
20020a30:	ab07      	add	r3, sp, #28
20020a32:	486c      	ldr	r0, [pc, #432]	@ (20020be4 <boot_device_init+0x2c4>)
20020a34:	a902      	add	r1, sp, #8
20020a36:	f002 ff0d 	bl	20023854 <HAL_FLASH_Init>
20020a3a:	4b6b      	ldr	r3, [pc, #428]	@ (20020be8 <boot_device_init+0x2c8>)
20020a3c:	4a6d      	ldr	r2, [pc, #436]	@ (20020bf4 <boot_device_init+0x2d4>)
20020a3e:	6023      	str	r3, [r4, #0]
20020a40:	4b6b      	ldr	r3, [pc, #428]	@ (20020bf0 <boot_device_init+0x2d0>)
20020a42:	601a      	str	r2, [r3, #0]
20020a44:	4b6d      	ldr	r3, [pc, #436]	@ (20020bfc <boot_device_init+0x2dc>)
20020a46:	4a6c      	ldr	r2, [pc, #432]	@ (20020bf8 <boot_device_init+0x2d8>)
20020a48:	601a      	str	r2, [r3, #0]
20020a4a:	4b6d      	ldr	r3, [pc, #436]	@ (20020c00 <boot_device_init+0x2e0>)
20020a4c:	6caa      	ldr	r2, [r5, #72]	@ 0x48
20020a4e:	601a      	str	r2, [r3, #0]
20020a50:	4b6c      	ldr	r3, [pc, #432]	@ (20020c04 <boot_device_init+0x2e4>)
20020a52:	601d      	str	r5, [r3, #0]
20020a54:	6823      	ldr	r3, [r4, #0]
20020a56:	2b00      	cmp	r3, #0
20020a58:	f000 8110 	beq.w	20020c7c <boot_device_init+0x35c>
20020a5c:	4e68      	ldr	r6, [pc, #416]	@ (20020c00 <boot_device_init+0x2e0>)
20020a5e:	6830      	ldr	r0, [r6, #0]
20020a60:	2800      	cmp	r0, #0
20020a62:	f000 810b 	beq.w	20020c7c <boot_device_init+0x35c>
20020a66:	4d6b      	ldr	r5, [pc, #428]	@ (20020c14 <boot_device_init+0x2f4>)
20020a68:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020a6c:	4629      	mov	r1, r5
20020a6e:	4798      	blx	r3
20020a70:	682a      	ldr	r2, [r5, #0]
20020a72:	4b69      	ldr	r3, [pc, #420]	@ (20020c18 <boot_device_init+0x2f8>)
20020a74:	7839      	ldrb	r1, [r7, #0]
20020a76:	429a      	cmp	r2, r3
20020a78:	f040 80fb 	bne.w	20020c72 <boot_device_init+0x352>
20020a7c:	2904      	cmp	r1, #4
20020a7e:	d105      	bne.n	20020a8c <boot_device_init+0x16c>
20020a80:	f8d5 30a4 	ldr.w	r3, [r5, #164]	@ 0xa4
20020a84:	1e5a      	subs	r2, r3, #1
20020a86:	3203      	adds	r2, #3
20020a88:	f240 80e2 	bls.w	20020c50 <boot_device_init+0x330>
20020a8c:	2001      	movs	r0, #1
20020a8e:	b00c      	add	sp, #48	@ 0x30
20020a90:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20020a94:	f7ff fc3e 	bl	20020314 <board_pinmux_mpi1_type2>
20020a98:	e7c4      	b.n	20020a24 <boot_device_init+0x104>
20020a9a:	2006      	movs	r0, #6
20020a9c:	4e5f      	ldr	r6, [pc, #380]	@ (20020c1c <boot_device_init+0x2fc>)
20020a9e:	f000 fe65 	bl	2002176c <BSP_SetFlash3DIV>
20020aa2:	ad02      	add	r5, sp, #8
20020aa4:	2102      	movs	r1, #2
20020aa6:	2008      	movs	r0, #8
20020aa8:	f003 fe80 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20020aac:	ce0f      	ldmia	r6!, {r0, r1, r2, r3}
20020aae:	c50f      	stmia	r5!, {r0, r1, r2, r3}
20020ab0:	f897 8000 	ldrb.w	r8, [r7]
20020ab4:	6833      	ldr	r3, [r6, #0]
20020ab6:	f1b8 0a03 	subs.w	sl, r8, #3
20020aba:	602b      	str	r3, [r5, #0]
20020abc:	f04f 0210 	mov.w	r2, #16
20020ac0:	f04f 0100 	mov.w	r1, #0
20020ac4:	a808      	add	r0, sp, #32
20020ac6:	bf18      	it	ne
20020ac8:	f04f 0a01 	movne.w	sl, #1
20020acc:	f005 fbc2 	bl	20026254 <memset>
20020ad0:	4b4e      	ldr	r3, [pc, #312]	@ (20020c0c <boot_device_init+0x2ec>)
20020ad2:	2502      	movs	r5, #2
20020ad4:	9307      	str	r3, [sp, #28]
20020ad6:	2332      	movs	r3, #50	@ 0x32
20020ad8:	950a      	str	r5, [sp, #40]	@ 0x28
20020ada:	f88d 3024 	strb.w	r3, [sp, #36]	@ 0x24
20020ade:	f7ff fc7d 	bl	200203dc <board_pinmux_mpi3>
20020ae2:	f1b8 0f03 	cmp.w	r8, #3
20020ae6:	9503      	str	r5, [sp, #12]
20020ae8:	4d3e      	ldr	r5, [pc, #248]	@ (20020be4 <boot_device_init+0x2c4>)
20020aea:	d045      	beq.n	20020b78 <boot_device_init+0x258>
20020aec:	4b4c      	ldr	r3, [pc, #304]	@ (20020c20 <boot_device_init+0x300>)
20020aee:	6023      	str	r3, [r4, #0]
20020af0:	9b04      	ldr	r3, [sp, #16]
20020af2:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20020af6:	9304      	str	r3, [sp, #16]
20020af8:	2301      	movs	r3, #1
20020afa:	9306      	str	r3, [sp, #24]
20020afc:	4b49      	ldr	r3, [pc, #292]	@ (20020c24 <boot_device_init+0x304>)
20020afe:	f8c5 30c4 	str.w	r3, [r5, #196]	@ 0xc4
20020b02:	f04f 0901 	mov.w	r9, #1
20020b06:	2000      	movs	r0, #0
20020b08:	f000 ff73 	bl	200219f2 <HAL_Delay_us>
20020b0c:	f885 90ed 	strb.w	r9, [r5, #237]	@ 0xed
20020b10:	f885 a0ec 	strb.w	sl, [r5, #236]	@ 0xec
20020b14:	f000 fe18 	bl	20021748 <BSP_GetFlash3DIV>
20020b18:	4a43      	ldr	r2, [pc, #268]	@ (20020c28 <boot_device_init+0x308>)
20020b1a:	9000      	str	r0, [sp, #0]
20020b1c:	ab07      	add	r3, sp, #28
20020b1e:	4843      	ldr	r0, [pc, #268]	@ (20020c2c <boot_device_init+0x30c>)
20020b20:	a902      	add	r1, sp, #8
20020b22:	f002 fe97 	bl	20023854 <HAL_FLASH_Init>
20020b26:	4e41      	ldr	r6, [pc, #260]	@ (20020c2c <boot_device_init+0x30c>)
20020b28:	bb48      	cbnz	r0, 20020b7e <boot_device_init+0x25e>
20020b2a:	f1b8 0f03 	cmp.w	r8, #3
20020b2e:	d029      	beq.n	20020b84 <boot_device_init+0x264>
20020b30:	4630      	mov	r0, r6
20020b32:	f002 fc0a 	bl	2002334a <HAL_NAND_PAGE_SIZE>
20020b36:	f8df a110 	ldr.w	sl, [pc, #272]	@ 20020c48 <boot_device_init+0x328>
20020b3a:	f8df 8110 	ldr.w	r8, [pc, #272]	@ 20020c4c <boot_device_init+0x32c>
20020b3e:	f8ca 0000 	str.w	r0, [sl]
20020b42:	4630      	mov	r0, r6
20020b44:	f002 fcc1 	bl	200234ca <HAL_NAND_BLOCK_SIZE>
20020b48:	4649      	mov	r1, r9
20020b4a:	f8c8 0000 	str.w	r0, [r8]
20020b4e:	4630      	mov	r0, r6
20020b50:	f885 90d6 	strb.w	r9, [r5, #214]	@ 0xd6
20020b54:	f002 fab9 	bl	200230ca <HAL_NAND_CONF_ECC>
20020b58:	f8da 0000 	ldr.w	r0, [sl]
20020b5c:	f004 fede 	bl	2002591c <bbm_set_page_size>
20020b60:	f8d8 0000 	ldr.w	r0, [r8]
20020b64:	f004 fee0 	bl	20025928 <bbm_set_blk_size>
20020b68:	4931      	ldr	r1, [pc, #196]	@ (20020c30 <boot_device_init+0x310>)
20020b6a:	f8d5 00f4 	ldr.w	r0, [r5, #244]	@ 0xf4
20020b6e:	f004 fd77 	bl	20025660 <sif_bbm_init>
20020b72:	f8d5 20f0 	ldr.w	r2, [r5, #240]	@ 0xf0
20020b76:	e730      	b.n	200209da <boot_device_init+0xba>
20020b78:	4b1b      	ldr	r3, [pc, #108]	@ (20020be8 <boot_device_init+0x2c8>)
20020b7a:	6023      	str	r3, [r4, #0]
20020b7c:	e7c1      	b.n	20020b02 <boot_device_init+0x1e2>
20020b7e:	f1b8 0f03 	cmp.w	r8, #3
20020b82:	d1f6      	bne.n	20020b72 <boot_device_init+0x252>
20020b84:	4b1a      	ldr	r3, [pc, #104]	@ (20020bf0 <boot_device_init+0x2d0>)
20020b86:	4a1b      	ldr	r2, [pc, #108]	@ (20020bf4 <boot_device_init+0x2d4>)
20020b88:	601a      	str	r2, [r3, #0]
20020b8a:	4b1c      	ldr	r3, [pc, #112]	@ (20020bfc <boot_device_init+0x2dc>)
20020b8c:	4a1a      	ldr	r2, [pc, #104]	@ (20020bf8 <boot_device_init+0x2d8>)
20020b8e:	601a      	str	r2, [r3, #0]
20020b90:	e7ef      	b.n	20020b72 <boot_device_init+0x252>
20020b92:	f7ff fc71 	bl	20020478 <board_pinmux_sd>
20020b96:	f000 fb59 	bl	2002124c <sdio_sd_init>
20020b9a:	2801      	cmp	r0, #1
20020b9c:	d111      	bne.n	20020bc2 <boot_device_init+0x2a2>
20020b9e:	4b25      	ldr	r3, [pc, #148]	@ (20020c34 <boot_device_init+0x314>)
20020ba0:	6023      	str	r3, [r4, #0]
20020ba2:	4b25      	ldr	r3, [pc, #148]	@ (20020c38 <boot_device_init+0x318>)
20020ba4:	4a16      	ldr	r2, [pc, #88]	@ (20020c00 <boot_device_init+0x2e0>)
20020ba6:	6013      	str	r3, [r2, #0]
20020ba8:	2200      	movs	r2, #0
20020baa:	4b16      	ldr	r3, [pc, #88]	@ (20020c04 <boot_device_init+0x2e4>)
20020bac:	601a      	str	r2, [r3, #0]
20020bae:	e751      	b.n	20020a54 <boot_device_init+0x134>
20020bb0:	f7ff fc62 	bl	20020478 <board_pinmux_sd>
20020bb4:	f000 fa1c 	bl	20020ff0 <sdio_emmc_init>
20020bb8:	4b20      	ldr	r3, [pc, #128]	@ (20020c3c <boot_device_init+0x31c>)
20020bba:	6018      	str	r0, [r3, #0]
20020bbc:	b908      	cbnz	r0, 20020bc2 <boot_device_init+0x2a2>
20020bbe:	4b20      	ldr	r3, [pc, #128]	@ (20020c40 <boot_device_init+0x320>)
20020bc0:	e7ee      	b.n	20020ba0 <boot_device_init+0x280>
20020bc2:	2300      	movs	r3, #0
20020bc4:	e7ee      	b.n	20020ba4 <boot_device_init+0x284>
20020bc6:	481f      	ldr	r0, [pc, #124]	@ (20020c44 <boot_device_init+0x324>)
20020bc8:	f005 f9ee 	bl	20025fa8 <iprintf>
20020bcc:	e742      	b.n	20020a54 <boot_device_init+0x134>
20020bce:	bf00      	nop
20020bd0:	20044a24 	.word	0x20044a24
20020bd4:	112a8800 	.word	0x112a8800
20020bd8:	20046d3c 	.word	0x20046d3c
20020bdc:	20026fbc 	.word	0x20026fbc
20020be0:	5008101c 	.word	0x5008101c
20020be4:	20046f70 	.word	0x20046f70
20020be8:	20020615 	.word	0x20020615
20020bec:	20046db0 	.word	0x20046db0
20020bf0:	20046d38 	.word	0x20046d38
20020bf4:	20020591 	.word	0x20020591
20020bf8:	2002053d 	.word	0x2002053d
20020bfc:	20046d34 	.word	0x20046d34
20020c00:	20046d2c 	.word	0x20046d2c
20020c04:	20046d30 	.word	0x20046d30
20020c08:	20026fd0 	.word	0x20026fd0
20020c0c:	50081008 	.word	0x50081008
20020c10:	20046d40 	.word	0x20046d40
20020c14:	20047138 	.word	0x20047138
20020c18:	53454346 	.word	0x53454346
20020c1c:	20026fe4 	.word	0x20026fe4
20020c20:	20020629 	.word	0x20020629
20020c24:	20045aac 	.word	0x20045aac
20020c28:	20046e20 	.word	0x20046e20
20020c2c:	20047018 	.word	0x20047018
20020c30:	20044a2c 	.word	0x20044a2c
20020c34:	200206a9 	.word	0x200206a9
20020c38:	64001000 	.word	0x64001000
20020c3c:	20044a28 	.word	0x20044a28
20020c40:	20020739 	.word	0x20020739
20020c44:	20026aa8 	.word	0x20026aa8
20020c48:	20042c04 	.word	0x20042c04
20020c4c:	20042c00 	.word	0x20042c00
20020c50:	4a0c      	ldr	r2, [pc, #48]	@ (20020c84 <boot_device_init+0x364>)
20020c52:	4629      	mov	r1, r5
20020c54:	6013      	str	r3, [r2, #0]
20020c56:	4b0c      	ldr	r3, [pc, #48]	@ (20020c88 <boot_device_init+0x368>)
20020c58:	6830      	ldr	r0, [r6, #0]
20020c5a:	681a      	ldr	r2, [r3, #0]
20020c5c:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
20020c60:	f043 0301 	orr.w	r3, r3, #1
20020c64:	f882 302c 	strb.w	r3, [r2, #44]	@ 0x2c
20020c68:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020c6c:	6823      	ldr	r3, [r4, #0]
20020c6e:	4798      	blx	r3
20020c70:	e70c      	b.n	20020a8c <boot_device_init+0x16c>
20020c72:	4806      	ldr	r0, [pc, #24]	@ (20020c8c <boot_device_init+0x36c>)
20020c74:	f005 f998 	bl	20025fa8 <iprintf>
20020c78:	2000      	movs	r0, #0
20020c7a:	e708      	b.n	20020a8e <boot_device_init+0x16e>
20020c7c:	7839      	ldrb	r1, [r7, #0]
20020c7e:	4804      	ldr	r0, [pc, #16]	@ (20020c90 <boot_device_init+0x370>)
20020c80:	e7f8      	b.n	20020c74 <boot_device_init+0x354>
20020c82:	bf00      	nop
20020c84:	20042c04 	.word	0x20042c04
20020c88:	20046d30 	.word	0x20046d30
20020c8c:	20026abc 	.word	0x20026abc
20020c90:	20026ae2 	.word	0x20026ae2

20020c94 <sifli_hw_efuse_load_bank0>:
20020c94:	2220      	movs	r2, #32
20020c96:	b508      	push	{r3, lr}
20020c98:	4904      	ldr	r1, [pc, #16]	@ (20020cac <sifli_hw_efuse_load_bank0+0x18>)
20020c9a:	2000      	movs	r0, #0
20020c9c:	f001 fb70 	bl	20022380 <HAL_EFUSE_Read>
20020ca0:	2800      	cmp	r0, #0
20020ca2:	4802      	ldr	r0, [pc, #8]	@ (20020cac <sifli_hw_efuse_load_bank0+0x18>)
20020ca4:	bf08      	it	eq
20020ca6:	2000      	moveq	r0, #0
20020ca8:	bd08      	pop	{r3, pc}
20020caa:	bf00      	nop
20020cac:	20047114 	.word	0x20047114

20020cb0 <update_sec_flash>:
20020cb0:	b570      	push	{r4, r5, r6, lr}
20020cb2:	4604      	mov	r4, r0
20020cb4:	4b08      	ldr	r3, [pc, #32]	@ (20020cd8 <update_sec_flash+0x28>)
20020cb6:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20020cba:	681d      	ldr	r5, [r3, #0]
20020cbc:	4b07      	ldr	r3, [pc, #28]	@ (20020cdc <update_sec_flash+0x2c>)
20020cbe:	4628      	mov	r0, r5
20020cc0:	681b      	ldr	r3, [r3, #0]
20020cc2:	4798      	blx	r3
20020cc4:	4b06      	ldr	r3, [pc, #24]	@ (20020ce0 <update_sec_flash+0x30>)
20020cc6:	4621      	mov	r1, r4
20020cc8:	4628      	mov	r0, r5
20020cca:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
20020cce:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020cd2:	681b      	ldr	r3, [r3, #0]
20020cd4:	4718      	bx	r3
20020cd6:	bf00      	nop
20020cd8:	20046d2c 	.word	0x20046d2c
20020cdc:	20046d34 	.word	0x20046d34
20020ce0:	20046d3c 	.word	0x20046d3c

20020ce4 <boot_images_help>:
20020ce4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20020ce8:	4e55      	ldr	r6, [pc, #340]	@ (20020e40 <boot_images_help+0x15c>)
20020cea:	f8df a164 	ldr.w	sl, [pc, #356]	@ 20020e50 <boot_images_help+0x16c>
20020cee:	6833      	ldr	r3, [r6, #0]
20020cf0:	b085      	sub	sp, #20
20020cf2:	4553      	cmp	r3, sl
20020cf4:	d156      	bne.n	20020da4 <boot_images_help+0xc0>
20020cf6:	2208      	movs	r2, #8
20020cf8:	2300      	movs	r3, #0
20020cfa:	f8df b158 	ldr.w	fp, [pc, #344]	@ 20020e54 <boot_images_help+0x170>
20020cfe:	eb0d 0102 	add.w	r1, sp, r2
20020d02:	e9cd 3302 	strd	r3, r3, [sp, #8]
20020d06:	484f      	ldr	r0, [pc, #316]	@ (20020e44 <boot_images_help+0x160>)
20020d08:	f8db 3000 	ldr.w	r3, [fp]
20020d0c:	4798      	blx	r3
20020d0e:	2008      	movs	r0, #8
20020d10:	f007 f848 	bl	20027da4 <HAL_Get_backup>
20020d14:	4605      	mov	r5, r0
20020d16:	2005      	movs	r0, #5
20020d18:	f007 f844 	bl	20027da4 <HAL_Get_backup>
20020d1c:	f8df 9138 	ldr.w	r9, [pc, #312]	@ 20020e58 <boot_images_help+0x174>
20020d20:	4949      	ldr	r1, [pc, #292]	@ (20020e48 <boot_images_help+0x164>)
20020d22:	f8d9 4000 	ldr.w	r4, [r9]
20020d26:	f8df 8134 	ldr.w	r8, [pc, #308]	@ 20020e5c <boot_images_help+0x178>
20020d2a:	f642 4210 	movw	r2, #11280	@ 0x2c10
20020d2e:	f8db 3000 	ldr.w	r3, [fp]
20020d32:	4607      	mov	r7, r0
20020d34:	f8c8 1000 	str.w	r1, [r8]
20020d38:	4620      	mov	r0, r4
20020d3a:	f506 5600 	add.w	r6, r6, #8192	@ 0x2000
20020d3e:	4798      	blx	r3
20020d40:	f8d6 bc08 	ldr.w	fp, [r6, #3080]	@ 0xc08
20020d44:	f504 52a0 	add.w	r2, r4, #5120	@ 0x1400
20020d48:	4593      	cmp	fp, r2
20020d4a:	d154      	bne.n	20020df6 <boot_images_help+0x112>
20020d4c:	b2eb      	uxtb	r3, r5
20020d4e:	2b04      	cmp	r3, #4
20020d50:	d02b      	beq.n	20020daa <boot_images_help+0xc6>
20020d52:	2b06      	cmp	r3, #6
20020d54:	d03f      	beq.n	20020dd6 <boot_images_help+0xf2>
20020d56:	2b01      	cmp	r3, #1
20020d58:	d148      	bne.n	20020dec <boot_images_help+0x108>
20020d5a:	2005      	movs	r0, #5
20020d5c:	f007 f822 	bl	20027da4 <HAL_Get_backup>
20020d60:	2802      	cmp	r0, #2
20020d62:	d006      	beq.n	20020d72 <boot_images_help+0x8e>
20020d64:	9b02      	ldr	r3, [sp, #8]
20020d66:	4553      	cmp	r3, sl
20020d68:	d106      	bne.n	20020d78 <boot_images_help+0x94>
20020d6a:	f89d 300d 	ldrb.w	r3, [sp, #13]
20020d6e:	2b7f      	cmp	r3, #127	@ 0x7f
20020d70:	d102      	bne.n	20020d78 <boot_images_help+0x94>
20020d72:	4b36      	ldr	r3, [pc, #216]	@ (20020e4c <boot_images_help+0x168>)
20020d74:	f8c6 3c08 	str.w	r3, [r6, #3080]	@ 0xc08
20020d78:	f7ff fbcf 	bl	2002051a <board_init_psram>
20020d7c:	f8d6 3200 	ldr.w	r3, [r6, #512]	@ 0x200
20020d80:	3301      	adds	r3, #1
20020d82:	d002      	beq.n	20020d8a <boot_images_help+0xa6>
20020d84:	200b      	movs	r0, #11
20020d86:	f000 fc2d 	bl	200215e4 <dfu_boot_img_in_flash>
20020d8a:	f8d6 0c08 	ldr.w	r0, [r6, #3080]	@ 0xc08
20020d8e:	1c43      	adds	r3, r0, #1
20020d90:	d008      	beq.n	20020da4 <boot_images_help+0xc0>
20020d92:	f8d9 3000 	ldr.w	r3, [r9]
20020d96:	1ac0      	subs	r0, r0, r3
20020d98:	f5a0 5080 	sub.w	r0, r0, #4096	@ 0x1000
20020d9c:	0a40      	lsrs	r0, r0, #9
20020d9e:	3002      	adds	r0, #2
20020da0:	f000 fc20 	bl	200215e4 <dfu_boot_img_in_flash>
20020da4:	b005      	add	sp, #20
20020da6:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20020daa:	2008      	movs	r0, #8
20020dac:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020db0:	2106      	movs	r1, #6
20020db2:	f8c6 4c08 	str.w	r4, [r6, #3080]	@ 0xc08
20020db6:	f006 ffef 	bl	20027d98 <HAL_Set_backup>
20020dba:	f8d8 0000 	ldr.w	r0, [r8]
20020dbe:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020dc2:	f8c3 4c08 	str.w	r4, [r3, #3080]	@ 0xc08
20020dc6:	b11f      	cbz	r7, 20020dd0 <boot_images_help+0xec>
20020dc8:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020dcc:	f8c3 7c00 	str.w	r7, [r3, #3072]	@ 0xc00
20020dd0:	f7ff ff6e 	bl	20020cb0 <update_sec_flash>
20020dd4:	e7c1      	b.n	20020d5a <boot_images_help+0x76>
20020dd6:	2101      	movs	r1, #1
20020dd8:	2008      	movs	r0, #8
20020dda:	f006 ffdd 	bl	20027d98 <HAL_Set_backup>
20020dde:	f8d8 0000 	ldr.w	r0, [r8]
20020de2:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020de6:	f8c3 bc08 	str.w	fp, [r3, #3080]	@ 0xc08
20020dea:	e7f1      	b.n	20020dd0 <boot_images_help+0xec>
20020dec:	2101      	movs	r1, #1
20020dee:	2008      	movs	r0, #8
20020df0:	f006 ffd2 	bl	20027d98 <HAL_Set_backup>
20020df4:	e7b1      	b.n	20020d5a <boot_images_help+0x76>
20020df6:	f504 54e0 	add.w	r4, r4, #7168	@ 0x1c00
20020dfa:	45a3      	cmp	fp, r4
20020dfc:	d1ad      	bne.n	20020d5a <boot_images_help+0x76>
20020dfe:	b2eb      	uxtb	r3, r5
20020e00:	2b03      	cmp	r3, #3
20020e02:	d005      	beq.n	20020e10 <boot_images_help+0x12c>
20020e04:	2b05      	cmp	r3, #5
20020e06:	d018      	beq.n	20020e3a <boot_images_help+0x156>
20020e08:	2b02      	cmp	r3, #2
20020e0a:	d0a6      	beq.n	20020d5a <boot_images_help+0x76>
20020e0c:	2102      	movs	r1, #2
20020e0e:	e7ee      	b.n	20020dee <boot_images_help+0x10a>
20020e10:	2008      	movs	r0, #8
20020e12:	2105      	movs	r1, #5
20020e14:	f8c6 2c08 	str.w	r2, [r6, #3080]	@ 0xc08
20020e18:	9201      	str	r2, [sp, #4]
20020e1a:	f006 ffbd 	bl	20027d98 <HAL_Set_backup>
20020e1e:	f8d8 0000 	ldr.w	r0, [r8]
20020e22:	9a01      	ldr	r2, [sp, #4]
20020e24:	f500 5300 	add.w	r3, r0, #8192	@ 0x2000
20020e28:	f8c3 2c08 	str.w	r2, [r3, #3080]	@ 0xc08
20020e2c:	2f00      	cmp	r7, #0
20020e2e:	d0cf      	beq.n	20020dd0 <boot_images_help+0xec>
20020e30:	f500 5380 	add.w	r3, r0, #4096	@ 0x1000
20020e34:	f8c3 7400 	str.w	r7, [r3, #1024]	@ 0x400
20020e38:	e7ca      	b.n	20020dd0 <boot_images_help+0xec>
20020e3a:	2102      	movs	r1, #2
20020e3c:	e7cc      	b.n	20020dd8 <boot_images_help+0xf4>
20020e3e:	bf00      	nop
20020e40:	20047138 	.word	0x20047138
20020e44:	127c0000 	.word	0x127c0000
20020e48:	20049d4c 	.word	0x20049d4c
20020e4c:	12001000 	.word	0x12001000
20020e50:	53454346 	.word	0x53454346
20020e54:	20046d3c 	.word	0x20046d3c
20020e58:	20046d2c 	.word	0x20046d2c
20020e5c:	20049d48 	.word	0x20049d48

20020e60 <_write>:
20020e60:	2802      	cmp	r0, #2
20020e62:	b510      	push	{r4, lr}
20020e64:	4614      	mov	r4, r2
20020e66:	dc04      	bgt.n	20020e72 <_write+0x12>
20020e68:	4803      	ldr	r0, [pc, #12]	@ (20020e78 <_write+0x18>)
20020e6a:	f7ff fa13 	bl	20020294 <boot_uart_tx>
20020e6e:	4620      	mov	r0, r4
20020e70:	bd10      	pop	{r4, pc}
20020e72:	f04f 34ff 	mov.w	r4, #4294967295
20020e76:	e7fa      	b.n	20020e6e <_write+0xe>
20020e78:	50084000 	.word	0x50084000

20020e7c <entry>:
20020e7c:	b508      	push	{r3, lr}
20020e7e:	f000 fb89 	bl	20021594 <sboot_init>
20020e82:	f7ff fb44 	bl	2002050e <board_init>
20020e86:	f7ff fb3b 	bl	20020500 <board_boot_from>
20020e8a:	4b04      	ldr	r3, [pc, #16]	@ (20020e9c <entry+0x20>)
20020e8c:	7018      	strb	r0, [r3, #0]
20020e8e:	f7ff fd47 	bl	20020920 <boot_device_init>
20020e92:	b108      	cbz	r0, 20020e98 <entry+0x1c>
20020e94:	f7ff ff26 	bl	20020ce4 <boot_images_help>
20020e98:	e7fe      	b.n	20020e98 <entry+0x1c>
20020e9a:	bf00      	nop
20020e9c:	20044a24 	.word	0x20044a24

20020ea0 <sd1_init>:
20020ea0:	b510      	push	{r4, lr}
20020ea2:	f04f 44a0 	mov.w	r4, #1342177280	@ 0x50000000
20020ea6:	68e3      	ldr	r3, [r4, #12]
20020ea8:	2064      	movs	r0, #100	@ 0x64
20020eaa:	f023 0310 	bic.w	r3, r3, #16
20020eae:	60e3      	str	r3, [r4, #12]
20020eb0:	f000 fd9f 	bl	200219f2 <HAL_Delay_us>
20020eb4:	f44f 7280 	mov.w	r2, #256	@ 0x100
20020eb8:	68e3      	ldr	r3, [r4, #12]
20020eba:	f043 0310 	orr.w	r3, r3, #16
20020ebe:	60e3      	str	r3, [r4, #12]
20020ec0:	4b02      	ldr	r3, [pc, #8]	@ (20020ecc <sd1_init+0x2c>)
20020ec2:	631a      	str	r2, [r3, #48]	@ 0x30
20020ec4:	2200      	movs	r2, #0
20020ec6:	63da      	str	r2, [r3, #60]	@ 0x3c
20020ec8:	bd10      	pop	{r4, pc}
20020eca:	bf00      	nop
20020ecc:	50045000 	.word	0x50045000

20020ed0 <sd1_wait_cmd>:
20020ed0:	4b08      	ldr	r3, [pc, #32]	@ (20020ef4 <sd1_wait_cmd+0x24>)
20020ed2:	681a      	ldr	r2, [r3, #0]
20020ed4:	f012 0f0a 	tst.w	r2, #10
20020ed8:	d0fb      	beq.n	20020ed2 <sd1_wait_cmd+0x2>
20020eda:	2202      	movs	r2, #2
20020edc:	601a      	str	r2, [r3, #0]
20020ede:	681a      	ldr	r2, [r3, #0]
20020ee0:	0712      	lsls	r2, r2, #28
20020ee2:	bf5f      	itttt	pl
20020ee4:	6818      	ldrpl	r0, [r3, #0]
20020ee6:	f3c0 0080 	ubfxpl	r0, r0, #2, #1
20020eea:	0040      	lslpl	r0, r0, #1
20020eec:	b2c0      	uxtbpl	r0, r0
20020eee:	bf48      	it	mi
20020ef0:	2001      	movmi	r0, #1
20020ef2:	4770      	bx	lr
20020ef4:	50045000 	.word	0x50045000

20020ef8 <sd1_send_cmd>:
20020ef8:	b538      	push	{r3, r4, r5, lr}
20020efa:	4604      	mov	r4, r0
20020efc:	460d      	mov	r5, r1
20020efe:	4b11      	ldr	r3, [pc, #68]	@ (20020f44 <sd1_send_cmd+0x4c>)
20020f00:	6818      	ldr	r0, [r3, #0]
20020f02:	f000 fd76 	bl	200219f2 <HAL_Delay_us>
20020f06:	4b10      	ldr	r3, [pc, #64]	@ (20020f48 <sd1_send_cmd+0x50>)
20020f08:	2c0f      	cmp	r4, #15
20020f0a:	609d      	str	r5, [r3, #8]
20020f0c:	ea4f 4384 	mov.w	r3, r4, lsl #18
20020f10:	d815      	bhi.n	20020f3e <sd1_send_cmd+0x46>
20020f12:	2201      	movs	r2, #1
20020f14:	f248 0111 	movw	r1, #32785	@ 0x8011
20020f18:	40a2      	lsls	r2, r4
20020f1a:	420a      	tst	r2, r1
20020f1c:	d105      	bne.n	20020f2a <sd1_send_cmd+0x32>
20020f1e:	f240 6104 	movw	r1, #1540	@ 0x604
20020f22:	420a      	tst	r2, r1
20020f24:	d00b      	beq.n	20020f3e <sd1_send_cmd+0x46>
20020f26:	f443 3340 	orr.w	r3, r3, #196608	@ 0x30000
20020f2a:	4a07      	ldr	r2, [pc, #28]	@ (20020f48 <sd1_send_cmd+0x50>)
20020f2c:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
20020f30:	f043 0301 	orr.w	r3, r3, #1
20020f34:	6053      	str	r3, [r2, #4]
20020f36:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20020f3a:	f7ff bfc9 	b.w	20020ed0 <sd1_wait_cmd>
20020f3e:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20020f42:	e7f2      	b.n	20020f2a <sd1_send_cmd+0x32>
20020f44:	20042c08 	.word	0x20042c08
20020f48:	50045000 	.word	0x50045000

20020f4c <sd1_send_acmd>:
20020f4c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20020f4e:	4605      	mov	r5, r0
20020f50:	460f      	mov	r7, r1
20020f52:	2037      	movs	r0, #55	@ 0x37
20020f54:	0411      	lsls	r1, r2, #16
20020f56:	f7ff ffcf 	bl	20020ef8 <sd1_send_cmd>
20020f5a:	4604      	mov	r4, r0
20020f5c:	b968      	cbnz	r0, 20020f7a <sd1_send_acmd+0x2e>
20020f5e:	4b08      	ldr	r3, [pc, #32]	@ (20020f80 <sd1_send_acmd+0x34>)
20020f60:	4e08      	ldr	r6, [pc, #32]	@ (20020f84 <sd1_send_acmd+0x38>)
20020f62:	ea43 4385 	orr.w	r3, r3, r5, lsl #18
20020f66:	60b7      	str	r7, [r6, #8]
20020f68:	6073      	str	r3, [r6, #4]
20020f6a:	f7ff ffb1 	bl	20020ed0 <sd1_wait_cmd>
20020f6e:	2802      	cmp	r0, #2
20020f70:	d104      	bne.n	20020f7c <sd1_send_acmd+0x30>
20020f72:	2d29      	cmp	r5, #41	@ 0x29
20020f74:	d102      	bne.n	20020f7c <sd1_send_acmd+0x30>
20020f76:	2304      	movs	r3, #4
20020f78:	6033      	str	r3, [r6, #0]
20020f7a:	4620      	mov	r0, r4
20020f7c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20020f7e:	bf00      	nop
20020f80:	00010101 	.word	0x00010101
20020f84:	50045000 	.word	0x50045000

20020f88 <sd1_get_rsp>:
20020f88:	b530      	push	{r4, r5, lr}
20020f8a:	4c06      	ldr	r4, [pc, #24]	@ (20020fa4 <sd1_get_rsp+0x1c>)
20020f8c:	68e5      	ldr	r5, [r4, #12]
20020f8e:	7005      	strb	r5, [r0, #0]
20020f90:	6920      	ldr	r0, [r4, #16]
20020f92:	6008      	str	r0, [r1, #0]
20020f94:	6961      	ldr	r1, [r4, #20]
20020f96:	6011      	str	r1, [r2, #0]
20020f98:	69a2      	ldr	r2, [r4, #24]
20020f9a:	601a      	str	r2, [r3, #0]
20020f9c:	69e2      	ldr	r2, [r4, #28]
20020f9e:	9b03      	ldr	r3, [sp, #12]
20020fa0:	601a      	str	r2, [r3, #0]
20020fa2:	bd30      	pop	{r4, r5, pc}
20020fa4:	50045000 	.word	0x50045000

20020fa8 <sd1_read>:
20020fa8:	f04f 33ff 	mov.w	r3, #4294967295
20020fac:	4a04      	ldr	r2, [pc, #16]	@ (20020fc0 <sd1_read+0x18>)
20020fae:	eb03 2341 	add.w	r3, r3, r1, lsl #9
20020fb2:	6293      	str	r3, [r2, #40]	@ 0x28
20020fb4:	4b03      	ldr	r3, [pc, #12]	@ (20020fc4 <sd1_read+0x1c>)
20020fb6:	ea43 23c0 	orr.w	r3, r3, r0, lsl #11
20020fba:	6253      	str	r3, [r2, #36]	@ 0x24
20020fbc:	4770      	bx	lr
20020fbe:	bf00      	nop
20020fc0:	50045000 	.word	0x50045000
20020fc4:	01ff0301 	.word	0x01ff0301

20020fc8 <sd1_wait_read>:
20020fc8:	4b08      	ldr	r3, [pc, #32]	@ (20020fec <sd1_wait_read+0x24>)
20020fca:	681a      	ldr	r2, [r3, #0]
20020fcc:	f012 0fe0 	tst.w	r2, #224	@ 0xe0
20020fd0:	d0fb      	beq.n	20020fca <sd1_wait_read+0x2>
20020fd2:	2220      	movs	r2, #32
20020fd4:	601a      	str	r2, [r3, #0]
20020fd6:	681a      	ldr	r2, [r3, #0]
20020fd8:	0612      	lsls	r2, r2, #24
20020fda:	bf5f      	itttt	pl
20020fdc:	6818      	ldrpl	r0, [r3, #0]
20020fde:	f3c0 1080 	ubfxpl	r0, r0, #6, #1
20020fe2:	0040      	lslpl	r0, r0, #1
20020fe4:	b2c0      	uxtbpl	r0, r0
20020fe6:	bf48      	it	mi
20020fe8:	2001      	movmi	r0, #1
20020fea:	4770      	bx	lr
20020fec:	50045000 	.word	0x50045000

20020ff0 <sdio_emmc_init>:
20020ff0:	b530      	push	{r4, r5, lr}
20020ff2:	b08d      	sub	sp, #52	@ 0x34
20020ff4:	f7ff ff54 	bl	20020ea0 <sd1_init>
20020ff8:	4c6c      	ldr	r4, [pc, #432]	@ (200211ac <sdio_emmc_init+0x1bc>)
20020ffa:	4b6d      	ldr	r3, [pc, #436]	@ (200211b0 <sdio_emmc_init+0x1c0>)
20020ffc:	2500      	movs	r5, #0
20020ffe:	6323      	str	r3, [r4, #48]	@ 0x30
20021000:	6b23      	ldr	r3, [r4, #48]	@ 0x30
20021002:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021006:	f043 0302 	orr.w	r3, r3, #2
2002100a:	6323      	str	r3, [r4, #48]	@ 0x30
2002100c:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
20021010:	62e5      	str	r5, [r4, #44]	@ 0x2c
20021012:	6223      	str	r3, [r4, #32]
20021014:	f000 fced 	bl	200219f2 <HAL_Delay_us>
20021018:	4629      	mov	r1, r5
2002101a:	4628      	mov	r0, r5
2002101c:	f7ff ff6c 	bl	20020ef8 <sd1_send_cmd>
20021020:	2301      	movs	r3, #1
20021022:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021024:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021026:	0799      	lsls	r1, r3, #30
20021028:	d5fc      	bpl.n	20021024 <sdio_emmc_init+0x34>
2002102a:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
2002102c:	f043 0320 	orr.w	r3, r3, #32
20021030:	63e3      	str	r3, [r4, #60]	@ 0x3c
20021032:	4960      	ldr	r1, [pc, #384]	@ (200211b4 <sdio_emmc_init+0x1c4>)
20021034:	2001      	movs	r0, #1
20021036:	ad07      	add	r5, sp, #28
20021038:	f7ff ff5e 	bl	20020ef8 <sd1_send_cmd>
2002103c:	ab06      	add	r3, sp, #24
2002103e:	aa05      	add	r2, sp, #20
20021040:	a904      	add	r1, sp, #16
20021042:	f10d 000f 	add.w	r0, sp, #15
20021046:	9500      	str	r5, [sp, #0]
20021048:	f7ff ff9e 	bl	20020f88 <sd1_get_rsp>
2002104c:	2014      	movs	r0, #20
2002104e:	f000 fcd0 	bl	200219f2 <HAL_Delay_us>
20021052:	9b04      	ldr	r3, [sp, #16]
20021054:	2b00      	cmp	r3, #0
20021056:	daec      	bge.n	20021032 <sdio_emmc_init+0x42>
20021058:	4a57      	ldr	r2, [pc, #348]	@ (200211b8 <sdio_emmc_init+0x1c8>)
2002105a:	f3c3 7380 	ubfx	r3, r3, #30, #1
2002105e:	f083 0301 	eor.w	r3, r3, #1
20021062:	2100      	movs	r1, #0
20021064:	2002      	movs	r0, #2
20021066:	7013      	strb	r3, [r2, #0]
20021068:	f7ff ff46 	bl	20020ef8 <sd1_send_cmd>
2002106c:	2801      	cmp	r0, #1
2002106e:	f000 8081 	beq.w	20021174 <sdio_emmc_init+0x184>
20021072:	2802      	cmp	r0, #2
20021074:	d07e      	beq.n	20021174 <sdio_emmc_init+0x184>
20021076:	ab08      	add	r3, sp, #32
20021078:	9300      	str	r3, [sp, #0]
2002107a:	aa0a      	add	r2, sp, #40	@ 0x28
2002107c:	ab09      	add	r3, sp, #36	@ 0x24
2002107e:	a90b      	add	r1, sp, #44	@ 0x2c
20021080:	f10d 000f 	add.w	r0, sp, #15
20021084:	f7ff ff80 	bl	20020f88 <sd1_get_rsp>
20021088:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
2002108c:	2003      	movs	r0, #3
2002108e:	f7ff ff33 	bl	20020ef8 <sd1_send_cmd>
20021092:	2801      	cmp	r0, #1
20021094:	d070      	beq.n	20021178 <sdio_emmc_init+0x188>
20021096:	2802      	cmp	r0, #2
20021098:	d070      	beq.n	2002117c <sdio_emmc_init+0x18c>
2002109a:	ab06      	add	r3, sp, #24
2002109c:	9500      	str	r5, [sp, #0]
2002109e:	aa05      	add	r2, sp, #20
200210a0:	a904      	add	r1, sp, #16
200210a2:	f10d 000f 	add.w	r0, sp, #15
200210a6:	f7ff ff6f 	bl	20020f88 <sd1_get_rsp>
200210aa:	f89d 300f 	ldrb.w	r3, [sp, #15]
200210ae:	2b03      	cmp	r3, #3
200210b0:	d166      	bne.n	20021180 <sdio_emmc_init+0x190>
200210b2:	4c3e      	ldr	r4, [pc, #248]	@ (200211ac <sdio_emmc_init+0x1bc>)
200210b4:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210b8:	6be3      	ldr	r3, [r4, #60]	@ 0x3c
200210ba:	2009      	movs	r0, #9
200210bc:	f023 0320 	bic.w	r3, r3, #32
200210c0:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210c2:	f7ff ff19 	bl	20020ef8 <sd1_send_cmd>
200210c6:	2801      	cmp	r0, #1
200210c8:	d05c      	beq.n	20021184 <sdio_emmc_init+0x194>
200210ca:	2802      	cmp	r0, #2
200210cc:	d05c      	beq.n	20021188 <sdio_emmc_init+0x198>
200210ce:	ab06      	add	r3, sp, #24
200210d0:	aa05      	add	r2, sp, #20
200210d2:	a904      	add	r1, sp, #16
200210d4:	f10d 000f 	add.w	r0, sp, #15
200210d8:	9500      	str	r5, [sp, #0]
200210da:	f7ff ff55 	bl	20020f88 <sd1_get_rsp>
200210de:	f44f 53b8 	mov.w	r3, #5888	@ 0x1700
200210e2:	6323      	str	r3, [r4, #48]	@ 0x30
200210e4:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200210e6:	f44f 3180 	mov.w	r1, #65536	@ 0x10000
200210ea:	f043 0302 	orr.w	r3, r3, #2
200210ee:	6323      	str	r3, [r4, #48]	@ 0x30
200210f0:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200210f4:	6223      	str	r3, [r4, #32]
200210f6:	2300      	movs	r3, #0
200210f8:	2007      	movs	r0, #7
200210fa:	63e3      	str	r3, [r4, #60]	@ 0x3c
200210fc:	f7ff fefc 	bl	20020ef8 <sd1_send_cmd>
20021100:	2801      	cmp	r0, #1
20021102:	d043      	beq.n	2002118c <sdio_emmc_init+0x19c>
20021104:	2802      	cmp	r0, #2
20021106:	d043      	beq.n	20021190 <sdio_emmc_init+0x1a0>
20021108:	ab06      	add	r3, sp, #24
2002110a:	9500      	str	r5, [sp, #0]
2002110c:	aa05      	add	r2, sp, #20
2002110e:	a904      	add	r1, sp, #16
20021110:	f10d 000f 	add.w	r0, sp, #15
20021114:	f7ff ff38 	bl	20020f88 <sd1_get_rsp>
20021118:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002111c:	2b07      	cmp	r3, #7
2002111e:	d139      	bne.n	20021194 <sdio_emmc_init+0x1a4>
20021120:	2101      	movs	r1, #1
20021122:	2000      	movs	r0, #0
20021124:	f7ff ff40 	bl	20020fa8 <sd1_read>
20021128:	f04f 33ff 	mov.w	r3, #4294967295
2002112c:	2100      	movs	r1, #0
2002112e:	2011      	movs	r0, #17
20021130:	6023      	str	r3, [r4, #0]
20021132:	f7ff fee1 	bl	20020ef8 <sd1_send_cmd>
20021136:	2801      	cmp	r0, #1
20021138:	d02e      	beq.n	20021198 <sdio_emmc_init+0x1a8>
2002113a:	2802      	cmp	r0, #2
2002113c:	d02e      	beq.n	2002119c <sdio_emmc_init+0x1ac>
2002113e:	ab06      	add	r3, sp, #24
20021140:	9500      	str	r5, [sp, #0]
20021142:	aa05      	add	r2, sp, #20
20021144:	a904      	add	r1, sp, #16
20021146:	f10d 000f 	add.w	r0, sp, #15
2002114a:	f7ff ff1d 	bl	20020f88 <sd1_get_rsp>
2002114e:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021152:	2b11      	cmp	r3, #17
20021154:	d124      	bne.n	200211a0 <sdio_emmc_init+0x1b0>
20021156:	2320      	movs	r3, #32
20021158:	62e3      	str	r3, [r4, #44]	@ 0x2c
2002115a:	f7ff ff35 	bl	20020fc8 <sd1_wait_read>
2002115e:	6823      	ldr	r3, [r4, #0]
20021160:	061a      	lsls	r2, r3, #24
20021162:	d41f      	bmi.n	200211a4 <sdio_emmc_init+0x1b4>
20021164:	6823      	ldr	r3, [r4, #0]
20021166:	065b      	lsls	r3, r3, #25
20021168:	d41e      	bmi.n	200211a8 <sdio_emmc_init+0x1b8>
2002116a:	2080      	movs	r0, #128	@ 0x80
2002116c:	3801      	subs	r0, #1
2002116e:	f8d4 3200 	ldr.w	r3, [r4, #512]	@ 0x200
20021172:	d1fb      	bne.n	2002116c <sdio_emmc_init+0x17c>
20021174:	b00d      	add	sp, #52	@ 0x34
20021176:	bd30      	pop	{r4, r5, pc}
20021178:	2003      	movs	r0, #3
2002117a:	e7fb      	b.n	20021174 <sdio_emmc_init+0x184>
2002117c:	2004      	movs	r0, #4
2002117e:	e7f9      	b.n	20021174 <sdio_emmc_init+0x184>
20021180:	2005      	movs	r0, #5
20021182:	e7f7      	b.n	20021174 <sdio_emmc_init+0x184>
20021184:	2006      	movs	r0, #6
20021186:	e7f5      	b.n	20021174 <sdio_emmc_init+0x184>
20021188:	2007      	movs	r0, #7
2002118a:	e7f3      	b.n	20021174 <sdio_emmc_init+0x184>
2002118c:	2008      	movs	r0, #8
2002118e:	e7f1      	b.n	20021174 <sdio_emmc_init+0x184>
20021190:	2009      	movs	r0, #9
20021192:	e7ef      	b.n	20021174 <sdio_emmc_init+0x184>
20021194:	200a      	movs	r0, #10
20021196:	e7ed      	b.n	20021174 <sdio_emmc_init+0x184>
20021198:	2012      	movs	r0, #18
2002119a:	e7eb      	b.n	20021174 <sdio_emmc_init+0x184>
2002119c:	2013      	movs	r0, #19
2002119e:	e7e9      	b.n	20021174 <sdio_emmc_init+0x184>
200211a0:	2014      	movs	r0, #20
200211a2:	e7e7      	b.n	20021174 <sdio_emmc_init+0x184>
200211a4:	2015      	movs	r0, #21
200211a6:	e7e5      	b.n	20021174 <sdio_emmc_init+0x184>
200211a8:	2016      	movs	r0, #22
200211aa:	e7e3      	b.n	20021174 <sdio_emmc_init+0x184>
200211ac:	50045000 	.word	0x50045000
200211b0:	00016700 	.word	0x00016700
200211b4:	40000080 	.word	0x40000080
200211b8:	20042c0c 	.word	0x20042c0c

200211bc <emmc_read_data>:
200211bc:	b570      	push	{r4, r5, r6, lr}
200211be:	4606      	mov	r6, r0
200211c0:	460d      	mov	r5, r1
200211c2:	2000      	movs	r0, #0
200211c4:	2101      	movs	r1, #1
200211c6:	b088      	sub	sp, #32
200211c8:	4614      	mov	r4, r2
200211ca:	f7ff feed 	bl	20020fa8 <sd1_read>
200211ce:	f04f 32ff 	mov.w	r2, #4294967295
200211d2:	4b1c      	ldr	r3, [pc, #112]	@ (20021244 <emmc_read_data+0x88>)
200211d4:	601a      	str	r2, [r3, #0]
200211d6:	4b1c      	ldr	r3, [pc, #112]	@ (20021248 <emmc_read_data+0x8c>)
200211d8:	781b      	ldrb	r3, [r3, #0]
200211da:	b903      	cbnz	r3, 200211de <emmc_read_data+0x22>
200211dc:	0a76      	lsrs	r6, r6, #9
200211de:	4631      	mov	r1, r6
200211e0:	2011      	movs	r0, #17
200211e2:	f7ff fe89 	bl	20020ef8 <sd1_send_cmd>
200211e6:	3801      	subs	r0, #1
200211e8:	b2c0      	uxtb	r0, r0
200211ea:	2801      	cmp	r0, #1
200211ec:	d802      	bhi.n	200211f4 <emmc_read_data+0x38>
200211ee:	2000      	movs	r0, #0
200211f0:	b008      	add	sp, #32
200211f2:	bd70      	pop	{r4, r5, r6, pc}
200211f4:	ab07      	add	r3, sp, #28
200211f6:	9300      	str	r3, [sp, #0]
200211f8:	aa05      	add	r2, sp, #20
200211fa:	ab06      	add	r3, sp, #24
200211fc:	a904      	add	r1, sp, #16
200211fe:	f10d 000f 	add.w	r0, sp, #15
20021202:	f7ff fec1 	bl	20020f88 <sd1_get_rsp>
20021206:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002120a:	2b11      	cmp	r3, #17
2002120c:	d1ef      	bne.n	200211ee <emmc_read_data+0x32>
2002120e:	f04f 33ff 	mov.w	r3, #4294967295
20021212:	4e0c      	ldr	r6, [pc, #48]	@ (20021244 <emmc_read_data+0x88>)
20021214:	6033      	str	r3, [r6, #0]
20021216:	2320      	movs	r3, #32
20021218:	62f3      	str	r3, [r6, #44]	@ 0x2c
2002121a:	f7ff fed5 	bl	20020fc8 <sd1_wait_read>
2002121e:	6833      	ldr	r3, [r6, #0]
20021220:	061a      	lsls	r2, r3, #24
20021222:	d4e4      	bmi.n	200211ee <emmc_read_data+0x32>
20021224:	6833      	ldr	r3, [r6, #0]
20021226:	065b      	lsls	r3, r3, #25
20021228:	d4e1      	bmi.n	200211ee <emmc_read_data+0x32>
2002122a:	f024 0303 	bic.w	r3, r4, #3
2002122e:	442b      	add	r3, r5
20021230:	429d      	cmp	r5, r3
20021232:	d101      	bne.n	20021238 <emmc_read_data+0x7c>
20021234:	4620      	mov	r0, r4
20021236:	e7db      	b.n	200211f0 <emmc_read_data+0x34>
20021238:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
2002123c:	f845 2b04 	str.w	r2, [r5], #4
20021240:	e7f6      	b.n	20021230 <emmc_read_data+0x74>
20021242:	bf00      	nop
20021244:	50045000 	.word	0x50045000
20021248:	20042c0c 	.word	0x20042c0c

2002124c <sdio_sd_init>:
2002124c:	b5f0      	push	{r4, r5, r6, r7, lr}
2002124e:	b08d      	sub	sp, #52	@ 0x34
20021250:	f7ff fe26 	bl	20020ea0 <sd1_init>
20021254:	4c83      	ldr	r4, [pc, #524]	@ (20021464 <sdio_sd_init+0x218>)
20021256:	4b84      	ldr	r3, [pc, #528]	@ (20021468 <sdio_sd_init+0x21c>)
20021258:	2500      	movs	r5, #0
2002125a:	6323      	str	r3, [r4, #48]	@ 0x30
2002125c:	6b23      	ldr	r3, [r4, #48]	@ 0x30
2002125e:	f44f 70fa 	mov.w	r0, #500	@ 0x1f4
20021262:	f043 0302 	orr.w	r3, r3, #2
20021266:	6323      	str	r3, [r4, #48]	@ 0x30
20021268:	f44f 2300 	mov.w	r3, #524288	@ 0x80000
2002126c:	62e5      	str	r5, [r4, #44]	@ 0x2c
2002126e:	6223      	str	r3, [r4, #32]
20021270:	f000 fbbf 	bl	200219f2 <HAL_Delay_us>
20021274:	4629      	mov	r1, r5
20021276:	4628      	mov	r0, r5
20021278:	f7ff fe3e 	bl	20020ef8 <sd1_send_cmd>
2002127c:	2301      	movs	r3, #1
2002127e:	65e3      	str	r3, [r4, #92]	@ 0x5c
20021280:	6de3      	ldr	r3, [r4, #92]	@ 0x5c
20021282:	079a      	lsls	r2, r3, #30
20021284:	d5fc      	bpl.n	20021280 <sdio_sd_init+0x34>
20021286:	f44f 71d5 	mov.w	r1, #426	@ 0x1aa
2002128a:	2008      	movs	r0, #8
2002128c:	f7ff fe34 	bl	20020ef8 <sd1_send_cmd>
20021290:	3801      	subs	r0, #1
20021292:	b2c0      	uxtb	r0, r0
20021294:	2801      	cmp	r0, #1
20021296:	d802      	bhi.n	2002129e <sdio_sd_init+0x52>
20021298:	2038      	movs	r0, #56	@ 0x38
2002129a:	b00d      	add	sp, #52	@ 0x34
2002129c:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002129e:	ac07      	add	r4, sp, #28
200212a0:	ab06      	add	r3, sp, #24
200212a2:	9400      	str	r4, [sp, #0]
200212a4:	aa05      	add	r2, sp, #20
200212a6:	a904      	add	r1, sp, #16
200212a8:	f10d 000f 	add.w	r0, sp, #15
200212ac:	f7ff fe6c 	bl	20020f88 <sd1_get_rsp>
200212b0:	f89d 300f 	ldrb.w	r3, [sp, #15]
200212b4:	2b08      	cmp	r3, #8
200212b6:	d1ef      	bne.n	20021298 <sdio_sd_init+0x4c>
200212b8:	9b04      	ldr	r3, [sp, #16]
200212ba:	f5b3 7fd5 	cmp.w	r3, #426	@ 0x1aa
200212be:	d1eb      	bne.n	20021298 <sdio_sd_init+0x4c>
200212c0:	2200      	movs	r2, #0
200212c2:	2029      	movs	r0, #41	@ 0x29
200212c4:	4969      	ldr	r1, [pc, #420]	@ (2002146c <sdio_sd_init+0x220>)
200212c6:	f7ff fe41 	bl	20020f4c <sd1_send_acmd>
200212ca:	2801      	cmp	r0, #1
200212cc:	f000 80bd 	beq.w	2002144a <sdio_sd_init+0x1fe>
200212d0:	ab06      	add	r3, sp, #24
200212d2:	9400      	str	r4, [sp, #0]
200212d4:	aa05      	add	r2, sp, #20
200212d6:	a904      	add	r1, sp, #16
200212d8:	f10d 000f 	add.w	r0, sp, #15
200212dc:	f7ff fe54 	bl	20020f88 <sd1_get_rsp>
200212e0:	9b04      	ldr	r3, [sp, #16]
200212e2:	2b00      	cmp	r3, #0
200212e4:	db03      	blt.n	200212ee <sdio_sd_init+0xa2>
200212e6:	2002      	movs	r0, #2
200212e8:	f000 fb83 	bl	200219f2 <HAL_Delay_us>
200212ec:	e7e8      	b.n	200212c0 <sdio_sd_init+0x74>
200212ee:	2100      	movs	r1, #0
200212f0:	2002      	movs	r0, #2
200212f2:	f7ff fe01 	bl	20020ef8 <sd1_send_cmd>
200212f6:	3801      	subs	r0, #1
200212f8:	b2c0      	uxtb	r0, r0
200212fa:	2801      	cmp	r0, #1
200212fc:	f240 80a7 	bls.w	2002144e <sdio_sd_init+0x202>
20021300:	ab08      	add	r3, sp, #32
20021302:	9300      	str	r3, [sp, #0]
20021304:	aa0a      	add	r2, sp, #40	@ 0x28
20021306:	ab09      	add	r3, sp, #36	@ 0x24
20021308:	a90b      	add	r1, sp, #44	@ 0x2c
2002130a:	f10d 000f 	add.w	r0, sp, #15
2002130e:	f7ff fe3b 	bl	20020f88 <sd1_get_rsp>
20021312:	2100      	movs	r1, #0
20021314:	2003      	movs	r0, #3
20021316:	f7ff fdef 	bl	20020ef8 <sd1_send_cmd>
2002131a:	3801      	subs	r0, #1
2002131c:	b2c0      	uxtb	r0, r0
2002131e:	2801      	cmp	r0, #1
20021320:	d801      	bhi.n	20021326 <sdio_sd_init+0xda>
20021322:	2033      	movs	r0, #51	@ 0x33
20021324:	e7b9      	b.n	2002129a <sdio_sd_init+0x4e>
20021326:	ab06      	add	r3, sp, #24
20021328:	9400      	str	r4, [sp, #0]
2002132a:	aa05      	add	r2, sp, #20
2002132c:	a904      	add	r1, sp, #16
2002132e:	f10d 000f 	add.w	r0, sp, #15
20021332:	f7ff fe29 	bl	20020f88 <sd1_get_rsp>
20021336:	f89d 300f 	ldrb.w	r3, [sp, #15]
2002133a:	2b03      	cmp	r3, #3
2002133c:	d1f1      	bne.n	20021322 <sdio_sd_init+0xd6>
2002133e:	9f04      	ldr	r7, [sp, #16]
20021340:	2009      	movs	r0, #9
20021342:	0c3d      	lsrs	r5, r7, #16
20021344:	042d      	lsls	r5, r5, #16
20021346:	4629      	mov	r1, r5
20021348:	f7ff fdd6 	bl	20020ef8 <sd1_send_cmd>
2002134c:	3801      	subs	r0, #1
2002134e:	b2c0      	uxtb	r0, r0
20021350:	2801      	cmp	r0, #1
20021352:	d97e      	bls.n	20021452 <sdio_sd_init+0x206>
20021354:	9400      	str	r4, [sp, #0]
20021356:	ab06      	add	r3, sp, #24
20021358:	aa05      	add	r2, sp, #20
2002135a:	a904      	add	r1, sp, #16
2002135c:	f10d 000f 	add.w	r0, sp, #15
20021360:	f7ff fe12 	bl	20020f88 <sd1_get_rsp>
20021364:	e9dd 2004 	ldrd	r2, r0, [sp, #16]
20021368:	9c06      	ldr	r4, [sp, #24]
2002136a:	9907      	ldr	r1, [sp, #28]
2002136c:	0e23      	lsrs	r3, r4, #24
2002136e:	ea43 2301 	orr.w	r3, r3, r1, lsl #8
20021372:	0e01      	lsrs	r1, r0, #24
20021374:	ea41 2104 	orr.w	r1, r1, r4, lsl #8
20021378:	9105      	str	r1, [sp, #20]
2002137a:	0e11      	lsrs	r1, r2, #24
2002137c:	9304      	str	r3, [sp, #16]
2002137e:	ea41 2100 	orr.w	r1, r1, r0, lsl #8
20021382:	0212      	lsls	r2, r2, #8
20021384:	0f9b      	lsrs	r3, r3, #30
20021386:	9106      	str	r1, [sp, #24]
20021388:	9207      	str	r2, [sp, #28]
2002138a:	d01b      	beq.n	200213c4 <sdio_sd_init+0x178>
2002138c:	2b01      	cmp	r3, #1
2002138e:	d162      	bne.n	20021456 <sdio_sd_init+0x20a>
20021390:	2300      	movs	r3, #0
20021392:	4a37      	ldr	r2, [pc, #220]	@ (20021470 <sdio_sd_init+0x224>)
20021394:	4c33      	ldr	r4, [pc, #204]	@ (20021464 <sdio_sd_init+0x218>)
20021396:	7013      	strb	r3, [r2, #0]
20021398:	f44f 63a0 	mov.w	r3, #1280	@ 0x500
2002139c:	6323      	str	r3, [r4, #48]	@ 0x30
2002139e:	6b23      	ldr	r3, [r4, #48]	@ 0x30
200213a0:	2600      	movs	r6, #0
200213a2:	f043 0302 	orr.w	r3, r3, #2
200213a6:	6323      	str	r3, [r4, #48]	@ 0x30
200213a8:	f04f 7300 	mov.w	r3, #33554432	@ 0x2000000
200213ac:	4629      	mov	r1, r5
200213ae:	6223      	str	r3, [r4, #32]
200213b0:	2007      	movs	r0, #7
200213b2:	63e6      	str	r6, [r4, #60]	@ 0x3c
200213b4:	f7ff fda0 	bl	20020ef8 <sd1_send_cmd>
200213b8:	3801      	subs	r0, #1
200213ba:	b2c0      	uxtb	r0, r0
200213bc:	2801      	cmp	r0, #1
200213be:	d803      	bhi.n	200213c8 <sdio_sd_init+0x17c>
200213c0:	2037      	movs	r0, #55	@ 0x37
200213c2:	e76a      	b.n	2002129a <sdio_sd_init+0x4e>
200213c4:	2301      	movs	r3, #1
200213c6:	e7e4      	b.n	20021392 <sdio_sd_init+0x146>
200213c8:	ad07      	add	r5, sp, #28
200213ca:	ab06      	add	r3, sp, #24
200213cc:	9500      	str	r5, [sp, #0]
200213ce:	aa05      	add	r2, sp, #20
200213d0:	a904      	add	r1, sp, #16
200213d2:	f10d 000f 	add.w	r0, sp, #15
200213d6:	f7ff fdd7 	bl	20020f88 <sd1_get_rsp>
200213da:	f89d 300f 	ldrb.w	r3, [sp, #15]
200213de:	2b07      	cmp	r3, #7
200213e0:	d1ee      	bne.n	200213c0 <sdio_sd_init+0x174>
200213e2:	4631      	mov	r1, r6
200213e4:	2006      	movs	r0, #6
200213e6:	0c3a      	lsrs	r2, r7, #16
200213e8:	f7ff fdb0 	bl	20020f4c <sd1_send_acmd>
200213ec:	3801      	subs	r0, #1
200213ee:	b2c0      	uxtb	r0, r0
200213f0:	2801      	cmp	r0, #1
200213f2:	d932      	bls.n	2002145a <sdio_sd_init+0x20e>
200213f4:	2101      	movs	r1, #1
200213f6:	4630      	mov	r0, r6
200213f8:	f7ff fdd6 	bl	20020fa8 <sd1_read>
200213fc:	4631      	mov	r1, r6
200213fe:	2011      	movs	r0, #17
20021400:	f7ff fd7a 	bl	20020ef8 <sd1_send_cmd>
20021404:	3801      	subs	r0, #1
20021406:	b2c0      	uxtb	r0, r0
20021408:	2801      	cmp	r0, #1
2002140a:	d801      	bhi.n	20021410 <sdio_sd_init+0x1c4>
2002140c:	2052      	movs	r0, #82	@ 0x52
2002140e:	e744      	b.n	2002129a <sdio_sd_init+0x4e>
20021410:	ab06      	add	r3, sp, #24
20021412:	9500      	str	r5, [sp, #0]
20021414:	aa05      	add	r2, sp, #20
20021416:	a904      	add	r1, sp, #16
20021418:	f10d 000f 	add.w	r0, sp, #15
2002141c:	f7ff fdb4 	bl	20020f88 <sd1_get_rsp>
20021420:	f89d 300f 	ldrb.w	r3, [sp, #15]
20021424:	2b11      	cmp	r3, #17
20021426:	d1f1      	bne.n	2002140c <sdio_sd_init+0x1c0>
20021428:	f04f 33ff 	mov.w	r3, #4294967295
2002142c:	6023      	str	r3, [r4, #0]
2002142e:	2320      	movs	r3, #32
20021430:	62e3      	str	r3, [r4, #44]	@ 0x2c
20021432:	f7ff fdc9 	bl	20020fc8 <sd1_wait_read>
20021436:	6823      	ldr	r3, [r4, #0]
20021438:	061b      	lsls	r3, r3, #24
2002143a:	d410      	bmi.n	2002145e <sdio_sd_init+0x212>
2002143c:	6823      	ldr	r3, [r4, #0]
2002143e:	f013 0f40 	tst.w	r3, #64	@ 0x40
20021442:	bf14      	ite	ne
20021444:	2044      	movne	r0, #68	@ 0x44
20021446:	2001      	moveq	r0, #1
20021448:	e727      	b.n	2002129a <sdio_sd_init+0x4e>
2002144a:	2034      	movs	r0, #52	@ 0x34
2002144c:	e725      	b.n	2002129a <sdio_sd_init+0x4e>
2002144e:	2032      	movs	r0, #50	@ 0x32
20021450:	e723      	b.n	2002129a <sdio_sd_init+0x4e>
20021452:	2039      	movs	r0, #57	@ 0x39
20021454:	e721      	b.n	2002129a <sdio_sd_init+0x4e>
20021456:	2054      	movs	r0, #84	@ 0x54
20021458:	e71f      	b.n	2002129a <sdio_sd_init+0x4e>
2002145a:	2036      	movs	r0, #54	@ 0x36
2002145c:	e71d      	b.n	2002129a <sdio_sd_init+0x4e>
2002145e:	204f      	movs	r0, #79	@ 0x4f
20021460:	e71b      	b.n	2002129a <sdio_sd_init+0x4e>
20021462:	bf00      	nop
20021464:	50045000 	.word	0x50045000
20021468:	00016700 	.word	0x00016700
2002146c:	40ff8000 	.word	0x40ff8000
20021470:	20042c0d 	.word	0x20042c0d

20021474 <sd_read_data>:
20021474:	b570      	push	{r4, r5, r6, lr}
20021476:	4606      	mov	r6, r0
20021478:	460d      	mov	r5, r1
2002147a:	2000      	movs	r0, #0
2002147c:	2101      	movs	r1, #1
2002147e:	b088      	sub	sp, #32
20021480:	4614      	mov	r4, r2
20021482:	f7ff fd91 	bl	20020fa8 <sd1_read>
20021486:	4b1b      	ldr	r3, [pc, #108]	@ (200214f4 <sd_read_data+0x80>)
20021488:	781b      	ldrb	r3, [r3, #0]
2002148a:	b903      	cbnz	r3, 2002148e <sd_read_data+0x1a>
2002148c:	0a76      	lsrs	r6, r6, #9
2002148e:	4631      	mov	r1, r6
20021490:	2011      	movs	r0, #17
20021492:	f7ff fd31 	bl	20020ef8 <sd1_send_cmd>
20021496:	3801      	subs	r0, #1
20021498:	b2c0      	uxtb	r0, r0
2002149a:	2801      	cmp	r0, #1
2002149c:	d802      	bhi.n	200214a4 <sd_read_data+0x30>
2002149e:	2000      	movs	r0, #0
200214a0:	b008      	add	sp, #32
200214a2:	bd70      	pop	{r4, r5, r6, pc}
200214a4:	ab07      	add	r3, sp, #28
200214a6:	9300      	str	r3, [sp, #0]
200214a8:	aa05      	add	r2, sp, #20
200214aa:	ab06      	add	r3, sp, #24
200214ac:	a904      	add	r1, sp, #16
200214ae:	f10d 000f 	add.w	r0, sp, #15
200214b2:	f7ff fd69 	bl	20020f88 <sd1_get_rsp>
200214b6:	f89d 300f 	ldrb.w	r3, [sp, #15]
200214ba:	2b11      	cmp	r3, #17
200214bc:	d1ef      	bne.n	2002149e <sd_read_data+0x2a>
200214be:	f04f 33ff 	mov.w	r3, #4294967295
200214c2:	4e0d      	ldr	r6, [pc, #52]	@ (200214f8 <sd_read_data+0x84>)
200214c4:	6033      	str	r3, [r6, #0]
200214c6:	2320      	movs	r3, #32
200214c8:	62f3      	str	r3, [r6, #44]	@ 0x2c
200214ca:	f7ff fd7d 	bl	20020fc8 <sd1_wait_read>
200214ce:	6833      	ldr	r3, [r6, #0]
200214d0:	061a      	lsls	r2, r3, #24
200214d2:	d4e4      	bmi.n	2002149e <sd_read_data+0x2a>
200214d4:	6833      	ldr	r3, [r6, #0]
200214d6:	065b      	lsls	r3, r3, #25
200214d8:	d4e1      	bmi.n	2002149e <sd_read_data+0x2a>
200214da:	f024 0303 	bic.w	r3, r4, #3
200214de:	442b      	add	r3, r5
200214e0:	429d      	cmp	r5, r3
200214e2:	d101      	bne.n	200214e8 <sd_read_data+0x74>
200214e4:	4620      	mov	r0, r4
200214e6:	e7db      	b.n	200214a0 <sd_read_data+0x2c>
200214e8:	f8d6 2200 	ldr.w	r2, [r6, #512]	@ 0x200
200214ec:	f845 2b04 	str.w	r2, [r5], #4
200214f0:	e7f6      	b.n	200214e0 <sd_read_data+0x6c>
200214f2:	bf00      	nop
200214f4:	20042c0d 	.word	0x20042c0d
200214f8:	50045000 	.word	0x50045000

200214fc <is_addr_in_nor>:
200214fc:	4b09      	ldr	r3, [pc, #36]	@ (20021524 <is_addr_in_nor+0x28>)
200214fe:	4602      	mov	r2, r0
20021500:	681b      	ldr	r3, [r3, #0]
20021502:	b163      	cbz	r3, 2002151e <is_addr_in_nor+0x22>
20021504:	f893 002b 	ldrb.w	r0, [r3, #43]	@ 0x2b
20021508:	b948      	cbnz	r0, 2002151e <is_addr_in_nor+0x22>
2002150a:	6919      	ldr	r1, [r3, #16]
2002150c:	4291      	cmp	r1, r2
2002150e:	d807      	bhi.n	20021520 <is_addr_in_nor+0x24>
20021510:	695b      	ldr	r3, [r3, #20]
20021512:	4419      	add	r1, r3
20021514:	4291      	cmp	r1, r2
20021516:	bf94      	ite	ls
20021518:	2000      	movls	r0, #0
2002151a:	2001      	movhi	r0, #1
2002151c:	4770      	bx	lr
2002151e:	2000      	movs	r0, #0
20021520:	4770      	bx	lr
20021522:	bf00      	nop
20021524:	20046d30 	.word	0x20046d30

20021528 <sifli_verify_img_cmac_hash>:
20021528:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
2002152c:	461d      	mov	r5, r3
2002152e:	4b16      	ldr	r3, [pc, #88]	@ (20021588 <sifli_verify_img_cmac_hash+0x60>)
20021530:	460e      	mov	r6, r1
20021532:	681b      	ldr	r3, [r3, #0]
20021534:	4617      	mov	r7, r2
20021536:	b092      	sub	sp, #72	@ 0x48
20021538:	b12b      	cbz	r3, 20021546 <sifli_verify_img_cmac_hash+0x1e>
2002153a:	b920      	cbnz	r0, 20021546 <sifli_verify_img_cmac_hash+0x1e>
2002153c:	2220      	movs	r2, #32
2002153e:	2002      	movs	r0, #2
20021540:	4912      	ldr	r1, [pc, #72]	@ (2002158c <sifli_verify_img_cmac_hash+0x64>)
20021542:	4798      	blx	r3
20021544:	4811      	ldr	r0, [pc, #68]	@ (2002158c <sifli_verify_img_cmac_hash+0x64>)
20021546:	4601      	mov	r1, r0
20021548:	2220      	movs	r2, #32
2002154a:	a803      	add	r0, sp, #12
2002154c:	f004 fa0c 	bl	20025968 <sf_crypto_aes_cmac_init>
20021550:	4604      	mov	r4, r0
20021552:	b100      	cbz	r0, 20021556 <sifli_verify_img_cmac_hash+0x2e>
20021554:	e7fe      	b.n	20021554 <sifli_verify_img_cmac_hash+0x2c>
20021556:	f8df 8038 	ldr.w	r8, [pc, #56]	@ 20021590 <sifli_verify_img_cmac_hash+0x68>
2002155a:	2301      	movs	r3, #1
2002155c:	463a      	mov	r2, r7
2002155e:	4631      	mov	r1, r6
20021560:	f8cd 8000 	str.w	r8, [sp]
20021564:	a803      	add	r0, sp, #12
20021566:	f004 fa3c 	bl	200259e2 <sf_crypto_aes_cmac_calc>
2002156a:	b950      	cbnz	r0, 20021582 <sifli_verify_img_cmac_hash+0x5a>
2002156c:	2210      	movs	r2, #16
2002156e:	4629      	mov	r1, r5
20021570:	4640      	mov	r0, r8
20021572:	f004 fe5f 	bl	20026234 <memcmp>
20021576:	fab0 f080 	clz	r0, r0
2002157a:	0940      	lsrs	r0, r0, #5
2002157c:	b012      	add	sp, #72	@ 0x48
2002157e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021582:	4620      	mov	r0, r4
20021584:	e7fa      	b.n	2002157c <sifli_verify_img_cmac_hash+0x54>
20021586:	bf00      	nop
20021588:	20047134 	.word	0x20047134
2002158c:	2004c960 	.word	0x2004c960
20021590:	2004c980 	.word	0x2004c980

20021594 <sboot_init>:
20021594:	b507      	push	{r0, r1, r2, lr}
20021596:	f7ff fb7d 	bl	20020c94 <sifli_hw_efuse_load_bank0>
2002159a:	b150      	cbz	r0, 200215b2 <sboot_init+0x1e>
2002159c:	2302      	movs	r3, #2
2002159e:	21ee      	movs	r1, #238	@ 0xee
200215a0:	f10d 0207 	add.w	r2, sp, #7
200215a4:	f006 fbb0 	bl	20027d08 <HAL_EFUSE_Extract>
200215a8:	2800      	cmp	r0, #0
200215aa:	dc08      	bgt.n	200215be <sboot_init+0x2a>
200215ac:	b003      	add	sp, #12
200215ae:	f85d fb04 	ldr.w	pc, [sp], #4
200215b2:	4807      	ldr	r0, [pc, #28]	@ (200215d0 <sboot_init+0x3c>)
200215b4:	b003      	add	sp, #12
200215b6:	f85d eb04 	ldr.w	lr, [sp], #4
200215ba:	f004 bd5d 	b.w	20026078 <puts>
200215be:	f89d 3007 	ldrb.w	r3, [sp, #7]
200215c2:	2b00      	cmp	r3, #0
200215c4:	d0f2      	beq.n	200215ac <sboot_init+0x18>
200215c6:	2201      	movs	r2, #1
200215c8:	4b02      	ldr	r3, [pc, #8]	@ (200215d4 <sboot_init+0x40>)
200215ca:	701a      	strb	r2, [r3, #0]
200215cc:	e7ee      	b.n	200215ac <sboot_init+0x18>
200215ce:	bf00      	nop
200215d0:	20026b04 	.word	0x20026b04
200215d4:	2004c95c 	.word	0x2004c95c

200215d8 <run_img>:
200215d8:	f8d0 d000 	ldr.w	sp, [r0]
200215dc:	f8d0 f004 	ldr.w	pc, [r0, #4]
200215e0:	4770      	bx	lr
	...

200215e4 <dfu_boot_img_in_flash>:
200215e4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200215e8:	4e27      	ldr	r6, [pc, #156]	@ (20021688 <dfu_boot_img_in_flash+0xa4>)
200215ea:	1e84      	subs	r4, r0, #2
200215ec:	eb06 1300 	add.w	r3, r6, r0, lsl #4
200215f0:	eb06 2040 	add.w	r0, r6, r0, lsl #9
200215f4:	f8d0 7c00 	ldr.w	r7, [r0, #3072]	@ 0xc00
200215f8:	f8d3 8004 	ldr.w	r8, [r3, #4]
200215fc:	68dd      	ldr	r5, [r3, #12]
200215fe:	b177      	cbz	r7, 2002161e <dfu_boot_img_in_flash+0x3a>
20021600:	45a8      	cmp	r8, r5
20021602:	d00c      	beq.n	2002161e <dfu_boot_img_in_flash+0x3a>
20021604:	4628      	mov	r0, r5
20021606:	f7ff ff79 	bl	200214fc <is_addr_in_nor>
2002160a:	b940      	cbnz	r0, 2002161e <dfu_boot_img_in_flash+0x3a>
2002160c:	4b1f      	ldr	r3, [pc, #124]	@ (2002168c <dfu_boot_img_in_flash+0xa8>)
2002160e:	4629      	mov	r1, r5
20021610:	781a      	ldrb	r2, [r3, #0]
20021612:	4b1f      	ldr	r3, [pc, #124]	@ (20021690 <dfu_boot_img_in_flash+0xac>)
20021614:	4640      	mov	r0, r8
20021616:	681b      	ldr	r3, [r3, #0]
20021618:	eb07 1202 	add.w	r2, r7, r2, lsl #4
2002161c:	4798      	blx	r3
2002161e:	2c07      	cmp	r4, #7
20021620:	dc30      	bgt.n	20021684 <dfu_boot_img_in_flash+0xa0>
20021622:	4263      	negs	r3, r4
20021624:	f003 0303 	and.w	r3, r3, #3
20021628:	f004 0703 	and.w	r7, r4, #3
2002162c:	bf58      	it	pl
2002162e:	425f      	negpl	r7, r3
20021630:	2f02      	cmp	r7, #2
20021632:	d827      	bhi.n	20021684 <dfu_boot_img_in_flash+0xa0>
20021634:	4628      	mov	r0, r5
20021636:	f7ff ff61 	bl	200214fc <is_addr_in_nor>
2002163a:	b150      	cbz	r0, 20021652 <dfu_boot_img_in_flash+0x6e>
2002163c:	4815      	ldr	r0, [pc, #84]	@ (20021694 <dfu_boot_img_in_flash+0xb0>)
2002163e:	f104 0208 	add.w	r2, r4, #8
20021642:	0252      	lsls	r2, r2, #9
20021644:	4629      	mov	r1, r5
20021646:	58b2      	ldr	r2, [r6, r2]
20021648:	6800      	ldr	r0, [r0, #0]
2002164a:	eba8 0305 	sub.w	r3, r8, r5
2002164e:	f001 fcff 	bl	20023050 <HAL_FLASH_ALIAS_CFG>
20021652:	4b0e      	ldr	r3, [pc, #56]	@ (2002168c <dfu_boot_img_in_flash+0xa8>)
20021654:	781b      	ldrb	r3, [r3, #0]
20021656:	b923      	cbnz	r3, 20021662 <dfu_boot_img_in_flash+0x7e>
20021658:	4628      	mov	r0, r5
2002165a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002165e:	f7ff bfbb 	b.w	200215d8 <run_img>
20021662:	2f01      	cmp	r7, #1
20021664:	d1f8      	bne.n	20021658 <dfu_boot_img_in_flash+0x74>
20021666:	3408      	adds	r4, #8
20021668:	0264      	lsls	r4, r4, #9
2002166a:	5932      	ldr	r2, [r6, r4]
2002166c:	4629      	mov	r1, r5
2002166e:	2000      	movs	r0, #0
20021670:	1953      	adds	r3, r2, r5
20021672:	f7ff ff59 	bl	20021528 <sifli_verify_img_cmac_hash>
20021676:	2800      	cmp	r0, #0
20021678:	d1ee      	bne.n	20021658 <dfu_boot_img_in_flash+0x74>
2002167a:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
2002167e:	4806      	ldr	r0, [pc, #24]	@ (20021698 <dfu_boot_img_in_flash+0xb4>)
20021680:	f004 bcfa 	b.w	20026078 <puts>
20021684:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20021688:	20047138 	.word	0x20047138
2002168c:	2004c95c 	.word	0x2004c95c
20021690:	20046d3c 	.word	0x20046d3c
20021694:	20046d30 	.word	0x20046d30
20021698:	20026b15 	.word	0x20026b15

2002169c <_close>:
2002169c:	f04f 30ff 	mov.w	r0, #4294967295
200216a0:	4770      	bx	lr

200216a2 <_lseek>:
200216a2:	f04f 30ff 	mov.w	r0, #4294967295
200216a6:	4770      	bx	lr

200216a8 <_read>:
200216a8:	2000      	movs	r0, #0
200216aa:	4770      	bx	lr

200216ac <_fstat>:
200216ac:	2000      	movs	r0, #0
200216ae:	4770      	bx	lr

200216b0 <_isatty>:
200216b0:	2001      	movs	r0, #1
200216b2:	4770      	bx	lr

200216b4 <flash_memset>:
200216b4:	4603      	mov	r3, r0
200216b6:	4402      	add	r2, r0
200216b8:	4293      	cmp	r3, r2
200216ba:	d100      	bne.n	200216be <flash_memset+0xa>
200216bc:	4770      	bx	lr
200216be:	f803 1b01 	strb.w	r1, [r3], #1
200216c2:	e7f9      	b.n	200216b8 <flash_memset+0x4>

200216c4 <bsp_psramc_init>:
200216c4:	b570      	push	{r4, r5, r6, lr}
200216c6:	b086      	sub	sp, #24
200216c8:	f000 f832 	bl	20021730 <BSP_GetFlash1DIV>
200216cc:	2100      	movs	r1, #0
200216ce:	2240      	movs	r2, #64	@ 0x40
200216d0:	4605      	mov	r5, r0
200216d2:	4815      	ldr	r0, [pc, #84]	@ (20021728 <bsp_psramc_init+0x64>)
200216d4:	f7ff ffee 	bl	200216b4 <flash_memset>
200216d8:	2214      	movs	r2, #20
200216da:	a801      	add	r0, sp, #4
200216dc:	f7ff ffea 	bl	200216b4 <flash_memset>
200216e0:	4b12      	ldr	r3, [pc, #72]	@ (2002172c <bsp_psramc_init+0x68>)
200216e2:	2001      	movs	r0, #1
200216e4:	9301      	str	r3, [sp, #4]
200216e6:	f006 f9c5 	bl	20027a74 <bsp_psram_get_mpi_mode>
200216ea:	2800      	cmp	r0, #0
200216ec:	bf08      	it	eq
200216ee:	2003      	moveq	r0, #3
200216f0:	f04f 5380 	mov.w	r3, #268435456	@ 0x10000000
200216f4:	2210      	movs	r2, #16
200216f6:	9005      	str	r0, [sp, #20]
200216f8:	e9cd 3203 	strd	r3, r2, [sp, #12]
200216fc:	f000 f8bf 	bl	2002187e <SystemPowerOnModeGet>
20021700:	1e41      	subs	r1, r0, #1
20021702:	4248      	negs	r0, r1
20021704:	4e08      	ldr	r6, [pc, #32]	@ (20021728 <bsp_psramc_init+0x64>)
20021706:	4148      	adcs	r0, r1
20021708:	f886 002f 	strb.w	r0, [r6, #47]	@ 0x2f
2002170c:	f006 f9c6 	bl	20027a9c <bsp_psram1_pinmux_init>
20021710:	4604      	mov	r4, r0
20021712:	b100      	cbz	r0, 20021716 <bsp_psramc_init+0x52>
20021714:	e7fe      	b.n	20021714 <bsp_psramc_init+0x50>
20021716:	462a      	mov	r2, r5
20021718:	4630      	mov	r0, r6
2002171a:	a901      	add	r1, sp, #4
2002171c:	f002 fdc0 	bl	200242a0 <HAL_MPI_PSRAM_Init>
20021720:	4620      	mov	r0, r4
20021722:	b006      	add	sp, #24
20021724:	bd70      	pop	{r4, r5, r6, pc}
20021726:	bf00      	nop
20021728:	2004c994 	.word	0x2004c994
2002172c:	50041000 	.word	0x50041000

20021730 <BSP_GetFlash1DIV>:
20021730:	4b01      	ldr	r3, [pc, #4]	@ (20021738 <BSP_GetFlash1DIV+0x8>)
20021732:	8818      	ldrh	r0, [r3, #0]
20021734:	4770      	bx	lr
20021736:	bf00      	nop
20021738:	20042c12 	.word	0x20042c12

2002173c <BSP_GetFlash2DIV>:
2002173c:	4b01      	ldr	r3, [pc, #4]	@ (20021744 <BSP_GetFlash2DIV+0x8>)
2002173e:	8818      	ldrh	r0, [r3, #0]
20021740:	4770      	bx	lr
20021742:	bf00      	nop
20021744:	20042c10 	.word	0x20042c10

20021748 <BSP_GetFlash3DIV>:
20021748:	4b01      	ldr	r3, [pc, #4]	@ (20021750 <BSP_GetFlash3DIV+0x8>)
2002174a:	8818      	ldrh	r0, [r3, #0]
2002174c:	4770      	bx	lr
2002174e:	bf00      	nop
20021750:	20042c0e 	.word	0x20042c0e

20021754 <BSP_SetFlash1DIV>:
20021754:	4b01      	ldr	r3, [pc, #4]	@ (2002175c <BSP_SetFlash1DIV+0x8>)
20021756:	8018      	strh	r0, [r3, #0]
20021758:	4770      	bx	lr
2002175a:	bf00      	nop
2002175c:	20042c12 	.word	0x20042c12

20021760 <BSP_SetFlash2DIV>:
20021760:	4b01      	ldr	r3, [pc, #4]	@ (20021768 <BSP_SetFlash2DIV+0x8>)
20021762:	8018      	strh	r0, [r3, #0]
20021764:	4770      	bx	lr
20021766:	bf00      	nop
20021768:	20042c10 	.word	0x20042c10

2002176c <BSP_SetFlash3DIV>:
2002176c:	4b01      	ldr	r3, [pc, #4]	@ (20021774 <BSP_SetFlash3DIV+0x8>)
2002176e:	8018      	strh	r0, [r3, #0]
20021770:	4770      	bx	lr
20021772:	bf00      	nop
20021774:	20042c0e 	.word	0x20042c0e

20021778 <BSP_GetOtpBase>:
20021778:	4800      	ldr	r0, [pc, #0]	@ (2002177c <BSP_GetOtpBase+0x4>)
2002177a:	4770      	bx	lr
2002177c:	1200e000 	.word	0x1200e000

20021780 <pmu_ldo_inc>:
20021780:	2000      	movs	r0, #0
20021782:	4770      	bx	lr

20021784 <pmu_ldo_recover>:
20021784:	2000      	movs	r0, #0
20021786:	4770      	bx	lr

20021788 <hw_preinit0>:
20021788:	4770      	bx	lr
	...

2002178c <mpu_dcache_clean>:
2002178c:	f1b0 4fc0 	cmp.w	r0, #1610612736	@ 0x60000000
20021790:	b570      	push	{r4, r5, r6, lr}
20021792:	d336      	bcc.n	20021802 <mpu_dcache_clean+0x76>
20021794:	f5b1 4f80 	cmp.w	r1, #16384	@ 0x4000
20021798:	d921      	bls.n	200217de <mpu_dcache_clean+0x52>
2002179a:	2300      	movs	r3, #0
2002179c:	491a      	ldr	r1, [pc, #104]	@ (20021808 <mpu_dcache_clean+0x7c>)
2002179e:	f8c1 3084 	str.w	r3, [r1, #132]	@ 0x84
200217a2:	f3bf 8f4f 	dsb	sy
200217a6:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
200217aa:	f8d1 3080 	ldr.w	r3, [r1, #128]	@ 0x80
200217ae:	f3c3 00c9 	ubfx	r0, r3, #3, #10
200217b2:	f3c3 334e 	ubfx	r3, r3, #13, #15
200217b6:	015b      	lsls	r3, r3, #5
200217b8:	4602      	mov	r2, r0
200217ba:	ea03 0604 	and.w	r6, r3, r4
200217be:	ea46 7582 	orr.w	r5, r6, r2, lsl #30
200217c2:	3a01      	subs	r2, #1
200217c4:	f8c1 526c 	str.w	r5, [r1, #620]	@ 0x26c
200217c8:	d2f9      	bcs.n	200217be <mpu_dcache_clean+0x32>
200217ca:	3b20      	subs	r3, #32
200217cc:	f113 0f20 	cmn.w	r3, #32
200217d0:	d1f2      	bne.n	200217b8 <mpu_dcache_clean+0x2c>
200217d2:	f3bf 8f4f 	dsb	sy
200217d6:	f3bf 8f6f 	isb	sy
200217da:	2001      	movs	r0, #1
200217dc:	bd70      	pop	{r4, r5, r6, pc}
200217de:	b181      	cbz	r1, 20021802 <mpu_dcache_clean+0x76>
200217e0:	f000 031f 	and.w	r3, r0, #31
200217e4:	440b      	add	r3, r1
200217e6:	f3bf 8f4f 	dsb	sy
200217ea:	4907      	ldr	r1, [pc, #28]	@ (20021808 <mpu_dcache_clean+0x7c>)
200217ec:	4403      	add	r3, r0
200217ee:	f8c1 0268 	str.w	r0, [r1, #616]	@ 0x268
200217f2:	3020      	adds	r0, #32
200217f4:	1a1a      	subs	r2, r3, r0
200217f6:	2a00      	cmp	r2, #0
200217f8:	dcf9      	bgt.n	200217ee <mpu_dcache_clean+0x62>
200217fa:	f3bf 8f4f 	dsb	sy
200217fe:	f3bf 8f6f 	isb	sy
20021802:	2000      	movs	r0, #0
20021804:	e7ea      	b.n	200217dc <mpu_dcache_clean+0x50>
20021806:	bf00      	nop
20021808:	e000ed00 	.word	0xe000ed00

2002180c <cache_disable>:
2002180c:	b570      	push	{r4, r5, r6, lr}
2002180e:	f3bf 8f4f 	dsb	sy
20021812:	f3bf 8f6f 	isb	sy
20021816:	4a18      	ldr	r2, [pc, #96]	@ (20021878 <cache_disable+0x6c>)
20021818:	6953      	ldr	r3, [r2, #20]
2002181a:	f423 3300 	bic.w	r3, r3, #131072	@ 0x20000
2002181e:	6153      	str	r3, [r2, #20]
20021820:	2300      	movs	r3, #0
20021822:	f8c2 3250 	str.w	r3, [r2, #592]	@ 0x250
20021826:	f3bf 8f4f 	dsb	sy
2002182a:	f3bf 8f6f 	isb	sy
2002182e:	f8c2 3084 	str.w	r3, [r2, #132]	@ 0x84
20021832:	f3bf 8f4f 	dsb	sy
20021836:	6953      	ldr	r3, [r2, #20]
20021838:	f423 3380 	bic.w	r3, r3, #65536	@ 0x10000
2002183c:	6153      	str	r3, [r2, #20]
2002183e:	f3bf 8f4f 	dsb	sy
20021842:	f643 74e0 	movw	r4, #16352	@ 0x3fe0
20021846:	f8d2 3080 	ldr.w	r3, [r2, #128]	@ 0x80
2002184a:	f3c3 00c9 	ubfx	r0, r3, #3, #10
2002184e:	f3c3 334e 	ubfx	r3, r3, #13, #15
20021852:	015b      	lsls	r3, r3, #5
20021854:	4601      	mov	r1, r0
20021856:	ea03 0604 	and.w	r6, r3, r4
2002185a:	ea46 7581 	orr.w	r5, r6, r1, lsl #30
2002185e:	3901      	subs	r1, #1
20021860:	f8c2 5274 	str.w	r5, [r2, #628]	@ 0x274
20021864:	d2f9      	bcs.n	2002185a <cache_disable+0x4e>
20021866:	3b20      	subs	r3, #32
20021868:	f113 0f20 	cmn.w	r3, #32
2002186c:	d1f2      	bne.n	20021854 <cache_disable+0x48>
2002186e:	f3bf 8f4f 	dsb	sy
20021872:	f3bf 8f6f 	isb	sy
20021876:	bd70      	pop	{r4, r5, r6, pc}
20021878:	e000ed00 	.word	0xe000ed00

2002187c <SystemPowerOnModeInit>:
2002187c:	4770      	bx	lr

2002187e <SystemPowerOnModeGet>:
2002187e:	2000      	movs	r0, #0
20021880:	4770      	bx	lr
	...

20021884 <SystemInit>:
20021884:	b508      	push	{r3, lr}
20021886:	4a0e      	ldr	r2, [pc, #56]	@ (200218c0 <SystemInit+0x3c>)
20021888:	4b0e      	ldr	r3, [pc, #56]	@ (200218c4 <SystemInit+0x40>)
2002188a:	609a      	str	r2, [r3, #8]
2002188c:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
20021890:	f042 023f 	orr.w	r2, r2, #63	@ 0x3f
20021894:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20021898:	f8d3 2088 	ldr.w	r2, [r3, #136]	@ 0x88
2002189c:	f442 0270 	orr.w	r2, r2, #15728640	@ 0xf00000
200218a0:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
200218a4:	f7ff ff70 	bl	20021788 <hw_preinit0>
200218a8:	f7ff ffb0 	bl	2002180c <cache_disable>
200218ac:	f7fe fcfe 	bl	200202ac <mpu_config>
200218b0:	f7fe fcfd 	bl	200202ae <cache_enable>
200218b4:	f7ff ffe2 	bl	2002187c <SystemPowerOnModeInit>
200218b8:	4b03      	ldr	r3, [pc, #12]	@ (200218c8 <SystemInit+0x44>)
200218ba:	4a04      	ldr	r2, [pc, #16]	@ (200218cc <SystemInit+0x48>)
200218bc:	601a      	str	r2, [r3, #0]
200218be:	bd08      	pop	{r3, pc}
200218c0:	20020000 	.word	0x20020000
200218c4:	e000ed00 	.word	0xe000ed00
200218c8:	20042c14 	.word	0x20042c14
200218cc:	017d7840 	.word	0x017d7840

200218d0 <Reset_Handler>:
200218d0:	f8df d048 	ldr.w	sp, [pc, #72]	@ 2002191c <ACPU2HCPU_IRQHandler+0x2>
200218d4:	4812      	ldr	r0, [pc, #72]	@ (20021920 <ACPU2HCPU_IRQHandler+0x6>)
200218d6:	f380 880a 	msr	MSPLIM, r0
200218da:	f7ff ffd3 	bl	20021884 <SystemInit>
200218de:	4c11      	ldr	r4, [pc, #68]	@ (20021924 <ACPU2HCPU_IRQHandler+0xa>)
200218e0:	4d11      	ldr	r5, [pc, #68]	@ (20021928 <ACPU2HCPU_IRQHandler+0xe>)
200218e2:	42ac      	cmp	r4, r5
200218e4:	da09      	bge.n	200218fa <Reset_Handler+0x2a>
200218e6:	6821      	ldr	r1, [r4, #0]
200218e8:	6862      	ldr	r2, [r4, #4]
200218ea:	68a3      	ldr	r3, [r4, #8]
200218ec:	3b04      	subs	r3, #4
200218ee:	bfa2      	ittt	ge
200218f0:	58c8      	ldrge	r0, [r1, r3]
200218f2:	50d0      	strge	r0, [r2, r3]
200218f4:	e7fa      	bge.n	200218ec <Reset_Handler+0x1c>
200218f6:	340c      	adds	r4, #12
200218f8:	e7f3      	b.n	200218e2 <Reset_Handler+0x12>
200218fa:	4b0c      	ldr	r3, [pc, #48]	@ (2002192c <ACPU2HCPU_IRQHandler+0x12>)
200218fc:	4c0c      	ldr	r4, [pc, #48]	@ (20021930 <ACPU2HCPU_IRQHandler+0x16>)
200218fe:	42a3      	cmp	r3, r4
20021900:	da08      	bge.n	20021914 <Reset_Handler+0x44>
20021902:	6819      	ldr	r1, [r3, #0]
20021904:	685a      	ldr	r2, [r3, #4]
20021906:	2000      	movs	r0, #0
20021908:	3a04      	subs	r2, #4
2002190a:	bfa4      	itt	ge
2002190c:	5088      	strge	r0, [r1, r2]
2002190e:	e7fb      	bge.n	20021908 <Reset_Handler+0x38>
20021910:	3308      	adds	r3, #8
20021912:	e7f4      	b.n	200218fe <Reset_Handler+0x2e>
20021914:	f7ff fab2 	bl	20020e7c <entry>

20021918 <HardFault_Handler>:
20021918:	e7fe      	b.n	20021918 <HardFault_Handler>

2002191a <ACPU2HCPU_IRQHandler>:
2002191a:	e7fe      	b.n	2002191a <ACPU2HCPU_IRQHandler>
2002191c:	20042000 	.word	0x20042000
20021920:	20040000 	.word	0x20040000
20021924:	20027ebc 	.word	0x20027ebc
20021928:	20027ec8 	.word	0x20027ec8
2002192c:	20027ec8 	.word	0x20027ec8
20021930:	20027ed0 	.word	0x20027ed0

20021934 <__aeabi_unwind_cpp_pr0>:
20021934:	2000      	movs	r0, #0
20021936:	4770      	bx	lr

20021938 <HAL_GetTick>:
20021938:	4b01      	ldr	r3, [pc, #4]	@ (20021940 <HAL_GetTick+0x8>)
2002193a:	6818      	ldr	r0, [r3, #0]
2002193c:	4770      	bx	lr
2002193e:	bf00      	nop
20021940:	2004c9d8 	.word	0x2004c9d8

20021944 <HAL_Delay_us_>:
20021944:	b538      	push	{r3, r4, r5, lr}
20021946:	4604      	mov	r4, r0
20021948:	4d16      	ldr	r5, [pc, #88]	@ (200219a4 <HAL_Delay_us_+0x60>)
2002194a:	b128      	cbz	r0, 20021958 <HAL_Delay_us_+0x14>
2002194c:	682b      	ldr	r3, [r5, #0]
2002194e:	b11b      	cbz	r3, 20021958 <HAL_Delay_us_+0x14>
20021950:	f1b4 7f80 	cmp.w	r4, #16777216	@ 0x1000000
20021954:	d90a      	bls.n	2002196c <HAL_Delay_us_+0x28>
20021956:	e7fe      	b.n	20021956 <HAL_Delay_us_+0x12>
20021958:	2000      	movs	r0, #0
2002195a:	f002 ff0b 	bl	20024774 <HAL_RCC_GetHCLKFreq>
2002195e:	4b12      	ldr	r3, [pc, #72]	@ (200219a8 <HAL_Delay_us_+0x64>)
20021960:	fbb0 f0f3 	udiv	r0, r0, r3
20021964:	6028      	str	r0, [r5, #0]
20021966:	2c00      	cmp	r4, #0
20021968:	d1f2      	bne.n	20021950 <HAL_Delay_us_+0xc>
2002196a:	bd38      	pop	{r3, r4, r5, pc}
2002196c:	4a0f      	ldr	r2, [pc, #60]	@ (200219ac <HAL_Delay_us_+0x68>)
2002196e:	6813      	ldr	r3, [r2, #0]
20021970:	f013 0301 	ands.w	r3, r3, #1
20021974:	d10d      	bne.n	20021992 <HAL_Delay_us_+0x4e>
20021976:	480e      	ldr	r0, [pc, #56]	@ (200219b0 <HAL_Delay_us_+0x6c>)
20021978:	f8d0 10fc 	ldr.w	r1, [r0, #252]	@ 0xfc
2002197c:	f041 7180 	orr.w	r1, r1, #16777216	@ 0x1000000
20021980:	f8c0 10fc 	str.w	r1, [r0, #252]	@ 0xfc
20021984:	6053      	str	r3, [r2, #4]
20021986:	6813      	ldr	r3, [r2, #0]
20021988:	f443 3300 	orr.w	r3, r3, #131072	@ 0x20000
2002198c:	f043 0301 	orr.w	r3, r3, #1
20021990:	6013      	str	r3, [r2, #0]
20021992:	682b      	ldr	r3, [r5, #0]
20021994:	4a05      	ldr	r2, [pc, #20]	@ (200219ac <HAL_Delay_us_+0x68>)
20021996:	435c      	muls	r4, r3
20021998:	6851      	ldr	r1, [r2, #4]
2002199a:	6853      	ldr	r3, [r2, #4]
2002199c:	1a5b      	subs	r3, r3, r1
2002199e:	429c      	cmp	r4, r3
200219a0:	d8fb      	bhi.n	2002199a <HAL_Delay_us_+0x56>
200219a2:	e7e2      	b.n	2002196a <HAL_Delay_us_+0x26>
200219a4:	2004c9d4 	.word	0x2004c9d4
200219a8:	000f4240 	.word	0x000f4240
200219ac:	e0001000 	.word	0xe0001000
200219b0:	e000ed00 	.word	0xe000ed00

200219b4 <HAL_Delay_us2_>:
200219b4:	b537      	push	{r0, r1, r2, r4, r5, lr}
200219b6:	9001      	str	r0, [sp, #4]
200219b8:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
200219bc:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
200219c0:	6944      	ldr	r4, [r0, #20]
200219c2:	9b01      	ldr	r3, [sp, #4]
200219c4:	4363      	muls	r3, r4
200219c6:	fbb3 f3f2 	udiv	r3, r3, r2
200219ca:	9301      	str	r3, [sp, #4]
200219cc:	2300      	movs	r3, #0
200219ce:	6981      	ldr	r1, [r0, #24]
200219d0:	6982      	ldr	r2, [r0, #24]
200219d2:	428a      	cmp	r2, r1
200219d4:	d0fc      	beq.n	200219d0 <HAL_Delay_us2_+0x1c>
200219d6:	bf25      	ittet	cs
200219d8:	1aa5      	subcs	r5, r4, r2
200219da:	195b      	addcs	r3, r3, r5
200219dc:	185b      	addcc	r3, r3, r1
200219de:	185b      	addcs	r3, r3, r1
200219e0:	9901      	ldr	r1, [sp, #4]
200219e2:	bf38      	it	cc
200219e4:	1a9b      	subcc	r3, r3, r2
200219e6:	4299      	cmp	r1, r3
200219e8:	d801      	bhi.n	200219ee <HAL_Delay_us2_+0x3a>
200219ea:	b003      	add	sp, #12
200219ec:	bd30      	pop	{r4, r5, pc}
200219ee:	4611      	mov	r1, r2
200219f0:	e7ee      	b.n	200219d0 <HAL_Delay_us2_+0x1c>

200219f2 <HAL_Delay_us>:
200219f2:	4603      	mov	r3, r0
200219f4:	b570      	push	{r4, r5, r6, lr}
200219f6:	b1b8      	cbz	r0, 20021a28 <HAL_Delay_us+0x36>
200219f8:	f242 7510 	movw	r5, #10000	@ 0x2710
200219fc:	f04f 26e0 	mov.w	r6, #3758153728	@ 0xe000e000
20021a00:	42ab      	cmp	r3, r5
20021a02:	bf84      	itt	hi
20021a04:	f5a3 541c 	subhi.w	r4, r3, #9984	@ 0x2700
20021a08:	f242 7310 	movwhi	r3, #10000	@ 0x2710
20021a0c:	6932      	ldr	r2, [r6, #16]
20021a0e:	bf98      	it	ls
20021a10:	2400      	movls	r4, #0
20021a12:	4618      	mov	r0, r3
20021a14:	bf88      	it	hi
20021a16:	3c10      	subhi	r4, #16
20021a18:	07d3      	lsls	r3, r2, #31
20021a1a:	d508      	bpl.n	20021a2e <HAL_Delay_us+0x3c>
20021a1c:	f7ff ffca 	bl	200219b4 <HAL_Delay_us2_>
20021a20:	4623      	mov	r3, r4
20021a22:	2c00      	cmp	r4, #0
20021a24:	d1ec      	bne.n	20021a00 <HAL_Delay_us+0xe>
20021a26:	e001      	b.n	20021a2c <HAL_Delay_us+0x3a>
20021a28:	f7ff ff8c 	bl	20021944 <HAL_Delay_us_>
20021a2c:	bd70      	pop	{r4, r5, r6, pc}
20021a2e:	f7ff ff89 	bl	20021944 <HAL_Delay_us_>
20021a32:	e7f5      	b.n	20021a20 <HAL_Delay_us+0x2e>

20021a34 <WDT_IRQHandler>:
20021a34:	4770      	bx	lr

20021a36 <DBG_Trigger_IRQHandler>:
20021a36:	4770      	bx	lr

20021a38 <NMI_Handler>:
20021a38:	b508      	push	{r3, lr}
20021a3a:	4b05      	ldr	r3, [pc, #20]	@ (20021a50 <NMI_Handler+0x18>)
20021a3c:	6a1b      	ldr	r3, [r3, #32]
20021a3e:	005b      	lsls	r3, r3, #1
20021a40:	d502      	bpl.n	20021a48 <NMI_Handler+0x10>
20021a42:	f7ff fff8 	bl	20021a36 <DBG_Trigger_IRQHandler>
20021a46:	bd08      	pop	{r3, pc}
20021a48:	f7ff fff4 	bl	20021a34 <WDT_IRQHandler>
20021a4c:	e7fb      	b.n	20021a46 <NMI_Handler+0xe>
20021a4e:	bf00      	nop
20021a50:	5000b000 	.word	0x5000b000

20021a54 <HAL_AES_run_help>:
20021a54:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021a56:	4615      	mov	r5, r2
20021a58:	461e      	mov	r6, r3
20021a5a:	460b      	mov	r3, r1
20021a5c:	f101 4270 	add.w	r2, r1, #4026531840	@ 0xf0000000
20021a60:	4c13      	ldr	r4, [pc, #76]	@ (20021ab0 <HAL_AES_run_help+0x5c>)
20021a62:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20021a66:	bf38      	it	cc
20021a68:	f101 43a0 	addcc.w	r3, r1, #1342177280	@ 0x50000000
20021a6c:	6163      	str	r3, [r4, #20]
20021a6e:	462b      	mov	r3, r5
20021a70:	4607      	mov	r7, r0
20021a72:	f105 4270 	add.w	r2, r5, #4026531840	@ 0xf0000000
20021a76:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20021a7a:	bf38      	it	cc
20021a7c:	f105 43a0 	addcc.w	r3, r5, #1342177280	@ 0x50000000
20021a80:	61a3      	str	r3, [r4, #24]
20021a82:	f106 030f 	add.w	r3, r6, #15
20021a86:	111b      	asrs	r3, r3, #4
20021a88:	61e3      	str	r3, [r4, #28]
20021a8a:	4608      	mov	r0, r1
20021a8c:	6923      	ldr	r3, [r4, #16]
20021a8e:	b10f      	cbz	r7, 20021a94 <HAL_AES_run_help+0x40>
20021a90:	ea43 13c7 	orr.w	r3, r3, r7, lsl #7
20021a94:	6123      	str	r3, [r4, #16]
20021a96:	4631      	mov	r1, r6
20021a98:	f7ff fe78 	bl	2002178c <mpu_dcache_clean>
20021a9c:	4631      	mov	r1, r6
20021a9e:	4628      	mov	r0, r5
20021aa0:	f7ff fe74 	bl	2002178c <mpu_dcache_clean>
20021aa4:	4a02      	ldr	r2, [pc, #8]	@ (20021ab0 <HAL_AES_run_help+0x5c>)
20021aa6:	6813      	ldr	r3, [r2, #0]
20021aa8:	f043 0301 	orr.w	r3, r3, #1
20021aac:	6013      	str	r3, [r2, #0]
20021aae:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021ab0:	5000d000 	.word	0x5000d000

20021ab4 <HAL_AES_reset>:
20021ab4:	2202      	movs	r2, #2
20021ab6:	2000      	movs	r0, #0
20021ab8:	4b01      	ldr	r3, [pc, #4]	@ (20021ac0 <HAL_AES_reset+0xc>)
20021aba:	601a      	str	r2, [r3, #0]
20021abc:	6018      	str	r0, [r3, #0]
20021abe:	4770      	bx	lr
20021ac0:	5000d000 	.word	0x5000d000

20021ac4 <HAL_AES_init>:
20021ac4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021ac6:	4604      	mov	r4, r0
20021ac8:	200c      	movs	r0, #12
20021aca:	461e      	mov	r6, r3
20021acc:	460d      	mov	r5, r1
20021ace:	4617      	mov	r7, r2
20021ad0:	f002 ffa4 	bl	20024a1c <HAL_RCC_EnableModule>
20021ad4:	4b1c      	ldr	r3, [pc, #112]	@ (20021b48 <HAL_AES_init+0x84>)
20021ad6:	685b      	ldr	r3, [r3, #4]
20021ad8:	07db      	lsls	r3, r3, #31
20021ada:	d501      	bpl.n	20021ae0 <HAL_AES_init+0x1c>
20021adc:	f7ff ffea 	bl	20021ab4 <HAL_AES_reset>
20021ae0:	fab4 f184 	clz	r1, r4
20021ae4:	2d18      	cmp	r5, #24
20021ae6:	ea4f 1151 	mov.w	r1, r1, lsr #5
20021aea:	ea4f 1141 	mov.w	r1, r1, lsl #5
20021aee:	d01b      	beq.n	20021b28 <HAL_AES_init+0x64>
20021af0:	2d20      	cmp	r5, #32
20021af2:	d01b      	beq.n	20021b2c <HAL_AES_init+0x68>
20021af4:	2d10      	cmp	r5, #16
20021af6:	d124      	bne.n	20021b42 <HAL_AES_init+0x7e>
20021af8:	2300      	movs	r3, #0
20021afa:	b164      	cbz	r4, 20021b16 <HAL_AES_init+0x52>
20021afc:	4620      	mov	r0, r4
20021afe:	4a13      	ldr	r2, [pc, #76]	@ (20021b4c <HAL_AES_init+0x88>)
20021b00:	f025 0503 	bic.w	r5, r5, #3
20021b04:	4425      	add	r5, r4
20021b06:	1b12      	subs	r2, r2, r4
20021b08:	1814      	adds	r4, r2, r0
20021b0a:	f850 cb04 	ldr.w	ip, [r0], #4
20021b0e:	4285      	cmp	r5, r0
20021b10:	f8c4 c000 	str.w	ip, [r4]
20021b14:	d1f8      	bne.n	20021b08 <HAL_AES_init+0x44>
20021b16:	4331      	orrs	r1, r6
20021b18:	ea41 01c3 	orr.w	r1, r1, r3, lsl #3
20021b1c:	4b0a      	ldr	r3, [pc, #40]	@ (20021b48 <HAL_AES_init+0x84>)
20021b1e:	6119      	str	r1, [r3, #16]
20021b20:	b106      	cbz	r6, 20021b24 <HAL_AES_init+0x60>
20021b22:	b92f      	cbnz	r7, 20021b30 <HAL_AES_init+0x6c>
20021b24:	2000      	movs	r0, #0
20021b26:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021b28:	2301      	movs	r3, #1
20021b2a:	e7e6      	b.n	20021afa <HAL_AES_init+0x36>
20021b2c:	2302      	movs	r3, #2
20021b2e:	e7e4      	b.n	20021afa <HAL_AES_init+0x36>
20021b30:	683a      	ldr	r2, [r7, #0]
20021b32:	621a      	str	r2, [r3, #32]
20021b34:	687a      	ldr	r2, [r7, #4]
20021b36:	625a      	str	r2, [r3, #36]	@ 0x24
20021b38:	68ba      	ldr	r2, [r7, #8]
20021b3a:	629a      	str	r2, [r3, #40]	@ 0x28
20021b3c:	68fa      	ldr	r2, [r7, #12]
20021b3e:	62da      	str	r2, [r3, #44]	@ 0x2c
20021b40:	e7f0      	b.n	20021b24 <HAL_AES_init+0x60>
20021b42:	f04f 30ff 	mov.w	r0, #4294967295
20021b46:	e7ee      	b.n	20021b26 <HAL_AES_init+0x62>
20021b48:	5000d000 	.word	0x5000d000
20021b4c:	5000d030 	.word	0x5000d030

20021b50 <HAL_AES_run>:
20021b50:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021b52:	2708      	movs	r7, #8
20021b54:	4e17      	ldr	r6, [pc, #92]	@ (20021bb4 <HAL_AES_run+0x64>)
20021b56:	4614      	mov	r4, r2
20021b58:	461d      	mov	r5, r3
20021b5a:	f8c6 7088 	str.w	r7, [r6, #136]	@ 0x88
20021b5e:	f3bf 8f4f 	dsb	sy
20021b62:	f3bf 8f6f 	isb	sy
20021b66:	2700      	movs	r7, #0
20021b68:	4e13      	ldr	r6, [pc, #76]	@ (20021bb8 <HAL_AES_run+0x68>)
20021b6a:	60f7      	str	r7, [r6, #12]
20021b6c:	f7ff ff72 	bl	20021a54 <HAL_AES_run_help>
20021b70:	6873      	ldr	r3, [r6, #4]
20021b72:	07db      	lsls	r3, r3, #31
20021b74:	d4fc      	bmi.n	20021b70 <HAL_AES_run+0x20>
20021b76:	68b0      	ldr	r0, [r6, #8]
20021b78:	f000 0006 	and.w	r0, r0, #6
20021b7c:	3800      	subs	r0, #0
20021b7e:	bf18      	it	ne
20021b80:	2001      	movne	r0, #1
20021b82:	f1b4 4fc0 	cmp.w	r4, #1610612736	@ 0x60000000
20021b86:	d314      	bcc.n	20021bb2 <HAL_AES_run+0x62>
20021b88:	2d00      	cmp	r5, #0
20021b8a:	dd12      	ble.n	20021bb2 <HAL_AES_run+0x62>
20021b8c:	f004 031f 	and.w	r3, r4, #31
20021b90:	442b      	add	r3, r5
20021b92:	f024 021f 	bic.w	r2, r4, #31
20021b96:	f3bf 8f4f 	dsb	sy
20021b9a:	4c08      	ldr	r4, [pc, #32]	@ (20021bbc <HAL_AES_run+0x6c>)
20021b9c:	4413      	add	r3, r2
20021b9e:	f8c4 225c 	str.w	r2, [r4, #604]	@ 0x25c
20021ba2:	3220      	adds	r2, #32
20021ba4:	1a99      	subs	r1, r3, r2
20021ba6:	2900      	cmp	r1, #0
20021ba8:	dcf9      	bgt.n	20021b9e <HAL_AES_run+0x4e>
20021baa:	f3bf 8f4f 	dsb	sy
20021bae:	f3bf 8f6f 	isb	sy
20021bb2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021bb4:	e000e100 	.word	0xe000e100
20021bb8:	5000d000 	.word	0x5000d000
20021bbc:	e000ed00 	.word	0xe000ed00

20021bc0 <HAL_NVIC_EnableIRQ>:
20021bc0:	2800      	cmp	r0, #0
20021bc2:	da00      	bge.n	20021bc6 <HAL_NVIC_EnableIRQ+0x6>
20021bc4:	e7fe      	b.n	20021bc4 <HAL_NVIC_EnableIRQ+0x4>
20021bc6:	2301      	movs	r3, #1
20021bc8:	0941      	lsrs	r1, r0, #5
20021bca:	4a03      	ldr	r2, [pc, #12]	@ (20021bd8 <HAL_NVIC_EnableIRQ+0x18>)
20021bcc:	f000 001f 	and.w	r0, r0, #31
20021bd0:	4083      	lsls	r3, r0
20021bd2:	f842 3021 	str.w	r3, [r2, r1, lsl #2]
20021bd6:	4770      	bx	lr
20021bd8:	e000e100 	.word	0xe000e100

20021bdc <HAL_NVIC_DisableIRQ>:
20021bdc:	2800      	cmp	r0, #0
20021bde:	da00      	bge.n	20021be2 <HAL_NVIC_DisableIRQ+0x6>
20021be0:	e7fe      	b.n	20021be0 <HAL_NVIC_DisableIRQ+0x4>
20021be2:	2201      	movs	r2, #1
20021be4:	4906      	ldr	r1, [pc, #24]	@ (20021c00 <HAL_NVIC_DisableIRQ+0x24>)
20021be6:	0943      	lsrs	r3, r0, #5
20021be8:	f000 001f 	and.w	r0, r0, #31
20021bec:	4082      	lsls	r2, r0
20021bee:	3320      	adds	r3, #32
20021bf0:	f841 2023 	str.w	r2, [r1, r3, lsl #2]
20021bf4:	f3bf 8f4f 	dsb	sy
20021bf8:	f3bf 8f6f 	isb	sy
20021bfc:	4770      	bx	lr
20021bfe:	bf00      	nop
20021c00:	e000e100 	.word	0xe000e100

20021c04 <DMA_IsChannelOwner>:
20021c04:	b510      	push	{r4, lr}
20021c06:	4911      	ldr	r1, [pc, #68]	@ (20021c4c <DMA_IsChannelOwner+0x48>)
20021c08:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021c0a:	4602      	mov	r2, r0
20021c0c:	428b      	cmp	r3, r1
20021c0e:	d003      	beq.n	20021c18 <DMA_IsChannelOwner+0x14>
20021c10:	490f      	ldr	r1, [pc, #60]	@ (20021c50 <DMA_IsChannelOwner+0x4c>)
20021c12:	428b      	cmp	r3, r1
20021c14:	d007      	beq.n	20021c26 <DMA_IsChannelOwner+0x22>
20021c16:	e7fe      	b.n	20021c16 <DMA_IsChannelOwner+0x12>
20021c18:	4b0e      	ldr	r3, [pc, #56]	@ (20021c54 <DMA_IsChannelOwner+0x50>)
20021c1a:	6d10      	ldr	r0, [r2, #80]	@ 0x50
20021c1c:	281f      	cmp	r0, #31
20021c1e:	ea4f 0190 	mov.w	r1, r0, lsr #2
20021c22:	d902      	bls.n	20021c2a <DMA_IsChannelOwner+0x26>
20021c24:	e7fe      	b.n	20021c24 <DMA_IsChannelOwner+0x20>
20021c26:	4b0c      	ldr	r3, [pc, #48]	@ (20021c58 <DMA_IsChannelOwner+0x54>)
20021c28:	e7f7      	b.n	20021c1a <DMA_IsChannelOwner+0x16>
20021c2a:	f3ef 8410 	mrs	r4, PRIMASK
20021c2e:	2001      	movs	r0, #1
20021c30:	f380 8810 	msr	PRIMASK, r0
20021c34:	eb03 00c1 	add.w	r0, r3, r1, lsl #3
20021c38:	7900      	ldrb	r0, [r0, #4]
20021c3a:	b120      	cbz	r0, 20021c46 <DMA_IsChannelOwner+0x42>
20021c3c:	f853 0031 	ldr.w	r0, [r3, r1, lsl #3]
20021c40:	1a83      	subs	r3, r0, r2
20021c42:	4258      	negs	r0, r3
20021c44:	4158      	adcs	r0, r3
20021c46:	f384 8810 	msr	PRIMASK, r4
20021c4a:	bd10      	pop	{r4, pc}
20021c4c:	50081000 	.word	0x50081000
20021c50:	40001000 	.word	0x40001000
20021c54:	2004ca1c 	.word	0x2004ca1c
20021c58:	2004c9dc 	.word	0x2004c9dc

20021c5c <DMA_FreeChannel.isra.0>:
20021c5c:	b538      	push	{r3, r4, r5, lr}
20021c5e:	4a13      	ldr	r2, [pc, #76]	@ (20021cac <DMA_FreeChannel.isra.0+0x50>)
20021c60:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
20021c62:	4293      	cmp	r3, r2
20021c64:	d003      	beq.n	20021c6e <DMA_FreeChannel.isra.0+0x12>
20021c66:	4a12      	ldr	r2, [pc, #72]	@ (20021cb0 <DMA_FreeChannel.isra.0+0x54>)
20021c68:	4293      	cmp	r3, r2
20021c6a:	d008      	beq.n	20021c7e <DMA_FreeChannel.isra.0+0x22>
20021c6c:	e7fe      	b.n	20021c6c <DMA_FreeChannel.isra.0+0x10>
20021c6e:	2132      	movs	r1, #50	@ 0x32
20021c70:	4a10      	ldr	r2, [pc, #64]	@ (20021cb4 <DMA_FreeChannel.isra.0+0x58>)
20021c72:	6d04      	ldr	r4, [r0, #80]	@ 0x50
20021c74:	2c1f      	cmp	r4, #31
20021c76:	ea4f 0394 	mov.w	r3, r4, lsr #2
20021c7a:	d903      	bls.n	20021c84 <DMA_FreeChannel.isra.0+0x28>
20021c7c:	e7fe      	b.n	20021c7c <DMA_FreeChannel.isra.0+0x20>
20021c7e:	2102      	movs	r1, #2
20021c80:	4a0d      	ldr	r2, [pc, #52]	@ (20021cb8 <DMA_FreeChannel.isra.0+0x5c>)
20021c82:	e7f6      	b.n	20021c72 <DMA_FreeChannel.isra.0+0x16>
20021c84:	f3ef 8410 	mrs	r4, PRIMASK
20021c88:	2501      	movs	r5, #1
20021c8a:	f385 8810 	msr	PRIMASK, r5
20021c8e:	eb02 05c3 	add.w	r5, r2, r3, lsl #3
20021c92:	f852 2033 	ldr.w	r2, [r2, r3, lsl #3]
20021c96:	4290      	cmp	r0, r2
20021c98:	d105      	bne.n	20021ca6 <DMA_FreeChannel.isra.0+0x4a>
20021c9a:	1858      	adds	r0, r3, r1
20021c9c:	b240      	sxtb	r0, r0
20021c9e:	f7ff ff9d 	bl	20021bdc <HAL_NVIC_DisableIRQ>
20021ca2:	2300      	movs	r3, #0
20021ca4:	712b      	strb	r3, [r5, #4]
20021ca6:	f384 8810 	msr	PRIMASK, r4
20021caa:	bd38      	pop	{r3, r4, r5, pc}
20021cac:	50081000 	.word	0x50081000
20021cb0:	40001000 	.word	0x40001000
20021cb4:	2004ca1c 	.word	0x2004ca1c
20021cb8:	2004c9dc 	.word	0x2004c9dc

20021cbc <DMA_SetBurstSizeAndFix.part.0>:
20021cbc:	6843      	ldr	r3, [r0, #4]
20021cbe:	2b10      	cmp	r3, #16
20021cc0:	d113      	bne.n	20021cea <DMA_SetBurstSizeAndFix.part.0+0x2e>
20021cc2:	8c02      	ldrh	r2, [r0, #32]
20021cc4:	b11a      	cbz	r2, 20021cce <DMA_SetBurstSizeAndFix.part.0+0x12>
20021cc6:	680b      	ldr	r3, [r1, #0]
20021cc8:	f043 5380 	orr.w	r3, r3, #268435456	@ 0x10000000
20021ccc:	600b      	str	r3, [r1, #0]
20021cce:	680b      	ldr	r3, [r1, #0]
20021cd0:	f362 6319 	bfi	r3, r2, #24, #2
20021cd4:	600b      	str	r3, [r1, #0]
20021cd6:	6842      	ldr	r2, [r0, #4]
20021cd8:	b94a      	cbnz	r2, 20021cee <DMA_SetBurstSizeAndFix.part.0+0x32>
20021cda:	8c02      	ldrh	r2, [r0, #32]
20021cdc:	b10a      	cbz	r2, 20021ce2 <DMA_SetBurstSizeAndFix.part.0+0x26>
20021cde:	f043 5300 	orr.w	r3, r3, #536870912	@ 0x20000000
20021ce2:	f362 639b 	bfi	r3, r2, #26, #2
20021ce6:	600b      	str	r3, [r1, #0]
20021ce8:	4770      	bx	lr
20021cea:	2203      	movs	r2, #3
20021cec:	e7ef      	b.n	20021cce <DMA_SetBurstSizeAndFix.part.0+0x12>
20021cee:	2203      	movs	r2, #3
20021cf0:	e7f7      	b.n	20021ce2 <DMA_SetBurstSizeAndFix.part.0+0x26>

20021cf2 <DMA_Init>:
20021cf2:	2302      	movs	r3, #2
20021cf4:	b537      	push	{r0, r1, r2, r4, r5, lr}
20021cf6:	f880 3031 	strb.w	r3, [r0, #49]	@ 0x31
20021cfa:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021cfe:	4604      	mov	r4, r0
20021d00:	2b00      	cmp	r3, #0
20021d02:	bfa2      	ittt	ge
20021d04:	6803      	ldrge	r3, [r0, #0]
20021d06:	6a42      	ldrge	r2, [r0, #36]	@ 0x24
20021d08:	611a      	strge	r2, [r3, #16]
20021d0a:	e9d0 3102 	ldrd	r3, r1, [r0, #8]
20021d0e:	430b      	orrs	r3, r1
20021d10:	6901      	ldr	r1, [r0, #16]
20021d12:	6805      	ldr	r5, [r0, #0]
20021d14:	430b      	orrs	r3, r1
20021d16:	6941      	ldr	r1, [r0, #20]
20021d18:	682a      	ldr	r2, [r5, #0]
20021d1a:	430b      	orrs	r3, r1
20021d1c:	6981      	ldr	r1, [r0, #24]
20021d1e:	f36f 120e 	bfc	r2, #4, #11
20021d22:	430b      	orrs	r3, r1
20021d24:	69c1      	ldr	r1, [r0, #28]
20021d26:	430b      	orrs	r3, r1
20021d28:	6a01      	ldr	r1, [r0, #32]
20021d2a:	430b      	orrs	r3, r1
20021d2c:	4313      	orrs	r3, r2
20021d2e:	9301      	str	r3, [sp, #4]
20021d30:	f990 3057 	ldrsb.w	r3, [r0, #87]	@ 0x57
20021d34:	2b00      	cmp	r3, #0
20021d36:	da08      	bge.n	20021d4a <DMA_Init+0x58>
20021d38:	6d43      	ldr	r3, [r0, #84]	@ 0x54
20021d3a:	f3c3 031e 	ubfx	r3, r3, #0, #31
20021d3e:	2b01      	cmp	r3, #1
20021d40:	d803      	bhi.n	20021d4a <DMA_Init+0x58>
20021d42:	a901      	add	r1, sp, #4
20021d44:	3004      	adds	r0, #4
20021d46:	f7ff ffb9 	bl	20021cbc <DMA_SetBurstSizeAndFix.part.0>
20021d4a:	9b01      	ldr	r3, [sp, #4]
20021d4c:	602b      	str	r3, [r5, #0]
20021d4e:	68a3      	ldr	r3, [r4, #8]
20021d50:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021d54:	d01f      	beq.n	20021d96 <DMA_Init+0xa4>
20021d56:	6d23      	ldr	r3, [r4, #80]	@ 0x50
20021d58:	f3c3 0387 	ubfx	r3, r3, #2, #8
20021d5c:	f3ef 8110 	mrs	r1, PRIMASK
20021d60:	2201      	movs	r2, #1
20021d62:	f382 8810 	msr	PRIMASK, r2
20021d66:	0758      	lsls	r0, r3, #29
20021d68:	6ce2      	ldr	r2, [r4, #76]	@ 0x4c
20021d6a:	d41d      	bmi.n	20021da8 <DMA_Init+0xb6>
20021d6c:	253f      	movs	r5, #63	@ 0x3f
20021d6e:	f003 0307 	and.w	r3, r3, #7
20021d72:	f8d2 00a8 	ldr.w	r0, [r2, #168]	@ 0xa8
20021d76:	00db      	lsls	r3, r3, #3
20021d78:	409d      	lsls	r5, r3
20021d7a:	ea20 0005 	bic.w	r0, r0, r5
20021d7e:	f8c2 00a8 	str.w	r0, [r2, #168]	@ 0xa8
20021d82:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021d84:	6862      	ldr	r2, [r4, #4]
20021d86:	f8d0 50a8 	ldr.w	r5, [r0, #168]	@ 0xa8
20021d8a:	409a      	lsls	r2, r3
20021d8c:	432a      	orrs	r2, r5
20021d8e:	f8c0 20a8 	str.w	r2, [r0, #168]	@ 0xa8
20021d92:	f381 8810 	msr	PRIMASK, r1
20021d96:	69a2      	ldr	r2, [r4, #24]
20021d98:	f5b2 6f80 	cmp.w	r2, #1024	@ 0x400
20021d9c:	d018      	beq.n	20021dd0 <DMA_Init+0xde>
20021d9e:	f5b2 6f00 	cmp.w	r2, #2048	@ 0x800
20021da2:	d01f      	beq.n	20021de4 <DMA_Init+0xf2>
20021da4:	b1aa      	cbz	r2, 20021dd2 <DMA_Init+0xe0>
20021da6:	e7fe      	b.n	20021da6 <DMA_Init+0xb4>
20021da8:	253f      	movs	r5, #63	@ 0x3f
20021daa:	f003 0303 	and.w	r3, r3, #3
20021dae:	f8d2 00ac 	ldr.w	r0, [r2, #172]	@ 0xac
20021db2:	00db      	lsls	r3, r3, #3
20021db4:	409d      	lsls	r5, r3
20021db6:	ea20 0005 	bic.w	r0, r0, r5
20021dba:	f8c2 00ac 	str.w	r0, [r2, #172]	@ 0xac
20021dbe:	6ce0      	ldr	r0, [r4, #76]	@ 0x4c
20021dc0:	6862      	ldr	r2, [r4, #4]
20021dc2:	f8d0 50ac 	ldr.w	r5, [r0, #172]	@ 0xac
20021dc6:	409a      	lsls	r2, r3
20021dc8:	432a      	orrs	r2, r5
20021dca:	f8c0 20ac 	str.w	r2, [r0, #172]	@ 0xac
20021dce:	e7e0      	b.n	20021d92 <DMA_Init+0xa0>
20021dd0:	2201      	movs	r2, #1
20021dd2:	6963      	ldr	r3, [r4, #20]
20021dd4:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20021dd8:	d006      	beq.n	20021de8 <DMA_Init+0xf6>
20021dda:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021dde:	d02c      	beq.n	20021e3a <DMA_Init+0x148>
20021de0:	b11b      	cbz	r3, 20021dea <DMA_Init+0xf8>
20021de2:	e7fe      	b.n	20021de2 <DMA_Init+0xf0>
20021de4:	2202      	movs	r2, #2
20021de6:	e7f4      	b.n	20021dd2 <DMA_Init+0xe0>
20021de8:	2301      	movs	r3, #1
20021dea:	6921      	ldr	r1, [r4, #16]
20021dec:	f1a1 0080 	sub.w	r0, r1, #128	@ 0x80
20021df0:	4241      	negs	r1, r0
20021df2:	4141      	adcs	r1, r0
20021df4:	68e0      	ldr	r0, [r4, #12]
20021df6:	f1a0 0540 	sub.w	r5, r0, #64	@ 0x40
20021dfa:	4268      	negs	r0, r5
20021dfc:	4168      	adcs	r0, r5
20021dfe:	68a5      	ldr	r5, [r4, #8]
20021e00:	2d10      	cmp	r5, #16
20021e02:	bf1f      	itttt	ne
20021e04:	f884 106d 	strbne.w	r1, [r4, #109]	@ 0x6d
20021e08:	4619      	movne	r1, r3
20021e0a:	4613      	movne	r3, r2
20021e0c:	460a      	movne	r2, r1
20021e0e:	f884 306f 	strb.w	r3, [r4, #111]	@ 0x6f
20021e12:	f884 206e 	strb.w	r2, [r4, #110]	@ 0x6e
20021e16:	f04f 0300 	mov.w	r3, #0
20021e1a:	f04f 0201 	mov.w	r2, #1
20021e1e:	64a3      	str	r3, [r4, #72]	@ 0x48
20021e20:	bf06      	itte	eq
20021e22:	f884 006d 	strbeq.w	r0, [r4, #109]	@ 0x6d
20021e26:	f884 106c 	strbeq.w	r1, [r4, #108]	@ 0x6c
20021e2a:	f884 006c 	strbne.w	r0, [r4, #108]	@ 0x6c
20021e2e:	f884 2031 	strb.w	r2, [r4, #49]	@ 0x31
20021e32:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20021e36:	b003      	add	sp, #12
20021e38:	bd30      	pop	{r4, r5, pc}
20021e3a:	2302      	movs	r3, #2
20021e3c:	e7d5      	b.n	20021dea <DMA_Init+0xf8>
	...

20021e40 <DMA_AllocChannel>:
20021e40:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20021e42:	4b31      	ldr	r3, [pc, #196]	@ (20021f08 <DMA_AllocChannel+0xc8>)
20021e44:	6802      	ldr	r2, [r0, #0]
20021e46:	4604      	mov	r4, r0
20021e48:	4413      	add	r3, r2
20021e4a:	2ba0      	cmp	r3, #160	@ 0xa0
20021e4c:	d904      	bls.n	20021e58 <DMA_AllocChannel+0x18>
20021e4e:	4b2f      	ldr	r3, [pc, #188]	@ (20021f0c <DMA_AllocChannel+0xcc>)
20021e50:	4413      	add	r3, r2
20021e52:	2ba0      	cmp	r3, #160	@ 0xa0
20021e54:	d90f      	bls.n	20021e76 <DMA_AllocChannel+0x36>
20021e56:	e7fe      	b.n	20021e56 <DMA_AllocChannel+0x16>
20021e58:	2032      	movs	r0, #50	@ 0x32
20021e5a:	f8df c0bc 	ldr.w	ip, [pc, #188]	@ 20021f18 <DMA_AllocChannel+0xd8>
20021e5e:	4b2c      	ldr	r3, [pc, #176]	@ (20021f10 <DMA_AllocChannel+0xd0>)
20021e60:	f3ef 8710 	mrs	r7, PRIMASK
20021e64:	2201      	movs	r2, #1
20021e66:	f382 8810 	msr	PRIMASK, r2
20021e6a:	6d26      	ldr	r6, [r4, #80]	@ 0x50
20021e6c:	2e1f      	cmp	r6, #31
20021e6e:	ea4f 0596 	mov.w	r5, r6, lsr #2
20021e72:	d905      	bls.n	20021e80 <DMA_AllocChannel+0x40>
20021e74:	e7fe      	b.n	20021e74 <DMA_AllocChannel+0x34>
20021e76:	2002      	movs	r0, #2
20021e78:	f8df c0a0 	ldr.w	ip, [pc, #160]	@ 20021f1c <DMA_AllocChannel+0xdc>
20021e7c:	4b25      	ldr	r3, [pc, #148]	@ (20021f14 <DMA_AllocChannel+0xd4>)
20021e7e:	e7ef      	b.n	20021e60 <DMA_AllocChannel+0x20>
20021e80:	eb03 06c5 	add.w	r6, r3, r5, lsl #3
20021e84:	f896 e004 	ldrb.w	lr, [r6, #4]
20021e88:	f1be 0f00 	cmp.w	lr, #0
20021e8c:	d037      	beq.n	20021efe <DMA_AllocChannel+0xbe>
20021e8e:	f853 2035 	ldr.w	r2, [r3, r5, lsl #3]
20021e92:	42a2      	cmp	r2, r4
20021e94:	d103      	bne.n	20021e9e <DMA_AllocChannel+0x5e>
20021e96:	f387 8810 	msr	PRIMASK, r7
20021e9a:	2002      	movs	r0, #2
20021e9c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20021e9e:	2200      	movs	r2, #0
20021ea0:	791d      	ldrb	r5, [r3, #4]
20021ea2:	461e      	mov	r6, r3
20021ea4:	bb2d      	cbnz	r5, 20021ef2 <DMA_AllocChannel+0xb2>
20021ea6:	2301      	movs	r3, #1
20021ea8:	7133      	strb	r3, [r6, #4]
20021eaa:	2314      	movs	r3, #20
20021eac:	fb03 c302 	mla	r3, r3, r2, ip
20021eb0:	6023      	str	r3, [r4, #0]
20021eb2:	0093      	lsls	r3, r2, #2
20021eb4:	6523      	str	r3, [r4, #80]	@ 0x50
20021eb6:	6d63      	ldr	r3, [r4, #84]	@ 0x54
20021eb8:	4410      	add	r0, r2
20021eba:	f362 031e 	bfi	r3, r2, #0, #31
20021ebe:	b245      	sxtb	r5, r0
20021ec0:	6563      	str	r3, [r4, #84]	@ 0x54
20021ec2:	f387 8810 	msr	PRIMASK, r7
20021ec6:	b129      	cbz	r1, 20021ed4 <DMA_AllocChannel+0x94>
20021ec8:	6833      	ldr	r3, [r6, #0]
20021eca:	42a3      	cmp	r3, r4
20021ecc:	d002      	beq.n	20021ed4 <DMA_AllocChannel+0x94>
20021ece:	4620      	mov	r0, r4
20021ed0:	f7ff ff0f 	bl	20021cf2 <DMA_Init>
20021ed4:	6034      	str	r4, [r6, #0]
20021ed6:	6aa3      	ldr	r3, [r4, #40]	@ 0x28
20021ed8:	f105 4260 	add.w	r2, r5, #3758096384	@ 0xe0000000
20021edc:	015b      	lsls	r3, r3, #5
20021ede:	b2db      	uxtb	r3, r3
20021ee0:	f502 4261 	add.w	r2, r2, #57600	@ 0xe100
20021ee4:	4628      	mov	r0, r5
20021ee6:	f882 3300 	strb.w	r3, [r2, #768]	@ 0x300
20021eea:	f7ff fe69 	bl	20021bc0 <HAL_NVIC_EnableIRQ>
20021eee:	2000      	movs	r0, #0
20021ef0:	e7d4      	b.n	20021e9c <DMA_AllocChannel+0x5c>
20021ef2:	3201      	adds	r2, #1
20021ef4:	2a08      	cmp	r2, #8
20021ef6:	f103 0308 	add.w	r3, r3, #8
20021efa:	d1d1      	bne.n	20021ea0 <DMA_AllocChannel+0x60>
20021efc:	e7cb      	b.n	20021e96 <DMA_AllocChannel+0x56>
20021efe:	4405      	add	r5, r0
20021f00:	7132      	strb	r2, [r6, #4]
20021f02:	b26d      	sxtb	r5, r5
20021f04:	e7dd      	b.n	20021ec2 <DMA_AllocChannel+0x82>
20021f06:	bf00      	nop
20021f08:	aff7eff8 	.word	0xaff7eff8
20021f0c:	bfffeff8 	.word	0xbfffeff8
20021f10:	2004ca1c 	.word	0x2004ca1c
20021f14:	2004c9dc 	.word	0x2004c9dc
20021f18:	50081008 	.word	0x50081008
20021f1c:	40001008 	.word	0x40001008

20021f20 <HAL_DMA_Init>:
20021f20:	b538      	push	{r3, r4, r5, lr}
20021f22:	4604      	mov	r4, r0
20021f24:	2800      	cmp	r0, #0
20021f26:	d05b      	beq.n	20021fe0 <HAL_DMA_Init+0xc0>
20021f28:	6883      	ldr	r3, [r0, #8]
20021f2a:	f033 0210 	bics.w	r2, r3, #16
20021f2e:	d003      	beq.n	20021f38 <HAL_DMA_Init+0x18>
20021f30:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
20021f34:	d000      	beq.n	20021f38 <HAL_DMA_Init+0x18>
20021f36:	e7fe      	b.n	20021f36 <HAL_DMA_Init+0x16>
20021f38:	68e3      	ldr	r3, [r4, #12]
20021f3a:	f033 0340 	bics.w	r3, r3, #64	@ 0x40
20021f3e:	d000      	beq.n	20021f42 <HAL_DMA_Init+0x22>
20021f40:	e7fe      	b.n	20021f40 <HAL_DMA_Init+0x20>
20021f42:	6923      	ldr	r3, [r4, #16]
20021f44:	f033 0380 	bics.w	r3, r3, #128	@ 0x80
20021f48:	d000      	beq.n	20021f4c <HAL_DMA_Init+0x2c>
20021f4a:	e7fe      	b.n	20021f4a <HAL_DMA_Init+0x2a>
20021f4c:	6963      	ldr	r3, [r4, #20]
20021f4e:	f433 7280 	bics.w	r2, r3, #256	@ 0x100
20021f52:	d003      	beq.n	20021f5c <HAL_DMA_Init+0x3c>
20021f54:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
20021f58:	d000      	beq.n	20021f5c <HAL_DMA_Init+0x3c>
20021f5a:	e7fe      	b.n	20021f5a <HAL_DMA_Init+0x3a>
20021f5c:	69a3      	ldr	r3, [r4, #24]
20021f5e:	f433 6280 	bics.w	r2, r3, #1024	@ 0x400
20021f62:	d003      	beq.n	20021f6c <HAL_DMA_Init+0x4c>
20021f64:	f5b3 6f00 	cmp.w	r3, #2048	@ 0x800
20021f68:	d000      	beq.n	20021f6c <HAL_DMA_Init+0x4c>
20021f6a:	e7fe      	b.n	20021f6a <HAL_DMA_Init+0x4a>
20021f6c:	69e3      	ldr	r3, [r4, #28]
20021f6e:	f033 0320 	bics.w	r3, r3, #32
20021f72:	d000      	beq.n	20021f76 <HAL_DMA_Init+0x56>
20021f74:	e7fe      	b.n	20021f74 <HAL_DMA_Init+0x54>
20021f76:	6a23      	ldr	r3, [r4, #32]
20021f78:	f433 5240 	bics.w	r2, r3, #12288	@ 0x3000
20021f7c:	d000      	beq.n	20021f80 <HAL_DMA_Init+0x60>
20021f7e:	e7fe      	b.n	20021f7e <HAL_DMA_Init+0x5e>
20021f80:	6863      	ldr	r3, [r4, #4]
20021f82:	2b51      	cmp	r3, #81	@ 0x51
20021f84:	d900      	bls.n	20021f88 <HAL_DMA_Init+0x68>
20021f86:	e7fe      	b.n	20021f86 <HAL_DMA_Init+0x66>
20021f88:	6821      	ldr	r1, [r4, #0]
20021f8a:	4b17      	ldr	r3, [pc, #92]	@ (20021fe8 <HAL_DMA_Init+0xc8>)
20021f8c:	440b      	add	r3, r1
20021f8e:	2b8c      	cmp	r3, #140	@ 0x8c
20021f90:	d81a      	bhi.n	20021fc8 <HAL_DMA_Init+0xa8>
20021f92:	2214      	movs	r2, #20
20021f94:	fbb3 f3f2 	udiv	r3, r3, r2
20021f98:	2201      	movs	r2, #1
20021f9a:	4914      	ldr	r1, [pc, #80]	@ (20021fec <HAL_DMA_Init+0xcc>)
20021f9c:	0098      	lsls	r0, r3, #2
20021f9e:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021fa2:	ea43 73c2 	orr.w	r3, r3, r2, lsl #31
20021fa6:	e9c4 1013 	strd	r1, r0, [r4, #76]	@ 0x4c
20021faa:	6563      	str	r3, [r4, #84]	@ 0x54
20021fac:	2100      	movs	r1, #0
20021fae:	4620      	mov	r0, r4
20021fb0:	f7ff ff46 	bl	20021e40 <DMA_AllocChannel>
20021fb4:	4605      	mov	r5, r0
20021fb6:	b9a8      	cbnz	r0, 20021fe4 <HAL_DMA_Init+0xc4>
20021fb8:	4620      	mov	r0, r4
20021fba:	f7ff fe9a 	bl	20021cf2 <DMA_Init>
20021fbe:	4620      	mov	r0, r4
20021fc0:	f7ff fe4c 	bl	20021c5c <DMA_FreeChannel.isra.0>
20021fc4:	4628      	mov	r0, r5
20021fc6:	bd38      	pop	{r3, r4, r5, pc}
20021fc8:	4b09      	ldr	r3, [pc, #36]	@ (20021ff0 <HAL_DMA_Init+0xd0>)
20021fca:	440b      	add	r3, r1
20021fcc:	2b8c      	cmp	r3, #140	@ 0x8c
20021fce:	d807      	bhi.n	20021fe0 <HAL_DMA_Init+0xc0>
20021fd0:	2114      	movs	r1, #20
20021fd2:	fbb3 f3f1 	udiv	r3, r3, r1
20021fd6:	4907      	ldr	r1, [pc, #28]	@ (20021ff4 <HAL_DMA_Init+0xd4>)
20021fd8:	0098      	lsls	r0, r3, #2
20021fda:	f023 4300 	bic.w	r3, r3, #2147483648	@ 0x80000000
20021fde:	e7e0      	b.n	20021fa2 <HAL_DMA_Init+0x82>
20021fe0:	2501      	movs	r5, #1
20021fe2:	e7ef      	b.n	20021fc4 <HAL_DMA_Init+0xa4>
20021fe4:	2502      	movs	r5, #2
20021fe6:	e7ed      	b.n	20021fc4 <HAL_DMA_Init+0xa4>
20021fe8:	aff7eff8 	.word	0xaff7eff8
20021fec:	50081000 	.word	0x50081000
20021ff0:	bfffeff8 	.word	0xbfffeff8
20021ff4:	40001000 	.word	0x40001000

20021ff8 <HAL_DMA_DeInit>:
20021ff8:	b538      	push	{r3, r4, r5, lr}
20021ffa:	4604      	mov	r4, r0
20021ffc:	2800      	cmp	r0, #0
20021ffe:	d05e      	beq.n	200220be <HAL_DMA_DeInit+0xc6>
20022000:	6802      	ldr	r2, [r0, #0]
20022002:	4b30      	ldr	r3, [pc, #192]	@ (200220c4 <HAL_DMA_DeInit+0xcc>)
20022004:	4413      	add	r3, r2
20022006:	2b8c      	cmp	r3, #140	@ 0x8c
20022008:	d841      	bhi.n	2002208e <HAL_DMA_DeInit+0x96>
2002200a:	2214      	movs	r2, #20
2002200c:	fbb3 f3f2 	udiv	r3, r3, r2
20022010:	009b      	lsls	r3, r3, #2
20022012:	6503      	str	r3, [r0, #80]	@ 0x50
20022014:	4b2c      	ldr	r3, [pc, #176]	@ (200220c8 <HAL_DMA_DeInit+0xd0>)
20022016:	64e3      	str	r3, [r4, #76]	@ 0x4c
20022018:	4620      	mov	r0, r4
2002201a:	f7ff fdf3 	bl	20021c04 <DMA_IsChannelOwner>
2002201e:	b3a0      	cbz	r0, 2002208a <HAL_DMA_DeInit+0x92>
20022020:	6822      	ldr	r2, [r4, #0]
20022022:	6813      	ldr	r3, [r2, #0]
20022024:	f023 0301 	bic.w	r3, r3, #1
20022028:	6013      	str	r3, [r2, #0]
2002202a:	2200      	movs	r2, #0
2002202c:	6823      	ldr	r3, [r4, #0]
2002202e:	601a      	str	r2, [r3, #0]
20022030:	2201      	movs	r2, #1
20022032:	e9d4 1313 	ldrd	r1, r3, [r4, #76]	@ 0x4c
20022036:	f003 031c 	and.w	r3, r3, #28
2002203a:	fa02 f303 	lsl.w	r3, r2, r3
2002203e:	604b      	str	r3, [r1, #4]
20022040:	f3ef 8510 	mrs	r5, PRIMASK
20022044:	f382 8810 	msr	PRIMASK, r2
20022048:	6d23      	ldr	r3, [r4, #80]	@ 0x50
2002204a:	6ce1      	ldr	r1, [r4, #76]	@ 0x4c
2002204c:	2b0f      	cmp	r3, #15
2002204e:	ea4f 0293 	mov.w	r2, r3, lsr #2
20022052:	d827      	bhi.n	200220a4 <HAL_DMA_DeInit+0xac>
20022054:	203f      	movs	r0, #63	@ 0x3f
20022056:	005b      	lsls	r3, r3, #1
20022058:	f8d1 20a8 	ldr.w	r2, [r1, #168]	@ 0xa8
2002205c:	f003 0338 	and.w	r3, r3, #56	@ 0x38
20022060:	fa00 f303 	lsl.w	r3, r0, r3
20022064:	ea22 0303 	bic.w	r3, r2, r3
20022068:	f8c1 30a8 	str.w	r3, [r1, #168]	@ 0xa8
2002206c:	f385 8810 	msr	PRIMASK, r5
20022070:	4620      	mov	r0, r4
20022072:	f7ff fdf3 	bl	20021c5c <DMA_FreeChannel.isra.0>
20022076:	2300      	movs	r3, #0
20022078:	e9c4 330e 	strd	r3, r3, [r4, #56]	@ 0x38
2002207c:	e9c4 3310 	strd	r3, r3, [r4, #64]	@ 0x40
20022080:	64a3      	str	r3, [r4, #72]	@ 0x48
20022082:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022086:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
2002208a:	2000      	movs	r0, #0
2002208c:	bd38      	pop	{r3, r4, r5, pc}
2002208e:	4b0f      	ldr	r3, [pc, #60]	@ (200220cc <HAL_DMA_DeInit+0xd4>)
20022090:	4413      	add	r3, r2
20022092:	2b8c      	cmp	r3, #140	@ 0x8c
20022094:	d8c0      	bhi.n	20022018 <HAL_DMA_DeInit+0x20>
20022096:	2214      	movs	r2, #20
20022098:	fbb3 f3f2 	udiv	r3, r3, r2
2002209c:	009b      	lsls	r3, r3, #2
2002209e:	6503      	str	r3, [r0, #80]	@ 0x50
200220a0:	4b0b      	ldr	r3, [pc, #44]	@ (200220d0 <HAL_DMA_DeInit+0xd8>)
200220a2:	e7b8      	b.n	20022016 <HAL_DMA_DeInit+0x1e>
200220a4:	f002 0303 	and.w	r3, r2, #3
200220a8:	223f      	movs	r2, #63	@ 0x3f
200220aa:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
200220ae:	00db      	lsls	r3, r3, #3
200220b0:	fa02 f303 	lsl.w	r3, r2, r3
200220b4:	ea20 0303 	bic.w	r3, r0, r3
200220b8:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
200220bc:	e7d6      	b.n	2002206c <HAL_DMA_DeInit+0x74>
200220be:	2001      	movs	r0, #1
200220c0:	e7e4      	b.n	2002208c <HAL_DMA_DeInit+0x94>
200220c2:	bf00      	nop
200220c4:	aff7eff8 	.word	0xaff7eff8
200220c8:	50081000 	.word	0x50081000
200220cc:	bfffeff8 	.word	0xbfffeff8
200220d0:	40001000 	.word	0x40001000

200220d4 <HAL_DMA_PollForTransfer>:
200220d4:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
200220d8:	f890 3031 	ldrb.w	r3, [r0, #49]	@ 0x31
200220dc:	4617      	mov	r7, r2
200220de:	2b02      	cmp	r3, #2
200220e0:	4604      	mov	r4, r0
200220e2:	4688      	mov	r8, r1
200220e4:	b2da      	uxtb	r2, r3
200220e6:	d005      	beq.n	200220f4 <HAL_DMA_PollForTransfer+0x20>
200220e8:	2304      	movs	r3, #4
200220ea:	6483      	str	r3, [r0, #72]	@ 0x48
200220ec:	2300      	movs	r3, #0
200220ee:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
200220f2:	e006      	b.n	20022102 <HAL_DMA_PollForTransfer+0x2e>
200220f4:	6803      	ldr	r3, [r0, #0]
200220f6:	681b      	ldr	r3, [r3, #0]
200220f8:	0699      	lsls	r1, r3, #26
200220fa:	d505      	bpl.n	20022108 <HAL_DMA_PollForTransfer+0x34>
200220fc:	f44f 7380 	mov.w	r3, #256	@ 0x100
20022100:	6483      	str	r3, [r0, #72]	@ 0x48
20022102:	2001      	movs	r0, #1
20022104:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
20022108:	6d05      	ldr	r5, [r0, #80]	@ 0x50
2002210a:	f005 051c 	and.w	r5, r5, #28
2002210e:	f1b8 0f00 	cmp.w	r8, #0
20022112:	d123      	bne.n	2002215c <HAL_DMA_PollForTransfer+0x88>
20022114:	fa02 f505 	lsl.w	r5, r2, r5
20022118:	f7ff fc0e 	bl	20021938 <HAL_GetTick>
2002211c:	f04f 0a08 	mov.w	sl, #8
20022120:	4681      	mov	r9, r0
20022122:	e9d4 6313 	ldrd	r6, r3, [r4, #76]	@ 0x4c
20022126:	f003 031c 	and.w	r3, r3, #28
2002212a:	fa0a f103 	lsl.w	r1, sl, r3
2002212e:	6832      	ldr	r2, [r6, #0]
20022130:	ea12 0b05 	ands.w	fp, r2, r5
20022134:	d016      	beq.n	20022164 <HAL_DMA_PollForTransfer+0x90>
20022136:	f1b8 0f00 	cmp.w	r8, #0
2002213a:	d136      	bne.n	200221aa <HAL_DMA_PollForTransfer+0xd6>
2002213c:	2202      	movs	r2, #2
2002213e:	fa02 f303 	lsl.w	r3, r2, r3
20022142:	6073      	str	r3, [r6, #4]
20022144:	6da3      	ldr	r3, [r4, #88]	@ 0x58
20022146:	b92b      	cbnz	r3, 20022154 <HAL_DMA_PollForTransfer+0x80>
20022148:	4620      	mov	r0, r4
2002214a:	f7ff fd87 	bl	20021c5c <DMA_FreeChannel.isra.0>
2002214e:	2301      	movs	r3, #1
20022150:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
20022154:	2000      	movs	r0, #0
20022156:	f884 0030 	strb.w	r0, [r4, #48]	@ 0x30
2002215a:	e7d3      	b.n	20022104 <HAL_DMA_PollForTransfer+0x30>
2002215c:	2304      	movs	r3, #4
2002215e:	fa03 f505 	lsl.w	r5, r3, r5
20022162:	e7d9      	b.n	20022118 <HAL_DMA_PollForTransfer+0x44>
20022164:	6832      	ldr	r2, [r6, #0]
20022166:	4211      	tst	r1, r2
20022168:	d00c      	beq.n	20022184 <HAL_DMA_PollForTransfer+0xb0>
2002216a:	2501      	movs	r5, #1
2002216c:	fa05 f303 	lsl.w	r3, r5, r3
20022170:	6073      	str	r3, [r6, #4]
20022172:	4620      	mov	r0, r4
20022174:	64a5      	str	r5, [r4, #72]	@ 0x48
20022176:	f7ff fd71 	bl	20021c5c <DMA_FreeChannel.isra.0>
2002217a:	f884 5031 	strb.w	r5, [r4, #49]	@ 0x31
2002217e:	f884 b030 	strb.w	fp, [r4, #48]	@ 0x30
20022182:	e7be      	b.n	20022102 <HAL_DMA_PollForTransfer+0x2e>
20022184:	1c7a      	adds	r2, r7, #1
20022186:	d0d2      	beq.n	2002212e <HAL_DMA_PollForTransfer+0x5a>
20022188:	f7ff fbd6 	bl	20021938 <HAL_GetTick>
2002218c:	eba0 0009 	sub.w	r0, r0, r9
20022190:	42b8      	cmp	r0, r7
20022192:	d801      	bhi.n	20022198 <HAL_DMA_PollForTransfer+0xc4>
20022194:	2f00      	cmp	r7, #0
20022196:	d1c4      	bne.n	20022122 <HAL_DMA_PollForTransfer+0x4e>
20022198:	2320      	movs	r3, #32
2002219a:	4620      	mov	r0, r4
2002219c:	64a3      	str	r3, [r4, #72]	@ 0x48
2002219e:	f7ff fd5d 	bl	20021c5c <DMA_FreeChannel.isra.0>
200221a2:	2301      	movs	r3, #1
200221a4:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
200221a8:	e7a0      	b.n	200220ec <HAL_DMA_PollForTransfer+0x18>
200221aa:	2204      	movs	r2, #4
200221ac:	fa02 f303 	lsl.w	r3, r2, r3
200221b0:	6073      	str	r3, [r6, #4]
200221b2:	e7cf      	b.n	20022154 <HAL_DMA_PollForTransfer+0x80>

200221b4 <DMA_Remap>:
200221b4:	b530      	push	{r4, r5, lr}
200221b6:	4b15      	ldr	r3, [pc, #84]	@ (2002220c <DMA_Remap+0x58>)
200221b8:	6cc4      	ldr	r4, [r0, #76]	@ 0x4c
200221ba:	429c      	cmp	r4, r3
200221bc:	d11b      	bne.n	200221f6 <DMA_Remap+0x42>
200221be:	6883      	ldr	r3, [r0, #8]
200221c0:	2b10      	cmp	r3, #16
200221c2:	d002      	beq.n	200221ca <DMA_Remap+0x16>
200221c4:	f5b3 4f80 	cmp.w	r3, #16384	@ 0x4000
200221c8:	d108      	bne.n	200221dc <DMA_Remap+0x28>
200221ca:	680b      	ldr	r3, [r1, #0]
200221cc:	4c10      	ldr	r4, [pc, #64]	@ (20022210 <DMA_Remap+0x5c>)
200221ce:	f103 4560 	add.w	r5, r3, #3758096384	@ 0xe0000000
200221d2:	42a5      	cmp	r5, r4
200221d4:	bf98      	it	ls
200221d6:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
200221da:	600b      	str	r3, [r1, #0]
200221dc:	6883      	ldr	r3, [r0, #8]
200221de:	f433 4380 	bics.w	r3, r3, #16384	@ 0x4000
200221e2:	d108      	bne.n	200221f6 <DMA_Remap+0x42>
200221e4:	6813      	ldr	r3, [r2, #0]
200221e6:	480a      	ldr	r0, [pc, #40]	@ (20022210 <DMA_Remap+0x5c>)
200221e8:	f103 4460 	add.w	r4, r3, #3758096384	@ 0xe0000000
200221ec:	4284      	cmp	r4, r0
200221ee:	bf98      	it	ls
200221f0:	f103 6320 	addls.w	r3, r3, #167772160	@ 0xa000000
200221f4:	6013      	str	r3, [r2, #0]
200221f6:	680b      	ldr	r3, [r1, #0]
200221f8:	f103 4270 	add.w	r2, r3, #4026531840	@ 0xf0000000
200221fc:	f1b2 5f80 	cmp.w	r2, #268435456	@ 0x10000000
20022200:	bf3c      	itt	cc
20022202:	f103 43a0 	addcc.w	r3, r3, #1342177280	@ 0x50000000
20022206:	600b      	strcc	r3, [r1, #0]
20022208:	bd30      	pop	{r4, r5, pc}
2002220a:	bf00      	nop
2002220c:	40001000 	.word	0x40001000
20022210:	0007fffe 	.word	0x0007fffe

20022214 <DMA_Start>:
20022214:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
20022218:	f64f 75ff 	movw	r5, #65535	@ 0xffff
2002221c:	4a31      	ldr	r2, [pc, #196]	@ (200222e4 <DMA_Start+0xd0>)
2002221e:	4e32      	ldr	r6, [pc, #200]	@ (200222e8 <DMA_Start+0xd4>)
20022220:	460f      	mov	r7, r1
20022222:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
20022224:	6d83      	ldr	r3, [r0, #88]	@ 0x58
20022226:	4291      	cmp	r1, r2
20022228:	bf18      	it	ne
2002222a:	4635      	movne	r5, r6
2002222c:	429d      	cmp	r5, r3
2002222e:	bf28      	it	cs
20022230:	461d      	movcs	r5, r3
20022232:	6802      	ldr	r2, [r0, #0]
20022234:	1b5b      	subs	r3, r3, r5
20022236:	6583      	str	r3, [r0, #88]	@ 0x58
20022238:	6605      	str	r5, [r0, #96]	@ 0x60
2002223a:	6813      	ldr	r3, [r2, #0]
2002223c:	f890 606e 	ldrb.w	r6, [r0, #110]	@ 0x6e
20022240:	f023 0301 	bic.w	r3, r3, #1
20022244:	f890 806f 	ldrb.w	r8, [r0, #111]	@ 0x6f
20022248:	6013      	str	r3, [r2, #0]
2002224a:	e9d0 2319 	ldrd	r2, r3, [r0, #100]	@ 0x64
2002224e:	e9cd 2300 	strd	r2, r3, [sp]
20022252:	e9d0 2313 	ldrd	r2, r3, [r0, #76]	@ 0x4c
20022256:	f003 011c 	and.w	r1, r3, #28
2002225a:	2301      	movs	r3, #1
2002225c:	4604      	mov	r4, r0
2002225e:	408b      	lsls	r3, r1
20022260:	6053      	str	r3, [r2, #4]
20022262:	6803      	ldr	r3, [r0, #0]
20022264:	4669      	mov	r1, sp
20022266:	605d      	str	r5, [r3, #4]
20022268:	aa01      	add	r2, sp, #4
2002226a:	f7ff ffa3 	bl	200221b4 <DMA_Remap>
2002226e:	e9dd 0300 	ldrd	r0, r3, [sp]
20022272:	68a1      	ldr	r1, [r4, #8]
20022274:	6822      	ldr	r2, [r4, #0]
20022276:	2910      	cmp	r1, #16
20022278:	bf0b      	itete	eq
2002227a:	6093      	streq	r3, [r2, #8]
2002227c:	6090      	strne	r0, [r2, #8]
2002227e:	6823      	ldreq	r3, [r4, #0]
20022280:	6822      	ldrne	r2, [r4, #0]
20022282:	bf0c      	ite	eq
20022284:	60d8      	streq	r0, [r3, #12]
20022286:	60d3      	strne	r3, [r2, #12]
20022288:	fa05 f606 	lsl.w	r6, r5, r6
2002228c:	4631      	mov	r1, r6
2002228e:	6e60      	ldr	r0, [r4, #100]	@ 0x64
20022290:	f7ff fa7c 	bl	2002178c <mpu_dcache_clean>
20022294:	f894 306c 	ldrb.w	r3, [r4, #108]	@ 0x6c
20022298:	b113      	cbz	r3, 200222a0 <DMA_Start+0x8c>
2002229a:	6e63      	ldr	r3, [r4, #100]	@ 0x64
2002229c:	4433      	add	r3, r6
2002229e:	6663      	str	r3, [r4, #100]	@ 0x64
200222a0:	f894 306d 	ldrb.w	r3, [r4, #109]	@ 0x6d
200222a4:	b123      	cbz	r3, 200222b0 <DMA_Start+0x9c>
200222a6:	6ea3      	ldr	r3, [r4, #104]	@ 0x68
200222a8:	fa05 f508 	lsl.w	r5, r5, r8
200222ac:	442b      	add	r3, r5
200222ae:	66a3      	str	r3, [r4, #104]	@ 0x68
200222b0:	b137      	cbz	r7, 200222c0 <DMA_Start+0xac>
200222b2:	6be2      	ldr	r2, [r4, #60]	@ 0x3c
200222b4:	6823      	ldr	r3, [r4, #0]
200222b6:	b15a      	cbz	r2, 200222d0 <DMA_Start+0xbc>
200222b8:	681a      	ldr	r2, [r3, #0]
200222ba:	f042 020e 	orr.w	r2, r2, #14
200222be:	601a      	str	r2, [r3, #0]
200222c0:	6822      	ldr	r2, [r4, #0]
200222c2:	6813      	ldr	r3, [r2, #0]
200222c4:	f043 0301 	orr.w	r3, r3, #1
200222c8:	6013      	str	r3, [r2, #0]
200222ca:	b002      	add	sp, #8
200222cc:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200222d0:	681a      	ldr	r2, [r3, #0]
200222d2:	f022 0204 	bic.w	r2, r2, #4
200222d6:	601a      	str	r2, [r3, #0]
200222d8:	6822      	ldr	r2, [r4, #0]
200222da:	6813      	ldr	r3, [r2, #0]
200222dc:	f043 030a 	orr.w	r3, r3, #10
200222e0:	6013      	str	r3, [r2, #0]
200222e2:	e7ed      	b.n	200222c0 <DMA_Start+0xac>
200222e4:	40001000 	.word	0x40001000
200222e8:	000fffff 	.word	0x000fffff

200222ec <HAL_DMA_Start>:
200222ec:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
200222ee:	461d      	mov	r5, r3
200222f0:	69c3      	ldr	r3, [r0, #28]
200222f2:	4604      	mov	r4, r0
200222f4:	2b20      	cmp	r3, #32
200222f6:	460f      	mov	r7, r1
200222f8:	4616      	mov	r6, r2
200222fa:	d10b      	bne.n	20022314 <HAL_DMA_Start+0x28>
200222fc:	b14d      	cbz	r5, 20022312 <HAL_DMA_Start+0x26>
200222fe:	f64f 73ff 	movw	r3, #65535	@ 0xffff
20022302:	6cc1      	ldr	r1, [r0, #76]	@ 0x4c
20022304:	4a1b      	ldr	r2, [pc, #108]	@ (20022374 <HAL_DMA_Start+0x88>)
20022306:	481c      	ldr	r0, [pc, #112]	@ (20022378 <HAL_DMA_Start+0x8c>)
20022308:	4291      	cmp	r1, r2
2002230a:	bf18      	it	ne
2002230c:	4603      	movne	r3, r0
2002230e:	42ab      	cmp	r3, r5
20022310:	d800      	bhi.n	20022314 <HAL_DMA_Start+0x28>
20022312:	e7fe      	b.n	20022312 <HAL_DMA_Start+0x26>
20022314:	f894 3030 	ldrb.w	r3, [r4, #48]	@ 0x30
20022318:	2b01      	cmp	r3, #1
2002231a:	d00e      	beq.n	2002233a <HAL_DMA_Start+0x4e>
2002231c:	2301      	movs	r3, #1
2002231e:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
20022322:	f894 3031 	ldrb.w	r3, [r4, #49]	@ 0x31
20022326:	2b01      	cmp	r3, #1
20022328:	b2d9      	uxtb	r1, r3
2002232a:	d103      	bne.n	20022334 <HAL_DMA_Start+0x48>
2002232c:	4620      	mov	r0, r4
2002232e:	f7ff fd87 	bl	20021e40 <DMA_AllocChannel>
20022332:	b120      	cbz	r0, 2002233e <HAL_DMA_Start+0x52>
20022334:	2300      	movs	r3, #0
20022336:	f884 3030 	strb.w	r3, [r4, #48]	@ 0x30
2002233a:	2002      	movs	r0, #2
2002233c:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
2002233e:	2302      	movs	r3, #2
20022340:	e9c4 5516 	strd	r5, r5, [r4, #88]	@ 0x58
20022344:	e9c4 7619 	strd	r7, r6, [r4, #100]	@ 0x64
20022348:	f884 3031 	strb.w	r3, [r4, #49]	@ 0x31
2002234c:	64a0      	str	r0, [r4, #72]	@ 0x48
2002234e:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20022350:	2800      	cmp	r0, #0
20022352:	d0f3      	beq.n	2002233c <HAL_DMA_Start+0x50>
20022354:	2100      	movs	r1, #0
20022356:	4620      	mov	r0, r4
20022358:	f7ff ff5c 	bl	20022214 <DMA_Start>
2002235c:	6da3      	ldr	r3, [r4, #88]	@ 0x58
2002235e:	2b00      	cmp	r3, #0
20022360:	d0f5      	beq.n	2002234e <HAL_DMA_Start+0x62>
20022362:	f44f 727a 	mov.w	r2, #1000	@ 0x3e8
20022366:	2100      	movs	r1, #0
20022368:	4620      	mov	r0, r4
2002236a:	f7ff feb3 	bl	200220d4 <HAL_DMA_PollForTransfer>
2002236e:	2800      	cmp	r0, #0
20022370:	d0ed      	beq.n	2002234e <HAL_DMA_Start+0x62>
20022372:	e7e3      	b.n	2002233c <HAL_DMA_Start+0x50>
20022374:	40001000 	.word	0x40001000
20022378:	000fffff 	.word	0x000fffff

2002237c <HAL_EFUSE_Init>:
2002237c:	2000      	movs	r0, #0
2002237e:	4770      	bx	lr

20022380 <HAL_EFUSE_Read>:
20022380:	2a20      	cmp	r2, #32
20022382:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20022386:	4607      	mov	r7, r0
20022388:	460c      	mov	r4, r1
2002238a:	4690      	mov	r8, r2
2002238c:	dc25      	bgt.n	200223da <HAL_EFUSE_Read+0x5a>
2002238e:	f3c0 09c4 	ubfx	r9, r0, #3, #5
20022392:	eb09 0302 	add.w	r3, r9, r2
20022396:	2b20      	cmp	r3, #32
20022398:	dc1f      	bgt.n	200223da <HAL_EFUSE_Read+0x5a>
2002239a:	f012 0f03 	tst.w	r2, #3
2002239e:	d11c      	bne.n	200223da <HAL_EFUSE_Read+0x5a>
200223a0:	f010 051f 	ands.w	r5, r0, #31
200223a4:	d119      	bne.n	200223da <HAL_EFUSE_Read+0x5a>
200223a6:	2003      	movs	r0, #3
200223a8:	f7ff f9ea 	bl	20021780 <pmu_ldo_inc>
200223ac:	4629      	mov	r1, r5
200223ae:	4e1d      	ldr	r6, [pc, #116]	@ (20022424 <HAL_EFUSE_Read+0xa4>)
200223b0:	0a3f      	lsrs	r7, r7, #8
200223b2:	00bb      	lsls	r3, r7, #2
200223b4:	6033      	str	r3, [r6, #0]
200223b6:	6833      	ldr	r3, [r6, #0]
200223b8:	4a1b      	ldr	r2, [pc, #108]	@ (20022428 <HAL_EFUSE_Read+0xa8>)
200223ba:	f043 0301 	orr.w	r3, r3, #1
200223be:	6033      	str	r3, [r6, #0]
200223c0:	68b3      	ldr	r3, [r6, #8]
200223c2:	07db      	lsls	r3, r3, #31
200223c4:	d401      	bmi.n	200223ca <HAL_EFUSE_Read+0x4a>
200223c6:	4291      	cmp	r1, r2
200223c8:	d10c      	bne.n	200223e4 <HAL_EFUSE_Read+0x64>
200223ca:	68b3      	ldr	r3, [r6, #8]
200223cc:	4291      	cmp	r1, r2
200223ce:	f043 0301 	orr.w	r3, r3, #1
200223d2:	60b3      	str	r3, [r6, #8]
200223d4:	d108      	bne.n	200223e8 <HAL_EFUSE_Read+0x68>
200223d6:	f7ff f9d5 	bl	20021784 <pmu_ldo_recover>
200223da:	f04f 0800 	mov.w	r8, #0
200223de:	4640      	mov	r0, r8
200223e0:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
200223e4:	3101      	adds	r1, #1
200223e6:	e7eb      	b.n	200223c0 <HAL_EFUSE_Read+0x40>
200223e8:	4a10      	ldr	r2, [pc, #64]	@ (2002242c <HAL_EFUSE_Read+0xac>)
200223ea:	f009 031c 	and.w	r3, r9, #28
200223ee:	eb03 1347 	add.w	r3, r3, r7, lsl #5
200223f2:	f028 0103 	bic.w	r1, r8, #3
200223f6:	441a      	add	r2, r3
200223f8:	4421      	add	r1, r4
200223fa:	428c      	cmp	r4, r1
200223fc:	d102      	bne.n	20022404 <HAL_EFUSE_Read+0x84>
200223fe:	f7ff f9c1 	bl	20021784 <pmu_ldo_recover>
20022402:	e7ec      	b.n	200223de <HAL_EFUSE_Read+0x5e>
20022404:	f852 3b04 	ldr.w	r3, [r2], #4
20022408:	3404      	adds	r4, #4
2002240a:	0a1d      	lsrs	r5, r3, #8
2002240c:	f804 3c04 	strb.w	r3, [r4, #-4]
20022410:	f804 5c03 	strb.w	r5, [r4, #-3]
20022414:	0c1d      	lsrs	r5, r3, #16
20022416:	0e1b      	lsrs	r3, r3, #24
20022418:	f804 5c02 	strb.w	r5, [r4, #-2]
2002241c:	f804 3c01 	strb.w	r3, [r4, #-1]
20022420:	e7eb      	b.n	200223fa <HAL_EFUSE_Read+0x7a>
20022422:	bf00      	nop
20022424:	5000c000 	.word	0x5000c000
20022428:	00bb8000 	.word	0x00bb8000
2002242c:	5000c030 	.word	0x5000c030

20022430 <HAL_HPAON_EnableXT48>:
20022430:	4b04      	ldr	r3, [pc, #16]	@ (20022444 <HAL_HPAON_EnableXT48+0x14>)
20022432:	689a      	ldr	r2, [r3, #8]
20022434:	f042 0202 	orr.w	r2, r2, #2
20022438:	609a      	str	r2, [r3, #8]
2002243a:	689a      	ldr	r2, [r3, #8]
2002243c:	2a00      	cmp	r2, #0
2002243e:	dafc      	bge.n	2002243a <HAL_HPAON_EnableXT48+0xa>
20022440:	4770      	bx	lr
20022442:	bf00      	nop
20022444:	500c0000 	.word	0x500c0000

20022448 <HAL_HPAON_DisableXT48>:
20022448:	4a02      	ldr	r2, [pc, #8]	@ (20022454 <HAL_HPAON_DisableXT48+0xc>)
2002244a:	6893      	ldr	r3, [r2, #8]
2002244c:	f023 0302 	bic.w	r3, r3, #2
20022450:	6093      	str	r3, [r2, #8]
20022452:	4770      	bx	lr
20022454:	500c0000 	.word	0x500c0000

20022458 <HAL_QSPI_Init>:
20022458:	b510      	push	{r4, lr}
2002245a:	b1e8      	cbz	r0, 20022498 <HAL_QSPI_Init+0x40>
2002245c:	b1e1      	cbz	r1, 20022498 <HAL_QSPI_Init+0x40>
2002245e:	2300      	movs	r3, #0
20022460:	2201      	movs	r2, #1
20022462:	6043      	str	r3, [r0, #4]
20022464:	f880 202a 	strb.w	r2, [r0, #42]	@ 0x2a
20022468:	680c      	ldr	r4, [r1, #0]
2002246a:	6004      	str	r4, [r0, #0]
2002246c:	684a      	ldr	r2, [r1, #4]
2002246e:	f880 2028 	strb.w	r2, [r0, #40]	@ 0x28
20022472:	688a      	ldr	r2, [r1, #8]
20022474:	6102      	str	r2, [r0, #16]
20022476:	68ca      	ldr	r2, [r1, #12]
20022478:	0512      	lsls	r2, r2, #20
2002247a:	6142      	str	r2, [r0, #20]
2002247c:	22ff      	movs	r2, #255	@ 0xff
2002247e:	f8c4 208c 	str.w	r2, [r4, #140]	@ 0x8c
20022482:	f04f 2450 	mov.w	r4, #1342197760	@ 0x50005000
20022486:	6801      	ldr	r1, [r0, #0]
20022488:	f8c1 4080 	str.w	r4, [r1, #128]	@ 0x80
2002248c:	6801      	ldr	r1, [r0, #0]
2002248e:	620a      	str	r2, [r1, #32]
20022490:	6801      	ldr	r1, [r0, #0]
20022492:	4618      	mov	r0, r3
20022494:	644a      	str	r2, [r1, #68]	@ 0x44
20022496:	bd10      	pop	{r4, pc}
20022498:	2001      	movs	r0, #1
2002249a:	e7fc      	b.n	20022496 <HAL_QSPI_Init+0x3e>

2002249c <HAL_FLASH_SET_AHB_RCMD>:
2002249c:	b138      	cbz	r0, 200224ae <HAL_FLASH_SET_AHB_RCMD+0x12>
2002249e:	6802      	ldr	r2, [r0, #0]
200224a0:	2000      	movs	r0, #0
200224a2:	6c13      	ldr	r3, [r2, #64]	@ 0x40
200224a4:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
200224a8:	4319      	orrs	r1, r3
200224aa:	6411      	str	r1, [r2, #64]	@ 0x40
200224ac:	4770      	bx	lr
200224ae:	2001      	movs	r0, #1
200224b0:	4770      	bx	lr

200224b2 <HAL_FLASH_CFG_AHB_RCMD>:
200224b2:	b570      	push	{r4, r5, r6, lr}
200224b4:	b1c8      	cbz	r0, 200224ea <HAL_FLASH_CFG_AHB_RCMD+0x38>
200224b6:	6805      	ldr	r5, [r0, #0]
200224b8:	f99d 6018 	ldrsb.w	r6, [sp, #24]
200224bc:	f99d 001c 	ldrsb.w	r0, [sp, #28]
200224c0:	6cac      	ldr	r4, [r5, #72]	@ 0x48
200224c2:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
200224c6:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
200224ca:	f99d 0010 	ldrsb.w	r0, [sp, #16]
200224ce:	f36f 0414 	bfc	r4, #0, #21
200224d2:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
200224d6:	f99d 0014 	ldrsb.w	r0, [sp, #20]
200224da:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
200224de:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
200224e2:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
200224e6:	4321      	orrs	r1, r4
200224e8:	64a9      	str	r1, [r5, #72]	@ 0x48
200224ea:	bd70      	pop	{r4, r5, r6, pc}

200224ec <HAL_FLASH_SET_AHB_WCMD>:
200224ec:	b140      	cbz	r0, 20022500 <HAL_FLASH_SET_AHB_WCMD+0x14>
200224ee:	6802      	ldr	r2, [r0, #0]
200224f0:	2000      	movs	r0, #0
200224f2:	6c13      	ldr	r3, [r2, #64]	@ 0x40
200224f4:	f423 437f 	bic.w	r3, r3, #65280	@ 0xff00
200224f8:	ea43 2101 	orr.w	r1, r3, r1, lsl #8
200224fc:	6411      	str	r1, [r2, #64]	@ 0x40
200224fe:	4770      	bx	lr
20022500:	2001      	movs	r0, #1
20022502:	4770      	bx	lr

20022504 <HAL_FLASH_CFG_AHB_WCMD>:
20022504:	b570      	push	{r4, r5, r6, lr}
20022506:	b1c8      	cbz	r0, 2002253c <HAL_FLASH_CFG_AHB_WCMD+0x38>
20022508:	6805      	ldr	r5, [r0, #0]
2002250a:	f99d 6018 	ldrsb.w	r6, [sp, #24]
2002250e:	f99d 001c 	ldrsb.w	r0, [sp, #28]
20022512:	6d2c      	ldr	r4, [r5, #80]	@ 0x50
20022514:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022518:	ea40 23c3 	orr.w	r3, r0, r3, lsl #11
2002251c:	f99d 0010 	ldrsb.w	r0, [sp, #16]
20022520:	f36f 0414 	bfc	r4, #0, #21
20022524:	ea43 2300 	orr.w	r3, r3, r0, lsl #8
20022528:	f99d 0014 	ldrsb.w	r0, [sp, #20]
2002252c:	ea43 1380 	orr.w	r3, r3, r0, lsl #6
20022530:	ea43 3242 	orr.w	r2, r3, r2, lsl #13
20022534:	ea42 4181 	orr.w	r1, r2, r1, lsl #18
20022538:	4321      	orrs	r1, r4
2002253a:	6529      	str	r1, [r5, #80]	@ 0x50
2002253c:	bd70      	pop	{r4, r5, r6, pc}

2002253e <HAL_FLASH_WRITE_WORD>:
2002253e:	b118      	cbz	r0, 20022548 <HAL_FLASH_WRITE_WORD+0xa>
20022540:	6803      	ldr	r3, [r0, #0]
20022542:	2000      	movs	r0, #0
20022544:	6059      	str	r1, [r3, #4]
20022546:	4770      	bx	lr
20022548:	2001      	movs	r0, #1
2002254a:	4770      	bx	lr

2002254c <HAL_FLASH_WRITE_DLEN>:
2002254c:	b130      	cbz	r0, 2002255c <HAL_FLASH_WRITE_DLEN+0x10>
2002254e:	6803      	ldr	r3, [r0, #0]
20022550:	3901      	subs	r1, #1
20022552:	f3c1 0113 	ubfx	r1, r1, #0, #20
20022556:	2000      	movs	r0, #0
20022558:	6259      	str	r1, [r3, #36]	@ 0x24
2002255a:	4770      	bx	lr
2002255c:	2001      	movs	r0, #1
2002255e:	4770      	bx	lr

20022560 <HAL_FLASH_WRITE_DLEN2>:
20022560:	b130      	cbz	r0, 20022570 <HAL_FLASH_WRITE_DLEN2+0x10>
20022562:	6803      	ldr	r3, [r0, #0]
20022564:	3901      	subs	r1, #1
20022566:	f3c1 0113 	ubfx	r1, r1, #0, #20
2002256a:	2000      	movs	r0, #0
2002256c:	6399      	str	r1, [r3, #56]	@ 0x38
2002256e:	4770      	bx	lr
20022570:	2001      	movs	r0, #1
20022572:	4770      	bx	lr

20022574 <HAL_FLASH_WRITE_ABYTE>:
20022574:	b108      	cbz	r0, 2002257a <HAL_FLASH_WRITE_ABYTE+0x6>
20022576:	6803      	ldr	r3, [r0, #0]
20022578:	6219      	str	r1, [r3, #32]
2002257a:	4770      	bx	lr

2002257c <HAL_FLASH_IS_CMD_DONE>:
2002257c:	b118      	cbz	r0, 20022586 <HAL_FLASH_IS_CMD_DONE+0xa>
2002257e:	6803      	ldr	r3, [r0, #0]
20022580:	6918      	ldr	r0, [r3, #16]
20022582:	f000 0001 	and.w	r0, r0, #1
20022586:	4770      	bx	lr

20022588 <HAL_FLASH_CLR_CMD_DONE>:
20022588:	b120      	cbz	r0, 20022594 <HAL_FLASH_CLR_CMD_DONE+0xc>
2002258a:	6802      	ldr	r2, [r0, #0]
2002258c:	6953      	ldr	r3, [r2, #20]
2002258e:	f043 0301 	orr.w	r3, r3, #1
20022592:	6153      	str	r3, [r2, #20]
20022594:	4770      	bx	lr

20022596 <HAL_FLASH_SET_CMD>:
20022596:	b538      	push	{r3, r4, r5, lr}
20022598:	460d      	mov	r5, r1
2002259a:	4604      	mov	r4, r0
2002259c:	b1a8      	cbz	r0, 200225ca <HAL_FLASH_SET_CMD+0x34>
2002259e:	6803      	ldr	r3, [r0, #0]
200225a0:	61da      	str	r2, [r3, #28]
200225a2:	6b43      	ldr	r3, [r0, #52]	@ 0x34
200225a4:	b10b      	cbz	r3, 200225aa <HAL_FLASH_SET_CMD+0x14>
200225a6:	2001      	movs	r0, #1
200225a8:	4798      	blx	r3
200225aa:	6823      	ldr	r3, [r4, #0]
200225ac:	619d      	str	r5, [r3, #24]
200225ae:	4620      	mov	r0, r4
200225b0:	f7ff ffe4 	bl	2002257c <HAL_FLASH_IS_CMD_DONE>
200225b4:	2800      	cmp	r0, #0
200225b6:	d0fa      	beq.n	200225ae <HAL_FLASH_SET_CMD+0x18>
200225b8:	4620      	mov	r0, r4
200225ba:	f7ff ffe5 	bl	20022588 <HAL_FLASH_CLR_CMD_DONE>
200225be:	6b63      	ldr	r3, [r4, #52]	@ 0x34
200225c0:	b10b      	cbz	r3, 200225c6 <HAL_FLASH_SET_CMD+0x30>
200225c2:	2000      	movs	r0, #0
200225c4:	4798      	blx	r3
200225c6:	2000      	movs	r0, #0
200225c8:	bd38      	pop	{r3, r4, r5, pc}
200225ca:	2001      	movs	r0, #1
200225cc:	e7fc      	b.n	200225c8 <HAL_FLASH_SET_CMD+0x32>

200225ce <HAL_FLASH_CLR_STATUS>:
200225ce:	b118      	cbz	r0, 200225d8 <HAL_FLASH_CLR_STATUS+0xa>
200225d0:	6802      	ldr	r2, [r0, #0]
200225d2:	6953      	ldr	r3, [r2, #20]
200225d4:	4319      	orrs	r1, r3
200225d6:	6151      	str	r1, [r2, #20]
200225d8:	4770      	bx	lr

200225da <HAL_FLASH_STATUS_MATCH>:
200225da:	b118      	cbz	r0, 200225e4 <HAL_FLASH_STATUS_MATCH+0xa>
200225dc:	6803      	ldr	r3, [r0, #0]
200225de:	6918      	ldr	r0, [r3, #16]
200225e0:	f3c0 00c0 	ubfx	r0, r0, #3, #1
200225e4:	4770      	bx	lr

200225e6 <HAL_FLASH_IS_PROG_DONE>:
200225e6:	b128      	cbz	r0, 200225f4 <HAL_FLASH_IS_PROG_DONE+0xe>
200225e8:	6803      	ldr	r3, [r0, #0]
200225ea:	6858      	ldr	r0, [r3, #4]
200225ec:	43c0      	mvns	r0, r0
200225ee:	f000 0001 	and.w	r0, r0, #1
200225f2:	4770      	bx	lr
200225f4:	2001      	movs	r0, #1
200225f6:	4770      	bx	lr

200225f8 <HAL_FLASH_READ32>:
200225f8:	b108      	cbz	r0, 200225fe <HAL_FLASH_READ32+0x6>
200225fa:	6803      	ldr	r3, [r0, #0]
200225fc:	6858      	ldr	r0, [r3, #4]
200225fe:	4770      	bx	lr

20022600 <HAL_FLASH_SET_TXSLOT>:
20022600:	b120      	cbz	r0, 2002260c <HAL_FLASH_SET_TXSLOT+0xc>
20022602:	6802      	ldr	r2, [r0, #0]
20022604:	6d53      	ldr	r3, [r2, #84]	@ 0x54
20022606:	f361 238e 	bfi	r3, r1, #10, #5
2002260a:	6553      	str	r3, [r2, #84]	@ 0x54
2002260c:	4770      	bx	lr

2002260e <HAL_FLASH_SET_CLK_rom>:
2002260e:	b108      	cbz	r0, 20022614 <HAL_FLASH_SET_CLK_rom+0x6>
20022610:	6803      	ldr	r3, [r0, #0]
20022612:	60d9      	str	r1, [r3, #12]
20022614:	4770      	bx	lr

20022616 <HAL_FLASH_GET_DIV>:
20022616:	b110      	cbz	r0, 2002261e <HAL_FLASH_GET_DIV+0x8>
20022618:	6803      	ldr	r3, [r0, #0]
2002261a:	68d8      	ldr	r0, [r3, #12]
2002261c:	b2c0      	uxtb	r0, r0
2002261e:	4770      	bx	lr

20022620 <HAL_FLASH_MANUAL_CMD>:
20022620:	b570      	push	{r4, r5, r6, lr}
20022622:	b1e8      	cbz	r0, 20022660 <HAL_FLASH_MANUAL_CMD+0x40>
20022624:	6805      	ldr	r5, [r0, #0]
20022626:	f99d 601c 	ldrsb.w	r6, [sp, #28]
2002262a:	f99d 0020 	ldrsb.w	r0, [sp, #32]
2002262e:	6aac      	ldr	r4, [r5, #40]	@ 0x28
20022630:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022634:	f99d 6010 	ldrsb.w	r6, [sp, #16]
20022638:	f36f 0415 	bfc	r4, #0, #22
2002263c:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022640:	f99d 6014 	ldrsb.w	r6, [sp, #20]
20022644:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
20022648:	f99d 6018 	ldrsb.w	r6, [sp, #24]
2002264c:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022650:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
20022654:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
20022658:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
2002265c:	4321      	orrs	r1, r4
2002265e:	62a9      	str	r1, [r5, #40]	@ 0x28
20022660:	bd70      	pop	{r4, r5, r6, pc}

20022662 <HAL_FLASH_MANUAL_CMD2>:
20022662:	b570      	push	{r4, r5, r6, lr}
20022664:	b1e8      	cbz	r0, 200226a2 <HAL_FLASH_MANUAL_CMD2+0x40>
20022666:	6805      	ldr	r5, [r0, #0]
20022668:	f99d 601c 	ldrsb.w	r6, [sp, #28]
2002266c:	f99d 0020 	ldrsb.w	r0, [sp, #32]
20022670:	6bec      	ldr	r4, [r5, #60]	@ 0x3c
20022672:	ea40 00c6 	orr.w	r0, r0, r6, lsl #3
20022676:	f99d 6010 	ldrsb.w	r6, [sp, #16]
2002267a:	f36f 0415 	bfc	r4, #0, #22
2002267e:	ea40 20c6 	orr.w	r0, r0, r6, lsl #11
20022682:	f99d 6014 	ldrsb.w	r6, [sp, #20]
20022686:	ea40 2006 	orr.w	r0, r0, r6, lsl #8
2002268a:	f99d 6018 	ldrsb.w	r6, [sp, #24]
2002268e:	ea40 1086 	orr.w	r0, r0, r6, lsl #6
20022692:	ea40 3343 	orr.w	r3, r0, r3, lsl #13
20022696:	ea43 4282 	orr.w	r2, r3, r2, lsl #18
2002269a:	ea42 5141 	orr.w	r1, r2, r1, lsl #21
2002269e:	4321      	orrs	r1, r4
200226a0:	63e9      	str	r1, [r5, #60]	@ 0x3c
200226a2:	bd70      	pop	{r4, r5, r6, pc}

200226a4 <HAL_FLASH_SET_ALIAS_RANGE>:
200226a4:	b510      	push	{r4, lr}
200226a6:	b158      	cbz	r0, 200226c0 <HAL_FLASH_SET_ALIAS_RANGE+0x1c>
200226a8:	4b06      	ldr	r3, [pc, #24]	@ (200226c4 <HAL_FLASH_SET_ALIAS_RANGE+0x20>)
200226aa:	6804      	ldr	r4, [r0, #0]
200226ac:	f202 32ff 	addw	r2, r2, #1023	@ 0x3ff
200226b0:	440a      	add	r2, r1
200226b2:	4019      	ands	r1, r3
200226b4:	6761      	str	r1, [r4, #116]	@ 0x74
200226b6:	401a      	ands	r2, r3
200226b8:	6803      	ldr	r3, [r0, #0]
200226ba:	2000      	movs	r0, #0
200226bc:	679a      	str	r2, [r3, #120]	@ 0x78
200226be:	bd10      	pop	{r4, pc}
200226c0:	2001      	movs	r0, #1
200226c2:	e7fc      	b.n	200226be <HAL_FLASH_SET_ALIAS_RANGE+0x1a>
200226c4:	fffffc00 	.word	0xfffffc00

200226c8 <HAL_FLASH_SET_ALIAS_OFFSET>:
200226c8:	b128      	cbz	r0, 200226d6 <HAL_FLASH_SET_ALIAS_OFFSET+0xe>
200226ca:	6803      	ldr	r3, [r0, #0]
200226cc:	f36f 0109 	bfc	r1, #0, #10
200226d0:	2000      	movs	r0, #0
200226d2:	67d9      	str	r1, [r3, #124]	@ 0x7c
200226d4:	4770      	bx	lr
200226d6:	2001      	movs	r0, #1
200226d8:	4770      	bx	lr

200226da <HAL_FLASH_ENABLE_QSPI>:
200226da:	b150      	cbz	r0, 200226f2 <HAL_FLASH_ENABLE_QSPI+0x18>
200226dc:	6803      	ldr	r3, [r0, #0]
200226de:	681a      	ldr	r2, [r3, #0]
200226e0:	b121      	cbz	r1, 200226ec <HAL_FLASH_ENABLE_QSPI+0x12>
200226e2:	f042 0201 	orr.w	r2, r2, #1
200226e6:	2000      	movs	r0, #0
200226e8:	601a      	str	r2, [r3, #0]
200226ea:	4770      	bx	lr
200226ec:	f022 0201 	bic.w	r2, r2, #1
200226f0:	e7f9      	b.n	200226e6 <HAL_FLASH_ENABLE_QSPI+0xc>
200226f2:	2001      	movs	r0, #1
200226f4:	4770      	bx	lr

200226f6 <HAL_FLASH_ENABLE_OPI>:
200226f6:	b150      	cbz	r0, 2002270e <HAL_FLASH_ENABLE_OPI+0x18>
200226f8:	6803      	ldr	r3, [r0, #0]
200226fa:	681a      	ldr	r2, [r3, #0]
200226fc:	b121      	cbz	r1, 20022708 <HAL_FLASH_ENABLE_OPI+0x12>
200226fe:	f442 1200 	orr.w	r2, r2, #2097152	@ 0x200000
20022702:	2000      	movs	r0, #0
20022704:	601a      	str	r2, [r3, #0]
20022706:	4770      	bx	lr
20022708:	f422 1200 	bic.w	r2, r2, #2097152	@ 0x200000
2002270c:	e7f9      	b.n	20022702 <HAL_FLASH_ENABLE_OPI+0xc>
2002270e:	2001      	movs	r0, #1
20022710:	4770      	bx	lr

20022712 <HAL_FLASH_ENABLE_HYPER>:
20022712:	b148      	cbz	r0, 20022728 <HAL_FLASH_ENABLE_HYPER+0x16>
20022714:	6802      	ldr	r2, [r0, #0]
20022716:	6893      	ldr	r3, [r2, #8]
20022718:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
2002271c:	b109      	cbz	r1, 20022722 <HAL_FLASH_ENABLE_HYPER+0x10>
2002271e:	f043 0320 	orr.w	r3, r3, #32
20022722:	2000      	movs	r0, #0
20022724:	6093      	str	r3, [r2, #8]
20022726:	4770      	bx	lr
20022728:	2001      	movs	r0, #1
2002272a:	4770      	bx	lr

2002272c <HAL_FLASH_ENABLE_CMD2>:
2002272c:	b150      	cbz	r0, 20022744 <HAL_FLASH_ENABLE_CMD2+0x18>
2002272e:	6803      	ldr	r3, [r0, #0]
20022730:	681a      	ldr	r2, [r3, #0]
20022732:	b121      	cbz	r1, 2002273e <HAL_FLASH_ENABLE_CMD2+0x12>
20022734:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
20022738:	2000      	movs	r0, #0
2002273a:	601a      	str	r2, [r3, #0]
2002273c:	4770      	bx	lr
2002273e:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
20022742:	e7f9      	b.n	20022738 <HAL_FLASH_ENABLE_CMD2+0xc>
20022744:	2001      	movs	r0, #1
20022746:	4770      	bx	lr

20022748 <HAL_FLASH_STAUS_MATCH_CMD2>:
20022748:	b150      	cbz	r0, 20022760 <HAL_FLASH_STAUS_MATCH_CMD2+0x18>
2002274a:	6803      	ldr	r3, [r0, #0]
2002274c:	681a      	ldr	r2, [r3, #0]
2002274e:	b121      	cbz	r1, 2002275a <HAL_FLASH_STAUS_MATCH_CMD2+0x12>
20022750:	f442 2280 	orr.w	r2, r2, #262144	@ 0x40000
20022754:	2000      	movs	r0, #0
20022756:	601a      	str	r2, [r3, #0]
20022758:	4770      	bx	lr
2002275a:	f422 2280 	bic.w	r2, r2, #262144	@ 0x40000
2002275e:	e7f9      	b.n	20022754 <HAL_FLASH_STAUS_MATCH_CMD2+0xc>
20022760:	2001      	movs	r0, #1
20022762:	4770      	bx	lr

20022764 <HAL_FLASH_SET_CS_TIME>:
20022764:	b530      	push	{r4, r5, lr}
20022766:	b180      	cbz	r0, 2002278a <HAL_FLASH_SET_CS_TIME+0x26>
20022768:	6805      	ldr	r5, [r0, #0]
2002276a:	f8bd 000c 	ldrh.w	r0, [sp, #12]
2002276e:	68ac      	ldr	r4, [r5, #8]
20022770:	0680      	lsls	r0, r0, #26
20022772:	ea40 5383 	orr.w	r3, r0, r3, lsl #22
20022776:	2000      	movs	r0, #0
20022778:	ea43 4181 	orr.w	r1, r3, r1, lsl #18
2002277c:	f36f 149e 	bfc	r4, #6, #25
20022780:	ea41 1282 	orr.w	r2, r1, r2, lsl #6
20022784:	4322      	orrs	r2, r4
20022786:	60aa      	str	r2, [r5, #8]
20022788:	bd30      	pop	{r4, r5, pc}
2002278a:	2001      	movs	r0, #1
2002278c:	e7fc      	b.n	20022788 <HAL_FLASH_SET_CS_TIME+0x24>

2002278e <HAL_FLASH_SET_ROW_BOUNDARY>:
2002278e:	b130      	cbz	r0, 2002279e <HAL_FLASH_SET_ROW_BOUNDARY+0x10>
20022790:	6802      	ldr	r2, [r0, #0]
20022792:	2000      	movs	r0, #0
20022794:	6893      	ldr	r3, [r2, #8]
20022796:	f361 0302 	bfi	r3, r1, #0, #3
2002279a:	6093      	str	r3, [r2, #8]
2002279c:	4770      	bx	lr
2002279e:	2001      	movs	r0, #1
200227a0:	4770      	bx	lr

200227a2 <HAL_FLASH_SET_LEGACY>:
200227a2:	b148      	cbz	r0, 200227b8 <HAL_FLASH_SET_LEGACY+0x16>
200227a4:	6802      	ldr	r2, [r0, #0]
200227a6:	6893      	ldr	r3, [r2, #8]
200227a8:	f023 0330 	bic.w	r3, r3, #48	@ 0x30
200227ac:	b109      	cbz	r1, 200227b2 <HAL_FLASH_SET_LEGACY+0x10>
200227ae:	f043 0310 	orr.w	r3, r3, #16
200227b2:	2000      	movs	r0, #0
200227b4:	6093      	str	r3, [r2, #8]
200227b6:	4770      	bx	lr
200227b8:	2001      	movs	r0, #1
200227ba:	4770      	bx	lr

200227bc <HAL_FLASH_SET_DUAL_MODE>:
200227bc:	b150      	cbz	r0, 200227d4 <HAL_FLASH_SET_DUAL_MODE+0x18>
200227be:	6803      	ldr	r3, [r0, #0]
200227c0:	681a      	ldr	r2, [r3, #0]
200227c2:	b121      	cbz	r1, 200227ce <HAL_FLASH_SET_DUAL_MODE+0x12>
200227c4:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
200227c8:	2000      	movs	r0, #0
200227ca:	601a      	str	r2, [r3, #0]
200227cc:	4770      	bx	lr
200227ce:	f022 7280 	bic.w	r2, r2, #16777216	@ 0x1000000
200227d2:	e7f9      	b.n	200227c8 <HAL_FLASH_SET_DUAL_MODE+0xc>
200227d4:	2001      	movs	r0, #1
200227d6:	4770      	bx	lr

200227d8 <HAL_FLASH_SET_X16_MODE>:
200227d8:	b150      	cbz	r0, 200227f0 <HAL_FLASH_SET_X16_MODE+0x18>
200227da:	6803      	ldr	r3, [r0, #0]
200227dc:	681a      	ldr	r2, [r3, #0]
200227de:	b121      	cbz	r1, 200227ea <HAL_FLASH_SET_X16_MODE+0x12>
200227e0:	f442 0200 	orr.w	r2, r2, #8388608	@ 0x800000
200227e4:	2000      	movs	r0, #0
200227e6:	601a      	str	r2, [r3, #0]
200227e8:	4770      	bx	lr
200227ea:	f422 0200 	bic.w	r2, r2, #8388608	@ 0x800000
200227ee:	e7f9      	b.n	200227e4 <HAL_FLASH_SET_X16_MODE+0xc>
200227f0:	2001      	movs	r0, #1
200227f2:	4770      	bx	lr

200227f4 <HAL_MPI_EN_FIXLAT>:
200227f4:	2000      	movs	r0, #0
200227f6:	4770      	bx	lr

200227f8 <HAL_MPI_ENABLE_DQS>:
200227f8:	fab0 f080 	clz	r0, r0
200227fc:	0940      	lsrs	r0, r0, #5
200227fe:	4770      	bx	lr

20022800 <HAL_MPI_SET_DQS_DELAY>:
20022800:	b138      	cbz	r0, 20022812 <HAL_MPI_SET_DQS_DELAY+0x12>
20022802:	6802      	ldr	r2, [r0, #0]
20022804:	2000      	movs	r0, #0
20022806:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022808:	f023 03ff 	bic.w	r3, r3, #255	@ 0xff
2002280c:	4319      	orrs	r1, r3
2002280e:	6591      	str	r1, [r2, #88]	@ 0x58
20022810:	4770      	bx	lr
20022812:	2001      	movs	r0, #1
20022814:	4770      	bx	lr

20022816 <HAL_MPI_SET_SCK>:
20022816:	b150      	cbz	r0, 2002282e <HAL_MPI_SET_SCK+0x18>
20022818:	6800      	ldr	r0, [r0, #0]
2002281a:	0412      	lsls	r2, r2, #16
2002281c:	6d83      	ldr	r3, [r0, #88]	@ 0x58
2002281e:	ea42 2101 	orr.w	r1, r2, r1, lsl #8
20022822:	f36f 2310 	bfc	r3, #8, #9
20022826:	4319      	orrs	r1, r3
20022828:	6581      	str	r1, [r0, #88]	@ 0x58
2002282a:	2000      	movs	r0, #0
2002282c:	4770      	bx	lr
2002282e:	2001      	movs	r0, #1
20022830:	4770      	bx	lr

20022832 <HAL_MPI_CFG_DTR>:
20022832:	6803      	ldr	r3, [r0, #0]
20022834:	6d9a      	ldr	r2, [r3, #88]	@ 0x58
20022836:	b121      	cbz	r1, 20022842 <HAL_MPI_CFG_DTR+0x10>
20022838:	f422 3280 	bic.w	r2, r2, #65536	@ 0x10000
2002283c:	2000      	movs	r0, #0
2002283e:	659a      	str	r2, [r3, #88]	@ 0x58
20022840:	4770      	bx	lr
20022842:	f442 3280 	orr.w	r2, r2, #65536	@ 0x10000
20022846:	e7f9      	b.n	2002283c <HAL_MPI_CFG_DTR+0xa>

20022848 <HAL_MPI_MODIFY_RCMD_DELAY>:
20022848:	b130      	cbz	r0, 20022858 <HAL_MPI_MODIFY_RCMD_DELAY+0x10>
2002284a:	6802      	ldr	r2, [r0, #0]
2002284c:	6c93      	ldr	r3, [r2, #72]	@ 0x48
2002284e:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
20022852:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
20022856:	6491      	str	r1, [r2, #72]	@ 0x48
20022858:	4770      	bx	lr

2002285a <HAL_MPI_MODIFY_WCMD_DELAY>:
2002285a:	b130      	cbz	r0, 2002286a <HAL_MPI_MODIFY_WCMD_DELAY+0x10>
2002285c:	6802      	ldr	r2, [r0, #0]
2002285e:	6d13      	ldr	r3, [r2, #80]	@ 0x50
20022860:	f423 3378 	bic.w	r3, r3, #253952	@ 0x3e000
20022864:	ea43 3141 	orr.w	r1, r3, r1, lsl #13
20022868:	6511      	str	r1, [r2, #80]	@ 0x50
2002286a:	4770      	bx	lr

2002286c <HAL_FLASH_SET_WDT>:
2002286c:	b148      	cbz	r0, 20022882 <HAL_FLASH_SET_WDT+0x16>
2002286e:	6803      	ldr	r3, [r0, #0]
20022870:	f8d3 2090 	ldr.w	r2, [r3, #144]	@ 0x90
20022874:	b109      	cbz	r1, 2002287a <HAL_FLASH_SET_WDT+0xe>
20022876:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
2002287a:	2000      	movs	r0, #0
2002287c:	f8c3 1090 	str.w	r1, [r3, #144]	@ 0x90
20022880:	4770      	bx	lr
20022882:	2001      	movs	r0, #1
20022884:	4770      	bx	lr

20022886 <HAL_FLASH_CONFIG_AHB_READ>:
20022886:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20022888:	4605      	mov	r5, r0
2002288a:	2800      	cmp	r0, #0
2002288c:	d03d      	beq.n	2002290a <HAL_FLASH_CONFIG_AHB_READ+0x84>
2002288e:	68c4      	ldr	r4, [r0, #12]
20022890:	b301      	cbz	r1, 200228d4 <HAL_FLASH_CONFIG_AHB_READ+0x4e>
20022892:	f894 306a 	ldrb.w	r3, [r4, #106]	@ 0x6a
20022896:	2b00      	cmp	r3, #0
20022898:	d037      	beq.n	2002290a <HAL_FLASH_CONFIG_AHB_READ+0x84>
2002289a:	f994 6072 	ldrsb.w	r6, [r4, #114]	@ 0x72
2002289e:	f994 306e 	ldrsb.w	r3, [r4, #110]	@ 0x6e
200228a2:	f994 106c 	ldrsb.w	r1, [r4, #108]	@ 0x6c
200228a6:	f994 206d 	ldrsb.w	r2, [r4, #109]	@ 0x6d
200228aa:	9603      	str	r6, [sp, #12]
200228ac:	f994 6071 	ldrsb.w	r6, [r4, #113]	@ 0x71
200228b0:	9602      	str	r6, [sp, #8]
200228b2:	f994 6070 	ldrsb.w	r6, [r4, #112]	@ 0x70
200228b6:	9601      	str	r6, [sp, #4]
200228b8:	f994 406f 	ldrsb.w	r4, [r4, #111]	@ 0x6f
200228bc:	9400      	str	r4, [sp, #0]
200228be:	f7ff fdf8 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
200228c2:	68eb      	ldr	r3, [r5, #12]
200228c4:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
200228c8:	4628      	mov	r0, r5
200228ca:	f7ff fde7 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
200228ce:	2000      	movs	r0, #0
200228d0:	b004      	add	sp, #16
200228d2:	bd70      	pop	{r4, r5, r6, pc}
200228d4:	f894 3046 	ldrb.w	r3, [r4, #70]	@ 0x46
200228d8:	b1bb      	cbz	r3, 2002290a <HAL_FLASH_CONFIG_AHB_READ+0x84>
200228da:	f994 604e 	ldrsb.w	r6, [r4, #78]	@ 0x4e
200228de:	f994 304a 	ldrsb.w	r3, [r4, #74]	@ 0x4a
200228e2:	f994 1048 	ldrsb.w	r1, [r4, #72]	@ 0x48
200228e6:	f994 2049 	ldrsb.w	r2, [r4, #73]	@ 0x49
200228ea:	9603      	str	r6, [sp, #12]
200228ec:	f994 604d 	ldrsb.w	r6, [r4, #77]	@ 0x4d
200228f0:	9602      	str	r6, [sp, #8]
200228f2:	f994 604c 	ldrsb.w	r6, [r4, #76]	@ 0x4c
200228f6:	9601      	str	r6, [sp, #4]
200228f8:	f994 404b 	ldrsb.w	r4, [r4, #75]	@ 0x4b
200228fc:	9400      	str	r4, [sp, #0]
200228fe:	f7ff fdd8 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20022902:	68eb      	ldr	r3, [r5, #12]
20022904:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20022908:	e7de      	b.n	200228c8 <HAL_FLASH_CONFIG_AHB_READ+0x42>
2002290a:	2001      	movs	r0, #1
2002290c:	e7e0      	b.n	200228d0 <HAL_FLASH_CONFIG_AHB_READ+0x4a>

2002290e <HAL_FLASH_CONFIG_FULL_AHB_READ>:
2002290e:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
20022910:	4605      	mov	r5, r0
20022912:	2800      	cmp	r0, #0
20022914:	d036      	beq.n	20022984 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x76>
20022916:	68c4      	ldr	r4, [r0, #12]
20022918:	b1e1      	cbz	r1, 20022954 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x46>
2002291a:	f994 616e 	ldrsb.w	r6, [r4, #366]	@ 0x16e
2002291e:	f994 316a 	ldrsb.w	r3, [r4, #362]	@ 0x16a
20022922:	f994 1168 	ldrsb.w	r1, [r4, #360]	@ 0x168
20022926:	f994 2169 	ldrsb.w	r2, [r4, #361]	@ 0x169
2002292a:	9603      	str	r6, [sp, #12]
2002292c:	f994 616d 	ldrsb.w	r6, [r4, #365]	@ 0x16d
20022930:	9602      	str	r6, [sp, #8]
20022932:	f994 616c 	ldrsb.w	r6, [r4, #364]	@ 0x16c
20022936:	9601      	str	r6, [sp, #4]
20022938:	f994 416b 	ldrsb.w	r4, [r4, #363]	@ 0x16b
2002293c:	9400      	str	r4, [sp, #0]
2002293e:	f7ff fdb8 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20022942:	68eb      	ldr	r3, [r5, #12]
20022944:	f893 1166 	ldrb.w	r1, [r3, #358]	@ 0x166
20022948:	4628      	mov	r0, r5
2002294a:	f7ff fda7 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
2002294e:	2000      	movs	r0, #0
20022950:	b004      	add	sp, #16
20022952:	bd70      	pop	{r4, r5, r6, pc}
20022954:	f994 615c 	ldrsb.w	r6, [r4, #348]	@ 0x15c
20022958:	f994 3158 	ldrsb.w	r3, [r4, #344]	@ 0x158
2002295c:	f994 1156 	ldrsb.w	r1, [r4, #342]	@ 0x156
20022960:	f994 2157 	ldrsb.w	r2, [r4, #343]	@ 0x157
20022964:	9603      	str	r6, [sp, #12]
20022966:	f994 615b 	ldrsb.w	r6, [r4, #347]	@ 0x15b
2002296a:	9602      	str	r6, [sp, #8]
2002296c:	f994 615a 	ldrsb.w	r6, [r4, #346]	@ 0x15a
20022970:	9601      	str	r6, [sp, #4]
20022972:	f994 4159 	ldrsb.w	r4, [r4, #345]	@ 0x159
20022976:	9400      	str	r4, [sp, #0]
20022978:	f7ff fd9b 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
2002297c:	68eb      	ldr	r3, [r5, #12]
2002297e:	f893 1154 	ldrb.w	r1, [r3, #340]	@ 0x154
20022982:	e7e1      	b.n	20022948 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x3a>
20022984:	2001      	movs	r0, #1
20022986:	e7e3      	b.n	20022950 <HAL_FLASH_CONFIG_FULL_AHB_READ+0x42>

20022988 <HAL_FLASH_PRE_CMD>:
20022988:	b530      	push	{r4, r5, lr}
2002298a:	68c4      	ldr	r4, [r0, #12]
2002298c:	b087      	sub	sp, #28
2002298e:	b304      	cbz	r4, 200229d2 <HAL_FLASH_PRE_CMD+0x4a>
20022990:	2938      	cmp	r1, #56	@ 0x38
20022992:	d81e      	bhi.n	200229d2 <HAL_FLASH_PRE_CMD+0x4a>
20022994:	eb01 01c1 	add.w	r1, r1, r1, lsl #3
20022998:	440c      	add	r4, r1
2002299a:	7c23      	ldrb	r3, [r4, #16]
2002299c:	b1cb      	cbz	r3, 200229d2 <HAL_FLASH_PRE_CMD+0x4a>
2002299e:	f994 5018 	ldrsb.w	r5, [r4, #24]
200229a2:	f994 3013 	ldrsb.w	r3, [r4, #19]
200229a6:	f994 2012 	ldrsb.w	r2, [r4, #18]
200229aa:	f994 1011 	ldrsb.w	r1, [r4, #17]
200229ae:	9504      	str	r5, [sp, #16]
200229b0:	f994 5017 	ldrsb.w	r5, [r4, #23]
200229b4:	9503      	str	r5, [sp, #12]
200229b6:	f994 5016 	ldrsb.w	r5, [r4, #22]
200229ba:	9502      	str	r5, [sp, #8]
200229bc:	f994 5015 	ldrsb.w	r5, [r4, #21]
200229c0:	9501      	str	r5, [sp, #4]
200229c2:	f994 4014 	ldrsb.w	r4, [r4, #20]
200229c6:	9400      	str	r4, [sp, #0]
200229c8:	f7ff fe2a 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
200229cc:	2000      	movs	r0, #0
200229ce:	b007      	add	sp, #28
200229d0:	bd30      	pop	{r4, r5, pc}
200229d2:	2001      	movs	r0, #1
200229d4:	e7fb      	b.n	200229ce <HAL_FLASH_PRE_CMD+0x46>

200229d6 <HAL_FLASH_ISSUE_CMD>:
200229d6:	b5f0      	push	{r4, r5, r6, r7, lr}
200229d8:	68c4      	ldr	r4, [r0, #12]
200229da:	4606      	mov	r6, r0
200229dc:	4617      	mov	r7, r2
200229de:	b087      	sub	sp, #28
200229e0:	b354      	cbz	r4, 20022a38 <HAL_FLASH_ISSUE_CMD+0x62>
200229e2:	2938      	cmp	r1, #56	@ 0x38
200229e4:	d828      	bhi.n	20022a38 <HAL_FLASH_ISSUE_CMD+0x62>
200229e6:	eb01 05c1 	add.w	r5, r1, r1, lsl #3
200229ea:	442c      	add	r4, r5
200229ec:	7c23      	ldrb	r3, [r4, #16]
200229ee:	b31b      	cbz	r3, 20022a38 <HAL_FLASH_ISSUE_CMD+0x62>
200229f0:	f994 c018 	ldrsb.w	ip, [r4, #24]
200229f4:	f994 3013 	ldrsb.w	r3, [r4, #19]
200229f8:	f994 2012 	ldrsb.w	r2, [r4, #18]
200229fc:	f994 1011 	ldrsb.w	r1, [r4, #17]
20022a00:	f8cd c010 	str.w	ip, [sp, #16]
20022a04:	f994 c017 	ldrsb.w	ip, [r4, #23]
20022a08:	f8cd c00c 	str.w	ip, [sp, #12]
20022a0c:	f994 c016 	ldrsb.w	ip, [r4, #22]
20022a10:	f8cd c008 	str.w	ip, [sp, #8]
20022a14:	f994 c015 	ldrsb.w	ip, [r4, #21]
20022a18:	f8cd c004 	str.w	ip, [sp, #4]
20022a1c:	f994 4014 	ldrsb.w	r4, [r4, #20]
20022a20:	9400      	str	r4, [sp, #0]
20022a22:	f7ff fdfd 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20022a26:	68f3      	ldr	r3, [r6, #12]
20022a28:	463a      	mov	r2, r7
20022a2a:	442b      	add	r3, r5
20022a2c:	4630      	mov	r0, r6
20022a2e:	7c19      	ldrb	r1, [r3, #16]
20022a30:	f7ff fdb1 	bl	20022596 <HAL_FLASH_SET_CMD>
20022a34:	b007      	add	sp, #28
20022a36:	bdf0      	pop	{r4, r5, r6, r7, pc}
20022a38:	2001      	movs	r0, #1
20022a3a:	e7fb      	b.n	20022a34 <HAL_FLASH_ISSUE_CMD+0x5e>

20022a3c <HAL_FLASH_ISSUE_CMD_SEQ>:
20022a3c:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20022a40:	4690      	mov	r8, r2
20022a42:	68c2      	ldr	r2, [r0, #12]
20022a44:	4604      	mov	r4, r0
20022a46:	b086      	sub	sp, #24
20022a48:	2a00      	cmp	r2, #0
20022a4a:	d073      	beq.n	20022b34 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a4c:	2938      	cmp	r1, #56	@ 0x38
20022a4e:	d871      	bhi.n	20022b34 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a50:	eb01 07c1 	add.w	r7, r1, r1, lsl #3
20022a54:	19d6      	adds	r6, r2, r7
20022a56:	7c31      	ldrb	r1, [r6, #16]
20022a58:	2900      	cmp	r1, #0
20022a5a:	d06b      	beq.n	20022b34 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a5c:	2b38      	cmp	r3, #56	@ 0x38
20022a5e:	d869      	bhi.n	20022b34 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a60:	eb03 05c3 	add.w	r5, r3, r3, lsl #3
20022a64:	442a      	add	r2, r5
20022a66:	7c13      	ldrb	r3, [r2, #16]
20022a68:	2b00      	cmp	r3, #0
20022a6a:	d063      	beq.n	20022b34 <HAL_FLASH_ISSUE_CMD_SEQ+0xf8>
20022a6c:	f996 c018 	ldrsb.w	ip, [r6, #24]
20022a70:	f996 3013 	ldrsb.w	r3, [r6, #19]
20022a74:	f996 2012 	ldrsb.w	r2, [r6, #18]
20022a78:	f996 1011 	ldrsb.w	r1, [r6, #17]
20022a7c:	f8cd c010 	str.w	ip, [sp, #16]
20022a80:	f996 c017 	ldrsb.w	ip, [r6, #23]
20022a84:	f8cd c00c 	str.w	ip, [sp, #12]
20022a88:	f996 c016 	ldrsb.w	ip, [r6, #22]
20022a8c:	f8cd c008 	str.w	ip, [sp, #8]
20022a90:	f996 c015 	ldrsb.w	ip, [r6, #21]
20022a94:	f8cd c004 	str.w	ip, [sp, #4]
20022a98:	f996 6014 	ldrsb.w	r6, [r6, #20]
20022a9c:	9600      	str	r6, [sp, #0]
20022a9e:	f7ff fdbf 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20022aa2:	68e0      	ldr	r0, [r4, #12]
20022aa4:	4428      	add	r0, r5
20022aa6:	f990 6018 	ldrsb.w	r6, [r0, #24]
20022aaa:	f990 3013 	ldrsb.w	r3, [r0, #19]
20022aae:	f990 2012 	ldrsb.w	r2, [r0, #18]
20022ab2:	f990 1011 	ldrsb.w	r1, [r0, #17]
20022ab6:	9604      	str	r6, [sp, #16]
20022ab8:	f990 6017 	ldrsb.w	r6, [r0, #23]
20022abc:	9603      	str	r6, [sp, #12]
20022abe:	f990 6016 	ldrsb.w	r6, [r0, #22]
20022ac2:	9602      	str	r6, [sp, #8]
20022ac4:	f990 6015 	ldrsb.w	r6, [r0, #21]
20022ac8:	9601      	str	r6, [sp, #4]
20022aca:	f990 0014 	ldrsb.w	r0, [r0, #20]
20022ace:	9000      	str	r0, [sp, #0]
20022ad0:	4620      	mov	r0, r4
20022ad2:	f7ff fdc6 	bl	20022662 <HAL_FLASH_MANUAL_CMD2>
20022ad6:	2200      	movs	r2, #0
20022ad8:	6823      	ldr	r3, [r4, #0]
20022ada:	2101      	movs	r1, #1
20022adc:	f8c3 2084 	str.w	r2, [r3, #132]	@ 0x84
20022ae0:	68e3      	ldr	r3, [r4, #12]
20022ae2:	6822      	ldr	r2, [r4, #0]
20022ae4:	442b      	add	r3, r5
20022ae6:	7c1b      	ldrb	r3, [r3, #16]
20022ae8:	4620      	mov	r0, r4
20022aea:	62d3      	str	r3, [r2, #44]	@ 0x2c
20022aec:	6823      	ldr	r3, [r4, #0]
20022aee:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
20022af0:	f8c3 2088 	str.w	r2, [r3, #136]	@ 0x88
20022af4:	f7ff fe1a 	bl	2002272c <HAL_FLASH_ENABLE_CMD2>
20022af8:	4620      	mov	r0, r4
20022afa:	f7ff fe25 	bl	20022748 <HAL_FLASH_STAUS_MATCH_CMD2>
20022afe:	6823      	ldr	r3, [r4, #0]
20022b00:	f8c3 801c 	str.w	r8, [r3, #28]
20022b04:	68e3      	ldr	r3, [r4, #12]
20022b06:	6822      	ldr	r2, [r4, #0]
20022b08:	443b      	add	r3, r7
20022b0a:	7c1b      	ldrb	r3, [r3, #16]
20022b0c:	6193      	str	r3, [r2, #24]
20022b0e:	4620      	mov	r0, r4
20022b10:	f7ff fd63 	bl	200225da <HAL_FLASH_STATUS_MATCH>
20022b14:	2800      	cmp	r0, #0
20022b16:	d0fa      	beq.n	20022b0e <HAL_FLASH_ISSUE_CMD_SEQ+0xd2>
20022b18:	2109      	movs	r1, #9
20022b1a:	4620      	mov	r0, r4
20022b1c:	f7ff fd57 	bl	200225ce <HAL_FLASH_CLR_STATUS>
20022b20:	2100      	movs	r1, #0
20022b22:	f7ff fe03 	bl	2002272c <HAL_FLASH_ENABLE_CMD2>
20022b26:	4620      	mov	r0, r4
20022b28:	f7ff fe0e 	bl	20022748 <HAL_FLASH_STAUS_MATCH_CMD2>
20022b2c:	4608      	mov	r0, r1
20022b2e:	b006      	add	sp, #24
20022b30:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20022b34:	2001      	movs	r0, #1
20022b36:	e7fa      	b.n	20022b2e <HAL_FLASH_ISSUE_CMD_SEQ+0xf2>

20022b38 <nor_qspi_switch>:
20022b38:	b570      	push	{r4, r5, r6, lr}
20022b3a:	4604      	mov	r4, r0
20022b3c:	b3e0      	cbz	r0, 20022bb8 <nor_qspi_switch+0x80>
20022b3e:	68c3      	ldr	r3, [r0, #12]
20022b40:	b3d3      	cbz	r3, 20022bb8 <nor_qspi_switch+0x80>
20022b42:	b3c9      	cbz	r1, 20022bb8 <nor_qspi_switch+0x80>
20022b44:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022b48:	2101      	movs	r1, #1
20022b4a:	b3b5      	cbz	r5, 20022bba <nor_qspi_switch+0x82>
20022b4c:	f7ff fcfe 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022b50:	2200      	movs	r2, #0
20022b52:	2114      	movs	r1, #20
20022b54:	4620      	mov	r0, r4
20022b56:	f7ff ff3e 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022b5a:	4620      	mov	r0, r4
20022b5c:	f7ff fd4c 	bl	200225f8 <HAL_FLASH_READ32>
20022b60:	f010 0501 	ands.w	r5, r0, #1
20022b64:	d000      	beq.n	20022b68 <nor_qspi_switch+0x30>
20022b66:	e7fe      	b.n	20022b66 <nor_qspi_switch+0x2e>
20022b68:	462a      	mov	r2, r5
20022b6a:	2115      	movs	r1, #21
20022b6c:	4620      	mov	r0, r4
20022b6e:	f7ff ff32 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022b72:	4606      	mov	r6, r0
20022b74:	b120      	cbz	r0, 20022b80 <nor_qspi_switch+0x48>
20022b76:	462a      	mov	r2, r5
20022b78:	4629      	mov	r1, r5
20022b7a:	4620      	mov	r0, r4
20022b7c:	f7ff ff2b 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022b80:	2102      	movs	r1, #2
20022b82:	4620      	mov	r0, r4
20022b84:	f7ff fcdb 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20022b88:	2101      	movs	r1, #1
20022b8a:	4620      	mov	r0, r4
20022b8c:	f7ff fcde 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022b90:	2200      	movs	r2, #0
20022b92:	212b      	movs	r1, #43	@ 0x2b
20022b94:	4620      	mov	r0, r4
20022b96:	f7ff ff1e 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022b9a:	b16e      	cbz	r6, 20022bb8 <nor_qspi_switch+0x80>
20022b9c:	2101      	movs	r1, #1
20022b9e:	4620      	mov	r0, r4
20022ba0:	f7ff fcd4 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022ba4:	2200      	movs	r2, #0
20022ba6:	2102      	movs	r1, #2
20022ba8:	4620      	mov	r0, r4
20022baa:	f7ff ff14 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022bae:	4620      	mov	r0, r4
20022bb0:	f7ff fd19 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
20022bb4:	2800      	cmp	r0, #0
20022bb6:	d0f5      	beq.n	20022ba4 <nor_qspi_switch+0x6c>
20022bb8:	bd70      	pop	{r4, r5, r6, pc}
20022bba:	f7ff fcc7 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022bbe:	462a      	mov	r2, r5
20022bc0:	2102      	movs	r1, #2
20022bc2:	4620      	mov	r0, r4
20022bc4:	f7ff ff07 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022bc8:	4620      	mov	r0, r4
20022bca:	f7ff fd15 	bl	200225f8 <HAL_FLASH_READ32>
20022bce:	462a      	mov	r2, r5
20022bd0:	2114      	movs	r1, #20
20022bd2:	4620      	mov	r0, r4
20022bd4:	f7ff feff 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022bd8:	b910      	cbnz	r0, 20022be0 <nor_qspi_switch+0xa8>
20022bda:	4620      	mov	r0, r4
20022bdc:	f7ff fd0c 	bl	200225f8 <HAL_FLASH_READ32>
20022be0:	68e3      	ldr	r3, [r4, #12]
20022be2:	7a1b      	ldrb	r3, [r3, #8]
20022be4:	b3ab      	cbz	r3, 20022c52 <nor_qspi_switch+0x11a>
20022be6:	2101      	movs	r1, #1
20022be8:	f003 050f 	and.w	r5, r3, #15
20022bec:	091b      	lsrs	r3, r3, #4
20022bee:	fa01 f303 	lsl.w	r3, r1, r3
20022bf2:	b2db      	uxtb	r3, r3
20022bf4:	b10d      	cbz	r5, 20022bfa <nor_qspi_switch+0xc2>
20022bf6:	461d      	mov	r5, r3
20022bf8:	2300      	movs	r3, #0
20022bfa:	2200      	movs	r2, #0
20022bfc:	2115      	movs	r1, #21
20022bfe:	4620      	mov	r0, r4
20022c00:	ea43 2505 	orr.w	r5, r3, r5, lsl #8
20022c04:	f7ff fee7 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022c08:	4606      	mov	r6, r0
20022c0a:	b120      	cbz	r0, 20022c16 <nor_qspi_switch+0xde>
20022c0c:	2200      	movs	r2, #0
20022c0e:	4620      	mov	r0, r4
20022c10:	4611      	mov	r1, r2
20022c12:	f7ff fee0 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022c16:	4629      	mov	r1, r5
20022c18:	4620      	mov	r0, r4
20022c1a:	f7ff fc90 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20022c1e:	2102      	movs	r1, #2
20022c20:	4620      	mov	r0, r4
20022c22:	f7ff fc93 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022c26:	2200      	movs	r2, #0
20022c28:	2103      	movs	r1, #3
20022c2a:	4620      	mov	r0, r4
20022c2c:	f7ff fed3 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022c30:	2e00      	cmp	r6, #0
20022c32:	d0c1      	beq.n	20022bb8 <nor_qspi_switch+0x80>
20022c34:	2101      	movs	r1, #1
20022c36:	4620      	mov	r0, r4
20022c38:	f7ff fc88 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022c3c:	2200      	movs	r2, #0
20022c3e:	2102      	movs	r1, #2
20022c40:	4620      	mov	r0, r4
20022c42:	f7ff fec8 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022c46:	4620      	mov	r0, r4
20022c48:	f7ff fccd 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
20022c4c:	2800      	cmp	r0, #0
20022c4e:	d0f5      	beq.n	20022c3c <nor_qspi_switch+0x104>
20022c50:	e7b2      	b.n	20022bb8 <nor_qspi_switch+0x80>
20022c52:	2502      	movs	r5, #2
20022c54:	e7d1      	b.n	20022bfa <nor_qspi_switch+0xc2>

20022c56 <HAL_FLASH_SET_QUAL_SPI>:
20022c56:	b538      	push	{r3, r4, r5, lr}
20022c58:	4604      	mov	r4, r0
20022c5a:	460d      	mov	r5, r1
20022c5c:	f7ff ff6c 	bl	20022b38 <nor_qspi_switch>
20022c60:	4629      	mov	r1, r5
20022c62:	4620      	mov	r0, r4
20022c64:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022c68:	f7ff be0d 	b.w	20022886 <HAL_FLASH_CONFIG_AHB_READ>

20022c6c <HAL_FLASH_FADDR_SET_QSPI>:
20022c6c:	b538      	push	{r3, r4, r5, lr}
20022c6e:	4604      	mov	r4, r0
20022c70:	460d      	mov	r5, r1
20022c72:	f7ff ff61 	bl	20022b38 <nor_qspi_switch>
20022c76:	4629      	mov	r1, r5
20022c78:	4620      	mov	r0, r4
20022c7a:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20022c7e:	f7ff be46 	b.w	2002290e <HAL_FLASH_CONFIG_FULL_AHB_READ>

20022c82 <HAL_FLASH_GET_NOR_ID>:
20022c82:	b510      	push	{r4, lr}
20022c84:	4604      	mov	r4, r0
20022c86:	b140      	cbz	r0, 20022c9a <HAL_FLASH_GET_NOR_ID+0x18>
20022c88:	6802      	ldr	r2, [r0, #0]
20022c8a:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022c8c:	f36f 0315 	bfc	r3, #0, #22
20022c90:	f443 2380 	orr.w	r3, r3, #262144	@ 0x40000
20022c94:	f043 0301 	orr.w	r3, r3, #1
20022c98:	6293      	str	r3, [r2, #40]	@ 0x28
20022c9a:	2103      	movs	r1, #3
20022c9c:	4620      	mov	r0, r4
20022c9e:	f7ff fc55 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022ca2:	2200      	movs	r2, #0
20022ca4:	219f      	movs	r1, #159	@ 0x9f
20022ca6:	4620      	mov	r0, r4
20022ca8:	f7ff fc75 	bl	20022596 <HAL_FLASH_SET_CMD>
20022cac:	4620      	mov	r0, r4
20022cae:	f7ff fca3 	bl	200225f8 <HAL_FLASH_READ32>
20022cb2:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
20022cb6:	bd10      	pop	{r4, pc}

20022cb8 <HAL_FLASH_CLR_PROTECT>:
20022cb8:	b570      	push	{r4, r5, r6, lr}
20022cba:	4604      	mov	r4, r0
20022cbc:	2800      	cmp	r0, #0
20022cbe:	d03e      	beq.n	20022d3e <HAL_FLASH_CLR_PROTECT+0x86>
20022cc0:	68c3      	ldr	r3, [r0, #12]
20022cc2:	2101      	movs	r1, #1
20022cc4:	f893 5193 	ldrb.w	r5, [r3, #403]	@ 0x193
20022cc8:	2d00      	cmp	r5, #0
20022cca:	d03b      	beq.n	20022d44 <HAL_FLASH_CLR_PROTECT+0x8c>
20022ccc:	f7ff fc3e 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022cd0:	2200      	movs	r2, #0
20022cd2:	2102      	movs	r1, #2
20022cd4:	4620      	mov	r0, r4
20022cd6:	f7ff fe7e 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022cda:	bb88      	cbnz	r0, 20022d40 <HAL_FLASH_CLR_PROTECT+0x88>
20022cdc:	4620      	mov	r0, r4
20022cde:	f7ff fc8b 	bl	200225f8 <HAL_FLASH_READ32>
20022ce2:	b2c0      	uxtb	r0, r0
20022ce4:	68e3      	ldr	r3, [r4, #12]
20022ce6:	79dd      	ldrb	r5, [r3, #7]
20022ce8:	b10d      	cbz	r5, 20022cee <HAL_FLASH_CLR_PROTECT+0x36>
20022cea:	ea20 0505 	bic.w	r5, r0, r5
20022cee:	2200      	movs	r2, #0
20022cf0:	2115      	movs	r1, #21
20022cf2:	4620      	mov	r0, r4
20022cf4:	f7ff fe6f 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022cf8:	4606      	mov	r6, r0
20022cfa:	b120      	cbz	r0, 20022d06 <HAL_FLASH_CLR_PROTECT+0x4e>
20022cfc:	2200      	movs	r2, #0
20022cfe:	4620      	mov	r0, r4
20022d00:	4611      	mov	r1, r2
20022d02:	f7ff fe68 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d06:	4629      	mov	r1, r5
20022d08:	4620      	mov	r0, r4
20022d0a:	f7ff fc18 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20022d0e:	2101      	movs	r1, #1
20022d10:	4620      	mov	r0, r4
20022d12:	f7ff fc1b 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022d16:	2200      	movs	r2, #0
20022d18:	2103      	movs	r1, #3
20022d1a:	4620      	mov	r0, r4
20022d1c:	f7ff fe5b 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d20:	b16e      	cbz	r6, 20022d3e <HAL_FLASH_CLR_PROTECT+0x86>
20022d22:	2101      	movs	r1, #1
20022d24:	4620      	mov	r0, r4
20022d26:	f7ff fc11 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022d2a:	2200      	movs	r2, #0
20022d2c:	2102      	movs	r1, #2
20022d2e:	4620      	mov	r0, r4
20022d30:	f7ff fe51 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d34:	4620      	mov	r0, r4
20022d36:	f7ff fc56 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
20022d3a:	2800      	cmp	r0, #0
20022d3c:	d0f5      	beq.n	20022d2a <HAL_FLASH_CLR_PROTECT+0x72>
20022d3e:	bd70      	pop	{r4, r5, r6, pc}
20022d40:	2000      	movs	r0, #0
20022d42:	e7cf      	b.n	20022ce4 <HAL_FLASH_CLR_PROTECT+0x2c>
20022d44:	f7ff fc02 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022d48:	462a      	mov	r2, r5
20022d4a:	2102      	movs	r1, #2
20022d4c:	4620      	mov	r0, r4
20022d4e:	f7ff fe42 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d52:	2800      	cmp	r0, #0
20022d54:	d13e      	bne.n	20022dd4 <HAL_FLASH_CLR_PROTECT+0x11c>
20022d56:	4620      	mov	r0, r4
20022d58:	f7ff fc4e 	bl	200225f8 <HAL_FLASH_READ32>
20022d5c:	b2c6      	uxtb	r6, r0
20022d5e:	2200      	movs	r2, #0
20022d60:	2114      	movs	r1, #20
20022d62:	4620      	mov	r0, r4
20022d64:	f7ff fe37 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d68:	b918      	cbnz	r0, 20022d72 <HAL_FLASH_CLR_PROTECT+0xba>
20022d6a:	4620      	mov	r0, r4
20022d6c:	f7ff fc44 	bl	200225f8 <HAL_FLASH_READ32>
20022d70:	b2c5      	uxtb	r5, r0
20022d72:	68e3      	ldr	r3, [r4, #12]
20022d74:	79d9      	ldrb	r1, [r3, #7]
20022d76:	b109      	cbz	r1, 20022d7c <HAL_FLASH_CLR_PROTECT+0xc4>
20022d78:	ea26 0101 	bic.w	r1, r6, r1
20022d7c:	2200      	movs	r2, #0
20022d7e:	4620      	mov	r0, r4
20022d80:	ea41 2505 	orr.w	r5, r1, r5, lsl #8
20022d84:	2115      	movs	r1, #21
20022d86:	f7ff fe26 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d8a:	4606      	mov	r6, r0
20022d8c:	b120      	cbz	r0, 20022d98 <HAL_FLASH_CLR_PROTECT+0xe0>
20022d8e:	2200      	movs	r2, #0
20022d90:	4620      	mov	r0, r4
20022d92:	4611      	mov	r1, r2
20022d94:	f7ff fe1f 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022d98:	4629      	mov	r1, r5
20022d9a:	4620      	mov	r0, r4
20022d9c:	f7ff fbcf 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20022da0:	2102      	movs	r1, #2
20022da2:	4620      	mov	r0, r4
20022da4:	f7ff fbd2 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022da8:	2200      	movs	r2, #0
20022daa:	2103      	movs	r1, #3
20022dac:	4620      	mov	r0, r4
20022dae:	f7ff fe12 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022db2:	2e00      	cmp	r6, #0
20022db4:	d0c3      	beq.n	20022d3e <HAL_FLASH_CLR_PROTECT+0x86>
20022db6:	2101      	movs	r1, #1
20022db8:	4620      	mov	r0, r4
20022dba:	f7ff fbc7 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022dbe:	2200      	movs	r2, #0
20022dc0:	2102      	movs	r1, #2
20022dc2:	4620      	mov	r0, r4
20022dc4:	f7ff fe07 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022dc8:	4620      	mov	r0, r4
20022dca:	f7ff fc0c 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
20022dce:	2800      	cmp	r0, #0
20022dd0:	d0f5      	beq.n	20022dbe <HAL_FLASH_CLR_PROTECT+0x106>
20022dd2:	e7b4      	b.n	20022d3e <HAL_FLASH_CLR_PROTECT+0x86>
20022dd4:	462e      	mov	r6, r5
20022dd6:	e7c2      	b.n	20022d5e <HAL_FLASH_CLR_PROTECT+0xa6>

20022dd8 <HAL_FLASH_PreInit>:
20022dd8:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20022dda:	4604      	mov	r4, r0
20022ddc:	b358      	cbz	r0, 20022e36 <HAL_FLASH_PreInit+0x5e>
20022dde:	2300      	movs	r3, #0
20022de0:	22ff      	movs	r2, #255	@ 0xff
20022de2:	2101      	movs	r1, #1
20022de4:	f04f 2650 	mov.w	r6, #1342197760	@ 0x50005000
20022de8:	6805      	ldr	r5, [r0, #0]
20022dea:	6043      	str	r3, [r0, #4]
20022dec:	f880 102a 	strb.w	r1, [r0, #42]	@ 0x2a
20022df0:	f880 3028 	strb.w	r3, [r0, #40]	@ 0x28
20022df4:	f8c5 208c 	str.w	r2, [r5, #140]	@ 0x8c
20022df8:	6805      	ldr	r5, [r0, #0]
20022dfa:	f8c5 6080 	str.w	r6, [r5, #128]	@ 0x80
20022dfe:	6805      	ldr	r5, [r0, #0]
20022e00:	622a      	str	r2, [r5, #32]
20022e02:	6805      	ldr	r5, [r0, #0]
20022e04:	646a      	str	r2, [r5, #68]	@ 0x44
20022e06:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
20022e0a:	6083      	str	r3, [r0, #8]
20022e0c:	f7ff fc65 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
20022e10:	4620      	mov	r0, r4
20022e12:	f7ff ff36 	bl	20022c82 <HAL_FLASH_GET_NOR_ID>
20022e16:	f3c0 2707 	ubfx	r7, r0, #8, #8
20022e1a:	f3c0 4507 	ubfx	r5, r0, #16, #8
20022e1e:	b2c6      	uxtb	r6, r0
20022e20:	4629      	mov	r1, r5
20022e22:	463a      	mov	r2, r7
20022e24:	4630      	mov	r0, r6
20022e26:	f001 fff9 	bl	20024e1c <spi_flash_get_cmd_by_id>
20022e2a:	4601      	mov	r1, r0
20022e2c:	60e0      	str	r0, [r4, #12]
20022e2e:	b920      	cbnz	r0, 20022e3a <HAL_FLASH_PreInit+0x62>
20022e30:	4620      	mov	r0, r4
20022e32:	f7ff fc52 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
20022e36:	2001      	movs	r0, #1
20022e38:	e00a      	b.n	20022e50 <HAL_FLASH_PreInit+0x78>
20022e3a:	463a      	mov	r2, r7
20022e3c:	4629      	mov	r1, r5
20022e3e:	4630      	mov	r0, r6
20022e40:	f002 f800 	bl	20024e44 <spi_flash_get_size_by_id>
20022e44:	b100      	cbz	r0, 20022e48 <HAL_FLASH_PreInit+0x70>
20022e46:	6160      	str	r0, [r4, #20]
20022e48:	f894 502b 	ldrb.w	r5, [r4, #43]	@ 0x2b
20022e4c:	b10d      	cbz	r5, 20022e52 <HAL_FLASH_PreInit+0x7a>
20022e4e:	2000      	movs	r0, #0
20022e50:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20022e52:	4620      	mov	r0, r4
20022e54:	f7ff ff30 	bl	20022cb8 <HAL_FLASH_CLR_PROTECT>
20022e58:	6963      	ldr	r3, [r4, #20]
20022e5a:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20022e5e:	d90d      	bls.n	20022e7c <HAL_FLASH_PreInit+0xa4>
20022e60:	2121      	movs	r1, #33	@ 0x21
20022e62:	462a      	mov	r2, r5
20022e64:	4620      	mov	r0, r4
20022e66:	f7ff fdb6 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022e6a:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022e6e:	b919      	cbnz	r1, 20022e78 <HAL_FLASH_PreInit+0xa0>
20022e70:	4620      	mov	r0, r4
20022e72:	f7ff fefb 	bl	20022c6c <HAL_FLASH_FADDR_SET_QSPI>
20022e76:	e7ea      	b.n	20022e4e <HAL_FLASH_PreInit+0x76>
20022e78:	2101      	movs	r1, #1
20022e7a:	e7f9      	b.n	20022e70 <HAL_FLASH_PreInit+0x98>
20022e7c:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
20022e80:	b919      	cbnz	r1, 20022e8a <HAL_FLASH_PreInit+0xb2>
20022e82:	4620      	mov	r0, r4
20022e84:	f7ff fee7 	bl	20022c56 <HAL_FLASH_SET_QUAL_SPI>
20022e88:	e7e1      	b.n	20022e4e <HAL_FLASH_PreInit+0x76>
20022e8a:	2101      	movs	r1, #1
20022e8c:	e7f9      	b.n	20022e82 <HAL_FLASH_PreInit+0xaa>

20022e8e <HAL_QSPI_SET_CLK_INV>:
20022e8e:	b120      	cbz	r0, 20022e9a <HAL_QSPI_SET_CLK_INV+0xc>
20022e90:	6802      	ldr	r2, [r0, #0]
20022e92:	6d93      	ldr	r3, [r2, #88]	@ 0x58
20022e94:	f443 3380 	orr.w	r3, r3, #65536	@ 0x10000
20022e98:	6593      	str	r3, [r2, #88]	@ 0x58
20022e9a:	4770      	bx	lr

20022e9c <HAL_QSPI_READ_OTP>:
20022e9c:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022ea0:	4691      	mov	r9, r2
20022ea2:	4605      	mov	r5, r0
20022ea4:	2800      	cmp	r0, #0
20022ea6:	d044      	beq.n	20022f32 <HAL_QSPI_READ_OTP+0x96>
20022ea8:	68c4      	ldr	r4, [r0, #12]
20022eaa:	b1b4      	cbz	r4, 20022eda <HAL_QSPI_READ_OTP+0x3e>
20022eac:	f5b1 5f80 	cmp.w	r1, #4096	@ 0x1000
20022eb0:	d33f      	bcc.n	20022f32 <HAL_QSPI_READ_OTP+0x96>
20022eb2:	79a2      	ldrb	r2, [r4, #6]
20022eb4:	3201      	adds	r2, #1
20022eb6:	ebb1 3f02 	cmp.w	r1, r2, lsl #12
20022eba:	d23a      	bcs.n	20022f32 <HAL_QSPI_READ_OTP+0x96>
20022ebc:	7ae0      	ldrb	r0, [r4, #11]
20022ebe:	f3c1 0209 	ubfx	r2, r1, #0, #10
20022ec2:	441a      	add	r2, r3
20022ec4:	ebb2 2f00 	cmp.w	r2, r0, lsl #8
20022ec8:	d833      	bhi.n	20022f32 <HAL_QSPI_READ_OTP+0x96>
20022eca:	461c      	mov	r4, r3
20022ecc:	2700      	movs	r7, #0
20022ece:	46a2      	mov	sl, r4
20022ed0:	6bab      	ldr	r3, [r5, #56]	@ 0x38
20022ed2:	18ce      	adds	r6, r1, r3
20022ed4:	f1ba 0f00 	cmp.w	sl, #0
20022ed8:	dc02      	bgt.n	20022ee0 <HAL_QSPI_READ_OTP+0x44>
20022eda:	4620      	mov	r0, r4
20022edc:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
20022ee0:	f1ba 0f40 	cmp.w	sl, #64	@ 0x40
20022ee4:	46d0      	mov	r8, sl
20022ee6:	bfa8      	it	ge
20022ee8:	f04f 0840 	movge.w	r8, #64	@ 0x40
20022eec:	4628      	mov	r0, r5
20022eee:	4641      	mov	r1, r8
20022ef0:	f7ff fb2c 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20022ef4:	4632      	mov	r2, r6
20022ef6:	2132      	movs	r1, #50	@ 0x32
20022ef8:	4628      	mov	r0, r5
20022efa:	f7ff fd6c 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20022efe:	463b      	mov	r3, r7
20022f00:	2f00      	cmp	r7, #0
20022f02:	bfb8      	it	lt
20022f04:	1cfb      	addlt	r3, r7, #3
20022f06:	ea4f 01a8 	mov.w	r1, r8, asr #2
20022f0a:	f023 0203 	bic.w	r2, r3, #3
20022f0e:	eb01 01a3 	add.w	r1, r1, r3, asr #2
20022f12:	444a      	add	r2, r9
20022f14:	eb09 0181 	add.w	r1, r9, r1, lsl #2
20022f18:	428a      	cmp	r2, r1
20022f1a:	d104      	bne.n	20022f26 <HAL_QSPI_READ_OTP+0x8a>
20022f1c:	4447      	add	r7, r8
20022f1e:	4446      	add	r6, r8
20022f20:	ebaa 0a08 	sub.w	sl, sl, r8
20022f24:	e7d6      	b.n	20022ed4 <HAL_QSPI_READ_OTP+0x38>
20022f26:	4628      	mov	r0, r5
20022f28:	f7ff fb66 	bl	200225f8 <HAL_FLASH_READ32>
20022f2c:	f842 0b04 	str.w	r0, [r2], #4
20022f30:	e7f2      	b.n	20022f18 <HAL_QSPI_READ_OTP+0x7c>
20022f32:	2400      	movs	r4, #0
20022f34:	e7d1      	b.n	20022eda <HAL_QSPI_READ_OTP+0x3e>

20022f36 <HAL_FLASH_RELEASE_DPD>:
20022f36:	b538      	push	{r3, r4, r5, lr}
20022f38:	4604      	mov	r4, r0
20022f3a:	b1d0      	cbz	r0, 20022f72 <HAL_FLASH_RELEASE_DPD+0x3c>
20022f3c:	6803      	ldr	r3, [r0, #0]
20022f3e:	21ab      	movs	r1, #171	@ 0xab
20022f40:	681d      	ldr	r5, [r3, #0]
20022f42:	f015 0501 	ands.w	r5, r5, #1
20022f46:	bf02      	ittt	eq
20022f48:	681a      	ldreq	r2, [r3, #0]
20022f4a:	f042 0201 	orreq.w	r2, r2, #1
20022f4e:	601a      	streq	r2, [r3, #0]
20022f50:	6802      	ldr	r2, [r0, #0]
20022f52:	6a93      	ldr	r3, [r2, #40]	@ 0x28
20022f54:	f36f 0315 	bfc	r3, #0, #22
20022f58:	f043 0301 	orr.w	r3, r3, #1
20022f5c:	6293      	str	r3, [r2, #40]	@ 0x28
20022f5e:	2200      	movs	r2, #0
20022f60:	f7ff fb19 	bl	20022596 <HAL_FLASH_SET_CMD>
20022f64:	b925      	cbnz	r5, 20022f70 <HAL_FLASH_RELEASE_DPD+0x3a>
20022f66:	6822      	ldr	r2, [r4, #0]
20022f68:	6813      	ldr	r3, [r2, #0]
20022f6a:	f023 0301 	bic.w	r3, r3, #1
20022f6e:	6013      	str	r3, [r2, #0]
20022f70:	bd38      	pop	{r3, r4, r5, pc}
20022f72:	2001      	movs	r0, #1
20022f74:	e7fc      	b.n	20022f70 <HAL_FLASH_RELEASE_DPD+0x3a>

20022f76 <flash_handle_valid>:
20022f76:	b118      	cbz	r0, 20022f80 <flash_handle_valid+0xa>
20022f78:	68c0      	ldr	r0, [r0, #12]
20022f7a:	3800      	subs	r0, #0
20022f7c:	bf18      	it	ne
20022f7e:	2001      	movne	r0, #1
20022f80:	4770      	bx	lr

20022f82 <HAL_GET_FLASH_MID>:
20022f82:	2000      	movs	r0, #0
20022f84:	4770      	bx	lr

20022f86 <HAL_FLASH_DMA_START>:
20022f86:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022f8a:	4688      	mov	r8, r1
20022f8c:	4699      	mov	r9, r3
20022f8e:	4604      	mov	r4, r0
20022f90:	2800      	cmp	r0, #0
20022f92:	d045      	beq.n	20023020 <HAL_FLASH_DMA_START+0x9a>
20022f94:	6883      	ldr	r3, [r0, #8]
20022f96:	2b00      	cmp	r3, #0
20022f98:	d042      	beq.n	20023020 <HAL_FLASH_DMA_START+0x9a>
20022f9a:	f1b9 0f00 	cmp.w	r9, #0
20022f9e:	d03f      	beq.n	20023020 <HAL_FLASH_DMA_START+0x9a>
20022fa0:	6801      	ldr	r1, [r0, #0]
20022fa2:	680f      	ldr	r7, [r1, #0]
20022fa4:	b332      	cbz	r2, 20022ff4 <HAL_FLASH_DMA_START+0x6e>
20022fa6:	2210      	movs	r2, #16
20022fa8:	609a      	str	r2, [r3, #8]
20022faa:	2300      	movs	r3, #0
20022fac:	6882      	ldr	r2, [r0, #8]
20022fae:	464e      	mov	r6, r9
20022fb0:	6153      	str	r3, [r2, #20]
20022fb2:	6882      	ldr	r2, [r0, #8]
20022fb4:	6193      	str	r3, [r2, #24]
20022fb6:	6882      	ldr	r2, [r0, #8]
20022fb8:	60d3      	str	r3, [r2, #12]
20022fba:	2280      	movs	r2, #128	@ 0x80
20022fbc:	6883      	ldr	r3, [r0, #8]
20022fbe:	611a      	str	r2, [r3, #16]
20022fc0:	6805      	ldr	r5, [r0, #0]
20022fc2:	3504      	adds	r5, #4
20022fc4:	68a0      	ldr	r0, [r4, #8]
20022fc6:	f7ff f817 	bl	20021ff8 <HAL_DMA_DeInit>
20022fca:	bb50      	cbnz	r0, 20023022 <HAL_FLASH_DMA_START+0x9c>
20022fcc:	68a0      	ldr	r0, [r4, #8]
20022fce:	f7fe ffa7 	bl	20021f20 <HAL_DMA_Init>
20022fd2:	bb30      	cbnz	r0, 20023022 <HAL_FLASH_DMA_START+0x9c>
20022fd4:	6823      	ldr	r3, [r4, #0]
20022fd6:	f047 0720 	orr.w	r7, r7, #32
20022fda:	601f      	str	r7, [r3, #0]
20022fdc:	6822      	ldr	r2, [r4, #0]
20022fde:	f109 33ff 	add.w	r3, r9, #4294967295
20022fe2:	6253      	str	r3, [r2, #36]	@ 0x24
20022fe4:	4641      	mov	r1, r8
20022fe6:	4633      	mov	r3, r6
20022fe8:	462a      	mov	r2, r5
20022fea:	68a0      	ldr	r0, [r4, #8]
20022fec:	e8bd 47f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20022ff0:	f7ff b97c 	b.w	200222ec <HAL_DMA_Start>
20022ff4:	f44f 7100 	mov.w	r1, #512	@ 0x200
20022ff8:	609a      	str	r2, [r3, #8]
20022ffa:	6883      	ldr	r3, [r0, #8]
20022ffc:	f109 0603 	add.w	r6, r9, #3
20023000:	6159      	str	r1, [r3, #20]
20023002:	f44f 6100 	mov.w	r1, #2048	@ 0x800
20023006:	6883      	ldr	r3, [r0, #8]
20023008:	4645      	mov	r5, r8
2002300a:	6199      	str	r1, [r3, #24]
2002300c:	6883      	ldr	r3, [r0, #8]
2002300e:	08b6      	lsrs	r6, r6, #2
20023010:	60da      	str	r2, [r3, #12]
20023012:	2280      	movs	r2, #128	@ 0x80
20023014:	6883      	ldr	r3, [r0, #8]
20023016:	611a      	str	r2, [r3, #16]
20023018:	6803      	ldr	r3, [r0, #0]
2002301a:	f103 0804 	add.w	r8, r3, #4
2002301e:	e7d1      	b.n	20022fc4 <HAL_FLASH_DMA_START+0x3e>
20023020:	2001      	movs	r0, #1
20023022:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

20023026 <HAL_FLASH_DMA_WAIT_DONE>:
20023026:	b510      	push	{r4, lr}
20023028:	460a      	mov	r2, r1
2002302a:	4604      	mov	r4, r0
2002302c:	b170      	cbz	r0, 2002304c <HAL_FLASH_DMA_WAIT_DONE+0x26>
2002302e:	6880      	ldr	r0, [r0, #8]
20023030:	b160      	cbz	r0, 2002304c <HAL_FLASH_DMA_WAIT_DONE+0x26>
20023032:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20023034:	b111      	cbz	r1, 2002303c <HAL_FLASH_DMA_WAIT_DONE+0x16>
20023036:	f04f 32ff 	mov.w	r2, #4294967295
2002303a:	2100      	movs	r1, #0
2002303c:	f7ff f84a 	bl	200220d4 <HAL_DMA_PollForTransfer>
20023040:	6822      	ldr	r2, [r4, #0]
20023042:	6813      	ldr	r3, [r2, #0]
20023044:	f023 0320 	bic.w	r3, r3, #32
20023048:	6013      	str	r3, [r2, #0]
2002304a:	bd10      	pop	{r4, pc}
2002304c:	2001      	movs	r0, #1
2002304e:	e7fc      	b.n	2002304a <HAL_FLASH_DMA_WAIT_DONE+0x24>

20023050 <HAL_FLASH_ALIAS_CFG>:
20023050:	b538      	push	{r3, r4, r5, lr}
20023052:	461d      	mov	r5, r3
20023054:	4604      	mov	r4, r0
20023056:	b158      	cbz	r0, 20023070 <HAL_FLASH_ALIAS_CFG+0x20>
20023058:	6903      	ldr	r3, [r0, #16]
2002305a:	428b      	cmp	r3, r1
2002305c:	bf98      	it	ls
2002305e:	1ac9      	subls	r1, r1, r3
20023060:	f7ff fb20 	bl	200226a4 <HAL_FLASH_SET_ALIAS_RANGE>
20023064:	4629      	mov	r1, r5
20023066:	4620      	mov	r0, r4
20023068:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
2002306c:	f7ff bb2c 	b.w	200226c8 <HAL_FLASH_SET_ALIAS_OFFSET>
20023070:	bd38      	pop	{r3, r4, r5, pc}

20023072 <nand_read_id>:
20023072:	b510      	push	{r4, lr}
20023074:	460b      	mov	r3, r1
20023076:	4604      	mov	r4, r0
20023078:	b086      	sub	sp, #24
2002307a:	b320      	cbz	r0, 200230c6 <nand_read_id+0x54>
2002307c:	2908      	cmp	r1, #8
2002307e:	f04f 0100 	mov.w	r1, #0
20023082:	f04f 0201 	mov.w	r2, #1
20023086:	bf83      	ittte	hi
20023088:	460b      	movhi	r3, r1
2002308a:	e9cd 1202 	strdhi	r1, r2, [sp, #8]
2002308e:	e9cd 1100 	strdhi	r1, r1, [sp]
20023092:	e9cd 1102 	strdls	r1, r1, [sp, #8]
20023096:	bf8e      	itee	hi
20023098:	4619      	movhi	r1, r3
2002309a:	e9cd 1100 	strdls	r1, r1, [sp]
2002309e:	b25b      	sxtbls	r3, r3
200230a0:	9204      	str	r2, [sp, #16]
200230a2:	f7ff fabd 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
200230a6:	2103      	movs	r1, #3
200230a8:	4620      	mov	r0, r4
200230aa:	f7ff fa4f 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200230ae:	2200      	movs	r2, #0
200230b0:	219f      	movs	r1, #159	@ 0x9f
200230b2:	4620      	mov	r0, r4
200230b4:	f7ff fa6f 	bl	20022596 <HAL_FLASH_SET_CMD>
200230b8:	4620      	mov	r0, r4
200230ba:	f7ff fa9d 	bl	200225f8 <HAL_FLASH_READ32>
200230be:	f020 407f 	bic.w	r0, r0, #4278190080	@ 0xff000000
200230c2:	b006      	add	sp, #24
200230c4:	bd10      	pop	{r4, pc}
200230c6:	20ff      	movs	r0, #255	@ 0xff
200230c8:	e7fb      	b.n	200230c2 <nand_read_id+0x50>

200230ca <HAL_NAND_CONF_ECC>:
200230ca:	b538      	push	{r3, r4, r5, lr}
200230cc:	460d      	mov	r5, r1
200230ce:	4604      	mov	r4, r0
200230d0:	b398      	cbz	r0, 2002313a <HAL_NAND_CONF_ECC+0x70>
200230d2:	68c3      	ldr	r3, [r0, #12]
200230d4:	b38b      	cbz	r3, 2002313a <HAL_NAND_CONF_ECC+0x70>
200230d6:	799a      	ldrb	r2, [r3, #6]
200230d8:	b392      	cbz	r2, 20023140 <HAL_NAND_CONF_ECC+0x76>
200230da:	7a9b      	ldrb	r3, [r3, #10]
200230dc:	b383      	cbz	r3, 20023140 <HAL_NAND_CONF_ECC+0x76>
200230de:	2101      	movs	r1, #1
200230e0:	f7ff fa34 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200230e4:	68e3      	ldr	r3, [r4, #12]
200230e6:	2102      	movs	r1, #2
200230e8:	799a      	ldrb	r2, [r3, #6]
200230ea:	4620      	mov	r0, r4
200230ec:	f7ff fc73 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200230f0:	4620      	mov	r0, r4
200230f2:	f7ff fa81 	bl	200225f8 <HAL_FLASH_READ32>
200230f6:	68e3      	ldr	r3, [r4, #12]
200230f8:	7a9b      	ldrb	r3, [r3, #10]
200230fa:	b1dd      	cbz	r5, 20023134 <HAL_NAND_CONF_ECC+0x6a>
200230fc:	ea43 0100 	orr.w	r1, r3, r0
20023100:	4620      	mov	r0, r4
20023102:	f7ff fa1c 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20023106:	2101      	movs	r1, #1
20023108:	4620      	mov	r0, r4
2002310a:	f7ff fa1f 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
2002310e:	68e3      	ldr	r3, [r4, #12]
20023110:	2103      	movs	r1, #3
20023112:	799a      	ldrb	r2, [r3, #6]
20023114:	4620      	mov	r0, r4
20023116:	f7ff fc5e 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
2002311a:	68e3      	ldr	r3, [r4, #12]
2002311c:	f884 502d 	strb.w	r5, [r4, #45]	@ 0x2d
20023120:	2102      	movs	r1, #2
20023122:	799a      	ldrb	r2, [r3, #6]
20023124:	4620      	mov	r0, r4
20023126:	f7ff fc56 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
2002312a:	4620      	mov	r0, r4
2002312c:	f7ff fa64 	bl	200225f8 <HAL_FLASH_READ32>
20023130:	2000      	movs	r0, #0
20023132:	bd38      	pop	{r3, r4, r5, pc}
20023134:	ea20 0103 	bic.w	r1, r0, r3
20023138:	e7e2      	b.n	20023100 <HAL_NAND_CONF_ECC+0x36>
2002313a:	f04f 30ff 	mov.w	r0, #4294967295
2002313e:	e7f8      	b.n	20023132 <HAL_NAND_CONF_ECC+0x68>
20023140:	f06f 0001 	mvn.w	r0, #1
20023144:	e7f5      	b.n	20023132 <HAL_NAND_CONF_ECC+0x68>

20023146 <HAL_NAND_GET_ECC_STATUS>:
20023146:	b510      	push	{r4, lr}
20023148:	4604      	mov	r4, r0
2002314a:	b320      	cbz	r0, 20023196 <HAL_NAND_GET_ECC_STATUS+0x50>
2002314c:	68c2      	ldr	r2, [r0, #12]
2002314e:	b31a      	cbz	r2, 20023198 <HAL_NAND_GET_ECC_STATUS+0x52>
20023150:	7913      	ldrb	r3, [r2, #4]
20023152:	b31b      	cbz	r3, 2002319c <HAL_NAND_GET_ECC_STATUS+0x56>
20023154:	79d3      	ldrb	r3, [r2, #7]
20023156:	b30b      	cbz	r3, 2002319c <HAL_NAND_GET_ECC_STATUS+0x56>
20023158:	2101      	movs	r1, #1
2002315a:	f7ff f9f7 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
2002315e:	68e3      	ldr	r3, [r4, #12]
20023160:	2102      	movs	r1, #2
20023162:	791a      	ldrb	r2, [r3, #4]
20023164:	4620      	mov	r0, r4
20023166:	f7ff fc36 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
2002316a:	4620      	mov	r0, r4
2002316c:	f7ff fa44 	bl	200225f8 <HAL_FLASH_READ32>
20023170:	f894 202c 	ldrb.w	r2, [r4, #44]	@ 0x2c
20023174:	2a3f      	cmp	r2, #63	@ 0x3f
20023176:	ea4f 1312 	mov.w	r3, r2, lsr #4
2002317a:	d804      	bhi.n	20023186 <HAL_NAND_GET_ECC_STATUS+0x40>
2002317c:	2b01      	cmp	r3, #1
2002317e:	d808      	bhi.n	20023192 <HAL_NAND_GET_ECC_STATUS+0x4c>
20023180:	f000 0030 	and.w	r0, r0, #48	@ 0x30
20023184:	e007      	b.n	20023196 <HAL_NAND_GET_ECC_STATUS+0x50>
20023186:	3b04      	subs	r3, #4
20023188:	2b01      	cmp	r3, #1
2002318a:	d8f9      	bhi.n	20023180 <HAL_NAND_GET_ECC_STATUS+0x3a>
2002318c:	f000 00f0 	and.w	r0, r0, #240	@ 0xf0
20023190:	e001      	b.n	20023196 <HAL_NAND_GET_ECC_STATUS+0x50>
20023192:	f000 0070 	and.w	r0, r0, #112	@ 0x70
20023196:	bd10      	pop	{r4, pc}
20023198:	4610      	mov	r0, r2
2002319a:	e7fc      	b.n	20023196 <HAL_NAND_GET_ECC_STATUS+0x50>
2002319c:	4618      	mov	r0, r3
2002319e:	e7fa      	b.n	20023196 <HAL_NAND_GET_ECC_STATUS+0x50>

200231a0 <HAL_NAND_CHECK_ECC>:
200231a0:	4603      	mov	r3, r0
200231a2:	1108      	asrs	r0, r1, #4
200231a4:	b172      	cbz	r2, 200231c4 <HAL_NAND_CHECK_ECC+0x24>
200231a6:	2b07      	cmp	r3, #7
200231a8:	d80c      	bhi.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
200231aa:	e8df f003 	tbb	[pc, r3]
200231ae:	0d04      	.short	0x0d04
200231b0:	3f352e18 	.word	0x3f352e18
200231b4:	4c47      	.short	0x4c47
200231b6:	b128      	cbz	r0, 200231c4 <HAL_NAND_CHECK_ECC+0x24>
200231b8:	2801      	cmp	r0, #1
200231ba:	6813      	ldr	r3, [r2, #0]
200231bc:	d10a      	bne.n	200231d4 <HAL_NAND_CHECK_ECC+0x34>
200231be:	f043 0301 	orr.w	r3, r3, #1
200231c2:	6013      	str	r3, [r2, #0]
200231c4:	2000      	movs	r0, #0
200231c6:	4770      	bx	lr
200231c8:	f020 0302 	bic.w	r3, r0, #2
200231cc:	2b01      	cmp	r3, #1
200231ce:	d003      	beq.n	200231d8 <HAL_NAND_CHECK_ECC+0x38>
200231d0:	b1d0      	cbz	r0, 20023208 <HAL_NAND_CHECK_ECC+0x68>
200231d2:	6813      	ldr	r3, [r2, #0]
200231d4:	4303      	orrs	r3, r0
200231d6:	e016      	b.n	20023206 <HAL_NAND_CHECK_ECC+0x66>
200231d8:	6813      	ldr	r3, [r2, #0]
200231da:	4303      	orrs	r3, r0
200231dc:	e7f1      	b.n	200231c2 <HAL_NAND_CHECK_ECC+0x22>
200231de:	2805      	cmp	r0, #5
200231e0:	d8f7      	bhi.n	200231d2 <HAL_NAND_CHECK_ECC+0x32>
200231e2:	a301      	add	r3, pc, #4	@ (adr r3, 200231e8 <HAL_NAND_CHECK_ECC+0x48>)
200231e4:	f853 f020 	ldr.w	pc, [r3, r0, lsl #2]
200231e8:	200231c5 	.word	0x200231c5
200231ec:	200231d9 	.word	0x200231d9
200231f0:	20023201 	.word	0x20023201
200231f4:	200231d9 	.word	0x200231d9
200231f8:	200231d3 	.word	0x200231d3
200231fc:	200231d9 	.word	0x200231d9
20023200:	6813      	ldr	r3, [r2, #0]
20023202:	f043 0302 	orr.w	r3, r3, #2
20023206:	6013      	str	r3, [r2, #0]
20023208:	4770      	bx	lr
2002320a:	2800      	cmp	r0, #0
2002320c:	d0da      	beq.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
2002320e:	1e43      	subs	r3, r0, #1
20023210:	2b05      	cmp	r3, #5
20023212:	6813      	ldr	r3, [r2, #0]
20023214:	d9e1      	bls.n	200231da <HAL_NAND_CHECK_ECC+0x3a>
20023216:	e7dd      	b.n	200231d4 <HAL_NAND_CHECK_ECC+0x34>
20023218:	07c3      	lsls	r3, r0, #31
2002321a:	f000 0103 	and.w	r1, r0, #3
2002321e:	d402      	bmi.n	20023226 <HAL_NAND_CHECK_ECC+0x86>
20023220:	2900      	cmp	r1, #0
20023222:	d0cf      	beq.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
20023224:	e7d5      	b.n	200231d2 <HAL_NAND_CHECK_ECC+0x32>
20023226:	6813      	ldr	r3, [r2, #0]
20023228:	430b      	orrs	r3, r1
2002322a:	e7ca      	b.n	200231c2 <HAL_NAND_CHECK_ECC+0x22>
2002322c:	2800      	cmp	r0, #0
2002322e:	d0c9      	beq.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
20023230:	6813      	ldr	r3, [r2, #0]
20023232:	2808      	cmp	r0, #8
20023234:	ea43 0300 	orr.w	r3, r3, r0
20023238:	dce5      	bgt.n	20023206 <HAL_NAND_CHECK_ECC+0x66>
2002323a:	e7c2      	b.n	200231c2 <HAL_NAND_CHECK_ECC+0x22>
2002323c:	2800      	cmp	r0, #0
2002323e:	d0c1      	beq.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
20023240:	1e43      	subs	r3, r0, #1
20023242:	2b01      	cmp	r3, #1
20023244:	e7e5      	b.n	20023212 <HAL_NAND_CHECK_ECC+0x72>
20023246:	2800      	cmp	r0, #0
20023248:	d0bc      	beq.n	200231c4 <HAL_NAND_CHECK_ECC+0x24>
2002324a:	1e43      	subs	r3, r0, #1
2002324c:	2b02      	cmp	r3, #2
2002324e:	e7e0      	b.n	20023212 <HAL_NAND_CHECK_ECC+0x72>

20023250 <HAL_NAND_GET_ECC_RESULT>:
20023250:	b510      	push	{r4, lr}
20023252:	f890 302d 	ldrb.w	r3, [r0, #45]	@ 0x2d
20023256:	4604      	mov	r4, r0
20023258:	b90b      	cbnz	r3, 2002325e <HAL_NAND_GET_ECC_RESULT+0xe>
2002325a:	2000      	movs	r0, #0
2002325c:	bd10      	pop	{r4, pc}
2002325e:	f7ff ff72 	bl	20023146 <HAL_NAND_GET_ECC_STATUS>
20023262:	4601      	mov	r1, r0
20023264:	2800      	cmp	r0, #0
20023266:	d0f8      	beq.n	2002325a <HAL_NAND_GET_ECC_RESULT+0xa>
20023268:	6862      	ldr	r2, [r4, #4]
2002326a:	6be0      	ldr	r0, [r4, #60]	@ 0x3c
2002326c:	f442 4200 	orr.w	r2, r2, #32768	@ 0x8000
20023270:	6062      	str	r2, [r4, #4]
20023272:	b938      	cbnz	r0, 20023284 <HAL_NAND_GET_ECC_RESULT+0x34>
20023274:	f894 002c 	ldrb.w	r0, [r4, #44]	@ 0x2c
20023278:	1d22      	adds	r2, r4, #4
2002327a:	0900      	lsrs	r0, r0, #4
2002327c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20023280:	f7ff bf8e 	b.w	200231a0 <HAL_NAND_CHECK_ECC>
20023284:	f5b1 7f00 	cmp.w	r1, #512	@ 0x200
20023288:	ea4f 1321 	mov.w	r3, r1, asr #4
2002328c:	db00      	blt.n	20023290 <HAL_NAND_GET_ECC_RESULT+0x40>
2002328e:	e7fe      	b.n	2002328e <HAL_NAND_GET_ECC_RESULT+0x3e>
20023290:	6801      	ldr	r1, [r0, #0]
20023292:	40d9      	lsrs	r1, r3
20023294:	f011 0f01 	tst.w	r1, #1
20023298:	bf18      	it	ne
2002329a:	4618      	movne	r0, r3
2002329c:	ea43 0302 	orr.w	r3, r3, r2
200232a0:	bf08      	it	eq
200232a2:	2000      	moveq	r0, #0
200232a4:	6063      	str	r3, [r4, #4]
200232a6:	e7d9      	b.n	2002325c <HAL_NAND_GET_ECC_RESULT+0xc>

200232a8 <HAL_NAND_EN_QUAL>:
200232a8:	b538      	push	{r3, r4, r5, lr}
200232aa:	460d      	mov	r5, r1
200232ac:	4604      	mov	r4, r0
200232ae:	b348      	cbz	r0, 20023304 <HAL_NAND_EN_QUAL+0x5c>
200232b0:	68c3      	ldr	r3, [r0, #12]
200232b2:	b33b      	cbz	r3, 20023304 <HAL_NAND_EN_QUAL+0x5c>
200232b4:	799a      	ldrb	r2, [r3, #6]
200232b6:	b10a      	cbz	r2, 200232bc <HAL_NAND_EN_QUAL+0x14>
200232b8:	7a1b      	ldrb	r3, [r3, #8]
200232ba:	b90b      	cbnz	r3, 200232c0 <HAL_NAND_EN_QUAL+0x18>
200232bc:	2000      	movs	r0, #0
200232be:	bd38      	pop	{r3, r4, r5, pc}
200232c0:	2101      	movs	r1, #1
200232c2:	f7ff f943 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200232c6:	68e3      	ldr	r3, [r4, #12]
200232c8:	2102      	movs	r1, #2
200232ca:	799a      	ldrb	r2, [r3, #6]
200232cc:	4620      	mov	r0, r4
200232ce:	f7ff fb82 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200232d2:	4620      	mov	r0, r4
200232d4:	f7ff f990 	bl	200225f8 <HAL_FLASH_READ32>
200232d8:	68e3      	ldr	r3, [r4, #12]
200232da:	7a1b      	ldrb	r3, [r3, #8]
200232dc:	b17d      	cbz	r5, 200232fe <HAL_NAND_EN_QUAL+0x56>
200232de:	ea43 0100 	orr.w	r1, r3, r0
200232e2:	4620      	mov	r0, r4
200232e4:	f7ff f92b 	bl	2002253e <HAL_FLASH_WRITE_WORD>
200232e8:	2101      	movs	r1, #1
200232ea:	4620      	mov	r0, r4
200232ec:	f7ff f92e 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200232f0:	68e3      	ldr	r3, [r4, #12]
200232f2:	2103      	movs	r1, #3
200232f4:	4620      	mov	r0, r4
200232f6:	799a      	ldrb	r2, [r3, #6]
200232f8:	f7ff fb6d 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200232fc:	e7de      	b.n	200232bc <HAL_NAND_EN_QUAL+0x14>
200232fe:	ea20 0103 	bic.w	r1, r0, r3
20023302:	e7ee      	b.n	200232e2 <HAL_NAND_EN_QUAL+0x3a>
20023304:	f04f 30ff 	mov.w	r0, #4294967295
20023308:	e7d9      	b.n	200232be <HAL_NAND_EN_QUAL+0x16>

2002330a <nand_clear_status>:
2002330a:	b538      	push	{r3, r4, r5, lr}
2002330c:	460d      	mov	r5, r1
2002330e:	2101      	movs	r1, #1
20023310:	4604      	mov	r4, r0
20023312:	f7ff f91b 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20023316:	2dc9      	cmp	r5, #201	@ 0xc9
20023318:	d001      	beq.n	2002331e <nand_clear_status+0x14>
2002331a:	2d01      	cmp	r5, #1
2002331c:	d109      	bne.n	20023332 <nand_clear_status+0x28>
2002331e:	2102      	movs	r1, #2
20023320:	4620      	mov	r0, r4
20023322:	f7ff f90c 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20023326:	68e3      	ldr	r3, [r4, #12]
20023328:	2103      	movs	r1, #3
2002332a:	4620      	mov	r0, r4
2002332c:	795a      	ldrb	r2, [r3, #5]
2002332e:	f7ff fb52 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023332:	2100      	movs	r1, #0
20023334:	4620      	mov	r0, r4
20023336:	f7ff f902 	bl	2002253e <HAL_FLASH_WRITE_WORD>
2002333a:	68e3      	ldr	r3, [r4, #12]
2002333c:	2103      	movs	r1, #3
2002333e:	4620      	mov	r0, r4
20023340:	795a      	ldrb	r2, [r3, #5]
20023342:	f7ff fb48 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023346:	2000      	movs	r0, #0
20023348:	bd38      	pop	{r3, r4, r5, pc}

2002334a <HAL_NAND_PAGE_SIZE>:
2002334a:	b140      	cbz	r0, 2002335e <HAL_NAND_PAGE_SIZE+0x14>
2002334c:	f890 302c 	ldrb.w	r3, [r0, #44]	@ 0x2c
20023350:	f013 0f01 	tst.w	r3, #1
20023354:	bf14      	ite	ne
20023356:	f44f 5080 	movne.w	r0, #4096	@ 0x1000
2002335a:	f44f 6000 	moveq.w	r0, #2048	@ 0x800
2002335e:	4770      	bx	lr

20023360 <HAL_NAND_READ_WITHOOB>:
20023360:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023364:	b085      	sub	sp, #20
20023366:	460e      	mov	r6, r1
20023368:	4691      	mov	r9, r2
2002336a:	461d      	mov	r5, r3
2002336c:	4604      	mov	r4, r0
2002336e:	9f0f      	ldr	r7, [sp, #60]	@ 0x3c
20023370:	b1b0      	cbz	r0, 200233a0 <HAL_NAND_READ_WITHOOB+0x40>
20023372:	68c3      	ldr	r3, [r0, #12]
20023374:	b1a3      	cbz	r3, 200233a0 <HAL_NAND_READ_WITHOOB+0x40>
20023376:	69c3      	ldr	r3, [r0, #28]
20023378:	b193      	cbz	r3, 200233a0 <HAL_NAND_READ_WITHOOB+0x40>
2002337a:	2f80      	cmp	r7, #128	@ 0x80
2002337c:	d810      	bhi.n	200233a0 <HAL_NAND_READ_WITHOOB+0x40>
2002337e:	f7ff ffe4 	bl	2002334a <HAL_NAND_PAGE_SIZE>
20023382:	f100 3aff 	add.w	sl, r0, #4294967295
20023386:	ea0a 0a01 	and.w	sl, sl, r1
2002338a:	eb0a 0305 	add.w	r3, sl, r5
2002338e:	4283      	cmp	r3, r0
20023390:	4680      	mov	r8, r0
20023392:	d907      	bls.n	200233a4 <HAL_NAND_READ_WITHOOB+0x44>
20023394:	2002      	movs	r0, #2
20023396:	6060      	str	r0, [r4, #4]
20023398:	2000      	movs	r0, #0
2002339a:	b005      	add	sp, #20
2002339c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200233a0:	2001      	movs	r0, #1
200233a2:	e7f8      	b.n	20023396 <HAL_NAND_READ_WITHOOB+0x36>
200233a4:	2300      	movs	r3, #0
200233a6:	6063      	str	r3, [r4, #4]
200233a8:	6923      	ldr	r3, [r4, #16]
200233aa:	f04f 0b00 	mov.w	fp, #0
200233ae:	428b      	cmp	r3, r1
200233b0:	bf98      	it	ls
200233b2:	1ace      	subls	r6, r1, r3
200233b4:	fbb6 f2f0 	udiv	r2, r6, r0
200233b8:	2104      	movs	r1, #4
200233ba:	4620      	mov	r0, r4
200233bc:	f7ff fb0b 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200233c0:	2014      	movs	r0, #20
200233c2:	f7fe fabf 	bl	20021944 <HAL_Delay_us_>
200233c6:	2101      	movs	r1, #1
200233c8:	4620      	mov	r0, r4
200233ca:	f7ff f8bf 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200233ce:	2005      	movs	r0, #5
200233d0:	f7fe fab8 	bl	20021944 <HAL_Delay_us_>
200233d4:	68e2      	ldr	r2, [r4, #12]
200233d6:	2102      	movs	r1, #2
200233d8:	7912      	ldrb	r2, [r2, #4]
200233da:	4620      	mov	r0, r4
200233dc:	f7ff fafb 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200233e0:	4620      	mov	r0, r4
200233e2:	f7ff f909 	bl	200225f8 <HAL_FLASH_READ32>
200233e6:	07c1      	lsls	r1, r0, #31
200233e8:	d4f1      	bmi.n	200233ce <HAL_NAND_READ_WITHOOB+0x6e>
200233ea:	f1bb 0f00 	cmp.w	fp, #0
200233ee:	d102      	bne.n	200233f6 <HAL_NAND_READ_WITHOOB+0x96>
200233f0:	f04f 0b01 	mov.w	fp, #1
200233f4:	e7eb      	b.n	200233ce <HAL_NAND_READ_WITHOOB+0x6e>
200233f6:	4620      	mov	r0, r4
200233f8:	f7ff ff2a 	bl	20023250 <HAL_NAND_GET_ECC_RESULT>
200233fc:	b110      	cbz	r0, 20023404 <HAL_NAND_READ_WITHOOB+0xa4>
200233fe:	f440 4000 	orr.w	r0, r0, #32768	@ 0x8000
20023402:	e7c8      	b.n	20023396 <HAL_NAND_READ_WITHOOB+0x36>
20023404:	f894 2028 	ldrb.w	r2, [r4, #40]	@ 0x28
20023408:	68e3      	ldr	r3, [r4, #12]
2002340a:	bbb2      	cbnz	r2, 2002347a <HAL_NAND_READ_WITHOOB+0x11a>
2002340c:	f893 1046 	ldrb.w	r1, [r3, #70]	@ 0x46
20023410:	4620      	mov	r0, r4
20023412:	f7ff f843 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
20023416:	68e0      	ldr	r0, [r4, #12]
20023418:	f990 c04e 	ldrsb.w	ip, [r0, #78]	@ 0x4e
2002341c:	f990 304a 	ldrsb.w	r3, [r0, #74]	@ 0x4a
20023420:	f990 2049 	ldrsb.w	r2, [r0, #73]	@ 0x49
20023424:	f990 1048 	ldrsb.w	r1, [r0, #72]	@ 0x48
20023428:	f8cd c00c 	str.w	ip, [sp, #12]
2002342c:	f990 c04d 	ldrsb.w	ip, [r0, #77]	@ 0x4d
20023430:	f8cd c008 	str.w	ip, [sp, #8]
20023434:	f990 c04c 	ldrsb.w	ip, [r0, #76]	@ 0x4c
20023438:	f8cd c004 	str.w	ip, [sp, #4]
2002343c:	f990 004b 	ldrsb.w	r0, [r0, #75]	@ 0x4b
20023440:	9000      	str	r0, [sp, #0]
20023442:	4620      	mov	r0, r4
20023444:	f7ff f835 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20023448:	03b2      	lsls	r2, r6, #14
2002344a:	f8d4 b010 	ldr.w	fp, [r4, #16]
2002344e:	d504      	bpl.n	2002345a <HAL_NAND_READ_WITHOOB+0xfa>
20023450:	f894 202f 	ldrb.w	r2, [r4, #47]	@ 0x2f
20023454:	b10a      	cbz	r2, 2002345a <HAL_NAND_READ_WITHOOB+0xfa>
20023456:	f44b 5b80 	orr.w	fp, fp, #4096	@ 0x1000
2002345a:	ea49 0205 	orr.w	r2, r9, r5
2002345e:	ea42 020a 	orr.w	r2, r2, sl
20023462:	0793      	lsls	r3, r2, #30
20023464:	d102      	bne.n	2002346c <HAL_NAND_READ_WITHOOB+0x10c>
20023466:	1e6a      	subs	r2, r5, #1
20023468:	2afe      	cmp	r2, #254	@ 0xfe
2002346a:	d821      	bhi.n	200234b0 <HAL_NAND_READ_WITHOOB+0x150>
2002346c:	462a      	mov	r2, r5
2002346e:	4648      	mov	r0, r9
20023470:	eb0b 010a 	add.w	r1, fp, sl
20023474:	f002 ff5d 	bl	20026332 <memcpy>
20023478:	e01d      	b.n	200234b6 <HAL_NAND_READ_WITHOOB+0x156>
2002347a:	f893 106a 	ldrb.w	r1, [r3, #106]	@ 0x6a
2002347e:	4620      	mov	r0, r4
20023480:	f7ff f80c 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
20023484:	68e0      	ldr	r0, [r4, #12]
20023486:	f990 c072 	ldrsb.w	ip, [r0, #114]	@ 0x72
2002348a:	f990 306e 	ldrsb.w	r3, [r0, #110]	@ 0x6e
2002348e:	f990 206d 	ldrsb.w	r2, [r0, #109]	@ 0x6d
20023492:	f990 106c 	ldrsb.w	r1, [r0, #108]	@ 0x6c
20023496:	f8cd c00c 	str.w	ip, [sp, #12]
2002349a:	f990 c071 	ldrsb.w	ip, [r0, #113]	@ 0x71
2002349e:	f8cd c008 	str.w	ip, [sp, #8]
200234a2:	f990 c070 	ldrsb.w	ip, [r0, #112]	@ 0x70
200234a6:	f8cd c004 	str.w	ip, [sp, #4]
200234aa:	f990 006f 	ldrsb.w	r0, [r0, #111]	@ 0x6f
200234ae:	e7c7      	b.n	20023440 <HAL_NAND_READ_WITHOOB+0xe0>
200234b0:	f1b9 0f00 	cmp.w	r9, #0
200234b4:	d1da      	bne.n	2002346c <HAL_NAND_READ_WITHOOB+0x10c>
200234b6:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
200234b8:	b12b      	cbz	r3, 200234c6 <HAL_NAND_READ_WITHOOB+0x166>
200234ba:	463a      	mov	r2, r7
200234bc:	4618      	mov	r0, r3
200234be:	eb0b 0108 	add.w	r1, fp, r8
200234c2:	f002 ff36 	bl	20026332 <memcpy>
200234c6:	1978      	adds	r0, r7, r5
200234c8:	e767      	b.n	2002339a <HAL_NAND_READ_WITHOOB+0x3a>

200234ca <HAL_NAND_BLOCK_SIZE>:
200234ca:	b508      	push	{r3, lr}
200234cc:	4602      	mov	r2, r0
200234ce:	f7ff ff3c 	bl	2002334a <HAL_NAND_PAGE_SIZE>
200234d2:	b128      	cbz	r0, 200234e0 <HAL_NAND_BLOCK_SIZE+0x16>
200234d4:	f892 302c 	ldrb.w	r3, [r2, #44]	@ 0x2c
200234d8:	079b      	lsls	r3, r3, #30
200234da:	bf4c      	ite	mi
200234dc:	01c0      	lslmi	r0, r0, #7
200234de:	0180      	lslpl	r0, r0, #6
200234e0:	bd08      	pop	{r3, pc}

200234e2 <HAL_NAND_GET_BADBLK>:
200234e2:	b51f      	push	{r0, r1, r2, r3, r4, lr}
200234e4:	4604      	mov	r4, r0
200234e6:	b910      	cbnz	r0, 200234ee <HAL_NAND_GET_BADBLK+0xc>
200234e8:	2000      	movs	r0, #0
200234ea:	b004      	add	sp, #16
200234ec:	bd10      	pop	{r4, pc}
200234ee:	6a03      	ldr	r3, [r0, #32]
200234f0:	2b00      	cmp	r3, #0
200234f2:	d0f9      	beq.n	200234e8 <HAL_NAND_GET_BADBLK+0x6>
200234f4:	f7ff ffe9 	bl	200234ca <HAL_NAND_BLOCK_SIZE>
200234f8:	2304      	movs	r3, #4
200234fa:	9301      	str	r3, [sp, #4]
200234fc:	ab03      	add	r3, sp, #12
200234fe:	9300      	str	r3, [sp, #0]
20023500:	2300      	movs	r3, #0
20023502:	4341      	muls	r1, r0
20023504:	461a      	mov	r2, r3
20023506:	4620      	mov	r0, r4
20023508:	f7ff ff2a 	bl	20023360 <HAL_NAND_READ_WITHOOB>
2002350c:	b140      	cbz	r0, 20023520 <HAL_NAND_GET_BADBLK+0x3e>
2002350e:	f89d 300c 	ldrb.w	r3, [sp, #12]
20023512:	2bff      	cmp	r3, #255	@ 0xff
20023514:	d0e8      	beq.n	200234e8 <HAL_NAND_GET_BADBLK+0x6>
20023516:	9803      	ldr	r0, [sp, #12]
20023518:	2800      	cmp	r0, #0
2002351a:	bf08      	it	eq
2002351c:	2001      	moveq	r0, #1
2002351e:	e7e4      	b.n	200234ea <HAL_NAND_GET_BADBLK+0x8>
20023520:	2001      	movs	r0, #1
20023522:	e7e2      	b.n	200234ea <HAL_NAND_GET_BADBLK+0x8>

20023524 <HAL_QSPIEX_WRITE_PAGE>:
20023524:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20023528:	b099      	sub	sp, #100	@ 0x64
2002352a:	4604      	mov	r4, r0
2002352c:	460e      	mov	r6, r1
2002352e:	4691      	mov	r9, r2
20023530:	f7ff fd21 	bl	20022f76 <flash_handle_valid>
20023534:	b318      	cbz	r0, 2002357e <HAL_QSPIEX_WRITE_PAGE+0x5a>
20023536:	2b00      	cmp	r3, #0
20023538:	f000 80d7 	beq.w	200236ea <HAL_QSPIEX_WRITE_PAGE+0x1c6>
2002353c:	f5b3 7f80 	cmp.w	r3, #256	@ 0x100
20023540:	bf28      	it	cs
20023542:	f44f 7380 	movcs.w	r3, #256	@ 0x100
20023546:	68a1      	ldr	r1, [r4, #8]
20023548:	461d      	mov	r5, r3
2002354a:	6962      	ldr	r2, [r4, #20]
2002354c:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023550:	2900      	cmp	r1, #0
20023552:	d03b      	beq.n	200235cc <HAL_QSPIEX_WRITE_PAGE+0xa8>
20023554:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
20023558:	d914      	bls.n	20023584 <HAL_QSPIEX_WRITE_PAGE+0x60>
2002355a:	2b02      	cmp	r3, #2
2002355c:	bf14      	ite	ne
2002355e:	2727      	movne	r7, #39	@ 0x27
20023560:	2728      	moveq	r7, #40	@ 0x28
20023562:	4639      	mov	r1, r7
20023564:	4620      	mov	r0, r4
20023566:	f7ff fa0f 	bl	20022988 <HAL_FLASH_PRE_CMD>
2002356a:	4649      	mov	r1, r9
2002356c:	462b      	mov	r3, r5
2002356e:	2201      	movs	r2, #1
20023570:	4620      	mov	r0, r4
20023572:	f7ff fd08 	bl	20022f86 <HAL_FLASH_DMA_START>
20023576:	4601      	mov	r1, r0
20023578:	b148      	cbz	r0, 2002358e <HAL_QSPIEX_WRITE_PAGE+0x6a>
2002357a:	2500      	movs	r5, #0
2002357c:	4628      	mov	r0, r5
2002357e:	b019      	add	sp, #100	@ 0x64
20023580:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20023584:	2b02      	cmp	r3, #2
20023586:	bf14      	ite	ne
20023588:	2716      	movne	r7, #22
2002358a:	2717      	moveq	r7, #23
2002358c:	e7e9      	b.n	20023562 <HAL_QSPIEX_WRITE_PAGE+0x3e>
2002358e:	4632      	mov	r2, r6
20023590:	4620      	mov	r0, r4
20023592:	f7ff fa20 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023596:	2101      	movs	r1, #1
20023598:	4620      	mov	r0, r4
2002359a:	f7fe ffe1 	bl	20022560 <HAL_FLASH_WRITE_DLEN2>
2002359e:	2301      	movs	r3, #1
200235a0:	4632      	mov	r2, r6
200235a2:	9300      	str	r3, [sp, #0]
200235a4:	4639      	mov	r1, r7
200235a6:	2302      	movs	r3, #2
200235a8:	4620      	mov	r0, r4
200235aa:	f7ff fa47 	bl	20022a3c <HAL_FLASH_ISSUE_CMD_SEQ>
200235ae:	2800      	cmp	r0, #0
200235b0:	d1e3      	bne.n	2002357a <HAL_QSPIEX_WRITE_PAGE+0x56>
200235b2:	f44f 717a 	mov.w	r1, #1000	@ 0x3e8
200235b6:	4620      	mov	r0, r4
200235b8:	f7ff fd35 	bl	20023026 <HAL_FLASH_DMA_WAIT_DONE>
200235bc:	2800      	cmp	r0, #0
200235be:	d1dc      	bne.n	2002357a <HAL_QSPIEX_WRITE_PAGE+0x56>
200235c0:	6822      	ldr	r2, [r4, #0]
200235c2:	6813      	ldr	r3, [r2, #0]
200235c4:	f023 0320 	bic.w	r3, r3, #32
200235c8:	6013      	str	r3, [r2, #0]
200235ca:	e7d7      	b.n	2002357c <HAL_QSPIEX_WRITE_PAGE+0x58>
200235cc:	f1b2 7f80 	cmp.w	r2, #16777216	@ 0x1000000
200235d0:	f240 8082 	bls.w	200236d8 <HAL_QSPIEX_WRITE_PAGE+0x1b4>
200235d4:	2b02      	cmp	r3, #2
200235d6:	bf14      	ite	ne
200235d8:	2327      	movne	r3, #39	@ 0x27
200235da:	2328      	moveq	r3, #40	@ 0x28
200235dc:	462f      	mov	r7, r5
200235de:	f04f 0800 	mov.w	r8, #0
200235e2:	9303      	str	r3, [sp, #12]
200235e4:	f64f 7afc 	movw	sl, #65532	@ 0xfffc
200235e8:	2f40      	cmp	r7, #64	@ 0x40
200235ea:	bfd4      	ite	le
200235ec:	ea0a 0a07 	andle.w	sl, sl, r7
200235f0:	f00a 0a40 	andgt.w	sl, sl, #64	@ 0x40
200235f4:	f1ba 0f00 	cmp.w	sl, #0
200235f8:	d03f      	beq.n	2002367a <HAL_QSPIEX_WRITE_PAGE+0x156>
200235fa:	2200      	movs	r2, #0
200235fc:	4620      	mov	r0, r4
200235fe:	4611      	mov	r1, r2
20023600:	f7ff f9e9 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023604:	eb09 0308 	add.w	r3, r9, r8
20023608:	f10d 0c20 	add.w	ip, sp, #32
2002360c:	f103 0e40 	add.w	lr, r3, #64	@ 0x40
20023610:	4662      	mov	r2, ip
20023612:	6818      	ldr	r0, [r3, #0]
20023614:	6859      	ldr	r1, [r3, #4]
20023616:	3308      	adds	r3, #8
20023618:	c203      	stmia	r2!, {r0, r1}
2002361a:	4573      	cmp	r3, lr
2002361c:	4694      	mov	ip, r2
2002361e:	d1f7      	bne.n	20023610 <HAL_QSPIEX_WRITE_PAGE+0xec>
20023620:	f04f 0b00 	mov.w	fp, #0
20023624:	ea4f 02aa 	mov.w	r2, sl, asr #2
20023628:	ab08      	add	r3, sp, #32
2002362a:	f853 1b04 	ldr.w	r1, [r3], #4
2002362e:	4620      	mov	r0, r4
20023630:	9205      	str	r2, [sp, #20]
20023632:	9304      	str	r3, [sp, #16]
20023634:	f7fe ff83 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20023638:	9a05      	ldr	r2, [sp, #20]
2002363a:	f10b 0b01 	add.w	fp, fp, #1
2002363e:	4593      	cmp	fp, r2
20023640:	9b04      	ldr	r3, [sp, #16]
20023642:	d1f2      	bne.n	2002362a <HAL_QSPIEX_WRITE_PAGE+0x106>
20023644:	4651      	mov	r1, sl
20023646:	4620      	mov	r0, r4
20023648:	f7fe ff80 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
2002364c:	4620      	mov	r0, r4
2002364e:	9903      	ldr	r1, [sp, #12]
20023650:	eb06 0208 	add.w	r2, r6, r8
20023654:	f7ff f9bf 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023658:	2101      	movs	r1, #1
2002365a:	4620      	mov	r0, r4
2002365c:	f7fe ff76 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20023660:	2200      	movs	r2, #0
20023662:	2102      	movs	r1, #2
20023664:	4620      	mov	r0, r4
20023666:	f7ff f9b6 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
2002366a:	4620      	mov	r0, r4
2002366c:	f7fe ffbb 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
20023670:	2800      	cmp	r0, #0
20023672:	d0f1      	beq.n	20023658 <HAL_QSPIEX_WRITE_PAGE+0x134>
20023674:	eba7 070a 	sub.w	r7, r7, sl
20023678:	44d0      	add	r8, sl
2002367a:	1e7b      	subs	r3, r7, #1
2002367c:	2b02      	cmp	r3, #2
2002367e:	d830      	bhi.n	200236e2 <HAL_QSPIEX_WRITE_PAGE+0x1be>
20023680:	6923      	ldr	r3, [r4, #16]
20023682:	4446      	add	r6, r8
20023684:	4333      	orrs	r3, r6
20023686:	681b      	ldr	r3, [r3, #0]
20023688:	463a      	mov	r2, r7
2002368a:	eb09 0108 	add.w	r1, r9, r8
2002368e:	a807      	add	r0, sp, #28
20023690:	9307      	str	r3, [sp, #28]
20023692:	f002 fe4e 	bl	20026332 <memcpy>
20023696:	2200      	movs	r2, #0
20023698:	4620      	mov	r0, r4
2002369a:	4611      	mov	r1, r2
2002369c:	f7ff f99b 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200236a0:	9907      	ldr	r1, [sp, #28]
200236a2:	4620      	mov	r0, r4
200236a4:	f7fe ff4b 	bl	2002253e <HAL_FLASH_WRITE_WORD>
200236a8:	2104      	movs	r1, #4
200236aa:	4620      	mov	r0, r4
200236ac:	f7fe ff4e 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200236b0:	4632      	mov	r2, r6
200236b2:	4620      	mov	r0, r4
200236b4:	9903      	ldr	r1, [sp, #12]
200236b6:	f7ff f98e 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200236ba:	2101      	movs	r1, #1
200236bc:	4620      	mov	r0, r4
200236be:	f7fe ff45 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200236c2:	2200      	movs	r2, #0
200236c4:	2102      	movs	r1, #2
200236c6:	4620      	mov	r0, r4
200236c8:	f7ff f985 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
200236cc:	4620      	mov	r0, r4
200236ce:	f7fe ff8a 	bl	200225e6 <HAL_FLASH_IS_PROG_DONE>
200236d2:	2800      	cmp	r0, #0
200236d4:	d0f1      	beq.n	200236ba <HAL_QSPIEX_WRITE_PAGE+0x196>
200236d6:	e751      	b.n	2002357c <HAL_QSPIEX_WRITE_PAGE+0x58>
200236d8:	2b02      	cmp	r3, #2
200236da:	bf14      	ite	ne
200236dc:	2316      	movne	r3, #22
200236de:	2317      	moveq	r3, #23
200236e0:	e77c      	b.n	200235dc <HAL_QSPIEX_WRITE_PAGE+0xb8>
200236e2:	2f00      	cmp	r7, #0
200236e4:	f73f af7e 	bgt.w	200235e4 <HAL_QSPIEX_WRITE_PAGE+0xc0>
200236e8:	e748      	b.n	2002357c <HAL_QSPIEX_WRITE_PAGE+0x58>
200236ea:	4618      	mov	r0, r3
200236ec:	e747      	b.n	2002357e <HAL_QSPIEX_WRITE_PAGE+0x5a>

200236ee <HAL_QSPIEX_SECT_ERASE>:
200236ee:	b573      	push	{r0, r1, r4, r5, r6, lr}
200236f0:	4604      	mov	r4, r0
200236f2:	460d      	mov	r5, r1
200236f4:	f7ff fc3f 	bl	20022f76 <flash_handle_valid>
200236f8:	b1e8      	cbz	r0, 20023736 <HAL_QSPIEX_SECT_ERASE+0x48>
200236fa:	6963      	ldr	r3, [r4, #20]
200236fc:	460a      	mov	r2, r1
200236fe:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023702:	f04f 0100 	mov.w	r1, #0
20023706:	4620      	mov	r0, r4
20023708:	bf94      	ite	ls
2002370a:	261b      	movls	r6, #27
2002370c:	2629      	movhi	r6, #41	@ 0x29
2002370e:	f7ff f962 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023712:	2101      	movs	r1, #1
20023714:	4620      	mov	r0, r4
20023716:	f7fe ff23 	bl	20022560 <HAL_FLASH_WRITE_DLEN2>
2002371a:	2301      	movs	r3, #1
2002371c:	462a      	mov	r2, r5
2002371e:	9300      	str	r3, [sp, #0]
20023720:	4631      	mov	r1, r6
20023722:	2302      	movs	r3, #2
20023724:	4620      	mov	r0, r4
20023726:	f7ff f989 	bl	20022a3c <HAL_FLASH_ISSUE_CMD_SEQ>
2002372a:	3800      	subs	r0, #0
2002372c:	bf18      	it	ne
2002372e:	2001      	movne	r0, #1
20023730:	4240      	negs	r0, r0
20023732:	b002      	add	sp, #8
20023734:	bd70      	pop	{r4, r5, r6, pc}
20023736:	f04f 30ff 	mov.w	r0, #4294967295
2002373a:	e7fa      	b.n	20023732 <HAL_QSPIEX_SECT_ERASE+0x44>

2002373c <HAL_QSPI_GET_SRC_CLK>:
2002373c:	b508      	push	{r3, lr}
2002373e:	b318      	cbz	r0, 20023788 <HAL_QSPI_GET_SRC_CLK+0x4c>
20023740:	6803      	ldr	r3, [r0, #0]
20023742:	4a12      	ldr	r2, [pc, #72]	@ (2002378c <HAL_QSPI_GET_SRC_CLK+0x50>)
20023744:	4293      	cmp	r3, r2
20023746:	d010      	beq.n	2002376a <HAL_QSPI_GET_SRC_CLK+0x2e>
20023748:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
2002374c:	4293      	cmp	r3, r2
2002374e:	d00e      	beq.n	2002376e <HAL_QSPI_GET_SRC_CLK+0x32>
20023750:	f502 5280 	add.w	r2, r2, #4096	@ 0x1000
20023754:	4293      	cmp	r3, r2
20023756:	d117      	bne.n	20023788 <HAL_QSPI_GET_SRC_CLK+0x4c>
20023758:	2008      	movs	r0, #8
2002375a:	f000 ff61 	bl	20024620 <HAL_RCC_HCPU_GetClockSrc>
2002375e:	2802      	cmp	r0, #2
20023760:	d107      	bne.n	20023772 <HAL_QSPI_GET_SRC_CLK+0x36>
20023762:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023766:	f000 bf9f 	b.w	200246a8 <HAL_RCC_HCPU_GetDLL2Freq>
2002376a:	2004      	movs	r0, #4
2002376c:	e7f5      	b.n	2002375a <HAL_QSPI_GET_SRC_CLK+0x1e>
2002376e:	2006      	movs	r0, #6
20023770:	e7f3      	b.n	2002375a <HAL_QSPI_GET_SRC_CLK+0x1e>
20023772:	2803      	cmp	r0, #3
20023774:	d103      	bne.n	2002377e <HAL_QSPI_GET_SRC_CLK+0x42>
20023776:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
2002377a:	f000 bf98 	b.w	200246ae <HAL_RCC_HCPU_GetDLL3Freq>
2002377e:	2001      	movs	r0, #1
20023780:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
20023784:	f000 bfee 	b.w	20024764 <HAL_RCC_GetSysCLKFreq>
20023788:	2000      	movs	r0, #0
2002378a:	bd08      	pop	{r3, pc}
2002378c:	50041000 	.word	0x50041000

20023790 <HAL_QSPI_GET_CLK>:
20023790:	b538      	push	{r3, r4, r5, lr}
20023792:	4605      	mov	r5, r0
20023794:	b908      	cbnz	r0, 2002379a <HAL_QSPI_GET_CLK+0xa>
20023796:	2000      	movs	r0, #0
20023798:	bd38      	pop	{r3, r4, r5, pc}
2002379a:	f7fe ff3c 	bl	20022616 <HAL_FLASH_GET_DIV>
2002379e:	4604      	mov	r4, r0
200237a0:	2800      	cmp	r0, #0
200237a2:	d0f8      	beq.n	20023796 <HAL_QSPI_GET_CLK+0x6>
200237a4:	4628      	mov	r0, r5
200237a6:	f7ff ffc9 	bl	2002373c <HAL_QSPI_GET_SRC_CLK>
200237aa:	fbb0 f0f4 	udiv	r0, r0, r4
200237ae:	e7f3      	b.n	20023798 <HAL_QSPI_GET_CLK+0x8>

200237b0 <HAL_QSPI_READ_ID>:
200237b0:	b138      	cbz	r0, 200237c2 <HAL_QSPI_READ_ID+0x12>
200237b2:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
200237b6:	b113      	cbz	r3, 200237be <HAL_QSPI_READ_ID+0xe>
200237b8:	2100      	movs	r1, #0
200237ba:	f7ff bc5a 	b.w	20023072 <nand_read_id>
200237be:	f7ff ba60 	b.w	20022c82 <HAL_FLASH_GET_NOR_ID>
200237c2:	20ff      	movs	r0, #255	@ 0xff
200237c4:	4770      	bx	lr

200237c6 <HAL_NOR_CFG_DTR>:
200237c6:	b57f      	push	{r0, r1, r2, r3, r4, r5, r6, lr}
200237c8:	4604      	mov	r4, r0
200237ca:	460a      	mov	r2, r1
200237cc:	b351      	cbz	r1, 20023824 <HAL_NOR_CFG_DTR+0x5e>
200237ce:	68c5      	ldr	r5, [r0, #12]
200237d0:	f895 31ff 	ldrb.w	r3, [r5, #511]	@ 0x1ff
200237d4:	2b00      	cmp	r3, #0
200237d6:	d03b      	beq.n	20023850 <HAL_NOR_CFG_DTR+0x8a>
200237d8:	f890 3028 	ldrb.w	r3, [r0, #40]	@ 0x28
200237dc:	b3c3      	cbz	r3, 20023850 <HAL_NOR_CFG_DTR+0x8a>
200237de:	f995 6207 	ldrsb.w	r6, [r5, #519]	@ 0x207
200237e2:	f995 2202 	ldrsb.w	r2, [r5, #514]	@ 0x202
200237e6:	f995 3203 	ldrsb.w	r3, [r5, #515]	@ 0x203
200237ea:	f995 1201 	ldrsb.w	r1, [r5, #513]	@ 0x201
200237ee:	9603      	str	r6, [sp, #12]
200237f0:	f995 6206 	ldrsb.w	r6, [r5, #518]	@ 0x206
200237f4:	9602      	str	r6, [sp, #8]
200237f6:	f995 6205 	ldrsb.w	r6, [r5, #517]	@ 0x205
200237fa:	9601      	str	r6, [sp, #4]
200237fc:	f995 5204 	ldrsb.w	r5, [r5, #516]	@ 0x204
20023800:	9500      	str	r5, [sp, #0]
20023802:	f7fe fe56 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20023806:	68e3      	ldr	r3, [r4, #12]
20023808:	4620      	mov	r0, r4
2002380a:	f893 11ff 	ldrb.w	r1, [r3, #511]	@ 0x1ff
2002380e:	f7fe fe45 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
20023812:	2101      	movs	r1, #1
20023814:	4620      	mov	r0, r4
20023816:	f894 202d 	ldrb.w	r2, [r4, #45]	@ 0x2d
2002381a:	f7ff f80a 	bl	20022832 <HAL_MPI_CFG_DTR>
2002381e:	2000      	movs	r0, #0
20023820:	b004      	add	sp, #16
20023822:	bd70      	pop	{r4, r5, r6, pc}
20023824:	f7ff f805 	bl	20022832 <HAL_MPI_CFG_DTR>
20023828:	6963      	ldr	r3, [r4, #20]
2002382a:	f894 1028 	ldrb.w	r1, [r4, #40]	@ 0x28
2002382e:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023832:	d906      	bls.n	20023842 <HAL_NOR_CFG_DTR+0x7c>
20023834:	b919      	cbnz	r1, 2002383e <HAL_NOR_CFG_DTR+0x78>
20023836:	4620      	mov	r0, r4
20023838:	f7ff f869 	bl	2002290e <HAL_FLASH_CONFIG_FULL_AHB_READ>
2002383c:	e7ef      	b.n	2002381e <HAL_NOR_CFG_DTR+0x58>
2002383e:	2101      	movs	r1, #1
20023840:	e7f9      	b.n	20023836 <HAL_NOR_CFG_DTR+0x70>
20023842:	b919      	cbnz	r1, 2002384c <HAL_NOR_CFG_DTR+0x86>
20023844:	4620      	mov	r0, r4
20023846:	f7ff f81e 	bl	20022886 <HAL_FLASH_CONFIG_AHB_READ>
2002384a:	e7e8      	b.n	2002381e <HAL_NOR_CFG_DTR+0x58>
2002384c:	2101      	movs	r1, #1
2002384e:	e7f9      	b.n	20023844 <HAL_NOR_CFG_DTR+0x7e>
20023850:	2001      	movs	r0, #1
20023852:	e7e5      	b.n	20023820 <HAL_NOR_CFG_DTR+0x5a>

20023854 <HAL_FLASH_Init>:
20023854:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
20023858:	460e      	mov	r6, r1
2002385a:	4690      	mov	r8, r2
2002385c:	461f      	mov	r7, r3
2002385e:	4604      	mov	r4, r0
20023860:	b087      	sub	sp, #28
20023862:	2800      	cmp	r0, #0
20023864:	f000 80e5 	beq.w	20023a32 <HAL_FLASH_Init+0x1de>
20023868:	2900      	cmp	r1, #0
2002386a:	f000 80e2 	beq.w	20023a32 <HAL_FLASH_Init+0x1de>
2002386e:	f7fe fdf3 	bl	20022458 <HAL_QSPI_Init>
20023872:	6820      	ldr	r0, [r4, #0]
20023874:	f7ff fb85 	bl	20022f82 <HAL_GET_FLASH_MID>
20023878:	6933      	ldr	r3, [r6, #16]
2002387a:	2100      	movs	r1, #0
2002387c:	f884 3044 	strb.w	r3, [r4, #68]	@ 0x44
20023880:	68b3      	ldr	r3, [r6, #8]
20023882:	4605      	mov	r5, r0
20023884:	64a3      	str	r3, [r4, #72]	@ 0x48
20023886:	68f3      	ldr	r3, [r6, #12]
20023888:	f884 102c 	strb.w	r1, [r4, #44]	@ 0x2c
2002388c:	051b      	lsls	r3, r3, #20
2002388e:	64e3      	str	r3, [r4, #76]	@ 0x4c
20023890:	2302      	movs	r3, #2
20023892:	f884 3046 	strb.w	r3, [r4, #70]	@ 0x46
20023896:	6933      	ldr	r3, [r6, #16]
20023898:	f8c4 8008 	str.w	r8, [r4, #8]
2002389c:	1e5a      	subs	r2, r3, #1
2002389e:	4253      	negs	r3, r2
200238a0:	4153      	adcs	r3, r2
200238a2:	f884 302b 	strb.w	r3, [r4, #43]	@ 0x2b
200238a6:	f1b8 0f00 	cmp.w	r8, #0
200238aa:	d058      	beq.n	2002395e <HAL_FLASH_Init+0x10a>
200238ac:	2f00      	cmp	r7, #0
200238ae:	d056      	beq.n	2002395e <HAL_FLASH_Init+0x10a>
200238b0:	683b      	ldr	r3, [r7, #0]
200238b2:	f8c8 3000 	str.w	r3, [r8]
200238b6:	68a3      	ldr	r3, [r4, #8]
200238b8:	68fa      	ldr	r2, [r7, #12]
200238ba:	605a      	str	r2, [r3, #4]
200238bc:	2210      	movs	r2, #16
200238be:	68a3      	ldr	r3, [r4, #8]
200238c0:	609a      	str	r2, [r3, #8]
200238c2:	2280      	movs	r2, #128	@ 0x80
200238c4:	68a3      	ldr	r3, [r4, #8]
200238c6:	60d9      	str	r1, [r3, #12]
200238c8:	68a3      	ldr	r3, [r4, #8]
200238ca:	611a      	str	r2, [r3, #16]
200238cc:	f44f 5280 	mov.w	r2, #4096	@ 0x1000
200238d0:	68a3      	ldr	r3, [r4, #8]
200238d2:	6159      	str	r1, [r3, #20]
200238d4:	68a3      	ldr	r3, [r4, #8]
200238d6:	6199      	str	r1, [r3, #24]
200238d8:	68a3      	ldr	r3, [r4, #8]
200238da:	61d9      	str	r1, [r3, #28]
200238dc:	68a3      	ldr	r3, [r4, #8]
200238de:	621a      	str	r2, [r3, #32]
200238e0:	68a3      	ldr	r3, [r4, #8]
200238e2:	6259      	str	r1, [r3, #36]	@ 0x24
200238e4:	b1c0      	cbz	r0, 20023918 <HAL_FLASH_Init+0xc4>
200238e6:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
200238ea:	4298      	cmp	r0, r3
200238ec:	d014      	beq.n	20023918 <HAL_FLASH_Init+0xc4>
200238ee:	2701      	movs	r7, #1
200238f0:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200238f4:	2b00      	cmp	r3, #0
200238f6:	d13d      	bne.n	20023974 <HAL_FLASH_Init+0x120>
200238f8:	2f00      	cmp	r7, #0
200238fa:	d15a      	bne.n	200239b2 <HAL_FLASH_Init+0x15e>
200238fc:	4620      	mov	r0, r4
200238fe:	f7ff fb1a 	bl	20022f36 <HAL_FLASH_RELEASE_DPD>
20023902:	4638      	mov	r0, r7
20023904:	f7fe f875 	bl	200219f2 <HAL_Delay_us>
20023908:	2032      	movs	r0, #50	@ 0x32
2002390a:	f7fe f872 	bl	200219f2 <HAL_Delay_us>
2002390e:	4620      	mov	r0, r4
20023910:	f7ff ff4e 	bl	200237b0 <HAL_QSPI_READ_ID>
20023914:	4605      	mov	r5, r0
20023916:	e04c      	b.n	200239b2 <HAL_FLASH_Init+0x15e>
20023918:	2101      	movs	r1, #1
2002391a:	4620      	mov	r0, r4
2002391c:	f7fe fe70 	bl	20022600 <HAL_FLASH_SET_TXSLOT>
20023920:	4baf      	ldr	r3, [pc, #700]	@ (20023be0 <HAL_FLASH_Init+0x38c>)
20023922:	69a2      	ldr	r2, [r4, #24]
20023924:	4620      	mov	r0, r4
20023926:	429a      	cmp	r2, r3
20023928:	f04f 0200 	mov.w	r2, #0
2002392c:	bf8c      	ite	hi
2002392e:	2101      	movhi	r1, #1
20023930:	4611      	movls	r1, r2
20023932:	f7ff faac 	bl	20022e8e <HAL_QSPI_SET_CLK_INV>
20023936:	4620      	mov	r0, r4
20023938:	f89d 1038 	ldrb.w	r1, [sp, #56]	@ 0x38
2002393c:	f7fe fe67 	bl	2002260e <HAL_FLASH_SET_CLK_rom>
20023940:	f894 3045 	ldrb.w	r3, [r4, #69]	@ 0x45
20023944:	b12b      	cbz	r3, 20023952 <HAL_FLASH_Init+0xfe>
20023946:	2b01      	cmp	r3, #1
20023948:	d110      	bne.n	2002396c <HAL_FLASH_Init+0x118>
2002394a:	2100      	movs	r1, #0
2002394c:	4620      	mov	r0, r4
2002394e:	f7fe ff35 	bl	200227bc <HAL_FLASH_SET_DUAL_MODE>
20023952:	2101      	movs	r1, #1
20023954:	4620      	mov	r0, r4
20023956:	f7fe fec0 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
2002395a:	2700      	movs	r7, #0
2002395c:	e7c8      	b.n	200238f0 <HAL_FLASH_Init+0x9c>
2002395e:	2d00      	cmp	r5, #0
20023960:	d0de      	beq.n	20023920 <HAL_FLASH_Init+0xcc>
20023962:	f06f 437f 	mvn.w	r3, #4278190080	@ 0xff000000
20023966:	429d      	cmp	r5, r3
20023968:	d1c1      	bne.n	200238ee <HAL_FLASH_Init+0x9a>
2002396a:	e7d9      	b.n	20023920 <HAL_FLASH_Init+0xcc>
2002396c:	2b02      	cmp	r3, #2
2002396e:	d1f0      	bne.n	20023952 <HAL_FLASH_Init+0xfe>
20023970:	2101      	movs	r1, #1
20023972:	e7eb      	b.n	2002394c <HAL_FLASH_Init+0xf8>
20023974:	6822      	ldr	r2, [r4, #0]
20023976:	2600      	movs	r6, #0
20023978:	6893      	ldr	r3, [r2, #8]
2002397a:	4631      	mov	r1, r6
2002397c:	f043 7370 	orr.w	r3, r3, #62914560	@ 0x3c00000
20023980:	6093      	str	r3, [r2, #8]
20023982:	2301      	movs	r3, #1
20023984:	4632      	mov	r2, r6
20023986:	4620      	mov	r0, r4
20023988:	e9cd 6303 	strd	r6, r3, [sp, #12]
2002398c:	e9cd 6601 	strd	r6, r6, [sp, #4]
20023990:	4633      	mov	r3, r6
20023992:	9600      	str	r6, [sp, #0]
20023994:	f7fe fe44 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20023998:	4632      	mov	r2, r6
2002399a:	21ff      	movs	r1, #255	@ 0xff
2002399c:	4620      	mov	r0, r4
2002399e:	f7fe fdfa 	bl	20022596 <HAL_FLASH_SET_CMD>
200239a2:	4630      	mov	r0, r6
200239a4:	f7fe f825 	bl	200219f2 <HAL_Delay_us>
200239a8:	20c8      	movs	r0, #200	@ 0xc8
200239aa:	f7fe f822 	bl	200219f2 <HAL_Delay_us>
200239ae:	2f00      	cmp	r7, #0
200239b0:	d0ad      	beq.n	2002390e <HAL_FLASH_Init+0xba>
200239b2:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200239b6:	b2ee      	uxtb	r6, r5
200239b8:	f3c5 2807 	ubfx	r8, r5, #8, #8
200239bc:	6425      	str	r5, [r4, #64]	@ 0x40
200239be:	f3c5 4507 	ubfx	r5, r5, #16, #8
200239c2:	4642      	mov	r2, r8
200239c4:	4629      	mov	r1, r5
200239c6:	4630      	mov	r0, r6
200239c8:	b3ab      	cbz	r3, 20023a36 <HAL_FLASH_Init+0x1e2>
200239ca:	f001 fa85 	bl	20024ed8 <spi_nand_get_cmd_by_id>
200239ce:	60e0      	str	r0, [r4, #12]
200239d0:	bba0      	cbnz	r0, 20023a3c <HAL_FLASH_Init+0x1e8>
200239d2:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
200239d6:	b32b      	cbz	r3, 20023a24 <HAL_FLASH_Init+0x1d0>
200239d8:	2108      	movs	r1, #8
200239da:	4620      	mov	r0, r4
200239dc:	f7ff fb49 	bl	20023072 <nand_read_id>
200239e0:	f3c0 2807 	ubfx	r8, r0, #8, #8
200239e4:	f3c0 4507 	ubfx	r5, r0, #16, #8
200239e8:	b2c6      	uxtb	r6, r0
200239ea:	6420      	str	r0, [r4, #64]	@ 0x40
200239ec:	4642      	mov	r2, r8
200239ee:	4629      	mov	r1, r5
200239f0:	4630      	mov	r0, r6
200239f2:	f001 fa71 	bl	20024ed8 <spi_nand_get_cmd_by_id>
200239f6:	60e0      	str	r0, [r4, #12]
200239f8:	bb00      	cbnz	r0, 20023a3c <HAL_FLASH_Init+0x1e8>
200239fa:	210f      	movs	r1, #15
200239fc:	4620      	mov	r0, r4
200239fe:	f7ff fb38 	bl	20023072 <nand_read_id>
20023a02:	f3c0 2807 	ubfx	r8, r0, #8, #8
20023a06:	f3c0 4507 	ubfx	r5, r0, #16, #8
20023a0a:	b2c6      	uxtb	r6, r0
20023a0c:	6420      	str	r0, [r4, #64]	@ 0x40
20023a0e:	4642      	mov	r2, r8
20023a10:	4629      	mov	r1, r5
20023a12:	4630      	mov	r0, r6
20023a14:	f001 fa60 	bl	20024ed8 <spi_nand_get_cmd_by_id>
20023a18:	60e0      	str	r0, [r4, #12]
20023a1a:	b978      	cbnz	r0, 20023a3c <HAL_FLASH_Init+0x1e8>
20023a1c:	f001 fa74 	bl	20024f08 <spi_nand_get_default_ctable>
20023a20:	60e0      	str	r0, [r4, #12]
20023a22:	b958      	cbnz	r0, 20023a3c <HAL_FLASH_Init+0x1e8>
20023a24:	2100      	movs	r1, #0
20023a26:	4620      	mov	r0, r4
20023a28:	f7fe fe57 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
20023a2c:	2300      	movs	r3, #0
20023a2e:	e9c4 3312 	strd	r3, r3, [r4, #72]	@ 0x48
20023a32:	2001      	movs	r0, #1
20023a34:	e052      	b.n	20023adc <HAL_FLASH_Init+0x288>
20023a36:	f001 f9f1 	bl	20024e1c <spi_flash_get_cmd_by_id>
20023a3a:	e7c8      	b.n	200239ce <HAL_FLASH_Init+0x17a>
20023a3c:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023a40:	4642      	mov	r2, r8
20023a42:	4629      	mov	r1, r5
20023a44:	4630      	mov	r0, r6
20023a46:	2b00      	cmp	r3, #0
20023a48:	d04b      	beq.n	20023ae2 <HAL_FLASH_Init+0x28e>
20023a4a:	f001 fa6b 	bl	20024f24 <spi_nand_get_size_by_id>
20023a4e:	4642      	mov	r2, r8
20023a50:	4629      	mov	r1, r5
20023a52:	4681      	mov	r9, r0
20023a54:	4630      	mov	r0, r6
20023a56:	f001 fa6f 	bl	20024f38 <spi_nand_get_plane_select_flag>
20023a5a:	4642      	mov	r2, r8
20023a5c:	4629      	mov	r1, r5
20023a5e:	f884 002f 	strb.w	r0, [r4, #47]	@ 0x2f
20023a62:	4630      	mov	r0, r6
20023a64:	f001 fa71 	bl	20024f4a <spi_nand_get_big_page_flag>
20023a68:	4642      	mov	r2, r8
20023a6a:	4629      	mov	r1, r5
20023a6c:	f884 002c 	strb.w	r0, [r4, #44]	@ 0x2c
20023a70:	4630      	mov	r0, r6
20023a72:	f001 fa73 	bl	20024f5c <spi_nand_get_ecc_mode>
20023a76:	f894 302c 	ldrb.w	r3, [r4, #44]	@ 0x2c
20023a7a:	4642      	mov	r2, r8
20023a7c:	ea43 1300 	orr.w	r3, r3, r0, lsl #4
20023a80:	4629      	mov	r1, r5
20023a82:	4630      	mov	r0, r6
20023a84:	f884 302c 	strb.w	r3, [r4, #44]	@ 0x2c
20023a88:	f001 fa38 	bl	20024efc <spi_nand_get_ext_cfg_by_id>
20023a8c:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023a8e:	f1b9 0f00 	cmp.w	r9, #0
20023a92:	d003      	beq.n	20023a9c <HAL_FLASH_Init+0x248>
20023a94:	f8c4 904c 	str.w	r9, [r4, #76]	@ 0x4c
20023a98:	f8c4 9014 	str.w	r9, [r4, #20]
20023a9c:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023aa0:	2b00      	cmp	r3, #0
20023aa2:	d17d      	bne.n	20023ba0 <HAL_FLASH_Init+0x34c>
20023aa4:	2f00      	cmp	r7, #0
20023aa6:	d178      	bne.n	20023b9a <HAL_FLASH_Init+0x346>
20023aa8:	4620      	mov	r0, r4
20023aaa:	f7ff f905 	bl	20022cb8 <HAL_FLASH_CLR_PROTECT>
20023aae:	6963      	ldr	r3, [r4, #20]
20023ab0:	f1b3 7f80 	cmp.w	r3, #16777216	@ 0x1000000
20023ab4:	d945      	bls.n	20023b42 <HAL_FLASH_Init+0x2ee>
20023ab6:	463a      	mov	r2, r7
20023ab8:	2121      	movs	r1, #33	@ 0x21
20023aba:	4620      	mov	r0, r4
20023abc:	f7fe ff8b 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023ac0:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023ac4:	bb0b      	cbnz	r3, 20023b0a <HAL_FLASH_Init+0x2b6>
20023ac6:	4639      	mov	r1, r7
20023ac8:	4620      	mov	r0, r4
20023aca:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023ace:	f7ff f8cd 	bl	20022c6c <HAL_FLASH_FADDR_SET_QSPI>
20023ad2:	2107      	movs	r1, #7
20023ad4:	4620      	mov	r0, r4
20023ad6:	f7fe fe5a 	bl	2002278e <HAL_FLASH_SET_ROW_BOUNDARY>
20023ada:	2000      	movs	r0, #0
20023adc:	b007      	add	sp, #28
20023ade:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20023ae2:	f001 f9af 	bl	20024e44 <spi_flash_get_size_by_id>
20023ae6:	4642      	mov	r2, r8
20023ae8:	4629      	mov	r1, r5
20023aea:	4681      	mov	r9, r0
20023aec:	4630      	mov	r0, r6
20023aee:	f001 f9bd 	bl	20024e6c <spi_flash_get_otp_base>
20023af2:	4642      	mov	r2, r8
20023af4:	63a0      	str	r0, [r4, #56]	@ 0x38
20023af6:	4629      	mov	r1, r5
20023af8:	4630      	mov	r0, r6
20023afa:	f001 f967 	bl	20024dcc <spi_nor_get_ext_cfg_by_id>
20023afe:	63e0      	str	r0, [r4, #60]	@ 0x3c
20023b00:	2800      	cmp	r0, #0
20023b02:	d0c4      	beq.n	20023a8e <HAL_FLASH_Init+0x23a>
20023b04:	6803      	ldr	r3, [r0, #0]
20023b06:	63a3      	str	r3, [r4, #56]	@ 0x38
20023b08:	e7c1      	b.n	20023a8e <HAL_FLASH_Init+0x23a>
20023b0a:	2101      	movs	r1, #1
20023b0c:	4620      	mov	r0, r4
20023b0e:	f7ff f8ad 	bl	20022c6c <HAL_FLASH_FADDR_SET_QSPI>
20023b12:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
20023b16:	f1b9 0f01 	cmp.w	r9, #1
20023b1a:	d1da      	bne.n	20023ad2 <HAL_FLASH_Init+0x27e>
20023b1c:	4642      	mov	r2, r8
20023b1e:	4629      	mov	r1, r5
20023b20:	4630      	mov	r0, r6
20023b22:	f001 f999 	bl	20024e58 <spi_flash_is_support_dtr>
20023b26:	b120      	cbz	r0, 20023b32 <HAL_FLASH_Init+0x2de>
20023b28:	4649      	mov	r1, r9
20023b2a:	4620      	mov	r0, r4
20023b2c:	f7ff fe4b 	bl	200237c6 <HAL_NOR_CFG_DTR>
20023b30:	e7cf      	b.n	20023ad2 <HAL_FLASH_Init+0x27e>
20023b32:	463a      	mov	r2, r7
20023b34:	4639      	mov	r1, r7
20023b36:	4620      	mov	r0, r4
20023b38:	f7fe fe7b 	bl	20022832 <HAL_MPI_CFG_DTR>
20023b3c:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023b40:	e7c7      	b.n	20023ad2 <HAL_FLASH_Init+0x27e>
20023b42:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023b46:	b933      	cbnz	r3, 20023b56 <HAL_FLASH_Init+0x302>
20023b48:	4639      	mov	r1, r7
20023b4a:	4620      	mov	r0, r4
20023b4c:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023b50:	f7ff f881 	bl	20022c56 <HAL_FLASH_SET_QUAL_SPI>
20023b54:	e7c1      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023b56:	2101      	movs	r1, #1
20023b58:	4620      	mov	r0, r4
20023b5a:	f7ff f87c 	bl	20022c56 <HAL_FLASH_SET_QUAL_SPI>
20023b5e:	f894 902e 	ldrb.w	r9, [r4, #46]	@ 0x2e
20023b62:	f1b9 0f01 	cmp.w	r9, #1
20023b66:	d112      	bne.n	20023b8e <HAL_FLASH_Init+0x33a>
20023b68:	4642      	mov	r2, r8
20023b6a:	4629      	mov	r1, r5
20023b6c:	4630      	mov	r0, r6
20023b6e:	f001 f973 	bl	20024e58 <spi_flash_is_support_dtr>
20023b72:	b120      	cbz	r0, 20023b7e <HAL_FLASH_Init+0x32a>
20023b74:	4649      	mov	r1, r9
20023b76:	4620      	mov	r0, r4
20023b78:	f7ff fe25 	bl	200237c6 <HAL_NOR_CFG_DTR>
20023b7c:	e7ad      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023b7e:	463a      	mov	r2, r7
20023b80:	4639      	mov	r1, r7
20023b82:	4620      	mov	r0, r4
20023b84:	f7fe fe55 	bl	20022832 <HAL_MPI_CFG_DTR>
20023b88:	f884 702e 	strb.w	r7, [r4, #46]	@ 0x2e
20023b8c:	e7a5      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023b8e:	463a      	mov	r2, r7
20023b90:	4639      	mov	r1, r7
20023b92:	4620      	mov	r0, r4
20023b94:	f7fe fe4d 	bl	20022832 <HAL_MPI_CFG_DTR>
20023b98:	e79f      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023b9a:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20023b9e:	e79c      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023ba0:	2101      	movs	r1, #1
20023ba2:	4620      	mov	r0, r4
20023ba4:	f7fe fcd2 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20023ba8:	68e3      	ldr	r3, [r4, #12]
20023baa:	2102      	movs	r1, #2
20023bac:	791a      	ldrb	r2, [r3, #4]
20023bae:	4620      	mov	r0, r4
20023bb0:	f7fe ff11 	bl	200229d6 <HAL_FLASH_ISSUE_CMD>
20023bb4:	4620      	mov	r0, r4
20023bb6:	f7fe fd1f 	bl	200225f8 <HAL_FLASH_READ32>
20023bba:	4605      	mov	r5, r0
20023bbc:	200a      	movs	r0, #10
20023bbe:	f7fd ff18 	bl	200219f2 <HAL_Delay_us>
20023bc2:	07eb      	lsls	r3, r5, #31
20023bc4:	d4ec      	bmi.n	20023ba0 <HAL_FLASH_Init+0x34c>
20023bc6:	4631      	mov	r1, r6
20023bc8:	4620      	mov	r0, r4
20023bca:	f7ff fb9e 	bl	2002330a <nand_clear_status>
20023bce:	f894 3028 	ldrb.w	r3, [r4, #40]	@ 0x28
20023bd2:	2b02      	cmp	r3, #2
20023bd4:	d181      	bne.n	20023ada <HAL_FLASH_Init+0x286>
20023bd6:	2101      	movs	r1, #1
20023bd8:	4620      	mov	r0, r4
20023bda:	f7ff fb65 	bl	200232a8 <HAL_NAND_EN_QUAL>
20023bde:	e77c      	b.n	20023ada <HAL_FLASH_Init+0x286>
20023be0:	03938700 	.word	0x03938700

20023be4 <HAL_MPI_OPSRAM_CAL_DELAY>:
20023be4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20023be8:	4b21      	ldr	r3, [pc, #132]	@ (20023c70 <HAL_MPI_OPSRAM_CAL_DELAY+0x8c>)
20023bea:	4616      	mov	r6, r2
20023bec:	6982      	ldr	r2, [r0, #24]
20023bee:	4605      	mov	r5, r0
20023bf0:	429a      	cmp	r2, r3
20023bf2:	460f      	mov	r7, r1
20023bf4:	d805      	bhi.n	20023c02 <HAL_MPI_OPSRAM_CAL_DELAY+0x1e>
20023bf6:	231f      	movs	r3, #31
20023bf8:	2000      	movs	r0, #0
20023bfa:	700b      	strb	r3, [r1, #0]
20023bfc:	7033      	strb	r3, [r6, #0]
20023bfe:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023c02:	f04f 4200 	mov.w	r2, #2147483648	@ 0x80000000
20023c06:	6803      	ldr	r3, [r0, #0]
20023c08:	2000      	movs	r0, #0
20023c0a:	65da      	str	r2, [r3, #92]	@ 0x5c
20023c0c:	f7fd fef1 	bl	200219f2 <HAL_Delay_us>
20023c10:	2400      	movs	r4, #0
20023c12:	682b      	ldr	r3, [r5, #0]
20023c14:	0222      	lsls	r2, r4, #8
20023c16:	659a      	str	r2, [r3, #88]	@ 0x58
20023c18:	200a      	movs	r0, #10
20023c1a:	f7fd feea 	bl	200219f2 <HAL_Delay_us>
20023c1e:	682b      	ldr	r3, [r5, #0]
20023c20:	46a0      	mov	r8, r4
20023c22:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023c24:	3401      	adds	r4, #1
20023c26:	03da      	lsls	r2, r3, #15
20023c28:	d502      	bpl.n	20023c30 <HAL_MPI_OPSRAM_CAL_DELAY+0x4c>
20023c2a:	2c80      	cmp	r4, #128	@ 0x80
20023c2c:	d1f1      	bne.n	20023c12 <HAL_MPI_OPSRAM_CAL_DELAY+0x2e>
20023c2e:	46a0      	mov	r8, r4
20023c30:	f108 0401 	add.w	r4, r8, #1
20023c34:	2c7f      	cmp	r4, #127	@ 0x7f
20023c36:	d905      	bls.n	20023c44 <HAL_MPI_OPSRAM_CAL_DELAY+0x60>
20023c38:	2001      	movs	r0, #1
20023c3a:	f04f 4280 	mov.w	r2, #1073741824	@ 0x40000000
20023c3e:	682b      	ldr	r3, [r5, #0]
20023c40:	65da      	str	r2, [r3, #92]	@ 0x5c
20023c42:	e7dc      	b.n	20023bfe <HAL_MPI_OPSRAM_CAL_DELAY+0x1a>
20023c44:	682b      	ldr	r3, [r5, #0]
20023c46:	0222      	lsls	r2, r4, #8
20023c48:	659a      	str	r2, [r3, #88]	@ 0x58
20023c4a:	200a      	movs	r0, #10
20023c4c:	f7fd fed1 	bl	200219f2 <HAL_Delay_us>
20023c50:	682b      	ldr	r3, [r5, #0]
20023c52:	6e1b      	ldr	r3, [r3, #96]	@ 0x60
20023c54:	03db      	lsls	r3, r3, #15
20023c56:	d401      	bmi.n	20023c5c <HAL_MPI_OPSRAM_CAL_DELAY+0x78>
20023c58:	3401      	adds	r4, #1
20023c5a:	e7eb      	b.n	20023c34 <HAL_MPI_OPSRAM_CAL_DELAY+0x50>
20023c5c:	eba4 0408 	sub.w	r4, r4, r8
20023c60:	f3c4 0447 	ubfx	r4, r4, #1, #8
20023c64:	1f63      	subs	r3, r4, #5
20023c66:	703b      	strb	r3, [r7, #0]
20023c68:	2000      	movs	r0, #0
20023c6a:	7034      	strb	r4, [r6, #0]
20023c6c:	e7e5      	b.n	20023c3a <HAL_MPI_OPSRAM_CAL_DELAY+0x56>
20023c6e:	bf00      	nop
20023c70:	016e3600 	.word	0x016e3600

20023c74 <HAL_SPI_PSRAM_Init>:
20023c74:	b537      	push	{r0, r1, r2, r4, r5, lr}
20023c76:	4614      	mov	r4, r2
20023c78:	4605      	mov	r5, r0
20023c7a:	2800      	cmp	r0, #0
20023c7c:	d043      	beq.n	20023d06 <HAL_SPI_PSRAM_Init+0x92>
20023c7e:	2900      	cmp	r1, #0
20023c80:	d041      	beq.n	20023d06 <HAL_SPI_PSRAM_Init+0x92>
20023c82:	f7fe fbe9 	bl	20022458 <HAL_QSPI_Init>
20023c86:	4628      	mov	r0, r5
20023c88:	b2e1      	uxtb	r1, r4
20023c8a:	f7fe fcc0 	bl	2002260e <HAL_FLASH_SET_CLK_rom>
20023c8e:	4628      	mov	r0, r5
20023c90:	f7ff fd7e 	bl	20023790 <HAL_QSPI_GET_CLK>
20023c94:	4b1d      	ldr	r3, [pc, #116]	@ (20023d0c <HAL_SPI_PSRAM_Init+0x98>)
20023c96:	4298      	cmp	r0, r3
20023c98:	d930      	bls.n	20023cfc <HAL_SPI_PSRAM_Init+0x88>
20023c9a:	4b1d      	ldr	r3, [pc, #116]	@ (20023d10 <HAL_SPI_PSRAM_Init+0x9c>)
20023c9c:	4298      	cmp	r0, r3
20023c9e:	d92f      	bls.n	20023d00 <HAL_SPI_PSRAM_Init+0x8c>
20023ca0:	4b1c      	ldr	r3, [pc, #112]	@ (20023d14 <HAL_SPI_PSRAM_Init+0xa0>)
20023ca2:	4298      	cmp	r0, r3
20023ca4:	d922      	bls.n	20023cec <HAL_SPI_PSRAM_Init+0x78>
20023ca6:	f240 34b6 	movw	r4, #950	@ 0x3b6
20023caa:	f240 4374 	movw	r3, #1140	@ 0x474
20023cae:	4a1a      	ldr	r2, [pc, #104]	@ (20023d18 <HAL_SPI_PSRAM_Init+0xa4>)
20023cb0:	4290      	cmp	r0, r2
20023cb2:	bf88      	it	hi
20023cb4:	461c      	movhi	r4, r3
20023cb6:	2200      	movs	r2, #0
20023cb8:	2101      	movs	r1, #1
20023cba:	4628      	mov	r0, r5
20023cbc:	f7ff f8e7 	bl	20022e8e <HAL_QSPI_SET_CLK_INV>
20023cc0:	2100      	movs	r1, #0
20023cc2:	4622      	mov	r2, r4
20023cc4:	2302      	movs	r3, #2
20023cc6:	4628      	mov	r0, r5
20023cc8:	9100      	str	r1, [sp, #0]
20023cca:	f7fe fd4b 	bl	20022764 <HAL_FLASH_SET_CS_TIME>
20023cce:	4604      	mov	r4, r0
20023cd0:	b948      	cbnz	r0, 20023ce6 <HAL_SPI_PSRAM_Init+0x72>
20023cd2:	2106      	movs	r1, #6
20023cd4:	4628      	mov	r0, r5
20023cd6:	f7fe fd5a 	bl	2002278e <HAL_FLASH_SET_ROW_BOUNDARY>
20023cda:	4604      	mov	r4, r0
20023cdc:	b918      	cbnz	r0, 20023ce6 <HAL_SPI_PSRAM_Init+0x72>
20023cde:	2101      	movs	r1, #1
20023ce0:	4628      	mov	r0, r5
20023ce2:	f7fe fcfa 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
20023ce6:	4620      	mov	r0, r4
20023ce8:	b003      	add	sp, #12
20023cea:	bd30      	pop	{r4, r5, pc}
20023cec:	4b0b      	ldr	r3, [pc, #44]	@ (20023d1c <HAL_SPI_PSRAM_Init+0xa8>)
20023cee:	f44f 743e 	mov.w	r4, #760	@ 0x2f8
20023cf2:	4298      	cmp	r0, r3
20023cf4:	d8df      	bhi.n	20023cb6 <HAL_SPI_PSRAM_Init+0x42>
20023cf6:	2200      	movs	r2, #0
20023cf8:	4611      	mov	r1, r2
20023cfa:	e7de      	b.n	20023cba <HAL_SPI_PSRAM_Init+0x46>
20023cfc:	24b4      	movs	r4, #180	@ 0xb4
20023cfe:	e7fa      	b.n	20023cf6 <HAL_SPI_PSRAM_Init+0x82>
20023d00:	f44f 74be 	mov.w	r4, #380	@ 0x17c
20023d04:	e7f7      	b.n	20023cf6 <HAL_SPI_PSRAM_Init+0x82>
20023d06:	2401      	movs	r4, #1
20023d08:	e7ed      	b.n	20023ce6 <HAL_SPI_PSRAM_Init+0x72>
20023d0a:	bf00      	nop
20023d0c:	016e3600 	.word	0x016e3600
20023d10:	02dc6c00 	.word	0x02dc6c00
20023d14:	05b8d800 	.word	0x05b8d800
20023d18:	07270e00 	.word	0x07270e00
20023d1c:	03938700 	.word	0x03938700

20023d20 <HAL_MPI_MR_WRITE>:
20023d20:	b5f0      	push	{r4, r5, r6, r7, lr}
20023d22:	460e      	mov	r6, r1
20023d24:	4617      	mov	r7, r2
20023d26:	4605      	mov	r5, r0
20023d28:	b087      	sub	sp, #28
20023d2a:	b1d8      	cbz	r0, 20023d64 <HAL_MPI_MR_WRITE+0x44>
20023d2c:	2207      	movs	r2, #7
20023d2e:	2400      	movs	r4, #0
20023d30:	2303      	movs	r3, #3
20023d32:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023d36:	2101      	movs	r1, #1
20023d38:	e9cd 4301 	strd	r4, r3, [sp, #4]
20023d3c:	9400      	str	r4, [sp, #0]
20023d3e:	4623      	mov	r3, r4
20023d40:	f7fe fc6e 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20023d44:	2102      	movs	r1, #2
20023d46:	4628      	mov	r0, r5
20023d48:	f7fe fc00 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20023d4c:	4639      	mov	r1, r7
20023d4e:	4628      	mov	r0, r5
20023d50:	f7fe fbf5 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20023d54:	4632      	mov	r2, r6
20023d56:	21c0      	movs	r1, #192	@ 0xc0
20023d58:	4628      	mov	r0, r5
20023d5a:	f7fe fc1c 	bl	20022596 <HAL_FLASH_SET_CMD>
20023d5e:	4620      	mov	r0, r4
20023d60:	b007      	add	sp, #28
20023d62:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023d64:	2001      	movs	r0, #1
20023d66:	e7fb      	b.n	20023d60 <HAL_MPI_MR_WRITE+0x40>

20023d68 <HAL_MPI_SET_FIXLAT>:
20023d68:	e92d 41ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, lr}
20023d6c:	460c      	mov	r4, r1
20023d6e:	4616      	mov	r6, r2
20023d70:	461f      	mov	r7, r3
20023d72:	4605      	mov	r5, r0
20023d74:	2800      	cmp	r0, #0
20023d76:	d040      	beq.n	20023dfa <HAL_MPI_SET_FIXLAT+0x92>
20023d78:	466b      	mov	r3, sp
20023d7a:	4a21      	ldr	r2, [pc, #132]	@ (20023e00 <HAL_MPI_SET_FIXLAT+0x98>)
20023d7c:	6810      	ldr	r0, [r2, #0]
20023d7e:	6851      	ldr	r1, [r2, #4]
20023d80:	c303      	stmia	r3!, {r0, r1}
20023d82:	6890      	ldr	r0, [r2, #8]
20023d84:	68d1      	ldr	r1, [r2, #12]
20023d86:	c303      	stmia	r3!, {r0, r1}
20023d88:	4628      	mov	r0, r5
20023d8a:	b2e1      	uxtb	r1, r4
20023d8c:	f7fe fd32 	bl	200227f4 <HAL_MPI_EN_FIXLAT>
20023d90:	f107 0310 	add.w	r3, r7, #16
20023d94:	446b      	add	r3, sp
20023d96:	f813 8c08 	ldrb.w	r8, [r3, #-8]
20023d9a:	ea4f 1848 	mov.w	r8, r8, lsl #5
20023d9e:	fa5f f888 	uxtb.w	r8, r8
20023da2:	b30c      	cbz	r4, 20023de8 <HAL_MPI_SET_FIXLAT+0x80>
20023da4:	ab04      	add	r3, sp, #16
20023da6:	eb03 0356 	add.w	r3, r3, r6, lsr #1
20023daa:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023dae:	00a4      	lsls	r4, r4, #2
20023db0:	f044 0421 	orr.w	r4, r4, #33	@ 0x21
20023db4:	b264      	sxtb	r4, r4
20023db6:	f004 02fd 	and.w	r2, r4, #253	@ 0xfd
20023dba:	2100      	movs	r1, #0
20023dbc:	4628      	mov	r0, r5
20023dbe:	f7ff ffaf 	bl	20023d20 <HAL_MPI_MR_WRITE>
20023dc2:	1e71      	subs	r1, r6, #1
20023dc4:	4628      	mov	r0, r5
20023dc6:	b249      	sxtb	r1, r1
20023dc8:	f7fe fd3e 	bl	20022848 <HAL_MPI_MODIFY_RCMD_DELAY>
20023dcc:	4642      	mov	r2, r8
20023dce:	2104      	movs	r1, #4
20023dd0:	4628      	mov	r0, r5
20023dd2:	f7ff ffa5 	bl	20023d20 <HAL_MPI_MR_WRITE>
20023dd6:	1e79      	subs	r1, r7, #1
20023dd8:	4628      	mov	r0, r5
20023dda:	b249      	sxtb	r1, r1
20023ddc:	f7fe fd3d 	bl	2002285a <HAL_MPI_MODIFY_WCMD_DELAY>
20023de0:	2000      	movs	r0, #0
20023de2:	b004      	add	sp, #16
20023de4:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20023de8:	f106 0310 	add.w	r3, r6, #16
20023dec:	446b      	add	r3, sp
20023dee:	f813 4c10 	ldrb.w	r4, [r3, #-16]
20023df2:	00a4      	lsls	r4, r4, #2
20023df4:	f044 0401 	orr.w	r4, r4, #1
20023df8:	e7dc      	b.n	20023db4 <HAL_MPI_SET_FIXLAT+0x4c>
20023dfa:	2001      	movs	r0, #1
20023dfc:	e7f1      	b.n	20023de2 <HAL_MPI_SET_FIXLAT+0x7a>
20023dfe:	bf00      	nop
20023e00:	200275fc 	.word	0x200275fc

20023e04 <HAL_LEGACY_MR_WRITE>:
20023e04:	b5f0      	push	{r4, r5, r6, r7, lr}
20023e06:	460e      	mov	r6, r1
20023e08:	4617      	mov	r7, r2
20023e0a:	4604      	mov	r4, r0
20023e0c:	b087      	sub	sp, #28
20023e0e:	b1e0      	cbz	r0, 20023e4a <HAL_LEGACY_MR_WRITE+0x46>
20023e10:	2207      	movs	r2, #7
20023e12:	2500      	movs	r5, #0
20023e14:	2302      	movs	r3, #2
20023e16:	e9cd 2203 	strd	r2, r2, [sp, #12]
20023e1a:	e9cd 5301 	strd	r5, r3, [sp, #4]
20023e1e:	9500      	str	r5, [sp, #0]
20023e20:	f990 302e 	ldrsb.w	r3, [r0, #46]	@ 0x2e
20023e24:	2101      	movs	r1, #1
20023e26:	f7fe fbfb 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20023e2a:	2104      	movs	r1, #4
20023e2c:	4620      	mov	r0, r4
20023e2e:	f7fe fb8d 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
20023e32:	4639      	mov	r1, r7
20023e34:	4620      	mov	r0, r4
20023e36:	f7fe fb82 	bl	2002253e <HAL_FLASH_WRITE_WORD>
20023e3a:	4632      	mov	r2, r6
20023e3c:	21c0      	movs	r1, #192	@ 0xc0
20023e3e:	4620      	mov	r0, r4
20023e40:	f7fe fba9 	bl	20022596 <HAL_FLASH_SET_CMD>
20023e44:	4628      	mov	r0, r5
20023e46:	b007      	add	sp, #28
20023e48:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023e4a:	2001      	movs	r0, #1
20023e4c:	e7fb      	b.n	20023e46 <HAL_LEGACY_MR_WRITE+0x42>

20023e4e <HAL_LEGACY_CFG_READ>:
20023e4e:	b530      	push	{r4, r5, lr}
20023e50:	4605      	mov	r5, r0
20023e52:	b085      	sub	sp, #20
20023e54:	b1a0      	cbz	r0, 20023e80 <HAL_LEGACY_CFG_READ+0x32>
20023e56:	2400      	movs	r4, #0
20023e58:	2107      	movs	r1, #7
20023e5a:	2302      	movs	r3, #2
20023e5c:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20023e60:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023e64:	0052      	lsls	r2, r2, #1
20023e66:	e9cd 4300 	strd	r4, r3, [sp]
20023e6a:	b252      	sxtb	r2, r2
20023e6c:	4623      	mov	r3, r4
20023e6e:	f7fe fb20 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20023e72:	4621      	mov	r1, r4
20023e74:	4628      	mov	r0, r5
20023e76:	f7fe fb11 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
20023e7a:	4620      	mov	r0, r4
20023e7c:	b005      	add	sp, #20
20023e7e:	bd30      	pop	{r4, r5, pc}
20023e80:	2001      	movs	r0, #1
20023e82:	e7fb      	b.n	20023e7c <HAL_LEGACY_CFG_READ+0x2e>

20023e84 <HAL_LEGACY_CFG_WRITE>:
20023e84:	b530      	push	{r4, r5, lr}
20023e86:	4605      	mov	r5, r0
20023e88:	b085      	sub	sp, #20
20023e8a:	b190      	cbz	r0, 20023eb2 <HAL_LEGACY_CFG_WRITE+0x2e>
20023e8c:	2107      	movs	r1, #7
20023e8e:	2400      	movs	r4, #0
20023e90:	2302      	movs	r3, #2
20023e92:	e9cd 1102 	strd	r1, r1, [sp, #8]
20023e96:	e9cd 4300 	strd	r4, r3, [sp]
20023e9a:	4623      	mov	r3, r4
20023e9c:	f990 202e 	ldrsb.w	r2, [r0, #46]	@ 0x2e
20023ea0:	f7fe fb30 	bl	20022504 <HAL_FLASH_CFG_AHB_WCMD>
20023ea4:	2180      	movs	r1, #128	@ 0x80
20023ea6:	4628      	mov	r0, r5
20023ea8:	f7fe fb20 	bl	200224ec <HAL_FLASH_SET_AHB_WCMD>
20023eac:	4620      	mov	r0, r4
20023eae:	b005      	add	sp, #20
20023eb0:	bd30      	pop	{r4, r5, pc}
20023eb2:	2001      	movs	r0, #1
20023eb4:	e7fb      	b.n	20023eae <HAL_LEGACY_CFG_WRITE+0x2a>

20023eb6 <HAL_PSRAM_RESET>:
20023eb6:	b5f0      	push	{r4, r5, r6, r7, lr}
20023eb8:	4604      	mov	r4, r0
20023eba:	b087      	sub	sp, #28
20023ebc:	2800      	cmp	r0, #0
20023ebe:	d03b      	beq.n	20023f38 <HAL_PSRAM_RESET+0x82>
20023ec0:	f890 302b 	ldrb.w	r3, [r0, #43]	@ 0x2b
20023ec4:	2b05      	cmp	r3, #5
20023ec6:	d034      	beq.n	20023f32 <HAL_PSRAM_RESET+0x7c>
20023ec8:	3b03      	subs	r3, #3
20023eca:	2b01      	cmp	r3, #1
20023ecc:	d82e      	bhi.n	20023f2c <HAL_PSRAM_RESET+0x76>
20023ece:	2601      	movs	r6, #1
20023ed0:	2703      	movs	r7, #3
20023ed2:	2300      	movs	r3, #0
20023ed4:	2507      	movs	r5, #7
20023ed6:	b276      	sxtb	r6, r6
20023ed8:	b27f      	sxtb	r7, r7
20023eda:	461a      	mov	r2, r3
20023edc:	2101      	movs	r1, #1
20023ede:	4620      	mov	r0, r4
20023ee0:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023ee4:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023ee8:	9600      	str	r6, [sp, #0]
20023eea:	f7fe fb99 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20023eee:	2200      	movs	r2, #0
20023ef0:	21ff      	movs	r1, #255	@ 0xff
20023ef2:	4620      	mov	r0, r4
20023ef4:	f7fe fb4f 	bl	20022596 <HAL_FLASH_SET_CMD>
20023ef8:	f894 302b 	ldrb.w	r3, [r4, #43]	@ 0x2b
20023efc:	2b05      	cmp	r3, #5
20023efe:	d10f      	bne.n	20023f20 <HAL_PSRAM_RESET+0x6a>
20023f00:	2300      	movs	r3, #0
20023f02:	2101      	movs	r1, #1
20023f04:	461a      	mov	r2, r3
20023f06:	4620      	mov	r0, r4
20023f08:	e9cd 5503 	strd	r5, r5, [sp, #12]
20023f0c:	e9cd 5701 	strd	r5, r7, [sp, #4]
20023f10:	9600      	str	r6, [sp, #0]
20023f12:	f7fe fb85 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
20023f16:	2200      	movs	r2, #0
20023f18:	21ff      	movs	r1, #255	@ 0xff
20023f1a:	4620      	mov	r0, r4
20023f1c:	f7fe fb3b 	bl	20022596 <HAL_FLASH_SET_CMD>
20023f20:	2000      	movs	r0, #0
20023f22:	f7fd fd66 	bl	200219f2 <HAL_Delay_us>
20023f26:	2003      	movs	r0, #3
20023f28:	f7fd fd63 	bl	200219f2 <HAL_Delay_us>
20023f2c:	2000      	movs	r0, #0
20023f2e:	b007      	add	sp, #28
20023f30:	bdf0      	pop	{r4, r5, r6, r7, pc}
20023f32:	2603      	movs	r6, #3
20023f34:	2702      	movs	r7, #2
20023f36:	e7cc      	b.n	20023ed2 <HAL_PSRAM_RESET+0x1c>
20023f38:	2001      	movs	r0, #1
20023f3a:	e7f8      	b.n	20023f2e <HAL_PSRAM_RESET+0x78>

20023f3c <HAL_OPI_PSRAM_Init>:
20023f3c:	b530      	push	{r4, r5, lr}
20023f3e:	4604      	mov	r4, r0
20023f40:	b085      	sub	sp, #20
20023f42:	2800      	cmp	r0, #0
20023f44:	d076      	beq.n	20024034 <HAL_OPI_PSRAM_Init+0xf8>
20023f46:	2900      	cmp	r1, #0
20023f48:	d074      	beq.n	20024034 <HAL_OPI_PSRAM_Init+0xf8>
20023f4a:	f7fe fa85 	bl	20022458 <HAL_QSPI_Init>
20023f4e:	6823      	ldr	r3, [r4, #0]
20023f50:	2101      	movs	r1, #1
20023f52:	4620      	mov	r0, r4
20023f54:	681d      	ldr	r5, [r3, #0]
20023f56:	f7fe fbce 	bl	200226f6 <HAL_FLASH_ENABLE_OPI>
20023f5a:	2101      	movs	r1, #1
20023f5c:	4620      	mov	r0, r4
20023f5e:	f7fe fb56 	bl	2002260e <HAL_FLASH_SET_CLK_rom>
20023f62:	4620      	mov	r0, r4
20023f64:	f7ff fc14 	bl	20023790 <HAL_QSPI_GET_CLK>
20023f68:	0840      	lsrs	r0, r0, #1
20023f6a:	61a0      	str	r0, [r4, #24]
20023f6c:	f10d 020e 	add.w	r2, sp, #14
20023f70:	4620      	mov	r0, r4
20023f72:	f10d 010f 	add.w	r1, sp, #15
20023f76:	f7ff fe35 	bl	20023be4 <HAL_MPI_OPSRAM_CAL_DELAY>
20023f7a:	4603      	mov	r3, r0
20023f7c:	b100      	cbz	r0, 20023f80 <HAL_OPI_PSRAM_Init+0x44>
20023f7e:	e7fe      	b.n	20023f7e <HAL_OPI_PSRAM_Init+0x42>
20023f80:	69a2      	ldr	r2, [r4, #24]
20023f82:	492d      	ldr	r1, [pc, #180]	@ (20024038 <HAL_OPI_PSRAM_Init+0xfc>)
20023f84:	428a      	cmp	r2, r1
20023f86:	d93b      	bls.n	20024000 <HAL_OPI_PSRAM_Init+0xc4>
20023f88:	4b2c      	ldr	r3, [pc, #176]	@ (2002403c <HAL_OPI_PSRAM_Init+0x100>)
20023f8a:	429a      	cmp	r2, r3
20023f8c:	d93c      	bls.n	20024008 <HAL_OPI_PSRAM_Init+0xcc>
20023f8e:	440b      	add	r3, r1
20023f90:	429a      	cmp	r2, r3
20023f92:	d93f      	bls.n	20024014 <HAL_OPI_PSRAM_Init+0xd8>
20023f94:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
20023f98:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
20023f9c:	429a      	cmp	r2, r3
20023f9e:	d93f      	bls.n	20024020 <HAL_OPI_PSRAM_Init+0xe4>
20023fa0:	2107      	movs	r1, #7
20023fa2:	2014      	movs	r0, #20
20023fa4:	2308      	movs	r3, #8
20023fa6:	f240 5232 	movw	r2, #1330	@ 0x532
20023faa:	f884 102d 	strb.w	r1, [r4, #45]	@ 0x2d
20023fae:	f884 102e 	strb.w	r1, [r4, #46]	@ 0x2e
20023fb2:	2106      	movs	r1, #6
20023fb4:	9000      	str	r0, [sp, #0]
20023fb6:	4620      	mov	r0, r4
20023fb8:	f7fe fbd4 	bl	20022764 <HAL_FLASH_SET_CS_TIME>
20023fbc:	2107      	movs	r1, #7
20023fbe:	4620      	mov	r0, r4
20023fc0:	f7fe fbe5 	bl	2002278e <HAL_FLASH_SET_ROW_BOUNDARY>
20023fc4:	2101      	movs	r1, #1
20023fc6:	4620      	mov	r0, r4
20023fc8:	f7fe fc16 	bl	200227f8 <HAL_MPI_ENABLE_DQS>
20023fcc:	f89d 100e 	ldrb.w	r1, [sp, #14]
20023fd0:	4620      	mov	r0, r4
20023fd2:	f7fe fc15 	bl	20022800 <HAL_MPI_SET_DQS_DELAY>
20023fd6:	2200      	movs	r2, #0
20023fd8:	f89d 100f 	ldrb.w	r1, [sp, #15]
20023fdc:	4620      	mov	r0, r4
20023fde:	f7fe fc1a 	bl	20022816 <HAL_MPI_SET_SCK>
20023fe2:	2101      	movs	r1, #1
20023fe4:	4620      	mov	r0, r4
20023fe6:	f7fe fb78 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
20023fea:	07eb      	lsls	r3, r5, #31
20023fec:	d405      	bmi.n	20023ffa <HAL_OPI_PSRAM_Init+0xbe>
20023fee:	4b14      	ldr	r3, [pc, #80]	@ (20024040 <HAL_OPI_PSRAM_Init+0x104>)
20023ff0:	681b      	ldr	r3, [r3, #0]
20023ff2:	f003 0303 	and.w	r3, r3, #3
20023ff6:	2b03      	cmp	r3, #3
20023ff8:	d118      	bne.n	2002402c <HAL_OPI_PSRAM_Init+0xf0>
20023ffa:	2000      	movs	r0, #0
20023ffc:	b005      	add	sp, #20
20023ffe:	bd30      	pop	{r4, r5, pc}
20024000:	2103      	movs	r1, #3
20024002:	22b4      	movs	r2, #180	@ 0xb4
20024004:	4608      	mov	r0, r1
20024006:	e7d0      	b.n	20023faa <HAL_OPI_PSRAM_Init+0x6e>
20024008:	2105      	movs	r1, #5
2002400a:	200e      	movs	r0, #14
2002400c:	2303      	movs	r3, #3
2002400e:	f240 32b6 	movw	r2, #950	@ 0x3b6
20024012:	e7ca      	b.n	20023faa <HAL_OPI_PSRAM_Init+0x6e>
20024014:	2106      	movs	r1, #6
20024016:	2011      	movs	r0, #17
20024018:	2305      	movs	r3, #5
2002401a:	f240 4274 	movw	r2, #1140	@ 0x474
2002401e:	e7c4      	b.n	20023faa <HAL_OPI_PSRAM_Init+0x6e>
20024020:	2106      	movs	r1, #6
20024022:	2013      	movs	r0, #19
20024024:	460b      	mov	r3, r1
20024026:	f240 42d3 	movw	r2, #1235	@ 0x4d3
2002402a:	e7be      	b.n	20023faa <HAL_OPI_PSRAM_Init+0x6e>
2002402c:	4620      	mov	r0, r4
2002402e:	f7ff ff42 	bl	20023eb6 <HAL_PSRAM_RESET>
20024032:	e7e2      	b.n	20023ffa <HAL_OPI_PSRAM_Init+0xbe>
20024034:	2001      	movs	r0, #1
20024036:	e7e1      	b.n	20023ffc <HAL_OPI_PSRAM_Init+0xc0>
20024038:	016e3600 	.word	0x016e3600
2002403c:	07270e00 	.word	0x07270e00
20024040:	500c0000 	.word	0x500c0000

20024044 <HAL_LEGACY_PSRAM_Init>:
20024044:	b5f0      	push	{r4, r5, r6, r7, lr}
20024046:	4604      	mov	r4, r0
20024048:	b085      	sub	sp, #20
2002404a:	2800      	cmp	r0, #0
2002404c:	f000 809e 	beq.w	2002418c <HAL_LEGACY_PSRAM_Init+0x148>
20024050:	2900      	cmp	r1, #0
20024052:	f000 809b 	beq.w	2002418c <HAL_LEGACY_PSRAM_Init+0x148>
20024056:	f7fe f9ff 	bl	20022458 <HAL_QSPI_Init>
2002405a:	6823      	ldr	r3, [r4, #0]
2002405c:	2101      	movs	r1, #1
2002405e:	4620      	mov	r0, r4
20024060:	681e      	ldr	r6, [r3, #0]
20024062:	f7fe fb48 	bl	200226f6 <HAL_FLASH_ENABLE_OPI>
20024066:	2101      	movs	r1, #1
20024068:	4620      	mov	r0, r4
2002406a:	f7fe fad0 	bl	2002260e <HAL_FLASH_SET_CLK_rom>
2002406e:	4620      	mov	r0, r4
20024070:	f7ff fb8e 	bl	20023790 <HAL_QSPI_GET_CLK>
20024074:	0845      	lsrs	r5, r0, #1
20024076:	61a5      	str	r5, [r4, #24]
20024078:	4620      	mov	r0, r4
2002407a:	f10d 020e 	add.w	r2, sp, #14
2002407e:	f10d 010f 	add.w	r1, sp, #15
20024082:	f7ff fdaf 	bl	20023be4 <HAL_MPI_OPSRAM_CAL_DELAY>
20024086:	4603      	mov	r3, r0
20024088:	b100      	cbz	r0, 2002408c <HAL_LEGACY_PSRAM_Init+0x48>
2002408a:	e7fe      	b.n	2002408a <HAL_LEGACY_PSRAM_Init+0x46>
2002408c:	4a40      	ldr	r2, [pc, #256]	@ (20024190 <HAL_LEGACY_PSRAM_Init+0x14c>)
2002408e:	4f41      	ldr	r7, [pc, #260]	@ (20024194 <HAL_LEGACY_PSRAM_Init+0x150>)
20024090:	4295      	cmp	r5, r2
20024092:	d95a      	bls.n	2002414a <HAL_LEGACY_PSRAM_Init+0x106>
20024094:	42bd      	cmp	r5, r7
20024096:	d95b      	bls.n	20024150 <HAL_LEGACY_PSRAM_Init+0x10c>
20024098:	4b3f      	ldr	r3, [pc, #252]	@ (20024198 <HAL_LEGACY_PSRAM_Init+0x154>)
2002409a:	429d      	cmp	r5, r3
2002409c:	d95d      	bls.n	2002415a <HAL_LEGACY_PSRAM_Init+0x116>
2002409e:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
200240a2:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
200240a6:	429d      	cmp	r5, r3
200240a8:	d95c      	bls.n	20024164 <HAL_LEGACY_PSRAM_Init+0x120>
200240aa:	f503 0337 	add.w	r3, r3, #11993088	@ 0xb70000
200240ae:	f503 53d8 	add.w	r3, r3, #6912	@ 0x1b00
200240b2:	429d      	cmp	r5, r3
200240b4:	d85b      	bhi.n	2002416e <HAL_LEGACY_PSRAM_Init+0x12a>
200240b6:	2114      	movs	r1, #20
200240b8:	2308      	movs	r3, #8
200240ba:	f240 5232 	movw	r2, #1330	@ 0x532
200240be:	9100      	str	r1, [sp, #0]
200240c0:	4620      	mov	r0, r4
200240c2:	2106      	movs	r1, #6
200240c4:	f7fe fb4e 	bl	20022764 <HAL_FLASH_SET_CS_TIME>
200240c8:	2107      	movs	r1, #7
200240ca:	4620      	mov	r0, r4
200240cc:	f7fe fb5f 	bl	2002278e <HAL_FLASH_SET_ROW_BOUNDARY>
200240d0:	2101      	movs	r1, #1
200240d2:	4620      	mov	r0, r4
200240d4:	f7fe fb90 	bl	200227f8 <HAL_MPI_ENABLE_DQS>
200240d8:	f89d 100e 	ldrb.w	r1, [sp, #14]
200240dc:	4620      	mov	r0, r4
200240de:	f7fe fb8f 	bl	20022800 <HAL_MPI_SET_DQS_DELAY>
200240e2:	2200      	movs	r2, #0
200240e4:	f89d 100f 	ldrb.w	r1, [sp, #15]
200240e8:	4620      	mov	r0, r4
200240ea:	f7fe fb94 	bl	20022816 <HAL_MPI_SET_SCK>
200240ee:	2101      	movs	r1, #1
200240f0:	4620      	mov	r0, r4
200240f2:	f7fe fb56 	bl	200227a2 <HAL_FLASH_SET_LEGACY>
200240f6:	2101      	movs	r1, #1
200240f8:	4620      	mov	r0, r4
200240fa:	f7fe faee 	bl	200226da <HAL_FLASH_ENABLE_QSPI>
200240fe:	07f3      	lsls	r3, r6, #31
20024100:	d405      	bmi.n	2002410e <HAL_LEGACY_PSRAM_Init+0xca>
20024102:	f894 302f 	ldrb.w	r3, [r4, #47]	@ 0x2f
20024106:	b913      	cbnz	r3, 2002410e <HAL_LEGACY_PSRAM_Init+0xca>
20024108:	4620      	mov	r0, r4
2002410a:	f7ff fed4 	bl	20023eb6 <HAL_PSRAM_RESET>
2002410e:	42bd      	cmp	r5, r7
20024110:	d932      	bls.n	20024178 <HAL_LEGACY_PSRAM_Init+0x134>
20024112:	4b22      	ldr	r3, [pc, #136]	@ (2002419c <HAL_LEGACY_PSRAM_Init+0x158>)
20024114:	429d      	cmp	r5, r3
20024116:	d934      	bls.n	20024182 <HAL_LEGACY_PSRAM_Init+0x13e>
20024118:	2206      	movs	r2, #6
2002411a:	2302      	movs	r3, #2
2002411c:	2588      	movs	r5, #136	@ 0x88
2002411e:	263b      	movs	r6, #59	@ 0x3b
20024120:	f884 302e 	strb.w	r3, [r4, #46]	@ 0x2e
20024124:	2101      	movs	r1, #1
20024126:	f884 202d 	strb.w	r2, [r4, #45]	@ 0x2d
2002412a:	4620      	mov	r0, r4
2002412c:	f7fe fb62 	bl	200227f4 <HAL_MPI_EN_FIXLAT>
20024130:	4632      	mov	r2, r6
20024132:	2100      	movs	r1, #0
20024134:	4620      	mov	r0, r4
20024136:	f7ff fe65 	bl	20023e04 <HAL_LEGACY_MR_WRITE>
2002413a:	462a      	mov	r2, r5
2002413c:	2104      	movs	r1, #4
2002413e:	4620      	mov	r0, r4
20024140:	f7ff fe60 	bl	20023e04 <HAL_LEGACY_MR_WRITE>
20024144:	2000      	movs	r0, #0
20024146:	b005      	add	sp, #20
20024148:	bdf0      	pop	{r4, r5, r6, r7, pc}
2002414a:	2103      	movs	r1, #3
2002414c:	22b4      	movs	r2, #180	@ 0xb4
2002414e:	e7b6      	b.n	200240be <HAL_LEGACY_PSRAM_Init+0x7a>
20024150:	210e      	movs	r1, #14
20024152:	2303      	movs	r3, #3
20024154:	f240 32b6 	movw	r2, #950	@ 0x3b6
20024158:	e7b1      	b.n	200240be <HAL_LEGACY_PSRAM_Init+0x7a>
2002415a:	2111      	movs	r1, #17
2002415c:	2305      	movs	r3, #5
2002415e:	f240 4274 	movw	r2, #1140	@ 0x474
20024162:	e7ac      	b.n	200240be <HAL_LEGACY_PSRAM_Init+0x7a>
20024164:	2113      	movs	r1, #19
20024166:	2306      	movs	r3, #6
20024168:	f240 42d3 	movw	r2, #1235	@ 0x4d3
2002416c:	e7a7      	b.n	200240be <HAL_LEGACY_PSRAM_Init+0x7a>
2002416e:	2117      	movs	r1, #23
20024170:	2309      	movs	r3, #9
20024172:	f44f 62be 	mov.w	r2, #1520	@ 0x5f0
20024176:	e7a2      	b.n	200240be <HAL_LEGACY_PSRAM_Init+0x7a>
20024178:	2204      	movs	r2, #4
2002417a:	2300      	movs	r3, #0
2002417c:	2508      	movs	r5, #8
2002417e:	2633      	movs	r6, #51	@ 0x33
20024180:	e7ce      	b.n	20024120 <HAL_LEGACY_PSRAM_Init+0xdc>
20024182:	2205      	movs	r2, #5
20024184:	2300      	movs	r3, #0
20024186:	2508      	movs	r5, #8
20024188:	2637      	movs	r6, #55	@ 0x37
2002418a:	e7c9      	b.n	20024120 <HAL_LEGACY_PSRAM_Init+0xdc>
2002418c:	2001      	movs	r0, #1
2002418e:	e7da      	b.n	20024146 <HAL_LEGACY_PSRAM_Init+0x102>
20024190:	016e3600 	.word	0x016e3600
20024194:	07270e00 	.word	0x07270e00
20024198:	08954400 	.word	0x08954400
2002419c:	094c5f00 	.word	0x094c5f00

200241a0 <HAL_HYPER_PSRAM_WriteCR>:
200241a0:	b570      	push	{r4, r5, r6, lr}
200241a2:	460e      	mov	r6, r1
200241a4:	4615      	mov	r5, r2
200241a6:	4604      	mov	r4, r0
200241a8:	b086      	sub	sp, #24
200241aa:	b1f8      	cbz	r0, 200241ec <HAL_HYPER_PSRAM_WriteCR+0x4c>
200241ac:	2207      	movs	r2, #7
200241ae:	2303      	movs	r3, #3
200241b0:	e9cd 2301 	strd	r2, r3, [sp, #4]
200241b4:	2300      	movs	r3, #0
200241b6:	e9cd 2203 	strd	r2, r2, [sp, #12]
200241ba:	9300      	str	r3, [sp, #0]
200241bc:	2101      	movs	r1, #1
200241be:	f7fe fa2f 	bl	20022620 <HAL_FLASH_MANUAL_CMD>
200241c2:	4631      	mov	r1, r6
200241c4:	4620      	mov	r0, r4
200241c6:	f7fe f9d5 	bl	20022574 <HAL_FLASH_WRITE_ABYTE>
200241ca:	2102      	movs	r1, #2
200241cc:	4620      	mov	r0, r4
200241ce:	f7fe f9bd 	bl	2002254c <HAL_FLASH_WRITE_DLEN>
200241d2:	4629      	mov	r1, r5
200241d4:	4620      	mov	r0, r4
200241d6:	f7fe f9b2 	bl	2002253e <HAL_FLASH_WRITE_WORD>
200241da:	f44f 3280 	mov.w	r2, #65536	@ 0x10000
200241de:	2160      	movs	r1, #96	@ 0x60
200241e0:	4620      	mov	r0, r4
200241e2:	b006      	add	sp, #24
200241e4:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
200241e8:	f7fe b9d5 	b.w	20022596 <HAL_FLASH_SET_CMD>
200241ec:	b006      	add	sp, #24
200241ee:	bd70      	pop	{r4, r5, r6, pc}

200241f0 <HAL_HYPER_PSRAM_Init>:
200241f0:	b538      	push	{r3, r4, r5, lr}
200241f2:	4605      	mov	r5, r0
200241f4:	2201      	movs	r2, #1
200241f6:	f7ff fea1 	bl	20023f3c <HAL_OPI_PSRAM_Init>
200241fa:	69ac      	ldr	r4, [r5, #24]
200241fc:	4b12      	ldr	r3, [pc, #72]	@ (20024248 <HAL_HYPER_PSRAM_Init+0x58>)
200241fe:	429c      	cmp	r4, r3
20024200:	d91c      	bls.n	2002423c <HAL_HYPER_PSRAM_Init+0x4c>
20024202:	4b12      	ldr	r3, [pc, #72]	@ (2002424c <HAL_HYPER_PSRAM_Init+0x5c>)
20024204:	429c      	cmp	r4, r3
20024206:	d91b      	bls.n	20024240 <HAL_HYPER_PSRAM_Init+0x50>
20024208:	4b11      	ldr	r3, [pc, #68]	@ (20024250 <HAL_HYPER_PSRAM_Init+0x60>)
2002420a:	429c      	cmp	r4, r3
2002420c:	d91a      	bls.n	20024244 <HAL_HYPER_PSRAM_Init+0x54>
2002420e:	4b11      	ldr	r3, [pc, #68]	@ (20024254 <HAL_HYPER_PSRAM_Init+0x64>)
20024210:	429c      	cmp	r4, r3
20024212:	bf8c      	ite	hi
20024214:	2402      	movhi	r4, #2
20024216:	2401      	movls	r4, #1
20024218:	2101      	movs	r1, #1
2002421a:	4628      	mov	r0, r5
2002421c:	f7fe fa79 	bl	20022712 <HAL_FLASH_ENABLE_HYPER>
20024220:	f240 428f 	movw	r2, #1167	@ 0x48f
20024224:	4628      	mov	r0, r5
20024226:	ea42 3204 	orr.w	r2, r2, r4, lsl #12
2002422a:	2100      	movs	r1, #0
2002422c:	f7ff ffb8 	bl	200241a0 <HAL_HYPER_PSRAM_WriteCR>
20024230:	2101      	movs	r1, #1
20024232:	4628      	mov	r0, r5
20024234:	f7fe fade 	bl	200227f4 <HAL_MPI_EN_FIXLAT>
20024238:	2000      	movs	r0, #0
2002423a:	bd38      	pop	{r3, r4, r5, pc}
2002423c:	240e      	movs	r4, #14
2002423e:	e7eb      	b.n	20024218 <HAL_HYPER_PSRAM_Init+0x28>
20024240:	240f      	movs	r4, #15
20024242:	e7e9      	b.n	20024218 <HAL_HYPER_PSRAM_Init+0x28>
20024244:	2400      	movs	r4, #0
20024246:	e7e7      	b.n	20024218 <HAL_HYPER_PSRAM_Init+0x28>
20024248:	0510ff40 	.word	0x0510ff40
2002424c:	0632ea00 	.word	0x0632ea00
20024250:	07ed6b40 	.word	0x07ed6b40
20024254:	09e4f580 	.word	0x09e4f580

20024258 <HAL_HYPER_CFG_READ>:
20024258:	b51f      	push	{r0, r1, r2, r3, r4, lr}
2002425a:	b160      	cbz	r0, 20024276 <HAL_HYPER_CFG_READ+0x1e>
2002425c:	2107      	movs	r1, #7
2002425e:	2303      	movs	r3, #3
20024260:	f890 202d 	ldrb.w	r2, [r0, #45]	@ 0x2d
20024264:	e9cd 1300 	strd	r1, r3, [sp]
20024268:	3a01      	subs	r2, #1
2002426a:	2300      	movs	r3, #0
2002426c:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024270:	b252      	sxtb	r2, r2
20024272:	f7fe f91e 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20024276:	b005      	add	sp, #20
20024278:	f85d fb04 	ldr.w	pc, [sp], #4

2002427c <HAL_HYPER_CFG_WRITE>:
2002427c:	b51f      	push	{r0, r1, r2, r3, r4, lr}
2002427e:	b160      	cbz	r0, 2002429a <HAL_HYPER_CFG_WRITE+0x1e>
20024280:	2107      	movs	r1, #7
20024282:	2303      	movs	r3, #3
20024284:	f890 202e 	ldrb.w	r2, [r0, #46]	@ 0x2e
20024288:	e9cd 1300 	strd	r1, r3, [sp]
2002428c:	3a01      	subs	r2, #1
2002428e:	2300      	movs	r3, #0
20024290:	e9cd 1102 	strd	r1, r1, [sp, #8]
20024294:	b252      	sxtb	r2, r2
20024296:	f7fe f935 	bl	20022504 <HAL_FLASH_CFG_AHB_WCMD>
2002429a:	b005      	add	sp, #20
2002429c:	f85d fb04 	ldr.w	pc, [sp], #4

200242a0 <HAL_MPI_PSRAM_Init>:
200242a0:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
200242a4:	690b      	ldr	r3, [r1, #16]
200242a6:	4604      	mov	r4, r0
200242a8:	f880 302b 	strb.w	r3, [r0, #43]	@ 0x2b
200242ac:	690b      	ldr	r3, [r1, #16]
200242ae:	3b03      	subs	r3, #3
200242b0:	2b03      	cmp	r3, #3
200242b2:	f200 8085 	bhi.w	200243c0 <HAL_MPI_PSRAM_Init+0x120>
200242b6:	e8df f003 	tbb	[pc, r3]
200242ba:	6302      	.short	0x6302
200242bc:	7958      	.short	0x7958
200242be:	4620      	mov	r0, r4
200242c0:	f7ff fe3c 	bl	20023f3c <HAL_OPI_PSRAM_Init>
200242c4:	2203      	movs	r2, #3
200242c6:	4606      	mov	r6, r0
200242c8:	2108      	movs	r1, #8
200242ca:	4620      	mov	r0, r4
200242cc:	f7ff fd28 	bl	20023d20 <HAL_MPI_MR_WRITE>
200242d0:	4620      	mov	r0, r4
200242d2:	f7ff fa5d 	bl	20023790 <HAL_QSPI_GET_CLK>
200242d6:	4b4d      	ldr	r3, [pc, #308]	@ (2002440c <HAL_MPI_PSRAM_Init+0x16c>)
200242d8:	4298      	cmp	r0, r3
200242da:	d95f      	bls.n	2002439c <HAL_MPI_PSRAM_Init+0xfc>
200242dc:	f103 63a4 	add.w	r3, r3, #85983232	@ 0x5200000
200242e0:	f503 4383 	add.w	r3, r3, #16768	@ 0x4180
200242e4:	4298      	cmp	r0, r3
200242e6:	d95b      	bls.n	200243a0 <HAL_MPI_PSRAM_Init+0x100>
200242e8:	f103 7337 	add.w	r3, r3, #47972352	@ 0x2dc0000
200242ec:	f503 43d8 	add.w	r3, r3, #27648	@ 0x6c00
200242f0:	4298      	cmp	r0, r3
200242f2:	d957      	bls.n	200243a4 <HAL_MPI_PSRAM_Init+0x104>
200242f4:	4b46      	ldr	r3, [pc, #280]	@ (20024410 <HAL_MPI_PSRAM_Init+0x170>)
200242f6:	4298      	cmp	r0, r3
200242f8:	d956      	bls.n	200243a8 <HAL_MPI_PSRAM_Init+0x108>
200242fa:	4b46      	ldr	r3, [pc, #280]	@ (20024414 <HAL_MPI_PSRAM_Init+0x174>)
200242fc:	4298      	cmp	r0, r3
200242fe:	bf94      	ite	ls
20024300:	2507      	movls	r5, #7
20024302:	2500      	movhi	r5, #0
20024304:	f04f 0800 	mov.w	r8, #0
20024308:	2707      	movs	r7, #7
2002430a:	f04f 0a03 	mov.w	sl, #3
2002430e:	ea4f 0945 	mov.w	r9, r5, lsl #1
20024312:	4643      	mov	r3, r8
20024314:	f109 32ff 	add.w	r2, r9, #4294967295
20024318:	4639      	mov	r1, r7
2002431a:	4620      	mov	r0, r4
2002431c:	e9cd 7702 	strd	r7, r7, [sp, #8]
20024320:	e9cd 8a00 	strd	r8, sl, [sp]
20024324:	f7fe f8c5 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
20024328:	4641      	mov	r1, r8
2002432a:	4620      	mov	r0, r4
2002432c:	f7fe f8b6 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
20024330:	4643      	mov	r3, r8
20024332:	1e6a      	subs	r2, r5, #1
20024334:	4639      	mov	r1, r7
20024336:	4620      	mov	r0, r4
20024338:	e9cd 7702 	strd	r7, r7, [sp, #8]
2002433c:	e9cd 8a00 	strd	r8, sl, [sp]
20024340:	f7fe f8e0 	bl	20022504 <HAL_FLASH_CFG_AHB_WCMD>
20024344:	2180      	movs	r1, #128	@ 0x80
20024346:	4620      	mov	r0, r4
20024348:	f7fe f8d0 	bl	200224ec <HAL_FLASH_SET_AHB_WCMD>
2002434c:	462b      	mov	r3, r5
2002434e:	464a      	mov	r2, r9
20024350:	2101      	movs	r1, #1
20024352:	4620      	mov	r0, r4
20024354:	f7ff fd08 	bl	20023d68 <HAL_MPI_SET_FIXLAT>
20024358:	f64f 71ff 	movw	r1, #65535	@ 0xffff
2002435c:	4620      	mov	r0, r4
2002435e:	f7fe fa85 	bl	2002286c <HAL_FLASH_SET_WDT>
20024362:	4630      	mov	r0, r6
20024364:	b004      	add	sp, #16
20024366:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002436a:	4620      	mov	r0, r4
2002436c:	f7ff fe6a 	bl	20024044 <HAL_LEGACY_PSRAM_Init>
20024370:	4620      	mov	r0, r4
20024372:	f7ff fd6c 	bl	20023e4e <HAL_LEGACY_CFG_READ>
20024376:	4620      	mov	r0, r4
20024378:	f7ff fd84 	bl	20023e84 <HAL_LEGACY_CFG_WRITE>
2002437c:	2600      	movs	r6, #0
2002437e:	e7eb      	b.n	20024358 <HAL_MPI_PSRAM_Init+0xb8>
20024380:	4620      	mov	r0, r4
20024382:	f7ff fddb 	bl	20023f3c <HAL_OPI_PSRAM_Init>
20024386:	2243      	movs	r2, #67	@ 0x43
20024388:	4606      	mov	r6, r0
2002438a:	2108      	movs	r1, #8
2002438c:	4620      	mov	r0, r4
2002438e:	f7ff fcc7 	bl	20023d20 <HAL_MPI_MR_WRITE>
20024392:	2101      	movs	r1, #1
20024394:	4620      	mov	r0, r4
20024396:	f7fe fa1f 	bl	200227d8 <HAL_FLASH_SET_X16_MODE>
2002439a:	e799      	b.n	200242d0 <HAL_MPI_PSRAM_Init+0x30>
2002439c:	2503      	movs	r5, #3
2002439e:	e7b1      	b.n	20024304 <HAL_MPI_PSRAM_Init+0x64>
200243a0:	2504      	movs	r5, #4
200243a2:	e7af      	b.n	20024304 <HAL_MPI_PSRAM_Init+0x64>
200243a4:	2505      	movs	r5, #5
200243a6:	e7ad      	b.n	20024304 <HAL_MPI_PSRAM_Init+0x64>
200243a8:	2506      	movs	r5, #6
200243aa:	e7ab      	b.n	20024304 <HAL_MPI_PSRAM_Init+0x64>
200243ac:	4620      	mov	r0, r4
200243ae:	f7ff ff1f 	bl	200241f0 <HAL_HYPER_PSRAM_Init>
200243b2:	4620      	mov	r0, r4
200243b4:	f7ff ff50 	bl	20024258 <HAL_HYPER_CFG_READ>
200243b8:	4620      	mov	r0, r4
200243ba:	f7ff ff5f 	bl	2002427c <HAL_HYPER_CFG_WRITE>
200243be:	e7dd      	b.n	2002437c <HAL_MPI_PSRAM_Init+0xdc>
200243c0:	2600      	movs	r6, #0
200243c2:	2503      	movs	r5, #3
200243c4:	f04f 0801 	mov.w	r8, #1
200243c8:	2702      	movs	r7, #2
200243ca:	4620      	mov	r0, r4
200243cc:	f7ff fc52 	bl	20023c74 <HAL_SPI_PSRAM_Init>
200243d0:	4633      	mov	r3, r6
200243d2:	2206      	movs	r2, #6
200243d4:	4629      	mov	r1, r5
200243d6:	4620      	mov	r0, r4
200243d8:	e9cd 6700 	strd	r6, r7, [sp]
200243dc:	e9cd 5802 	strd	r5, r8, [sp, #8]
200243e0:	f7fe f867 	bl	200224b2 <HAL_FLASH_CFG_AHB_RCMD>
200243e4:	21eb      	movs	r1, #235	@ 0xeb
200243e6:	4620      	mov	r0, r4
200243e8:	f7fe f858 	bl	2002249c <HAL_FLASH_SET_AHB_RCMD>
200243ec:	4633      	mov	r3, r6
200243ee:	4632      	mov	r2, r6
200243f0:	4629      	mov	r1, r5
200243f2:	4620      	mov	r0, r4
200243f4:	e9cd 6700 	strd	r6, r7, [sp]
200243f8:	e9cd 5802 	strd	r5, r8, [sp, #8]
200243fc:	f7fe f882 	bl	20022504 <HAL_FLASH_CFG_AHB_WCMD>
20024400:	2138      	movs	r1, #56	@ 0x38
20024402:	4620      	mov	r0, r4
20024404:	f7fe f872 	bl	200224ec <HAL_FLASH_SET_AHB_WCMD>
20024408:	4606      	mov	r6, r0
2002440a:	e7a5      	b.n	20024358 <HAL_MPI_PSRAM_Init+0xb8>
2002440c:	07de2901 	.word	0x07de2901
20024410:	13c9eb01 	.word	0x13c9eb01
20024414:	17d78401 	.word	0x17d78401

20024418 <HAL_PIN_Set2>:
20024418:	0a03      	lsrs	r3, r0, #8
2002441a:	1e5a      	subs	r2, r3, #1
2002441c:	2a53      	cmp	r2, #83	@ 0x53
2002441e:	b2c0      	uxtb	r0, r0
20024420:	d80e      	bhi.n	20024440 <HAL_PIN_Set2+0x28>
20024422:	4a09      	ldr	r2, [pc, #36]	@ (20024448 <HAL_PIN_Set2+0x30>)
20024424:	009b      	lsls	r3, r3, #2
20024426:	441a      	add	r2, r3
20024428:	6813      	ldr	r3, [r2, #0]
2002442a:	f401 7140 	and.w	r1, r1, #768	@ 0x300
2002442e:	f36f 0309 	bfc	r3, #0, #10
20024432:	430b      	orrs	r3, r1
20024434:	4303      	orrs	r3, r0
20024436:	f443 6380 	orr.w	r3, r3, #1024	@ 0x400
2002443a:	2000      	movs	r0, #0
2002443c:	6013      	str	r3, [r2, #0]
2002443e:	4770      	bx	lr
20024440:	f04f 30ff 	mov.w	r0, #4294967295
20024444:	4770      	bx	lr
20024446:	bf00      	nop
20024448:	50002ffc 	.word	0x50002ffc

2002444c <HAL_PIN_Set>:
2002444c:	3801      	subs	r0, #1
2002444e:	2853      	cmp	r0, #83	@ 0x53
20024450:	b570      	push	{r4, r5, r6, lr}
20024452:	f04f 0400 	mov.w	r4, #0
20024456:	d824      	bhi.n	200244a2 <HAL_PIN_Set+0x56>
20024458:	0083      	lsls	r3, r0, #2
2002445a:	f1a1 0510 	sub.w	r5, r1, #16
2002445e:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20024462:	2dee      	cmp	r5, #238	@ 0xee
20024464:	f503 5340 	add.w	r3, r3, #12288	@ 0x3000
20024468:	d80c      	bhi.n	20024484 <HAL_PIN_Set+0x38>
2002446a:	b2cc      	uxtb	r4, r1
2002446c:	2000      	movs	r0, #0
2002446e:	6819      	ldr	r1, [r3, #0]
20024470:	f402 7240 	and.w	r2, r2, #768	@ 0x300
20024474:	4322      	orrs	r2, r4
20024476:	f36f 0109 	bfc	r1, #0, #10
2002447a:	430a      	orrs	r2, r1
2002447c:	f442 6280 	orr.w	r2, r2, #1024	@ 0x400
20024480:	601a      	str	r2, [r3, #0]
20024482:	bd70      	pop	{r4, r5, r6, pc}
20024484:	4d08      	ldr	r5, [pc, #32]	@ (200244a8 <HAL_PIN_Set+0x5c>)
20024486:	f855 0020 	ldr.w	r0, [r5, r0, lsl #2]
2002448a:	f100 0640 	add.w	r6, r0, #64	@ 0x40
2002448e:	8845      	ldrh	r5, [r0, #2]
20024490:	b13d      	cbz	r5, 200244a2 <HAL_PIN_Set+0x56>
20024492:	428d      	cmp	r5, r1
20024494:	d101      	bne.n	2002449a <HAL_PIN_Set+0x4e>
20024496:	7804      	ldrb	r4, [r0, #0]
20024498:	e7e8      	b.n	2002446c <HAL_PIN_Set+0x20>
2002449a:	3004      	adds	r0, #4
2002449c:	42b0      	cmp	r0, r6
2002449e:	d1f6      	bne.n	2002448e <HAL_PIN_Set+0x42>
200244a0:	e7e4      	b.n	2002446c <HAL_PIN_Set+0x20>
200244a2:	f04f 30ff 	mov.w	r0, #4294967295
200244a6:	e7ec      	b.n	20024482 <HAL_PIN_Set+0x36>
200244a8:	20026ff8 	.word	0x20026ff8

200244ac <HAL_PIN_Set_DS0>:
200244ac:	2854      	cmp	r0, #84	@ 0x54
200244ae:	dc0e      	bgt.n	200244ce <HAL_PIN_Set_DS0+0x22>
200244b0:	b168      	cbz	r0, 200244ce <HAL_PIN_Set_DS0+0x22>
200244b2:	4b08      	ldr	r3, [pc, #32]	@ (200244d4 <HAL_PIN_Set_DS0+0x28>)
200244b4:	0080      	lsls	r0, r0, #2
200244b6:	4403      	add	r3, r0
200244b8:	b12a      	cbz	r2, 200244c6 <HAL_PIN_Set_DS0+0x1a>
200244ba:	681a      	ldr	r2, [r3, #0]
200244bc:	f442 5200 	orr.w	r2, r2, #8192	@ 0x2000
200244c0:	2000      	movs	r0, #0
200244c2:	601a      	str	r2, [r3, #0]
200244c4:	4770      	bx	lr
200244c6:	681a      	ldr	r2, [r3, #0]
200244c8:	f422 5200 	bic.w	r2, r2, #8192	@ 0x2000
200244cc:	e7f8      	b.n	200244c0 <HAL_PIN_Set_DS0+0x14>
200244ce:	f04f 30ff 	mov.w	r0, #4294967295
200244d2:	4770      	bx	lr
200244d4:	50002ffc 	.word	0x50002ffc

200244d8 <HAL_PIN_Set_DS1>:
200244d8:	2854      	cmp	r0, #84	@ 0x54
200244da:	dc0e      	bgt.n	200244fa <HAL_PIN_Set_DS1+0x22>
200244dc:	b168      	cbz	r0, 200244fa <HAL_PIN_Set_DS1+0x22>
200244de:	4b08      	ldr	r3, [pc, #32]	@ (20024500 <HAL_PIN_Set_DS1+0x28>)
200244e0:	0080      	lsls	r0, r0, #2
200244e2:	4403      	add	r3, r0
200244e4:	b12a      	cbz	r2, 200244f2 <HAL_PIN_Set_DS1+0x1a>
200244e6:	681a      	ldr	r2, [r3, #0]
200244e8:	f442 4280 	orr.w	r2, r2, #16384	@ 0x4000
200244ec:	2000      	movs	r0, #0
200244ee:	601a      	str	r2, [r3, #0]
200244f0:	4770      	bx	lr
200244f2:	681a      	ldr	r2, [r3, #0]
200244f4:	f422 4280 	bic.w	r2, r2, #16384	@ 0x4000
200244f8:	e7f8      	b.n	200244ec <HAL_PIN_Set_DS1+0x14>
200244fa:	f04f 30ff 	mov.w	r0, #4294967295
200244fe:	4770      	bx	lr
20024500:	50002ffc 	.word	0x50002ffc

20024504 <HAL_PMU_EnableDLL>:
20024504:	4b05      	ldr	r3, [pc, #20]	@ (2002451c <HAL_PMU_EnableDLL+0x18>)
20024506:	6eda      	ldr	r2, [r3, #108]	@ 0x6c
20024508:	b120      	cbz	r0, 20024514 <HAL_PMU_EnableDLL+0x10>
2002450a:	f042 0220 	orr.w	r2, r2, #32
2002450e:	2000      	movs	r0, #0
20024510:	66da      	str	r2, [r3, #108]	@ 0x6c
20024512:	4770      	bx	lr
20024514:	f022 0220 	bic.w	r2, r2, #32
20024518:	e7f9      	b.n	2002450e <HAL_PMU_EnableDLL+0xa>
2002451a:	bf00      	nop
2002451c:	500ca000 	.word	0x500ca000

20024520 <HAL_PMU_LoadCalData>:
20024520:	b510      	push	{r4, lr}
20024522:	4c27      	ldr	r4, [pc, #156]	@ (200245c0 <HAL_PMU_LoadCalData+0xa0>)
20024524:	220f      	movs	r2, #15
20024526:	4621      	mov	r1, r4
20024528:	2006      	movs	r0, #6
2002452a:	f000 fb97 	bl	20024c5c <BSP_CONFIG_get>
2002452e:	2800      	cmp	r0, #0
20024530:	dd44      	ble.n	200245bc <HAL_PMU_LoadCalData+0x9c>
20024532:	2301      	movs	r3, #1
20024534:	7862      	ldrb	r2, [r4, #1]
20024536:	f804 3c01 	strb.w	r3, [r4, #-1]
2002453a:	7821      	ldrb	r1, [r4, #0]
2002453c:	4b21      	ldr	r3, [pc, #132]	@ (200245c4 <HAL_PMU_LoadCalData+0xa4>)
2002453e:	0792      	lsls	r2, r2, #30
20024540:	6ad8      	ldr	r0, [r3, #44]	@ 0x2c
20024542:	0649      	lsls	r1, r1, #25
20024544:	f001 6160 	and.w	r1, r1, #234881024	@ 0xe000000
20024548:	f002 4280 	and.w	r2, r2, #1073741824	@ 0x40000000
2002454c:	430a      	orrs	r2, r1
2002454e:	f020 419c 	bic.w	r1, r0, #1308622848	@ 0x4e000000
20024552:	430a      	orrs	r2, r1
20024554:	62da      	str	r2, [r3, #44]	@ 0x2c
20024556:	f8d3 2094 	ldr.w	r2, [r3, #148]	@ 0x94
2002455a:	78e1      	ldrb	r1, [r4, #3]
2002455c:	f361 0203 	bfi	r2, r1, #0, #4
20024560:	f8c3 2094 	str.w	r2, [r3, #148]	@ 0x94
20024564:	695a      	ldr	r2, [r3, #20]
20024566:	7921      	ldrb	r1, [r4, #4]
20024568:	f361 228d 	bfi	r2, r1, #10, #4
2002456c:	615a      	str	r2, [r3, #20]
2002456e:	7962      	ldrb	r2, [r4, #5]
20024570:	79a0      	ldrb	r0, [r4, #6]
20024572:	6e19      	ldr	r1, [r3, #96]	@ 0x60
20024574:	00d2      	lsls	r2, r2, #3
20024576:	02c0      	lsls	r0, r0, #11
20024578:	f002 0278 	and.w	r2, r2, #120	@ 0x78
2002457c:	f400 40f0 	and.w	r0, r0, #30720	@ 0x7800
20024580:	f021 1178 	bic.w	r1, r1, #7864440	@ 0x780078
20024584:	f421 41f0 	bic.w	r1, r1, #30720	@ 0x7800
20024588:	4302      	orrs	r2, r0
2002458a:	430a      	orrs	r2, r1
2002458c:	79e1      	ldrb	r1, [r4, #7]
2002458e:	04c9      	lsls	r1, r1, #19
20024590:	f401 01f0 	and.w	r1, r1, #7864320	@ 0x780000
20024594:	430a      	orrs	r2, r1
20024596:	661a      	str	r2, [r3, #96]	@ 0x60
20024598:	6a59      	ldr	r1, [r3, #36]	@ 0x24
2002459a:	7a22      	ldrb	r2, [r4, #8]
2002459c:	f021 0127 	bic.w	r1, r1, #39	@ 0x27
200245a0:	f002 0207 	and.w	r2, r2, #7
200245a4:	430a      	orrs	r2, r1
200245a6:	7a61      	ldrb	r1, [r4, #9]
200245a8:	0149      	lsls	r1, r1, #5
200245aa:	f001 0120 	and.w	r1, r1, #32
200245ae:	430a      	orrs	r2, r1
200245b0:	625a      	str	r2, [r3, #36]	@ 0x24
200245b2:	6a9a      	ldr	r2, [r3, #40]	@ 0x28
200245b4:	7ba1      	ldrb	r1, [r4, #14]
200245b6:	f361 0203 	bfi	r2, r1, #0, #4
200245ba:	629a      	str	r2, [r3, #40]	@ 0x28
200245bc:	bd10      	pop	{r4, pc}
200245be:	bf00      	nop
200245c0:	2004ca5d 	.word	0x2004ca5d
200245c4:	500ca000 	.word	0x500ca000

200245c8 <HAL_RCC_HCPU_ConfigSxModeVolt>:
200245c8:	b507      	push	{r0, r1, r2, lr}
200245ca:	4a13      	ldr	r2, [pc, #76]	@ (20024618 <HAL_RCC_HCPU_ConfigSxModeVolt+0x50>)
200245cc:	4913      	ldr	r1, [pc, #76]	@ (2002461c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
200245ce:	eb02 02c0 	add.w	r2, r2, r0, lsl #3
200245d2:	f8d1 3098 	ldr.w	r3, [r1, #152]	@ 0x98
200245d6:	7892      	ldrb	r2, [r2, #2]
200245d8:	2802      	cmp	r0, #2
200245da:	f362 0304 	bfi	r3, r2, #0, #5
200245de:	f8c1 3098 	str.w	r3, [r1, #152]	@ 0x98
200245e2:	f10d 0007 	add.w	r0, sp, #7
200245e6:	d111      	bne.n	2002460c <HAL_RCC_HCPU_ConfigSxModeVolt+0x44>
200245e8:	f003 fbea 	bl	20027dc0 <HAL_PMU_GetHpsysVoutRef>
200245ec:	b110      	cbz	r0, 200245f4 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
200245ee:	230b      	movs	r3, #11
200245f0:	f88d 3007 	strb.w	r3, [sp, #7]
200245f4:	4a09      	ldr	r2, [pc, #36]	@ (2002461c <HAL_RCC_HCPU_ConfigSxModeVolt+0x54>)
200245f6:	f89d 1007 	ldrb.w	r1, [sp, #7]
200245fa:	f8d2 3090 	ldr.w	r3, [r2, #144]	@ 0x90
200245fe:	f361 0303 	bfi	r3, r1, #0, #4
20024602:	f8c2 3090 	str.w	r3, [r2, #144]	@ 0x90
20024606:	b003      	add	sp, #12
20024608:	f85d fb04 	ldr.w	pc, [sp], #4
2002460c:	f003 fbe4 	bl	20027dd8 <HAL_PMU_GetHpsysVoutRef2>
20024610:	2800      	cmp	r0, #0
20024612:	d0ef      	beq.n	200245f4 <HAL_RCC_HCPU_ConfigSxModeVolt+0x2c>
20024614:	230e      	movs	r3, #14
20024616:	e7eb      	b.n	200245f0 <HAL_RCC_HCPU_ConfigSxModeVolt+0x28>
20024618:	2002761c 	.word	0x2002761c
2002461c:	500ca000 	.word	0x500ca000

20024620 <HAL_RCC_HCPU_GetClockSrc>:
20024620:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024624:	2810      	cmp	r0, #16
20024626:	6a1a      	ldr	r2, [r3, #32]
20024628:	d80c      	bhi.n	20024644 <HAL_RCC_HCPU_GetClockSrc+0x24>
2002462a:	4b07      	ldr	r3, [pc, #28]	@ (20024648 <HAL_RCC_HCPU_GetClockSrc+0x28>)
2002462c:	40c3      	lsrs	r3, r0
2002462e:	f013 0f01 	tst.w	r3, #1
20024632:	bf0c      	ite	eq
20024634:	2301      	moveq	r3, #1
20024636:	2303      	movne	r3, #3
20024638:	4083      	lsls	r3, r0
2002463a:	4013      	ands	r3, r2
2002463c:	fa23 f000 	lsr.w	r0, r3, r0
20024640:	b2c0      	uxtb	r0, r0
20024642:	4770      	bx	lr
20024644:	2301      	movs	r3, #1
20024646:	e7f7      	b.n	20024638 <HAL_RCC_HCPU_GetClockSrc+0x18>
20024648:	00012ff1 	.word	0x00012ff1

2002464c <HAL_RCC_HCPU_GetDLLFreq>:
2002464c:	2801      	cmp	r0, #1
2002464e:	d003      	beq.n	20024658 <HAL_RCC_HCPU_GetDLLFreq+0xc>
20024650:	2802      	cmp	r0, #2
20024652:	d00e      	beq.n	20024672 <HAL_RCC_HCPU_GetDLLFreq+0x26>
20024654:	2000      	movs	r0, #0
20024656:	4770      	bx	lr
20024658:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
2002465c:	6adb      	ldr	r3, [r3, #44]	@ 0x2c
2002465e:	b163      	cbz	r3, 2002467a <HAL_RCC_HCPU_GetDLLFreq+0x2e>
20024660:	f013 0001 	ands.w	r0, r3, #1
20024664:	d00a      	beq.n	2002467c <HAL_RCC_HCPU_GetDLLFreq+0x30>
20024666:	4806      	ldr	r0, [pc, #24]	@ (20024680 <HAL_RCC_HCPU_GetDLLFreq+0x34>)
20024668:	f3c3 0383 	ubfx	r3, r3, #2, #4
2002466c:	fb03 0000 	mla	r0, r3, r0, r0
20024670:	4770      	bx	lr
20024672:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024676:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
20024678:	e7f1      	b.n	2002465e <HAL_RCC_HCPU_GetDLLFreq+0x12>
2002467a:	4618      	mov	r0, r3
2002467c:	4770      	bx	lr
2002467e:	bf00      	nop
20024680:	016e3600 	.word	0x016e3600

20024684 <HAL_RCC_HCPU_GetDLL1Freq>:
20024684:	2001      	movs	r0, #1
20024686:	f7ff bfe1 	b.w	2002464c <HAL_RCC_HCPU_GetDLLFreq>
	...

2002468c <HAL_RCC_GetSysCLKFreq.part.0>:
2002468c:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024690:	6a1b      	ldr	r3, [r3, #32]
20024692:	f003 0303 	and.w	r3, r3, #3
20024696:	2b03      	cmp	r3, #3
20024698:	d101      	bne.n	2002469e <HAL_RCC_GetSysCLKFreq.part.0+0x12>
2002469a:	f7ff bff3 	b.w	20024684 <HAL_RCC_HCPU_GetDLL1Freq>
2002469e:	4801      	ldr	r0, [pc, #4]	@ (200246a4 <HAL_RCC_GetSysCLKFreq.part.0+0x18>)
200246a0:	4770      	bx	lr
200246a2:	bf00      	nop
200246a4:	02dc6c00 	.word	0x02dc6c00

200246a8 <HAL_RCC_HCPU_GetDLL2Freq>:
200246a8:	2002      	movs	r0, #2
200246aa:	f7ff bfcf 	b.w	2002464c <HAL_RCC_HCPU_GetDLLFreq>

200246ae <HAL_RCC_HCPU_GetDLL3Freq>:
200246ae:	2000      	movs	r0, #0
200246b0:	4770      	bx	lr
	...

200246b4 <HAL_RCC_HCPU_EnableDLL>:
200246b4:	4b1a      	ldr	r3, [pc, #104]	@ (20024720 <HAL_RCC_HCPU_EnableDLL+0x6c>)
200246b6:	f1a1 71b7 	sub.w	r1, r1, #23986176	@ 0x16e0000
200246ba:	f5a1 5158 	sub.w	r1, r1, #13824	@ 0x3600
200246be:	4299      	cmp	r1, r3
200246c0:	b510      	push	{r4, lr}
200246c2:	d82a      	bhi.n	2002471a <HAL_RCC_HCPU_EnableDLL+0x66>
200246c4:	2801      	cmp	r0, #1
200246c6:	d002      	beq.n	200246ce <HAL_RCC_HCPU_EnableDLL+0x1a>
200246c8:	2802      	cmp	r0, #2
200246ca:	d024      	beq.n	20024716 <HAL_RCC_HCPU_EnableDLL+0x62>
200246cc:	e7fe      	b.n	200246cc <HAL_RCC_HCPU_EnableDLL+0x18>
200246ce:	4c15      	ldr	r4, [pc, #84]	@ (20024724 <HAL_RCC_HCPU_EnableDLL+0x70>)
200246d0:	4a15      	ldr	r2, [pc, #84]	@ (20024728 <HAL_RCC_HCPU_EnableDLL+0x74>)
200246d2:	2000      	movs	r0, #0
200246d4:	6c53      	ldr	r3, [r2, #68]	@ 0x44
200246d6:	f043 0301 	orr.w	r3, r3, #1
200246da:	6453      	str	r3, [r2, #68]	@ 0x44
200246dc:	4a13      	ldr	r2, [pc, #76]	@ (2002472c <HAL_RCC_HCPU_EnableDLL+0x78>)
200246de:	6823      	ldr	r3, [r4, #0]
200246e0:	fbb1 f1f2 	udiv	r1, r1, r2
200246e4:	f023 0301 	bic.w	r3, r3, #1
200246e8:	6023      	str	r3, [r4, #0]
200246ea:	6823      	ldr	r3, [r4, #0]
200246ec:	f423 4380 	bic.w	r3, r3, #16384	@ 0x4000
200246f0:	f023 033c 	bic.w	r3, r3, #60	@ 0x3c
200246f4:	ea43 0381 	orr.w	r3, r3, r1, lsl #2
200246f8:	f443 5300 	orr.w	r3, r3, #8192	@ 0x2000
200246fc:	f043 0301 	orr.w	r3, r3, #1
20024700:	6023      	str	r3, [r4, #0]
20024702:	f7fd f976 	bl	200219f2 <HAL_Delay_us>
20024706:	200a      	movs	r0, #10
20024708:	f7fd f973 	bl	200219f2 <HAL_Delay_us>
2002470c:	6823      	ldr	r3, [r4, #0]
2002470e:	2b00      	cmp	r3, #0
20024710:	dafc      	bge.n	2002470c <HAL_RCC_HCPU_EnableDLL+0x58>
20024712:	2000      	movs	r0, #0
20024714:	bd10      	pop	{r4, pc}
20024716:	4c06      	ldr	r4, [pc, #24]	@ (20024730 <HAL_RCC_HCPU_EnableDLL+0x7c>)
20024718:	e7da      	b.n	200246d0 <HAL_RCC_HCPU_EnableDLL+0x1c>
2002471a:	2001      	movs	r0, #1
2002471c:	e7fa      	b.n	20024714 <HAL_RCC_HCPU_EnableDLL+0x60>
2002471e:	bf00      	nop
20024720:	15752a00 	.word	0x15752a00
20024724:	5000002c 	.word	0x5000002c
20024728:	5000b000 	.word	0x5000b000
2002472c:	016e3600 	.word	0x016e3600
20024730:	50000030 	.word	0x50000030

20024734 <HAL_RCC_HCPU_EnableDLL1>:
20024734:	4601      	mov	r1, r0
20024736:	2001      	movs	r0, #1
20024738:	f7ff bfbc 	b.w	200246b4 <HAL_RCC_HCPU_EnableDLL>

2002473c <HAL_RCC_HCPU_EnableDLL2>:
2002473c:	4601      	mov	r1, r0
2002473e:	2002      	movs	r0, #2
20024740:	f7ff bfb8 	b.w	200246b4 <HAL_RCC_HCPU_EnableDLL>

20024744 <HAL_RCC_HCPU_DisableDLL1>:
20024744:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024748:	6ad3      	ldr	r3, [r2, #44]	@ 0x2c
2002474a:	2000      	movs	r0, #0
2002474c:	f023 0301 	bic.w	r3, r3, #1
20024750:	62d3      	str	r3, [r2, #44]	@ 0x2c
20024752:	4770      	bx	lr

20024754 <HAL_RCC_HCPU_DisableDLL2>:
20024754:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
20024758:	6b13      	ldr	r3, [r2, #48]	@ 0x30
2002475a:	2000      	movs	r0, #0
2002475c:	f023 0301 	bic.w	r3, r3, #1
20024760:	6313      	str	r3, [r2, #48]	@ 0x30
20024762:	4770      	bx	lr

20024764 <HAL_RCC_GetSysCLKFreq>:
20024764:	2801      	cmp	r0, #1
20024766:	d101      	bne.n	2002476c <HAL_RCC_GetSysCLKFreq+0x8>
20024768:	f7ff bf90 	b.w	2002468c <HAL_RCC_GetSysCLKFreq.part.0>
2002476c:	4800      	ldr	r0, [pc, #0]	@ (20024770 <HAL_RCC_GetSysCLKFreq+0xc>)
2002476e:	4770      	bx	lr
20024770:	02dc6c00 	.word	0x02dc6c00

20024774 <HAL_RCC_GetHCLKFreq>:
20024774:	1e02      	subs	r2, r0, #0
20024776:	bf08      	it	eq
20024778:	2201      	moveq	r2, #1
2002477a:	b508      	push	{r3, lr}
2002477c:	4610      	mov	r0, r2
2002477e:	f7ff fff1 	bl	20024764 <HAL_RCC_GetSysCLKFreq>
20024782:	2a01      	cmp	r2, #1
20024784:	d002      	beq.n	2002478c <HAL_RCC_GetHCLKFreq+0x18>
20024786:	2a02      	cmp	r2, #2
20024788:	d00a      	beq.n	200247a0 <HAL_RCC_GetHCLKFreq+0x2c>
2002478a:	e7fe      	b.n	2002478a <HAL_RCC_GetHCLKFreq+0x16>
2002478c:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
20024790:	6a5b      	ldr	r3, [r3, #36]	@ 0x24
20024792:	b2db      	uxtb	r3, r3
20024794:	2b01      	cmp	r3, #1
20024796:	bfb8      	it	lt
20024798:	2301      	movlt	r3, #1
2002479a:	fbb0 f0f3 	udiv	r0, r0, r3
2002479e:	bd08      	pop	{r3, pc}
200247a0:	f04f 4380 	mov.w	r3, #1073741824	@ 0x40000000
200247a4:	695b      	ldr	r3, [r3, #20]
200247a6:	f003 033f 	and.w	r3, r3, #63	@ 0x3f
200247aa:	e7f3      	b.n	20024794 <HAL_RCC_GetHCLKFreq+0x20>

200247ac <HAL_RCC_HCPU_ClockSelect>:
200247ac:	f04f 43a0 	mov.w	r3, #1342177280	@ 0x50000000
200247b0:	b510      	push	{r4, lr}
200247b2:	2810      	cmp	r0, #16
200247b4:	6a1b      	ldr	r3, [r3, #32]
200247b6:	d817      	bhi.n	200247e8 <HAL_RCC_HCPU_ClockSelect+0x3c>
200247b8:	4a0c      	ldr	r2, [pc, #48]	@ (200247ec <HAL_RCC_HCPU_ClockSelect+0x40>)
200247ba:	40c2      	lsrs	r2, r0
200247bc:	f012 0f01 	tst.w	r2, #1
200247c0:	bf0c      	ite	eq
200247c2:	2201      	moveq	r2, #1
200247c4:	2203      	movne	r2, #3
200247c6:	fa02 f400 	lsl.w	r4, r2, r0
200247ca:	4011      	ands	r1, r2
200247cc:	f04f 42a0 	mov.w	r2, #1342177280	@ 0x50000000
200247d0:	ea23 0304 	bic.w	r3, r3, r4
200247d4:	4081      	lsls	r1, r0
200247d6:	430b      	orrs	r3, r1
200247d8:	6213      	str	r3, [r2, #32]
200247da:	b920      	cbnz	r0, 200247e6 <HAL_RCC_HCPU_ClockSelect+0x3a>
200247dc:	2001      	movs	r0, #1
200247de:	f7ff ffc9 	bl	20024774 <HAL_RCC_GetHCLKFreq>
200247e2:	4b03      	ldr	r3, [pc, #12]	@ (200247f0 <HAL_RCC_HCPU_ClockSelect+0x44>)
200247e4:	6018      	str	r0, [r3, #0]
200247e6:	bd10      	pop	{r4, pc}
200247e8:	2201      	movs	r2, #1
200247ea:	e7ec      	b.n	200247c6 <HAL_RCC_HCPU_ClockSelect+0x1a>
200247ec:	00012ff1 	.word	0x00012ff1
200247f0:	20042c14 	.word	0x20042c14

200247f4 <HAL_RCC_HCPU_SetDiv>:
200247f4:	2800      	cmp	r0, #0
200247f6:	bfd8      	it	le
200247f8:	2000      	movle	r0, #0
200247fa:	b508      	push	{r3, lr}
200247fc:	bfcc      	ite	gt
200247fe:	23ff      	movgt	r3, #255	@ 0xff
20024800:	4603      	movle	r3, r0
20024802:	2900      	cmp	r1, #0
20024804:	db12      	blt.n	2002482c <HAL_RCC_HCPU_SetDiv+0x38>
20024806:	2a00      	cmp	r2, #0
20024808:	f443 63e0 	orr.w	r3, r3, #1792	@ 0x700
2002480c:	ea40 2001 	orr.w	r0, r0, r1, lsl #8
20024810:	da0e      	bge.n	20024830 <HAL_RCC_HCPU_SetDiv+0x3c>
20024812:	f04f 41a0 	mov.w	r1, #1342177280	@ 0x50000000
20024816:	6a4a      	ldr	r2, [r1, #36]	@ 0x24
20024818:	ea22 0303 	bic.w	r3, r2, r3
2002481c:	4303      	orrs	r3, r0
2002481e:	624b      	str	r3, [r1, #36]	@ 0x24
20024820:	2001      	movs	r0, #1
20024822:	f7ff ffa7 	bl	20024774 <HAL_RCC_GetHCLKFreq>
20024826:	4b07      	ldr	r3, [pc, #28]	@ (20024844 <HAL_RCC_HCPU_SetDiv+0x50>)
20024828:	6018      	str	r0, [r3, #0]
2002482a:	bd08      	pop	{r3, pc}
2002482c:	2a00      	cmp	r2, #0
2002482e:	db04      	blt.n	2002483a <HAL_RCC_HCPU_SetDiv+0x46>
20024830:	f443 43e0 	orr.w	r3, r3, #28672	@ 0x7000
20024834:	ea40 3002 	orr.w	r0, r0, r2, lsl #12
20024838:	e7eb      	b.n	20024812 <HAL_RCC_HCPU_SetDiv+0x1e>
2002483a:	2b00      	cmp	r3, #0
2002483c:	d0f0      	beq.n	20024820 <HAL_RCC_HCPU_SetDiv+0x2c>
2002483e:	23ff      	movs	r3, #255	@ 0xff
20024840:	e7e7      	b.n	20024812 <HAL_RCC_HCPU_SetDiv+0x1e>
20024842:	bf00      	nop
20024844:	20042c14 	.word	0x20042c14

20024848 <HAL_RCC_HCPU_SwitchDvfsD2S>:
20024848:	b570      	push	{r4, r5, r6, lr}
2002484a:	460c      	mov	r4, r1
2002484c:	4d19      	ldr	r5, [pc, #100]	@ (200248b4 <HAL_RCC_HCPU_SwitchDvfsD2S+0x6c>)
2002484e:	4606      	mov	r6, r0
20024850:	f7ff feba 	bl	200245c8 <HAL_RCC_HCPU_ConfigSxModeVolt>
20024854:	692b      	ldr	r3, [r5, #16]
20024856:	20fa      	movs	r0, #250	@ 0xfa
20024858:	f023 0301 	bic.w	r3, r3, #1
2002485c:	612b      	str	r3, [r5, #16]
2002485e:	f7fd f8c8 	bl	200219f2 <HAL_Delay_us>
20024862:	2c30      	cmp	r4, #48	@ 0x30
20024864:	d80d      	bhi.n	20024882 <HAL_RCC_HCPU_SwitchDvfsD2S+0x3a>
20024866:	2100      	movs	r1, #0
20024868:	4608      	mov	r0, r1
2002486a:	f7ff ff9f 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
2002486e:	2030      	movs	r0, #48	@ 0x30
20024870:	2204      	movs	r2, #4
20024872:	2100      	movs	r1, #0
20024874:	fbb0 f0f4 	udiv	r0, r0, r4
20024878:	f7ff ffbc 	bl	200247f4 <HAL_RCC_HCPU_SetDiv>
2002487c:	2400      	movs	r4, #0
2002487e:	4620      	mov	r0, r4
20024880:	bd70      	pop	{r4, r5, r6, pc}
20024882:	f7fd fdd5 	bl	20022430 <HAL_HPAON_EnableXT48>
20024886:	480c      	ldr	r0, [pc, #48]	@ (200248b8 <HAL_RCC_HCPU_SwitchDvfsD2S+0x70>)
20024888:	eb00 00c6 	add.w	r0, r0, r6, lsl #3
2002488c:	6843      	ldr	r3, [r0, #4]
2002488e:	480b      	ldr	r0, [pc, #44]	@ (200248bc <HAL_RCC_HCPU_SwitchDvfsD2S+0x74>)
20024890:	61eb      	str	r3, [r5, #28]
20024892:	4360      	muls	r0, r4
20024894:	f7ff ff4e 	bl	20024734 <HAL_RCC_HCPU_EnableDLL1>
20024898:	4604      	mov	r4, r0
2002489a:	2800      	cmp	r0, #0
2002489c:	d1ef      	bne.n	2002487e <HAL_RCC_HCPU_SwitchDvfsD2S+0x36>
2002489e:	2101      	movs	r1, #1
200248a0:	2206      	movs	r2, #6
200248a2:	4608      	mov	r0, r1
200248a4:	f7ff ffa6 	bl	200247f4 <HAL_RCC_HCPU_SetDiv>
200248a8:	2103      	movs	r1, #3
200248aa:	4620      	mov	r0, r4
200248ac:	f7ff ff7e 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
200248b0:	e7e4      	b.n	2002487c <HAL_RCC_HCPU_SwitchDvfsD2S+0x34>
200248b2:	bf00      	nop
200248b4:	5000b000 	.word	0x5000b000
200248b8:	2002761c 	.word	0x2002761c
200248bc:	000f4240 	.word	0x000f4240

200248c0 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>:
200248c0:	e92d 41f3 	stmdb	sp!, {r0, r1, r4, r5, r6, r7, r8, lr}
200248c4:	4c1d      	ldr	r4, [pc, #116]	@ (2002493c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x7c>)
200248c6:	4f1e      	ldr	r7, [pc, #120]	@ (20024940 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x80>)
200248c8:	eb04 02c0 	add.w	r2, r4, r0, lsl #3
200248cc:	6b3b      	ldr	r3, [r7, #48]	@ 0x30
200248ce:	7892      	ldrb	r2, [r2, #2]
200248d0:	4605      	mov	r5, r0
200248d2:	f362 4396 	bfi	r3, r2, #18, #5
200248d6:	ea4f 08c0 	mov.w	r8, r0, lsl #3
200248da:	633b      	str	r3, [r7, #48]	@ 0x30
200248dc:	f10d 0007 	add.w	r0, sp, #7
200248e0:	460e      	mov	r6, r1
200248e2:	f003 fa6d 	bl	20027dc0 <HAL_PMU_GetHpsysVoutRef>
200248e6:	b110      	cbz	r0, 200248ee <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x2e>
200248e8:	230b      	movs	r3, #11
200248ea:	f88d 3007 	strb.w	r3, [sp, #7]
200248ee:	f89d 1007 	ldrb.w	r1, [sp, #7]
200248f2:	f914 2035 	ldrsb.w	r2, [r4, r5, lsl #3]
200248f6:	6d3b      	ldr	r3, [r7, #80]	@ 0x50
200248f8:	440a      	add	r2, r1
200248fa:	2100      	movs	r1, #0
200248fc:	f362 0385 	bfi	r3, r2, #2, #4
20024900:	4608      	mov	r0, r1
20024902:	653b      	str	r3, [r7, #80]	@ 0x50
20024904:	f7ff ff52 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20024908:	2e30      	cmp	r6, #48	@ 0x30
2002490a:	d900      	bls.n	2002490e <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4e>
2002490c:	e7fe      	b.n	2002490c <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x4c>
2002490e:	2030      	movs	r0, #48	@ 0x30
20024910:	2204      	movs	r2, #4
20024912:	2100      	movs	r1, #0
20024914:	fbb0 f0f6 	udiv	r0, r0, r6
20024918:	f7ff ff6c 	bl	200247f4 <HAL_RCC_HCPU_SetDiv>
2002491c:	f7ff ff12 	bl	20024744 <HAL_RCC_HCPU_DisableDLL1>
20024920:	f7fd fd92 	bl	20022448 <HAL_HPAON_DisableXT48>
20024924:	4444      	add	r4, r8
20024926:	4b07      	ldr	r3, [pc, #28]	@ (20024944 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0+0x84>)
20024928:	6862      	ldr	r2, [r4, #4]
2002492a:	61da      	str	r2, [r3, #28]
2002492c:	691a      	ldr	r2, [r3, #16]
2002492e:	f042 0201 	orr.w	r2, r2, #1
20024932:	611a      	str	r2, [r3, #16]
20024934:	b002      	add	sp, #8
20024936:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
2002493a:	bf00      	nop
2002493c:	2002761c 	.word	0x2002761c
20024940:	500ca000 	.word	0x500ca000
20024944:	5000b000 	.word	0x5000b000

20024948 <HAL_RCC_HCPU_ConfigDvfs>:
20024948:	b570      	push	{r4, r5, r6, lr}
2002494a:	4e31      	ldr	r6, [pc, #196]	@ (20024a10 <HAL_RCC_HCPU_ConfigDvfs+0xc8>)
2002494c:	4605      	mov	r5, r0
2002494e:	7833      	ldrb	r3, [r6, #0]
20024950:	460c      	mov	r4, r1
20024952:	2b01      	cmp	r3, #1
20024954:	d943      	bls.n	200249de <HAL_RCC_HCPU_ConfigDvfs+0x96>
20024956:	3b02      	subs	r3, #2
20024958:	2b01      	cmp	r3, #1
2002495a:	d902      	bls.n	20024962 <HAL_RCC_HCPU_ConfigDvfs+0x1a>
2002495c:	2501      	movs	r5, #1
2002495e:	4628      	mov	r0, r5
20024960:	bd70      	pop	{r4, r5, r6, pc}
20024962:	4b2c      	ldr	r3, [pc, #176]	@ (20024a14 <HAL_RCC_HCPU_ConfigDvfs+0xcc>)
20024964:	f853 2021 	ldr.w	r2, [r3, r1, lsl #2]
20024968:	f7ff fe9e 	bl	200246a8 <HAL_RCC_HCPU_GetDLL2Freq>
2002496c:	4290      	cmp	r0, r2
2002496e:	d8f5      	bhi.n	2002495c <HAL_RCC_HCPU_ConfigDvfs+0x14>
20024970:	2901      	cmp	r1, #1
20024972:	d805      	bhi.n	20024980 <HAL_RCC_HCPU_ConfigDvfs+0x38>
20024974:	4629      	mov	r1, r5
20024976:	4620      	mov	r0, r4
20024978:	f7ff ffa2 	bl	200248c0 <HAL_RCC_HCPU_SwitchDvfsS2D.isra.0>
2002497c:	2500      	movs	r5, #0
2002497e:	e035      	b.n	200249ec <HAL_RCC_HCPU_ConfigDvfs+0xa4>
20024980:	2100      	movs	r1, #0
20024982:	4608      	mov	r0, r1
20024984:	f7ff ff12 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20024988:	4620      	mov	r0, r4
2002498a:	f7ff fe1d 	bl	200245c8 <HAL_RCC_HCPU_ConfigSxModeVolt>
2002498e:	20fa      	movs	r0, #250	@ 0xfa
20024990:	f7fd f82f 	bl	200219f2 <HAL_Delay_us>
20024994:	f7ff fed6 	bl	20024744 <HAL_RCC_HCPU_DisableDLL1>
20024998:	2d30      	cmp	r5, #48	@ 0x30
2002499a:	d80d      	bhi.n	200249b8 <HAL_RCC_HCPU_ConfigDvfs+0x70>
2002499c:	f7fd fd54 	bl	20022448 <HAL_HPAON_DisableXT48>
200249a0:	2100      	movs	r1, #0
200249a2:	4608      	mov	r0, r1
200249a4:	f7ff ff02 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
200249a8:	2204      	movs	r2, #4
200249aa:	2100      	movs	r1, #0
200249ac:	2030      	movs	r0, #48	@ 0x30
200249ae:	fbb0 f0f5 	udiv	r0, r0, r5
200249b2:	f7ff ff1f 	bl	200247f4 <HAL_RCC_HCPU_SetDiv>
200249b6:	e7e1      	b.n	2002497c <HAL_RCC_HCPU_ConfigDvfs+0x34>
200249b8:	f7fd fd3a 	bl	20022430 <HAL_HPAON_EnableXT48>
200249bc:	4816      	ldr	r0, [pc, #88]	@ (20024a18 <HAL_RCC_HCPU_ConfigDvfs+0xd0>)
200249be:	4368      	muls	r0, r5
200249c0:	f7ff feb8 	bl	20024734 <HAL_RCC_HCPU_EnableDLL1>
200249c4:	4605      	mov	r5, r0
200249c6:	2800      	cmp	r0, #0
200249c8:	d1c8      	bne.n	2002495c <HAL_RCC_HCPU_ConfigDvfs+0x14>
200249ca:	2101      	movs	r1, #1
200249cc:	2206      	movs	r2, #6
200249ce:	4608      	mov	r0, r1
200249d0:	f7ff ff10 	bl	200247f4 <HAL_RCC_HCPU_SetDiv>
200249d4:	2103      	movs	r1, #3
200249d6:	4628      	mov	r0, r5
200249d8:	f7ff fee8 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
200249dc:	e7ce      	b.n	2002497c <HAL_RCC_HCPU_ConfigDvfs+0x34>
200249de:	2901      	cmp	r1, #1
200249e0:	d909      	bls.n	200249f6 <HAL_RCC_HCPU_ConfigDvfs+0xae>
200249e2:	4601      	mov	r1, r0
200249e4:	4620      	mov	r0, r4
200249e6:	f7ff ff2f 	bl	20024848 <HAL_RCC_HCPU_SwitchDvfsD2S>
200249ea:	4605      	mov	r5, r0
200249ec:	2000      	movs	r0, #0
200249ee:	7034      	strb	r4, [r6, #0]
200249f0:	f7fc ffff 	bl	200219f2 <HAL_Delay_us>
200249f4:	e7b3      	b.n	2002495e <HAL_RCC_HCPU_ConfigDvfs+0x16>
200249f6:	428b      	cmp	r3, r1
200249f8:	d103      	bne.n	20024a02 <HAL_RCC_HCPU_ConfigDvfs+0xba>
200249fa:	f04f 32ff 	mov.w	r2, #4294967295
200249fe:	4611      	mov	r1, r2
20024a00:	e7d4      	b.n	200249ac <HAL_RCC_HCPU_ConfigDvfs+0x64>
20024a02:	2190      	movs	r1, #144	@ 0x90
20024a04:	2002      	movs	r0, #2
20024a06:	f7ff ff1f 	bl	20024848 <HAL_RCC_HCPU_SwitchDvfsD2S>
20024a0a:	2800      	cmp	r0, #0
20024a0c:	d1a6      	bne.n	2002495c <HAL_RCC_HCPU_ConfigDvfs+0x14>
20024a0e:	e7b1      	b.n	20024974 <HAL_RCC_HCPU_ConfigDvfs+0x2c>
20024a10:	20042c18 	.word	0x20042c18
20024a14:	2002760c 	.word	0x2002760c
20024a18:	000f4240 	.word	0x000f4240

20024a1c <HAL_RCC_EnableModule>:
20024a1c:	1c43      	adds	r3, r0, #1
20024a1e:	d014      	beq.n	20024a4a <HAL_RCC_EnableModule+0x2e>
20024a20:	f010 0fe0 	tst.w	r0, #224	@ 0xe0
20024a24:	b282      	uxth	r2, r0
20024a26:	d000      	beq.n	20024a2a <HAL_RCC_EnableModule+0xe>
20024a28:	e7fe      	b.n	20024a28 <HAL_RCC_EnableModule+0xc>
20024a2a:	f410 6f40 	tst.w	r0, #3072	@ 0xc00
20024a2e:	f3c0 2181 	ubfx	r1, r0, #10, #2
20024a32:	f3c0 2301 	ubfx	r3, r0, #8, #2
20024a36:	b2d2      	uxtb	r2, r2
20024a38:	d108      	bne.n	20024a4c <HAL_RCC_EnableModule+0x30>
20024a3a:	009b      	lsls	r3, r3, #2
20024a3c:	f103 43a0 	add.w	r3, r3, #1342177280	@ 0x50000000
20024a40:	3310      	adds	r3, #16
20024a42:	2101      	movs	r1, #1
20024a44:	fa01 f202 	lsl.w	r2, r1, r2
20024a48:	601a      	str	r2, [r3, #0]
20024a4a:	4770      	bx	lr
20024a4c:	2901      	cmp	r1, #1
20024a4e:	d104      	bne.n	20024a5a <HAL_RCC_EnableModule+0x3e>
20024a50:	009b      	lsls	r3, r3, #2
20024a52:	f103 4380 	add.w	r3, r3, #1073741824	@ 0x40000000
20024a56:	3308      	adds	r3, #8
20024a58:	e7f3      	b.n	20024a42 <HAL_RCC_EnableModule+0x26>
20024a5a:	2902      	cmp	r1, #2
20024a5c:	d108      	bne.n	20024a70 <HAL_RCC_EnableModule+0x54>
20024a5e:	2301      	movs	r3, #1
20024a60:	4904      	ldr	r1, [pc, #16]	@ (20024a74 <HAL_RCC_EnableModule+0x58>)
20024a62:	4093      	lsls	r3, r2
20024a64:	f8d1 00ac 	ldr.w	r0, [r1, #172]	@ 0xac
20024a68:	4303      	orrs	r3, r0
20024a6a:	f8c1 30ac 	str.w	r3, [r1, #172]	@ 0xac
20024a6e:	4770      	bx	lr
20024a70:	e7fe      	b.n	20024a70 <HAL_RCC_EnableModule+0x54>
20024a72:	bf00      	nop
20024a74:	50002000 	.word	0x50002000

20024a78 <HAL_RCC_HCPU_ConfigHCLK>:
20024a78:	28f0      	cmp	r0, #240	@ 0xf0
20024a7a:	d80d      	bhi.n	20024a98 <HAL_RCC_HCPU_ConfigHCLK+0x20>
20024a7c:	2890      	cmp	r0, #144	@ 0x90
20024a7e:	d807      	bhi.n	20024a90 <HAL_RCC_HCPU_ConfigHCLK+0x18>
20024a80:	2830      	cmp	r0, #48	@ 0x30
20024a82:	d807      	bhi.n	20024a94 <HAL_RCC_HCPU_ConfigHCLK+0x1c>
20024a84:	2818      	cmp	r0, #24
20024a86:	bf94      	ite	ls
20024a88:	2100      	movls	r1, #0
20024a8a:	2101      	movhi	r1, #1
20024a8c:	f7ff bf5c 	b.w	20024948 <HAL_RCC_HCPU_ConfigDvfs>
20024a90:	2103      	movs	r1, #3
20024a92:	e7fb      	b.n	20024a8c <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024a94:	2102      	movs	r1, #2
20024a96:	e7f9      	b.n	20024a8c <HAL_RCC_HCPU_ConfigHCLK+0x14>
20024a98:	2001      	movs	r0, #1
20024a9a:	4770      	bx	lr

20024a9c <BSP_OTP_CFG_READ.part.0>:
20024a9c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024a9e:	4606      	mov	r6, r0
20024aa0:	2500      	movs	r5, #0
20024aa2:	4608      	mov	r0, r1
20024aa4:	9f06      	ldr	r7, [sp, #24]
20024aa6:	5d59      	ldrb	r1, [r3, r5]
20024aa8:	29ff      	cmp	r1, #255	@ 0xff
20024aaa:	d101      	bne.n	20024ab0 <BSP_OTP_CFG_READ.part.0+0x14>
20024aac:	2400      	movs	r4, #0
20024aae:	e013      	b.n	20024ad8 <BSP_OTP_CFG_READ.part.0+0x3c>
20024ab0:	195c      	adds	r4, r3, r5
20024ab2:	42b1      	cmp	r1, r6
20024ab4:	7864      	ldrb	r4, [r4, #1]
20024ab6:	d006      	beq.n	20024ac6 <BSP_OTP_CFG_READ.part.0+0x2a>
20024ab8:	1961      	adds	r1, r4, r5
20024aba:	3102      	adds	r1, #2
20024abc:	42b9      	cmp	r1, r7
20024abe:	daf5      	bge.n	20024aac <BSP_OTP_CFG_READ.part.0+0x10>
20024ac0:	3402      	adds	r4, #2
20024ac2:	4425      	add	r5, r4
20024ac4:	e7ef      	b.n	20024aa6 <BSP_OTP_CFG_READ.part.0+0xa>
20024ac6:	b13c      	cbz	r4, 20024ad8 <BSP_OTP_CFG_READ.part.0+0x3c>
20024ac8:	4294      	cmp	r4, r2
20024aca:	bfa8      	it	ge
20024acc:	4614      	movge	r4, r2
20024ace:	3502      	adds	r5, #2
20024ad0:	4622      	mov	r2, r4
20024ad2:	1959      	adds	r1, r3, r5
20024ad4:	f001 fc2d 	bl	20026332 <memcpy>
20024ad8:	b2e0      	uxtb	r0, r4
20024ada:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}

20024adc <BSP_OTP_CFG_READ>:
20024adc:	b410      	push	{r4}
20024ade:	b11b      	cbz	r3, 20024ae8 <BSP_OTP_CFG_READ+0xc>
20024ae0:	f85d 4b04 	ldr.w	r4, [sp], #4
20024ae4:	f7ff bfda 	b.w	20024a9c <BSP_OTP_CFG_READ.part.0>
20024ae8:	4618      	mov	r0, r3
20024aea:	f85d 4b04 	ldr.w	r4, [sp], #4
20024aee:	4770      	bx	lr

20024af0 <BSP_OTP_ReadCfg>:
20024af0:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024af2:	9f08      	ldr	r7, [sp, #32]
20024af4:	4604      	mov	r4, r0
20024af6:	9700      	str	r7, [sp, #0]
20024af8:	460d      	mov	r5, r1
20024afa:	4616      	mov	r6, r2
20024afc:	f7ff ffee 	bl	20024adc <BSP_OTP_CFG_READ>
20024b00:	b998      	cbnz	r0, 20024b2a <BSP_OTP_ReadCfg+0x3a>
20024b02:	f44f 7780 	mov.w	r7, #256	@ 0x100
20024b06:	4632      	mov	r2, r6
20024b08:	4629      	mov	r1, r5
20024b0a:	4620      	mov	r0, r4
20024b0c:	4b08      	ldr	r3, [pc, #32]	@ (20024b30 <BSP_OTP_ReadCfg+0x40>)
20024b0e:	9700      	str	r7, [sp, #0]
20024b10:	f7ff ffc4 	bl	20024a9c <BSP_OTP_CFG_READ.part.0>
20024b14:	b948      	cbnz	r0, 20024b2a <BSP_OTP_ReadCfg+0x3a>
20024b16:	4632      	mov	r2, r6
20024b18:	4629      	mov	r1, r5
20024b1a:	4620      	mov	r0, r4
20024b1c:	4b05      	ldr	r3, [pc, #20]	@ (20024b34 <BSP_OTP_ReadCfg+0x44>)
20024b1e:	9708      	str	r7, [sp, #32]
20024b20:	b003      	add	sp, #12
20024b22:	e8bd 40f0 	ldmia.w	sp!, {r4, r5, r6, r7, lr}
20024b26:	f7ff bfb9 	b.w	20024a9c <BSP_OTP_CFG_READ.part.0>
20024b2a:	b003      	add	sp, #12
20024b2c:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024b2e:	bf00      	nop
20024b30:	2004cb6c 	.word	0x2004cb6c
20024b34:	2004ca6c 	.word	0x2004ca6c

20024b38 <BSP_GetFlashByAddr>:
20024b38:	f100 4370 	add.w	r3, r0, #4026531840	@ 0xf0000000
20024b3c:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20024b40:	d30c      	bcc.n	20024b5c <BSP_GetFlashByAddr+0x24>
20024b42:	f100 436e 	add.w	r3, r0, #3992977408	@ 0xee000000
20024b46:	f1b3 7f00 	cmp.w	r3, #33554432	@ 0x2000000
20024b4a:	d309      	bcc.n	20024b60 <BSP_GetFlashByAddr+0x28>
20024b4c:	f100 406c 	add.w	r0, r0, #3959422976	@ 0xec000000
20024b50:	f1b0 6f40 	cmp.w	r0, #201326592	@ 0xc000000
20024b54:	4803      	ldr	r0, [pc, #12]	@ (20024b64 <BSP_GetFlashByAddr+0x2c>)
20024b56:	bf28      	it	cs
20024b58:	2000      	movcs	r0, #0
20024b5a:	4770      	bx	lr
20024b5c:	4802      	ldr	r0, [pc, #8]	@ (20024b68 <BSP_GetFlashByAddr+0x30>)
20024b5e:	4770      	bx	lr
20024b60:	4802      	ldr	r0, [pc, #8]	@ (20024b6c <BSP_GetFlashByAddr+0x34>)
20024b62:	4770      	bx	lr
20024b64:	50043000 	.word	0x50043000
20024b68:	50041000 	.word	0x50041000
20024b6c:	50042000 	.word	0x50042000

20024b70 <BSP_Get_UserOTP_Cache>:
20024b70:	4800      	ldr	r0, [pc, #0]	@ (20024b74 <BSP_Get_UserOTP_Cache+0x4>)
20024b72:	4770      	bx	lr
20024b74:	2004cb6c 	.word	0x2004cb6c

20024b78 <BSP_Get_CustOTP_Cache>:
20024b78:	4800      	ldr	r0, [pc, #0]	@ (20024b7c <BSP_Get_CustOTP_Cache+0x4>)
20024b7a:	4770      	bx	lr
20024b7c:	2004ca6c 	.word	0x2004ca6c

20024b80 <BSP_System_Config>:
20024b80:	b570      	push	{r4, r5, r6, lr}
20024b82:	b09c      	sub	sp, #112	@ 0x70
20024b84:	f7fd fbfa 	bl	2002237c <HAL_EFUSE_Init>
20024b88:	4604      	mov	r4, r0
20024b8a:	2800      	cmp	r0, #0
20024b8c:	d160      	bne.n	20024c50 <BSP_System_Config+0xd0>
20024b8e:	f7fc ff30 	bl	200219f2 <HAL_Delay_us>
20024b92:	200a      	movs	r0, #10
20024b94:	f7fc ff2d 	bl	200219f2 <HAL_Delay_us>
20024b98:	2220      	movs	r2, #32
20024b9a:	4621      	mov	r1, r4
20024b9c:	482e      	ldr	r0, [pc, #184]	@ (20024c58 <BSP_System_Config+0xd8>)
20024b9e:	f001 fb59 	bl	20026254 <memset>
20024ba2:	2220      	movs	r2, #32
20024ba4:	f44f 7080 	mov.w	r0, #256	@ 0x100
20024ba8:	492b      	ldr	r1, [pc, #172]	@ (20024c58 <BSP_System_Config+0xd8>)
20024baa:	f7fd fbe9 	bl	20022380 <HAL_EFUSE_Read>
20024bae:	2820      	cmp	r0, #32
20024bb0:	4605      	mov	r5, r0
20024bb2:	d14f      	bne.n	20024c54 <BSP_System_Config+0xd4>
20024bb4:	f7ff fcb4 	bl	20024520 <HAL_PMU_LoadCalData>
20024bb8:	f7fc fdde 	bl	20021778 <BSP_GetOtpBase>
20024bbc:	4606      	mov	r6, r0
20024bbe:	2240      	movs	r2, #64	@ 0x40
20024bc0:	4621      	mov	r1, r4
20024bc2:	a80c      	add	r0, sp, #48	@ 0x30
20024bc4:	f001 fb46 	bl	20026254 <memset>
20024bc8:	4630      	mov	r0, r6
20024bca:	f7ff ffb5 	bl	20024b38 <BSP_GetFlashByAddr>
20024bce:	900c      	str	r0, [sp, #48]	@ 0x30
20024bd0:	b900      	cbnz	r0, 20024bd4 <BSP_System_Config+0x54>
20024bd2:	e7fe      	b.n	20024bd2 <BSP_System_Config+0x52>
20024bd4:	a80c      	add	r0, sp, #48	@ 0x30
20024bd6:	f7fe f8ff 	bl	20022dd8 <HAL_FLASH_PreInit>
20024bda:	b100      	cbz	r0, 20024bde <BSP_System_Config+0x5e>
20024bdc:	e7fe      	b.n	20024bdc <BSP_System_Config+0x5c>
20024bde:	462b      	mov	r3, r5
20024be0:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
20024be4:	aa04      	add	r2, sp, #16
20024be6:	a80c      	add	r0, sp, #48	@ 0x30
20024be8:	f7fe f958 	bl	20022e9c <HAL_QSPI_READ_OTP>
20024bec:	2800      	cmp	r0, #0
20024bee:	dc00      	bgt.n	20024bf2 <BSP_System_Config+0x72>
20024bf0:	e7fe      	b.n	20024bf0 <BSP_System_Config+0x70>
20024bf2:	f7ff ffbd 	bl	20024b70 <BSP_Get_UserOTP_Cache>
20024bf6:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024bfa:	4602      	mov	r2, r0
20024bfc:	f44f 5100 	mov.w	r1, #8192	@ 0x2000
20024c00:	a80c      	add	r0, sp, #48	@ 0x30
20024c02:	f7fe f94b 	bl	20022e9c <HAL_QSPI_READ_OTP>
20024c06:	2800      	cmp	r0, #0
20024c08:	dc00      	bgt.n	20024c0c <BSP_System_Config+0x8c>
20024c0a:	e7fe      	b.n	20024c0a <BSP_System_Config+0x8a>
20024c0c:	f7ff ffb4 	bl	20024b78 <BSP_Get_CustOTP_Cache>
20024c10:	f44f 7380 	mov.w	r3, #256	@ 0x100
20024c14:	4602      	mov	r2, r0
20024c16:	f44f 5140 	mov.w	r1, #12288	@ 0x3000
20024c1a:	a80c      	add	r0, sp, #48	@ 0x30
20024c1c:	f7fe f93e 	bl	20022e9c <HAL_QSPI_READ_OTP>
20024c20:	2800      	cmp	r0, #0
20024c22:	dc00      	bgt.n	20024c26 <BSP_System_Config+0xa6>
20024c24:	e7fe      	b.n	20024c24 <BSP_System_Config+0xa4>
20024c26:	9000      	str	r0, [sp, #0]
20024c28:	2204      	movs	r2, #4
20024c2a:	2003      	movs	r0, #3
20024c2c:	ab04      	add	r3, sp, #16
20024c2e:	a903      	add	r1, sp, #12
20024c30:	f7ff ff5e 	bl	20024af0 <BSP_OTP_ReadCfg>
20024c34:	b910      	cbnz	r0, 20024c3c <BSP_System_Config+0xbc>
20024c36:	2000      	movs	r0, #0
20024c38:	b01c      	add	sp, #112	@ 0x70
20024c3a:	bd70      	pop	{r4, r5, r6, pc}
20024c3c:	9803      	ldr	r0, [sp, #12]
20024c3e:	2800      	cmp	r0, #0
20024c40:	d0f9      	beq.n	20024c36 <BSP_System_Config+0xb6>
20024c42:	f240 33ff 	movw	r3, #1023	@ 0x3ff
20024c46:	4298      	cmp	r0, r3
20024c48:	d0f5      	beq.n	20024c36 <BSP_System_Config+0xb6>
20024c4a:	f003 f901 	bl	20027e50 <BSP_HxtCbank_Config>
20024c4e:	e7f2      	b.n	20024c36 <BSP_System_Config+0xb6>
20024c50:	2001      	movs	r0, #1
20024c52:	e7f1      	b.n	20024c38 <BSP_System_Config+0xb8>
20024c54:	2002      	movs	r0, #2
20024c56:	e7ef      	b.n	20024c38 <BSP_System_Config+0xb8>
20024c58:	2004cc6c 	.word	0x2004cc6c

20024c5c <BSP_CONFIG_get>:
20024c5c:	b5f0      	push	{r4, r5, r6, r7, lr}
20024c5e:	4604      	mov	r4, r0
20024c60:	4610      	mov	r0, r2
20024c62:	b109      	cbz	r1, 20024c68 <BSP_CONFIG_get+0xc>
20024c64:	2a00      	cmp	r2, #0
20024c66:	dc01      	bgt.n	20024c6c <BSP_CONFIG_get+0x10>
20024c68:	2000      	movs	r0, #0
20024c6a:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024c6c:	4b56      	ldr	r3, [pc, #344]	@ (20024dc8 <BSP_CONFIG_get+0x16c>)
20024c6e:	781a      	ldrb	r2, [r3, #0]
20024c70:	2a00      	cmp	r2, #0
20024c72:	d0f9      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024c74:	2c04      	cmp	r4, #4
20024c76:	d152      	bne.n	20024d1e <BSP_CONFIG_get+0xc2>
20024c78:	280d      	cmp	r0, #13
20024c7a:	ddf5      	ble.n	20024c68 <BSP_CONFIG_get+0xc>
20024c7c:	795a      	ldrb	r2, [r3, #5]
20024c7e:	f893 c004 	ldrb.w	ip, [r3, #4]
20024c82:	0212      	lsls	r2, r2, #8
20024c84:	f402 6270 	and.w	r2, r2, #3840	@ 0xf00
20024c88:	ea4c 0c02 	orr.w	ip, ip, r2
20024c8c:	f8a1 c000 	strh.w	ip, [r1]
20024c90:	799d      	ldrb	r5, [r3, #6]
20024c92:	795a      	ldrb	r2, [r3, #5]
20024c94:	012d      	lsls	r5, r5, #4
20024c96:	f005 0510 	and.w	r5, r5, #16
20024c9a:	ea45 1512 	orr.w	r5, r5, r2, lsr #4
20024c9e:	808d      	strh	r5, [r1, #4]
20024ca0:	79df      	ldrb	r7, [r3, #7]
20024ca2:	799a      	ldrb	r2, [r3, #6]
20024ca4:	01ff      	lsls	r7, r7, #7
20024ca6:	f407 6778 	and.w	r7, r7, #3968	@ 0xf80
20024caa:	ea47 0752 	orr.w	r7, r7, r2, lsr #1
20024cae:	804f      	strh	r7, [r1, #2]
20024cb0:	7a1c      	ldrb	r4, [r3, #8]
20024cb2:	79da      	ldrb	r2, [r3, #7]
20024cb4:	00e4      	lsls	r4, r4, #3
20024cb6:	f004 0418 	and.w	r4, r4, #24
20024cba:	ea44 1452 	orr.w	r4, r4, r2, lsr #5
20024cbe:	80cc      	strh	r4, [r1, #6]
20024cc0:	7a5a      	ldrb	r2, [r3, #9]
20024cc2:	7a1e      	ldrb	r6, [r3, #8]
20024cc4:	0192      	lsls	r2, r2, #6
20024cc6:	f402 627c 	and.w	r2, r2, #4032	@ 0xfc0
20024cca:	ea42 0296 	orr.w	r2, r2, r6, lsr #2
20024cce:	810a      	strh	r2, [r1, #8]
20024cd0:	7a9e      	ldrb	r6, [r3, #10]
20024cd2:	7a5b      	ldrb	r3, [r3, #9]
20024cd4:	00b6      	lsls	r6, r6, #2
20024cd6:	f006 063c 	and.w	r6, r6, #60	@ 0x3c
20024cda:	ea46 1393 	orr.w	r3, r6, r3, lsr #6
20024cde:	eb05 0585 	add.w	r5, r5, r5, lsl #2
20024ce2:	eb04 0484 	add.w	r4, r4, r4, lsl #2
20024ce6:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024cea:	eb05 0585 	add.w	r5, r5, r5, lsl #2
20024cee:	eb04 0484 	add.w	r4, r4, r4, lsl #2
20024cf2:	eb03 0383 	add.w	r3, r3, r3, lsl #2
20024cf6:	00ad      	lsls	r5, r5, #2
20024cf8:	00a4      	lsls	r4, r4, #2
20024cfa:	009b      	lsls	r3, r3, #2
20024cfc:	808d      	strh	r5, [r1, #4]
20024cfe:	80cc      	strh	r4, [r1, #6]
20024d00:	814b      	strh	r3, [r1, #10]
20024d02:	f1bc 0f00 	cmp.w	ip, #0
20024d06:	d0af      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d08:	2d00      	cmp	r5, #0
20024d0a:	d0ad      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d0c:	2f00      	cmp	r7, #0
20024d0e:	d0ab      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d10:	2c00      	cmp	r4, #0
20024d12:	d0a9      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d14:	2a00      	cmp	r2, #0
20024d16:	d0a7      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d18:	2b00      	cmp	r3, #0
20024d1a:	d0a5      	beq.n	20024c68 <BSP_CONFIG_get+0xc>
20024d1c:	e7a5      	b.n	20024c6a <BSP_CONFIG_get+0xe>
20024d1e:	2c06      	cmp	r4, #6
20024d20:	d132      	bne.n	20024d88 <BSP_CONFIG_get+0x12c>
20024d22:	280e      	cmp	r0, #14
20024d24:	dda0      	ble.n	20024c68 <BSP_CONFIG_get+0xc>
20024d26:	f002 0207 	and.w	r2, r2, #7
20024d2a:	700a      	strb	r2, [r1, #0]
20024d2c:	781a      	ldrb	r2, [r3, #0]
20024d2e:	f3c2 04c0 	ubfx	r4, r2, #3, #1
20024d32:	704c      	strb	r4, [r1, #1]
20024d34:	785c      	ldrb	r4, [r3, #1]
20024d36:	0912      	lsrs	r2, r2, #4
20024d38:	f004 050f 	and.w	r5, r4, #15
20024d3c:	0924      	lsrs	r4, r4, #4
20024d3e:	708a      	strb	r2, [r1, #2]
20024d40:	70cd      	strb	r5, [r1, #3]
20024d42:	710c      	strb	r4, [r1, #4]
20024d44:	7b5c      	ldrb	r4, [r3, #13]
20024d46:	789e      	ldrb	r6, [r3, #2]
20024d48:	0924      	lsrs	r4, r4, #4
20024d4a:	730c      	strb	r4, [r1, #12]
20024d4c:	7b9d      	ldrb	r5, [r3, #14]
20024d4e:	f005 050f 	and.w	r5, r5, #15
20024d52:	734d      	strb	r5, [r1, #13]
20024d54:	0935      	lsrs	r5, r6, #4
20024d56:	718d      	strb	r5, [r1, #6]
20024d58:	78dd      	ldrb	r5, [r3, #3]
20024d5a:	f006 060f 	and.w	r6, r6, #15
20024d5e:	f005 070f 	and.w	r7, r5, #15
20024d62:	71cf      	strb	r7, [r1, #7]
20024d64:	7b5f      	ldrb	r7, [r3, #13]
20024d66:	092d      	lsrs	r5, r5, #4
20024d68:	f007 0707 	and.w	r7, r7, #7
20024d6c:	720f      	strb	r7, [r1, #8]
20024d6e:	7b5b      	ldrb	r3, [r3, #13]
20024d70:	738d      	strb	r5, [r1, #14]
20024d72:	f3c3 03c0 	ubfx	r3, r3, #3, #1
20024d76:	724b      	strb	r3, [r1, #9]
20024d78:	714e      	strb	r6, [r1, #5]
20024d7a:	2a00      	cmp	r2, #0
20024d7c:	f43f af74 	beq.w	20024c68 <BSP_CONFIG_get+0xc>
20024d80:	2c00      	cmp	r4, #0
20024d82:	f43f af71 	beq.w	20024c68 <BSP_CONFIG_get+0xc>
20024d86:	e770      	b.n	20024c6a <BSP_CONFIG_get+0xe>
20024d88:	2c15      	cmp	r4, #21
20024d8a:	f47f af6d 	bne.w	20024c68 <BSP_CONFIG_get+0xc>
20024d8e:	2807      	cmp	r0, #7
20024d90:	f77f af6a 	ble.w	20024c68 <BSP_CONFIG_get+0xc>
20024d94:	7a9a      	ldrb	r2, [r3, #10]
20024d96:	0912      	lsrs	r2, r2, #4
20024d98:	700a      	strb	r2, [r1, #0]
20024d9a:	7ada      	ldrb	r2, [r3, #11]
20024d9c:	f002 023f 	and.w	r2, r2, #63	@ 0x3f
20024da0:	704a      	strb	r2, [r1, #1]
20024da2:	7b1a      	ldrb	r2, [r3, #12]
20024da4:	7adc      	ldrb	r4, [r3, #11]
20024da6:	0092      	lsls	r2, r2, #2
20024da8:	f002 021c 	and.w	r2, r2, #28
20024dac:	ea42 1294 	orr.w	r2, r2, r4, lsr #6
20024db0:	708a      	strb	r2, [r1, #2]
20024db2:	7b1a      	ldrb	r2, [r3, #12]
20024db4:	08d2      	lsrs	r2, r2, #3
20024db6:	70ca      	strb	r2, [r1, #3]
20024db8:	7b9a      	ldrb	r2, [r3, #14]
20024dba:	7bdb      	ldrb	r3, [r3, #15]
20024dbc:	011b      	lsls	r3, r3, #4
20024dbe:	ea43 1312 	orr.w	r3, r3, r2, lsr #4
20024dc2:	710b      	strb	r3, [r1, #4]
20024dc4:	e751      	b.n	20024c6a <BSP_CONFIG_get+0xe>
20024dc6:	bf00      	nop
20024dc8:	2004cc6c 	.word	0x2004cc6c

20024dcc <spi_nor_get_ext_cfg_by_id>:
20024dcc:	2000      	movs	r0, #0
20024dce:	4770      	bx	lr

20024dd0 <spi_nor_get_user_flash_cfg>:
20024dd0:	2000      	movs	r0, #0
20024dd2:	4770      	bx	lr

20024dd4 <spi_flash_get_rdid>:
20024dd4:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024dd6:	4604      	mov	r4, r0
20024dd8:	3801      	subs	r0, #1
20024dda:	b2c0      	uxtb	r0, r0
20024ddc:	28fd      	cmp	r0, #253	@ 0xfd
20024dde:	d816      	bhi.n	20024e0e <spi_flash_get_rdid+0x3a>
20024de0:	2500      	movs	r5, #0
20024de2:	4e0d      	ldr	r6, [pc, #52]	@ (20024e18 <spi_flash_get_rdid+0x44>)
20024de4:	f856 0b04 	ldr.w	r0, [r6], #4
20024de8:	7807      	ldrb	r7, [r0, #0]
20024dea:	b937      	cbnz	r7, 20024dfa <spi_flash_get_rdid+0x26>
20024dec:	3501      	adds	r5, #1
20024dee:	2d06      	cmp	r5, #6
20024df0:	d1f8      	bne.n	20024de4 <spi_flash_get_rdid+0x10>
20024df2:	4620      	mov	r0, r4
20024df4:	f7ff ffec 	bl	20024dd0 <spi_nor_get_user_flash_cfg>
20024df8:	e00d      	b.n	20024e16 <spi_flash_get_rdid+0x42>
20024dfa:	42a7      	cmp	r7, r4
20024dfc:	d105      	bne.n	20024e0a <spi_flash_get_rdid+0x36>
20024dfe:	7847      	ldrb	r7, [r0, #1]
20024e00:	4297      	cmp	r7, r2
20024e02:	d102      	bne.n	20024e0a <spi_flash_get_rdid+0x36>
20024e04:	7887      	ldrb	r7, [r0, #2]
20024e06:	428f      	cmp	r7, r1
20024e08:	d003      	beq.n	20024e12 <spi_flash_get_rdid+0x3e>
20024e0a:	3008      	adds	r0, #8
20024e0c:	e7ec      	b.n	20024de8 <spi_flash_get_rdid+0x14>
20024e0e:	2000      	movs	r0, #0
20024e10:	e001      	b.n	20024e16 <spi_flash_get_rdid+0x42>
20024e12:	b103      	cbz	r3, 20024e16 <spi_flash_get_rdid+0x42>
20024e14:	701d      	strb	r5, [r3, #0]
20024e16:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024e18:	20042c1c 	.word	0x20042c1c

20024e1c <spi_flash_get_cmd_by_id>:
20024e1c:	b507      	push	{r0, r1, r2, lr}
20024e1e:	f10d 0307 	add.w	r3, sp, #7
20024e22:	f7ff ffd7 	bl	20024dd4 <spi_flash_get_rdid>
20024e26:	4b06      	ldr	r3, [pc, #24]	@ (20024e40 <spi_flash_get_cmd_by_id+0x24>)
20024e28:	b140      	cbz	r0, 20024e3c <spi_flash_get_cmd_by_id+0x20>
20024e2a:	f44f 7105 	mov.w	r1, #532	@ 0x214
20024e2e:	f89d 2007 	ldrb.w	r2, [sp, #7]
20024e32:	fb01 3002 	mla	r0, r1, r2, r3
20024e36:	b003      	add	sp, #12
20024e38:	f85d fb04 	ldr.w	pc, [sp], #4
20024e3c:	4618      	mov	r0, r3
20024e3e:	e7fa      	b.n	20024e36 <spi_flash_get_cmd_by_id+0x1a>
20024e40:	20042e64 	.word	0x20042e64

20024e44 <spi_flash_get_size_by_id>:
20024e44:	b508      	push	{r3, lr}
20024e46:	2300      	movs	r3, #0
20024e48:	f7ff ffc4 	bl	20024dd4 <spi_flash_get_rdid>
20024e4c:	b108      	cbz	r0, 20024e52 <spi_flash_get_size_by_id+0xe>
20024e4e:	6840      	ldr	r0, [r0, #4]
20024e50:	bd08      	pop	{r3, pc}
20024e52:	f44f 2000 	mov.w	r0, #524288	@ 0x80000
20024e56:	e7fb      	b.n	20024e50 <spi_flash_get_size_by_id+0xc>

20024e58 <spi_flash_is_support_dtr>:
20024e58:	b508      	push	{r3, lr}
20024e5a:	2300      	movs	r3, #0
20024e5c:	f7ff ffba 	bl	20024dd4 <spi_flash_get_rdid>
20024e60:	b110      	cbz	r0, 20024e68 <spi_flash_is_support_dtr+0x10>
20024e62:	78c0      	ldrb	r0, [r0, #3]
20024e64:	f000 0001 	and.w	r0, r0, #1
20024e68:	bd08      	pop	{r3, pc}
	...

20024e6c <spi_flash_get_otp_base>:
20024e6c:	b508      	push	{r3, lr}
20024e6e:	2300      	movs	r3, #0
20024e70:	f7ff ffb0 	bl	20024dd4 <spi_flash_get_rdid>
20024e74:	b130      	cbz	r0, 20024e84 <spi_flash_get_otp_base+0x18>
20024e76:	78c3      	ldrb	r3, [r0, #3]
20024e78:	4803      	ldr	r0, [pc, #12]	@ (20024e88 <spi_flash_get_otp_base+0x1c>)
20024e7a:	f003 0306 	and.w	r3, r3, #6
20024e7e:	2b02      	cmp	r3, #2
20024e80:	bf18      	it	ne
20024e82:	2000      	movne	r0, #0
20024e84:	bd08      	pop	{r3, pc}
20024e86:	bf00      	nop
20024e88:	00ffc000 	.word	0x00ffc000

20024e8c <spi_nand_get_user_flash_cfg>:
20024e8c:	2000      	movs	r0, #0
20024e8e:	4770      	bx	lr

20024e90 <spi_nand_get_rdid>:
20024e90:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20024e92:	4604      	mov	r4, r0
20024e94:	3801      	subs	r0, #1
20024e96:	b2c0      	uxtb	r0, r0
20024e98:	28fd      	cmp	r0, #253	@ 0xfd
20024e9a:	d816      	bhi.n	20024eca <spi_nand_get_rdid+0x3a>
20024e9c:	2500      	movs	r5, #0
20024e9e:	4e0d      	ldr	r6, [pc, #52]	@ (20024ed4 <spi_nand_get_rdid+0x44>)
20024ea0:	f856 0b04 	ldr.w	r0, [r6], #4
20024ea4:	7807      	ldrb	r7, [r0, #0]
20024ea6:	b937      	cbnz	r7, 20024eb6 <spi_nand_get_rdid+0x26>
20024ea8:	3501      	adds	r5, #1
20024eaa:	2d06      	cmp	r5, #6
20024eac:	d1f8      	bne.n	20024ea0 <spi_nand_get_rdid+0x10>
20024eae:	4620      	mov	r0, r4
20024eb0:	f7ff ffec 	bl	20024e8c <spi_nand_get_user_flash_cfg>
20024eb4:	e00d      	b.n	20024ed2 <spi_nand_get_rdid+0x42>
20024eb6:	42a7      	cmp	r7, r4
20024eb8:	d105      	bne.n	20024ec6 <spi_nand_get_rdid+0x36>
20024eba:	7847      	ldrb	r7, [r0, #1]
20024ebc:	4297      	cmp	r7, r2
20024ebe:	d102      	bne.n	20024ec6 <spi_nand_get_rdid+0x36>
20024ec0:	7887      	ldrb	r7, [r0, #2]
20024ec2:	428f      	cmp	r7, r1
20024ec4:	d003      	beq.n	20024ece <spi_nand_get_rdid+0x3e>
20024ec6:	3008      	adds	r0, #8
20024ec8:	e7ec      	b.n	20024ea4 <spi_nand_get_rdid+0x14>
20024eca:	2000      	movs	r0, #0
20024ecc:	e001      	b.n	20024ed2 <spi_nand_get_rdid+0x42>
20024ece:	b103      	cbz	r3, 20024ed2 <spi_nand_get_rdid+0x42>
20024ed0:	701d      	strb	r5, [r3, #0]
20024ed2:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20024ed4:	20043adc 	.word	0x20043adc

20024ed8 <spi_nand_get_cmd_by_id>:
20024ed8:	b507      	push	{r0, r1, r2, lr}
20024eda:	f10d 0307 	add.w	r3, sp, #7
20024ede:	f7ff ffd7 	bl	20024e90 <spi_nand_get_rdid>
20024ee2:	b130      	cbz	r0, 20024ef2 <spi_nand_get_cmd_by_id+0x1a>
20024ee4:	f44f 7205 	mov.w	r2, #532	@ 0x214
20024ee8:	f89d 3007 	ldrb.w	r3, [sp, #7]
20024eec:	4802      	ldr	r0, [pc, #8]	@ (20024ef8 <spi_nand_get_cmd_by_id+0x20>)
20024eee:	fb02 0003 	mla	r0, r2, r3, r0
20024ef2:	b003      	add	sp, #12
20024ef4:	f85d fb04 	ldr.w	pc, [sp], #4
20024ef8:	20043d24 	.word	0x20043d24

20024efc <spi_nand_get_ext_cfg_by_id>:
20024efc:	2000      	movs	r0, #0
20024efe:	4770      	bx	lr

20024f00 <HAL_GET_NAND_FLASH_DEFAUT_IDX>:
20024f00:	f04f 30ff 	mov.w	r0, #4294967295
20024f04:	4770      	bx	lr
	...

20024f08 <spi_nand_get_default_ctable>:
20024f08:	b508      	push	{r3, lr}
20024f0a:	f7ff fff9 	bl	20024f00 <HAL_GET_NAND_FLASH_DEFAUT_IDX>
20024f0e:	1e03      	subs	r3, r0, #0
20024f10:	bfa5      	ittet	ge
20024f12:	f44f 7205 	movge.w	r2, #532	@ 0x214
20024f16:	4802      	ldrge	r0, [pc, #8]	@ (20024f20 <spi_nand_get_default_ctable+0x18>)
20024f18:	2000      	movlt	r0, #0
20024f1a:	fb02 0003 	mlage	r0, r2, r3, r0
20024f1e:	bd08      	pop	{r3, pc}
20024f20:	20043d24 	.word	0x20043d24

20024f24 <spi_nand_get_size_by_id>:
20024f24:	b508      	push	{r3, lr}
20024f26:	2300      	movs	r3, #0
20024f28:	f7ff ffb2 	bl	20024e90 <spi_nand_get_rdid>
20024f2c:	b108      	cbz	r0, 20024f32 <spi_nand_get_size_by_id+0xe>
20024f2e:	6840      	ldr	r0, [r0, #4]
20024f30:	bd08      	pop	{r3, pc}
20024f32:	f04f 6080 	mov.w	r0, #67108864	@ 0x4000000
20024f36:	e7fb      	b.n	20024f30 <spi_nand_get_size_by_id+0xc>

20024f38 <spi_nand_get_plane_select_flag>:
20024f38:	b508      	push	{r3, lr}
20024f3a:	2300      	movs	r3, #0
20024f3c:	f7ff ffa8 	bl	20024e90 <spi_nand_get_rdid>
20024f40:	b110      	cbz	r0, 20024f48 <spi_nand_get_plane_select_flag+0x10>
20024f42:	78c0      	ldrb	r0, [r0, #3]
20024f44:	f3c0 0040 	ubfx	r0, r0, #1, #1
20024f48:	bd08      	pop	{r3, pc}

20024f4a <spi_nand_get_big_page_flag>:
20024f4a:	b508      	push	{r3, lr}
20024f4c:	2300      	movs	r3, #0
20024f4e:	f7ff ff9f 	bl	20024e90 <spi_nand_get_rdid>
20024f52:	b110      	cbz	r0, 20024f5a <spi_nand_get_big_page_flag+0x10>
20024f54:	78c0      	ldrb	r0, [r0, #3]
20024f56:	f3c0 0081 	ubfx	r0, r0, #2, #2
20024f5a:	bd08      	pop	{r3, pc}

20024f5c <spi_nand_get_ecc_mode>:
20024f5c:	b508      	push	{r3, lr}
20024f5e:	2300      	movs	r3, #0
20024f60:	f7ff ff96 	bl	20024e90 <spi_nand_get_rdid>
20024f64:	b108      	cbz	r0, 20024f6a <spi_nand_get_ecc_mode+0xe>
20024f66:	78c0      	ldrb	r0, [r0, #3]
20024f68:	0900      	lsrs	r0, r0, #4
20024f6a:	bd08      	pop	{r3, pc}

20024f6c <bbm_map_check.part.0>:
20024f6c:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
20024f6e:	4b21      	ldr	r3, [pc, #132]	@ (20024ff4 <bbm_map_check.part.0+0x88>)
20024f70:	4606      	mov	r6, r0
20024f72:	681d      	ldr	r5, [r3, #0]
20024f74:	4b20      	ldr	r3, [pc, #128]	@ (20024ff8 <bbm_map_check.part.0+0x8c>)
20024f76:	3d04      	subs	r5, #4
20024f78:	681f      	ldr	r7, [r3, #0]
20024f7a:	2300      	movs	r3, #0
20024f7c:	f100 0e1a 	add.w	lr, r0, #26
20024f80:	42ab      	cmp	r3, r5
20024f82:	db02      	blt.n	20024f8a <bbm_map_check.part.0+0x1e>
20024f84:	2000      	movs	r0, #0
20024f86:	b003      	add	sp, #12
20024f88:	bdf0      	pop	{r4, r5, r6, r7, pc}
20024f8a:	8b31      	ldrh	r1, [r6, #24]
20024f8c:	b321      	cbz	r1, 20024fd8 <bbm_map_check.part.0+0x6c>
20024f8e:	8b72      	ldrh	r2, [r6, #26]
20024f90:	b33a      	cbz	r2, 20024fe2 <bbm_map_check.part.0+0x76>
20024f92:	42b9      	cmp	r1, r7
20024f94:	d201      	bcs.n	20024f9a <bbm_map_check.part.0+0x2e>
20024f96:	4297      	cmp	r7, r2
20024f98:	d905      	bls.n	20024fa6 <bbm_map_check.part.0+0x3a>
20024f9a:	4b18      	ldr	r3, [pc, #96]	@ (20024ffc <bbm_map_check.part.0+0x90>)
20024f9c:	681b      	ldr	r3, [r3, #0]
20024f9e:	b10b      	cbz	r3, 20024fa4 <bbm_map_check.part.0+0x38>
20024fa0:	4817      	ldr	r0, [pc, #92]	@ (20025000 <bbm_map_check.part.0+0x94>)
20024fa2:	4798      	blx	r3
20024fa4:	e7fe      	b.n	20024fa4 <bbm_map_check.part.0+0x38>
20024fa6:	3301      	adds	r3, #1
20024fa8:	461c      	mov	r4, r3
20024faa:	42ac      	cmp	r4, r5
20024fac:	db01      	blt.n	20024fb2 <bbm_map_check.part.0+0x46>
20024fae:	3604      	adds	r6, #4
20024fb0:	e7e6      	b.n	20024f80 <bbm_map_check.part.0+0x14>
20024fb2:	f83e c024 	ldrh.w	ip, [lr, r4, lsl #2]
20024fb6:	f1bc 0f00 	cmp.w	ip, #0
20024fba:	d0f8      	beq.n	20024fae <bbm_map_check.part.0+0x42>
20024fbc:	4562      	cmp	r2, ip
20024fbe:	d109      	bne.n	20024fd4 <bbm_map_check.part.0+0x68>
20024fc0:	4b0e      	ldr	r3, [pc, #56]	@ (20024ffc <bbm_map_check.part.0+0x90>)
20024fc2:	681d      	ldr	r5, [r3, #0]
20024fc4:	b12d      	cbz	r5, 20024fd2 <bbm_map_check.part.0+0x66>
20024fc6:	3406      	adds	r4, #6
20024fc8:	f830 3024 	ldrh.w	r3, [r0, r4, lsl #2]
20024fcc:	480d      	ldr	r0, [pc, #52]	@ (20025004 <bbm_map_check.part.0+0x98>)
20024fce:	9200      	str	r2, [sp, #0]
20024fd0:	47a8      	blx	r5
20024fd2:	e7fe      	b.n	20024fd2 <bbm_map_check.part.0+0x66>
20024fd4:	3401      	adds	r4, #1
20024fd6:	e7e8      	b.n	20024faa <bbm_map_check.part.0+0x3e>
20024fd8:	eb00 0283 	add.w	r2, r0, r3, lsl #2
20024fdc:	8b52      	ldrh	r2, [r2, #26]
20024fde:	2a00      	cmp	r2, #0
20024fe0:	d0d0      	beq.n	20024f84 <bbm_map_check.part.0+0x18>
20024fe2:	4a06      	ldr	r2, [pc, #24]	@ (20024ffc <bbm_map_check.part.0+0x90>)
20024fe4:	6814      	ldr	r4, [r2, #0]
20024fe6:	b124      	cbz	r4, 20024ff2 <bbm_map_check.part.0+0x86>
20024fe8:	eb00 0383 	add.w	r3, r0, r3, lsl #2
20024fec:	8b5a      	ldrh	r2, [r3, #26]
20024fee:	4806      	ldr	r0, [pc, #24]	@ (20025008 <bbm_map_check.part.0+0x9c>)
20024ff0:	47a0      	blx	r4
20024ff2:	e7fe      	b.n	20024ff2 <bbm_map_check.part.0+0x86>
20024ff4:	2004cc9c 	.word	0x2004cc9c
20024ff8:	2004cca0 	.word	0x2004cca0
20024ffc:	2004cc8c 	.word	0x2004cc8c
20025000:	20026b38 	.word	0x20026b38
20025004:	20026b55 	.word	0x20026b55
20025008:	20026ba2 	.word	0x20026ba2

2002500c <bbm_crc_check>:
2002500c:	f04f 32ff 	mov.w	r2, #4294967295
20025010:	b510      	push	{r4, lr}
20025012:	4c07      	ldr	r4, [pc, #28]	@ (20025030 <bbm_crc_check+0x24>)
20025014:	4401      	add	r1, r0
20025016:	4288      	cmp	r0, r1
20025018:	d101      	bne.n	2002501e <bbm_crc_check+0x12>
2002501a:	43d0      	mvns	r0, r2
2002501c:	bd10      	pop	{r4, pc}
2002501e:	f810 3b01 	ldrb.w	r3, [r0], #1
20025022:	4053      	eors	r3, r2
20025024:	b2db      	uxtb	r3, r3
20025026:	f854 3023 	ldr.w	r3, [r4, r3, lsl #2]
2002502a:	ea83 2212 	eor.w	r2, r3, r2, lsr #8
2002502e:	e7f2      	b.n	20025016 <bbm_crc_check+0xa>
20025030:	2002763c 	.word	0x2002763c

20025034 <bbm_get_phy_blk>:
20025034:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20025036:	4b14      	ldr	r3, [pc, #80]	@ (20025088 <bbm_get_phy_blk+0x54>)
20025038:	4601      	mov	r1, r0
2002503a:	681e      	ldr	r6, [r3, #0]
2002503c:	42b0      	cmp	r0, r6
2002503e:	d21e      	bcs.n	2002507e <bbm_get_phy_blk+0x4a>
20025040:	b138      	cbz	r0, 20025052 <bbm_get_phy_blk+0x1e>
20025042:	4b12      	ldr	r3, [pc, #72]	@ (2002508c <bbm_get_phy_blk+0x58>)
20025044:	2200      	movs	r2, #0
20025046:	681c      	ldr	r4, [r3, #0]
20025048:	4b11      	ldr	r3, [pc, #68]	@ (20025090 <bbm_get_phy_blk+0x5c>)
2002504a:	3c04      	subs	r4, #4
2002504c:	461d      	mov	r5, r3
2002504e:	4294      	cmp	r4, r2
20025050:	dc00      	bgt.n	20025054 <bbm_get_phy_blk+0x20>
20025052:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20025054:	8b1f      	ldrh	r7, [r3, #24]
20025056:	428f      	cmp	r7, r1
20025058:	d10a      	bne.n	20025070 <bbm_get_phy_blk+0x3c>
2002505a:	eb05 0582 	add.w	r5, r5, r2, lsl #2
2002505e:	8b6a      	ldrh	r2, [r5, #26]
20025060:	4296      	cmp	r6, r2
20025062:	dd0f      	ble.n	20025084 <bbm_get_phy_blk+0x50>
20025064:	4b0b      	ldr	r3, [pc, #44]	@ (20025094 <bbm_get_phy_blk+0x60>)
20025066:	681b      	ldr	r3, [r3, #0]
20025068:	b10b      	cbz	r3, 2002506e <bbm_get_phy_blk+0x3a>
2002506a:	480b      	ldr	r0, [pc, #44]	@ (20025098 <bbm_get_phy_blk+0x64>)
2002506c:	4798      	blx	r3
2002506e:	e7fe      	b.n	2002506e <bbm_get_phy_blk+0x3a>
20025070:	b917      	cbnz	r7, 20025078 <bbm_get_phy_blk+0x44>
20025072:	8b5f      	ldrh	r7, [r3, #26]
20025074:	2f00      	cmp	r7, #0
20025076:	d0ec      	beq.n	20025052 <bbm_get_phy_blk+0x1e>
20025078:	3201      	adds	r2, #1
2002507a:	3304      	adds	r3, #4
2002507c:	e7e7      	b.n	2002504e <bbm_get_phy_blk+0x1a>
2002507e:	f04f 30ff 	mov.w	r0, #4294967295
20025082:	e7e6      	b.n	20025052 <bbm_get_phy_blk+0x1e>
20025084:	4610      	mov	r0, r2
20025086:	e7e4      	b.n	20025052 <bbm_get_phy_blk+0x1e>
20025088:	2004cca0 	.word	0x2004cca0
2002508c:	2004cc9c 	.word	0x2004cc9c
20025090:	2004cca4 	.word	0x2004cca4
20025094:	2004cc8c 	.word	0x2004cc8c
20025098:	20026bc0 	.word	0x20026bc0

2002509c <bbm_get_version_inblk>:
2002509c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
200250a0:	4607      	mov	r7, r0
200250a2:	4688      	mov	r8, r1
200250a4:	b087      	sub	sp, #28
200250a6:	2900      	cmp	r1, #0
200250a8:	d14b      	bne.n	20025142 <bbm_get_version_inblk+0xa6>
200250aa:	2500      	movs	r5, #0
200250ac:	4628      	mov	r0, r5
200250ae:	b007      	add	sp, #28
200250b0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
200250b4:	2200      	movs	r2, #0
200250b6:	e9cd 2201 	strd	r2, r2, [sp, #4]
200250ba:	4e26      	ldr	r6, [pc, #152]	@ (20025154 <bbm_get_version_inblk+0xb8>)
200250bc:	9100      	str	r1, [sp, #0]
200250be:	4638      	mov	r0, r7
200250c0:	4621      	mov	r1, r4
200250c2:	6833      	ldr	r3, [r6, #0]
200250c4:	f7fb fb80 	bl	200207c8 <port_read_page>
200250c8:	2800      	cmp	r0, #0
200250ca:	dd32      	ble.n	20025132 <bbm_get_version_inblk+0x96>
200250cc:	6832      	ldr	r2, [r6, #0]
200250ce:	6813      	ldr	r3, [r2, #0]
200250d0:	455b      	cmp	r3, fp
200250d2:	d123      	bne.n	2002511c <bbm_get_version_inblk+0x80>
200250d4:	6856      	ldr	r6, [r2, #4]
200250d6:	f3c6 061e 	ubfx	r6, r6, #0, #31
200250da:	42ae      	cmp	r6, r5
200250dc:	dd15      	ble.n	2002510a <bbm_get_version_inblk+0x6e>
200250de:	4610      	mov	r0, r2
200250e0:	2110      	movs	r1, #16
200250e2:	9205      	str	r2, [sp, #20]
200250e4:	f7ff ff92 	bl	2002500c <bbm_crc_check>
200250e8:	9a05      	ldr	r2, [sp, #20]
200250ea:	6913      	ldr	r3, [r2, #16]
200250ec:	4283      	cmp	r3, r0
200250ee:	d113      	bne.n	20025118 <bbm_get_version_inblk+0x7c>
200250f0:	f8c8 4000 	str.w	r4, [r8]
200250f4:	4635      	mov	r5, r6
200250f6:	3401      	adds	r4, #1
200250f8:	f8da 1000 	ldr.w	r1, [sl]
200250fc:	f8d9 3000 	ldr.w	r3, [r9]
20025100:	fbb3 f3f1 	udiv	r3, r3, r1
20025104:	42a3      	cmp	r3, r4
20025106:	d8d5      	bhi.n	200250b4 <bbm_get_version_inblk+0x18>
20025108:	e7d0      	b.n	200250ac <bbm_get_version_inblk+0x10>
2002510a:	4b13      	ldr	r3, [pc, #76]	@ (20025158 <bbm_get_version_inblk+0xbc>)
2002510c:	681b      	ldr	r3, [r3, #0]
2002510e:	b11b      	cbz	r3, 20025118 <bbm_get_version_inblk+0x7c>
20025110:	4632      	mov	r2, r6
20025112:	4629      	mov	r1, r5
20025114:	4811      	ldr	r0, [pc, #68]	@ (2002515c <bbm_get_version_inblk+0xc0>)
20025116:	4798      	blx	r3
20025118:	462e      	mov	r6, r5
2002511a:	e7eb      	b.n	200250f4 <bbm_get_version_inblk+0x58>
2002511c:	1c5a      	adds	r2, r3, #1
2002511e:	d0c5      	beq.n	200250ac <bbm_get_version_inblk+0x10>
20025120:	4a0d      	ldr	r2, [pc, #52]	@ (20025158 <bbm_get_version_inblk+0xbc>)
20025122:	6815      	ldr	r5, [r2, #0]
20025124:	2d00      	cmp	r5, #0
20025126:	d0c0      	beq.n	200250aa <bbm_get_version_inblk+0xe>
20025128:	4622      	mov	r2, r4
2002512a:	4639      	mov	r1, r7
2002512c:	480c      	ldr	r0, [pc, #48]	@ (20025160 <bbm_get_version_inblk+0xc4>)
2002512e:	47a8      	blx	r5
20025130:	e7bb      	b.n	200250aa <bbm_get_version_inblk+0xe>
20025132:	4b09      	ldr	r3, [pc, #36]	@ (20025158 <bbm_get_version_inblk+0xbc>)
20025134:	681b      	ldr	r3, [r3, #0]
20025136:	2b00      	cmp	r3, #0
20025138:	d0ee      	beq.n	20025118 <bbm_get_version_inblk+0x7c>
2002513a:	4622      	mov	r2, r4
2002513c:	4639      	mov	r1, r7
2002513e:	4809      	ldr	r0, [pc, #36]	@ (20025164 <bbm_get_version_inblk+0xc8>)
20025140:	e7e9      	b.n	20025116 <bbm_get_version_inblk+0x7a>
20025142:	2400      	movs	r4, #0
20025144:	f8df a020 	ldr.w	sl, [pc, #32]	@ 20025168 <bbm_get_version_inblk+0xcc>
20025148:	4625      	mov	r5, r4
2002514a:	f8df 9020 	ldr.w	r9, [pc, #32]	@ 2002516c <bbm_get_version_inblk+0xd0>
2002514e:	f8df b020 	ldr.w	fp, [pc, #32]	@ 20025170 <bbm_get_version_inblk+0xd4>
20025152:	e7d1      	b.n	200250f8 <bbm_get_version_inblk+0x5c>
20025154:	2004cc90 	.word	0x2004cc90
20025158:	2004cc8c 	.word	0x2004cc8c
2002515c:	20026bdf 	.word	0x20026bdf
20025160:	20026c0c 	.word	0x20026c0c
20025164:	20026c3d 	.word	0x20026c3d
20025168:	2004499c 	.word	0x2004499c
2002516c:	200449a0 	.word	0x200449a0
20025170:	5366424d 	.word	0x5366424d

20025174 <bbm_get_map_table>:
20025174:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025178:	2801      	cmp	r0, #1
2002517a:	4607      	mov	r7, r0
2002517c:	f8df b15c 	ldr.w	fp, [pc, #348]	@ 200252dc <bbm_get_map_table+0x168>
20025180:	b087      	sub	sp, #28
20025182:	dd0a      	ble.n	2002519a <bbm_get_map_table+0x26>
20025184:	f8db 3000 	ldr.w	r3, [fp]
20025188:	b91b      	cbnz	r3, 20025192 <bbm_get_map_table+0x1e>
2002518a:	2000      	movs	r0, #0
2002518c:	b007      	add	sp, #28
2002518e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025192:	4601      	mov	r1, r0
20025194:	4847      	ldr	r0, [pc, #284]	@ (200252b4 <bbm_get_map_table+0x140>)
20025196:	4798      	blx	r3
20025198:	e7f7      	b.n	2002518a <bbm_get_map_table+0x16>
2002519a:	f8df 8144 	ldr.w	r8, [pc, #324]	@ 200252e0 <bbm_get_map_table+0x16c>
2002519e:	2800      	cmp	r0, #0
200251a0:	d163      	bne.n	2002526a <bbm_get_map_table+0xf6>
200251a2:	f8b8 6000 	ldrh.w	r6, [r8]
200251a6:	f8b8 5002 	ldrh.w	r5, [r8, #2]
200251aa:	2e00      	cmp	r6, #0
200251ac:	d062      	beq.n	20025274 <bbm_get_map_table+0x100>
200251ae:	4630      	mov	r0, r6
200251b0:	a904      	add	r1, sp, #16
200251b2:	f7ff ff73 	bl	2002509c <bbm_get_version_inblk>
200251b6:	4681      	mov	r9, r0
200251b8:	2d00      	cmp	r5, #0
200251ba:	d05d      	beq.n	20025278 <bbm_get_map_table+0x104>
200251bc:	4628      	mov	r0, r5
200251be:	a905      	add	r1, sp, #20
200251c0:	f7ff ff6c 	bl	2002509c <bbm_get_version_inblk>
200251c4:	4604      	mov	r4, r0
200251c6:	f8db a000 	ldr.w	sl, [fp]
200251ca:	f1ba 0f00 	cmp.w	sl, #0
200251ce:	d005      	beq.n	200251dc <bbm_get_map_table+0x68>
200251d0:	4623      	mov	r3, r4
200251d2:	4632      	mov	r2, r6
200251d4:	4649      	mov	r1, r9
200251d6:	4838      	ldr	r0, [pc, #224]	@ (200252b8 <bbm_get_map_table+0x144>)
200251d8:	9500      	str	r5, [sp, #0]
200251da:	47d0      	blx	sl
200251dc:	45a1      	cmp	r9, r4
200251de:	d0d4      	beq.n	2002518a <bbm_get_map_table+0x16>
200251e0:	f04f 0200 	mov.w	r2, #0
200251e4:	bf98      	it	ls
200251e6:	462e      	movls	r6, r5
200251e8:	f107 0308 	add.w	r3, r7, #8
200251ec:	bf94      	ite	ls
200251ee:	f828 5013 	strhls.w	r5, [r8, r3, lsl #1]
200251f2:	f828 6013 	strhhi.w	r6, [r8, r3, lsl #1]
200251f6:	e9cd 2201 	strd	r2, r2, [sp, #4]
200251fa:	4b30      	ldr	r3, [pc, #192]	@ (200252bc <bbm_get_map_table+0x148>)
200251fc:	bf88      	it	hi
200251fe:	f8dd a010 	ldrhi.w	sl, [sp, #16]
20025202:	681b      	ldr	r3, [r3, #0]
20025204:	bf98      	it	ls
20025206:	f8dd a014 	ldrls.w	sl, [sp, #20]
2002520a:	f8df 80d8 	ldr.w	r8, [pc, #216]	@ 200252e4 <bbm_get_map_table+0x170>
2002520e:	9300      	str	r3, [sp, #0]
20025210:	4651      	mov	r1, sl
20025212:	4630      	mov	r0, r6
20025214:	f8d8 3000 	ldr.w	r3, [r8]
20025218:	bf88      	it	hi
2002521a:	464c      	movhi	r4, r9
2002521c:	f7fb fad4 	bl	200207c8 <port_read_page>
20025220:	2800      	cmp	r0, #0
20025222:	f8db 5000 	ldr.w	r5, [fp]
20025226:	dd38      	ble.n	2002529a <bbm_get_map_table+0x126>
20025228:	f8d8 8000 	ldr.w	r8, [r8]
2002522c:	4b24      	ldr	r3, [pc, #144]	@ (200252c0 <bbm_get_map_table+0x14c>)
2002522e:	f8d8 2000 	ldr.w	r2, [r8]
20025232:	429a      	cmp	r2, r3
20025234:	d12b      	bne.n	2002528e <bbm_get_map_table+0x11a>
20025236:	2110      	movs	r1, #16
20025238:	4640      	mov	r0, r8
2002523a:	f7ff fee7 	bl	2002500c <bbm_crc_check>
2002523e:	f8d8 2010 	ldr.w	r2, [r8, #16]
20025242:	4601      	mov	r1, r0
20025244:	4282      	cmp	r2, r0
20025246:	d11e      	bne.n	20025286 <bbm_get_map_table+0x112>
20025248:	f8d8 1004 	ldr.w	r1, [r8, #4]
2002524c:	f3c1 011e 	ubfx	r1, r1, #0, #31
20025250:	42a1      	cmp	r1, r4
20025252:	d113      	bne.n	2002527c <bbm_get_map_table+0x108>
20025254:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025258:	481a      	ldr	r0, [pc, #104]	@ (200252c4 <bbm_get_map_table+0x150>)
2002525a:	4641      	mov	r1, r8
2002525c:	fb02 0007 	mla	r0, r2, r7, r0
20025260:	f001 f867 	bl	20026332 <memcpy>
20025264:	bb0d      	cbnz	r5, 200252aa <bbm_get_map_table+0x136>
20025266:	4620      	mov	r0, r4
20025268:	e790      	b.n	2002518c <bbm_get_map_table+0x18>
2002526a:	f8b8 6004 	ldrh.w	r6, [r8, #4]
2002526e:	f8b8 5006 	ldrh.w	r5, [r8, #6]
20025272:	e79a      	b.n	200251aa <bbm_get_map_table+0x36>
20025274:	46b1      	mov	r9, r6
20025276:	e79f      	b.n	200251b8 <bbm_get_map_table+0x44>
20025278:	462c      	mov	r4, r5
2002527a:	e7a4      	b.n	200251c6 <bbm_get_map_table+0x52>
2002527c:	b115      	cbz	r5, 20025284 <bbm_get_map_table+0x110>
2002527e:	4622      	mov	r2, r4
20025280:	4811      	ldr	r0, [pc, #68]	@ (200252c8 <bbm_get_map_table+0x154>)
20025282:	47a8      	blx	r5
20025284:	e7fe      	b.n	20025284 <bbm_get_map_table+0x110>
20025286:	b10d      	cbz	r5, 2002528c <bbm_get_map_table+0x118>
20025288:	4810      	ldr	r0, [pc, #64]	@ (200252cc <bbm_get_map_table+0x158>)
2002528a:	47a8      	blx	r5
2002528c:	e7fe      	b.n	2002528c <bbm_get_map_table+0x118>
2002528e:	b11d      	cbz	r5, 20025298 <bbm_get_map_table+0x124>
20025290:	4652      	mov	r2, sl
20025292:	4631      	mov	r1, r6
20025294:	480e      	ldr	r0, [pc, #56]	@ (200252d0 <bbm_get_map_table+0x15c>)
20025296:	47a8      	blx	r5
20025298:	e7fe      	b.n	20025298 <bbm_get_map_table+0x124>
2002529a:	2d00      	cmp	r5, #0
2002529c:	f43f af75 	beq.w	2002518a <bbm_get_map_table+0x16>
200252a0:	4652      	mov	r2, sl
200252a2:	4631      	mov	r1, r6
200252a4:	480b      	ldr	r0, [pc, #44]	@ (200252d4 <bbm_get_map_table+0x160>)
200252a6:	47a8      	blx	r5
200252a8:	e76f      	b.n	2002518a <bbm_get_map_table+0x16>
200252aa:	4621      	mov	r1, r4
200252ac:	480a      	ldr	r0, [pc, #40]	@ (200252d8 <bbm_get_map_table+0x164>)
200252ae:	47a8      	blx	r5
200252b0:	e7d9      	b.n	20025266 <bbm_get_map_table+0xf2>
200252b2:	bf00      	nop
200252b4:	20026c5b 	.word	0x20026c5b
200252b8:	20026c6f 	.word	0x20026c6f
200252bc:	2004499c 	.word	0x2004499c
200252c0:	5366424d 	.word	0x5366424d
200252c4:	2004cca4 	.word	0x2004cca4
200252c8:	20026c95 	.word	0x20026c95
200252cc:	20026cdf 	.word	0x20026cdf
200252d0:	20026cf1 	.word	0x20026cf1
200252d4:	20026d26 	.word	0x20026d26
200252d8:	20026d52 	.word	0x20026d52
200252dc:	2004cc8c 	.word	0x2004cc8c
200252e0:	2004d0b4 	.word	0x2004d0b4
200252e4:	2004cc90 	.word	0x2004cc90

200252e8 <bbm_get_page_num>:
200252e8:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200252ec:	4605      	mov	r5, r0
200252ee:	2400      	movs	r4, #0
200252f0:	4f13      	ldr	r7, [pc, #76]	@ (20025340 <bbm_get_page_num+0x58>)
200252f2:	4e14      	ldr	r6, [pc, #80]	@ (20025344 <bbm_get_page_num+0x5c>)
200252f4:	f8df 8050 	ldr.w	r8, [pc, #80]	@ 20025348 <bbm_get_page_num+0x60>
200252f8:	b085      	sub	sp, #20
200252fa:	6839      	ldr	r1, [r7, #0]
200252fc:	6833      	ldr	r3, [r6, #0]
200252fe:	fbb3 f3f1 	udiv	r3, r3, r1
20025302:	42a3      	cmp	r3, r4
20025304:	d802      	bhi.n	2002530c <bbm_get_page_num+0x24>
20025306:	f04f 34ff 	mov.w	r4, #4294967295
2002530a:	e015      	b.n	20025338 <bbm_get_page_num+0x50>
2002530c:	2200      	movs	r2, #0
2002530e:	e9cd 2201 	strd	r2, r2, [sp, #4]
20025312:	f8df 9038 	ldr.w	r9, [pc, #56]	@ 2002534c <bbm_get_page_num+0x64>
20025316:	9100      	str	r1, [sp, #0]
20025318:	4628      	mov	r0, r5
2002531a:	4621      	mov	r1, r4
2002531c:	f8d9 3000 	ldr.w	r3, [r9]
20025320:	f7fb fa52 	bl	200207c8 <port_read_page>
20025324:	b120      	cbz	r0, 20025330 <bbm_get_page_num+0x48>
20025326:	f8d9 3000 	ldr.w	r3, [r9]
2002532a:	681b      	ldr	r3, [r3, #0]
2002532c:	4543      	cmp	r3, r8
2002532e:	d101      	bne.n	20025334 <bbm_get_page_num+0x4c>
20025330:	3401      	adds	r4, #1
20025332:	e7e2      	b.n	200252fa <bbm_get_page_num+0x12>
20025334:	3301      	adds	r3, #1
20025336:	d1fb      	bne.n	20025330 <bbm_get_page_num+0x48>
20025338:	4620      	mov	r0, r4
2002533a:	b005      	add	sp, #20
2002533c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20025340:	2004499c 	.word	0x2004499c
20025344:	200449a0 	.word	0x200449a0
20025348:	5366424d 	.word	0x5366424d
2002534c:	2004cc90 	.word	0x2004cc90

20025350 <bbm_read_page>:
20025350:	b5f0      	push	{r4, r5, r6, r7, lr}
20025352:	4604      	mov	r4, r0
20025354:	b085      	sub	sp, #20
20025356:	b280      	uxth	r0, r0
20025358:	461f      	mov	r7, r3
2002535a:	460d      	mov	r5, r1
2002535c:	4616      	mov	r6, r2
2002535e:	f7ff fe69 	bl	20025034 <bbm_get_phy_blk>
20025362:	1c43      	adds	r3, r0, #1
20025364:	d108      	bne.n	20025378 <bbm_read_page+0x28>
20025366:	4b0a      	ldr	r3, [pc, #40]	@ (20025390 <bbm_read_page+0x40>)
20025368:	681b      	ldr	r3, [r3, #0]
2002536a:	b113      	cbz	r3, 20025372 <bbm_read_page+0x22>
2002536c:	4621      	mov	r1, r4
2002536e:	4809      	ldr	r0, [pc, #36]	@ (20025394 <bbm_read_page+0x44>)
20025370:	4798      	blx	r3
20025372:	2000      	movs	r0, #0
20025374:	b005      	add	sp, #20
20025376:	bdf0      	pop	{r4, r5, r6, r7, pc}
20025378:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
2002537a:	4632      	mov	r2, r6
2002537c:	9302      	str	r3, [sp, #8]
2002537e:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
20025380:	4629      	mov	r1, r5
20025382:	9301      	str	r3, [sp, #4]
20025384:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
20025386:	9300      	str	r3, [sp, #0]
20025388:	463b      	mov	r3, r7
2002538a:	f7fb fa1d 	bl	200207c8 <port_read_page>
2002538e:	e7f1      	b.n	20025374 <bbm_read_page+0x24>
20025390:	2004cc8c 	.word	0x2004cc8c
20025394:	20026d65 	.word	0x20026d65

20025398 <port_write_page>:
20025398:	4b01      	ldr	r3, [pc, #4]	@ (200253a0 <port_write_page+0x8>)
2002539a:	6818      	ldr	r0, [r3, #0]
2002539c:	4770      	bx	lr
2002539e:	bf00      	nop
200253a0:	2004499c 	.word	0x2004499c

200253a4 <bbm_write_talbe.isra.0>:
200253a4:	b5f7      	push	{r0, r1, r2, r4, r5, r6, r7, lr}
200253a6:	4604      	mov	r4, r0
200253a8:	4608      	mov	r0, r1
200253aa:	460e      	mov	r6, r1
200253ac:	f7ff ff9c 	bl	200252e8 <bbm_get_page_num>
200253b0:	1e05      	subs	r5, r0, #0
200253b2:	db25      	blt.n	20025400 <bbm_write_talbe.isra.0+0x5c>
200253b4:	4b13      	ldr	r3, [pc, #76]	@ (20025404 <bbm_write_talbe.isra.0+0x60>)
200253b6:	681a      	ldr	r2, [r3, #0]
200253b8:	4b13      	ldr	r3, [pc, #76]	@ (20025408 <bbm_write_talbe.isra.0+0x64>)
200253ba:	681b      	ldr	r3, [r3, #0]
200253bc:	fbb3 f3f2 	udiv	r3, r3, r2
200253c0:	429d      	cmp	r5, r3
200253c2:	da1d      	bge.n	20025400 <bbm_write_talbe.isra.0+0x5c>
200253c4:	4f11      	ldr	r7, [pc, #68]	@ (2002540c <bbm_write_talbe.isra.0+0x68>)
200253c6:	21ff      	movs	r1, #255	@ 0xff
200253c8:	6838      	ldr	r0, [r7, #0]
200253ca:	f000 ff43 	bl	20026254 <memset>
200253ce:	4264      	negs	r4, r4
200253d0:	490f      	ldr	r1, [pc, #60]	@ (20025410 <bbm_write_talbe.isra.0+0x6c>)
200253d2:	f404 7402 	and.w	r4, r4, #520	@ 0x208
200253d6:	f44f 7202 	mov.w	r2, #520	@ 0x208
200253da:	6838      	ldr	r0, [r7, #0]
200253dc:	4421      	add	r1, r4
200253de:	f000 ffa8 	bl	20026332 <memcpy>
200253e2:	6838      	ldr	r0, [r7, #0]
200253e4:	b160      	cbz	r0, 20025400 <bbm_write_talbe.isra.0+0x5c>
200253e6:	6802      	ldr	r2, [r0, #0]
200253e8:	4b0a      	ldr	r3, [pc, #40]	@ (20025414 <bbm_write_talbe.isra.0+0x70>)
200253ea:	429a      	cmp	r2, r3
200253ec:	d108      	bne.n	20025400 <bbm_write_talbe.isra.0+0x5c>
200253ee:	f7ff fdbd 	bl	20024f6c <bbm_map_check.part.0>
200253f2:	2300      	movs	r3, #0
200253f4:	9300      	str	r3, [sp, #0]
200253f6:	4629      	mov	r1, r5
200253f8:	4630      	mov	r0, r6
200253fa:	683a      	ldr	r2, [r7, #0]
200253fc:	f7ff ffcc 	bl	20025398 <port_write_page>
20025400:	b003      	add	sp, #12
20025402:	bdf0      	pop	{r4, r5, r6, r7, pc}
20025404:	2004499c 	.word	0x2004499c
20025408:	200449a0 	.word	0x200449a0
2002540c:	2004cc90 	.word	0x2004cc90
20025410:	2004cca4 	.word	0x2004cca4
20025414:	5366424d 	.word	0x5366424d

20025418 <port_erase_block>:
20025418:	2000      	movs	r0, #0
2002541a:	4770      	bx	lr

2002541c <bbm_init_table>:
2002541c:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025420:	4c7c      	ldr	r4, [pc, #496]	@ (20025614 <bbm_init_table+0x1f8>)
20025422:	4b7d      	ldr	r3, [pc, #500]	@ (20025618 <bbm_init_table+0x1fc>)
20025424:	6822      	ldr	r2, [r4, #0]
20025426:	b085      	sub	sp, #20
20025428:	429a      	cmp	r2, r3
2002542a:	f000 80ed 	beq.w	20025608 <bbm_init_table+0x1ec>
2002542e:	f8d4 2208 	ldr.w	r2, [r4, #520]	@ 0x208
20025432:	429a      	cmp	r2, r3
20025434:	f000 80e8 	beq.w	20025608 <bbm_init_table+0x1ec>
20025438:	6023      	str	r3, [r4, #0]
2002543a:	2301      	movs	r3, #1
2002543c:	6063      	str	r3, [r4, #4]
2002543e:	2300      	movs	r3, #0
20025440:	f8df 9208 	ldr.w	r9, [pc, #520]	@ 2002564c <bbm_init_table+0x230>
20025444:	8123      	strh	r3, [r4, #8]
20025446:	f8d9 3000 	ldr.w	r3, [r9]
2002544a:	f8df 8204 	ldr.w	r8, [pc, #516]	@ 20025650 <bbm_init_table+0x234>
2002544e:	3b04      	subs	r3, #4
20025450:	f8df a200 	ldr.w	sl, [pc, #512]	@ 20025654 <bbm_init_table+0x238>
20025454:	8163      	strh	r3, [r4, #10]
20025456:	f8d8 3000 	ldr.w	r3, [r8]
2002545a:	f8da 5000 	ldr.w	r5, [sl]
2002545e:	3b01      	subs	r3, #1
20025460:	4e6e      	ldr	r6, [pc, #440]	@ (2002561c <bbm_init_table+0x200>)
20025462:	81a3      	strh	r3, [r4, #12]
20025464:	81e5      	strh	r5, [r4, #14]
20025466:	f8d8 3000 	ldr.w	r3, [r8]
2002546a:	429d      	cmp	r5, r3
2002546c:	db10      	blt.n	20025490 <bbm_init_table+0x74>
2002546e:	2500      	movs	r5, #0
20025470:	462f      	mov	r7, r5
20025472:	f8df b1a8 	ldr.w	fp, [pc, #424]	@ 2002561c <bbm_init_table+0x200>
20025476:	f8da 6000 	ldr.w	r6, [sl]
2002547a:	42b5      	cmp	r5, r6
2002547c:	db1d      	blt.n	200254ba <bbm_init_table+0x9e>
2002547e:	8963      	ldrh	r3, [r4, #10]
20025480:	2b00      	cmp	r3, #0
20025482:	d148      	bne.n	20025516 <bbm_init_table+0xfa>
20025484:	4b65      	ldr	r3, [pc, #404]	@ (2002561c <bbm_init_table+0x200>)
20025486:	681b      	ldr	r3, [r3, #0]
20025488:	b10b      	cbz	r3, 2002548e <bbm_init_table+0x72>
2002548a:	4865      	ldr	r0, [pc, #404]	@ (20025620 <bbm_init_table+0x204>)
2002548c:	4798      	blx	r3
2002548e:	e7fe      	b.n	2002548e <bbm_init_table+0x72>
20025490:	4628      	mov	r0, r5
20025492:	f7fb f9ff 	bl	20020894 <bbm_get_bb>
20025496:	b950      	cbnz	r0, 200254ae <bbm_init_table+0x92>
20025498:	4628      	mov	r0, r5
2002549a:	f7ff ffbd 	bl	20025418 <port_erase_block>
2002549e:	b120      	cbz	r0, 200254aa <bbm_init_table+0x8e>
200254a0:	6833      	ldr	r3, [r6, #0]
200254a2:	b113      	cbz	r3, 200254aa <bbm_init_table+0x8e>
200254a4:	4629      	mov	r1, r5
200254a6:	485f      	ldr	r0, [pc, #380]	@ (20025624 <bbm_init_table+0x208>)
200254a8:	4798      	blx	r3
200254aa:	3501      	adds	r5, #1
200254ac:	e7db      	b.n	20025466 <bbm_init_table+0x4a>
200254ae:	6833      	ldr	r3, [r6, #0]
200254b0:	2b00      	cmp	r3, #0
200254b2:	d0fa      	beq.n	200254aa <bbm_init_table+0x8e>
200254b4:	4629      	mov	r1, r5
200254b6:	485c      	ldr	r0, [pc, #368]	@ (20025628 <bbm_init_table+0x20c>)
200254b8:	e7f6      	b.n	200254a8 <bbm_init_table+0x8c>
200254ba:	4628      	mov	r0, r5
200254bc:	f7fb f9ea 	bl	20020894 <bbm_get_bb>
200254c0:	b338      	cbz	r0, 20025512 <bbm_init_table+0xf6>
200254c2:	f8db 3000 	ldr.w	r3, [fp]
200254c6:	b113      	cbz	r3, 200254ce <bbm_init_table+0xb2>
200254c8:	4629      	mov	r1, r5
200254ca:	4858      	ldr	r0, [pc, #352]	@ (2002562c <bbm_init_table+0x210>)
200254cc:	4798      	blx	r3
200254ce:	89a0      	ldrh	r0, [r4, #12]
200254d0:	f7fb f9e0 	bl	20020894 <bbm_get_bb>
200254d4:	89a3      	ldrh	r3, [r4, #12]
200254d6:	4606      	mov	r6, r0
200254d8:	3b01      	subs	r3, #1
200254da:	81a3      	strh	r3, [r4, #12]
200254dc:	8963      	ldrh	r3, [r4, #10]
200254de:	3b01      	subs	r3, #1
200254e0:	b29b      	uxth	r3, r3
200254e2:	8163      	strh	r3, [r4, #10]
200254e4:	b108      	cbz	r0, 200254ea <bbm_init_table+0xce>
200254e6:	2b00      	cmp	r3, #0
200254e8:	d1f1      	bne.n	200254ce <bbm_init_table+0xb2>
200254ea:	f8db 3000 	ldr.w	r3, [fp]
200254ee:	b11b      	cbz	r3, 200254f8 <bbm_init_table+0xdc>
200254f0:	463a      	mov	r2, r7
200254f2:	4629      	mov	r1, r5
200254f4:	484e      	ldr	r0, [pc, #312]	@ (20025630 <bbm_init_table+0x214>)
200254f6:	4798      	blx	r3
200254f8:	b93e      	cbnz	r6, 2002550a <bbm_init_table+0xee>
200254fa:	89a2      	ldrh	r2, [r4, #12]
200254fc:	1dbb      	adds	r3, r7, #6
200254fe:	f824 5023 	strh.w	r5, [r4, r3, lsl #2]
20025502:	3201      	adds	r2, #1
20025504:	eb04 0383 	add.w	r3, r4, r3, lsl #2
20025508:	805a      	strh	r2, [r3, #2]
2002550a:	8923      	ldrh	r3, [r4, #8]
2002550c:	3701      	adds	r7, #1
2002550e:	3301      	adds	r3, #1
20025510:	8123      	strh	r3, [r4, #8]
20025512:	3501      	adds	r5, #1
20025514:	e7af      	b.n	20025476 <bbm_init_table+0x5a>
20025516:	2110      	movs	r1, #16
20025518:	483e      	ldr	r0, [pc, #248]	@ (20025614 <bbm_init_table+0x1f8>)
2002551a:	f7ff fd77 	bl	2002500c <bbm_crc_check>
2002551e:	f8d9 1000 	ldr.w	r1, [r9]
20025522:	6120      	str	r0, [r4, #16]
20025524:	3904      	subs	r1, #4
20025526:	0089      	lsls	r1, r1, #2
20025528:	4842      	ldr	r0, [pc, #264]	@ (20025634 <bbm_init_table+0x218>)
2002552a:	f7ff fd6f 	bl	2002500c <bbm_crc_check>
2002552e:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025532:	4938      	ldr	r1, [pc, #224]	@ (20025614 <bbm_init_table+0x1f8>)
20025534:	6160      	str	r0, [r4, #20]
20025536:	1888      	adds	r0, r1, r2
20025538:	f000 fefb 	bl	20026332 <memcpy>
2002553c:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025540:	2110      	movs	r1, #16
20025542:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20025546:	483c      	ldr	r0, [pc, #240]	@ (20025638 <bbm_init_table+0x21c>)
20025548:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
2002554c:	f7ff fd5e 	bl	2002500c <bbm_crc_check>
20025550:	2700      	movs	r7, #0
20025552:	f8df a104 	ldr.w	sl, [pc, #260]	@ 20025658 <bbm_init_table+0x23c>
20025556:	f8df 9104 	ldr.w	r9, [pc, #260]	@ 2002565c <bbm_init_table+0x240>
2002555a:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
2002555e:	f8d8 3000 	ldr.w	r3, [r8]
20025562:	429e      	cmp	r6, r3
20025564:	db08      	blt.n	20025578 <bbm_init_table+0x15c>
20025566:	2f03      	cmp	r7, #3
20025568:	dc2f      	bgt.n	200255ca <bbm_init_table+0x1ae>
2002556a:	4b2c      	ldr	r3, [pc, #176]	@ (2002561c <bbm_init_table+0x200>)
2002556c:	681b      	ldr	r3, [r3, #0]
2002556e:	b113      	cbz	r3, 20025576 <bbm_init_table+0x15a>
20025570:	4639      	mov	r1, r7
20025572:	4832      	ldr	r0, [pc, #200]	@ (2002563c <bbm_init_table+0x220>)
20025574:	4798      	blx	r3
20025576:	e7fe      	b.n	20025576 <bbm_init_table+0x15a>
20025578:	4630      	mov	r0, r6
2002557a:	f7fb f98b 	bl	20020894 <bbm_get_bb>
2002557e:	4604      	mov	r4, r0
20025580:	bb08      	cbnz	r0, 200255c6 <bbm_init_table+0x1aa>
20025582:	f8da 5000 	ldr.w	r5, [sl]
20025586:	21ff      	movs	r1, #255	@ 0xff
20025588:	462a      	mov	r2, r5
2002558a:	f8d9 0000 	ldr.w	r0, [r9]
2002558e:	f000 fe61 	bl	20026254 <memset>
20025592:	e9cd 4401 	strd	r4, r4, [sp, #4]
20025596:	9500      	str	r5, [sp, #0]
20025598:	f8d9 3000 	ldr.w	r3, [r9]
2002559c:	4622      	mov	r2, r4
2002559e:	4621      	mov	r1, r4
200255a0:	4630      	mov	r0, r6
200255a2:	f7fb f911 	bl	200207c8 <port_read_page>
200255a6:	f8da 3000 	ldr.w	r3, [sl]
200255aa:	4298      	cmp	r0, r3
200255ac:	d109      	bne.n	200255c2 <bbm_init_table+0x1a6>
200255ae:	f8d9 3000 	ldr.w	r3, [r9]
200255b2:	681b      	ldr	r3, [r3, #0]
200255b4:	3301      	adds	r3, #1
200255b6:	bf01      	itttt	eq
200255b8:	4b21      	ldreq	r3, [pc, #132]	@ (20025640 <bbm_init_table+0x224>)
200255ba:	1d3a      	addeq	r2, r7, #4
200255bc:	f823 6012 	strheq.w	r6, [r3, r2, lsl #1]
200255c0:	3701      	addeq	r7, #1
200255c2:	2f03      	cmp	r7, #3
200255c4:	dc01      	bgt.n	200255ca <bbm_init_table+0x1ae>
200255c6:	3601      	adds	r6, #1
200255c8:	e7c9      	b.n	2002555e <bbm_init_table+0x142>
200255ca:	2500      	movs	r5, #0
200255cc:	4c1c      	ldr	r4, [pc, #112]	@ (20025640 <bbm_init_table+0x224>)
200255ce:	2000      	movs	r0, #0
200255d0:	8921      	ldrh	r1, [r4, #8]
200255d2:	f7ff fee7 	bl	200253a4 <bbm_write_talbe.isra.0>
200255d6:	8923      	ldrh	r3, [r4, #8]
200255d8:	2001      	movs	r0, #1
200255da:	8961      	ldrh	r1, [r4, #10]
200255dc:	8023      	strh	r3, [r4, #0]
200255de:	8223      	strh	r3, [r4, #16]
200255e0:	8125      	strh	r5, [r4, #8]
200255e2:	f7ff fedf 	bl	200253a4 <bbm_write_talbe.isra.0>
200255e6:	8963      	ldrh	r3, [r4, #10]
200255e8:	8165      	strh	r5, [r4, #10]
200255ea:	80a3      	strh	r3, [r4, #4]
200255ec:	8263      	strh	r3, [r4, #18]
200255ee:	89a3      	ldrh	r3, [r4, #12]
200255f0:	8063      	strh	r3, [r4, #2]
200255f2:	89e3      	ldrh	r3, [r4, #14]
200255f4:	80e3      	strh	r3, [r4, #6]
200255f6:	4b09      	ldr	r3, [pc, #36]	@ (2002561c <bbm_init_table+0x200>)
200255f8:	681b      	ldr	r3, [r3, #0]
200255fa:	b10b      	cbz	r3, 20025600 <bbm_init_table+0x1e4>
200255fc:	4811      	ldr	r0, [pc, #68]	@ (20025644 <bbm_init_table+0x228>)
200255fe:	4798      	blx	r3
20025600:	2000      	movs	r0, #0
20025602:	b005      	add	sp, #20
20025604:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025608:	4b04      	ldr	r3, [pc, #16]	@ (2002561c <bbm_init_table+0x200>)
2002560a:	681b      	ldr	r3, [r3, #0]
2002560c:	b10b      	cbz	r3, 20025612 <bbm_init_table+0x1f6>
2002560e:	480e      	ldr	r0, [pc, #56]	@ (20025648 <bbm_init_table+0x22c>)
20025610:	4798      	blx	r3
20025612:	e7fe      	b.n	20025612 <bbm_init_table+0x1f6>
20025614:	2004cca4 	.word	0x2004cca4
20025618:	5366424d 	.word	0x5366424d
2002561c:	2004cc8c 	.word	0x2004cc8c
20025620:	20026dfa 	.word	0x20026dfa
20025624:	20026d88 	.word	0x20026d88
20025628:	20026daa 	.word	0x20026daa
2002562c:	20026dc7 	.word	0x20026dc7
20025630:	20026de6 	.word	0x20026de6
20025634:	2004ccbc 	.word	0x2004ccbc
20025638:	2004ceac 	.word	0x2004ceac
2002563c:	20026e14 	.word	0x20026e14
20025640:	2004d0b4 	.word	0x2004d0b4
20025644:	20026e3b 	.word	0x20026e3b
20025648:	20026e57 	.word	0x20026e57
2002564c:	2004cc9c 	.word	0x2004cc9c
20025650:	2004cc98 	.word	0x2004cc98
20025654:	2004cca0 	.word	0x2004cca0
20025658:	2004499c 	.word	0x2004499c
2002565c:	2004cc90 	.word	0x2004cc90

20025660 <sif_bbm_init>:
20025660:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20025664:	b087      	sub	sp, #28
20025666:	2900      	cmp	r1, #0
20025668:	f000 8129 	beq.w	200258be <sif_bbm_init+0x25e>
2002566c:	4b95      	ldr	r3, [pc, #596]	@ (200258c4 <sif_bbm_init+0x264>)
2002566e:	681a      	ldr	r2, [r3, #0]
20025670:	2a01      	cmp	r2, #1
20025672:	d108      	bne.n	20025686 <sif_bbm_init+0x26>
20025674:	4b94      	ldr	r3, [pc, #592]	@ (200258c8 <sif_bbm_init+0x268>)
20025676:	681b      	ldr	r3, [r3, #0]
20025678:	b10b      	cbz	r3, 2002567e <sif_bbm_init+0x1e>
2002567a:	4894      	ldr	r0, [pc, #592]	@ (200258cc <sif_bbm_init+0x26c>)
2002567c:	4798      	blx	r3
2002567e:	2000      	movs	r0, #0
20025680:	b007      	add	sp, #28
20025682:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20025686:	2201      	movs	r2, #1
20025688:	601a      	str	r2, [r3, #0]
2002568a:	4b91      	ldr	r3, [pc, #580]	@ (200258d0 <sif_bbm_init+0x270>)
2002568c:	681c      	ldr	r4, [r3, #0]
2002568e:	b904      	cbnz	r4, 20025692 <sif_bbm_init+0x32>
20025690:	e7fe      	b.n	20025690 <sif_bbm_init+0x30>
20025692:	f8df a27c 	ldr.w	sl, [pc, #636]	@ 20025910 <sif_bbm_init+0x2b0>
20025696:	f8da 2000 	ldr.w	r2, [sl]
2002569a:	b902      	cbnz	r2, 2002569e <sif_bbm_init+0x3e>
2002569c:	e7fe      	b.n	2002569c <sif_bbm_init+0x3c>
2002569e:	fbb0 f4f4 	udiv	r4, r0, r4
200256a2:	f04f 0800 	mov.w	r8, #0
200256a6:	4a8b      	ldr	r2, [pc, #556]	@ (200258d4 <sif_bbm_init+0x274>)
200256a8:	f8df b268 	ldr.w	fp, [pc, #616]	@ 20025914 <sif_bbm_init+0x2b4>
200256ac:	0963      	lsrs	r3, r4, #5
200256ae:	f8df 9268 	ldr.w	r9, [pc, #616]	@ 20025918 <sif_bbm_init+0x2b8>
200256b2:	6013      	str	r3, [r2, #0]
200256b4:	f8cb 4000 	str.w	r4, [fp]
200256b8:	1ae4      	subs	r4, r4, r3
200256ba:	4b87      	ldr	r3, [pc, #540]	@ (200258d8 <sif_bbm_init+0x278>)
200256bc:	2218      	movs	r2, #24
200256be:	f8c9 1000 	str.w	r1, [r9]
200256c2:	4886      	ldr	r0, [pc, #536]	@ (200258dc <sif_bbm_init+0x27c>)
200256c4:	2100      	movs	r1, #0
200256c6:	601c      	str	r4, [r3, #0]
200256c8:	f000 fdc4 	bl	20026254 <memset>
200256cc:	f44f 6282 	mov.w	r2, #1040	@ 0x410
200256d0:	2100      	movs	r1, #0
200256d2:	4883      	ldr	r0, [pc, #524]	@ (200258e0 <sif_bbm_init+0x280>)
200256d4:	f000 fdbe 	bl	20026254 <memset>
200256d8:	4647      	mov	r7, r8
200256da:	4646      	mov	r6, r8
200256dc:	f8db 3000 	ldr.w	r3, [fp]
200256e0:	429c      	cmp	r4, r3
200256e2:	db02      	blt.n	200256ea <sif_bbm_init+0x8a>
200256e4:	f04f 35ff 	mov.w	r5, #4294967295
200256e8:	e064      	b.n	200257b4 <sif_bbm_init+0x154>
200256ea:	4620      	mov	r0, r4
200256ec:	f7fb f8d2 	bl	20020894 <bbm_get_bb>
200256f0:	4605      	mov	r5, r0
200256f2:	b138      	cbz	r0, 20025704 <sif_bbm_init+0xa4>
200256f4:	4b74      	ldr	r3, [pc, #464]	@ (200258c8 <sif_bbm_init+0x268>)
200256f6:	681b      	ldr	r3, [r3, #0]
200256f8:	b113      	cbz	r3, 20025700 <sif_bbm_init+0xa0>
200256fa:	4621      	mov	r1, r4
200256fc:	4879      	ldr	r0, [pc, #484]	@ (200258e4 <sif_bbm_init+0x284>)
200256fe:	4798      	blx	r3
20025700:	3401      	adds	r4, #1
20025702:	e7eb      	b.n	200256dc <sif_bbm_init+0x7c>
20025704:	f8da 2000 	ldr.w	r2, [sl]
20025708:	21ff      	movs	r1, #255	@ 0xff
2002570a:	f8d9 0000 	ldr.w	r0, [r9]
2002570e:	9205      	str	r2, [sp, #20]
20025710:	f000 fda0 	bl	20026254 <memset>
20025714:	9a05      	ldr	r2, [sp, #20]
20025716:	e9cd 5501 	strd	r5, r5, [sp, #4]
2002571a:	9200      	str	r2, [sp, #0]
2002571c:	f8d9 3000 	ldr.w	r3, [r9]
20025720:	462a      	mov	r2, r5
20025722:	4629      	mov	r1, r5
20025724:	4620      	mov	r0, r4
20025726:	f7fb f84f 	bl	200207c8 <port_read_page>
2002572a:	f8da 3000 	ldr.w	r3, [sl]
2002572e:	4298      	cmp	r0, r3
20025730:	d12e      	bne.n	20025790 <sif_bbm_init+0x130>
20025732:	f8d9 1000 	ldr.w	r1, [r9]
20025736:	486c      	ldr	r0, [pc, #432]	@ (200258e8 <sif_bbm_init+0x288>)
20025738:	680b      	ldr	r3, [r1, #0]
2002573a:	b2a2      	uxth	r2, r4
2002573c:	4283      	cmp	r3, r0
2002573e:	4b67      	ldr	r3, [pc, #412]	@ (200258dc <sif_bbm_init+0x27c>)
20025740:	d11f      	bne.n	20025782 <sif_bbm_init+0x122>
20025742:	f991 1007 	ldrsb.w	r1, [r1, #7]
20025746:	2900      	cmp	r1, #0
20025748:	bfb5      	itete	lt
2002574a:	eb03 0147 	addlt.w	r1, r3, r7, lsl #1
2002574e:	f823 2016 	strhge.w	r2, [r3, r6, lsl #1]
20025752:	808a      	strhlt	r2, [r1, #4]
20025754:	3601      	addge	r6, #1
20025756:	bfb8      	it	lt
20025758:	3701      	addlt	r7, #1
2002575a:	eb06 0208 	add.w	r2, r6, r8
2002575e:	443a      	add	r2, r7
20025760:	2a03      	cmp	r2, #3
20025762:	ddcd      	ble.n	20025700 <sif_bbm_init+0xa0>
20025764:	2e00      	cmp	r6, #0
20025766:	f000 8081 	beq.w	2002586c <sif_bbm_init+0x20c>
2002576a:	2f00      	cmp	r7, #0
2002576c:	d07e      	beq.n	2002586c <sif_bbm_init+0x20c>
2002576e:	2e01      	cmp	r6, #1
20025770:	d001      	beq.n	20025776 <sif_bbm_init+0x116>
20025772:	2f01      	cmp	r7, #1
20025774:	d11e      	bne.n	200257b4 <sif_bbm_init+0x154>
20025776:	8819      	ldrh	r1, [r3, #0]
20025778:	891a      	ldrh	r2, [r3, #8]
2002577a:	b981      	cbnz	r1, 2002579e <sif_bbm_init+0x13e>
2002577c:	801a      	strh	r2, [r3, #0]
2002577e:	895a      	ldrh	r2, [r3, #10]
20025780:	e013      	b.n	200257aa <sif_bbm_init+0x14a>
20025782:	f108 0104 	add.w	r1, r8, #4
20025786:	f823 2011 	strh.w	r2, [r3, r1, lsl #1]
2002578a:	f108 0801 	add.w	r8, r8, #1
2002578e:	e7e4      	b.n	2002575a <sif_bbm_init+0xfa>
20025790:	4b4d      	ldr	r3, [pc, #308]	@ (200258c8 <sif_bbm_init+0x268>)
20025792:	681b      	ldr	r3, [r3, #0]
20025794:	2b00      	cmp	r3, #0
20025796:	d0b3      	beq.n	20025700 <sif_bbm_init+0xa0>
20025798:	4854      	ldr	r0, [pc, #336]	@ (200258ec <sif_bbm_init+0x28c>)
2002579a:	1c61      	adds	r1, r4, #1
2002579c:	e7af      	b.n	200256fe <sif_bbm_init+0x9e>
2002579e:	8859      	ldrh	r1, [r3, #2]
200257a0:	b909      	cbnz	r1, 200257a6 <sif_bbm_init+0x146>
200257a2:	805a      	strh	r2, [r3, #2]
200257a4:	e7eb      	b.n	2002577e <sif_bbm_init+0x11e>
200257a6:	2a00      	cmp	r2, #0
200257a8:	d0e9      	beq.n	2002577e <sif_bbm_init+0x11e>
200257aa:	8899      	ldrh	r1, [r3, #4]
200257ac:	2900      	cmp	r1, #0
200257ae:	d158      	bne.n	20025862 <sif_bbm_init+0x202>
200257b0:	809a      	strh	r2, [r3, #4]
200257b2:	2502      	movs	r5, #2
200257b4:	f8df 9110 	ldr.w	r9, [pc, #272]	@ 200258c8 <sif_bbm_init+0x268>
200257b8:	f8d9 4000 	ldr.w	r4, [r9]
200257bc:	b124      	cbz	r4, 200257c8 <sif_bbm_init+0x168>
200257be:	4643      	mov	r3, r8
200257c0:	463a      	mov	r2, r7
200257c2:	4631      	mov	r1, r6
200257c4:	484a      	ldr	r0, [pc, #296]	@ (200258f0 <sif_bbm_init+0x290>)
200257c6:	47a0      	blx	r4
200257c8:	f8d9 3000 	ldr.w	r3, [r9]
200257cc:	b113      	cbz	r3, 200257d4 <sif_bbm_init+0x174>
200257ce:	4629      	mov	r1, r5
200257d0:	4848      	ldr	r0, [pc, #288]	@ (200258f4 <sif_bbm_init+0x294>)
200257d2:	4798      	blx	r3
200257d4:	f035 0002 	bics.w	r0, r5, #2
200257d8:	d164      	bne.n	200258a4 <sif_bbm_init+0x244>
200257da:	f7ff fccb 	bl	20025174 <bbm_get_map_table>
200257de:	4605      	mov	r5, r0
200257e0:	2001      	movs	r0, #1
200257e2:	f7ff fcc7 	bl	20025174 <bbm_get_map_table>
200257e6:	f8d9 6000 	ldr.w	r6, [r9]
200257ea:	4604      	mov	r4, r0
200257ec:	b13e      	cbz	r6, 200257fe <sif_bbm_init+0x19e>
200257ee:	4a3b      	ldr	r2, [pc, #236]	@ (200258dc <sif_bbm_init+0x27c>)
200257f0:	4629      	mov	r1, r5
200257f2:	8a53      	ldrh	r3, [r2, #18]
200257f4:	9300      	str	r3, [sp, #0]
200257f6:	8a12      	ldrh	r2, [r2, #16]
200257f8:	4603      	mov	r3, r0
200257fa:	483f      	ldr	r0, [pc, #252]	@ (200258f8 <sif_bbm_init+0x298>)
200257fc:	47b0      	blx	r6
200257fe:	42a5      	cmp	r5, r4
20025800:	4c37      	ldr	r4, [pc, #220]	@ (200258e0 <sif_bbm_init+0x280>)
20025802:	dd35      	ble.n	20025870 <sif_bbm_init+0x210>
20025804:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025808:	4621      	mov	r1, r4
2002580a:	18a0      	adds	r0, r4, r2
2002580c:	f000 fd91 	bl	20026332 <memcpy>
20025810:	f894 320f 	ldrb.w	r3, [r4, #527]	@ 0x20f
20025814:	2110      	movs	r1, #16
20025816:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
2002581a:	f884 320f 	strb.w	r3, [r4, #527]	@ 0x20f
2002581e:	f504 7002 	add.w	r0, r4, #520	@ 0x208
20025822:	f7ff fbf3 	bl	2002500c <bbm_crc_check>
20025826:	f8c4 0218 	str.w	r0, [r4, #536]	@ 0x218
2002582a:	2001      	movs	r0, #1
2002582c:	4b2b      	ldr	r3, [pc, #172]	@ (200258dc <sif_bbm_init+0x27c>)
2002582e:	8a59      	ldrh	r1, [r3, #18]
20025830:	f7ff fdb8 	bl	200253a4 <bbm_write_talbe.isra.0>
20025834:	6822      	ldr	r2, [r4, #0]
20025836:	4b2c      	ldr	r3, [pc, #176]	@ (200258e8 <sif_bbm_init+0x288>)
20025838:	429a      	cmp	r2, r3
2002583a:	d12d      	bne.n	20025898 <sif_bbm_init+0x238>
2002583c:	4828      	ldr	r0, [pc, #160]	@ (200258e0 <sif_bbm_init+0x280>)
2002583e:	f7ff fb95 	bl	20024f6c <bbm_map_check.part.0>
20025842:	f8d9 4000 	ldr.w	r4, [r9]
20025846:	b12c      	cbz	r4, 20025854 <sif_bbm_init+0x1f4>
20025848:	4b2c      	ldr	r3, [pc, #176]	@ (200258fc <sif_bbm_init+0x29c>)
2002584a:	4924      	ldr	r1, [pc, #144]	@ (200258dc <sif_bbm_init+0x27c>)
2002584c:	482c      	ldr	r0, [pc, #176]	@ (20025900 <sif_bbm_init+0x2a0>)
2002584e:	f5a3 7202 	sub.w	r2, r3, #520	@ 0x208
20025852:	47a0      	blx	r4
20025854:	f8d9 3000 	ldr.w	r3, [r9]
20025858:	2b00      	cmp	r3, #0
2002585a:	f43f af10 	beq.w	2002567e <sif_bbm_init+0x1e>
2002585e:	4829      	ldr	r0, [pc, #164]	@ (20025904 <sif_bbm_init+0x2a4>)
20025860:	e70c      	b.n	2002567c <sif_bbm_init+0x1c>
20025862:	88d9      	ldrh	r1, [r3, #6]
20025864:	2900      	cmp	r1, #0
20025866:	d1a4      	bne.n	200257b2 <sif_bbm_init+0x152>
20025868:	80da      	strh	r2, [r3, #6]
2002586a:	e7a2      	b.n	200257b2 <sif_bbm_init+0x152>
2002586c:	2501      	movs	r5, #1
2002586e:	e7a1      	b.n	200257b4 <sif_bbm_init+0x154>
20025870:	dae0      	bge.n	20025834 <sif_bbm_init+0x1d4>
20025872:	f44f 7202 	mov.w	r2, #520	@ 0x208
20025876:	4620      	mov	r0, r4
20025878:	18a1      	adds	r1, r4, r2
2002587a:	f000 fd5a 	bl	20026332 <memcpy>
2002587e:	79e3      	ldrb	r3, [r4, #7]
20025880:	2110      	movs	r1, #16
20025882:	f023 0380 	bic.w	r3, r3, #128	@ 0x80
20025886:	71e3      	strb	r3, [r4, #7]
20025888:	4620      	mov	r0, r4
2002588a:	f7ff fbbf 	bl	2002500c <bbm_crc_check>
2002588e:	4b13      	ldr	r3, [pc, #76]	@ (200258dc <sif_bbm_init+0x27c>)
20025890:	6120      	str	r0, [r4, #16]
20025892:	8a19      	ldrh	r1, [r3, #16]
20025894:	2000      	movs	r0, #0
20025896:	e7cb      	b.n	20025830 <sif_bbm_init+0x1d0>
20025898:	f8d9 3000 	ldr.w	r3, [r9]
2002589c:	b10b      	cbz	r3, 200258a2 <sif_bbm_init+0x242>
2002589e:	481a      	ldr	r0, [pc, #104]	@ (20025908 <sif_bbm_init+0x2a8>)
200258a0:	4798      	blx	r3
200258a2:	e7fe      	b.n	200258a2 <sif_bbm_init+0x242>
200258a4:	2d01      	cmp	r5, #1
200258a6:	d102      	bne.n	200258ae <sif_bbm_init+0x24e>
200258a8:	f7ff fdb8 	bl	2002541c <bbm_init_table>
200258ac:	e7c9      	b.n	20025842 <sif_bbm_init+0x1e2>
200258ae:	f8d9 3000 	ldr.w	r3, [r9]
200258b2:	b11b      	cbz	r3, 200258bc <sif_bbm_init+0x25c>
200258b4:	f04f 31ff 	mov.w	r1, #4294967295
200258b8:	4814      	ldr	r0, [pc, #80]	@ (2002590c <sif_bbm_init+0x2ac>)
200258ba:	4798      	blx	r3
200258bc:	e7fe      	b.n	200258bc <sif_bbm_init+0x25c>
200258be:	f04f 30ff 	mov.w	r0, #4294967295
200258c2:	e6dd      	b.n	20025680 <sif_bbm_init+0x20>
200258c4:	2004cc94 	.word	0x2004cc94
200258c8:	2004cc8c 	.word	0x2004cc8c
200258cc:	20026e6b 	.word	0x20026e6b
200258d0:	200449a0 	.word	0x200449a0
200258d4:	2004cc9c 	.word	0x2004cc9c
200258d8:	2004cca0 	.word	0x2004cca0
200258dc:	2004d0b4 	.word	0x2004d0b4
200258e0:	2004cca4 	.word	0x2004cca4
200258e4:	20026e99 	.word	0x20026e99
200258e8:	5366424d 	.word	0x5366424d
200258ec:	20026ea5 	.word	0x20026ea5
200258f0:	20026ec4 	.word	0x20026ec4
200258f4:	20026ee3 	.word	0x20026ee3
200258f8:	20026ef5 	.word	0x20026ef5
200258fc:	2004ceac 	.word	0x2004ceac
20025900:	20026f50 	.word	0x20026f50
20025904:	20026f74 	.word	0x20026f74
20025908:	20026f19 	.word	0x20026f19
2002590c:	20026f2f 	.word	0x20026f2f
20025910:	2004499c 	.word	0x2004499c
20025914:	2004cc98 	.word	0x2004cc98
20025918:	2004cc90 	.word	0x2004cc90

2002591c <bbm_set_page_size>:
2002591c:	4b01      	ldr	r3, [pc, #4]	@ (20025924 <bbm_set_page_size+0x8>)
2002591e:	6018      	str	r0, [r3, #0]
20025920:	4770      	bx	lr
20025922:	bf00      	nop
20025924:	2004499c 	.word	0x2004499c

20025928 <bbm_set_blk_size>:
20025928:	4b01      	ldr	r3, [pc, #4]	@ (20025930 <bbm_set_blk_size+0x8>)
2002592a:	6018      	str	r0, [r3, #0]
2002592c:	4770      	bx	lr
2002592e:	bf00      	nop
20025930:	200449a0 	.word	0x200449a0

20025934 <sf_crypto_cmac_gen_subkey>:
20025934:	2300      	movs	r3, #0
20025936:	b530      	push	{r4, r5, lr}
20025938:	f100 0210 	add.w	r2, r0, #16
2002593c:	f101 0410 	add.w	r4, r1, #16
20025940:	f812 5d01 	ldrb.w	r5, [r2, #-1]!
20025944:	ea43 0345 	orr.w	r3, r3, r5, lsl #1
20025948:	f804 3d01 	strb.w	r3, [r4, #-1]!
2002594c:	7813      	ldrb	r3, [r2, #0]
2002594e:	4282      	cmp	r2, r0
20025950:	ea4f 13d3 	mov.w	r3, r3, lsr #7
20025954:	d1f4      	bne.n	20025940 <sf_crypto_cmac_gen_subkey+0xc>
20025956:	f992 3000 	ldrsb.w	r3, [r2]
2002595a:	2b00      	cmp	r3, #0
2002595c:	bfbe      	ittt	lt
2002595e:	7bcb      	ldrblt	r3, [r1, #15]
20025960:	f083 0387 	eorlt.w	r3, r3, #135	@ 0x87
20025964:	73cb      	strblt	r3, [r1, #15]
20025966:	bd30      	pop	{r4, r5, pc}

20025968 <sf_crypto_aes_cmac_init>:
20025968:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
2002596c:	2a20      	cmp	r2, #32
2002596e:	4604      	mov	r4, r0
20025970:	460e      	mov	r6, r1
20025972:	4615      	mov	r5, r2
20025974:	b08c      	sub	sp, #48	@ 0x30
20025976:	d12e      	bne.n	200259d6 <sf_crypto_aes_cmac_init+0x6e>
20025978:	b380      	cbz	r0, 200259dc <sf_crypto_aes_cmac_init+0x74>
2002597a:	2710      	movs	r7, #16
2002597c:	ab04      	add	r3, sp, #16
2002597e:	6001      	str	r1, [r0, #0]
20025980:	8082      	strh	r2, [r0, #4]
20025982:	2100      	movs	r1, #0
20025984:	463a      	mov	r2, r7
20025986:	4618      	mov	r0, r3
20025988:	f000 fc64 	bl	20026254 <memset>
2002598c:	2300      	movs	r3, #0
2002598e:	f10d 0820 	add.w	r8, sp, #32
20025992:	4629      	mov	r1, r5
20025994:	9000      	str	r0, [sp, #0]
20025996:	461a      	mov	r2, r3
20025998:	4630      	mov	r0, r6
2002599a:	e9cd 7801 	strd	r7, r8, [sp, #4]
2002599e:	f000 f8da 	bl	20025b56 <sf_crypto_aes_enc_sync>
200259a2:	4605      	mov	r5, r0
200259a4:	b100      	cbz	r0, 200259a8 <sf_crypto_aes_cmac_init+0x40>
200259a6:	e7fe      	b.n	200259a6 <sf_crypto_aes_cmac_init+0x3e>
200259a8:	1da6      	adds	r6, r4, #6
200259aa:	4631      	mov	r1, r6
200259ac:	4640      	mov	r0, r8
200259ae:	f7ff ffc1 	bl	20025934 <sf_crypto_cmac_gen_subkey>
200259b2:	4630      	mov	r0, r6
200259b4:	f104 0116 	add.w	r1, r4, #22
200259b8:	f7ff ffbc 	bl	20025934 <sf_crypto_cmac_gen_subkey>
200259bc:	463a      	mov	r2, r7
200259be:	4629      	mov	r1, r5
200259c0:	f104 0028 	add.w	r0, r4, #40	@ 0x28
200259c4:	f000 fc46 	bl	20026254 <memset>
200259c8:	f240 1301 	movw	r3, #257	@ 0x101
200259cc:	8723      	strh	r3, [r4, #56]	@ 0x38
200259ce:	4628      	mov	r0, r5
200259d0:	b00c      	add	sp, #48	@ 0x30
200259d2:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
200259d6:	f06f 0502 	mvn.w	r5, #2
200259da:	e7f8      	b.n	200259ce <sf_crypto_aes_cmac_init+0x66>
200259dc:	f04f 35ff 	mov.w	r5, #4294967295
200259e0:	e7f5      	b.n	200259ce <sf_crypto_aes_cmac_init+0x66>

200259e2 <sf_crypto_aes_cmac_calc>:
200259e2:	e92d 43f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, lr}
200259e6:	b089      	sub	sp, #36	@ 0x24
200259e8:	460f      	mov	r7, r1
200259ea:	4604      	mov	r4, r0
200259ec:	9e10      	ldr	r6, [sp, #64]	@ 0x40
200259ee:	b138      	cbz	r0, 20025a00 <sf_crypto_aes_cmac_calc+0x1e>
200259f0:	b136      	cbz	r6, 20025a00 <sf_crypto_aes_cmac_calc+0x1e>
200259f2:	f890 1039 	ldrb.w	r1, [r0, #57]	@ 0x39
200259f6:	2900      	cmp	r1, #0
200259f8:	f000 80aa 	beq.w	20025b50 <sf_crypto_aes_cmac_calc+0x16e>
200259fc:	b11a      	cbz	r2, 20025a06 <sf_crypto_aes_cmac_calc+0x24>
200259fe:	b957      	cbnz	r7, 20025a16 <sf_crypto_aes_cmac_calc+0x34>
20025a00:	f04f 30ff 	mov.w	r0, #4294967295
20025a04:	e0a1      	b.n	20025b4a <sf_crypto_aes_cmac_calc+0x168>
20025a06:	f890 1038 	ldrb.w	r1, [r0, #56]	@ 0x38
20025a0a:	b109      	cbz	r1, 20025a10 <sf_crypto_aes_cmac_calc+0x2e>
20025a0c:	2b00      	cmp	r3, #0
20025a0e:	d16e      	bne.n	20025aee <sf_crypto_aes_cmac_calc+0x10c>
20025a10:	f06f 0003 	mvn.w	r0, #3
20025a14:	e099      	b.n	20025b4a <sf_crypto_aes_cmac_calc+0x168>
20025a16:	f002 000f 	and.w	r0, r2, #15
20025a1a:	b973      	cbnz	r3, 20025a3a <sf_crypto_aes_cmac_calc+0x58>
20025a1c:	2800      	cmp	r0, #0
20025a1e:	d1f7      	bne.n	20025a10 <sf_crypto_aes_cmac_calc+0x2e>
20025a20:	e9cd 2601 	strd	r2, r6, [sp, #4]
20025a24:	9700      	str	r7, [sp, #0]
20025a26:	2303      	movs	r3, #3
20025a28:	88a1      	ldrh	r1, [r4, #4]
20025a2a:	6820      	ldr	r0, [r4, #0]
20025a2c:	f104 0228 	add.w	r2, r4, #40	@ 0x28
20025a30:	f000 f891 	bl	20025b56 <sf_crypto_aes_enc_sync>
20025a34:	2800      	cmp	r0, #0
20025a36:	d07b      	beq.n	20025b30 <sf_crypto_aes_cmac_calc+0x14e>
20025a38:	e7fe      	b.n	20025a38 <sf_crypto_aes_cmac_calc+0x56>
20025a3a:	320f      	adds	r2, #15
20025a3c:	ea4f 1812 	mov.w	r8, r2, lsr #4
20025a40:	f108 31ff 	add.w	r1, r8, #4294967295
20025a44:	eb07 1101 	add.w	r1, r7, r1, lsl #4
20025a48:	b3c0      	cbz	r0, 20025abc <sf_crypto_aes_cmac_calc+0xda>
20025a4a:	f1c0 0910 	rsb	r9, r0, #16
20025a4e:	fa1f f989 	uxth.w	r9, r9
20025a52:	f1c9 0510 	rsb	r5, r9, #16
20025a56:	462a      	mov	r2, r5
20025a58:	a804      	add	r0, sp, #16
20025a5a:	f000 fc6a 	bl	20026332 <memcpy>
20025a5e:	f105 0320 	add.w	r3, r5, #32
20025a62:	eb0d 0203 	add.w	r2, sp, r3
20025a66:	2380      	movs	r3, #128	@ 0x80
20025a68:	f802 3c10 	strb.w	r3, [r2, #-16]
20025a6c:	ab08      	add	r3, sp, #32
20025a6e:	eba3 0209 	sub.w	r2, r3, r9
20025a72:	2100      	movs	r1, #0
20025a74:	2301      	movs	r3, #1
20025a76:	454b      	cmp	r3, r9
20025a78:	d33f      	bcc.n	20025afa <sf_crypto_aes_cmac_calc+0x118>
20025a7a:	aa04      	add	r2, sp, #16
20025a7c:	f104 0315 	add.w	r3, r4, #21
20025a80:	f104 0025 	add.w	r0, r4, #37	@ 0x25
20025a84:	7811      	ldrb	r1, [r2, #0]
20025a86:	f813 5f01 	ldrb.w	r5, [r3, #1]!
20025a8a:	4069      	eors	r1, r5
20025a8c:	4283      	cmp	r3, r0
20025a8e:	f802 1b01 	strb.w	r1, [r2], #1
20025a92:	d1f7      	bne.n	20025a84 <sf_crypto_aes_cmac_calc+0xa2>
20025a94:	f1b8 0f01 	cmp.w	r8, #1
20025a98:	f104 0528 	add.w	r5, r4, #40	@ 0x28
20025a9c:	d93b      	bls.n	20025b16 <sf_crypto_aes_cmac_calc+0x134>
20025a9e:	f108 38ff 	add.w	r8, r8, #4294967295
20025aa2:	ea4f 1308 	mov.w	r3, r8, lsl #4
20025aa6:	e9cd 7300 	strd	r7, r3, [sp]
20025aaa:	9602      	str	r6, [sp, #8]
20025aac:	2303      	movs	r3, #3
20025aae:	462a      	mov	r2, r5
20025ab0:	88a1      	ldrh	r1, [r4, #4]
20025ab2:	6820      	ldr	r0, [r4, #0]
20025ab4:	f000 f84f 	bl	20025b56 <sf_crypto_aes_enc_sync>
20025ab8:	b318      	cbz	r0, 20025b02 <sf_crypto_aes_cmac_calc+0x120>
20025aba:	e7fe      	b.n	20025aba <sf_crypto_aes_cmac_calc+0xd8>
20025abc:	460b      	mov	r3, r1
20025abe:	ad04      	add	r5, sp, #16
20025ac0:	f101 0c10 	add.w	ip, r1, #16
20025ac4:	462a      	mov	r2, r5
20025ac6:	6818      	ldr	r0, [r3, #0]
20025ac8:	6859      	ldr	r1, [r3, #4]
20025aca:	3308      	adds	r3, #8
20025acc:	c203      	stmia	r2!, {r0, r1}
20025ace:	4563      	cmp	r3, ip
20025ad0:	4615      	mov	r5, r2
20025ad2:	d1f7      	bne.n	20025ac4 <sf_crypto_aes_cmac_calc+0xe2>
20025ad4:	ab04      	add	r3, sp, #16
20025ad6:	1d62      	adds	r2, r4, #5
20025ad8:	f104 0015 	add.w	r0, r4, #21
20025adc:	7819      	ldrb	r1, [r3, #0]
20025ade:	f812 5f01 	ldrb.w	r5, [r2, #1]!
20025ae2:	4069      	eors	r1, r5
20025ae4:	4282      	cmp	r2, r0
20025ae6:	f803 1b01 	strb.w	r1, [r3], #1
20025aea:	d1f7      	bne.n	20025adc <sf_crypto_aes_cmac_calc+0xfa>
20025aec:	e7d2      	b.n	20025a94 <sf_crypto_aes_cmac_calc+0xb2>
20025aee:	4615      	mov	r5, r2
20025af0:	f04f 0910 	mov.w	r9, #16
20025af4:	f04f 0801 	mov.w	r8, #1
20025af8:	e7b1      	b.n	20025a5e <sf_crypto_aes_cmac_calc+0x7c>
20025afa:	f802 1f01 	strb.w	r1, [r2, #1]!
20025afe:	3301      	adds	r3, #1
20025b00:	e7b9      	b.n	20025a76 <sf_crypto_aes_cmac_calc+0x94>
20025b02:	4633      	mov	r3, r6
20025b04:	462a      	mov	r2, r5
20025b06:	f106 0110 	add.w	r1, r6, #16
20025b0a:	f853 0b04 	ldr.w	r0, [r3], #4
20025b0e:	428b      	cmp	r3, r1
20025b10:	f842 0b04 	str.w	r0, [r2], #4
20025b14:	d1f9      	bne.n	20025b0a <sf_crypto_aes_cmac_calc+0x128>
20025b16:	2310      	movs	r3, #16
20025b18:	9301      	str	r3, [sp, #4]
20025b1a:	446b      	add	r3, sp
20025b1c:	9300      	str	r3, [sp, #0]
20025b1e:	9602      	str	r6, [sp, #8]
20025b20:	2303      	movs	r3, #3
20025b22:	462a      	mov	r2, r5
20025b24:	88a1      	ldrh	r1, [r4, #4]
20025b26:	6820      	ldr	r0, [r4, #0]
20025b28:	f000 f815 	bl	20025b56 <sf_crypto_aes_enc_sync>
20025b2c:	b100      	cbz	r0, 20025b30 <sf_crypto_aes_cmac_calc+0x14e>
20025b2e:	e7fe      	b.n	20025b2e <sf_crypto_aes_cmac_calc+0x14c>
20025b30:	f104 0328 	add.w	r3, r4, #40	@ 0x28
20025b34:	f106 0210 	add.w	r2, r6, #16
20025b38:	f856 1b04 	ldr.w	r1, [r6], #4
20025b3c:	4296      	cmp	r6, r2
20025b3e:	f843 1b04 	str.w	r1, [r3], #4
20025b42:	d1f9      	bne.n	20025b38 <sf_crypto_aes_cmac_calc+0x156>
20025b44:	2000      	movs	r0, #0
20025b46:	f884 0038 	strb.w	r0, [r4, #56]	@ 0x38
20025b4a:	b009      	add	sp, #36	@ 0x24
20025b4c:	e8bd 83f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, pc}
20025b50:	f06f 0001 	mvn.w	r0, #1
20025b54:	e7f9      	b.n	20025b4a <sf_crypto_aes_cmac_calc+0x168>

20025b56 <sf_crypto_aes_enc_sync>:
20025b56:	b508      	push	{r3, lr}
20025b58:	f7fb ffb4 	bl	20021ac4 <HAL_AES_init>
20025b5c:	b100      	cbz	r0, 20025b60 <sf_crypto_aes_enc_sync+0xa>
20025b5e:	e7fe      	b.n	20025b5e <sf_crypto_aes_enc_sync+0x8>
20025b60:	2001      	movs	r0, #1
20025b62:	e9dd 3203 	ldrd	r3, r2, [sp, #12]
20025b66:	9902      	ldr	r1, [sp, #8]
20025b68:	f7fb fff2 	bl	20021b50 <HAL_AES_run>
20025b6c:	b100      	cbz	r0, 20025b70 <sf_crypto_aes_enc_sync+0x1a>
20025b6e:	e7fe      	b.n	20025b6e <sf_crypto_aes_enc_sync+0x18>
20025b70:	bd08      	pop	{r3, pc}
	...

20025b74 <sbrk_aligned>:
20025b74:	b570      	push	{r4, r5, r6, lr}
20025b76:	4e0f      	ldr	r6, [pc, #60]	@ (20025bb4 <sbrk_aligned+0x40>)
20025b78:	460c      	mov	r4, r1
20025b7a:	4605      	mov	r5, r0
20025b7c:	6831      	ldr	r1, [r6, #0]
20025b7e:	b911      	cbnz	r1, 20025b86 <sbrk_aligned+0x12>
20025b80:	f000 fba4 	bl	200262cc <_sbrk_r>
20025b84:	6030      	str	r0, [r6, #0]
20025b86:	4621      	mov	r1, r4
20025b88:	4628      	mov	r0, r5
20025b8a:	f000 fb9f 	bl	200262cc <_sbrk_r>
20025b8e:	1c43      	adds	r3, r0, #1
20025b90:	d103      	bne.n	20025b9a <sbrk_aligned+0x26>
20025b92:	f04f 34ff 	mov.w	r4, #4294967295
20025b96:	4620      	mov	r0, r4
20025b98:	bd70      	pop	{r4, r5, r6, pc}
20025b9a:	1cc4      	adds	r4, r0, #3
20025b9c:	f024 0403 	bic.w	r4, r4, #3
20025ba0:	42a0      	cmp	r0, r4
20025ba2:	d0f8      	beq.n	20025b96 <sbrk_aligned+0x22>
20025ba4:	1a21      	subs	r1, r4, r0
20025ba6:	4628      	mov	r0, r5
20025ba8:	f000 fb90 	bl	200262cc <_sbrk_r>
20025bac:	3001      	adds	r0, #1
20025bae:	d1f2      	bne.n	20025b96 <sbrk_aligned+0x22>
20025bb0:	e7ef      	b.n	20025b92 <sbrk_aligned+0x1e>
20025bb2:	bf00      	nop
20025bb4:	2004d0cc 	.word	0x2004d0cc

20025bb8 <_malloc_r>:
20025bb8:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025bbc:	1ccd      	adds	r5, r1, #3
20025bbe:	4606      	mov	r6, r0
20025bc0:	f025 0503 	bic.w	r5, r5, #3
20025bc4:	3508      	adds	r5, #8
20025bc6:	2d0c      	cmp	r5, #12
20025bc8:	bf38      	it	cc
20025bca:	250c      	movcc	r5, #12
20025bcc:	2d00      	cmp	r5, #0
20025bce:	db01      	blt.n	20025bd4 <_malloc_r+0x1c>
20025bd0:	42a9      	cmp	r1, r5
20025bd2:	d904      	bls.n	20025bde <_malloc_r+0x26>
20025bd4:	230c      	movs	r3, #12
20025bd6:	6033      	str	r3, [r6, #0]
20025bd8:	2000      	movs	r0, #0
20025bda:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20025bde:	f8df 80d4 	ldr.w	r8, [pc, #212]	@ 20025cb4 <_malloc_r+0xfc>
20025be2:	f000 f869 	bl	20025cb8 <__malloc_lock>
20025be6:	f8d8 3000 	ldr.w	r3, [r8]
20025bea:	461c      	mov	r4, r3
20025bec:	bb44      	cbnz	r4, 20025c40 <_malloc_r+0x88>
20025bee:	4629      	mov	r1, r5
20025bf0:	4630      	mov	r0, r6
20025bf2:	f7ff ffbf 	bl	20025b74 <sbrk_aligned>
20025bf6:	1c43      	adds	r3, r0, #1
20025bf8:	4604      	mov	r4, r0
20025bfa:	d158      	bne.n	20025cae <_malloc_r+0xf6>
20025bfc:	f8d8 4000 	ldr.w	r4, [r8]
20025c00:	4627      	mov	r7, r4
20025c02:	2f00      	cmp	r7, #0
20025c04:	d143      	bne.n	20025c8e <_malloc_r+0xd6>
20025c06:	2c00      	cmp	r4, #0
20025c08:	d04b      	beq.n	20025ca2 <_malloc_r+0xea>
20025c0a:	6823      	ldr	r3, [r4, #0]
20025c0c:	4639      	mov	r1, r7
20025c0e:	4630      	mov	r0, r6
20025c10:	eb04 0903 	add.w	r9, r4, r3
20025c14:	f000 fb5a 	bl	200262cc <_sbrk_r>
20025c18:	4581      	cmp	r9, r0
20025c1a:	d142      	bne.n	20025ca2 <_malloc_r+0xea>
20025c1c:	6821      	ldr	r1, [r4, #0]
20025c1e:	4630      	mov	r0, r6
20025c20:	1a6d      	subs	r5, r5, r1
20025c22:	4629      	mov	r1, r5
20025c24:	f7ff ffa6 	bl	20025b74 <sbrk_aligned>
20025c28:	3001      	adds	r0, #1
20025c2a:	d03a      	beq.n	20025ca2 <_malloc_r+0xea>
20025c2c:	6823      	ldr	r3, [r4, #0]
20025c2e:	442b      	add	r3, r5
20025c30:	6023      	str	r3, [r4, #0]
20025c32:	f8d8 3000 	ldr.w	r3, [r8]
20025c36:	685a      	ldr	r2, [r3, #4]
20025c38:	bb62      	cbnz	r2, 20025c94 <_malloc_r+0xdc>
20025c3a:	f8c8 7000 	str.w	r7, [r8]
20025c3e:	e00f      	b.n	20025c60 <_malloc_r+0xa8>
20025c40:	6822      	ldr	r2, [r4, #0]
20025c42:	1b52      	subs	r2, r2, r5
20025c44:	d420      	bmi.n	20025c88 <_malloc_r+0xd0>
20025c46:	2a0b      	cmp	r2, #11
20025c48:	d917      	bls.n	20025c7a <_malloc_r+0xc2>
20025c4a:	1961      	adds	r1, r4, r5
20025c4c:	42a3      	cmp	r3, r4
20025c4e:	6025      	str	r5, [r4, #0]
20025c50:	bf18      	it	ne
20025c52:	6059      	strne	r1, [r3, #4]
20025c54:	6863      	ldr	r3, [r4, #4]
20025c56:	bf08      	it	eq
20025c58:	f8c8 1000 	streq.w	r1, [r8]
20025c5c:	5162      	str	r2, [r4, r5]
20025c5e:	604b      	str	r3, [r1, #4]
20025c60:	4630      	mov	r0, r6
20025c62:	f000 f82f 	bl	20025cc4 <__malloc_unlock>
20025c66:	f104 000b 	add.w	r0, r4, #11
20025c6a:	1d23      	adds	r3, r4, #4
20025c6c:	f020 0007 	bic.w	r0, r0, #7
20025c70:	1ac2      	subs	r2, r0, r3
20025c72:	bf1c      	itt	ne
20025c74:	1a1b      	subne	r3, r3, r0
20025c76:	50a3      	strne	r3, [r4, r2]
20025c78:	e7af      	b.n	20025bda <_malloc_r+0x22>
20025c7a:	6862      	ldr	r2, [r4, #4]
20025c7c:	42a3      	cmp	r3, r4
20025c7e:	bf0c      	ite	eq
20025c80:	f8c8 2000 	streq.w	r2, [r8]
20025c84:	605a      	strne	r2, [r3, #4]
20025c86:	e7eb      	b.n	20025c60 <_malloc_r+0xa8>
20025c88:	4623      	mov	r3, r4
20025c8a:	6864      	ldr	r4, [r4, #4]
20025c8c:	e7ae      	b.n	20025bec <_malloc_r+0x34>
20025c8e:	463c      	mov	r4, r7
20025c90:	687f      	ldr	r7, [r7, #4]
20025c92:	e7b6      	b.n	20025c02 <_malloc_r+0x4a>
20025c94:	461a      	mov	r2, r3
20025c96:	685b      	ldr	r3, [r3, #4]
20025c98:	42a3      	cmp	r3, r4
20025c9a:	d1fb      	bne.n	20025c94 <_malloc_r+0xdc>
20025c9c:	2300      	movs	r3, #0
20025c9e:	6053      	str	r3, [r2, #4]
20025ca0:	e7de      	b.n	20025c60 <_malloc_r+0xa8>
20025ca2:	230c      	movs	r3, #12
20025ca4:	4630      	mov	r0, r6
20025ca6:	6033      	str	r3, [r6, #0]
20025ca8:	f000 f80c 	bl	20025cc4 <__malloc_unlock>
20025cac:	e794      	b.n	20025bd8 <_malloc_r+0x20>
20025cae:	6005      	str	r5, [r0, #0]
20025cb0:	e7d6      	b.n	20025c60 <_malloc_r+0xa8>
20025cb2:	bf00      	nop
20025cb4:	2004d0d0 	.word	0x2004d0d0

20025cb8 <__malloc_lock>:
20025cb8:	4801      	ldr	r0, [pc, #4]	@ (20025cc0 <__malloc_lock+0x8>)
20025cba:	f000 bb2a 	b.w	20026312 <__retarget_lock_acquire_recursive>
20025cbe:	bf00      	nop
20025cc0:	2004d214 	.word	0x2004d214

20025cc4 <__malloc_unlock>:
20025cc4:	4801      	ldr	r0, [pc, #4]	@ (20025ccc <__malloc_unlock+0x8>)
20025cc6:	f000 bb25 	b.w	20026314 <__retarget_lock_release_recursive>
20025cca:	bf00      	nop
20025ccc:	2004d214 	.word	0x2004d214

20025cd0 <__sflush_r>:
20025cd0:	f9b1 200c 	ldrsh.w	r2, [r1, #12]
20025cd4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20025cd8:	0716      	lsls	r6, r2, #28
20025cda:	4605      	mov	r5, r0
20025cdc:	460c      	mov	r4, r1
20025cde:	d451      	bmi.n	20025d84 <__sflush_r+0xb4>
20025ce0:	684b      	ldr	r3, [r1, #4]
20025ce2:	2b00      	cmp	r3, #0
20025ce4:	dc02      	bgt.n	20025cec <__sflush_r+0x1c>
20025ce6:	6c0b      	ldr	r3, [r1, #64]	@ 0x40
20025ce8:	2b00      	cmp	r3, #0
20025cea:	dd49      	ble.n	20025d80 <__sflush_r+0xb0>
20025cec:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025cee:	2e00      	cmp	r6, #0
20025cf0:	d046      	beq.n	20025d80 <__sflush_r+0xb0>
20025cf2:	2300      	movs	r3, #0
20025cf4:	f412 5280 	ands.w	r2, r2, #4096	@ 0x1000
20025cf8:	682f      	ldr	r7, [r5, #0]
20025cfa:	602b      	str	r3, [r5, #0]
20025cfc:	d031      	beq.n	20025d62 <__sflush_r+0x92>
20025cfe:	6d62      	ldr	r2, [r4, #84]	@ 0x54
20025d00:	89a3      	ldrh	r3, [r4, #12]
20025d02:	0759      	lsls	r1, r3, #29
20025d04:	d505      	bpl.n	20025d12 <__sflush_r+0x42>
20025d06:	6863      	ldr	r3, [r4, #4]
20025d08:	1ad2      	subs	r2, r2, r3
20025d0a:	6b63      	ldr	r3, [r4, #52]	@ 0x34
20025d0c:	b10b      	cbz	r3, 20025d12 <__sflush_r+0x42>
20025d0e:	6c23      	ldr	r3, [r4, #64]	@ 0x40
20025d10:	1ad2      	subs	r2, r2, r3
20025d12:	2300      	movs	r3, #0
20025d14:	6ae6      	ldr	r6, [r4, #44]	@ 0x2c
20025d16:	6a21      	ldr	r1, [r4, #32]
20025d18:	4628      	mov	r0, r5
20025d1a:	47b0      	blx	r6
20025d1c:	1c42      	adds	r2, r0, #1
20025d1e:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025d22:	d106      	bne.n	20025d32 <__sflush_r+0x62>
20025d24:	6829      	ldr	r1, [r5, #0]
20025d26:	291d      	cmp	r1, #29
20025d28:	d845      	bhi.n	20025db6 <__sflush_r+0xe6>
20025d2a:	4a28      	ldr	r2, [pc, #160]	@ (20025dcc <__sflush_r+0xfc>)
20025d2c:	40ca      	lsrs	r2, r1
20025d2e:	07d6      	lsls	r6, r2, #31
20025d30:	d541      	bpl.n	20025db6 <__sflush_r+0xe6>
20025d32:	2200      	movs	r2, #0
20025d34:	04d9      	lsls	r1, r3, #19
20025d36:	6062      	str	r2, [r4, #4]
20025d38:	6922      	ldr	r2, [r4, #16]
20025d3a:	6022      	str	r2, [r4, #0]
20025d3c:	d504      	bpl.n	20025d48 <__sflush_r+0x78>
20025d3e:	1c42      	adds	r2, r0, #1
20025d40:	d101      	bne.n	20025d46 <__sflush_r+0x76>
20025d42:	682b      	ldr	r3, [r5, #0]
20025d44:	b903      	cbnz	r3, 20025d48 <__sflush_r+0x78>
20025d46:	6560      	str	r0, [r4, #84]	@ 0x54
20025d48:	6b61      	ldr	r1, [r4, #52]	@ 0x34
20025d4a:	602f      	str	r7, [r5, #0]
20025d4c:	b1c1      	cbz	r1, 20025d80 <__sflush_r+0xb0>
20025d4e:	f104 0344 	add.w	r3, r4, #68	@ 0x44
20025d52:	4299      	cmp	r1, r3
20025d54:	d002      	beq.n	20025d5c <__sflush_r+0x8c>
20025d56:	4628      	mov	r0, r5
20025d58:	f000 faf8 	bl	2002634c <_free_r>
20025d5c:	2300      	movs	r3, #0
20025d5e:	6363      	str	r3, [r4, #52]	@ 0x34
20025d60:	e00e      	b.n	20025d80 <__sflush_r+0xb0>
20025d62:	2301      	movs	r3, #1
20025d64:	6a21      	ldr	r1, [r4, #32]
20025d66:	4628      	mov	r0, r5
20025d68:	47b0      	blx	r6
20025d6a:	4602      	mov	r2, r0
20025d6c:	1c50      	adds	r0, r2, #1
20025d6e:	d1c7      	bne.n	20025d00 <__sflush_r+0x30>
20025d70:	682b      	ldr	r3, [r5, #0]
20025d72:	2b00      	cmp	r3, #0
20025d74:	d0c4      	beq.n	20025d00 <__sflush_r+0x30>
20025d76:	2b1d      	cmp	r3, #29
20025d78:	d001      	beq.n	20025d7e <__sflush_r+0xae>
20025d7a:	2b16      	cmp	r3, #22
20025d7c:	d119      	bne.n	20025db2 <__sflush_r+0xe2>
20025d7e:	602f      	str	r7, [r5, #0]
20025d80:	2000      	movs	r0, #0
20025d82:	e01d      	b.n	20025dc0 <__sflush_r+0xf0>
20025d84:	690f      	ldr	r7, [r1, #16]
20025d86:	2f00      	cmp	r7, #0
20025d88:	d0fa      	beq.n	20025d80 <__sflush_r+0xb0>
20025d8a:	0793      	lsls	r3, r2, #30
20025d8c:	680e      	ldr	r6, [r1, #0]
20025d8e:	600f      	str	r7, [r1, #0]
20025d90:	bf0c      	ite	eq
20025d92:	694b      	ldreq	r3, [r1, #20]
20025d94:	2300      	movne	r3, #0
20025d96:	eba6 0807 	sub.w	r8, r6, r7
20025d9a:	608b      	str	r3, [r1, #8]
20025d9c:	f1b8 0f00 	cmp.w	r8, #0
20025da0:	ddee      	ble.n	20025d80 <__sflush_r+0xb0>
20025da2:	4643      	mov	r3, r8
20025da4:	463a      	mov	r2, r7
20025da6:	6a21      	ldr	r1, [r4, #32]
20025da8:	4628      	mov	r0, r5
20025daa:	6aa6      	ldr	r6, [r4, #40]	@ 0x28
20025dac:	47b0      	blx	r6
20025dae:	2800      	cmp	r0, #0
20025db0:	dc08      	bgt.n	20025dc4 <__sflush_r+0xf4>
20025db2:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025db6:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
20025dba:	f04f 30ff 	mov.w	r0, #4294967295
20025dbe:	81a3      	strh	r3, [r4, #12]
20025dc0:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20025dc4:	4407      	add	r7, r0
20025dc6:	eba8 0800 	sub.w	r8, r8, r0
20025dca:	e7e7      	b.n	20025d9c <__sflush_r+0xcc>
20025dcc:	20400001 	.word	0x20400001

20025dd0 <_fflush_r>:
20025dd0:	b538      	push	{r3, r4, r5, lr}
20025dd2:	690b      	ldr	r3, [r1, #16]
20025dd4:	4605      	mov	r5, r0
20025dd6:	460c      	mov	r4, r1
20025dd8:	b913      	cbnz	r3, 20025de0 <_fflush_r+0x10>
20025dda:	2500      	movs	r5, #0
20025ddc:	4628      	mov	r0, r5
20025dde:	bd38      	pop	{r3, r4, r5, pc}
20025de0:	b118      	cbz	r0, 20025dea <_fflush_r+0x1a>
20025de2:	6a03      	ldr	r3, [r0, #32]
20025de4:	b90b      	cbnz	r3, 20025dea <_fflush_r+0x1a>
20025de6:	f000 f8a9 	bl	20025f3c <__sinit>
20025dea:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20025dee:	2b00      	cmp	r3, #0
20025df0:	d0f3      	beq.n	20025dda <_fflush_r+0xa>
20025df2:	6e62      	ldr	r2, [r4, #100]	@ 0x64
20025df4:	07d0      	lsls	r0, r2, #31
20025df6:	d404      	bmi.n	20025e02 <_fflush_r+0x32>
20025df8:	0599      	lsls	r1, r3, #22
20025dfa:	d402      	bmi.n	20025e02 <_fflush_r+0x32>
20025dfc:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025dfe:	f000 fa88 	bl	20026312 <__retarget_lock_acquire_recursive>
20025e02:	4628      	mov	r0, r5
20025e04:	4621      	mov	r1, r4
20025e06:	f7ff ff63 	bl	20025cd0 <__sflush_r>
20025e0a:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025e0c:	4605      	mov	r5, r0
20025e0e:	07da      	lsls	r2, r3, #31
20025e10:	d4e4      	bmi.n	20025ddc <_fflush_r+0xc>
20025e12:	89a3      	ldrh	r3, [r4, #12]
20025e14:	059b      	lsls	r3, r3, #22
20025e16:	d4e1      	bmi.n	20025ddc <_fflush_r+0xc>
20025e18:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025e1a:	f000 fa7b 	bl	20026314 <__retarget_lock_release_recursive>
20025e1e:	e7dd      	b.n	20025ddc <_fflush_r+0xc>

20025e20 <std>:
20025e20:	2300      	movs	r3, #0
20025e22:	b510      	push	{r4, lr}
20025e24:	4604      	mov	r4, r0
20025e26:	6083      	str	r3, [r0, #8]
20025e28:	8181      	strh	r1, [r0, #12]
20025e2a:	4619      	mov	r1, r3
20025e2c:	6643      	str	r3, [r0, #100]	@ 0x64
20025e2e:	81c2      	strh	r2, [r0, #14]
20025e30:	2208      	movs	r2, #8
20025e32:	6183      	str	r3, [r0, #24]
20025e34:	e9c0 3300 	strd	r3, r3, [r0]
20025e38:	e9c0 3304 	strd	r3, r3, [r0, #16]
20025e3c:	305c      	adds	r0, #92	@ 0x5c
20025e3e:	f000 fa09 	bl	20026254 <memset>
20025e42:	4b0d      	ldr	r3, [pc, #52]	@ (20025e78 <std+0x58>)
20025e44:	6224      	str	r4, [r4, #32]
20025e46:	6263      	str	r3, [r4, #36]	@ 0x24
20025e48:	4b0c      	ldr	r3, [pc, #48]	@ (20025e7c <std+0x5c>)
20025e4a:	62a3      	str	r3, [r4, #40]	@ 0x28
20025e4c:	4b0c      	ldr	r3, [pc, #48]	@ (20025e80 <std+0x60>)
20025e4e:	62e3      	str	r3, [r4, #44]	@ 0x2c
20025e50:	4b0c      	ldr	r3, [pc, #48]	@ (20025e84 <std+0x64>)
20025e52:	6323      	str	r3, [r4, #48]	@ 0x30
20025e54:	4b0c      	ldr	r3, [pc, #48]	@ (20025e88 <std+0x68>)
20025e56:	429c      	cmp	r4, r3
20025e58:	d006      	beq.n	20025e68 <std+0x48>
20025e5a:	f103 0268 	add.w	r2, r3, #104	@ 0x68
20025e5e:	4294      	cmp	r4, r2
20025e60:	d002      	beq.n	20025e68 <std+0x48>
20025e62:	33d0      	adds	r3, #208	@ 0xd0
20025e64:	429c      	cmp	r4, r3
20025e66:	d105      	bne.n	20025e74 <std+0x54>
20025e68:	f104 0058 	add.w	r0, r4, #88	@ 0x58
20025e6c:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025e70:	f000 ba4e 	b.w	20026310 <__retarget_lock_init_recursive>
20025e74:	bd10      	pop	{r4, pc}
20025e76:	bf00      	nop
20025e78:	20026089 	.word	0x20026089
20025e7c:	200260ab 	.word	0x200260ab
20025e80:	200260e3 	.word	0x200260e3
20025e84:	20026109 	.word	0x20026109
20025e88:	2004d0d4 	.word	0x2004d0d4

20025e8c <stdio_exit_handler>:
20025e8c:	4a02      	ldr	r2, [pc, #8]	@ (20025e98 <stdio_exit_handler+0xc>)
20025e8e:	4903      	ldr	r1, [pc, #12]	@ (20025e9c <stdio_exit_handler+0x10>)
20025e90:	4803      	ldr	r0, [pc, #12]	@ (20025ea0 <stdio_exit_handler+0x14>)
20025e92:	f000 b86b 	b.w	20025f6c <_fwalk_sglue>
20025e96:	bf00      	nop
20025e98:	200449a4 	.word	0x200449a4
20025e9c:	20025dd1 	.word	0x20025dd1
20025ea0:	200449b4 	.word	0x200449b4

20025ea4 <cleanup_stdio>:
20025ea4:	6841      	ldr	r1, [r0, #4]
20025ea6:	4b0c      	ldr	r3, [pc, #48]	@ (20025ed8 <cleanup_stdio+0x34>)
20025ea8:	4299      	cmp	r1, r3
20025eaa:	b510      	push	{r4, lr}
20025eac:	4604      	mov	r4, r0
20025eae:	d001      	beq.n	20025eb4 <cleanup_stdio+0x10>
20025eb0:	f7ff ff8e 	bl	20025dd0 <_fflush_r>
20025eb4:	68a1      	ldr	r1, [r4, #8]
20025eb6:	4b09      	ldr	r3, [pc, #36]	@ (20025edc <cleanup_stdio+0x38>)
20025eb8:	4299      	cmp	r1, r3
20025eba:	d002      	beq.n	20025ec2 <cleanup_stdio+0x1e>
20025ebc:	4620      	mov	r0, r4
20025ebe:	f7ff ff87 	bl	20025dd0 <_fflush_r>
20025ec2:	68e1      	ldr	r1, [r4, #12]
20025ec4:	4b06      	ldr	r3, [pc, #24]	@ (20025ee0 <cleanup_stdio+0x3c>)
20025ec6:	4299      	cmp	r1, r3
20025ec8:	d004      	beq.n	20025ed4 <cleanup_stdio+0x30>
20025eca:	4620      	mov	r0, r4
20025ecc:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025ed0:	f7ff bf7e 	b.w	20025dd0 <_fflush_r>
20025ed4:	bd10      	pop	{r4, pc}
20025ed6:	bf00      	nop
20025ed8:	2004d0d4 	.word	0x2004d0d4
20025edc:	2004d13c 	.word	0x2004d13c
20025ee0:	2004d1a4 	.word	0x2004d1a4

20025ee4 <global_stdio_init.part.0>:
20025ee4:	4b0c      	ldr	r3, [pc, #48]	@ (20025f18 <global_stdio_init.part.0+0x34>)
20025ee6:	2104      	movs	r1, #4
20025ee8:	4a0c      	ldr	r2, [pc, #48]	@ (20025f1c <global_stdio_init.part.0+0x38>)
20025eea:	480d      	ldr	r0, [pc, #52]	@ (20025f20 <global_stdio_init.part.0+0x3c>)
20025eec:	b510      	push	{r4, lr}
20025eee:	601a      	str	r2, [r3, #0]
20025ef0:	2200      	movs	r2, #0
20025ef2:	f7ff ff95 	bl	20025e20 <std>
20025ef6:	4b0a      	ldr	r3, [pc, #40]	@ (20025f20 <global_stdio_init.part.0+0x3c>)
20025ef8:	2201      	movs	r2, #1
20025efa:	2109      	movs	r1, #9
20025efc:	461c      	mov	r4, r3
20025efe:	f103 0068 	add.w	r0, r3, #104	@ 0x68
20025f02:	f7ff ff8d 	bl	20025e20 <std>
20025f06:	2202      	movs	r2, #2
20025f08:	f104 00d0 	add.w	r0, r4, #208	@ 0xd0
20025f0c:	2112      	movs	r1, #18
20025f0e:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025f12:	f7ff bf85 	b.w	20025e20 <std>
20025f16:	bf00      	nop
20025f18:	2004d20c 	.word	0x2004d20c
20025f1c:	20025e8d 	.word	0x20025e8d
20025f20:	2004d0d4 	.word	0x2004d0d4

20025f24 <__sfp_lock_acquire>:
20025f24:	4801      	ldr	r0, [pc, #4]	@ (20025f2c <__sfp_lock_acquire+0x8>)
20025f26:	f000 b9f4 	b.w	20026312 <__retarget_lock_acquire_recursive>
20025f2a:	bf00      	nop
20025f2c:	2004d215 	.word	0x2004d215

20025f30 <__sfp_lock_release>:
20025f30:	4801      	ldr	r0, [pc, #4]	@ (20025f38 <__sfp_lock_release+0x8>)
20025f32:	f000 b9ef 	b.w	20026314 <__retarget_lock_release_recursive>
20025f36:	bf00      	nop
20025f38:	2004d215 	.word	0x2004d215

20025f3c <__sinit>:
20025f3c:	b510      	push	{r4, lr}
20025f3e:	4604      	mov	r4, r0
20025f40:	f7ff fff0 	bl	20025f24 <__sfp_lock_acquire>
20025f44:	6a23      	ldr	r3, [r4, #32]
20025f46:	b11b      	cbz	r3, 20025f50 <__sinit+0x14>
20025f48:	e8bd 4010 	ldmia.w	sp!, {r4, lr}
20025f4c:	f7ff bff0 	b.w	20025f30 <__sfp_lock_release>
20025f50:	4b04      	ldr	r3, [pc, #16]	@ (20025f64 <__sinit+0x28>)
20025f52:	6223      	str	r3, [r4, #32]
20025f54:	4b04      	ldr	r3, [pc, #16]	@ (20025f68 <__sinit+0x2c>)
20025f56:	681b      	ldr	r3, [r3, #0]
20025f58:	2b00      	cmp	r3, #0
20025f5a:	d1f5      	bne.n	20025f48 <__sinit+0xc>
20025f5c:	f7ff ffc2 	bl	20025ee4 <global_stdio_init.part.0>
20025f60:	e7f2      	b.n	20025f48 <__sinit+0xc>
20025f62:	bf00      	nop
20025f64:	20025ea5 	.word	0x20025ea5
20025f68:	2004d20c 	.word	0x2004d20c

20025f6c <_fwalk_sglue>:
20025f6c:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
20025f70:	4607      	mov	r7, r0
20025f72:	4688      	mov	r8, r1
20025f74:	4614      	mov	r4, r2
20025f76:	2600      	movs	r6, #0
20025f78:	e9d4 9501 	ldrd	r9, r5, [r4, #4]
20025f7c:	f1b9 0901 	subs.w	r9, r9, #1
20025f80:	d505      	bpl.n	20025f8e <_fwalk_sglue+0x22>
20025f82:	6824      	ldr	r4, [r4, #0]
20025f84:	2c00      	cmp	r4, #0
20025f86:	d1f7      	bne.n	20025f78 <_fwalk_sglue+0xc>
20025f88:	4630      	mov	r0, r6
20025f8a:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
20025f8e:	89ab      	ldrh	r3, [r5, #12]
20025f90:	2b01      	cmp	r3, #1
20025f92:	d907      	bls.n	20025fa4 <_fwalk_sglue+0x38>
20025f94:	f9b5 300e 	ldrsh.w	r3, [r5, #14]
20025f98:	3301      	adds	r3, #1
20025f9a:	d003      	beq.n	20025fa4 <_fwalk_sglue+0x38>
20025f9c:	4629      	mov	r1, r5
20025f9e:	4638      	mov	r0, r7
20025fa0:	47c0      	blx	r8
20025fa2:	4306      	orrs	r6, r0
20025fa4:	3568      	adds	r5, #104	@ 0x68
20025fa6:	e7e9      	b.n	20025f7c <_fwalk_sglue+0x10>

20025fa8 <iprintf>:
20025fa8:	b40f      	push	{r0, r1, r2, r3}
20025faa:	b507      	push	{r0, r1, r2, lr}
20025fac:	4906      	ldr	r1, [pc, #24]	@ (20025fc8 <iprintf+0x20>)
20025fae:	ab04      	add	r3, sp, #16
20025fb0:	6808      	ldr	r0, [r1, #0]
20025fb2:	f853 2b04 	ldr.w	r2, [r3], #4
20025fb6:	6881      	ldr	r1, [r0, #8]
20025fb8:	9301      	str	r3, [sp, #4]
20025fba:	f000 fa3b 	bl	20026434 <_vfiprintf_r>
20025fbe:	b003      	add	sp, #12
20025fc0:	f85d eb04 	ldr.w	lr, [sp], #4
20025fc4:	b004      	add	sp, #16
20025fc6:	4770      	bx	lr
20025fc8:	200449b0 	.word	0x200449b0

20025fcc <_puts_r>:
20025fcc:	6a03      	ldr	r3, [r0, #32]
20025fce:	b570      	push	{r4, r5, r6, lr}
20025fd0:	4605      	mov	r5, r0
20025fd2:	460e      	mov	r6, r1
20025fd4:	6884      	ldr	r4, [r0, #8]
20025fd6:	b90b      	cbnz	r3, 20025fdc <_puts_r+0x10>
20025fd8:	f7ff ffb0 	bl	20025f3c <__sinit>
20025fdc:	6e63      	ldr	r3, [r4, #100]	@ 0x64
20025fde:	07db      	lsls	r3, r3, #31
20025fe0:	d405      	bmi.n	20025fee <_puts_r+0x22>
20025fe2:	89a3      	ldrh	r3, [r4, #12]
20025fe4:	0598      	lsls	r0, r3, #22
20025fe6:	d402      	bmi.n	20025fee <_puts_r+0x22>
20025fe8:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20025fea:	f000 f992 	bl	20026312 <__retarget_lock_acquire_recursive>
20025fee:	89a3      	ldrh	r3, [r4, #12]
20025ff0:	0719      	lsls	r1, r3, #28
20025ff2:	d502      	bpl.n	20025ffa <_puts_r+0x2e>
20025ff4:	6923      	ldr	r3, [r4, #16]
20025ff6:	2b00      	cmp	r3, #0
20025ff8:	d135      	bne.n	20026066 <_puts_r+0x9a>
20025ffa:	4621      	mov	r1, r4
20025ffc:	4628      	mov	r0, r5
20025ffe:	f000 f8c5 	bl	2002618c <__swsetup_r>
20026002:	b380      	cbz	r0, 20026066 <_puts_r+0x9a>
20026004:	f04f 35ff 	mov.w	r5, #4294967295
20026008:	6e63      	ldr	r3, [r4, #100]	@ 0x64
2002600a:	07da      	lsls	r2, r3, #31
2002600c:	d405      	bmi.n	2002601a <_puts_r+0x4e>
2002600e:	89a3      	ldrh	r3, [r4, #12]
20026010:	059b      	lsls	r3, r3, #22
20026012:	d402      	bmi.n	2002601a <_puts_r+0x4e>
20026014:	6da0      	ldr	r0, [r4, #88]	@ 0x58
20026016:	f000 f97d 	bl	20026314 <__retarget_lock_release_recursive>
2002601a:	4628      	mov	r0, r5
2002601c:	bd70      	pop	{r4, r5, r6, pc}
2002601e:	2b00      	cmp	r3, #0
20026020:	da04      	bge.n	2002602c <_puts_r+0x60>
20026022:	69a2      	ldr	r2, [r4, #24]
20026024:	4293      	cmp	r3, r2
20026026:	db17      	blt.n	20026058 <_puts_r+0x8c>
20026028:	290a      	cmp	r1, #10
2002602a:	d015      	beq.n	20026058 <_puts_r+0x8c>
2002602c:	6823      	ldr	r3, [r4, #0]
2002602e:	1c5a      	adds	r2, r3, #1
20026030:	6022      	str	r2, [r4, #0]
20026032:	7019      	strb	r1, [r3, #0]
20026034:	68a3      	ldr	r3, [r4, #8]
20026036:	f816 1f01 	ldrb.w	r1, [r6, #1]!
2002603a:	3b01      	subs	r3, #1
2002603c:	60a3      	str	r3, [r4, #8]
2002603e:	2900      	cmp	r1, #0
20026040:	d1ed      	bne.n	2002601e <_puts_r+0x52>
20026042:	2b00      	cmp	r3, #0
20026044:	da11      	bge.n	2002606a <_puts_r+0x9e>
20026046:	4622      	mov	r2, r4
20026048:	210a      	movs	r1, #10
2002604a:	4628      	mov	r0, r5
2002604c:	f000 f860 	bl	20026110 <__swbuf_r>
20026050:	3001      	adds	r0, #1
20026052:	d0d7      	beq.n	20026004 <_puts_r+0x38>
20026054:	250a      	movs	r5, #10
20026056:	e7d7      	b.n	20026008 <_puts_r+0x3c>
20026058:	4622      	mov	r2, r4
2002605a:	4628      	mov	r0, r5
2002605c:	f000 f858 	bl	20026110 <__swbuf_r>
20026060:	3001      	adds	r0, #1
20026062:	d1e7      	bne.n	20026034 <_puts_r+0x68>
20026064:	e7ce      	b.n	20026004 <_puts_r+0x38>
20026066:	3e01      	subs	r6, #1
20026068:	e7e4      	b.n	20026034 <_puts_r+0x68>
2002606a:	6823      	ldr	r3, [r4, #0]
2002606c:	1c5a      	adds	r2, r3, #1
2002606e:	6022      	str	r2, [r4, #0]
20026070:	220a      	movs	r2, #10
20026072:	701a      	strb	r2, [r3, #0]
20026074:	e7ee      	b.n	20026054 <_puts_r+0x88>
	...

20026078 <puts>:
20026078:	4b02      	ldr	r3, [pc, #8]	@ (20026084 <puts+0xc>)
2002607a:	4601      	mov	r1, r0
2002607c:	6818      	ldr	r0, [r3, #0]
2002607e:	f7ff bfa5 	b.w	20025fcc <_puts_r>
20026082:	bf00      	nop
20026084:	200449b0 	.word	0x200449b0

20026088 <__sread>:
20026088:	b510      	push	{r4, lr}
2002608a:	460c      	mov	r4, r1
2002608c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20026090:	f000 f90a 	bl	200262a8 <_read_r>
20026094:	2800      	cmp	r0, #0
20026096:	bfab      	itete	ge
20026098:	6d63      	ldrge	r3, [r4, #84]	@ 0x54
2002609a:	89a3      	ldrhlt	r3, [r4, #12]
2002609c:	181b      	addge	r3, r3, r0
2002609e:	f423 5380 	biclt.w	r3, r3, #4096	@ 0x1000
200260a2:	bfac      	ite	ge
200260a4:	6563      	strge	r3, [r4, #84]	@ 0x54
200260a6:	81a3      	strhlt	r3, [r4, #12]
200260a8:	bd10      	pop	{r4, pc}

200260aa <__swrite>:
200260aa:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
200260ae:	461f      	mov	r7, r3
200260b0:	898b      	ldrh	r3, [r1, #12]
200260b2:	4605      	mov	r5, r0
200260b4:	460c      	mov	r4, r1
200260b6:	05db      	lsls	r3, r3, #23
200260b8:	4616      	mov	r6, r2
200260ba:	d505      	bpl.n	200260c8 <__swrite+0x1e>
200260bc:	2302      	movs	r3, #2
200260be:	2200      	movs	r2, #0
200260c0:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200260c4:	f000 f8de 	bl	20026284 <_lseek_r>
200260c8:	89a3      	ldrh	r3, [r4, #12]
200260ca:	4632      	mov	r2, r6
200260cc:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
200260d0:	4628      	mov	r0, r5
200260d2:	f423 5380 	bic.w	r3, r3, #4096	@ 0x1000
200260d6:	81a3      	strh	r3, [r4, #12]
200260d8:	463b      	mov	r3, r7
200260da:	e8bd 41f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, lr}
200260de:	f000 b905 	b.w	200262ec <_write_r>

200260e2 <__sseek>:
200260e2:	b510      	push	{r4, lr}
200260e4:	460c      	mov	r4, r1
200260e6:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
200260ea:	f000 f8cb 	bl	20026284 <_lseek_r>
200260ee:	1c42      	adds	r2, r0, #1
200260f0:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200260f4:	bf15      	itete	ne
200260f6:	6560      	strne	r0, [r4, #84]	@ 0x54
200260f8:	f423 5380 	biceq.w	r3, r3, #4096	@ 0x1000
200260fc:	f443 5380 	orrne.w	r3, r3, #4096	@ 0x1000
20026100:	81a3      	strheq	r3, [r4, #12]
20026102:	bf18      	it	ne
20026104:	81a3      	strhne	r3, [r4, #12]
20026106:	bd10      	pop	{r4, pc}

20026108 <__sclose>:
20026108:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
2002610c:	f000 b8aa 	b.w	20026264 <_close_r>

20026110 <__swbuf_r>:
20026110:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20026112:	460e      	mov	r6, r1
20026114:	4614      	mov	r4, r2
20026116:	4605      	mov	r5, r0
20026118:	b118      	cbz	r0, 20026122 <__swbuf_r+0x12>
2002611a:	6a03      	ldr	r3, [r0, #32]
2002611c:	b90b      	cbnz	r3, 20026122 <__swbuf_r+0x12>
2002611e:	f7ff ff0d 	bl	20025f3c <__sinit>
20026122:	69a3      	ldr	r3, [r4, #24]
20026124:	60a3      	str	r3, [r4, #8]
20026126:	89a3      	ldrh	r3, [r4, #12]
20026128:	071a      	lsls	r2, r3, #28
2002612a:	d501      	bpl.n	20026130 <__swbuf_r+0x20>
2002612c:	6923      	ldr	r3, [r4, #16]
2002612e:	b943      	cbnz	r3, 20026142 <__swbuf_r+0x32>
20026130:	4621      	mov	r1, r4
20026132:	4628      	mov	r0, r5
20026134:	f000 f82a 	bl	2002618c <__swsetup_r>
20026138:	b118      	cbz	r0, 20026142 <__swbuf_r+0x32>
2002613a:	f04f 37ff 	mov.w	r7, #4294967295
2002613e:	4638      	mov	r0, r7
20026140:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
20026142:	6823      	ldr	r3, [r4, #0]
20026144:	b2f6      	uxtb	r6, r6
20026146:	6922      	ldr	r2, [r4, #16]
20026148:	4637      	mov	r7, r6
2002614a:	1a98      	subs	r0, r3, r2
2002614c:	6963      	ldr	r3, [r4, #20]
2002614e:	4283      	cmp	r3, r0
20026150:	dc05      	bgt.n	2002615e <__swbuf_r+0x4e>
20026152:	4621      	mov	r1, r4
20026154:	4628      	mov	r0, r5
20026156:	f7ff fe3b 	bl	20025dd0 <_fflush_r>
2002615a:	2800      	cmp	r0, #0
2002615c:	d1ed      	bne.n	2002613a <__swbuf_r+0x2a>
2002615e:	68a3      	ldr	r3, [r4, #8]
20026160:	3b01      	subs	r3, #1
20026162:	60a3      	str	r3, [r4, #8]
20026164:	6823      	ldr	r3, [r4, #0]
20026166:	1c5a      	adds	r2, r3, #1
20026168:	6022      	str	r2, [r4, #0]
2002616a:	701e      	strb	r6, [r3, #0]
2002616c:	1c43      	adds	r3, r0, #1
2002616e:	6962      	ldr	r2, [r4, #20]
20026170:	429a      	cmp	r2, r3
20026172:	d004      	beq.n	2002617e <__swbuf_r+0x6e>
20026174:	89a3      	ldrh	r3, [r4, #12]
20026176:	07db      	lsls	r3, r3, #31
20026178:	d5e1      	bpl.n	2002613e <__swbuf_r+0x2e>
2002617a:	2e0a      	cmp	r6, #10
2002617c:	d1df      	bne.n	2002613e <__swbuf_r+0x2e>
2002617e:	4621      	mov	r1, r4
20026180:	4628      	mov	r0, r5
20026182:	f7ff fe25 	bl	20025dd0 <_fflush_r>
20026186:	2800      	cmp	r0, #0
20026188:	d0d9      	beq.n	2002613e <__swbuf_r+0x2e>
2002618a:	e7d6      	b.n	2002613a <__swbuf_r+0x2a>

2002618c <__swsetup_r>:
2002618c:	b538      	push	{r3, r4, r5, lr}
2002618e:	4b28      	ldr	r3, [pc, #160]	@ (20026230 <__swsetup_r+0xa4>)
20026190:	4605      	mov	r5, r0
20026192:	460c      	mov	r4, r1
20026194:	6818      	ldr	r0, [r3, #0]
20026196:	b118      	cbz	r0, 200261a0 <__swsetup_r+0x14>
20026198:	6a03      	ldr	r3, [r0, #32]
2002619a:	b90b      	cbnz	r3, 200261a0 <__swsetup_r+0x14>
2002619c:	f7ff fece 	bl	20025f3c <__sinit>
200261a0:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200261a4:	071a      	lsls	r2, r3, #28
200261a6:	d421      	bmi.n	200261ec <__swsetup_r+0x60>
200261a8:	06d8      	lsls	r0, r3, #27
200261aa:	d407      	bmi.n	200261bc <__swsetup_r+0x30>
200261ac:	2209      	movs	r2, #9
200261ae:	602a      	str	r2, [r5, #0]
200261b0:	f043 0340 	orr.w	r3, r3, #64	@ 0x40
200261b4:	f04f 30ff 	mov.w	r0, #4294967295
200261b8:	81a3      	strh	r3, [r4, #12]
200261ba:	e030      	b.n	2002621e <__swsetup_r+0x92>
200261bc:	0759      	lsls	r1, r3, #29
200261be:	d512      	bpl.n	200261e6 <__swsetup_r+0x5a>
200261c0:	6b61      	ldr	r1, [r4, #52]	@ 0x34
200261c2:	b141      	cbz	r1, 200261d6 <__swsetup_r+0x4a>
200261c4:	f104 0344 	add.w	r3, r4, #68	@ 0x44
200261c8:	4299      	cmp	r1, r3
200261ca:	d002      	beq.n	200261d2 <__swsetup_r+0x46>
200261cc:	4628      	mov	r0, r5
200261ce:	f000 f8bd 	bl	2002634c <_free_r>
200261d2:	2300      	movs	r3, #0
200261d4:	6363      	str	r3, [r4, #52]	@ 0x34
200261d6:	2200      	movs	r2, #0
200261d8:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
200261dc:	6062      	str	r2, [r4, #4]
200261de:	f023 0324 	bic.w	r3, r3, #36	@ 0x24
200261e2:	6922      	ldr	r2, [r4, #16]
200261e4:	6022      	str	r2, [r4, #0]
200261e6:	f043 0308 	orr.w	r3, r3, #8
200261ea:	81a3      	strh	r3, [r4, #12]
200261ec:	6922      	ldr	r2, [r4, #16]
200261ee:	b93a      	cbnz	r2, 20026200 <__swsetup_r+0x74>
200261f0:	059a      	lsls	r2, r3, #22
200261f2:	d501      	bpl.n	200261f8 <__swsetup_r+0x6c>
200261f4:	0618      	lsls	r0, r3, #24
200261f6:	d503      	bpl.n	20026200 <__swsetup_r+0x74>
200261f8:	4621      	mov	r1, r4
200261fa:	4628      	mov	r0, r5
200261fc:	f000 fbe8 	bl	200269d0 <__smakebuf_r>
20026200:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20026204:	f013 0201 	ands.w	r2, r3, #1
20026208:	d00a      	beq.n	20026220 <__swsetup_r+0x94>
2002620a:	2200      	movs	r2, #0
2002620c:	60a2      	str	r2, [r4, #8]
2002620e:	6962      	ldr	r2, [r4, #20]
20026210:	4252      	negs	r2, r2
20026212:	61a2      	str	r2, [r4, #24]
20026214:	6922      	ldr	r2, [r4, #16]
20026216:	b942      	cbnz	r2, 2002622a <__swsetup_r+0x9e>
20026218:	f013 0080 	ands.w	r0, r3, #128	@ 0x80
2002621c:	d1c8      	bne.n	200261b0 <__swsetup_r+0x24>
2002621e:	bd38      	pop	{r3, r4, r5, pc}
20026220:	0799      	lsls	r1, r3, #30
20026222:	bf58      	it	pl
20026224:	6962      	ldrpl	r2, [r4, #20]
20026226:	60a2      	str	r2, [r4, #8]
20026228:	e7f4      	b.n	20026214 <__swsetup_r+0x88>
2002622a:	2000      	movs	r0, #0
2002622c:	e7f7      	b.n	2002621e <__swsetup_r+0x92>
2002622e:	bf00      	nop
20026230:	200449b0 	.word	0x200449b0

20026234 <memcmp>:
20026234:	3901      	subs	r1, #1
20026236:	4402      	add	r2, r0
20026238:	b510      	push	{r4, lr}
2002623a:	4290      	cmp	r0, r2
2002623c:	d101      	bne.n	20026242 <memcmp+0xe>
2002623e:	2000      	movs	r0, #0
20026240:	e005      	b.n	2002624e <memcmp+0x1a>
20026242:	7803      	ldrb	r3, [r0, #0]
20026244:	f811 4f01 	ldrb.w	r4, [r1, #1]!
20026248:	42a3      	cmp	r3, r4
2002624a:	d001      	beq.n	20026250 <memcmp+0x1c>
2002624c:	1b18      	subs	r0, r3, r4
2002624e:	bd10      	pop	{r4, pc}
20026250:	3001      	adds	r0, #1
20026252:	e7f2      	b.n	2002623a <memcmp+0x6>

20026254 <memset>:
20026254:	4402      	add	r2, r0
20026256:	4603      	mov	r3, r0
20026258:	4293      	cmp	r3, r2
2002625a:	d100      	bne.n	2002625e <memset+0xa>
2002625c:	4770      	bx	lr
2002625e:	f803 1b01 	strb.w	r1, [r3], #1
20026262:	e7f9      	b.n	20026258 <memset+0x4>

20026264 <_close_r>:
20026264:	b538      	push	{r3, r4, r5, lr}
20026266:	2300      	movs	r3, #0
20026268:	4d05      	ldr	r5, [pc, #20]	@ (20026280 <_close_r+0x1c>)
2002626a:	4604      	mov	r4, r0
2002626c:	4608      	mov	r0, r1
2002626e:	602b      	str	r3, [r5, #0]
20026270:	f7fb fa14 	bl	2002169c <_close>
20026274:	1c43      	adds	r3, r0, #1
20026276:	d102      	bne.n	2002627e <_close_r+0x1a>
20026278:	682b      	ldr	r3, [r5, #0]
2002627a:	b103      	cbz	r3, 2002627e <_close_r+0x1a>
2002627c:	6023      	str	r3, [r4, #0]
2002627e:	bd38      	pop	{r3, r4, r5, pc}
20026280:	2004d210 	.word	0x2004d210

20026284 <_lseek_r>:
20026284:	b538      	push	{r3, r4, r5, lr}
20026286:	4604      	mov	r4, r0
20026288:	4d06      	ldr	r5, [pc, #24]	@ (200262a4 <_lseek_r+0x20>)
2002628a:	4608      	mov	r0, r1
2002628c:	4611      	mov	r1, r2
2002628e:	2200      	movs	r2, #0
20026290:	602a      	str	r2, [r5, #0]
20026292:	461a      	mov	r2, r3
20026294:	f7fb fa05 	bl	200216a2 <_lseek>
20026298:	1c43      	adds	r3, r0, #1
2002629a:	d102      	bne.n	200262a2 <_lseek_r+0x1e>
2002629c:	682b      	ldr	r3, [r5, #0]
2002629e:	b103      	cbz	r3, 200262a2 <_lseek_r+0x1e>
200262a0:	6023      	str	r3, [r4, #0]
200262a2:	bd38      	pop	{r3, r4, r5, pc}
200262a4:	2004d210 	.word	0x2004d210

200262a8 <_read_r>:
200262a8:	b538      	push	{r3, r4, r5, lr}
200262aa:	4604      	mov	r4, r0
200262ac:	4d06      	ldr	r5, [pc, #24]	@ (200262c8 <_read_r+0x20>)
200262ae:	4608      	mov	r0, r1
200262b0:	4611      	mov	r1, r2
200262b2:	2200      	movs	r2, #0
200262b4:	602a      	str	r2, [r5, #0]
200262b6:	461a      	mov	r2, r3
200262b8:	f7fb f9f6 	bl	200216a8 <_read>
200262bc:	1c43      	adds	r3, r0, #1
200262be:	d102      	bne.n	200262c6 <_read_r+0x1e>
200262c0:	682b      	ldr	r3, [r5, #0]
200262c2:	b103      	cbz	r3, 200262c6 <_read_r+0x1e>
200262c4:	6023      	str	r3, [r4, #0]
200262c6:	bd38      	pop	{r3, r4, r5, pc}
200262c8:	2004d210 	.word	0x2004d210

200262cc <_sbrk_r>:
200262cc:	b538      	push	{r3, r4, r5, lr}
200262ce:	2300      	movs	r3, #0
200262d0:	4d05      	ldr	r5, [pc, #20]	@ (200262e8 <_sbrk_r+0x1c>)
200262d2:	4604      	mov	r4, r0
200262d4:	4608      	mov	r0, r1
200262d6:	602b      	str	r3, [r5, #0]
200262d8:	f000 fbd6 	bl	20026a88 <_sbrk>
200262dc:	1c43      	adds	r3, r0, #1
200262de:	d102      	bne.n	200262e6 <_sbrk_r+0x1a>
200262e0:	682b      	ldr	r3, [r5, #0]
200262e2:	b103      	cbz	r3, 200262e6 <_sbrk_r+0x1a>
200262e4:	6023      	str	r3, [r4, #0]
200262e6:	bd38      	pop	{r3, r4, r5, pc}
200262e8:	2004d210 	.word	0x2004d210

200262ec <_write_r>:
200262ec:	b538      	push	{r3, r4, r5, lr}
200262ee:	4604      	mov	r4, r0
200262f0:	4d06      	ldr	r5, [pc, #24]	@ (2002630c <_write_r+0x20>)
200262f2:	4608      	mov	r0, r1
200262f4:	4611      	mov	r1, r2
200262f6:	2200      	movs	r2, #0
200262f8:	602a      	str	r2, [r5, #0]
200262fa:	461a      	mov	r2, r3
200262fc:	f7fa fdb0 	bl	20020e60 <_write>
20026300:	1c43      	adds	r3, r0, #1
20026302:	d102      	bne.n	2002630a <_write_r+0x1e>
20026304:	682b      	ldr	r3, [r5, #0]
20026306:	b103      	cbz	r3, 2002630a <_write_r+0x1e>
20026308:	6023      	str	r3, [r4, #0]
2002630a:	bd38      	pop	{r3, r4, r5, pc}
2002630c:	2004d210 	.word	0x2004d210

20026310 <__retarget_lock_init_recursive>:
20026310:	4770      	bx	lr

20026312 <__retarget_lock_acquire_recursive>:
20026312:	4770      	bx	lr

20026314 <__retarget_lock_release_recursive>:
20026314:	4770      	bx	lr

20026316 <memchr>:
20026316:	b2c9      	uxtb	r1, r1
20026318:	4603      	mov	r3, r0
2002631a:	4402      	add	r2, r0
2002631c:	b510      	push	{r4, lr}
2002631e:	4293      	cmp	r3, r2
20026320:	4618      	mov	r0, r3
20026322:	d101      	bne.n	20026328 <memchr+0x12>
20026324:	2000      	movs	r0, #0
20026326:	e003      	b.n	20026330 <memchr+0x1a>
20026328:	7804      	ldrb	r4, [r0, #0]
2002632a:	3301      	adds	r3, #1
2002632c:	428c      	cmp	r4, r1
2002632e:	d1f6      	bne.n	2002631e <memchr+0x8>
20026330:	bd10      	pop	{r4, pc}

20026332 <memcpy>:
20026332:	440a      	add	r2, r1
20026334:	1e43      	subs	r3, r0, #1
20026336:	4291      	cmp	r1, r2
20026338:	d100      	bne.n	2002633c <memcpy+0xa>
2002633a:	4770      	bx	lr
2002633c:	b510      	push	{r4, lr}
2002633e:	f811 4b01 	ldrb.w	r4, [r1], #1
20026342:	4291      	cmp	r1, r2
20026344:	f803 4f01 	strb.w	r4, [r3, #1]!
20026348:	d1f9      	bne.n	2002633e <memcpy+0xc>
2002634a:	bd10      	pop	{r4, pc}

2002634c <_free_r>:
2002634c:	b538      	push	{r3, r4, r5, lr}
2002634e:	4605      	mov	r5, r0
20026350:	2900      	cmp	r1, #0
20026352:	d041      	beq.n	200263d8 <_free_r+0x8c>
20026354:	f851 3c04 	ldr.w	r3, [r1, #-4]
20026358:	1f0c      	subs	r4, r1, #4
2002635a:	2b00      	cmp	r3, #0
2002635c:	bfb8      	it	lt
2002635e:	18e4      	addlt	r4, r4, r3
20026360:	f7ff fcaa 	bl	20025cb8 <__malloc_lock>
20026364:	4a1d      	ldr	r2, [pc, #116]	@ (200263dc <_free_r+0x90>)
20026366:	6813      	ldr	r3, [r2, #0]
20026368:	b933      	cbnz	r3, 20026378 <_free_r+0x2c>
2002636a:	6063      	str	r3, [r4, #4]
2002636c:	6014      	str	r4, [r2, #0]
2002636e:	4628      	mov	r0, r5
20026370:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
20026374:	f7ff bca6 	b.w	20025cc4 <__malloc_unlock>
20026378:	42a3      	cmp	r3, r4
2002637a:	d908      	bls.n	2002638e <_free_r+0x42>
2002637c:	6820      	ldr	r0, [r4, #0]
2002637e:	1821      	adds	r1, r4, r0
20026380:	428b      	cmp	r3, r1
20026382:	bf01      	itttt	eq
20026384:	6819      	ldreq	r1, [r3, #0]
20026386:	685b      	ldreq	r3, [r3, #4]
20026388:	1809      	addeq	r1, r1, r0
2002638a:	6021      	streq	r1, [r4, #0]
2002638c:	e7ed      	b.n	2002636a <_free_r+0x1e>
2002638e:	461a      	mov	r2, r3
20026390:	685b      	ldr	r3, [r3, #4]
20026392:	b10b      	cbz	r3, 20026398 <_free_r+0x4c>
20026394:	42a3      	cmp	r3, r4
20026396:	d9fa      	bls.n	2002638e <_free_r+0x42>
20026398:	6811      	ldr	r1, [r2, #0]
2002639a:	1850      	adds	r0, r2, r1
2002639c:	42a0      	cmp	r0, r4
2002639e:	d10b      	bne.n	200263b8 <_free_r+0x6c>
200263a0:	6820      	ldr	r0, [r4, #0]
200263a2:	4401      	add	r1, r0
200263a4:	1850      	adds	r0, r2, r1
200263a6:	6011      	str	r1, [r2, #0]
200263a8:	4283      	cmp	r3, r0
200263aa:	d1e0      	bne.n	2002636e <_free_r+0x22>
200263ac:	6818      	ldr	r0, [r3, #0]
200263ae:	685b      	ldr	r3, [r3, #4]
200263b0:	4408      	add	r0, r1
200263b2:	6053      	str	r3, [r2, #4]
200263b4:	6010      	str	r0, [r2, #0]
200263b6:	e7da      	b.n	2002636e <_free_r+0x22>
200263b8:	d902      	bls.n	200263c0 <_free_r+0x74>
200263ba:	230c      	movs	r3, #12
200263bc:	602b      	str	r3, [r5, #0]
200263be:	e7d6      	b.n	2002636e <_free_r+0x22>
200263c0:	6820      	ldr	r0, [r4, #0]
200263c2:	1821      	adds	r1, r4, r0
200263c4:	428b      	cmp	r3, r1
200263c6:	bf02      	ittt	eq
200263c8:	6819      	ldreq	r1, [r3, #0]
200263ca:	685b      	ldreq	r3, [r3, #4]
200263cc:	1809      	addeq	r1, r1, r0
200263ce:	6063      	str	r3, [r4, #4]
200263d0:	bf08      	it	eq
200263d2:	6021      	streq	r1, [r4, #0]
200263d4:	6054      	str	r4, [r2, #4]
200263d6:	e7ca      	b.n	2002636e <_free_r+0x22>
200263d8:	bd38      	pop	{r3, r4, r5, pc}
200263da:	bf00      	nop
200263dc:	2004d0d0 	.word	0x2004d0d0

200263e0 <__sfputc_r>:
200263e0:	6893      	ldr	r3, [r2, #8]
200263e2:	3b01      	subs	r3, #1
200263e4:	2b00      	cmp	r3, #0
200263e6:	b410      	push	{r4}
200263e8:	6093      	str	r3, [r2, #8]
200263ea:	da08      	bge.n	200263fe <__sfputc_r+0x1e>
200263ec:	6994      	ldr	r4, [r2, #24]
200263ee:	42a3      	cmp	r3, r4
200263f0:	db01      	blt.n	200263f6 <__sfputc_r+0x16>
200263f2:	290a      	cmp	r1, #10
200263f4:	d103      	bne.n	200263fe <__sfputc_r+0x1e>
200263f6:	f85d 4b04 	ldr.w	r4, [sp], #4
200263fa:	f7ff be89 	b.w	20026110 <__swbuf_r>
200263fe:	6813      	ldr	r3, [r2, #0]
20026400:	1c58      	adds	r0, r3, #1
20026402:	6010      	str	r0, [r2, #0]
20026404:	4608      	mov	r0, r1
20026406:	7019      	strb	r1, [r3, #0]
20026408:	f85d 4b04 	ldr.w	r4, [sp], #4
2002640c:	4770      	bx	lr

2002640e <__sfputs_r>:
2002640e:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20026410:	4606      	mov	r6, r0
20026412:	460f      	mov	r7, r1
20026414:	4614      	mov	r4, r2
20026416:	18d5      	adds	r5, r2, r3
20026418:	42ac      	cmp	r4, r5
2002641a:	d101      	bne.n	20026420 <__sfputs_r+0x12>
2002641c:	2000      	movs	r0, #0
2002641e:	e007      	b.n	20026430 <__sfputs_r+0x22>
20026420:	463a      	mov	r2, r7
20026422:	f814 1b01 	ldrb.w	r1, [r4], #1
20026426:	4630      	mov	r0, r6
20026428:	f7ff ffda 	bl	200263e0 <__sfputc_r>
2002642c:	1c43      	adds	r3, r0, #1
2002642e:	d1f3      	bne.n	20026418 <__sfputs_r+0xa>
20026430:	bdf8      	pop	{r3, r4, r5, r6, r7, pc}
	...

20026434 <_vfiprintf_r>:
20026434:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
20026438:	460d      	mov	r5, r1
2002643a:	b09d      	sub	sp, #116	@ 0x74
2002643c:	4614      	mov	r4, r2
2002643e:	4698      	mov	r8, r3
20026440:	4606      	mov	r6, r0
20026442:	b118      	cbz	r0, 2002644c <_vfiprintf_r+0x18>
20026444:	6a03      	ldr	r3, [r0, #32]
20026446:	b90b      	cbnz	r3, 2002644c <_vfiprintf_r+0x18>
20026448:	f7ff fd78 	bl	20025f3c <__sinit>
2002644c:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
2002644e:	07d9      	lsls	r1, r3, #31
20026450:	d405      	bmi.n	2002645e <_vfiprintf_r+0x2a>
20026452:	89ab      	ldrh	r3, [r5, #12]
20026454:	059a      	lsls	r2, r3, #22
20026456:	d402      	bmi.n	2002645e <_vfiprintf_r+0x2a>
20026458:	6da8      	ldr	r0, [r5, #88]	@ 0x58
2002645a:	f7ff ff5a 	bl	20026312 <__retarget_lock_acquire_recursive>
2002645e:	89ab      	ldrh	r3, [r5, #12]
20026460:	071b      	lsls	r3, r3, #28
20026462:	d501      	bpl.n	20026468 <_vfiprintf_r+0x34>
20026464:	692b      	ldr	r3, [r5, #16]
20026466:	b99b      	cbnz	r3, 20026490 <_vfiprintf_r+0x5c>
20026468:	4629      	mov	r1, r5
2002646a:	4630      	mov	r0, r6
2002646c:	f7ff fe8e 	bl	2002618c <__swsetup_r>
20026470:	b170      	cbz	r0, 20026490 <_vfiprintf_r+0x5c>
20026472:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20026474:	07dc      	lsls	r4, r3, #31
20026476:	d504      	bpl.n	20026482 <_vfiprintf_r+0x4e>
20026478:	f04f 30ff 	mov.w	r0, #4294967295
2002647c:	b01d      	add	sp, #116	@ 0x74
2002647e:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
20026482:	89ab      	ldrh	r3, [r5, #12]
20026484:	0598      	lsls	r0, r3, #22
20026486:	d4f7      	bmi.n	20026478 <_vfiprintf_r+0x44>
20026488:	6da8      	ldr	r0, [r5, #88]	@ 0x58
2002648a:	f7ff ff43 	bl	20026314 <__retarget_lock_release_recursive>
2002648e:	e7f3      	b.n	20026478 <_vfiprintf_r+0x44>
20026490:	2300      	movs	r3, #0
20026492:	f8cd 800c 	str.w	r8, [sp, #12]
20026496:	f04f 0901 	mov.w	r9, #1
2002649a:	f8df 81b4 	ldr.w	r8, [pc, #436]	@ 20026650 <_vfiprintf_r+0x21c>
2002649e:	9309      	str	r3, [sp, #36]	@ 0x24
200264a0:	2320      	movs	r3, #32
200264a2:	f88d 3029 	strb.w	r3, [sp, #41]	@ 0x29
200264a6:	2330      	movs	r3, #48	@ 0x30
200264a8:	f88d 302a 	strb.w	r3, [sp, #42]	@ 0x2a
200264ac:	4623      	mov	r3, r4
200264ae:	469a      	mov	sl, r3
200264b0:	f813 2b01 	ldrb.w	r2, [r3], #1
200264b4:	b10a      	cbz	r2, 200264ba <_vfiprintf_r+0x86>
200264b6:	2a25      	cmp	r2, #37	@ 0x25
200264b8:	d1f9      	bne.n	200264ae <_vfiprintf_r+0x7a>
200264ba:	ebba 0b04 	subs.w	fp, sl, r4
200264be:	d00b      	beq.n	200264d8 <_vfiprintf_r+0xa4>
200264c0:	465b      	mov	r3, fp
200264c2:	4622      	mov	r2, r4
200264c4:	4629      	mov	r1, r5
200264c6:	4630      	mov	r0, r6
200264c8:	f7ff ffa1 	bl	2002640e <__sfputs_r>
200264cc:	3001      	adds	r0, #1
200264ce:	f000 80a7 	beq.w	20026620 <_vfiprintf_r+0x1ec>
200264d2:	9a09      	ldr	r2, [sp, #36]	@ 0x24
200264d4:	445a      	add	r2, fp
200264d6:	9209      	str	r2, [sp, #36]	@ 0x24
200264d8:	f89a 3000 	ldrb.w	r3, [sl]
200264dc:	2b00      	cmp	r3, #0
200264de:	f000 809f 	beq.w	20026620 <_vfiprintf_r+0x1ec>
200264e2:	2300      	movs	r3, #0
200264e4:	f04f 32ff 	mov.w	r2, #4294967295
200264e8:	f10a 0a01 	add.w	sl, sl, #1
200264ec:	9304      	str	r3, [sp, #16]
200264ee:	9307      	str	r3, [sp, #28]
200264f0:	f88d 3053 	strb.w	r3, [sp, #83]	@ 0x53
200264f4:	931a      	str	r3, [sp, #104]	@ 0x68
200264f6:	e9cd 2305 	strd	r2, r3, [sp, #20]
200264fa:	4654      	mov	r4, sl
200264fc:	2205      	movs	r2, #5
200264fe:	4854      	ldr	r0, [pc, #336]	@ (20026650 <_vfiprintf_r+0x21c>)
20026500:	f814 1b01 	ldrb.w	r1, [r4], #1
20026504:	f7ff ff07 	bl	20026316 <memchr>
20026508:	9a04      	ldr	r2, [sp, #16]
2002650a:	b9d8      	cbnz	r0, 20026544 <_vfiprintf_r+0x110>
2002650c:	06d1      	lsls	r1, r2, #27
2002650e:	bf44      	itt	mi
20026510:	2320      	movmi	r3, #32
20026512:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20026516:	0713      	lsls	r3, r2, #28
20026518:	bf44      	itt	mi
2002651a:	232b      	movmi	r3, #43	@ 0x2b
2002651c:	f88d 3053 	strbmi.w	r3, [sp, #83]	@ 0x53
20026520:	f89a 3000 	ldrb.w	r3, [sl]
20026524:	2b2a      	cmp	r3, #42	@ 0x2a
20026526:	d015      	beq.n	20026554 <_vfiprintf_r+0x120>
20026528:	9a07      	ldr	r2, [sp, #28]
2002652a:	4654      	mov	r4, sl
2002652c:	2000      	movs	r0, #0
2002652e:	f04f 0c0a 	mov.w	ip, #10
20026532:	4621      	mov	r1, r4
20026534:	f811 3b01 	ldrb.w	r3, [r1], #1
20026538:	3b30      	subs	r3, #48	@ 0x30
2002653a:	2b09      	cmp	r3, #9
2002653c:	d94b      	bls.n	200265d6 <_vfiprintf_r+0x1a2>
2002653e:	b1b0      	cbz	r0, 2002656e <_vfiprintf_r+0x13a>
20026540:	9207      	str	r2, [sp, #28]
20026542:	e014      	b.n	2002656e <_vfiprintf_r+0x13a>
20026544:	eba0 0308 	sub.w	r3, r0, r8
20026548:	46a2      	mov	sl, r4
2002654a:	fa09 f303 	lsl.w	r3, r9, r3
2002654e:	4313      	orrs	r3, r2
20026550:	9304      	str	r3, [sp, #16]
20026552:	e7d2      	b.n	200264fa <_vfiprintf_r+0xc6>
20026554:	9b03      	ldr	r3, [sp, #12]
20026556:	1d19      	adds	r1, r3, #4
20026558:	681b      	ldr	r3, [r3, #0]
2002655a:	2b00      	cmp	r3, #0
2002655c:	9103      	str	r1, [sp, #12]
2002655e:	bfbb      	ittet	lt
20026560:	425b      	neglt	r3, r3
20026562:	f042 0202 	orrlt.w	r2, r2, #2
20026566:	9307      	strge	r3, [sp, #28]
20026568:	9307      	strlt	r3, [sp, #28]
2002656a:	bfb8      	it	lt
2002656c:	9204      	strlt	r2, [sp, #16]
2002656e:	7823      	ldrb	r3, [r4, #0]
20026570:	2b2e      	cmp	r3, #46	@ 0x2e
20026572:	d10a      	bne.n	2002658a <_vfiprintf_r+0x156>
20026574:	7863      	ldrb	r3, [r4, #1]
20026576:	2b2a      	cmp	r3, #42	@ 0x2a
20026578:	d132      	bne.n	200265e0 <_vfiprintf_r+0x1ac>
2002657a:	9b03      	ldr	r3, [sp, #12]
2002657c:	3402      	adds	r4, #2
2002657e:	1d1a      	adds	r2, r3, #4
20026580:	681b      	ldr	r3, [r3, #0]
20026582:	ea43 73e3 	orr.w	r3, r3, r3, asr #31
20026586:	9203      	str	r2, [sp, #12]
20026588:	9305      	str	r3, [sp, #20]
2002658a:	f8df a0d4 	ldr.w	sl, [pc, #212]	@ 20026660 <_vfiprintf_r+0x22c>
2002658e:	2203      	movs	r2, #3
20026590:	7821      	ldrb	r1, [r4, #0]
20026592:	4650      	mov	r0, sl
20026594:	f7ff febf 	bl	20026316 <memchr>
20026598:	b138      	cbz	r0, 200265aa <_vfiprintf_r+0x176>
2002659a:	eba0 000a 	sub.w	r0, r0, sl
2002659e:	2240      	movs	r2, #64	@ 0x40
200265a0:	9b04      	ldr	r3, [sp, #16]
200265a2:	3401      	adds	r4, #1
200265a4:	4082      	lsls	r2, r0
200265a6:	4313      	orrs	r3, r2
200265a8:	9304      	str	r3, [sp, #16]
200265aa:	f814 1b01 	ldrb.w	r1, [r4], #1
200265ae:	2206      	movs	r2, #6
200265b0:	4828      	ldr	r0, [pc, #160]	@ (20026654 <_vfiprintf_r+0x220>)
200265b2:	f88d 1028 	strb.w	r1, [sp, #40]	@ 0x28
200265b6:	f7ff feae 	bl	20026316 <memchr>
200265ba:	2800      	cmp	r0, #0
200265bc:	d03f      	beq.n	2002663e <_vfiprintf_r+0x20a>
200265be:	4b26      	ldr	r3, [pc, #152]	@ (20026658 <_vfiprintf_r+0x224>)
200265c0:	bb1b      	cbnz	r3, 2002660a <_vfiprintf_r+0x1d6>
200265c2:	9b03      	ldr	r3, [sp, #12]
200265c4:	3307      	adds	r3, #7
200265c6:	f023 0307 	bic.w	r3, r3, #7
200265ca:	3308      	adds	r3, #8
200265cc:	9303      	str	r3, [sp, #12]
200265ce:	9b09      	ldr	r3, [sp, #36]	@ 0x24
200265d0:	443b      	add	r3, r7
200265d2:	9309      	str	r3, [sp, #36]	@ 0x24
200265d4:	e76a      	b.n	200264ac <_vfiprintf_r+0x78>
200265d6:	fb0c 3202 	mla	r2, ip, r2, r3
200265da:	460c      	mov	r4, r1
200265dc:	2001      	movs	r0, #1
200265de:	e7a8      	b.n	20026532 <_vfiprintf_r+0xfe>
200265e0:	2300      	movs	r3, #0
200265e2:	3401      	adds	r4, #1
200265e4:	f04f 0c0a 	mov.w	ip, #10
200265e8:	4619      	mov	r1, r3
200265ea:	9305      	str	r3, [sp, #20]
200265ec:	4620      	mov	r0, r4
200265ee:	f810 2b01 	ldrb.w	r2, [r0], #1
200265f2:	3a30      	subs	r2, #48	@ 0x30
200265f4:	2a09      	cmp	r2, #9
200265f6:	d903      	bls.n	20026600 <_vfiprintf_r+0x1cc>
200265f8:	2b00      	cmp	r3, #0
200265fa:	d0c6      	beq.n	2002658a <_vfiprintf_r+0x156>
200265fc:	9105      	str	r1, [sp, #20]
200265fe:	e7c4      	b.n	2002658a <_vfiprintf_r+0x156>
20026600:	fb0c 2101 	mla	r1, ip, r1, r2
20026604:	4604      	mov	r4, r0
20026606:	2301      	movs	r3, #1
20026608:	e7f0      	b.n	200265ec <_vfiprintf_r+0x1b8>
2002660a:	ab03      	add	r3, sp, #12
2002660c:	462a      	mov	r2, r5
2002660e:	a904      	add	r1, sp, #16
20026610:	4630      	mov	r0, r6
20026612:	9300      	str	r3, [sp, #0]
20026614:	4b11      	ldr	r3, [pc, #68]	@ (2002665c <_vfiprintf_r+0x228>)
20026616:	f3af 8000 	nop.w
2002661a:	4607      	mov	r7, r0
2002661c:	1c78      	adds	r0, r7, #1
2002661e:	d1d6      	bne.n	200265ce <_vfiprintf_r+0x19a>
20026620:	6e6b      	ldr	r3, [r5, #100]	@ 0x64
20026622:	07d9      	lsls	r1, r3, #31
20026624:	d405      	bmi.n	20026632 <_vfiprintf_r+0x1fe>
20026626:	89ab      	ldrh	r3, [r5, #12]
20026628:	059a      	lsls	r2, r3, #22
2002662a:	d402      	bmi.n	20026632 <_vfiprintf_r+0x1fe>
2002662c:	6da8      	ldr	r0, [r5, #88]	@ 0x58
2002662e:	f7ff fe71 	bl	20026314 <__retarget_lock_release_recursive>
20026632:	89ab      	ldrh	r3, [r5, #12]
20026634:	065b      	lsls	r3, r3, #25
20026636:	f53f af1f 	bmi.w	20026478 <_vfiprintf_r+0x44>
2002663a:	9809      	ldr	r0, [sp, #36]	@ 0x24
2002663c:	e71e      	b.n	2002647c <_vfiprintf_r+0x48>
2002663e:	ab03      	add	r3, sp, #12
20026640:	462a      	mov	r2, r5
20026642:	a904      	add	r1, sp, #16
20026644:	4630      	mov	r0, r6
20026646:	9300      	str	r3, [sp, #0]
20026648:	4b04      	ldr	r3, [pc, #16]	@ (2002665c <_vfiprintf_r+0x228>)
2002664a:	f000 f87d 	bl	20026748 <_printf_i>
2002664e:	e7e4      	b.n	2002661a <_vfiprintf_r+0x1e6>
20026650:	20026f87 	.word	0x20026f87
20026654:	20026f91 	.word	0x20026f91
20026658:	00000000 	.word	0x00000000
2002665c:	2002640f 	.word	0x2002640f
20026660:	20026f8d 	.word	0x20026f8d

20026664 <_printf_common>:
20026664:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
20026668:	4616      	mov	r6, r2
2002666a:	4698      	mov	r8, r3
2002666c:	688a      	ldr	r2, [r1, #8]
2002666e:	4607      	mov	r7, r0
20026670:	690b      	ldr	r3, [r1, #16]
20026672:	460c      	mov	r4, r1
20026674:	f8dd 9020 	ldr.w	r9, [sp, #32]
20026678:	4293      	cmp	r3, r2
2002667a:	bfb8      	it	lt
2002667c:	4613      	movlt	r3, r2
2002667e:	6033      	str	r3, [r6, #0]
20026680:	f891 2043 	ldrb.w	r2, [r1, #67]	@ 0x43
20026684:	b10a      	cbz	r2, 2002668a <_printf_common+0x26>
20026686:	3301      	adds	r3, #1
20026688:	6033      	str	r3, [r6, #0]
2002668a:	6823      	ldr	r3, [r4, #0]
2002668c:	0699      	lsls	r1, r3, #26
2002668e:	bf42      	ittt	mi
20026690:	6833      	ldrmi	r3, [r6, #0]
20026692:	3302      	addmi	r3, #2
20026694:	6033      	strmi	r3, [r6, #0]
20026696:	6825      	ldr	r5, [r4, #0]
20026698:	f015 0506 	ands.w	r5, r5, #6
2002669c:	d106      	bne.n	200266ac <_printf_common+0x48>
2002669e:	f104 0a19 	add.w	sl, r4, #25
200266a2:	68e3      	ldr	r3, [r4, #12]
200266a4:	6832      	ldr	r2, [r6, #0]
200266a6:	1a9b      	subs	r3, r3, r2
200266a8:	42ab      	cmp	r3, r5
200266aa:	dc2b      	bgt.n	20026704 <_printf_common+0xa0>
200266ac:	f894 3043 	ldrb.w	r3, [r4, #67]	@ 0x43
200266b0:	6822      	ldr	r2, [r4, #0]
200266b2:	3b00      	subs	r3, #0
200266b4:	bf18      	it	ne
200266b6:	2301      	movne	r3, #1
200266b8:	0692      	lsls	r2, r2, #26
200266ba:	d430      	bmi.n	2002671e <_printf_common+0xba>
200266bc:	f104 0243 	add.w	r2, r4, #67	@ 0x43
200266c0:	4641      	mov	r1, r8
200266c2:	4638      	mov	r0, r7
200266c4:	47c8      	blx	r9
200266c6:	3001      	adds	r0, #1
200266c8:	d023      	beq.n	20026712 <_printf_common+0xae>
200266ca:	6823      	ldr	r3, [r4, #0]
200266cc:	341a      	adds	r4, #26
200266ce:	f854 2c0a 	ldr.w	r2, [r4, #-10]
200266d2:	f003 0306 	and.w	r3, r3, #6
200266d6:	2b04      	cmp	r3, #4
200266d8:	bf0a      	itet	eq
200266da:	f854 5c0e 	ldreq.w	r5, [r4, #-14]
200266de:	2500      	movne	r5, #0
200266e0:	6833      	ldreq	r3, [r6, #0]
200266e2:	f04f 0600 	mov.w	r6, #0
200266e6:	bf08      	it	eq
200266e8:	1aed      	subeq	r5, r5, r3
200266ea:	f854 3c12 	ldr.w	r3, [r4, #-18]
200266ee:	bf08      	it	eq
200266f0:	ea25 75e5 	biceq.w	r5, r5, r5, asr #31
200266f4:	4293      	cmp	r3, r2
200266f6:	bfc4      	itt	gt
200266f8:	1a9b      	subgt	r3, r3, r2
200266fa:	18ed      	addgt	r5, r5, r3
200266fc:	42b5      	cmp	r5, r6
200266fe:	d11a      	bne.n	20026736 <_printf_common+0xd2>
20026700:	2000      	movs	r0, #0
20026702:	e008      	b.n	20026716 <_printf_common+0xb2>
20026704:	2301      	movs	r3, #1
20026706:	4652      	mov	r2, sl
20026708:	4641      	mov	r1, r8
2002670a:	4638      	mov	r0, r7
2002670c:	47c8      	blx	r9
2002670e:	3001      	adds	r0, #1
20026710:	d103      	bne.n	2002671a <_printf_common+0xb6>
20026712:	f04f 30ff 	mov.w	r0, #4294967295
20026716:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
2002671a:	3501      	adds	r5, #1
2002671c:	e7c1      	b.n	200266a2 <_printf_common+0x3e>
2002671e:	18e1      	adds	r1, r4, r3
20026720:	1c5a      	adds	r2, r3, #1
20026722:	2030      	movs	r0, #48	@ 0x30
20026724:	3302      	adds	r3, #2
20026726:	4422      	add	r2, r4
20026728:	f881 0043 	strb.w	r0, [r1, #67]	@ 0x43
2002672c:	f894 1045 	ldrb.w	r1, [r4, #69]	@ 0x45
20026730:	f882 1043 	strb.w	r1, [r2, #67]	@ 0x43
20026734:	e7c2      	b.n	200266bc <_printf_common+0x58>
20026736:	2301      	movs	r3, #1
20026738:	4622      	mov	r2, r4
2002673a:	4641      	mov	r1, r8
2002673c:	4638      	mov	r0, r7
2002673e:	47c8      	blx	r9
20026740:	3001      	adds	r0, #1
20026742:	d0e6      	beq.n	20026712 <_printf_common+0xae>
20026744:	3601      	adds	r6, #1
20026746:	e7d9      	b.n	200266fc <_printf_common+0x98>

20026748 <_printf_i>:
20026748:	e92d 47ff 	stmdb	sp!, {r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, sl, lr}
2002674c:	7e0f      	ldrb	r7, [r1, #24]
2002674e:	4691      	mov	r9, r2
20026750:	4680      	mov	r8, r0
20026752:	460c      	mov	r4, r1
20026754:	2f78      	cmp	r7, #120	@ 0x78
20026756:	469a      	mov	sl, r3
20026758:	9e0c      	ldr	r6, [sp, #48]	@ 0x30
2002675a:	f101 0243 	add.w	r2, r1, #67	@ 0x43
2002675e:	d807      	bhi.n	20026770 <_printf_i+0x28>
20026760:	2f62      	cmp	r7, #98	@ 0x62
20026762:	d80a      	bhi.n	2002677a <_printf_i+0x32>
20026764:	2f00      	cmp	r7, #0
20026766:	f000 80d2 	beq.w	2002690e <_printf_i+0x1c6>
2002676a:	2f58      	cmp	r7, #88	@ 0x58
2002676c:	f000 80b7 	beq.w	200268de <_printf_i+0x196>
20026770:	f104 0642 	add.w	r6, r4, #66	@ 0x42
20026774:	f884 7042 	strb.w	r7, [r4, #66]	@ 0x42
20026778:	e03a      	b.n	200267f0 <_printf_i+0xa8>
2002677a:	f1a7 0363 	sub.w	r3, r7, #99	@ 0x63
2002677e:	2b15      	cmp	r3, #21
20026780:	d8f6      	bhi.n	20026770 <_printf_i+0x28>
20026782:	a101      	add	r1, pc, #4	@ (adr r1, 20026788 <_printf_i+0x40>)
20026784:	f851 f023 	ldr.w	pc, [r1, r3, lsl #2]
20026788:	200267e1 	.word	0x200267e1
2002678c:	200267f5 	.word	0x200267f5
20026790:	20026771 	.word	0x20026771
20026794:	20026771 	.word	0x20026771
20026798:	20026771 	.word	0x20026771
2002679c:	20026771 	.word	0x20026771
200267a0:	200267f5 	.word	0x200267f5
200267a4:	20026771 	.word	0x20026771
200267a8:	20026771 	.word	0x20026771
200267ac:	20026771 	.word	0x20026771
200267b0:	20026771 	.word	0x20026771
200267b4:	200268f5 	.word	0x200268f5
200267b8:	2002681f 	.word	0x2002681f
200267bc:	200268ab 	.word	0x200268ab
200267c0:	20026771 	.word	0x20026771
200267c4:	20026771 	.word	0x20026771
200267c8:	20026917 	.word	0x20026917
200267cc:	20026771 	.word	0x20026771
200267d0:	2002681f 	.word	0x2002681f
200267d4:	20026771 	.word	0x20026771
200267d8:	20026771 	.word	0x20026771
200267dc:	200268b3 	.word	0x200268b3
200267e0:	6833      	ldr	r3, [r6, #0]
200267e2:	1d1a      	adds	r2, r3, #4
200267e4:	681b      	ldr	r3, [r3, #0]
200267e6:	6032      	str	r2, [r6, #0]
200267e8:	f104 0642 	add.w	r6, r4, #66	@ 0x42
200267ec:	f884 3042 	strb.w	r3, [r4, #66]	@ 0x42
200267f0:	2301      	movs	r3, #1
200267f2:	e09d      	b.n	20026930 <_printf_i+0x1e8>
200267f4:	6833      	ldr	r3, [r6, #0]
200267f6:	6820      	ldr	r0, [r4, #0]
200267f8:	1d19      	adds	r1, r3, #4
200267fa:	6031      	str	r1, [r6, #0]
200267fc:	0606      	lsls	r6, r0, #24
200267fe:	d501      	bpl.n	20026804 <_printf_i+0xbc>
20026800:	681d      	ldr	r5, [r3, #0]
20026802:	e003      	b.n	2002680c <_printf_i+0xc4>
20026804:	0645      	lsls	r5, r0, #25
20026806:	d5fb      	bpl.n	20026800 <_printf_i+0xb8>
20026808:	f9b3 5000 	ldrsh.w	r5, [r3]
2002680c:	2d00      	cmp	r5, #0
2002680e:	da03      	bge.n	20026818 <_printf_i+0xd0>
20026810:	232d      	movs	r3, #45	@ 0x2d
20026812:	426d      	negs	r5, r5
20026814:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026818:	4859      	ldr	r0, [pc, #356]	@ (20026980 <_printf_i+0x238>)
2002681a:	230a      	movs	r3, #10
2002681c:	e010      	b.n	20026840 <_printf_i+0xf8>
2002681e:	6821      	ldr	r1, [r4, #0]
20026820:	6833      	ldr	r3, [r6, #0]
20026822:	0608      	lsls	r0, r1, #24
20026824:	f853 5b04 	ldr.w	r5, [r3], #4
20026828:	d402      	bmi.n	20026830 <_printf_i+0xe8>
2002682a:	0649      	lsls	r1, r1, #25
2002682c:	bf48      	it	mi
2002682e:	b2ad      	uxthmi	r5, r5
20026830:	2f6f      	cmp	r7, #111	@ 0x6f
20026832:	4853      	ldr	r0, [pc, #332]	@ (20026980 <_printf_i+0x238>)
20026834:	6033      	str	r3, [r6, #0]
20026836:	d159      	bne.n	200268ec <_printf_i+0x1a4>
20026838:	2308      	movs	r3, #8
2002683a:	2100      	movs	r1, #0
2002683c:	f884 1043 	strb.w	r1, [r4, #67]	@ 0x43
20026840:	6866      	ldr	r6, [r4, #4]
20026842:	2e00      	cmp	r6, #0
20026844:	60a6      	str	r6, [r4, #8]
20026846:	db05      	blt.n	20026854 <_printf_i+0x10c>
20026848:	6821      	ldr	r1, [r4, #0]
2002684a:	432e      	orrs	r6, r5
2002684c:	f021 0104 	bic.w	r1, r1, #4
20026850:	6021      	str	r1, [r4, #0]
20026852:	d04d      	beq.n	200268f0 <_printf_i+0x1a8>
20026854:	4616      	mov	r6, r2
20026856:	fbb5 f1f3 	udiv	r1, r5, r3
2002685a:	fb03 5711 	mls	r7, r3, r1, r5
2002685e:	5dc7      	ldrb	r7, [r0, r7]
20026860:	f806 7d01 	strb.w	r7, [r6, #-1]!
20026864:	462f      	mov	r7, r5
20026866:	460d      	mov	r5, r1
20026868:	42bb      	cmp	r3, r7
2002686a:	d9f4      	bls.n	20026856 <_printf_i+0x10e>
2002686c:	2b08      	cmp	r3, #8
2002686e:	d10b      	bne.n	20026888 <_printf_i+0x140>
20026870:	6823      	ldr	r3, [r4, #0]
20026872:	07df      	lsls	r7, r3, #31
20026874:	d508      	bpl.n	20026888 <_printf_i+0x140>
20026876:	6923      	ldr	r3, [r4, #16]
20026878:	6861      	ldr	r1, [r4, #4]
2002687a:	4299      	cmp	r1, r3
2002687c:	bfde      	ittt	le
2002687e:	2330      	movle	r3, #48	@ 0x30
20026880:	f806 3c01 	strble.w	r3, [r6, #-1]
20026884:	f106 36ff 	addle.w	r6, r6, #4294967295
20026888:	1b92      	subs	r2, r2, r6
2002688a:	6122      	str	r2, [r4, #16]
2002688c:	464b      	mov	r3, r9
2002688e:	aa03      	add	r2, sp, #12
20026890:	4621      	mov	r1, r4
20026892:	4640      	mov	r0, r8
20026894:	f8cd a000 	str.w	sl, [sp]
20026898:	f7ff fee4 	bl	20026664 <_printf_common>
2002689c:	3001      	adds	r0, #1
2002689e:	d14c      	bne.n	2002693a <_printf_i+0x1f2>
200268a0:	f04f 30ff 	mov.w	r0, #4294967295
200268a4:	b004      	add	sp, #16
200268a6:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}
200268aa:	6823      	ldr	r3, [r4, #0]
200268ac:	f043 0320 	orr.w	r3, r3, #32
200268b0:	6023      	str	r3, [r4, #0]
200268b2:	2778      	movs	r7, #120	@ 0x78
200268b4:	4833      	ldr	r0, [pc, #204]	@ (20026984 <_printf_i+0x23c>)
200268b6:	6823      	ldr	r3, [r4, #0]
200268b8:	f884 7045 	strb.w	r7, [r4, #69]	@ 0x45
200268bc:	061f      	lsls	r7, r3, #24
200268be:	6831      	ldr	r1, [r6, #0]
200268c0:	f851 5b04 	ldr.w	r5, [r1], #4
200268c4:	d402      	bmi.n	200268cc <_printf_i+0x184>
200268c6:	065f      	lsls	r7, r3, #25
200268c8:	bf48      	it	mi
200268ca:	b2ad      	uxthmi	r5, r5
200268cc:	6031      	str	r1, [r6, #0]
200268ce:	07d9      	lsls	r1, r3, #31
200268d0:	bf44      	itt	mi
200268d2:	f043 0320 	orrmi.w	r3, r3, #32
200268d6:	6023      	strmi	r3, [r4, #0]
200268d8:	b11d      	cbz	r5, 200268e2 <_printf_i+0x19a>
200268da:	2310      	movs	r3, #16
200268dc:	e7ad      	b.n	2002683a <_printf_i+0xf2>
200268de:	4828      	ldr	r0, [pc, #160]	@ (20026980 <_printf_i+0x238>)
200268e0:	e7e9      	b.n	200268b6 <_printf_i+0x16e>
200268e2:	6823      	ldr	r3, [r4, #0]
200268e4:	f023 0320 	bic.w	r3, r3, #32
200268e8:	6023      	str	r3, [r4, #0]
200268ea:	e7f6      	b.n	200268da <_printf_i+0x192>
200268ec:	230a      	movs	r3, #10
200268ee:	e7a4      	b.n	2002683a <_printf_i+0xf2>
200268f0:	4616      	mov	r6, r2
200268f2:	e7bb      	b.n	2002686c <_printf_i+0x124>
200268f4:	6833      	ldr	r3, [r6, #0]
200268f6:	6825      	ldr	r5, [r4, #0]
200268f8:	1d18      	adds	r0, r3, #4
200268fa:	6961      	ldr	r1, [r4, #20]
200268fc:	6030      	str	r0, [r6, #0]
200268fe:	062e      	lsls	r6, r5, #24
20026900:	681b      	ldr	r3, [r3, #0]
20026902:	d501      	bpl.n	20026908 <_printf_i+0x1c0>
20026904:	6019      	str	r1, [r3, #0]
20026906:	e002      	b.n	2002690e <_printf_i+0x1c6>
20026908:	0668      	lsls	r0, r5, #25
2002690a:	d5fb      	bpl.n	20026904 <_printf_i+0x1bc>
2002690c:	8019      	strh	r1, [r3, #0]
2002690e:	2300      	movs	r3, #0
20026910:	4616      	mov	r6, r2
20026912:	6123      	str	r3, [r4, #16]
20026914:	e7ba      	b.n	2002688c <_printf_i+0x144>
20026916:	6833      	ldr	r3, [r6, #0]
20026918:	2100      	movs	r1, #0
2002691a:	1d1a      	adds	r2, r3, #4
2002691c:	6032      	str	r2, [r6, #0]
2002691e:	681e      	ldr	r6, [r3, #0]
20026920:	6862      	ldr	r2, [r4, #4]
20026922:	4630      	mov	r0, r6
20026924:	f7ff fcf7 	bl	20026316 <memchr>
20026928:	b108      	cbz	r0, 2002692e <_printf_i+0x1e6>
2002692a:	1b80      	subs	r0, r0, r6
2002692c:	6060      	str	r0, [r4, #4]
2002692e:	6863      	ldr	r3, [r4, #4]
20026930:	6123      	str	r3, [r4, #16]
20026932:	2300      	movs	r3, #0
20026934:	f884 3043 	strb.w	r3, [r4, #67]	@ 0x43
20026938:	e7a8      	b.n	2002688c <_printf_i+0x144>
2002693a:	6923      	ldr	r3, [r4, #16]
2002693c:	4632      	mov	r2, r6
2002693e:	4649      	mov	r1, r9
20026940:	4640      	mov	r0, r8
20026942:	47d0      	blx	sl
20026944:	3001      	adds	r0, #1
20026946:	d0ab      	beq.n	200268a0 <_printf_i+0x158>
20026948:	6823      	ldr	r3, [r4, #0]
2002694a:	079b      	lsls	r3, r3, #30
2002694c:	d413      	bmi.n	20026976 <_printf_i+0x22e>
2002694e:	68e0      	ldr	r0, [r4, #12]
20026950:	9b03      	ldr	r3, [sp, #12]
20026952:	4298      	cmp	r0, r3
20026954:	bfb8      	it	lt
20026956:	4618      	movlt	r0, r3
20026958:	e7a4      	b.n	200268a4 <_printf_i+0x15c>
2002695a:	2301      	movs	r3, #1
2002695c:	4632      	mov	r2, r6
2002695e:	4649      	mov	r1, r9
20026960:	4640      	mov	r0, r8
20026962:	47d0      	blx	sl
20026964:	3001      	adds	r0, #1
20026966:	d09b      	beq.n	200268a0 <_printf_i+0x158>
20026968:	3501      	adds	r5, #1
2002696a:	68e3      	ldr	r3, [r4, #12]
2002696c:	9903      	ldr	r1, [sp, #12]
2002696e:	1a5b      	subs	r3, r3, r1
20026970:	42ab      	cmp	r3, r5
20026972:	dcf2      	bgt.n	2002695a <_printf_i+0x212>
20026974:	e7eb      	b.n	2002694e <_printf_i+0x206>
20026976:	2500      	movs	r5, #0
20026978:	f104 0619 	add.w	r6, r4, #25
2002697c:	e7f5      	b.n	2002696a <_printf_i+0x222>
2002697e:	bf00      	nop
20026980:	20026f98 	.word	0x20026f98
20026984:	20026fa9 	.word	0x20026fa9

20026988 <__swhatbuf_r>:
20026988:	b570      	push	{r4, r5, r6, lr}
2002698a:	460c      	mov	r4, r1
2002698c:	f9b1 100e 	ldrsh.w	r1, [r1, #14]
20026990:	b096      	sub	sp, #88	@ 0x58
20026992:	4615      	mov	r5, r2
20026994:	2900      	cmp	r1, #0
20026996:	461e      	mov	r6, r3
20026998:	da0a      	bge.n	200269b0 <__swhatbuf_r+0x28>
2002699a:	89a1      	ldrh	r1, [r4, #12]
2002699c:	f011 0180 	ands.w	r1, r1, #128	@ 0x80
200269a0:	d113      	bne.n	200269ca <__swhatbuf_r+0x42>
200269a2:	f44f 6280 	mov.w	r2, #1024	@ 0x400
200269a6:	2000      	movs	r0, #0
200269a8:	6031      	str	r1, [r6, #0]
200269aa:	602a      	str	r2, [r5, #0]
200269ac:	b016      	add	sp, #88	@ 0x58
200269ae:	bd70      	pop	{r4, r5, r6, pc}
200269b0:	466a      	mov	r2, sp
200269b2:	f000 f847 	bl	20026a44 <_fstat_r>
200269b6:	2800      	cmp	r0, #0
200269b8:	dbef      	blt.n	2002699a <__swhatbuf_r+0x12>
200269ba:	9901      	ldr	r1, [sp, #4]
200269bc:	f401 4170 	and.w	r1, r1, #61440	@ 0xf000
200269c0:	f5a1 5300 	sub.w	r3, r1, #8192	@ 0x2000
200269c4:	4259      	negs	r1, r3
200269c6:	4159      	adcs	r1, r3
200269c8:	e7eb      	b.n	200269a2 <__swhatbuf_r+0x1a>
200269ca:	2100      	movs	r1, #0
200269cc:	2240      	movs	r2, #64	@ 0x40
200269ce:	e7ea      	b.n	200269a6 <__swhatbuf_r+0x1e>

200269d0 <__smakebuf_r>:
200269d0:	898b      	ldrh	r3, [r1, #12]
200269d2:	b573      	push	{r0, r1, r4, r5, r6, lr}
200269d4:	079e      	lsls	r6, r3, #30
200269d6:	4605      	mov	r5, r0
200269d8:	460c      	mov	r4, r1
200269da:	d507      	bpl.n	200269ec <__smakebuf_r+0x1c>
200269dc:	f104 0347 	add.w	r3, r4, #71	@ 0x47
200269e0:	6023      	str	r3, [r4, #0]
200269e2:	6123      	str	r3, [r4, #16]
200269e4:	2301      	movs	r3, #1
200269e6:	6163      	str	r3, [r4, #20]
200269e8:	b002      	add	sp, #8
200269ea:	bd70      	pop	{r4, r5, r6, pc}
200269ec:	ab01      	add	r3, sp, #4
200269ee:	466a      	mov	r2, sp
200269f0:	f7ff ffca 	bl	20026988 <__swhatbuf_r>
200269f4:	9e00      	ldr	r6, [sp, #0]
200269f6:	4628      	mov	r0, r5
200269f8:	4631      	mov	r1, r6
200269fa:	f7ff f8dd 	bl	20025bb8 <_malloc_r>
200269fe:	f9b4 300c 	ldrsh.w	r3, [r4, #12]
20026a02:	b938      	cbnz	r0, 20026a14 <__smakebuf_r+0x44>
20026a04:	059a      	lsls	r2, r3, #22
20026a06:	d4ef      	bmi.n	200269e8 <__smakebuf_r+0x18>
20026a08:	f023 0303 	bic.w	r3, r3, #3
20026a0c:	f043 0302 	orr.w	r3, r3, #2
20026a10:	81a3      	strh	r3, [r4, #12]
20026a12:	e7e3      	b.n	200269dc <__smakebuf_r+0xc>
20026a14:	f043 0380 	orr.w	r3, r3, #128	@ 0x80
20026a18:	6020      	str	r0, [r4, #0]
20026a1a:	81a3      	strh	r3, [r4, #12]
20026a1c:	9b01      	ldr	r3, [sp, #4]
20026a1e:	e9c4 0604 	strd	r0, r6, [r4, #16]
20026a22:	2b00      	cmp	r3, #0
20026a24:	d0e0      	beq.n	200269e8 <__smakebuf_r+0x18>
20026a26:	f9b4 100e 	ldrsh.w	r1, [r4, #14]
20026a2a:	4628      	mov	r0, r5
20026a2c:	f000 f81c 	bl	20026a68 <_isatty_r>
20026a30:	2800      	cmp	r0, #0
20026a32:	d0d9      	beq.n	200269e8 <__smakebuf_r+0x18>
20026a34:	89a3      	ldrh	r3, [r4, #12]
20026a36:	f023 0303 	bic.w	r3, r3, #3
20026a3a:	f043 0301 	orr.w	r3, r3, #1
20026a3e:	81a3      	strh	r3, [r4, #12]
20026a40:	e7d2      	b.n	200269e8 <__smakebuf_r+0x18>
	...

20026a44 <_fstat_r>:
20026a44:	b538      	push	{r3, r4, r5, lr}
20026a46:	2300      	movs	r3, #0
20026a48:	4d06      	ldr	r5, [pc, #24]	@ (20026a64 <_fstat_r+0x20>)
20026a4a:	4604      	mov	r4, r0
20026a4c:	4608      	mov	r0, r1
20026a4e:	4611      	mov	r1, r2
20026a50:	602b      	str	r3, [r5, #0]
20026a52:	f7fa fe2b 	bl	200216ac <_fstat>
20026a56:	1c43      	adds	r3, r0, #1
20026a58:	d102      	bne.n	20026a60 <_fstat_r+0x1c>
20026a5a:	682b      	ldr	r3, [r5, #0]
20026a5c:	b103      	cbz	r3, 20026a60 <_fstat_r+0x1c>
20026a5e:	6023      	str	r3, [r4, #0]
20026a60:	bd38      	pop	{r3, r4, r5, pc}
20026a62:	bf00      	nop
20026a64:	2004d210 	.word	0x2004d210

20026a68 <_isatty_r>:
20026a68:	b538      	push	{r3, r4, r5, lr}
20026a6a:	2300      	movs	r3, #0
20026a6c:	4d05      	ldr	r5, [pc, #20]	@ (20026a84 <_isatty_r+0x1c>)
20026a6e:	4604      	mov	r4, r0
20026a70:	4608      	mov	r0, r1
20026a72:	602b      	str	r3, [r5, #0]
20026a74:	f7fa fe1c 	bl	200216b0 <_isatty>
20026a78:	1c43      	adds	r3, r0, #1
20026a7a:	d102      	bne.n	20026a82 <_isatty_r+0x1a>
20026a7c:	682b      	ldr	r3, [r5, #0]
20026a7e:	b103      	cbz	r3, 20026a82 <_isatty_r+0x1a>
20026a80:	6023      	str	r3, [r4, #0]
20026a82:	bd38      	pop	{r3, r4, r5, pc}
20026a84:	2004d210 	.word	0x2004d210

20026a88 <_sbrk>:
20026a88:	4a05      	ldr	r2, [pc, #20]	@ (20026aa0 <_sbrk+0x18>)
20026a8a:	4603      	mov	r3, r0
20026a8c:	6810      	ldr	r0, [r2, #0]
20026a8e:	b110      	cbz	r0, 20026a96 <_sbrk+0xe>
20026a90:	4403      	add	r3, r0
20026a92:	6013      	str	r3, [r2, #0]
20026a94:	4770      	bx	lr
20026a96:	4803      	ldr	r0, [pc, #12]	@ (20026aa4 <_sbrk+0x1c>)
20026a98:	4403      	add	r3, r0
20026a9a:	6013      	str	r3, [r2, #0]
20026a9c:	4770      	bx	lr
20026a9e:	bf00      	nop
20026aa0:	2004d218 	.word	0x2004d218
20026aa4:	20042000 	.word	0x20042000
20026aa8:	61766e69 	.word	0x61766e69
20026aac:	2064696c 	.word	0x2064696c
20026ab0:	746f6f62 	.word	0x746f6f62
20026ab4:	76656420 	.word	0x76656420
20026ab8:	00656369 	.word	0x00656369
20026abc:	693a4c42 	.word	0x693a4c42
20026ac0:	6c61766e 	.word	0x6c61766e
20026ac4:	66206469 	.word	0x66206469
20026ac8:	20626174 	.word	0x20626174
20026acc:	6967616d 	.word	0x6967616d
20026ad0:	72662063 	.word	0x72662063
20026ad4:	64206d6f 	.word	0x64206d6f
20026ad8:	63697665 	.word	0x63697665
20026adc:	64253a65 	.word	0x64253a65
20026ae0:	4c42000a 	.word	0x4c42000a
20026ae4:	6f6f623a 	.word	0x6f6f623a
20026ae8:	65642074 	.word	0x65642074
20026aec:	65636976 	.word	0x65636976
20026af0:	696e6920 	.word	0x696e6920
20026af4:	61662074 	.word	0x61662074
20026af8:	66206c69 	.word	0x66206c69
20026afc:	3a6d6f72 	.word	0x3a6d6f72
20026b00:	000a6425 	.word	0x000a6425
20026b04:	64616f6c 	.word	0x64616f6c
20026b08:	6e616220 	.word	0x6e616220
20026b0c:	6620306b 	.word	0x6620306b
20026b10:	736c6961 	.word	0x736c6961
20026b14:	616d6900 	.word	0x616d6900
20026b18:	73206567 	.word	0x73206567
20026b1c:	616e6769 	.word	0x616e6769
20026b20:	65727574 	.word	0x65727574
20026b24:	72657620 	.word	0x72657620
20026b28:	63696669 	.word	0x63696669
20026b2c:	6f697461 	.word	0x6f697461
20026b30:	6166206e 	.word	0x6166206e
20026b34:	00736c69 	.word	0x00736c69
20026b38:	2070614d 	.word	0x2070614d
20026b3c:	6f727265 	.word	0x6f727265
20026b40:	6c203a72 	.word	0x6c203a72
20026b44:	6369676f 	.word	0x6369676f
20026b48:	2c642520 	.word	0x2c642520
20026b4c:	79687020 	.word	0x79687020
20026b50:	0a642520 	.word	0x0a642520
20026b54:	52524500 	.word	0x52524500
20026b58:	2032203a 	.word	0x2032203a
20026b5c:	69676f6c 	.word	0x69676f6c
20026b60:	6c622063 	.word	0x6c622063
20026b64:	736b636f 	.word	0x736b636f
20026b68:	70616d20 	.word	0x70616d20
20026b6c:	206f7420 	.word	0x206f7420
20026b70:	656d6173 	.word	0x656d6173
20026b74:	6b6c6220 	.word	0x6b6c6220
20026b78:	6f6c203a 	.word	0x6f6c203a
20026b7c:	30636967 	.word	0x30636967
20026b80:	2c642520 	.word	0x2c642520
20026b84:	79687020 	.word	0x79687020
20026b88:	64252030 	.word	0x64252030
20026b8c:	6f6c202c 	.word	0x6f6c202c
20026b90:	31636967 	.word	0x31636967
20026b94:	2c642520 	.word	0x2c642520
20026b98:	79687020 	.word	0x79687020
20026b9c:	64252031 	.word	0x64252031
20026ba0:	614d000a 	.word	0x614d000a
20026ba4:	72652070 	.word	0x72652070
20026ba8:	30726f72 	.word	0x30726f72
20026bac:	6f6c203a 	.word	0x6f6c203a
20026bb0:	20636967 	.word	0x20636967
20026bb4:	202c6425 	.word	0x202c6425
20026bb8:	20796870 	.word	0x20796870
20026bbc:	000a6425 	.word	0x000a6425
20026bc0:	20746547 	.word	0x20746547
20026bc4:	2070616d 	.word	0x2070616d
20026bc8:	636f6c62 	.word	0x636f6c62
20026bcc:	7265206b 	.word	0x7265206b
20026bd0:	20726f72 	.word	0x20726f72
20026bd4:	2d206425 	.word	0x2d206425
20026bd8:	25203e2d 	.word	0x25203e2d
20026bdc:	42000a64 	.word	0x42000a64
20026be0:	76204d42 	.word	0x76204d42
20026be4:	69737265 	.word	0x69737265
20026be8:	6e206e6f 	.word	0x6e206e6f
20026bec:	6920746f 	.word	0x6920746f
20026bf0:	6572636e 	.word	0x6572636e
20026bf4:	64657361 	.word	0x64657361
20026bf8:	7270203a 	.word	0x7270203a
20026bfc:	25207665 	.word	0x25207665
20026c00:	63202c64 	.word	0x63202c64
20026c04:	20727275 	.word	0x20727275
20026c08:	000a6425 	.word	0x000a6425
20026c0c:	41544144 	.word	0x41544144
20026c10:	746f6e20 	.word	0x746f6e20
20026c14:	61657220 	.word	0x61657220
20026c18:	616e6f73 	.word	0x616e6f73
20026c1c:	20656c62 	.word	0x20656c62
20026c20:	42206e69 	.word	0x42206e69
20026c24:	62204d42 	.word	0x62204d42
20026c28:	25206b6c 	.word	0x25206b6c
20026c2c:	61702064 	.word	0x61702064
20026c30:	25206567 	.word	0x25206567
20026c34:	30203a64 	.word	0x30203a64
20026c38:	0a782578 	.word	0x0a782578
20026c3c:	61655200 	.word	0x61655200
20026c40:	62622064 	.word	0x62622064
20026c44:	6c62206d 	.word	0x6c62206d
20026c48:	6425206b 	.word	0x6425206b
20026c4c:	67617020 	.word	0x67617020
20026c50:	64252065 	.word	0x64252065
20026c54:	69616620 	.word	0x69616620
20026c58:	49000a6c 	.word	0x49000a6c
20026c5c:	6c61766e 	.word	0x6c61766e
20026c60:	42206469 	.word	0x42206469
20026c64:	49204d42 	.word	0x49204d42
20026c68:	25205844 	.word	0x25205844
20026c6c:	56000a64 	.word	0x56000a64
20026c70:	64252031 	.word	0x64252031
20026c74:	206e6920 	.word	0x206e6920
20026c78:	636f6c62 	.word	0x636f6c62
20026c7c:	6425206b 	.word	0x6425206b
20026c80:	3256202c 	.word	0x3256202c
20026c84:	20642520 	.word	0x20642520
20026c88:	62206e69 	.word	0x62206e69
20026c8c:	6b636f6c 	.word	0x6b636f6c
20026c90:	0a642520 	.word	0x0a642520
20026c94:	6d615300 	.word	0x6d615300
20026c98:	69687465 	.word	0x69687465
20026c9c:	6d20676e 	.word	0x6d20676e
20026ca0:	20747375 	.word	0x20747375
20026ca4:	77206562 	.word	0x77206562
20026ca8:	676e6f72 	.word	0x676e6f72
20026cac:	6567202c 	.word	0x6567202c
20026cb0:	656e2074 	.word	0x656e2074
20026cb4:	65762077 	.word	0x65762077
20026cb8:	6f697372 	.word	0x6f697372
20026cbc:	6425206e 	.word	0x6425206e
20026cc0:	206f6420 	.word	0x206f6420
20026cc4:	20746f6e 	.word	0x20746f6e
20026cc8:	656d6173 	.word	0x656d6173
20026ccc:	206f7420 	.word	0x206f7420
20026cd0:	76657270 	.word	0x76657270
20026cd4:	65686320 	.word	0x65686320
20026cd8:	25206b63 	.word	0x25206b63
20026cdc:	43000a64 	.word	0x43000a64
20026ce0:	63204352 	.word	0x63204352
20026ce4:	6b636568 	.word	0x6b636568
20026ce8:	72726520 	.word	0x72726520
20026cec:	0a20726f 	.word	0x0a20726f
20026cf0:	61655200 	.word	0x61655200
20026cf4:	62622064 	.word	0x62622064
20026cf8:	6c62206d 	.word	0x6c62206d
20026cfc:	6425206b 	.word	0x6425206b
20026d00:	67617020 	.word	0x67617020
20026d04:	64252065 	.word	0x64252065
20026d08:	74616420 	.word	0x74616420
20026d0c:	6f6e2061 	.word	0x6f6e2061
20026d10:	72772074 	.word	0x72772074
20026d14:	20657469 	.word	0x20657469
20026d18:	20726f66 	.word	0x20726f66
20026d1c:	20646e32 	.word	0x20646e32
20026d20:	656d6974 	.word	0x656d6974
20026d24:	6552000a 	.word	0x6552000a
20026d28:	62206461 	.word	0x62206461
20026d2c:	62206d62 	.word	0x62206d62
20026d30:	25206b6c 	.word	0x25206b6c
20026d34:	61702064 	.word	0x61702064
20026d38:	25206567 	.word	0x25206567
20026d3c:	61662064 	.word	0x61662064
20026d40:	66206c69 	.word	0x66206c69
20026d44:	3220726f 	.word	0x3220726f
20026d48:	7420646e 	.word	0x7420646e
20026d4c:	3f656d69 	.word	0x3f656d69
20026d50:	614c000a 	.word	0x614c000a
20026d54:	74736574 	.word	0x74736574
20026d58:	72657620 	.word	0x72657620
20026d5c:	6e6f6973 	.word	0x6e6f6973
20026d60:	0a642520 	.word	0x0a642520
20026d64:	74654700 	.word	0x74654700
20026d68:	79687020 	.word	0x79687020
20026d6c:	6b6c6220 	.word	0x6b6c6220
20026d70:	726f6620 	.word	0x726f6620
20026d74:	20642520 	.word	0x20642520
20026d78:	6c696166 	.word	0x6c696166
20026d7c:	65687720 	.word	0x65687720
20026d80:	6572206e 	.word	0x6572206e
20026d84:	000a6461 	.word	0x000a6461
20026d88:	636f6c42 	.word	0x636f6c42
20026d8c:	6425206b 	.word	0x6425206b
20026d90:	61726520 	.word	0x61726520
20026d94:	66206573 	.word	0x66206573
20026d98:	2c6c6961 	.word	0x2c6c6961
20026d9c:	72616d20 	.word	0x72616d20
20026da0:	7361206b 	.word	0x7361206b
20026da4:	64616220 	.word	0x64616220
20026da8:	6c42000a 	.word	0x6c42000a
20026dac:	206b636f 	.word	0x206b636f
20026db0:	63206425 	.word	0x63206425
20026db4:	6b636568 	.word	0x6b636568
20026db8:	20736120 	.word	0x20736120
20026dbc:	20646162 	.word	0x20646162
20026dc0:	636f6c62 	.word	0x636f6c62
20026dc4:	42000a6b 	.word	0x42000a6b
20026dc8:	6b636f6c 	.word	0x6b636f6c
20026dcc:	20642520 	.word	0x20642520
20026dd0:	62207369 	.word	0x62207369
20026dd4:	69206461 	.word	0x69206461
20026dd8:	7375206e 	.word	0x7375206e
20026ddc:	62207265 	.word	0x62207265
20026de0:	6b636f6c 	.word	0x6b636f6c
20026de4:	6162000a 	.word	0x6162000a
20026de8:	64252064 	.word	0x64252064
20026dec:	6572202c 	.word	0x6572202c
20026df0:	63616c70 	.word	0x63616c70
20026df4:	64252065 	.word	0x64252065
20026df8:	6f4e000a 	.word	0x6f4e000a
20026dfc:	63616220 	.word	0x63616220
20026e00:	2070756b 	.word	0x2070756b
20026e04:	636f6c62 	.word	0x636f6c62
20026e08:	6e61206b 	.word	0x6e61206b
20026e0c:	6f6d2079 	.word	0x6f6d2079
20026e10:	000a6572 	.word	0x000a6572
20026e14:	74706d65 	.word	0x74706d65
20026e18:	61742079 	.word	0x61742079
20026e1c:	20656c62 	.word	0x20656c62
20026e20:	6e206425 	.word	0x6e206425
20026e24:	6520746f 	.word	0x6520746f
20026e28:	67756f6e 	.word	0x67756f6e
20026e2c:	6f662068 	.word	0x6f662068
20026e30:	6e692072 	.word	0x6e692072
20026e34:	61697469 	.word	0x61697469
20026e38:	55000a6c 	.word	0x55000a6c
20026e3c:	74616470 	.word	0x74616470
20026e40:	61742065 	.word	0x61742065
20026e44:	20656c62 	.word	0x20656c62
20026e48:	66206f74 	.word	0x66206f74
20026e4c:	6873616c 	.word	0x6873616c
20026e50:	6e6f6420 	.word	0x6e6f6420
20026e54:	49000a65 	.word	0x49000a65
20026e58:	6974696e 	.word	0x6974696e
20026e5c:	74206c61 	.word	0x74206c61
20026e60:	656c6261 	.word	0x656c6261
20026e64:	69616620 	.word	0x69616620
20026e68:	42000a6c 	.word	0x42000a6c
20026e6c:	69204d42 	.word	0x69204d42
20026e70:	6974696e 	.word	0x6974696e
20026e74:	7a696c61 	.word	0x7a696c61
20026e78:	62206465 	.word	0x62206465
20026e7c:	726f6665 	.word	0x726f6665
20026e80:	64202c65 	.word	0x64202c65
20026e84:	6f6e206f 	.word	0x6f6e206f
20026e88:	6e692074 	.word	0x6e692074
20026e8c:	61207469 	.word	0x61207469
20026e90:	6d20796e 	.word	0x6d20796e
20026e94:	0a65726f 	.word	0x0a65726f
20026e98:	54454400 	.word	0x54454400
20026e9c:	20642520 	.word	0x20642520
20026ea0:	0a646162 	.word	0x0a646162
20026ea4:	4b4c4200 	.word	0x4b4c4200
20026ea8:	20642520 	.word	0x20642520
20026eac:	64616572 	.word	0x64616572
20026eb0:	69616620 	.word	0x69616620
20026eb4:	6d202c6c 	.word	0x6d202c6c
20026eb8:	206b7261 	.word	0x206b7261
20026ebc:	62207361 	.word	0x62207361
20026ec0:	000a6461 	.word	0x000a6461
20026ec4:	20746564 	.word	0x20746564
20026ec8:	206d6262 	.word	0x206d6262
20026ecc:	6c626174 	.word	0x6c626174
20026ed0:	69772065 	.word	0x69772065
20026ed4:	25206874 	.word	0x25206874
20026ed8:	25202c64 	.word	0x25202c64
20026edc:	25202c64 	.word	0x25202c64
20026ee0:	64000a64 	.word	0x64000a64
20026ee4:	63657465 	.word	0x63657465
20026ee8:	65722074 	.word	0x65722074
20026eec:	746c7573 	.word	0x746c7573
20026ef0:	0a642520 	.word	0x0a642520
20026ef4:	20317600 	.word	0x20317600
20026ef8:	69206425 	.word	0x69206425
20026efc:	6c62206e 	.word	0x6c62206e
20026f00:	6425206b 	.word	0x6425206b
20026f04:	3276202c 	.word	0x3276202c
20026f08:	20642520 	.word	0x20642520
20026f0c:	62206e69 	.word	0x62206e69
20026f10:	6b636f6c 	.word	0x6b636f6c
20026f14:	0a642520 	.word	0x0a642520
20026f18:	65684300 	.word	0x65684300
20026f1c:	62206b63 	.word	0x62206b63
20026f20:	74206d62 	.word	0x74206d62
20026f24:	656c6261 	.word	0x656c6261
20026f28:	69616620 	.word	0x69616620
20026f2c:	64000a6c 	.word	0x64000a6c
20026f30:	63657465 	.word	0x63657465
20026f34:	65722074 	.word	0x65722074
20026f38:	746c7573 	.word	0x746c7573
20026f3c:	20642520 	.word	0x20642520
20026f40:	20746f6e 	.word	0x20746f6e
20026f44:	73616572 	.word	0x73616572
20026f48:	62616e6f 	.word	0x62616e6f
20026f4c:	000a656c 	.word	0x000a656c
20026f50:	204d4242 	.word	0x204d4242
20026f54:	3a4d454d 	.word	0x3a4d454d
20026f58:	78746320 	.word	0x78746320
20026f5c:	2c702520 	.word	0x2c702520
20026f60:	70616d20 	.word	0x70616d20
20026f64:	70252031 	.word	0x70252031
20026f68:	616d202c 	.word	0x616d202c
20026f6c:	25203270 	.word	0x25203270
20026f70:	000a2070 	.word	0x000a2070
20026f74:	5f666973 	.word	0x5f666973
20026f78:	5f6d6262 	.word	0x5f6d6262
20026f7c:	74696e69 	.word	0x74696e69
20026f80:	6e6f6420 	.word	0x6e6f6420
20026f84:	23000a65 	.word	0x23000a65
20026f88:	202b302d 	.word	0x202b302d
20026f8c:	4c6c6800 	.word	0x4c6c6800
20026f90:	67666500 	.word	0x67666500
20026f94:	00474645 	.word	0x00474645
20026f98:	33323130 	.word	0x33323130
20026f9c:	37363534 	.word	0x37363534
20026fa0:	42413938 	.word	0x42413938
20026fa4:	46454443 	.word	0x46454443
20026fa8:	32313000 	.word	0x32313000
20026fac:	36353433 	.word	0x36353433
20026fb0:	61393837 	.word	0x61393837
20026fb4:	65646362 	.word	0x65646362
20026fb8:	00000066 	.word	0x00000066
20026fbc:	50042000 	.word	0x50042000
20026fc0:	00000002 	.word	0x00000002
20026fc4:	12000000 	.word	0x12000000
20026fc8:	00000004 	.word	0x00000004
20026fcc:	00000000 	.word	0x00000000
20026fd0:	50041000 	.word	0x50041000
20026fd4:	00000002 	.word	0x00000002
20026fd8:	10000000 	.word	0x10000000
20026fdc:	00000004 	.word	0x00000004
20026fe0:	00000000 	.word	0x00000000
20026fe4:	50043000 	.word	0x50043000
20026fe8:	00000002 	.word	0x00000002
20026fec:	14000000 	.word	0x14000000
20026ff0:	00000004 	.word	0x00000004
20026ff4:	00000000 	.word	0x00000000

20026ff8 <pad_fsel_func_tbls>:
20026ff8:	200275f0 200275e4 200275d8 200275cc     .u. .u. .u. .u. 
20027008:	200275c0 200275b4 200275a8 2002759c     .u. .u. .u. .u. 
20027018:	20027590 20027580 20027574 20027564     .u. .u. tu. du. 
20027028:	20027550 20027548 2002753c 20027530     Pu. Hu. <u. 0u. 
20027038:	20027524 20027518 2002750c 200274fc     $u. .u. .u. .t. 
20027048:	200274ec 200274dc 200274cc 200274bc     .t. .t. .t. .t. 
20027058:	200274ac 20027498 20027488 2002747c     .t. .t. .t. |t. 
20027068:	20027468 20027454 20027440 2002742c     ht. Tt. @t. ,t. 
20027078:	20027418 20027404 200273f0 200273e0     .t. .t. .s. .s. 
20027088:	200273d4 200273c0 200273b0 200273a0     .s. .s. .s. .s. 
20027098:	20027390 20027380 20027370 20027360     .s. .s. ps. `s. 
200270a8:	20027350 20027340 20027330 20027328     Ps. @s. 0s. (s. 
200270b8:	20027318 20027308 200272f4 200272e0     .s. .s. .r. .r. 
200270c8:	200272d0 200272c0 200272b0 200272a0     .r. .r. .r. .r. 
200270d8:	20027294 20027284 20027278 2002726c     .r. .r. xr. lr. 
200270e8:	20027264 2002725c 20027254 20027240     dr. \r. Tr. @r. 
200270f8:	20027230 2002721c 20027208 200271f8     0r. .r. .r. .q. 
20027108:	200271e8 200271d8 200271c8 200271bc     .q. .q. .q. .q. 
20027118:	200271b0 200271a4 20027198 2002718c     .q. .q. .q. .q. 
20027128:	20027180 20027178 20027170 20027168     .q. xq. pq. hq. 
20027138:	20027160 20027158 20027150 20027148     `q. Xq. Pq. Hq. 

20027148 <pad_pa57_fsel_func_tbl>:
20027148:	01670000 00000000                       ..g.....

20027150 <pad_pa56_fsel_func_tbl>:
20027150:	01660000 00000000                       ..f.....

20027158 <pad_pa55_fsel_func_tbl>:
20027158:	01650000 00000000                       ..e.....

20027160 <pad_pa54_fsel_func_tbl>:
20027160:	01640000 00000000                       ..d.....

20027168 <pad_pa53_fsel_func_tbl>:
20027168:	01630000 00000000                       ..c.....

20027170 <pad_pa52_fsel_func_tbl>:
20027170:	01620000 00000000                       ..b.....

20027178 <pad_pa51_fsel_func_tbl>:
20027178:	01610000 00000000                       ..a.....

20027180 <pad_pa50_fsel_func_tbl>:
20027180:	01600000 01870003 00000000              ..`.........

2002718c <pad_pa49_fsel_func_tbl>:
2002718c:	015f0000 01860003 00000000              .._.........

20027198 <pad_pa48_fsel_func_tbl>:
20027198:	015e0000 01850003 00000000              ..^.........

200271a4 <pad_pa47_fsel_func_tbl>:
200271a4:	015d0000 01830003 00000000              ..].........

200271b0 <pad_pa46_fsel_func_tbl>:
200271b0:	015c0000 01890003 00000000              ..\.........

200271bc <pad_pa45_fsel_func_tbl>:
200271bc:	015b0000 01880003 00000000              ..[.........

200271c8 <pad_pa44_fsel_func_tbl>:
200271c8:	015a0000 018c0001 01b70007 00000000     ..Z.............

200271d8 <pad_pa43_fsel_func_tbl>:
200271d8:	01590000 018b0001 01b60007 00000000     ..Y.............

200271e8 <pad_pa42_fsel_func_tbl>:
200271e8:	01580000 017c0002 01b50007 00000000     ..X...|.........

200271f8 <pad_pa41_fsel_func_tbl>:
200271f8:	01570000 017b0002 01b40007 00000000     ..W...{.........

20027208 <pad_pa40_fsel_func_tbl>:
20027208:	01560000 01750001 017a0002 01b30007     ..V...u...z.....
20027218:	00000000                                ....

2002721c <pad_pa39_fsel_func_tbl>:
2002721c:	01550000 01740001 01780002 01b20007     ..U...t...x.....
2002722c:	00000000                                ....

20027230 <pad_pa38_fsel_func_tbl>:
20027230:	01540000 01760001 017e0002 00000000     ..T...v...~.....

20027240 <pad_pa37_fsel_func_tbl>:
20027240:	01530000 01770001 017d0002 01b10007     ..S...w...}.....
20027250:	00000000                                ....

20027254 <pad_pa36_fsel_func_tbl>:
20027254:	01520000 00000000                       ..R.....

2002725c <pad_pa35_fsel_func_tbl>:
2002725c:	01510000 00000000                       ..Q.....

20027264 <pad_pa34_fsel_func_tbl>:
20027264:	01500000 00000000                       ..P.....

2002726c <pad_pa33_fsel_func_tbl>:
2002726c:	014f0000 01870003 00000000              ..O.........

20027278 <pad_pa32_fsel_func_tbl>:
20027278:	014e0000 01860003 00000000              ..N.........

20027284 <pad_pa31_fsel_func_tbl>:
20027284:	014d0000 01850003 01b00007 00000000     ..M.............

20027294 <pad_pa30_fsel_func_tbl>:
20027294:	014c0000 01830003 00000000              ..L.........

200272a0 <pad_pa29_fsel_func_tbl>:
200272a0:	014b0000 01710001 01890003 00000000     ..K...q.........

200272b0 <pad_pa28_fsel_func_tbl>:
200272b0:	014a0000 01700001 01880003 00000000     ..J...p.........

200272c0 <pad_pa27_fsel_func_tbl>:
200272c0:	01490000 017c0002 01870003 00000000     ..I...|.........

200272d0 <pad_pa26_fsel_func_tbl>:
200272d0:	01480000 017b0002 01860003 00000000     ..H...{.........

200272e0 <pad_pa25_fsel_func_tbl>:
200272e0:	01470000 01720001 017a0002 01850003     ..G...r...z.....
200272f0:	00000000                                ....

200272f4 <pad_pa24_fsel_func_tbl>:
200272f4:	01460000 01730001 01780002 01830003     ..F...s...x.....
20027304:	00000000                                ....

20027308 <pad_pa23_fsel_func_tbl>:
20027308:	01450000 017e0002 01890003 00000000     ..E...~.........

20027318 <pad_pa22_fsel_func_tbl>:
20027318:	01440000 017d0002 01880003 00000000     ..D...}.........

20027328 <pad_pa21_fsel_func_tbl>:
20027328:	01430000 00000000                       ..C.....

20027330 <pad_pa20_fsel_func_tbl>:
20027330:	01420000 018d0001 01b80007 00000000     ..B.............

20027340 <pad_pa19_fsel_func_tbl>:
20027340:	01410000 00200001 018c0002 00000000     ..A... .........

20027350 <pad_pa18_fsel_func_tbl>:
20027350:	01400000 00210001 018b0002 00000000     ..@...!.........

20027360 <pad_pa17_fsel_func_tbl>:
20027360:	013f0000 012d0001 017c0002 00000000     ..?...-...|.....

20027370 <pad_pa16_fsel_func_tbl>:
20027370:	013e0000 01260001 017b0002 00000000     ..>...&...{.....

20027380 <pad_pa15_fsel_func_tbl>:
20027380:	013d0000 012a0001 017a0002 00000000     ..=...*...z.....

20027390 <pad_pa14_fsel_func_tbl>:
20027390:	013c0000 012c0001 01780002 00000000     ..<...,...x.....

200273a0 <pad_pa13_fsel_func_tbl>:
200273a0:	013b0000 012b0001 017e0002 00000000     ..;...+...~.....

200273b0 <pad_pa12_fsel_func_tbl>:
200273b0:	013a0000 01270001 017d0002 00000000     ..:...'...}.....

200273c0 <pad_pa11_fsel_func_tbl>:
200273c0:	01390000 01280001 017c0002 018a0007     ..9...(...|.....
200273d0:	00000000                                ....

200273d4 <pad_pa10_fsel_func_tbl>:
200273d4:	01380000 017b0002 00000000              ..8...{.....

200273e0 <pad_pa09_fsel_func_tbl>:
200273e0:	01370000 017a0002 01af0007 00000000     ..7...z.........

200273f0 <pad_pa08_fsel_func_tbl>:
200273f0:	01360000 016d0001 01780002 01ae0007     ..6...m...x.....
20027400:	00000000                                ....

20027404 <pad_pa07_fsel_func_tbl>:
20027404:	01350000 016c0001 017e0002 01ad0007     ..5...l...~.....
20027414:	00000000                                ....

20027418 <pad_pa06_fsel_func_tbl>:
20027418:	01340000 016b0001 017d0002 01ac0007     ..4...k...}.....
20027428:	00000000                                ....

2002742c <pad_pa05_fsel_func_tbl>:
2002742c:	01330000 016a0001 01870003 01ab0007     ..3...j.........
2002743c:	00000000                                ....

20027440 <pad_pa04_fsel_func_tbl>:
20027440:	01320000 01690001 01860003 01aa0007     ..2...i.........
20027450:	00000000                                ....

20027454 <pad_pa03_fsel_func_tbl>:
20027454:	01310000 01680001 01850003 01a90007     ..1...h.........
20027464:	00000000                                ....

20027468 <pad_pa02_fsel_func_tbl>:
20027468:	01300000 016f0001 01830003 01a80007     ..0...o.........
20027478:	00000000                                ....

2002747c <pad_pa01_fsel_func_tbl>:
2002747c:	012f0000 01890003 00000000              ../.........

20027488 <pad_pa00_fsel_func_tbl>:
20027488:	012e0000 016e0001 01880003 00000000     ......n.........

20027498 <pad_sb12_fsel_func_tbl>:
20027498:	011a0001 011b0002 01180003 01160004     ................
200274a8:	00000000                                ....

200274ac <pad_sb11_fsel_func_tbl>:
200274ac:	01250001 01160003 01210004 00000000     ..%.......!.....

200274bc <pad_sb10_fsel_func_tbl>:
200274bc:	01240001 011b0003 011e0004 00000000     ..$.............

200274cc <pad_sb09_fsel_func_tbl>:
200274cc:	01230001 01250003 01260004 00000000     ..#...%...&.....

200274dc <pad_sb08_fsel_func_tbl>:
200274dc:	01220001 01240003 012d0004 00000000     .."...$...-.....

200274ec <pad_sb07_fsel_func_tbl>:
200274ec:	01160001 01230003 012a0004 00000000     ......#...*.....

200274fc <pad_sb06_fsel_func_tbl>:
200274fc:	01170001 01220003 01180004 00000000     ......".........

2002750c <pad_sb05_fsel_func_tbl>:
2002750c:	01180001 011f0004 00000000              ............

20027518 <pad_sb04_fsel_func_tbl>:
20027518:	01210001 01200004 00000000              ..!... .....

20027524 <pad_sb03_fsel_func_tbl>:
20027524:	01200001 01270004 00000000              .. ...'.....

20027530 <pad_sb02_fsel_func_tbl>:
20027530:	011f0001 012b0004 00000000              ......+.....

2002753c <pad_sb01_fsel_func_tbl>:
2002753c:	011e0001 012c0004 00000000              ......,.....

20027548 <pad_sb00_fsel_func_tbl>:
20027548:	01190001 00000000                       ........

20027550 <pad_sa12_fsel_func_tbl>:
20027550:	010a0001 010b0002 01080003 01020004     ................
20027560:	00000000                                ....

20027564 <pad_sa11_fsel_func_tbl>:
20027564:	01150001 01060003 01050004 00000000     ................

20027574 <pad_sa10_fsel_func_tbl>:
20027574:	01140001 01000004 00000000              ............

20027580 <pad_sa09_fsel_func_tbl>:
20027580:	01130001 010b0003 01050004 00000000     ................

20027590 <pad_sa08_fsel_func_tbl>:
20027590:	01120001 01150003 00000000              ............

2002759c <pad_sa07_fsel_func_tbl>:
2002759c:	01060001 01140003 00000000              ............

200275a8 <pad_sa06_fsel_func_tbl>:
200275a8:	01070001 01130003 00000000              ............

200275b4 <pad_sa05_fsel_func_tbl>:
200275b4:	01080001 01120003 00000000              ............

200275c0 <pad_sa04_fsel_func_tbl>:
200275c0:	01110001 01040004 00000000              ............

200275cc <pad_sa03_fsel_func_tbl>:
200275cc:	01100001 01010004 00000000              ............

200275d8 <pad_sa02_fsel_func_tbl>:
200275d8:	010f0001 01030004 00000000              ............

200275e4 <pad_sa01_fsel_func_tbl>:
200275e4:	010e0001 01040004 00000000              ............

200275f0 <pad_sa00_fsel_func_tbl>:
200275f0:	01090001 01010004 00000000 00000000     ................
20027600:	04030201 00000000 01060204              ............

2002760c <hpsys_dll2_limit>:
	...
20027614:	112a8800 112a8800                       ..*...*.

2002761c <hpsys_dvfs_config>:
2002761c:	000906fb 00100330 000a08fd 00110331     ....0.......1...
2002762c:	000d0b00 00130213 000f0e02 00130213     ................

2002763c <crc32tab>:
2002763c:	00000000 77073096 ee0e612c 990951ba     .....0.w,a...Q..
2002764c:	076dc419 706af48f e963a535 9e6495a3     ..m...jp5.c...d.
2002765c:	0edb8832 79dcb8a4 e0d5e91e 97d2d988     2......y........
2002766c:	09b64c2b 7eb17cbd e7b82d07 90bf1d91     +L...|.~.-......
2002767c:	1db71064 6ab020f2 f3b97148 84be41de     d.... .jHq...A..
2002768c:	1adad47d 6ddde4eb f4d4b551 83d385c7     }......mQ.......
2002769c:	136c9856 646ba8c0 fd62f97a 8a65c9ec     V.l...kdz.b...e.
200276ac:	14015c4f 63066cd9 fa0f3d63 8d080df5     O\...l.cc=......
200276bc:	3b6e20c8 4c69105e d56041e4 a2677172     . n;^.iL.A`.rqg.
200276cc:	3c03e4d1 4b04d447 d20d85fd a50ab56b     ...<G..K....k...
200276dc:	35b5a8fa 42b2986c dbbbc9d6 acbcf940     ...5l..B....@...
200276ec:	32d86ce3 45df5c75 dcd60dcf abd13d59     .l.2u\.E....Y=..
200276fc:	26d930ac 51de003a c8d75180 bfd06116     .0.&:..Q.Q...a..
2002770c:	21b4f4b5 56b3c423 cfba9599 b8bda50f     ...!#..V........
2002771c:	2802b89e 5f058808 c60cd9b2 b10be924     ...(..._....$...
2002772c:	2f6f7c87 58684c11 c1611dab b6662d3d     .|o/.LhX..a.=-f.
2002773c:	76dc4190 01db7106 98d220bc efd5102a     .A.v.q... ..*...
2002774c:	71b18589 06b6b51f 9fbfe4a5 e8b8d433     ...q........3...
2002775c:	7807c9a2 0f00f934 9609a88e e10e9818     ...x4...........
2002776c:	7f6a0dbb 086d3d2d 91646c97 e6635c01     ..j.-=m..ld..\c.
2002777c:	6b6b51f4 1c6c6162 856530d8 f262004e     .Qkkbal..0e.N.b.
2002778c:	6c0695ed 1b01a57b 8208f4c1 f50fc457     ...l{.......W...
2002779c:	65b0d9c6 12b7e950 8bbeb8ea fcb9887c     ...eP.......|...
200277ac:	62dd1ddf 15da2d49 8cd37cf3 fbd44c65     ...bI-...|..eL..
200277bc:	4db26158 3ab551ce a3bc0074 d4bb30e2     Xa.M.Q.:t....0..
200277cc:	4adfa541 3dd895d7 a4d1c46d d3d6f4fb     A..J...=m.......
200277dc:	4369e96a 346ed9fc ad678846 da60b8d0     j.iC..n4F.g...`.
200277ec:	44042d73 33031de5 aa0a4c5f dd0d7cc9     s-.D...3_L...|..
200277fc:	5005713c 270241aa be0b1010 c90c2086     <q.P.A.'..... ..
2002780c:	5768b525 206f85b3 b966d409 ce61e49f     %.hW..o ..f...a.
2002781c:	5edef90e 29d9c998 b0d09822 c7d7a8b4     ...^...)".......
2002782c:	59b33d17 2eb40d81 b7bd5c3b c0ba6cad     .=.Y....;\...l..
2002783c:	edb88320 9abfb3b6 03b6e20c 74b1d29a      ..............t
2002784c:	ead54739 9dd277af 04db2615 73dc1683     9G...w...&.....s
2002785c:	e3630b12 94643b84 0d6d6a3e 7a6a5aa8     ..c..;d.>jm..Zjz
2002786c:	e40ecf0b 9309ff9d 0a00ae27 7d079eb1     ........'......}
2002787c:	f00f9344 8708a3d2 1e01f268 6906c2fe     D.......h......i
2002788c:	f762575d 806567cb 196c3671 6e6b06e7     ]Wb..ge.q6l...kn
2002789c:	fed41b76 89d32be0 10da7a5a 67dd4acc     v....+..Zz...J.g
200278ac:	f9b9df6f 8ebeeff9 17b7be43 60b08ed5     o.......C......`
200278bc:	d6d6a3e8 a1d1937e 38d8c2c4 4fdff252     ....~......8R..O
200278cc:	d1bb67f1 a6bc5767 3fb506dd 48b2364b     .g..gW.....?K6.H
200278dc:	d80d2bda af0a1b4c 36034af6 41047a60     .+..L....J.6`z.A
200278ec:	df60efc3 a867df55 316e8eef 4669be79     ..`.U.g...n1y.iF
200278fc:	cb61b38c bc66831a 256fd2a0 5268e236     ..a...f...o%6.hR
2002790c:	cc0c7795 bb0b4703 220216b9 5505262f     .w...G....."/&.U
2002791c:	c5ba3bbe b2bd0b28 2bb45a92 5cb36a04     .;..(....Z.+.j.\
2002792c:	c2d7ffa7 b5d0cf31 2cd99e8b 5bdeae1d     ....1......,...[
2002793c:	9b64c2b0 ec63f226 756aa39c 026d930a     ..d.&.c...ju..m.
2002794c:	9c0906a9 eb0e363f 72076785 05005713     ....?6...g.r.W..
2002795c:	95bf4a82 e2b87a14 7bb12bae 0cb61b38     .J...z...+.{8...
2002796c:	92d28e9b e5d5be0d 7cdcefb7 0bdbdf21     ...........|!...
2002797c:	86d3d2d4 f1d4e242 68ddb3f8 1fda836e     ....B......hn...
2002798c:	81be16cd f6b9265b 6fb077e1 18b74777     ....[&...w.owG..
2002799c:	88085ae6 ff0f6a70 66063bca 11010b5c     .Z..pj...;.f\...
200279ac:	8f659eff f862ae69 616bffd3 166ccf45     ..e.i.b...kaE.l.
200279bc:	a00ae278 d70dd2ee 4e048354 3903b3c2     x.......T..N...9
200279cc:	a7672661 d06016f7 4969474d 3e6e77db     a&g...`.MGiI.wn>
200279dc:	aed16a4a d9d65adc 40df0b66 37d83bf0     Jj...Z..f..@.;.7
200279ec:	a9bcae53 debb9ec5 47b2cf7f 30b5ffe9     S..........G...0
200279fc:	bdbdf21c cabac28a 53b39330 24b4a3a6     ........0..S...$
20027a0c:	bad03605 cdd70693 54de5729 23d967bf     .6......)W.T.g.#
20027a1c:	b3667a2e c4614ab8 5d681b02 2a6f2b94     .zf..Ja...h].+o*
20027a2c:	b40bbe37 c30c8ea1 5a05df1b 2d02ef8d     7..........Z...-

20027a3c <_init>:
20027a3c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027a3e:	bf00      	nop
20027a40:	bcf8      	pop	{r3, r4, r5, r6, r7}
20027a42:	bc08      	pop	{r3}
20027a44:	469e      	mov	lr, r3
20027a46:	4770      	bx	lr

20027a48 <_fini>:
20027a48:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027a4a:	bf00      	nop
20027a4c:	bcf8      	pop	{r3, r4, r5, r6, r7}
20027a4e:	bc08      	pop	{r3}
20027a50:	469e      	mov	lr, r3
20027a52:	4770      	bx	lr

20027a54 <__EH_FRAME_BEGIN__>:
20027a54:	0000 0000                                   ....

Disassembly of section .l1_ret_text_bsp_psram_init_info:

20027a58 <bsp_psram_init_info>:
20027a58:	4b04      	ldr	r3, [pc, #16]	@ (20027a6c <bsp_psram_init_info+0x14>)
20027a5a:	4a05      	ldr	r2, [pc, #20]	@ (20027a70 <bsp_psram_init_info+0x18>)
20027a5c:	685b      	ldr	r3, [r3, #4]
20027a5e:	2000      	movs	r0, #0
20027a60:	f3c3 3301 	ubfx	r3, r3, #12, #2
20027a64:	7053      	strb	r3, [r2, #1]
20027a66:	2301      	movs	r3, #1
20027a68:	7013      	strb	r3, [r2, #0]
20027a6a:	4770      	bx	lr
20027a6c:	5000b000 	.word	0x5000b000
20027a70:	2004c990 	.word	0x2004c990

Disassembly of section .l1_ret_text_bsp_psram_get_mpi_mode:

20027a74 <bsp_psram_get_mpi_mode>:
20027a74:	2801      	cmp	r0, #1
20027a76:	b508      	push	{r3, lr}
20027a78:	d10a      	bne.n	20027a90 <bsp_psram_get_mpi_mode+0x1c>
20027a7a:	4906      	ldr	r1, [pc, #24]	@ (20027a94 <bsp_psram_get_mpi_mode+0x20>)
20027a7c:	780b      	ldrb	r3, [r1, #0]
20027a7e:	b90b      	cbnz	r3, 20027a84 <bsp_psram_get_mpi_mode+0x10>
20027a80:	f7ff ffea 	bl	20027a58 <bsp_psram_init_info>
20027a84:	784b      	ldrb	r3, [r1, #1]
20027a86:	4a04      	ldr	r2, [pc, #16]	@ (20027a98 <bsp_psram_get_mpi_mode+0x24>)
20027a88:	5cd0      	ldrb	r0, [r2, r3]
20027a8a:	f000 000f 	and.w	r0, r0, #15
20027a8e:	bd08      	pop	{r3, pc}
20027a90:	2000      	movs	r0, #0
20027a92:	e7fc      	b.n	20027a8e <bsp_psram_get_mpi_mode+0x1a>
20027a94:	2004c990 	.word	0x2004c990
20027a98:	20027ea8 	.word	0x20027ea8

Disassembly of section .l1_ret_text_bsp_psram1_pinmux_init:

20027a9c <bsp_psram1_pinmux_init>:
20027a9c:	b538      	push	{r3, r4, r5, lr}
20027a9e:	4998      	ldr	r1, [pc, #608]	@ (20027d00 <bsp_psram1_pinmux_init+0x264>)
20027aa0:	780b      	ldrb	r3, [r1, #0]
20027aa2:	b90b      	cbnz	r3, 20027aa8 <bsp_psram1_pinmux_init+0xc>
20027aa4:	f7ff ffd8 	bl	20027a58 <bsp_psram_init_info>
20027aa8:	784b      	ldrb	r3, [r1, #1]
20027aaa:	4a96      	ldr	r2, [pc, #600]	@ (20027d04 <bsp_psram1_pinmux_init+0x268>)
20027aac:	5cd4      	ldrb	r4, [r2, r3]
20027aae:	0924      	lsrs	r4, r4, #4
20027ab0:	2c01      	cmp	r4, #1
20027ab2:	d175      	bne.n	20027ba0 <bsp_psram1_pinmux_init+0x104>
20027ab4:	4623      	mov	r3, r4
20027ab6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027aba:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027abe:	2002      	movs	r0, #2
20027ac0:	f7fc fcc4 	bl	2002444c <HAL_PIN_Set>
20027ac4:	4623      	mov	r3, r4
20027ac6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027aca:	f240 110f 	movw	r1, #271	@ 0x10f
20027ace:	2003      	movs	r0, #3
20027ad0:	f7fc fcbc 	bl	2002444c <HAL_PIN_Set>
20027ad4:	4623      	mov	r3, r4
20027ad6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027ada:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027ade:	2004      	movs	r0, #4
20027ae0:	f7fc fcb4 	bl	2002444c <HAL_PIN_Set>
20027ae4:	4623      	mov	r3, r4
20027ae6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027aea:	f240 1111 	movw	r1, #273	@ 0x111
20027aee:	2005      	movs	r0, #5
20027af0:	f7fc fcac 	bl	2002444c <HAL_PIN_Set>
20027af4:	4623      	mov	r3, r4
20027af6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027afa:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027afe:	2009      	movs	r0, #9
20027b00:	f7fc fca4 	bl	2002444c <HAL_PIN_Set>
20027b04:	4623      	mov	r3, r4
20027b06:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b0a:	f240 1113 	movw	r1, #275	@ 0x113
20027b0e:	200a      	movs	r0, #10
20027b10:	f7fc fc9c 	bl	2002444c <HAL_PIN_Set>
20027b14:	4623      	mov	r3, r4
20027b16:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b1a:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027b1e:	200b      	movs	r0, #11
20027b20:	f7fc fc94 	bl	2002444c <HAL_PIN_Set>
20027b24:	4623      	mov	r3, r4
20027b26:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b2a:	f240 1115 	movw	r1, #277	@ 0x115
20027b2e:	200c      	movs	r0, #12
20027b30:	f7fc fc8c 	bl	2002444c <HAL_PIN_Set>
20027b34:	4623      	mov	r3, r4
20027b36:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b3a:	f240 1109 	movw	r1, #265	@ 0x109
20027b3e:	4620      	mov	r0, r4
20027b40:	f7fc fc84 	bl	2002444c <HAL_PIN_Set>
20027b44:	4623      	mov	r3, r4
20027b46:	2200      	movs	r2, #0
20027b48:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027b4c:	2006      	movs	r0, #6
20027b4e:	f7fc fc7d 	bl	2002444c <HAL_PIN_Set>
20027b52:	4623      	mov	r3, r4
20027b54:	2200      	movs	r2, #0
20027b56:	f240 1107 	movw	r1, #263	@ 0x107
20027b5a:	2007      	movs	r0, #7
20027b5c:	f7fc fc76 	bl	2002444c <HAL_PIN_Set>
20027b60:	4623      	mov	r3, r4
20027b62:	2200      	movs	r2, #0
20027b64:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027b68:	2008      	movs	r0, #8
20027b6a:	f7fc fc6f 	bl	2002444c <HAL_PIN_Set>
20027b6e:	4623      	mov	r3, r4
20027b70:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027b74:	f44f 7185 	mov.w	r1, #266	@ 0x10a
20027b78:	200d      	movs	r0, #13
20027b7a:	f7fc fc67 	bl	2002444c <HAL_PIN_Set>
20027b7e:	2500      	movs	r5, #0
20027b80:	2400      	movs	r4, #0
20027b82:	2201      	movs	r2, #1
20027b84:	3401      	adds	r4, #1
20027b86:	4611      	mov	r1, r2
20027b88:	4620      	mov	r0, r4
20027b8a:	f7fc fc8f 	bl	200244ac <HAL_PIN_Set_DS0>
20027b8e:	2200      	movs	r2, #0
20027b90:	2101      	movs	r1, #1
20027b92:	4620      	mov	r0, r4
20027b94:	f7fc fca0 	bl	200244d8 <HAL_PIN_Set_DS1>
20027b98:	2c0d      	cmp	r4, #13
20027b9a:	d1f2      	bne.n	20027b82 <bsp_psram1_pinmux_init+0xe6>
20027b9c:	4628      	mov	r0, r5
20027b9e:	bd38      	pop	{r3, r4, r5, pc}
20027ba0:	2c02      	cmp	r4, #2
20027ba2:	d153      	bne.n	20027c4c <bsp_psram1_pinmux_init+0x1b0>
20027ba4:	2301      	movs	r3, #1
20027ba6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027baa:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027bae:	4620      	mov	r0, r4
20027bb0:	f7fc fc4c 	bl	2002444c <HAL_PIN_Set>
20027bb4:	2301      	movs	r3, #1
20027bb6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bba:	f240 110f 	movw	r1, #271	@ 0x10f
20027bbe:	2003      	movs	r0, #3
20027bc0:	f7fc fc44 	bl	2002444c <HAL_PIN_Set>
20027bc4:	2301      	movs	r3, #1
20027bc6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bca:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027bce:	2004      	movs	r0, #4
20027bd0:	f7fc fc3c 	bl	2002444c <HAL_PIN_Set>
20027bd4:	2301      	movs	r3, #1
20027bd6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bda:	f240 1111 	movw	r1, #273	@ 0x111
20027bde:	2005      	movs	r0, #5
20027be0:	f7fc fc34 	bl	2002444c <HAL_PIN_Set>
20027be4:	2301      	movs	r3, #1
20027be6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bea:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027bee:	2009      	movs	r0, #9
20027bf0:	f7fc fc2c 	bl	2002444c <HAL_PIN_Set>
20027bf4:	2301      	movs	r3, #1
20027bf6:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027bfa:	f240 1113 	movw	r1, #275	@ 0x113
20027bfe:	200a      	movs	r0, #10
20027c00:	f7fc fc24 	bl	2002444c <HAL_PIN_Set>
20027c04:	2301      	movs	r3, #1
20027c06:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c0a:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027c0e:	200b      	movs	r0, #11
20027c10:	f7fc fc1c 	bl	2002444c <HAL_PIN_Set>
20027c14:	2301      	movs	r3, #1
20027c16:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c1a:	f240 1115 	movw	r1, #277	@ 0x115
20027c1e:	200c      	movs	r0, #12
20027c20:	f7fc fc14 	bl	2002444c <HAL_PIN_Set>
20027c24:	2301      	movs	r3, #1
20027c26:	2200      	movs	r2, #0
20027c28:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027c2c:	2006      	movs	r0, #6
20027c2e:	f7fc fc0d 	bl	2002444c <HAL_PIN_Set>
20027c32:	2301      	movs	r3, #1
20027c34:	2200      	movs	r2, #0
20027c36:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027c3a:	2008      	movs	r0, #8
20027c3c:	f7fc fc06 	bl	2002444c <HAL_PIN_Set>
20027c40:	2301      	movs	r3, #1
20027c42:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c46:	f240 110b 	movw	r1, #267	@ 0x10b
20027c4a:	e795      	b.n	20027b78 <bsp_psram1_pinmux_init+0xdc>
20027c4c:	2c03      	cmp	r4, #3
20027c4e:	d154      	bne.n	20027cfa <bsp_psram1_pinmux_init+0x25e>
20027c50:	2301      	movs	r3, #1
20027c52:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c56:	f44f 7187 	mov.w	r1, #270	@ 0x10e
20027c5a:	2002      	movs	r0, #2
20027c5c:	f7fc fbf6 	bl	2002444c <HAL_PIN_Set>
20027c60:	2301      	movs	r3, #1
20027c62:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c66:	f240 110f 	movw	r1, #271	@ 0x10f
20027c6a:	4620      	mov	r0, r4
20027c6c:	f7fc fbee 	bl	2002444c <HAL_PIN_Set>
20027c70:	2301      	movs	r3, #1
20027c72:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c76:	f44f 7188 	mov.w	r1, #272	@ 0x110
20027c7a:	2004      	movs	r0, #4
20027c7c:	f7fc fbe6 	bl	2002444c <HAL_PIN_Set>
20027c80:	2301      	movs	r3, #1
20027c82:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c86:	f240 1111 	movw	r1, #273	@ 0x111
20027c8a:	2005      	movs	r0, #5
20027c8c:	f7fc fbde 	bl	2002444c <HAL_PIN_Set>
20027c90:	2301      	movs	r3, #1
20027c92:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027c96:	f44f 7189 	mov.w	r1, #274	@ 0x112
20027c9a:	2006      	movs	r0, #6
20027c9c:	f7fc fbd6 	bl	2002444c <HAL_PIN_Set>
20027ca0:	2301      	movs	r3, #1
20027ca2:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027ca6:	f240 1113 	movw	r1, #275	@ 0x113
20027caa:	2007      	movs	r0, #7
20027cac:	f7fc fbce 	bl	2002444c <HAL_PIN_Set>
20027cb0:	2301      	movs	r3, #1
20027cb2:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cb6:	f44f 718a 	mov.w	r1, #276	@ 0x114
20027cba:	2008      	movs	r0, #8
20027cbc:	f7fc fbc6 	bl	2002444c <HAL_PIN_Set>
20027cc0:	2301      	movs	r3, #1
20027cc2:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cc6:	f240 1115 	movw	r1, #277	@ 0x115
20027cca:	2009      	movs	r0, #9
20027ccc:	f7fc fbbe 	bl	2002444c <HAL_PIN_Set>
20027cd0:	2301      	movs	r3, #1
20027cd2:	2200      	movs	r2, #0
20027cd4:	f44f 7184 	mov.w	r1, #264	@ 0x108
20027cd8:	200d      	movs	r0, #13
20027cda:	f7fc fbb7 	bl	2002444c <HAL_PIN_Set>
20027cde:	2301      	movs	r3, #1
20027ce0:	2200      	movs	r2, #0
20027ce2:	f44f 7183 	mov.w	r1, #262	@ 0x106
20027ce6:	200c      	movs	r0, #12
20027ce8:	f7fc fbb0 	bl	2002444c <HAL_PIN_Set>
20027cec:	2301      	movs	r3, #1
20027cee:	f44f 7280 	mov.w	r2, #256	@ 0x100
20027cf2:	f240 110b 	movw	r1, #267	@ 0x10b
20027cf6:	200a      	movs	r0, #10
20027cf8:	e73f      	b.n	20027b7a <bsp_psram1_pinmux_init+0xde>
20027cfa:	f04f 35ff 	mov.w	r5, #4294967295
20027cfe:	e73f      	b.n	20027b80 <bsp_psram1_pinmux_init+0xe4>
20027d00:	2004c990 	.word	0x2004c990
20027d04:	20027ea8 	.word	0x20027ea8

Disassembly of section .l1_ret_text_HAL_EFUSE_Extract:

20027d08 <HAL_EFUSE_Extract>:
20027d08:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
20027d0c:	2800      	cmp	r0, #0
20027d0e:	d041      	beq.n	20027d94 <HAL_EFUSE_Extract+0x8c>
20027d10:	2a00      	cmp	r2, #0
20027d12:	d03f      	beq.n	20027d94 <HAL_EFUSE_Extract+0x8c>
20027d14:	18cc      	adds	r4, r1, r3
20027d16:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
20027d1a:	dc3b      	bgt.n	20027d94 <HAL_EFUSE_Extract+0x8c>
20027d1c:	2400      	movs	r4, #0
20027d1e:	46a4      	mov	ip, r4
20027d20:	094e      	lsrs	r6, r1, #5
20027d22:	1ddd      	adds	r5, r3, #7
20027d24:	f850 7026 	ldr.w	r7, [r0, r6, lsl #2]
20027d28:	f001 011f 	and.w	r1, r1, #31
20027d2c:	f3c5 05cf 	ubfx	r5, r5, #3, #16
20027d30:	42a5      	cmp	r5, r4
20027d32:	d807      	bhi.n	20027d44 <HAL_EFUSE_Extract+0x3c>
20027d34:	2400      	movs	r4, #0
20027d36:	46a6      	mov	lr, r4
20027d38:	46a4      	mov	ip, r4
20027d3a:	459c      	cmp	ip, r3
20027d3c:	d106      	bne.n	20027d4c <HAL_EFUSE_Extract+0x44>
20027d3e:	4618      	mov	r0, r3
20027d40:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
20027d44:	f802 c004 	strb.w	ip, [r2, r4]
20027d48:	3401      	adds	r4, #1
20027d4a:	e7f1      	b.n	20027d30 <HAL_EFUSE_Extract+0x28>
20027d4c:	fa27 f501 	lsr.w	r5, r7, r1
20027d50:	3101      	adds	r1, #1
20027d52:	f812 800e 	ldrb.w	r8, [r2, lr]
20027d56:	b289      	uxth	r1, r1
20027d58:	f005 0501 	and.w	r5, r5, #1
20027d5c:	2920      	cmp	r1, #32
20027d5e:	fa05 f504 	lsl.w	r5, r5, r4
20027d62:	bf08      	it	eq
20027d64:	3601      	addeq	r6, #1
20027d66:	ea45 0508 	orr.w	r5, r5, r8
20027d6a:	f104 0401 	add.w	r4, r4, #1
20027d6e:	b2a4      	uxth	r4, r4
20027d70:	f802 500e 	strb.w	r5, [r2, lr]
20027d74:	bf02      	ittt	eq
20027d76:	b2b6      	uxtheq	r6, r6
20027d78:	2100      	moveq	r1, #0
20027d7a:	f850 7026 	ldreq.w	r7, [r0, r6, lsl #2]
20027d7e:	2c08      	cmp	r4, #8
20027d80:	bf04      	itt	eq
20027d82:	f10e 0401 	addeq.w	r4, lr, #1
20027d86:	fa1f fe84 	uxtheq.w	lr, r4
20027d8a:	f10c 0c01 	add.w	ip, ip, #1
20027d8e:	bf08      	it	eq
20027d90:	2400      	moveq	r4, #0
20027d92:	e7d2      	b.n	20027d3a <HAL_EFUSE_Extract+0x32>
20027d94:	2300      	movs	r3, #0
20027d96:	e7d2      	b.n	20027d3e <HAL_EFUSE_Extract+0x36>

Disassembly of section .l1_ret_text_HAL_Set_backup:

20027d98 <HAL_Set_backup>:
20027d98:	4b01      	ldr	r3, [pc, #4]	@ (20027da0 <HAL_Set_backup+0x8>)
20027d9a:	f843 1020 	str.w	r1, [r3, r0, lsl #2]
20027d9e:	4770      	bx	lr
20027da0:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_Get_backup:

20027da4 <HAL_Get_backup>:
20027da4:	4b01      	ldr	r3, [pc, #4]	@ (20027dac <HAL_Get_backup+0x8>)
20027da6:	f853 0020 	ldr.w	r0, [r3, r0, lsl #2]
20027daa:	4770      	bx	lr
20027dac:	500cb030 	.word	0x500cb030

Disassembly of section .l1_ret_text_HAL_PMU_SET_HXT_CBANK:

20027db0 <HAL_PMU_SET_HXT_CBANK>:
20027db0:	4a02      	ldr	r2, [pc, #8]	@ (20027dbc <HAL_PMU_SET_HXT_CBANK+0xc>)
20027db2:	6ed3      	ldr	r3, [r2, #108]	@ 0x6c
20027db4:	f360 531d 	bfi	r3, r0, #20, #10
20027db8:	66d3      	str	r3, [r2, #108]	@ 0x6c
20027dba:	4770      	bx	lr
20027dbc:	500ca000 	.word	0x500ca000

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef:

20027dc0 <HAL_PMU_GetHpsysVoutRef>:
20027dc0:	4b04      	ldr	r3, [pc, #16]	@ (20027dd4 <HAL_PMU_GetHpsysVoutRef+0x14>)
20027dc2:	781a      	ldrb	r2, [r3, #0]
20027dc4:	b122      	cbz	r2, 20027dd0 <HAL_PMU_GetHpsysVoutRef+0x10>
20027dc6:	b118      	cbz	r0, 20027dd0 <HAL_PMU_GetHpsysVoutRef+0x10>
20027dc8:	78db      	ldrb	r3, [r3, #3]
20027dca:	7003      	strb	r3, [r0, #0]
20027dcc:	2000      	movs	r0, #0
20027dce:	4770      	bx	lr
20027dd0:	2001      	movs	r0, #1
20027dd2:	4770      	bx	lr
20027dd4:	2004ca5c 	.word	0x2004ca5c

Disassembly of section .l1_ret_text_HAL_PMU_GetHpsysVoutRef2:

20027dd8 <HAL_PMU_GetHpsysVoutRef2>:
20027dd8:	4b04      	ldr	r3, [pc, #16]	@ (20027dec <HAL_PMU_GetHpsysVoutRef2+0x14>)
20027dda:	781a      	ldrb	r2, [r3, #0]
20027ddc:	b122      	cbz	r2, 20027de8 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027dde:	b118      	cbz	r0, 20027de8 <HAL_PMU_GetHpsysVoutRef2+0x10>
20027de0:	7b5b      	ldrb	r3, [r3, #13]
20027de2:	7003      	strb	r3, [r0, #0]
20027de4:	2000      	movs	r0, #0
20027de6:	4770      	bx	lr
20027de8:	2001      	movs	r0, #1
20027dea:	4770      	bx	lr
20027dec:	2004ca5c 	.word	0x2004ca5c

Disassembly of section .l1_ret_text_HAL_PMU_ConfigPeriLdo:

20027df0 <HAL_PMU_ConfigPeriLdo>:
20027df0:	2810      	cmp	r0, #16
20027df2:	b510      	push	{r4, lr}
20027df4:	d823      	bhi.n	20027e3e <HAL_PMU_ConfigPeriLdo+0x4e>
20027df6:	4b13      	ldr	r3, [pc, #76]	@ (20027e44 <HAL_PMU_ConfigPeriLdo+0x54>)
20027df8:	40c3      	lsrs	r3, r0
20027dfa:	07db      	lsls	r3, r3, #31
20027dfc:	d51f      	bpl.n	20027e3e <HAL_PMU_ConfigPeriLdo+0x4e>
20027dfe:	2900      	cmp	r1, #0
20027e00:	bf0c      	ite	eq
20027e02:	2104      	moveq	r1, #4
20027e04:	2101      	movne	r1, #1
20027e06:	4081      	lsls	r1, r0
20027e08:	b158      	cbz	r0, 20027e22 <HAL_PMU_ConfigPeriLdo+0x32>
20027e0a:	2305      	movs	r3, #5
20027e0c:	fa03 f000 	lsl.w	r0, r3, r0
20027e10:	4c0d      	ldr	r4, [pc, #52]	@ (20027e48 <HAL_PMU_ConfigPeriLdo+0x58>)
20027e12:	6e23      	ldr	r3, [r4, #96]	@ 0x60
20027e14:	ea23 0300 	bic.w	r3, r3, r0
20027e18:	430b      	orrs	r3, r1
20027e1a:	6623      	str	r3, [r4, #96]	@ 0x60
20027e1c:	b952      	cbnz	r2, 20027e34 <HAL_PMU_ConfigPeriLdo+0x44>
20027e1e:	2000      	movs	r0, #0
20027e20:	bd10      	pop	{r4, pc}
20027e22:	4b0a      	ldr	r3, [pc, #40]	@ (20027e4c <HAL_PMU_ConfigPeriLdo+0x5c>)
20027e24:	781b      	ldrb	r3, [r3, #0]
20027e26:	b91b      	cbnz	r3, 20027e30 <HAL_PMU_ConfigPeriLdo+0x40>
20027e28:	207d      	movs	r0, #125	@ 0x7d
20027e2a:	f041 0170 	orr.w	r1, r1, #112	@ 0x70
20027e2e:	e7ef      	b.n	20027e10 <HAL_PMU_ConfigPeriLdo+0x20>
20027e30:	2005      	movs	r0, #5
20027e32:	e7ed      	b.n	20027e10 <HAL_PMU_ConfigPeriLdo+0x20>
20027e34:	f44f 707a 	mov.w	r0, #1000	@ 0x3e8
20027e38:	f7f9 fddb 	bl	200219f2 <HAL_Delay_us>
20027e3c:	e7ef      	b.n	20027e1e <HAL_PMU_ConfigPeriLdo+0x2e>
20027e3e:	2001      	movs	r0, #1
20027e40:	e7ee      	b.n	20027e20 <HAL_PMU_ConfigPeriLdo+0x30>
20027e42:	bf00      	nop
20027e44:	00010101 	.word	0x00010101
20027e48:	500ca000 	.word	0x500ca000
20027e4c:	2004ca5c 	.word	0x2004ca5c

Disassembly of section .l1_ret_text_BSP_HxtCbank_Config:

20027e50 <BSP_HxtCbank_Config>:
20027e50:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
20027e52:	4607      	mov	r7, r0
20027e54:	2000      	movs	r0, #0
20027e56:	f7fc fbe3 	bl	20024620 <HAL_RCC_HCPU_GetClockSrc>
20027e5a:	2100      	movs	r1, #0
20027e5c:	4604      	mov	r4, r0
20027e5e:	4608      	mov	r0, r1
20027e60:	f7fc fca4 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20027e64:	f7fc fc0e 	bl	20024684 <HAL_RCC_HCPU_GetDLL1Freq>
20027e68:	4606      	mov	r6, r0
20027e6a:	f7fc fc1d 	bl	200246a8 <HAL_RCC_HCPU_GetDLL2Freq>
20027e6e:	4605      	mov	r5, r0
20027e70:	4638      	mov	r0, r7
20027e72:	f7ff ff9d 	bl	20027db0 <HAL_PMU_SET_HXT_CBANK>
20027e76:	2000      	movs	r0, #0
20027e78:	f7f9 fdbb 	bl	200219f2 <HAL_Delay_us>
20027e7c:	2028      	movs	r0, #40	@ 0x28
20027e7e:	f7f9 fdb8 	bl	200219f2 <HAL_Delay_us>
20027e82:	f7fc fc5f 	bl	20024744 <HAL_RCC_HCPU_DisableDLL1>
20027e86:	f7fc fc65 	bl	20024754 <HAL_RCC_HCPU_DisableDLL2>
20027e8a:	4630      	mov	r0, r6
20027e8c:	f7fc fc52 	bl	20024734 <HAL_RCC_HCPU_EnableDLL1>
20027e90:	4628      	mov	r0, r5
20027e92:	f7fc fc53 	bl	2002473c <HAL_RCC_HCPU_EnableDLL2>
20027e96:	4621      	mov	r1, r4
20027e98:	2000      	movs	r0, #0
20027e9a:	f7fc fc87 	bl	200247ac <HAL_RCC_HCPU_ClockSelect>
20027e9e:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
20027ea2:	2000      	movs	r0, #0
20027ea4:	f7f9 bda5 	b.w	200219f2 <HAL_Delay_us>
