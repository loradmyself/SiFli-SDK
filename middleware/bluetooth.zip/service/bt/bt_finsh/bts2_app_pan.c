/*
 * SPDX-FileCopyrightText: 2006-2021 Lianway Corporation
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "bts2_app_inc.h"
#include "bts2_app_pan.h"
#include "bts2_task.h"
#include "rtdef.h"
#include "bf0_sibles.h"

#ifdef RT_USING_BT
    #include "bt_rt_device_urc.h"
#endif

#ifdef BT_FINSH_PAN

#define LOG_TAG         "btapp_pan"
#include "log.h"

#include "bt_prot.h"

#ifdef BT_PAN_NO_B0_NETIF
/* Default weak implementation: return -1 to keep the normal BNEP/lwIP path.
 * The hook contract (call context, buffer lifetime, parameters) is documented
 * at the declaration in bts2_app_pan.h. */
__attribute__((weak)) int bt_pan_on_raw_rx(void *buff, int len)
{
    (void)buff;
    (void)len;
    return -1;
}
#endif

static int running_flag = 0;

#ifdef CFG_GNU
#define FIFO "/data/myfifo"
static void bt_pan_wr_data(char *string)
{
    int fd;
    int nwrite;

    if (fd == -1)
    {
        if (errno == ENXIO)
        {
            printf("open error; no reading process\n");
        }
    }

    fd = open(FIFO, O_WRONLY | O_NONBLOCK, 0);

    if ((nwrite = write(fd, string, 60)) == -1)
    {
        if (errno == EAGAIN)
        {
            printf("The FIFO has not been read yet.Please try later\n");
        }
    }
    else
    {
        printf("write %s to the FIFO\n", string);
    }
}

void bt_pan_set_ip_addr(char *string)
{
    char ipaddress[60];
    snprintf(ipaddress, "ifconfig btn0 address %s up", string);
    bt_pan_wr_data(ipaddress);
}

void bt_pan_set_netmask(char *string)
{
    char netmask[60];
    snprintf(netmask, "ifconfig btn0 netmask %s", string);
    bt_pan_wr_data(netmask);
}

void bt_pan_set_gw(char *string)
{
    char gw[60];
    snprintf(gw, "route add default gw %s", string);
    bt_pan_wr_data(gw);
}

void bt_pan_set_dns1(char *string)
{
    char gw[60];
    snprintf(gw, "setprop net.dns1 %s", string);
    bt_pan_wr_data(gw);
}

void bt_pan_set_dns2(char *string)
{
    char gw[60];
    snprintf(gw, "setprop net.dns2 %s", string);
    bt_pan_wr_data(gw);
}

void bt_pan_scan_proc_net_dev(void)
{
    FILE *proc_net_f;
    char linebuf[512];
    int linenum;
    unsigned char *p;
    char name[512]; /* XXX - pick a size */
    char *q, *saveq;

    proc_net_f = fopen("/proc/net/dev", "r");
    if (proc_net_f == NULL)
        return (0);

    for (linenum = 1; fgets(linebuf, sizeof linebuf, proc_net_f) != NULL; linenum++)
    {
        /*
         * Skip the first two lines - they're headers.
         */
        if (linenum <= 2)
            continue;

        p = &linebuf[0];

        /*
         * Skip leading white space.
         */
        while (*p != '\0' && isspace(*p))
            p++;
        if (*p == '\0' || *p == '\n')
            continue;   /* blank line */

        /*
         * Get the interface name.
         */
        q = &name[0];
        while (*p != '\0' && !isspace(*p))
        {
            if (*p == ':')
            {
                /*
                 * This could be the separator between a
                 * name and an alias number, or it could be
                 * the separator between a name with no
                 * alias number and the next field.
                 *
                 * If there's a colon after digits, it
                 * separates the name and the alias number,
                 * otherwise it separates the name and the
                 * next field.
                 */
                saveq = q;
                while (isdigit(*p))
                    *q++ = *p++;
                if (*p != ':')
                {
                    /*
                     * That was the next field,
                     * not the alias number.
                     */
                    q = saveq;
                }
                break;
            }
            else
                *q++ = *p++;
        }
        *q = '\0';

        /*
         * Get the flags for this interface, and skip it if
         * it's not up.
         */

        //strncpy(ifrflags.ifr_name, name, sizeof(ifrflags.ifr_name));
        USER_TRACE("Interface name:%s\n", name);
    }

    (void)fclose(proc_net_f);
}

void bt_pan_set_nap_route(char *string)
{
    char nap_route[60];
    bt_pan_wr_data("sh /data/iptables-open.sh");
    bt_pan_wr_data("sh /data/firwall.sh");
    snprintf(nap_route, "iptables -t nat -A POSTROUTING -o %s -s 192.168.1.0/24 -j SNAT --to 192.168.0.171", string);
    bt_pan_wr_data(nap_route);
}
#endif

static int bt_pan_notify_connection_state(bt_notify_profile_state_info_t *info, uint16_t event_id)
{
#ifdef BT_PAN_NO_B0_NETIF
    /* Raw RX mode: do not create lwIP netif "b0". Frames received over
     * PAN/BNEP are handed to bt_pan_on_raw_rx() instead, so
     * bnep_connect_event_handle() (which allocates bnep_dev[] and
     * registers netif "b0") is skipped. */
#else
    /* Normal PAN mode: register b0 netif + lwIP (e.g. headset running iperf). */
    bnep_connect_event_handle(info, event_id);
#endif
    bt_profile_update_connection_state(BT_NOTIFY_PAN, event_id, info);
    return 0;
}

static U8 bt_pan_get_idx(bts2_app_stru *bts2_app_data)
{
    U8 i = 0xff;
    bts2_pan_inst_data *ptr = NULL;
    ptr = bts2_app_data->pan_inst_ptr;

    for (i = 0; i < PAN_MAX_NUM; i++)
    {
        if (bd_is_empty(&(ptr->pan_info_list[i].bd_addr)))
        {
            return i;
        }
    }
    return i;
}

static U8 bt_pan_get_idx_by_bd(bts2_app_stru *bts2_app_data, const BTS2S_BD_ADDR *bd)
{
    U8 i = 0xff;
    bts2_pan_inst_data *ptr = NULL;
    ptr = bts2_app_data->pan_inst_ptr;

    for (i = 0; i < PAN_MAX_NUM; i++)
    {
        if (bd_eq(&(ptr->pan_info_list[i].bd_addr), bd))
        {
            return i;
        }
    }
    return i;
}

static U8 bt_pan_get_idx_by_id(bts2_app_stru *bts2_app_data, uint16_t id)
{
    U8 i = 0xff;
    bts2_pan_inst_data *ptr = NULL;
    ptr = bts2_app_data->pan_inst_ptr;

    for (i = 0; i < PAN_MAX_NUM; i++)
    {
        if (ptr->pan_info_list[i].id == id)
        {
            return i;
        }
    }
    return i;
}

static bts2_pan_info_t *bt_pan_get_device_by_bd(BTS2S_BD_ADDR *bd)
{
    bts2_pan_inst_data *ptr = NULL;
    ptr = getApp()->pan_inst_ptr;

    for (U8 i = 0; i < PAN_MAX_NUM; i++)
    {
        if (bd_eq(&(ptr->pan_info_list[i].bd_addr), bd))
        {
            return &ptr->pan_info_list[i];
        }
    }
    return NULL;
}

static bts2_pan_info_t *bt_pan_app_alloc_device()
{
    bts2_pan_inst_data *ptr = getApp()->pan_inst_ptr;

    for (U8 i = 0; i < PAN_MAX_NUM; i++)
    {
        if (!ptr->pan_info_list[i].is_use)
        {
            ptr->pan_info_list[i].is_use = 1;
            return &ptr->pan_info_list[i];
        }
    }
    return NULL;
}

static void bt_pan_app_dealloc_device(bts2_pan_info_t *device)
{
    if (device)
    {
        bmemset(device, 0x00, sizeof(bts2_pan_info_t));
        device->is_use = 0;
        device->id = 0xffff;
        device->mode = ACT_MODE;
        device->rmt_role = PAN_NO_ROLE;
        device->local_role = PAN_NO_ROLE;
    }
}

void bt_pan_init(bts2_app_stru *bts2_app_data)
{
    U8 i;
    bts2_app_data->pan_inst_ptr = &bts2_app_data->pan_inst;

    bts2_app_data->pan_inst.pan_st = PAN_REG_ST;
    bts2_app_data->pan_inst.local_role = PAN_NO_ROLE;

    for (i = 0; i < PAN_MAX_NUM; i++)
    {
        bmemset(&bts2_app_data->pan_inst.pan_info_list[i], 0x00, sizeof(bts2_pan_info_t));
        bd_set_empty(&(bts2_app_data->pan_inst.pan_info_list[i].bd_addr));
        bts2_app_data->pan_inst.pan_info_list[i].gn_sdp_pending = FALSE;
        bts2_app_data->pan_inst.pan_info_list[i].gn_sdp_fail = FALSE;
        bts2_app_data->pan_inst.pan_info_list[i].nap_sdp_pending = FALSE;
        bts2_app_data->pan_inst.pan_info_list[i].nap_sdp_fail = FALSE;
        bts2_app_data->pan_inst.pan_info_list[i].rmt_role = PAN_NO_ROLE;
        bts2_app_data->pan_inst.pan_info_list[i].mode = ACT_MODE;
        bts2_app_data->pan_inst.pan_info_list[i].id = 0xffff;
    }
}

void bt_pan_reg(bts2_app_stru *bts2_app_data)
{
    bts2_pan_inst_data *ptr = NULL;
    ptr = bts2_app_data->pan_inst_ptr;

    if (ptr->pan_st == PAN_REG_ST)
    {
        /*
        void pan_reg_req(U16 the_conn_phdl, U16 the_data_phdl);
        */
        bd_addr_t addr;
        BTS2S_BD_ADDR bd_addr;
        ble_get_public_address(&addr);
        bt_addr_convert_to_bts((bd_addr_t *)&addr, &bd_addr);
        bt_pan_update_addr(&bd_addr);
        pan_reg_req(bts2_task_get_app_task_id(), bts2_task_get_pan_task_id(), bd_addr);
        ptr->pan_st = PAN_IDLE_ST;
        bt_pan_enable(bts2_app_data);
        USER_TRACE(">> PAN register successful\n");
    }
    else
    {
        USER_TRACE(">> PAN register fail\n");
    }
}

void bt_pan_enable(bts2_app_stru *bts2_app_data)
{
    bts2_pan_inst_data *ptr = NULL;
    ptr = bts2_app_data->pan_inst_ptr;

    if (ptr->pan_st == PAN_IDLE_ST)
    {
        /*
        void pan_enb_req(BOOL the_single_user, U16  the_local_role, U16  the_rmt_role);
        */
#ifdef BT_PAN_DUAL_ROLE
        pan_enb_req(FALSE, PAN_PANU_ROLE | PAN_NAP_ROLE,
                    PAN_NAP_ROLE | PAN_PANU_ROLE);
#else
        pan_enb_req(FALSE, PAN_PANU_ROLE, PAN_NAP_ROLE);
#endif
        ptr->pan_st = PAN_IDLE_ST;
        // bt_lwip_pan_attach_tcpip();
        USER_TRACE(">> PAN enable\n");
    }
    else
    {
        USER_TRACE(">> PAN enable fail\n");
    }
}

extern bts2_app_stru *bts2g_app_p;
int bt_pan_connect_request(BTS2S_BD_ADDR *remote_addr)
{
    bts2_app_stru *bts2_app_data = bts2g_app_p;
    bts2_pan_inst_data *ptr = NULL;
    U8 idx, idx2;

    int ret = 1;

    ptr = bts2_app_data->pan_inst_ptr;

    USER_TRACE(" pan st %x\n", ptr->pan_st);

    if (ptr->pan_st == PAN_IDLE_ST)
    {
        /*Before send connection,send service search requst*/
        //modified for product type
        bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(remote_addr);
        if (device_info)
        {
            if (device_info->gn_sdp_pending == TRUE)
            {
                USER_TRACE("SDP is in progress,connect pan later\n");
            }
            else
            {
                device_info->gn_sdp_pending = TRUE;
                device_info->state = PAN_DEV_CONNECTING_ST;
                pan_svc_srch_req(bts2_task_get_app_task_id(), remote_addr, PAN_NAP_ROLE);
                USER_TRACE(">> PAN connect\n");
                ret = 0;
            }
        }
        else
        {
            device_info = bt_pan_app_alloc_device();

            if (device_info)
            {
                bd_copy(&(device_info->bd_addr), remote_addr);
                device_info->gn_sdp_pending = TRUE;
                device_info->is_use = 1;
                device_info->state = PAN_DEV_CONNECTING_ST;
                pan_svc_srch_req(bts2_task_get_app_task_id(), remote_addr, PAN_NAP_ROLE);
                ret = 0;
                USER_TRACE(">> PAN connect\n");
            }
            else
            {
                USER_TRACE("No pan resources are available\n");
            }
        }
    }
    else
    {
        if (ptr->pan_st == PAN_BUSY_ST)
        {
            USER_TRACE(">> PAN already connected\n");
        }
        else
        {
            USER_TRACE(">> PAN connect fail\n");
        }
    }
    return ret;
}

int bt_pan_connect_request_ext(BTS2S_BD_ADDR *remote_addr, U16 role)
{
    bts2_app_stru *bts2_app_data = bts2g_app_p;
    bts2_pan_inst_data *ptr = NULL;
    U8 idx, idx2;

    int ret = 1;

    ptr = bts2_app_data->pan_inst_ptr;

    USER_TRACE(" pan st %x\n", ptr->pan_st);

    if (ptr->pan_st == PAN_IDLE_ST)
    {
        /*Before send connection,send service search requst*/
        //modified for product type
        bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(remote_addr);
        if (device_info)
        {
            if (device_info->gn_sdp_pending == TRUE)
            {
                USER_TRACE("SDP is in progress,connect pan later\n");
            }
            else
            {
                device_info->gn_sdp_pending = TRUE;
                device_info->state = PAN_DEV_CONNECTING_ST;
                pan_svc_srch_req(bts2_task_get_app_task_id(), remote_addr, role);
                USER_TRACE(">> PAN connect\n");
                ret = 0;
            }
        }
        else
        {
            device_info = bt_pan_app_alloc_device();

            if (device_info)
            {
                bd_copy(&(device_info->bd_addr), remote_addr);
                device_info->gn_sdp_pending = TRUE;
                device_info->is_use = 1;
                device_info->state = PAN_DEV_CONNECTING_ST;
                pan_svc_srch_req(bts2_task_get_app_task_id(), remote_addr, role);
                ret = 0;
                USER_TRACE(">> PAN connect\n");
            }
            else
            {
                USER_TRACE("No pan resources are available\n");
            }
        }
    }
    else
    {
        if (ptr->pan_st == PAN_BUSY_ST)
        {
            USER_TRACE(">> PAN already connected\n");
        }
        else
        {
            USER_TRACE(">> PAN connect fail\n");
        }
    }
    return ret;
}

extern BTS2S_ETHER_ADDR bd2etheraddr(const BTS2S_BD_ADDR *bd);

void bt_pan_update_addr(BTS2S_BD_ADDR *bd_addr)
{
    bts2_local_ether_addr =  bd2etheraddr(bd_addr);
    return;
}

void bt_pan_disc(BTS2S_BD_ADDR *bd)
{
    bts2_app_stru *bts2_app_data = getApp();
    bts2_pan_inst_data *ptr = NULL;
    uint8_t idx = bt_pan_get_idx_by_bd(bts2_app_data, bd);
    ptr = bts2_app_data->pan_inst_ptr;

    if (idx == 0xff)
    {
        USER_TRACE(">> PAN disconnect fail, device not found\n");
        return;
    }

    if (ptr->pan_info_list[idx].state == PAN_DEV_CONNECTED_ST)
    {
        /*
        void pan_disc_req (U16 the_id);
        void pan_disc_res (U16 the_id);
        */
        pan_disc_req(ptr->pan_info_list[idx].id);
        USER_TRACE(">> PAN disconnect\n");
    }
    else
    {
        USER_TRACE(">> PAN disconnect fail");
    }
}

void bt_pan_send_data(uint16_t bnep_id, void *buff, int len)
{
    bts2_pan_inst_data *ptr = NULL;
    void  *p;
    U8   *eth_header;
    ptr = getApp()->pan_inst_ptr;
    uint8_t idx = bt_pan_get_idx_by_id(getApp(), bnep_id);

    if ((idx != 0xff) && (ptr->pan_info_list[idx].state == PAN_DEV_CONNECTED_ST))
    {
        if (ptr->pan_info_list[idx].mode == SNIFF_MODE)
            bt_exit_sniff_mode(&ptr->pan_info_list[idx].bd_addr);

        BTS2S_PAN_DATA_REQ *msg;
        msg = (BTS2S_PAN_DATA_REQ *)bmalloc(sizeof(BTS2S_PAN_DATA_REQ));
        BT_OOM_ASSERT(msg);
        if (msg)
        {
            msg->type = BTS2MD_PAN_DATA_REQ;
            eth_header = buff;
            msg->ether_type = (eth_header[12] << 8) + eth_header[13];
            msg->len = len - 14;
            buff = eth_header + 14;
            msg->id = bnep_id;

            //msg->dst_addr = bt_pan_get_remote_mac_address(bt_dev);
            msg->dst_addr.w[0] = (((U16)eth_header[0]) << 8) | (U16)eth_header[1];
            msg->dst_addr.w[1] = (((U16)eth_header[2]) << 8) | (U16)eth_header[3];
            msg->dst_addr.w[2] = (((U16)eth_header[4]) << 8) | (U16)eth_header[5];
            msg->src_addr = bt_pan_get_mac_address();
            p = bmalloc(msg->len);
            BT_OOM_ASSERT(p);
            if (p == NULL)
            {
                bfree(msg);
                return;
            }
            memcpy(p, buff, msg->len);
            msg->payload = p;
            bts2_msg_put(bts2_task_get_pan_task_id(), BTS2M_PAN, msg);
            //USER_TRACE("bt_pan_send_data\n");
        }
    }
    else
    {
        USER_TRACE(">> PAN data send fail\n");
    }
}


void bt_hdl_pan_msg(bts2_app_stru *bts2_app_data)
{

    U16 *msg_type = NULL;
    bts2_pan_inst_data *ptr;

    ptr = bts2_app_data->pan_inst_ptr;
    msg_type = (U16 *)bts2_app_data->recv_msg;

    switch (*msg_type)
    {
    case BTS2MU_PAN_ENB_CFM:
    {
        BTS2S_PAN_ENB_CFM *msg;

        msg = (BTS2S_PAN_ENB_CFM *)bts2_app_data->recv_msg;
        if (msg->res == BTS2_FAILED)
        {

            ptr->pan_st = PAN_IDLE_ST;
            USER_TRACE(">> Enable PAN fail\n");
        }

        USER_TRACE(">> PAN enable success\n");
        break;
    }
    case BTS2MU_PAN_CONN_IND:
    {
        BTS2S_PAN_CONN_IND *msg;
#ifdef CFG_GNU
        BOOL init_ret;
#endif
        BTS2S_BD_ADDR local_bd;
        BTS2S_ETHER_ADDR local_eth;

        local_bd.lap = bts2_app_data->local_bd.lap;
        local_bd.nap = bts2_app_data->local_bd.nap;
        local_bd.uap = bts2_app_data->local_bd.uap;

        local_eth = bconvbd2etherbig(&local_bd);

        msg = (BTS2S_PAN_CONN_IND *)bts2_app_data->recv_msg;

        USER_TRACE("<< PAN local device addreess: %04X:%02X:%06lX, result=%d\n id:%d",
                   bts2_app_data->local_bd.nap,
                   bts2_app_data->local_bd.uap,
                   bts2_app_data->local_bd.lap,
                   msg->res, msg->id);

        bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(&msg->bd_addr);
        if (msg->res == BTS2_SUCC)
        {
            if (!device_info)
            {
                device_info = bt_pan_app_alloc_device();
                if (!device_info)
                {
                    pan_disc_req(msg->id);
                    break;
                }
            }

            device_info->id = msg->id;
            device_info->bd_addr = msg->bd_addr;
            device_info->local_role = msg->local_role;
            device_info->rmt_role = msg->rmt_role;
            device_info->state = PAN_DEV_CONNECTED_ST;

#ifdef CFG_BNEP_DBG
            INFO_TRACE(">> Remote device bd_addr: %04X:%02X:%06X\n", msg->bd_addr.nap, msg->bd_addr.uap, msg->bd_addr.lap);
            INFO_TRACE("\n>> enable finish,now regeist a network card\n");
#endif

            bt_notify_profile_state_info_t profile_state;
            bt_addr_convert(&msg->bd_addr, profile_state.mac.addr);
            profile_state.profile_type = BT_NOTIFY_PAN;
            profile_state.res = BTS2_SUCC;
            profile_state.profile_role = msg->local_role;
            profile_state.profile_channel = msg->id;
            bt_pan_notify_connection_state(&profile_state, BT_NOTIFY_PAN_PROFILE_CONNECTED);
#ifdef CFG_GNU
            if (0 == running_flag)
            {
                init_ret = Inter_Init((U8 *)(&local_eth));
            }

            if (1 == init_ret)
            {
                INFO_TRACE("init netcard successful\n");
            }

            running_flag ++ ;
#endif
            INFO_TRACE(">> PAN connect successfully, running_flag = %d\n", running_flag);
        }
        else
        {
            if (device_info)
            {
                bt_pan_app_dealloc_device(device_info);
            }

            bt_notify_profile_state_info_t profile_state;
            bt_addr_convert(&msg->bd_addr, profile_state.mac.addr);
            profile_state.profile_type = BT_NOTIFY_PAN;
            profile_state.res = msg->res;
            profile_state.profile_role = ptr->local_role;
            profile_state.profile_channel = msg->id;
            bt_pan_notify_connection_state(&profile_state, BT_NOTIFY_PAN_PROFILE_DISCONNECTED);

        }
        USER_TRACE("BTS2MU_PAN_CONN_IND\n");

#ifdef CFG_BQB
#ifdef TP_BNEP_BV_20_C
        struct rt_bnep_device_t *bt_dev;
        U8 buff[50];
        int len = 50;
        bt_dev = &bnep_dev[0];
        bt_dev->bts2_app_data = bts2_app_data;
        bt_dev->bts2_app_data->pan_inst_ptr =  ptr;
        memset(buff, 0xbb, 50);
        buff[12] = 0x08;
        buff[13] = 0x00;//ether_type ipv4
        extern BTS2S_ETHER_ADDR   bts2_local_ether_addr;
        bts2_local_ether_addr.w[0] = 0xaaaa;
        bts2_local_ether_addr.w[1] = 0xaaaa;
        bts2_local_ether_addr.w[2] = 0xaaaa;
        bt_pan_send_data(bt_dev, buff, len);
#endif
#ifdef TP_PANU_AUTONET_BV_01_I
        struct rt_bnep_device_t *bt_dev;
        //raw data:28byte
        //header 14byte;
        U8 buff[42] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00\
                       , 0x00, 0x01, 0x08, 0x00, 0x06, 0x04, 0x00, 0x01, 0xab, 0x89, 0x56, 0x34, 0x12, 0x00\
                       , 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0xa8, 0x01, 0x1e
                      };
        int len = 42;
        bt_dev = &bnep_dev[0];
        bt_dev->bts2_app_data = bts2_app_data;
        bt_dev->bts2_app_data->pan_inst_ptr =  ptr;
        buff[12] = 0x08;
        buff[13] = 0x06;//ether_type ETHER_TYPE_ARP
        extern BTS2S_ETHER_ADDR   bts2_local_ether_addr;
        bts2_local_ether_addr.w[0] = 0xab89;
        bts2_local_ether_addr.w[1] = 0x5634;
        bts2_local_ether_addr.w[2] = 0x1200;
        bt_pan_send_data(bt_dev, buff, len);
#endif
#endif

        break;
    }
    case BTS2MU_PAN_DATA_IND:
    {
        BTS2S_PAN_DATA_IND *msg;
        msg = (BTS2S_PAN_DATA_IND *)bts2_app_data->recv_msg;
        uint8_t idx = bt_pan_get_idx_by_id(getApp(), msg->id);

        if ((idx != 0xff) && (ptr->pan_info_list[idx].mode == SNIFF_MODE))
        {
            bt_exit_sniff_mode(&ptr->pan_info_list[idx].bd_addr);
        }
#ifdef CFG_GNU
        tx_data(msg);
#endif
        //USER_TRACE(" BTS2MU_PAN_DATA_IND\n");
        msg->len = msg->len + 14;
        memcpy(msg->payload, msg->dst_addr.w, 6);
        memcpy(msg->payload + 6, msg->src_addr.w, 6);
        msg->payload[12] = (msg->ether_type >> 8);
        msg->payload[13] = (msg->ether_type & 0xff);
        if (0x86dd == msg->ether_type)
        {
            bfree(msg->payload);
            break;
        }

#ifdef BT_PAN_NO_B0_NETIF
        /* Raw RX hook: let the application consume the frame before it
         * enters the normal BNEP/lwIP path. */
        if (bt_pan_on_raw_rx(msg->payload, msg->len) == 0)
        {
            bfree(msg->payload);
            break;
        }
#endif

        bnep_dev_recv_data(msg->id, (void *)msg->payload, msg->len);
        bfree(msg->payload);
        break;
    }
    case BTS2MU_PAN_DISC_IND:
    {
        BTS2S_PAN_DISC_IND *msg;
        msg = (BTS2S_PAN_DISC_IND *)bts2_app_data->recv_msg;

        bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(&msg->bd);
        if (device_info)
        {
            bt_pan_app_dealloc_device(device_info);
        }

        bt_notify_profile_state_info_t profile_state;
        bt_addr_convert(&msg->bd, profile_state.mac.addr);
        profile_state.profile_type = BT_NOTIFY_PAN;
        profile_state.res = msg->res;
        bt_pan_notify_connection_state(&profile_state, BT_NOTIFY_PAN_PROFILE_DISCONNECTED);

        INFO_TRACE(" BTS2MU_PAN_DISC_IND\n");
        break;
    }
    case BTS2MU_PAN_STS_IND:
    {
        BTS2S_PAN_STS_IND *msg;
        msg = (BTS2S_PAN_STS_IND *)bts2_app_data->recv_msg;
        uint8_t idx = bt_pan_get_idx_by_id(getApp(), msg->id);
#ifdef CFG_BNEP_DBG
        INFO_TRACE("id=%d\n", msg->id);
        INFO_TRACE("ev=%d\n", msg->ev);
        INFO_TRACE("sts=%d\n", msg->sts);
#endif
        if ((idx != 0xff) && (msg->ev == PAN_LINK_ST_EV))
        {
            ptr->pan_info_list[idx].mode = msg->sts;
        }
        INFO_TRACE(" BTS2MU_PAN_STS_IND\n");
        break;
    }
    case BTS2MU_PAN_SVC_SRCH_CFM:
    {
        BTS2S_PAN_SVC_SRCH_CFM *msg;
        msg = (BTS2S_PAN_SVC_SRCH_CFM *)bts2_app_data->recv_msg;

        if (msg->res != BTS2_SUCC)
        {
            bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(&msg->bd_addr);
            if (device_info)
            {
                bt_pan_app_dealloc_device(device_info);

                bt_notify_profile_state_info_t profile_state;
                bt_addr_convert(&msg->bd_addr, profile_state.mac.addr);
                profile_state.profile_type = BT_NOTIFY_PAN;
                profile_state.res = msg->res;
                bt_pan_notify_connection_state(&profile_state, BT_NOTIFY_PAN_PROFILE_DISCONNECTED);
            }
            else
            {
                INFO_TRACE("error,the address is wrong\n");
            }
        }
        else
        {
            INFO_TRACE("SDP service search finish successfully\n");
        }
        break;
    }
    case BTS2MU_PAN_SVC_SRCH_RSP_IND:
    {
        /*When receive this message,indicate that the service search finish,so can send connect request now*/
        BTS2S_PAN_SVC_SRCH_RSP_IND *msg;
        msg = (BTS2S_PAN_SVC_SRCH_RSP_IND *)bts2_app_data->recv_msg;

        INFO_TRACE("BTS2MU_PAN_SVC_SRCH_RSP_IND bd: %04X:%02X:%06X\n", msg->bd_addr.nap, msg->bd_addr.uap, msg->bd_addr.lap);
        INFO_TRACE("BTS2MU_PAN_SVC_SRCH_RSP_IND role:%x\n", msg->srch_role);

        if ((msg->srch_role == PAN_GN_ROLE) || (msg->srch_role == PAN_NAP_ROLE))
        {
            /*
            void pan_conn_req(BTS2S_BD_ADDR *the_bd_addr, U16 the_local_role, U16 the_rmt_role);
            */
            bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(&msg->bd_addr);

            if (device_info)
            {
                device_info->gn_sdp_pending = FALSE;
                pan_conn_req(&(msg->bd_addr), PAN_PANU_ROLE, msg->srch_role);
            }
            else
            {
                INFO_TRACE("error,the address is wrong\n");
            }
        }
        else if (msg->srch_role == PAN_PANU_ROLE)
        {
            /*
            void pan_conn_req(BTS2S_BD_ADDR *the_bd_addr, U16 the_local_role, U16 the_rmt_role);
            */
            bts2_pan_info_t *device_info = bt_pan_get_device_by_bd(&msg->bd_addr);

            if (device_info)
            {
                device_info->gn_sdp_pending = FALSE;
                pan_conn_req(&(msg->bd_addr), PAN_NAP_ROLE, msg->srch_role);
            }
            else
            {
                INFO_TRACE("error,the address is wrong\n");
            }
        }
        else
        {
            INFO_TRACE("BTS2MU_PAN_SVC_SRCH_RSP_IND: fail\n");
        }
        break;
    }
    default:
    {
        INFO_TRACE("Default %x\n", *msg_type);
        break;
    }
    }
}

#endif
