/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _BTS2_APP_AV_SRC_H_
#define _BTS2_APP_AV_SRC_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifdef CFG_AV_SRC
/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_init(bts2s_av_inst_data *inst, bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
int bt_a2dp_sink_connect_request(BTS2S_BD_ADDR *bd);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_disc_2_snk(void);
void bt_avsrc_close_a2dp(void);
void bt_avsrc_disc_by_addr(BTS2S_BD_ADDR *bd_addr);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_start_stream(bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_release_stream(bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_suspend_stream(bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_msg_handler(bts2_app_stru *bts2_app_data);


/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_get_cfg(bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_recfg(bts2_app_stru *bts2_app_data);

/*----------------------------------------------------------------------------*
 *
 * DESCRIPTION:
 *
 * INPUT:
 *      bts2_app_stru *bts2_app_data:
 *
 * OUTPUT:
 *      void.
 *
 * NOTE:
 *      none.
 *
 *----------------------------------------------------------------------------*/
void bt_avsrc_abort_stream(bts2_app_stru *bts2_app_data);

int bt_avsrc_get_plyback_conn(bts2s_av_inst_data *inst);

int bt_avsrc_get_stream_conn(bts2s_av_inst_data *inst);

void bt_avsrc_set_start_flag(BOOL flag);

BOOL bt_avsrc_get_start_flag(void);

/* Media forwarding diagnostics (see bts2_app_av_src.c). */
void bt_avsrc_note_qos(U16 shdl, U16 buff_st);
BOOL bt_avsrc_get_media_stats(U8 idx, U32 *req, U32 *nomem, U32 *qos, U8 *buff);

/* Shared SBC encoder lock (see bts2_app_av_src.c). */
void bt_avsrc_sbc_lock(void);
void bt_avsrc_sbc_unlock(void);

#ifdef CFG_AV_SHARING
uint16_t bt_avsrc_sharing(struct rt_ringbuffer32 *rb);
/* Media pacing on the dedicated "a2dptx" thread (see bts2_app_av_src.c):
 * sched() arms the next pump iteration (delay 0/1 = asap) instead of the
 * old bts2 send timer, cancel() stops pacing (audio close/pause/disconnect),
 * armed() reports whether the send chain is alive so the app pump can
 * re-kick it after a gate (suspend_pending etc.) dropped the chain. */
void bt_avsrc_sharing_sched(struct rt_ringbuffer32 *rb, int32_t delay_ms);
void bt_avsrc_sharing_cancel(void);
int bt_avsrc_sharing_armed(void);
#else
#define bt_avsrc_sharing_sched(rb, delay_ms) do {} while (0)
#define bt_avsrc_sharing_cancel() do {} while (0)
#define bt_avsrc_sharing_armed() 0
#endif

#else

#define bt_avsrc_init(inst,bts2_app_data)
#define bt_a2dp_sink_connect_request(bts2_app_data)
#define bt_avsrc_disc_2_snk()
#define bt_avsrc_close_a2dp()
#define bt_avsrc_disc_by_addr(BTS2S_BD_ADDR)
#define bt_avsrc_start_stream(bts2_app_data)
#define bt_avsrc_release_stream(bts2_app_data)
#define bt_avsrc_suspend_stream(bts2_app_data)
#define bt_avsrc_msg_handler(bts2_app_data)
#define bt_avsrc_get_cfg(bts2_app_data)
#define bt_avsrc_recfg(bts2_app_data)
#define bt_avsrc_abort_stream(bts2_app_data)
#define bt_avsrc_get_plyback_conn(inst) (-1)
#define bt_avsrc_get_stream_conn(inst) (-1)
#define bt_avsrc_set_start_flag(flag)
#define bt_avsrc_get_start_flag() 0
#define bt_avsrc_note_qos(shdl, buff_st)
#define bt_avsrc_get_media_stats(idx, req, nomem, qos, buff) (0)

#endif

#ifdef __cplusplus
}
#endif

#endif
