/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "bts2_global.h"
#ifdef CFG_HFP_AG

#include "bts2_app_inc.h"
#include "hfp_ag_api.h"
#include "bf0_sibles.h"

#define LOG_TAG         "btapp_ag"
#include "log.h"


#ifdef AUDIO_USING_MANAGER
    #include "hfp_audio_api.h"
#endif

#ifdef RT_USING_BT
    #include "bt_rt_device.h"
#endif

#ifndef HFP_AG_LOCAL_FEATURES
#define HFP_AG_LOCAL_FEATURES  (HFP_AG_FEAT_ECNR   | \
                                HFP_AG_FEAT_INBAND | \
                                HFP_AG_FEAT_REJECT | \
                                HFP_AG_FEAT_ECS    | \
                                HFP_AG_FEAT_EXTERR | \
                                HFP_AG_FEAT_CODEC  | \
                                HFP_AG_FEAT_ESCO)
#endif
#ifndef BT_USING_AG
uint8_t g_flag_auto_answer_call = 1;

__WEAK uint8_t bt_hfp_ag_set_auto_answer_call_default()
{
    return g_flag_auto_answer_call;
}
#endif


__WEAK uint32_t bt_hfp_ag_local_feature()
{
    return HFP_AG_LOCAL_FEATURES;
}

/****************************************remote SLC collision guard***************************************/
/* The headset often opens the HFP session ITSELF a few seconds after
 * AVDTP (measured ~3s on Anyka OWS T700). Firing our AG->HF connect into
 * that in-flight setup collides inside RFCOMM and BOTH attempts die
 * (CONN_CFM res 19) — the link then stays music-only until something
 * gives the SLC another clean window. When a remote-initiated SLC
 * (BTS2MU_AG_CONN_IND) is pending for a device, bt_hfp_ag_connect_request
 * refuses to fire and lets the remote's own SLC finish instead.
 *
 * The window only needs to cover a WORKING remote SLC (RFCOMM open ->
 * SLC resolve is ~2s), but it must expire well before the 10s link
 * supervision timeout: some headsets open the RFCOMM DLC and then never
 * speak AT at all (Redmi Buds 4 Pro stalls exactly there), and the old
 * 10s window outlived the link itself — our AG connect was suppressed
 * every time and the headset died music-only. When the window expires
 * with the SLC still unresolved, bt_hfp_ag_connect_request tears the
 * dead session down so its retry starts a fresh one. */
#define BT_HFP_AG_INCOMING_SLC_WINDOW_MS 4000U

static BTS2S_BD_ADDR g_hfp_ag_incoming_bd;
static uint32_t g_hfp_ag_incoming_tick;
static uint8_t g_hfp_ag_incoming_slc;

static uint8_t bt_hfp_ag_bd_equal(BTS2S_BD_ADDR *a, BTS2S_BD_ADDR *b)
{
    return (a->lap == b->lap) && (a->uap == b->uap) && (a->nap == b->nap);
}

static void bt_hfp_ag_incoming_slc_start(BTS2S_BD_ADDR *bd)
{
    bd_copy(&g_hfp_ag_incoming_bd, bd);
    g_hfp_ag_incoming_tick = rt_tick_get();
    g_hfp_ag_incoming_slc = 1;
}

static void bt_hfp_ag_incoming_slc_clear(BTS2S_BD_ADDR *bd)
{
    if (g_hfp_ag_incoming_slc &&
            ((bd == NULL) || bt_hfp_ag_bd_equal(&g_hfp_ag_incoming_bd, bd)))
    {
        g_hfp_ag_incoming_slc = 0;
    }
}

static uint8_t bt_hfp_ag_incoming_slc_pending(BTS2S_BD_ADDR *bd)
{
    return g_hfp_ag_incoming_slc && bt_hfp_ag_bd_equal(&g_hfp_ag_incoming_bd, bd);
}
/*******************************************************************************************************/

/*******************************************device info func start**********************************************/
static void bt_hfp_ag_app_init_device_info(bts2_hfp_ag_inst_data *ag_data)
{
    if (ag_data)
    {
        for (int i = 0; i < CFG_MAX_HFP_CONN_NUM; i++)
        {
            bmemset(&ag_data->devices_info[i], 0x00, sizeof(bts2_hfp_ag_device_info));
            ag_data->devices_info[i].call_state = HFP_CALL_IDLE;
            ag_data->devices_info[i].is_use = 1;
            ag_data->devices_info[i].mux_id = 0xff;
            ag_data->devices_info[i].pre_profile_state = HFP_DEVICE_DISCONNECTED;
            ag_data->devices_info[i].profile_state = HFP_DEVICE_DISCONNECTED;
            ag_data->devices_info[i].srv_chnl = 0xff;
        }
    }
}

static bts2_hfp_ag_device_info *bt_hfp_ag_app_get_device_by_mux_id(bts2_hfp_ag_inst_data *ag_data, U8 mux_id)
{
    if (ag_data)
    {
        for (int i = 0; i < CFG_MAX_HFP_CONN_NUM; i++)
        {
            if (ag_data->devices_info[i].mux_id == mux_id)
            {
                return &ag_data->devices_info[i];
            }
        }
    }
    return NULL;
}

static bts2_hfp_ag_device_info *bt_hfp_ag_app_alloc_device(bts2_hfp_ag_inst_data *ag_data)
{
    if (ag_data)
    {
        for (int i = 0; i < CFG_MAX_HFP_CONN_NUM; i++)
        {
            if (ag_data->devices_info[i].is_use)
            {
                ag_data->devices_info[i].is_use = 0;
                return &ag_data->devices_info[i];
            }
        }
    }
    return NULL;
}

static void bt_hfp_ag_app_dealloc_device(bts2_hfp_ag_device_info *device)
{
    if (device)
    {
        bmemset(device, 0x00, sizeof(bts2_hfp_ag_device_info));
        device->call_state = HFP_CALL_IDLE;
        device->is_use = 1;
        device->mux_id = 0xff;
        device->pre_profile_state = HFP_DEVICE_DISCONNECTED;
        device->profile_state = HFP_DEVICE_DISCONNECTED;
        device->srv_chnl = 0xff;
    }
}

static bts2_hfp_ag_device_info *bt_hfp_ag_app_get_busy_device(bts2_hfp_ag_inst_data *ag_data)
{
    if (ag_data)
    {
        for (int i = 0; i < CFG_MAX_HFP_CONN_NUM; i++)
        {
            if (ag_data->devices_info[i].is_use == 0)
            {
                return &ag_data->devices_info[i];
            }
        }
    }
    return NULL;
}

/*******************************************device info func end************************************************/
/*******************************************add for ag func test start**********************************/
static hfp_phone_call_info_t g_remote_calls_info ;
hfp_cind_status_t g_cind_states;

void bt_hfp_ag_app_call_status_change(U8 mux_id, char *phone_num, uint8_t phone_len, uint8_t active, uint8_t callsetup_state, uint8_t call_dir)
{
    phone_call_status_t call_status;

    if (0 == active && 0 == callsetup_state)
    {
        call_status = 0xff;
    }

    if (1 == active && 0 == callsetup_state)
    {
        call_status = PHONE_CALL_ACTIVE;
    }

    if (1 == callsetup_state)
    {
        call_status = PHONE_CALL_INCOMING;

    }
    else if (2 == callsetup_state)
    {
        call_status = PHONE_CALL_DAILING;
    }
    else if (3 == callsetup_state)
    {
        call_status = PHONE_CALL_ALERTING;
    }

    g_cind_states.call = active;
    g_cind_states.callsetup = callsetup_state;

    if (0xff == call_status)
    {
        bmemset(&g_remote_calls_info, 0x00, sizeof(hfp_phone_call_info_t));
    }
    else
    {
        if (g_remote_calls_info.call_idx == 0x00)
        {
            g_remote_calls_info.phone_info.type = PHONE_NUMBER_TYPE_UNKNOWN;
            bmemcpy(&g_remote_calls_info.phone_info.phone_number, phone_num, phone_len);
        }

        g_remote_calls_info.call_idx = 1;
        g_remote_calls_info.call_dir = call_dir;
        g_remote_calls_info.call_status = call_status;
        g_remote_calls_info.call_mode = 0;
        g_remote_calls_info.call_mtpty = 0;
    }

    HFP_CALL_INFO_T call_info;
    call_info.num_active = active;
    call_info.num_held = 0;
    call_info.callsetup_state = callsetup_state;
    bmemcpy(&call_info.phone_number, phone_num, phone_len);
    call_info.phone_type = 0x81;
    call_info.phone_len = phone_len;
    bt_hfp_ag_call_state_update_listener(mux_id, &call_info);
}

void bt_hfp_ag_app_cind_status_change(uint8_t type, uint8_t val)
{
    switch (type)
    {
    case HFP_AG_CIND_SERVICE_TYPE:
    {
        g_cind_states.service_status = val;
        break;
    }
    case HFP_AG_CIND_CALL_TYPE:
    {
        g_cind_states.call = val;
        break;
    }
    case HFP_AG_CIND_CALLSETUP_TYPE:
    {
        g_cind_states.callsetup = val;
        break;
    }
    case HFP_AG_CIND_BATT_TYPE:
    {
        g_cind_states.batt_level = val;
        break;
    }
    case HFP_AG_CIND_SIGNAL_TYPE:
    {
        g_cind_states.signal = val;
        break;
    }
    case HFP_AG_CIND_ROAM_TYPE:
    {
        g_cind_states.roam_status = val;
        break;
    }
    case HFP_AG_CIND_CALLHELD_TYPE:
    {
        g_cind_states.callheld = val;
        break;
    }
    }
}

hfp_phone_call_info_t *bt_hfp_ag_app_get_remote_call_info()
{
    return &g_remote_calls_info;
}
/*******************************************add for ag func test end**********************************/

/*******************************************static func**********************************************/
static void bt_hfp_ag_app_profile_service_update(bts2_hfp_ag_inst_data *ag_data, bts2_ag_st new_state)
{
    ag_data->old_st = ag_data->st;
    ag_data->st = new_state;
    USER_TRACE("hfp ag profile service new_date:%d, old_state:%d", ag_data->st, ag_data->old_st);
    //to update
}

static void bt_hfp_ag_reg_res_hdl(bts2_app_stru *bts2_app_data)
{
    BTS2S_AG_CFM *msg;
    msg = (BTS2S_AG_CFM *)bts2_app_data->recv_msg;
    switch (msg->res)
    {
    case HFP_AG_SUCC:
    {
        bt_hfp_ag_app_profile_service_update(&bts2_app_data->hfp_ag_inst, HFP_AG_APP_OPEN);
        break;
    }
    case HFP_AG_BUSYING:
    {
        //notify waiting
        break;
    }
    default:
    {
        bts2_hfp_ag_inst_data *ag_data = &bts2_app_data->hfp_ag_inst;
        bt_hfp_ag_app_profile_service_update(ag_data, ag_data->old_st);
        break;
    }
    }

}

static void bt_hfp_ag_dereg_res_hdl(bts2_app_stru *bts2_app_data)
{
    BTS2S_AG_CFM *msg;
    msg = (BTS2S_AG_CFM *)bts2_app_data->recv_msg;
    switch (msg->res)
    {
    case HFP_AG_SUCC:
    {
        bt_hfp_ag_app_profile_service_update(&bts2_app_data->hfp_ag_inst, HFP_AG_APP_INIT);
        break;
    }
    case HFP_AG_BUSYING:
    {
        //notify waiting
        break;
    }
    default:
    {
        bts2_hfp_ag_inst_data *ag_data = &bts2_app_data->hfp_ag_inst;
        bt_hfp_ag_app_profile_service_update(ag_data, ag_data->old_st);
        break;
    }
    }
}

static void bt_hfp_ag_app_device_state_changed(bts2_app_stru *bts2_app_data, BTS2S_AG_CONN_RES *con_msg)
{
    bts2_hfp_ag_inst_data *p_data = &bts2_app_data->hfp_ag_inst;

    USER_TRACE("hfp_ag device state: %d res: %d type %d mux_id:%d", con_msg->device_state, con_msg->res, con_msg->type, con_msg->mux_id);

    if ((con_msg->device_state == HFP_DEVICE_CONNECTED) ||
            (con_msg->device_state == HFP_DEVICE_DISCONNECTED))
    {
        /* Whatever direction opened the session, it has now resolved —
         * our own outbound connect is free to fire again. */
        bt_hfp_ag_incoming_slc_clear(&con_msg->bd);
    }

    switch (p_data->st)
    {
    case HFP_AG_APP_INIT:
    case HFP_AG_APP_OPENING:
    case HFP_AG_APP_OPEN:
    {
        bts2_hfp_ag_device_info *device_info = bt_hfp_ag_app_get_device_by_mux_id(p_data, con_msg->mux_id);
        if (device_info == NULL)
        {
            device_info = bt_hfp_ag_app_alloc_device(p_data);
            if (device_info)
            {
                device_info->mux_id = con_msg->mux_id;
                device_info->ag_bd = con_msg->bd;
            }
        }

        if (device_info)
        {
            device_info->pre_profile_state = device_info->profile_state;
            device_info->profile_state = con_msg->device_state;
            if (device_info->profile_state == device_info->pre_profile_state)
            {
                return;
            }
        }

        if (con_msg->device_state == HFP_DEVICE_CONNECTED)
        {
            bt_notify_profile_state_info_t profile_state;
            bt_addr_convert(&con_msg->bd, profile_state.mac.addr);
            profile_state.profile_type = BT_NOTIFY_HFP_AG;
            profile_state.res = BTS2_SUCC;
            profile_state.profile_channel = con_msg->mux_id;
            bt_profile_update_connection_state(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_PROFILE_CONNECTED, &profile_state);
#ifndef BT_USING_AG
            if (bt_hfp_ag_set_auto_answer_call_default())
            {
                hfp_phone_call_info_t *call_info = bt_hfp_ag_app_get_remote_call_info();

                if (g_cind_states.call || g_cind_states.callsetup)
                {
                    bt_hfp_ag_app_call_status_change(con_msg->mux_id, (char *)&call_info->phone_info.phone_number, strlen(call_info->phone_info.phone_number) + 1,
                                                     g_cind_states.call, g_cind_states.callsetup, call_info->call_dir);
                }
            }
#endif
        }
        else if (con_msg->device_state == HFP_DEVICE_DISCONNECTED)
        {
            bt_notify_profile_state_info_t profile_state;
            bt_addr_convert(&con_msg->bd, profile_state.mac.addr);
            profile_state.profile_type = BT_NOTIFY_HFP_AG;
            profile_state.res = con_msg->res;
            profile_state.profile_channel = con_msg->mux_id;
            bt_profile_update_connection_state(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_PROFILE_DISCONNECTED, &profile_state);

            if (device_info)
            {
                bt_hfp_ag_app_dealloc_device(device_info);
            }

#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
            BTS2S_HF_AUDIO_INFO msg;
            hfp_ag_audio_opt(&msg, 0);
#endif // AUDIO_USING_MANAGER
        }
        else if (con_msg->res != HFP_AG_SUCC)
        {
            /* A connect attempt resolved with an error (e.g. res 19 when
             * our AG->HF request collides with the remote's own in-flight
             * SLC). Only CONNECTED/DISCONNECTED were reported before, so
             * the app sat blind until its next blind retry. Report the
             * failure as a CONNECTED event carrying the error so the app
             * can back off briefly and retry into a clean window. */
            bt_notify_profile_state_info_t profile_state;
            bt_addr_convert(&con_msg->bd, profile_state.mac.addr);
            profile_state.profile_type = BT_NOTIFY_HFP_AG;
            profile_state.res = con_msg->res;
            profile_state.profile_channel = con_msg->mux_id;
            bt_profile_update_connection_state(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_PROFILE_CONNECTED, &profile_state);
        }

        break;
    }
    case HFP_AG_APP_CLOSING:
    {
        if (con_msg->device_state == HFP_DEVICE_DISCONNECTED)
        {
            bts2_hfp_ag_device_info *device_info = bt_hfp_ag_app_get_device_by_mux_id(p_data, con_msg->mux_id);
            if (device_info)
            {
                bt_hfp_ag_app_dealloc_device(device_info);
                device_info = NULL;
            }

            device_info = bt_hfp_ag_app_get_busy_device(p_data);
            if (device_info && (device_info->profile_state != HFP_DEVICE_DISCONNECTED))
            {
                bt_hfp_ag_disconnect_request(&device_info->ag_bd);
            }
            hfp_ag_deregister();
        }
        break;
    }
    default:
    {
        break;
    }
    }
}

//static void bt_hfp_ag_app_onAudioStateChanged(hfp_device_state_t state)

static void bt_hfp_ag_app_vr_state_changed(U8 mux_id)
{
}

static void bt_hfp_ag_app_answercall(U8 mux_id)
{
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_ANSWER_CALL_REQ, &mux_id, 1);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_phone_call_info_t *call_info = bt_hfp_ag_app_get_remote_call_info();
        bt_hfp_ag_app_call_status_change(mux_id, (char *)&call_info->phone_info.phone_number, strlen(call_info->phone_info.phone_number) + 1,
                                         1, 0, call_info->call_dir);
    }
#endif
}

static void bt_hfp_ag_app_hangupcall(U8 mux_id)
{
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_HANGUP_CALL_REQ,  &mux_id, 1);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_phone_call_info_t *call_info = bt_hfp_ag_app_get_remote_call_info();
        bt_hfp_ag_app_call_status_change(mux_id, (char *)&call_info->phone_info.phone_number, strlen(call_info->phone_info.phone_number) + 1,
                                         0, 0, call_info->call_dir);
    }
#endif

}

static void bt_hfp_ag_app_vol_changed(U8 mux_id, U16 val)
{
    bt_notify_ag_at_arg_t *data_info = (bt_notify_ag_at_arg_t *)bmalloc(sizeof(bt_notify_ag_at_arg_t) + 1);
    data_info->profile_channel = mux_id;
    data_info->payload_len = 1;
    bmemcpy(data_info->payload, &val, 1);
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_VOLUME_CHANGE, data_info, sizeof(bt_notify_ag_at_arg_t) + 1);
    bfree(data_info);
}

static void bt_hfp_ag_app_onDialCall(U8 mux_id, char *number)
{
    bt_notify_ag_at_arg_t *data_info = (bt_notify_ag_at_arg_t *)bmalloc(sizeof(bt_notify_ag_at_arg_t) + strlen(number));
    data_info->profile_channel = mux_id;
    data_info->payload_len = strlen(number);
    bmemcpy(data_info->payload, number, strlen(number));
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_MAKE_CALL_REQ, data_info, sizeof(bt_notify_ag_at_arg_t) + strlen(number));
    bfree(data_info);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_ag_at_cmd_result(mux_id, BTS2_SUCC);
        uint8_t phone_len = strlen(number);
        number[phone_len - 1] = '\0';
        bt_hfp_ag_app_call_status_change(mux_id, number, phone_len, 0, 2, PHONE_CALL_DIR_OUTGOING);
        bt_hfp_ag_app_call_status_change(mux_id, number, phone_len, 0, 3, PHONE_CALL_DIR_OUTGOING);
    }
    else
    {
        hfp_ag_at_cmd_result(mux_id, BTS2_FAILED);
    }
#endif
}

static void bt_hfp_ag_app_onSendDtmf(U8 mux_id, char *number)
{
    bt_notify_ag_at_arg_t *data_info = (bt_notify_ag_at_arg_t *)bmalloc(sizeof(bt_notify_ag_at_arg_t) + strlen(number));
    data_info->profile_channel = mux_id;
    data_info->payload_len = strlen(number);
    bmemcpy(data_info->payload, number, strlen(number));
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_RECV_DTMF_KEY, data_info, sizeof(bt_notify_ag_at_arg_t) + strlen(number));
    bfree(data_info);
}

static void bt_hfp_ag_app_onNoiseReductionEnable(U8 mux_id)
{
}

static void bt_hfp_ag_app_onWBS(U8 mux_id)
{
}

static void bt_hfp_ag_app_onAtChld(U8 mux_id)
{
}

static void bt_hfp_ag_app_onAtCnum(U8 mux_id)
{
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_GET_LOCAL_PHONE_INFO_REQ, &mux_id, 1);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_phone_number_t local_phone_num;
        char *str = "19396395979";
        bmemcpy(&local_phone_num.phone_number, str, strlen(str) + 1);
        local_phone_num.type = 0x81;
        bt_hfp_ag_cnum_response(mux_id, &local_phone_num);
    }
#endif
}

static void bt_hfp_ag_app_onAtCind(U8 mux_id)
{
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_GET_INDICATOR_STATUS_REQ, &mux_id, 1);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_cind_status_t cind_status;
        cind_status.service_status = 1;
        cind_status.call = g_cind_states.call;
        cind_status.callsetup =  g_cind_states.callsetup;
        cind_status.batt_level = 5;
        cind_status.signal = 3;
        cind_status.roam_status = 1;
        cind_status.callheld = g_cind_states.callheld;
        bt_hfp_ag_cind_response(mux_id, &cind_status);
    }
#endif
}

static void bt_hfp_ag_app_onAtCops(U8 mux_id)
{
    char *test_payload = "4G FOR TEST";
    bt_hfp_ag_cops_response(mux_id, test_payload, strlen(test_payload));
}

static void bt_hfp_ag_app_onAtClcc(U8 mux_id)
{
    bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_GET_ALL_REMT_CALLS_INFO_REQ, &mux_id, 1);
#ifndef BT_USING_AG
    if (bt_hfp_ag_set_auto_answer_call_default())
    {
        hfp_phone_call_info_t *remote_call_info = bt_hfp_ag_app_get_remote_call_info();
        if (remote_call_info->call_idx)
        {
            bt_hfp_ag_clcc_response(mux_id, remote_call_info);
        }
        hfp_ag_at_cmd_result(mux_id, BTS2_SUCC);
    }
#endif
}

static void bt_hfp_ag_app_at_cmd_hdl(BTS2S_AG_AT_CMD_INFO *at_cmd)
{
    USER_TRACE("bt_hfp_ag_app_at_cmd_hdl %d %s", at_cmd->command_id, at_cmd->str);

    switch (at_cmd->command_id)
    {
    case HFP_AG_SPK_EVT:
    case HFP_AG_MIC_EVT:
    {
        bt_hfp_ag_app_vol_changed(at_cmd->mux_id, at_cmd->val);
        break;
    }
    case HFP_AG_AT_A_EVT:
    {
        bt_hfp_ag_app_answercall(at_cmd->mux_id);
        break;
    }
    case HFP_AG_AT_D_EVT:
    {
        bt_hfp_ag_app_onDialCall(at_cmd->mux_id, at_cmd->str);
        break;
    }
    case HFP_AG_AT_CHLD_EVT:
    {
        hfp_ag_at_cmd_result(at_cmd->mux_id, BTS2_SUCC);
        break;
    }
    case HFP_AG_AT_CHUP_EVT:
    {
        bt_hfp_ag_app_hangupcall(at_cmd->mux_id);
        break;
    }
    case HFP_AG_AT_CIND_EVT:
    {
        bt_hfp_ag_app_onAtCind(at_cmd->mux_id);
        break;
    }
    case HFP_AG_AT_VTS_EVT:
    {
        bt_hfp_ag_app_onSendDtmf(at_cmd->mux_id, at_cmd->str);
        break;
    }
    case HFP_AG_AT_BLDN_EVT:
    {
        bt_hfp_ag_app_onDialCall(at_cmd->mux_id, at_cmd->str);
        break;
    }
    case HFP_AG_AT_BVRA_EVT:
    {
        hfp_ag_at_cmd_result(at_cmd->mux_id, BTS2_SUCC);
        break;
    }
    case HFP_AG_AT_NREC_EVT:
    {
        break;
    }
    case HFP_AG_AT_BTRH_EVT:
    {
        break;
    }
    case HFP_AG_AT_CLCC_EVT:
    {
        bt_hfp_ag_app_onAtClcc(at_cmd->mux_id);
        break;
    }
    case HFP_AG_AT_COPS_EVT:
    {
        bt_hfp_ag_app_onAtCops(at_cmd->mux_id);
        hfp_ag_at_cmd_result(at_cmd->mux_id, BTS2_SUCC);
        break;
    }
    case HFP_AG_AT_CNUM_EVT:
    {
        bt_hfp_ag_app_onAtCnum(at_cmd->mux_id);
        break;
    }
    case HFP_AG_AT_UNAT_EVT:
    {
        LOG_I("ag recv at cmd:%s", at_cmd->str); //handle and need send result
        bt_notify_ag_at_arg_t *data_info = (bt_notify_ag_at_arg_t *)bmalloc(sizeof(bt_notify_ag_at_arg_t) + strlen(at_cmd->str));
        data_info->profile_channel = at_cmd->mux_id;
        data_info->payload_len = strlen(at_cmd->str);
        bmemcpy(data_info->payload,  at_cmd->str, strlen(at_cmd->str));
        bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_EXTERN_AT_CMD_KEY_REQ, data_info, strlen(at_cmd->str));
        bfree(data_info);
        break;
    }
    case HFP_AG_WBS_EVT:
    {
        bt_hfp_ag_app_onWBS(at_cmd->mux_id);
        break;
    }
    case HFP_AG_BATT_EVT:
    {
        hfp_batt_vaule_t *batt = (hfp_batt_vaule_t *) at_cmd->str;
        // USER_TRACE("recv HFP_AG_BATT_EVT status:%d val :%d",batt->batt_status,batt->batt_val);
        bt_interface_bt_event_notify(BT_NOTIFY_HFP_AG, BT_NOTIFY_AG_BATTERY_UPDATE, batt, sizeof(hfp_batt_vaule_t));
        break;
    }
    }
}

/*******************************************func API **********************************/
void bt_hfp_ag_msg_hdl(bts2_app_stru *bts2_app_data)
{
    U16 *msg_type;
    bts2_hfp_ag_inst_data *inst_data;
    inst_data = &bts2_app_data->hfp_ag_inst;
    msg_type = (U16 *)bts2_app_data->recv_msg;
    USER_TRACE("hfp ag msg *msg_type %x inst_data->st %d\n", *msg_type, inst_data->st);

    switch (*msg_type)
    {
    case BTS2MU_AG_REG_CFM:
    {
        bt_hfp_ag_reg_res_hdl(bts2_app_data);
        break;
    }
    case BTS2MU_AG_UNREG_CFM:
    {
        bt_hfp_ag_dereg_res_hdl(bts2_app_data);
        break;
    }
    case BTS2MU_AG_DISC_CFM:
    {
        BTS2S_AG_CONN_RES *con_msg;
        con_msg = (BTS2S_AG_CONN_RES *)bts2_app_data->recv_msg;

        bt_hfp_ag_app_device_state_changed(bts2_app_data, con_msg);
        //USER_TRACE("BTS2MU_AG_CONN_STATE state: %d res: %d type %d", con_msg->device_state, con_msg->res, con_msg->type);
        break;
    }
    case BTS2MU_AG_CONN_IND:
    {
        BTS2S_AG_CONN_REQ *con_msg;
        con_msg = (BTS2S_AG_CONN_REQ *)bts2_app_data->recv_msg;
        /* Remote is opening the SLC itself right now — remember it so our
         * own AG->HF connect does not fire into this in-flight setup
         * (both attempts then die with res 19). Cleared when the session
         * resolves in bt_hfp_ag_app_device_state_changed(). */
        bt_hfp_ag_incoming_slc_start(&con_msg->bd);
        hfp_ag_connect_ind_res(&con_msg->bd, con_msg->rfcomm_chnl, 1);//acpt connect from remote
        // hfp_ag_connect_ind_res(&con_msg->bd, con_msg->rfcomm_chnl, 0);//reject connect from remote
        break;
    }
    case BTS2MU_AG_CONN_CFM:
    {
        BTS2S_AG_CONN_RES *con_msg;
        con_msg = (BTS2S_AG_CONN_RES *)bts2_app_data->recv_msg;
        bt_hfp_ag_app_device_state_changed(bts2_app_data, con_msg);
        USER_TRACE("BTS2MU_AG_CONN_CFM state: %d res: %d type %d", con_msg->device_state, con_msg->res, con_msg->type);
        break;
    }
    case BTS2MU_AG_DISC_IND:
    {
        BTS2S_AG_CONN_RES *con_msg;
        con_msg = (BTS2S_AG_CONN_RES *)bts2_app_data->recv_msg;
        bt_hfp_ag_app_device_state_changed(bts2_app_data, con_msg);
        USER_TRACE("BTS2MU_AG_DISC_IND state: %d res: %d type %d", con_msg->device_state, con_msg->res, con_msg->type);
        break;
    }
    case BTS2MU_AG_AUDIO_CFM:
    {
        BTS2S_AG_AUDIO_CONN_CFM *recv_msg;
        recv_msg = (BTS2S_AG_AUDIO_CONN_CFM *)bts2_app_data->recv_msg;
        break;
    }
    case BTS2MU_AG_AUDIO_CONN_CFM:
    {
        BTS2S_HF_AUDIO_INFO *msg;
        msg = (BTS2S_HF_AUDIO_INFO *)bts2_app_data->recv_msg;
        if (msg->audio_on)
        {
            USER_TRACE("<< Audio connected\n");
            bt_notify_device_sco_info_t sco_info;
            sco_info.sco_type = BT_NOTIFY_HFP_AG;
            sco_info.sco_res = BTS2_SUCC;
            sco_info.profile_channel = msg->mux_id;
            sco_info.para.type = msg->type;
            bt_addr_convert_to_general(&msg->bd, (bd_addr_t *)sco_info.para.bd.addr);
            sco_info.para.audio_on = msg->audio_on;
            sco_info.para.sco_hdl = msg->sco_hdl;
            sco_info.para.profile_type = msg->profile_type;
            sco_info.para.tx_intvl = msg->tx_intvl;
            sco_info.para.we_sco = msg->we_sco;
            sco_info.para.rx_pkt_len = msg->rx_pkt_len;
            sco_info.para.tx_pkt_len = msg->tx_pkt_len;
            sco_info.para.air_mode = msg->air_mode;

            if (inst_data->local_feature & HFP_AG_FEAT_SWB)
            {
                sco_info.para.codec_id = msg->codec_id;
            }
            else
            {
                sco_info.para.codec_id = 0xFF;
            }
            bt_interface_bt_event_notify(BT_NOTIFY_COMMON, BT_NOTIFY_COMMON_SCO_CONNECTED,
                                         &sco_info, sizeof(bt_notify_device_sco_info_t));
        }
        else
        {
            USER_TRACE("<< Audio disconnected\n");
            bt_notify_device_sco_info_t sco_info;
            sco_info.sco_type = BT_NOTIFY_HFP_AG;
            sco_info.sco_res = BTS2_SUCC;
            sco_info.profile_channel = msg->mux_id;
            sco_info.para.type = msg->type;
            bt_addr_convert_to_general(&msg->bd, (bd_addr_t *)sco_info.para.bd.addr);
            sco_info.para.audio_on = msg->audio_on;
            sco_info.para.sco_hdl = msg->sco_hdl;
            sco_info.para.profile_type = msg->profile_type;
            sco_info.para.tx_intvl = msg->tx_intvl;
            sco_info.para.we_sco = msg->we_sco;
            sco_info.para.rx_pkt_len = msg->rx_pkt_len;
            sco_info.para.tx_pkt_len = msg->tx_pkt_len;
            sco_info.para.air_mode = msg->air_mode;
            bt_interface_bt_event_notify(BT_NOTIFY_COMMON, BT_NOTIFY_COMMON_SCO_DISCONNECTED,
                                         &sco_info, sizeof(bt_notify_device_sco_info_t));
        }

#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
        hfp_ag_audio_opt(msg, msg->audio_on);
#endif // AUDIO_USING_MANAGER
        break;
    }
    case BTS2MU_AG_AUDIO_CONN_IND:
    {
        BTS2S_AG_AUDIO_CONN_IND *msg;
        msg = (BTS2S_AG_AUDIO_CONN_IND *)bts2_app_data->recv_msg;
        USER_TRACE("<< BTS2MU_AG_AUDIO_CONN_IND\n");
        if (msg->code_id == 0)
        {
            gap_sync_conn_res(&msg->bd, msg->code_id, 0);
        }
        else
        {
            gap_sync_conn_res(&msg->bd, msg->code_id, 1);
        }
        break;
    }
    case BTS2MU_AG_AUDIO_DISC_CFM:
    {
        BTS2S_HF_AUDIO_INFO *msg;
        msg = (BTS2S_HF_AUDIO_INFO *)bts2_app_data->recv_msg;
        USER_TRACE("<< BTS2MU_AG_AUDIO_DISC_CFM\n");

        bt_notify_device_sco_info_t sco_info;
        sco_info.sco_type = BT_NOTIFY_HFP_AG;
        sco_info.sco_res = BTS2_SUCC;
        sco_info.profile_channel = msg->mux_id;
        sco_info.para.type = msg->type;
        bt_addr_convert_to_general(&msg->bd, (bd_addr_t *)sco_info.para.bd.addr);
        sco_info.para.audio_on = msg->audio_on;
        sco_info.para.sco_hdl = msg->sco_hdl;
        sco_info.para.profile_type = msg->profile_type;
        sco_info.para.tx_intvl = msg->tx_intvl;
        sco_info.para.we_sco = msg->we_sco;
        sco_info.para.rx_pkt_len = msg->rx_pkt_len;
        sco_info.para.tx_pkt_len = msg->tx_pkt_len;
        sco_info.para.air_mode = msg->air_mode;
        bt_interface_bt_event_notify(BT_NOTIFY_COMMON, BT_NOTIFY_COMMON_SCO_DISCONNECTED,
                                     &sco_info, sizeof(bt_notify_device_sco_info_t));

#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
        hfp_ag_audio_opt(msg, msg->audio_on);
#endif // AUDIO_USING_MANAGER
        break;
    }
    case BTS2MU_AG_AUDIO_DISC_IND:
    {
        BTS2S_HF_AUDIO_INFO *msg;
        msg = (BTS2S_HF_AUDIO_INFO *)bts2_app_data->recv_msg;
        USER_TRACE("<< BTS2MU_AG_AUDIO_DISC_IND hdl 0x%2x\n", msg->sco_hdl);

        bt_notify_device_sco_info_t sco_info;
        sco_info.sco_type = BT_NOTIFY_HFP_AG;
        sco_info.sco_res = BTS2_SUCC;
        sco_info.profile_channel = msg->mux_id;
        sco_info.para.type = msg->type;
        bt_addr_convert_to_general(&msg->bd, (bd_addr_t *)sco_info.para.bd.addr);
        sco_info.para.audio_on = msg->audio_on;
        sco_info.para.sco_hdl = msg->sco_hdl;
        sco_info.para.profile_type = msg->profile_type;
        sco_info.para.tx_intvl = msg->tx_intvl;
        sco_info.para.we_sco = msg->we_sco;
        sco_info.para.rx_pkt_len = msg->rx_pkt_len;
        sco_info.para.tx_pkt_len = msg->tx_pkt_len;
        sco_info.para.air_mode = msg->air_mode;
        bt_interface_bt_event_notify(BT_NOTIFY_COMMON, BT_NOTIFY_COMMON_SCO_DISCONNECTED,
                                     &sco_info, sizeof(bt_notify_device_sco_info_t));

#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
        hfp_ag_audio_opt(msg, msg->audio_on);
#endif // AUDIO_USING_MANAGER
        break;
    }
    case BTS2MU_AG_SCO_RENEGOTIATE_IND:
    {
        break;
    }
    case BTS2MU_AG_SCO_RENEGOTIATE_CFM:
    {
        break;
    }
    case BTS2MU_AG_AT_CMD_EVENT:
    {
        BTS2S_AG_AT_CMD_INFO *msg;
        msg = (BTS2S_AG_AT_CMD_INFO *)bts2_app_data->recv_msg;
        bt_hfp_ag_app_at_cmd_hdl(msg);
        break;
    }
    }

}

void bt_hfp_ag_app_init(bts2_app_stru *bts2_app_data)
{
    if (bts2_app_data)
    {
        // bts2_app_data->hfp_ag_inst.srv_chnl = 0xff;
        // bts2_app_data->hfp_ag_inst.profile_state = HFP_DEVICE_DISCONNECTED;
        // bts2_app_data->hfp_ag_inst.pre_profile_state = HFP_DEVICE_DISCONNECTED;
        bts2_app_data->hfp_ag_inst.local_feature = bt_hfp_ag_local_feature();
        bt_hfp_ag_app_init_device_info(&bts2_app_data->hfp_ag_inst);
        bt_hfp_ag_app_profile_service_update(&bts2_app_data->hfp_ag_inst, HFP_AG_APP_INIT);
        bmemset(&g_remote_calls_info, 0x00, sizeof(hfp_phone_call_info_t));
#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
        hfp_ag_audio_register();
#endif // AUDIO_USING_MANAGER
    }
}

void bt_hfp_start_profile_service(bts2_app_stru *bts2_app_data)
{
    bts2_hfp_ag_inst_data *ptr;
    ptr = &bts2_app_data->hfp_ag_inst;
    switch (ptr->st)
    {
    case HFP_AG_APP_INIT:
    {
        hfp_ag_register(ptr->local_feature);
        bt_hfp_ag_app_profile_service_update(ptr, HFP_AG_APP_OPENING);
        break;
    }
    case HFP_AG_APP_OPENING:
    {
        //update to ag is in opening please wait
        break;
    }
    case HFP_AG_APP_OPEN:
    {
        //update to ag have been opened please wait
        break;
    }
    case HFP_AG_APP_CLOSING:
    {
        //update to ag is in closing please open later
        break;
    }
    }

}
void bt_hfp_stop_profile_service(bts2_app_stru *bts2_app_data)
{
    bts2_hfp_ag_inst_data *ptr;
    ptr = &bts2_app_data->hfp_ag_inst;
    switch (ptr->st)
    {
    case HFP_AG_APP_INIT:
    {
        //notify app that ag isnot opened
        break;
    }
    case HFP_AG_APP_OPENING:
    {
        //notify app that ag is in opening please close later
        break;
    }
    case HFP_AG_APP_OPEN:
    {
        bts2_hfp_ag_device_info *device_info = bt_hfp_ag_app_get_busy_device(ptr);
        if (device_info && (device_info->profile_state != HFP_DEVICE_DISCONNECTED))
        {
            bt_hfp_ag_disconnect_request(&device_info->ag_bd);
        }
        else
        {
            hfp_ag_deregister();
        }

        bt_hfp_ag_app_profile_service_update(ptr, HFP_AG_APP_CLOSING);
        break;
    }
    case HFP_AG_APP_CLOSING:
    {
        //notify APP that ag is in closing please wait
        break;
    }
    }
}

int bt_hfp_ag_connect_request(BTS2S_BD_ADDR *bd)
{
    if (bt_hfp_ag_incoming_slc_pending(bd))
    {
        if ((rt_tick_get() - g_hfp_ag_incoming_tick) <
                rt_tick_from_millisecond(BT_HFP_AG_INCOMING_SLC_WINDOW_MS))
        {
            /* The remote is opening the SLC itself — do NOT fire our AG->HF
             * connect into that in-flight setup; both attempts collide inside
             * RFCOMM and both die (res 19). Let the remote's own SLC finish;
             * if it fails, the failure notify frees the app to retry. */
            USER_TRACE(" -- hfp ag connect suppressed: remote SLC in progress\n");
            return (int)BT_ERROR_IN_PROGRESS;
        }
        /* Window expired with the remote's SLC never resolving (it opened
         * the RFCOMM DLC and then never spoke AT — Redmi Buds stalls exactly
         * there). The half-open session is a dead end: tear it down so the
         * caller's retry starts a fresh SLC instead of colliding with the
         * zombie DLC (CONN_CFM res 19). */
        g_hfp_ag_incoming_slc = 0;
        USER_TRACE(" -- hfp ag stalled remote SLC torn down; retry shortly\n");
        hfp_ag_disconnect(bd);
        return (int)BT_ERROR_TIMEOUT;
    }
    hfp_ag_connect(bd, 0);
    return 0;
}

void bt_hfp_ag_disconnect_request(BTS2S_BD_ADDR *bd)
{
    //BTS2S_BD_ADDR temp = {0xffffff, 0xff, 0xffff};
    hfp_ag_disconnect(bd);
}

void bt_hfp_connect_audio(BTS2S_BD_ADDR *bd)
{
    hfp_ag_connect_audio(bd);
}

void bt_hfp_disconnect_audio(BTS2S_BD_ADDR *bd)
{

#if defined(AUDIO_USING_MANAGER) && !defined(CFG_BT_VOICE_RELAY)
    BTS2S_HF_AUDIO_INFO msg;
    hfp_ag_audio_opt(&msg, 0);
#endif // AUDIO_USING_MANAGER
    hfp_ag_disconnect_audio(bd);
}

void bt_hfp_ag_call_state_update_listener(U8 mux_id,  HFP_CALL_INFO_T *call_info)
{
    hfp_ag_phone_call_status_changed_api(mux_id, call_info);
}

void bt_hfp_ag_remote_calls_res_hdl(U8 mux_id, hfp_remote_calls_info_t *call_info)
{
    //U8 num_call = call_info->num_call;
    if (call_info->num_call)
    {
        for (U8 i = 0; i < call_info->num_call; i++)
        {
            bt_hfp_ag_clcc_response(mux_id, &call_info->calls[i]);
        }
    }

    hfp_ag_at_cmd_result(mux_id, BTS2_SUCC);
}

/*************************************AT CMD *************************************/
void bt_hfp_ag_spk_vol_control(U8 mux_id, U8 vol)
{
    if (0 <= vol && vol <= 15)
    {
        hfp_ag_spk_volume_control(mux_id, vol);
    }
    else
    {
        USER_TRACE("AG spk ERROR VOL %d", vol);
    }
}

void bt_hfp_ag_mic_vol_control(U8 mux_id, U8 vol)
{
    if (0 <= vol && vol <= 15)
    {
        hfp_ag_mic_volume_control(mux_id, vol);
    }
    else
    {
        USER_TRACE("AG mic ERROR VOL %d", vol);
    }
}

void bt_hfp_ag_cind_response(U8 mux_id, hfp_cind_status_t *cind_status)
{
    char payload[24];
    U8 payload_len = snprintf(payload, sizeof(payload), "%d,%d,%d,%d,%d,%d,%d",
                              cind_status->service_status,
                              cind_status->call,
                              cind_status->callsetup,
                              cind_status->batt_level,
                              cind_status->signal,
                              cind_status->roam_status,
                              cind_status->callheld);
    hfp_ag_cind_response(mux_id, payload, payload_len);
    hfp_ag_at_cmd_result(mux_id, BTS2_SUCC);
}

void bt_hfp_ag_ind_status_update(U8 mux_id, U8 type, U8 val)
{
    char payload[6];
    U8 payload_len = snprintf(payload, sizeof(payload), "%u,%u", type, val);
    hfp_ag_ind_status_update(mux_id, payload, payload_len);
}

void bt_hfp_ag_brva_response(U8 mux_id, U8 val)
{
    if (0 <= val && val <= 1)
    {
        hfp_ag_brva_response(mux_id, val);
    }
    else
    {
        USER_TRACE("AG brva ERROR VOL %d", val);
    }
}

void bt_hfp_ag_set_inband(U8 mux_id, U8 val)
{
    if (0 <= val && val <= 1)
    {
        hfp_ag_set_inband(mux_id, val);
    }
    else
    {
        USER_TRACE("AG inband ERROR VOL %d", val);
    }
}

void bt_hfp_ag_cnum_response(U8 mux_id, hfp_phone_number_t *local_phone_num)
{
    char payload[40];
    U8 payload_len = snprintf(payload, sizeof(payload), ",\"%s\",%u, ,...", local_phone_num->phone_number, local_phone_num->type);

    hfp_ag_cnum_response(mux_id, payload, payload_len);
    hfp_ag_at_cmd_result(mux_id, BTS2_SUCC);
}

void bt_hfp_ag_set_btrh(U8 mux_id, U8 val)
{
    hfp_ag_set_btrh(mux_id, val);
}

void bt_hfp_ag_clcc_response(U8 mux_id, hfp_phone_call_info_t *call_info)
{
    char payload[100];
    int payload_len = snprintf(payload, sizeof(payload), "%d,%d,%d,%d,%d",  call_info->call_idx, call_info->call_dir,
                               call_info->call_status, call_info->call_mode, call_info->call_mtpty);
    if (call_info->phone_info.type != 0)
    {
        payload_len += snprintf(payload + payload_len, sizeof(payload) - payload_len - 3, ",\"%s\",%u",
                                call_info->phone_info.phone_number, call_info->phone_info.type);
    }

    hfp_ag_clcc_response(mux_id, payload, payload_len);
}

void bt_hfp_ag_cops_response(U8 mux_id, char *payload, U8 payload_len)
{
    hfp_ag_cops_response(mux_id, payload, payload_len);
}

void bt_hfp_ag_set_bcs(U8 mux_id, U8 code_id)
{
    hfp_ag_set_codec_id(mux_id, code_id);
}

void bt_hfp_ag_clip_response(U8 mux_id, hfp_phone_number_t *remote_phone_num)
{
    char payload[40];
    U8 payload_len = snprintf(payload, sizeof(payload), "\"%s\",%u", remote_phone_num->phone_number, remote_phone_num->type);

    hfp_ag_clip_response(mux_id, payload, payload_len);
}

void bt_hfp_ag_at_result_res(U8 mux_id, U8 res)
{
    hfp_ag_at_cmd_result(mux_id, res);
}

#endif