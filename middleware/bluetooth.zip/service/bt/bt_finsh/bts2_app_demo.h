/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _BTS2_APP_DEMO_H_
#define _BTS2_APP_DEMO_H_

#include <sys/stat.h>
#include <stdio.h>
#include "rtthread.h"

//add for pan project start
#include "bts2_type.h"
#include "bts2_bt.h"
#include "gap_api.h"
#include "bt_config.h"
#include "os_adaptor.h"


#include "hfp_type_api.h"

//#if defined(BSP_BTS2_PAN) || defined(BT_FINSH_PAN)
//#define CFG_PAN
//#endif
//add for pan project end

#ifdef __cplusplus
extern "C" {
#endif

#define RETURN_KEY        0x0D
#define RETURN_ENTER      0x0A
#define BACKSPACE_KEY     0x08
#define CLS               "cls"
#define ESCAPE_KEY        0x1B

//#define SPP_MAX_NUM 2
#define SPP_INSTANCE_UNDEFINED 0xFF

/*default link device */
//#define CFG_BD_NAP                  (0x0018)
//#define CFG_BD_UAP                  (0x11)
//#define CFG_BD_LAP                  (0x920182)

//20220727
#define CFG_BD_NAP                  (0xffff)
#define CFG_BD_UAP                  (0xff)
#define CFG_BD_LAP                  (0xffffff)

#define CBR_230400                  230400
#define CBR_460800                  460800
#define CBR_691200                  691200
#define CBR_921600                  921600

#define KEY_MSG                     0x0CBA

#define MAX_ENB_TIME                (0)
#define KEYB_CHK_TIMEOUT            (200*MILLISECOND)

#define MAX_DISCOV_RESS             (20)

#define MAX_ONLY_FILE_NAME_LEN      (260)

#define TIME_WITH_NO_DATA           (3000*MILLISECOND)

#ifndef CFG_TL_USB
#define CFG_COM_PORT                "COM1"
#define CFG_COM_PORT_BAUD_RATE      115200
#endif


#define CFG_PATH_SYB            '\\'


#define CFG_PIN_CODE               "0000"
#define CFG_MAX_HFP_CONN_NUM                2

typedef enum
{
    BTS_APP_IDLE,
    BTS_APP_STACK_READY,
    BTS_APP_PROFILE_READY,
} bts_app_state_t;


#ifdef CFG_SPP_SRV
typedef enum
{
    spp_srv_idle,
    spp_srv_enbd,
    spp_srv_conned
} bts2_spp_srv_st;
#endif

#ifdef CFG_SPP_SRV
typedef struct
{
    U8               sending;
    U8               srv_chnl;
    FILE             *cur_file_hdl;
    FILE             *wr_file_hdl;
    U32              cur_file_pos;
    U32              cur_file_size;
    char             file_name[MAX_ONLY_FILE_NAME_LEN];
    char             rd_file_name[20];
    U32              start_timer;
    U32              last_time;
    U32              time_id;
    U8               timer_flag;
    U32              counter;
    U32         rand_total_len;
    U16         rand_packet_len;
    U8          *rand_buf;
    U8          is_rand_going;
    U8          receive_first_packet;
    U16         mtu_size;
    void                    *next_struct;
} bts2_spp_service_list;

typedef struct
{
    BTS2S_BD_ADDR           bd_addr;
    U8                      device_id;
    U8                      cur_link_mode;
    BOOL                    exit_sniff_pending;
    U16                     spp_srv_mfs;
    U32                     service_list;
    bts2_spp_service_list *spp_service_list;
} bts2_spp_srv_inst_data;
#endif

#ifdef CFG_HFP_HF
typedef enum
{
    hfp_idle,       /* Initializing state */
    hfp_enbd,       /* Enable service state */
    hfp_disb,       /* Disable service state */
    hfp_conned,     /* SLC connected */
    hfp_calling     /* An active call */
} bts2_hfp_st;
#endif

#ifdef CFG_HFP_AG

typedef enum
{
    HFP_AG_APP_INIT,       /* Initializing state */
    HFP_AG_APP_OPENING,       /* Enable service state */
    HFP_AG_APP_OPEN,       /* Disable service state */
    HFP_AG_APP_CLOSING,     /* SLC connected */
} bts2_ag_st;

typedef struct
{
    BTS2S_BD_ADDR      ag_bd;
    hfp_device_state_t profile_state;
    hfp_device_state_t pre_profile_state;
    hfp_call_state_t call_state;
    U8 srv_chnl;
    U8 mux_id;
    U8 is_use;
} bts2_hfp_ag_device_info;

typedef struct
{
    bts2_ag_st st;
    bts2_ag_st old_st;
    U32 local_feature;
    bts2_hfp_ag_device_info devices_info[CFG_MAX_HFP_CONN_NUM];
} bts2_hfp_ag_inst_data;
#endif

#ifdef CFG_HFP_HF
typedef struct
{
    hfp_device_state_t profile_state;
    hfp_device_state_t pre_profile_state;
    /*
      profile_type 0 indicate hf connect
      profile_type 1 indicate hs connect
     */
    U8 profile_type;
    U8 srv_chnl;
    U8 mux_id;
    U8 is_use;
    U8 esco_flag;
    BOOL voice_flag;

    U32 peer_features;
    U16 sco_hdl;
    BTS2S_BD_ADDR         hfp_bd;
    hfp_cind_status_t cind_status;
} bts2_hfp_hf_device_info;

typedef struct
{
    bts2_hfp_st st;
    U32 local_feature;
    bts2_hfp_hf_device_info devices_info[CFG_MAX_HFP_CONN_NUM];
} bts2_hfp_hf_inst_data;
#endif

#ifdef BT_FINSH_PAN
#define PAN_MAX_NUM 2
typedef enum
{
    PAN_IDLE_ST,
    PAN_REG_ST,
    PAN_SDS_REG_ST,
    PAN_BUSY_ST
} bts2_pan_st;

typedef enum
{
    PAN_DEV_DISCONNECTED_ST,
    PAN_DEV_CONNECTING_ST,
    PAN_DEV_CONNECTED_ST,
    PAN_DEV_DISCONNECTING_ST
} bts2_pan_device_state_t;

typedef struct
{
    U8 mode;
    U8 is_use;
    bts2_pan_device_state_t state;
    U16 id;
    U16 local_role;
    U16 rmt_role;
    BTS2S_BD_ADDR bd_addr;
    U8 gn_sdp_pending;
    U8 gn_sdp_fail;
    U8 nap_sdp_pending;
    U8 nap_sdp_fail;
} bts2_pan_info_t;

typedef struct
{
    bts2_pan_st pan_st;
    U16 local_role;
    bts2_pan_info_t pan_info_list[PAN_MAX_NUM];
} bts2_pan_inst_data;
#endif
#ifdef CFG_AVRCP
#define AVRCP_COVER_ART_IMAGE_HANDLE_LEN   (8)
typedef struct
{
    BTS2S_BD_ADDR  rmt_bd;
    U8             role;
    ot_timer_id_t     avrcp_vol_time_handle;
    U8             play_status_notify;
    U8             ab_volume;//the absolute volue be set.
    U8             tgTlable_1;
    U8             playback_status;
    U8             abs_vol_support;//0:TG has not register absolute volume; 1:TG has register absolute volume.
    U8             tgTlable_2;
    U8             abs_volume_pending;
    U8             rmt_abs_sup;//remote device support absolute volume?
#ifdef CFG_AVRCP_COVER_ART
    U8             is_cover_connected;
    U8             need_reconnect;
    U8             has_image_hdl;
    U8             get_cover_art_pending;
    U8             need_update_cover_art;
    const char     avrcp_cover_art_image_handle[AVRCP_COVER_ART_IMAGE_HANDLE_LEN];
#endif
    U32            element_support;
} bts2_avrcp_conn;

typedef struct
{
    bts2_avrcp_conn conn[CFG_MAX_ACL_CONN_NUM];
    os_semaphore_t       volume_change_sem;
    U8             abs_volume_pending;
    U8             release_type;
    U8             tgTlable;
} bts2_avrcp_inst_data;
#endif


#ifdef CFG_HID
typedef enum
{
    hid_idle,
    hid_conned
} bts2_hid_st;

typedef struct
{
    BTS2S_BD_ADDR  rmt_bd;
    BOOL is_hid_device_role;
    rt_timer_t     hid_time_handle;
    rt_timer_t     hid_time_handle_reset_at_middle_ios;
    rt_timer_t     hid_time_handle_reset_report;
    U8        local_protocol_mode;
    U8        mode;
    BOOL      is_device_ios;
    BOOL      is_hid_point_calibrated;
    void     *device_input_data;
    void     *device_output_data;
    void     *device_feature_data;
} bts2_hid_conn;

typedef struct
{
    bts2_hid_conn conn[CFG_MAX_HID_CONN_NUM];
} bts2_hid_inst_data;
#endif
#ifdef CFG_BT_L2CAP_PROFILE
typedef struct
{
    U8 is_use;
    U8 device_state;
    U16 cid;
    U16 remote_mtu;
    U16 sco_hdl;
    BTS2S_BD_ADDR bd;
} bts2_bt_l2cap_device_info_inst;

typedef struct
{
    U8 conn_num;
    U8 reg_status;
    U16 local_psm;
    U16 local_mtu;
    bts2_bt_l2cap_device_info_inst device[CFG_MAX_ACL_CONN_NUM];
} bts2_bt_l2cap_inst_data_t;
#endif

typedef enum
{
    BTS_SCAN_MODE_IDLE = 0,
    BTS_SCAN_MODE_SETTING,
} bts_scan_mode_fsm_t;

/* app structure */
typedef struct
{
    /* name should prefix with app_ */
    U8                menu_id;
    U8                input_str_len;
    U8                input_str[512];
    U8                dev_idx;
    bts_app_state_t   state;

    void              *recv_msg;
    BOOL              inquiry_flag;
    U8                bd_list_num;
    U8                inquiry_list_num;
    BTS2S_BD_ADDR     bd_list[MAX_DISCOV_RESS];
    BTS2S_BD_ADDR     inquiry_list[MAX_DISCOV_RESS];
    //20220727
    BTS2S_BD_ADDR     last_conn_bd;
    BTS2S_BD_ADDR     pair_bd;
    BTS2S_BD_ADDR     local_bd;
    U8                pin_code_len;
    U8                pin_code[HCI_MAX_PIN_LEN];
    //U16               sdc_app_hdl;
    U16               phdl;

    /* HFP HF */
#ifdef CFG_HFP_HF
    bts2_hfp_hf_inst_data *hfp_hf_ptr;
    bts2_hfp_hf_inst_data hfp_hf_inst;
#endif
#ifdef CFG_HFP_AG
    bts2_hfp_ag_inst_data  hfp_ag_inst;
#endif
    /* SPP */
    /* name should prefix with spp_ */

#ifdef CFG_SPP_SRV
    bts2_spp_srv_inst_data *spp_srv_inst_ptr;
    bts2_spp_srv_inst_data spp_srv_inst[CFG_MAX_ACL_CONN_NUM];
    U8 select_device_id;
    U8 select_srv_chnl;
#endif

#ifdef CFG_AVRCP
    bts2_avrcp_inst_data avrcp_inst;
#endif

#ifdef CFG_HID
    bts2_hid_inst_data hid_inst;
#endif

#ifdef BT_FINSH_PAN
    bts2_pan_inst_data pan_inst;
    bts2_pan_inst_data *pan_inst_ptr;
#endif

#ifdef CFG_BT_L2CAP_PROFILE
    bts2_bt_l2cap_inst_data_t  bt_l2cap_profile_inst;
#endif
    //****************COMMOND SETTINGS*******************
    U8                 pre_menu_id;
    //U8                 conn_count;    //connections count
    //U8                 connect_mode;  //connect  mode
    //U8                 sec_mode;      //security  mode
    //U8                 sec_auth;      //security  authortiy
    //U8                 sec_encry;     //security  encription

    //U16                local_cls;           //local device services class
    //BTS2S_DEV_NAME     local_dmname[20];    //local device name
    //BTS2S_BD_ADDR      local_db;            //local device services class
    //U8                 cfg_fname[MAX_ONLY_FILE_NAME_LEN];       //setting filename
    //U8                 cfg_hist_fname[MAX_ONLY_FILE_NAME_LEN];  //history filename
    //U8                 discover_mode;       //discove mode
    //U8                 manuafacture[20];    //bluetooth chip manuafacture

    //U8                 lmp_version;
    //U8                 hci_version;
    //U8                 l2cap_version;
    U8                 scan_mode;
    U8                 target_scan_mode;
    U8                 scan_mode_fsm;
} bts2_app_stru;

void key_msg_svc(void);
void hdl_keyb_msg(U8 thechar, bts2_app_stru *bts2_app_data);
void bt_init_profile(bts2_app_stru *bts2_app_data);
void app_fn_init(void **pp);
void app_fn_rel(void **pp);
void app_fn_hdl(void **pp);
void app_fn_hdl_ext(void **pp);

extern void bt_log_output(uint8_t tag, char *fmt, ...);

/* used by upper layer to get application global structure */
bts2_app_stru *getApp(void);

#if defined(BSP_BT_CUSTOMIZE_LOG) && !defined(BSP_BT_LOG_OFF)
#define USER_TRACE_ON
#define INFO_TRACE_ON
// #define BT_SPP_DEBUG_ENABLE
#endif

/* used to trace menu/key information have to displayed to the end user */
#if defined(USER_TRACE_ON)
#define USER_TRACE(...)  bt_log_output(BT_TAG_I, __VA_ARGS__)
#else // !USER_TRACE_ON
#ifdef BSP_BT_LOG_OFF
#define USER_TRACE(...)
#else // !BSP_BT_LOG_OFF
#define USER_TRACE       LOG_I
#endif // BSP_BT_LOG_OFF
#endif // USER_TRACE_ON



#if defined(BT_SPP_DEBUG_ENABLE)
#define BT_SPP_DEBUG(...)    bt_log_output(BT_TAG_D, __VA_ARGS__)
#else // !BT_SPP_DEBUG_ENABLE
#ifdef BSP_BT_LOG_OFF
#define BT_SPP_DEBUG(...)
#else // !BSP_BT_LOG_OFF
#define BT_SPP_DEBUG         LOG_D
#endif // BSP_BT_LOG_OFF
#endif // BT_SPP_DEBUG_ENABLE

/* used to trace debug information helpful for the developer */
#if defined(INFO_TRACE_ON)
#define INFO_TRACE(...)  bt_log_output(BT_TAG_D, __VA_ARGS__)
#else // !INFO_TRACE_ON
#ifdef BSP_BT_LOG_OFF
#define INFO_TRACE(...)
#else // !BSP_BT_LOG_OFF
#define INFO_TRACE       LOG_D
#endif // BSP_BT_LOG_OFF
#endif // INFO_TRACE_ON


#ifdef __cplusplus
}
#endif

#endif
