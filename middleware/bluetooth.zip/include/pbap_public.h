/*
 * SPDX-FileCopyrightText: 2019-2025 SiFli Technologies(Nanjing) Co., Ltd
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef _PBAP_PUBLIC_H_
#define _PBAP_PUBLIC_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Bit mask definition for remote device supported repositories */
#define PBAP_REP_LOCAL (1<<0)   /* Mask for Local Repository */
#define PBAP_REP_SIM  (1<<1)    /* Mask for SIM1 Repository  */

/* PhoneBook repositories */
typedef enum
{
    PBAP_CURRENT,
    PBAP_LOCAL,
    PBAP_SIM1,
    PBAP_UNKNOWN_REPO
} BTS2E_PBAP_PHONE_REPOSITORY;

/* Phone Book Objects */
typedef enum
{
    PBAP_TELECOM,
    PBAP_PB,
    PBAP_ICH,
    PBAP_OCH,
    PBAP_MCH,
    PBAP_CCH,
    PBAP_UNKNOWN_PHONEBOOK
} BTS2E_PBAP_PHONE_BOOK;

/* Order values for use with the PullvCardListing function. */
typedef enum
{
    PBAP_ORDER_IDX = 0x00,      /* Indexed. */
    PBAP_ORDER_ALPHA = 0x01,    /* Alphanumeric */
    PBAP_ORDER_PHONE = 0x02     /* Phonetic */
} BTS2E_PBAP_ORDER_VALUES;

/* Search Attributes to use with the PullvCardListing function. */
typedef enum
{
    PBAP_SEARCH_NAME = 0x00,    /* Name. */
    PBAP_SEARCH_NUMBER = 0x01,  /* Number */
    PBAP_SEARCH_SOUND = 0x02    /* Sound */
} BTS2E_PBAP_SEARCH_VALUES;

/* vCard formats to use with the PullvCardEntry and PullPhonebook functions. */
typedef enum
{
    PBAP_FORMAT_21 = 0x00,  /* vCard 2.1. */
    PBAP_FORMAT_30 = 0x01,  /* vCard 3.0 */
} BTS2E_PBAP_VCARD_FORMAT;

/* Single Response Mode values to use with PBAP GET functions. */
typedef enum
{
    PBAP_SRM_DISABLE = 0x00,    /* Disable Single Response Mode */
    PBAP_SRM_ENABLE  = 0x01,    /* Enable Single Response Mode */
    PBAP_SRM_DEFAULT           /* Do not send SRM header */
} BTS2S_PBAP_SRM_VALUES;

typedef enum
{
    PBAP_SRMP_NEXT    = 0x00,   /* Next */
    PBAP_SRMP_WAIT    = 0x01,   /* Wait */
    PBAP_SRMP_DEFAULT          /* Do not send SRMP header */
} BTS2S_PBAP_SRMP_VALUES;

/* vCard selector operator values to use with PBAP GET functions. */
typedef enum
{
    PBAP_VCARD_SELECTOR_OPERATOR_OR      = 0x00, /* OR */
    PBAP_VCARD_SELECTOR_OPERATOR_AND     = 0x01, /* AND */
    PBAP_VCARD_SELECTOR_OPERATOR_DEFAULT         /* Do not send vCardSelectorOperator */
} BTS2S_PBAP_VCARD_SELECTOR_OPERATOR_VALUES;

typedef enum
{
    PBAP_VCARD_PROP_VERSION                 = (1ULL << 0),
    PBAP_VCARD_PROP_FN                      = (1ULL << 1),
    PBAP_VCARD_PROP_N                       = (1ULL << 2),
    PBAP_VCARD_PROP_PHOTO                   = (1ULL << 3),
    PBAP_VCARD_PROP_BDAY                    = (1ULL << 4),
    PBAP_VCARD_PROP_ADR                     = (1ULL << 5),
    PBAP_VCARD_PROP_LABEL                   = (1ULL << 6),
    PBAP_VCARD_PROP_TEL                     = (1ULL << 7),
    PBAP_VCARD_PROP_EMAIL                   = (1ULL << 8),
    PBAP_VCARD_PROP_MAILER                  = (1ULL << 9),
    PBAP_VCARD_PROP_TZ                      = (1ULL << 10),
    PBAP_VCARD_PROP_GEO                     = (1ULL << 11),
    PBAP_VCARD_PROP_TITLE                   = (1ULL << 12),
    PBAP_VCARD_PROP_ROLE                    = (1ULL << 13),
    PBAP_VCARD_PROP_LOGO                    = (1ULL << 14),
    PBAP_VCARD_PROP_AGENT                   = (1ULL << 15),
    PBAP_VCARD_PROP_ORG                     = (1ULL << 16),
    PBAP_VCARD_PROP_NOTE                    = (1ULL << 17),
    PBAP_VCARD_PROP_REV                     = (1ULL << 18),
    PBAP_VCARD_PROP_SOUND                   = (1ULL << 19),
    PBAP_VCARD_PROP_URL                     = (1ULL << 20),
    PBAP_VCARD_PROP_UID                     = (1ULL << 21),
    PBAP_VCARD_PROP_KEY                     = (1ULL << 22),
    PBAP_VCARD_PROP_NICKNAME                = (1ULL << 23),
    PBAP_VCARD_PROP_CATEGORIES              = (1ULL << 24),
    PBAP_VCARD_PROP_PROID                   = (1ULL << 25),
    PBAP_VCARD_PROP_CLASS                   = (1ULL << 26),
    PBAP_VCARD_PROP_SORT_STRING             = (1ULL << 27),
    PBAP_VCARD_PROP_X_IRMC_CALL_DATETIME    = (1ULL << 28),
    PBAP_VCARD_PROP_X_BT_SPEEDDIALKEY       = (1ULL << 29),
    PBAP_VCARD_PROP_X_BT_UCI                = (1ULL << 30),
    PBAP_VCARD_PROP_X_BT_UID                = (1ULL << 31),

    /* bit 32 ~ 38: Reserved for future use */
    PBAP_VCARD_PROP_PROPRIETARY_FILTER      = (1ULL << 39),

    /* bit 40 ~ 63: Reserved for proprietary filter usage */
} BTS2S_PBAP_VCARD_PROPERTY_BITS;

/* PBAP application default parameters values */
#define PBAP_ORDER_DEFAULT              PBAP_ORDER_IDX     /* Order Index */
#define PBAP_SEARCH_ATTR_DEFAULT        PBAP_SEARCH_NAME   /* Search Attribute [Name] */
/* Maximum List Count, The value 65535 means that the number of entries is not restricted */
#define PBAP_MAX_LIST_DEFAULT           65535
#define PBAP_LIST_START_OFFSET_DEFAULT  0   /* List Start Offset, the offset of the first entry */
#define PBAP_FORMAT_DEFAULT             PBAP_FORMAT_21  /* The format vCard 2.1 is the default format */


/* Filter Attribute Mask Values */
#define PBAP_FILTER_VERSION     (1<<0)  /* vCard Version */
#define PBAP_FILTER_FN          (1<<1)  /* Formatted Name (FN) */
#define PBAP_FILTER_N           (1<<2)  /* Structured Presentation of Name (N) */
#define PBAP_FILTER_PHOTO       (1<<3)  /* Photo Associated with the name (PHOTO) */
#define PBAP_FILTER_BDAY        (1<<4)  /* Birthday (BDAY) */
#define PBAP_FILTER_ADR         (1<<5)  /* Delivery Address (ADR) */
#define PBAP_FILTER_LABEL       (1<<6)  /* Delivery Label (LABEL) */
#define PBAP_FILTER_TEL         (1<<7)  /* Telephone Number (TEL) */
#define PBAP_FILTER_EMAIL       (1<<8)  /* Electronic Mail Address (EMAIL) */
#define PBAP_FILTER_MAILER      (1<<9)  /* Electronic Mail (MAILER) */
#define PBAP_FILTER_TZ          (1<<10) /* Time Zone (TZ) */
#define PBAP_FILTER_GEO         (1<<11) /* Geographic Position (GEO) */
#define PBAP_FILTER_TITLE       (1<<12) /* Job Title (TITLE) */
#define PBAP_FILTER_ROLE        (1<<13) /* Role within the Organization (ROLE) */
#define PBAP_FILTER_LOGO        (1<<14) /* Organization Logo (LOGO) */
#define PBAP_FILTER_AGENT       (1<<15) /* vCard of person representing (AGENT) */
#define PBAP_FILTER_ORG         (1<<16) /* Name of Organization (ORG) */
#define PBAP_FILTER_NOTE        (1<<17) /* Comments (NOTE) */
#define PBAP_FILTER_REV         (1<<18) /* vCard Revision (REV) */
#define PBAP_FILTER_SOUND       (1<<19) /* Pronunciation of Name (SOUND) */
#define PBAP_FILTER_URL         (1<<20) /* Uniform Resource Locator (URL) */
#define PBAP_FILTER_UID         (1<<21) /* Unique ID (UID) */
#define PBAP_FILTER_KEY         (1<<22) /* Public Encryption Key (KEY) */
#define PBAP_FILTER_NICKNAME    (1<<23) /* Nickname (NICKNAME) */
#define PBAP_FILTER_CATAGORY    (1<<24) /* Categories (CATAGORIES) */
#define PBAP_FILTER_PROID       (1<<25) /* Product ID (PROID) */
#define PBAP_FILTER_CLASS       (1<<26) /* Class Information (CLASS) */
#define PBAP_FILTER_SORT        (1<<27) /* String used for sorting operations (SORT-STRING) */
#define PBAP_FILTER_CALL_DATETIME (1<<28) /* Timestamp (X-IRMC-CALL-DATETIME) */

/* vCard version 2.1 Mandatory attributes */
#define PBAP_FILTER_VCARD21 (PBAP_FILTER_N | PBAP_FILTER_TEL)
/* vCard version 3.0 Mandatory attributes */
#define PBAP_FILTER_VCARD30 (PBAP_FILTER_FN | PBAP_FILTER_TEL)

#ifdef __cplusplus
}
#endif

#endif


